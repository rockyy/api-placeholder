package com.hdfcbank.insurance.hli.process.models.enums;

import lombok.Getter;

import java.util.Arrays;
import java.util.Locale;

@Getter
public enum OccupationMapping {

    EMPLOYED("Salaried"),
    SELF_EMPLOYED("Self Employee"),
    STUDENT(OccupationMapping.OTHER_OCCUPATION),
    HOME_MAKER(OccupationMapping.OTHER_OCCUPATION),
    RETIRED(OccupationMapping.OTHER_OCCUPATION),
    PENSIONER(OccupationMapping.OTHER_OCCUPATION),
    UN_EMPLOYED(OccupationMapping.OTHER_OCCUPATION);

    private static final String OTHER_OCCUPATION = "Others";

    private final String mappedValue;

    OccupationMapping(String mappedValue) {
        this.mappedValue = mappedValue;
    }

    /**
     * Converts string input to enum safely and returns mapped value.
     */
    public static String getMappedValue(String input) {
        if (input == null) {
            return OTHER_OCCUPATION;
        }

        String normalized = input.toUpperCase(Locale.ROOT).replace(" ", "_");

        return Arrays.stream(OccupationMapping.values())
                .filter(e -> normalized.equals(e.name()))
                .findFirst()
                .map(OccupationMapping::getMappedValue)
                .orElse(OTHER_OCCUPATION);
    }
}
