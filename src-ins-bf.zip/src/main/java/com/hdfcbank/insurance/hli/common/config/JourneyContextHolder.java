package com.hdfcbank.insurance.hli.common.config;

import com.hdfcbank.common.models.vo.journey.JourneyData;

public class JourneyContextHolder {

    private JourneyContextHolder() {
    }

    private static final ThreadLocal<JourneyData> journeyDataHolder = new ThreadLocal<>();

    public static void setJourneyData(JourneyData journeyData) {
        journeyDataHolder.set(journeyData);
    }

    public static JourneyData getJourneyData() {
        return journeyDataHolder.get();
    }

    public static void clear() {
        journeyDataHolder.remove();
    }
}
