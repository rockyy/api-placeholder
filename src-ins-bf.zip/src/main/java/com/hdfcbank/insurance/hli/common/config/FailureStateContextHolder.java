package com.hdfcbank.insurance.hli.common.config;

import com.hdfcbank.insurance.hli.common.enums.JourneyStateName;

public class FailureStateContextHolder {

    private FailureStateContextHolder() {
    }

    private static final ThreadLocal<JourneyStateName> FAILURE_STATE = new ThreadLocal<>();
    private static final ThreadLocal<String> JOURNEY_ID = new ThreadLocal<>();

    public static void setJourneyId(String journeyId) {
        JOURNEY_ID.set(journeyId);
    }

    public static String getJourneyId() {
        return JOURNEY_ID.get();
    }

    public static void clearJourneyID() {
        JOURNEY_ID.remove();
    }


    public static void set(JourneyStateName state) {
        FAILURE_STATE.set(state);
    }

    public static JourneyStateName get() {
        return FAILURE_STATE.get();
    }

    public static void clear() {
        FAILURE_STATE.remove();
    }
}
