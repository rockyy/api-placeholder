package com.hdfcbank.insurance.hli.process.service.impl;

import tools.jackson.databind.JsonNode;
import tools.jackson.databind.ObjectMapper;
import com.hdfcbank.adapters.clients.feign.journey.JourneyServiceFeignClient;
import com.hdfcbank.common.models.vo.core.ApiResponse;
import com.hdfcbank.common.models.vo.journey.JourneyData;
import com.hdfcbank.insurance.adapter.process.models.Product;
import com.hdfcbank.insurance.adapter.process.models.request.CurateProductRequest;
import com.hdfcbank.insurance.adapter.process.models.request.RecommendedProductRequest;
import com.hdfcbank.insurance.adapter.process.models.response.ContentGroupResponse;
import com.hdfcbank.insurance.adapter.process.models.response.CurateProductResponse;
import com.hdfcbank.insurance.adapter.process.models.response.RecommendedProductResponse;
import com.hdfcbank.insurance.hli.common.config.JourneyContextHolder;
import com.hdfcbank.insurance.hli.common.constant.HLICommonConstants;
import com.hdfcbank.insurance.hli.common.enums.JourneyStateName;
import com.hdfcbank.insurance.hli.process.models.HLIProcessConstant;
import com.hdfcbank.insurance.hli.process.models.mapper.HLIProductMapping;
import com.hdfcbank.insurance.hli.process.models.request.DecisionParameterConfig;
import com.hdfcbank.insurance.hli.process.models.response.HLICurateProductResponse;
import com.hdfcbank.insurance.hli.process.models.response.HLIRecommendedProductResponse;
import com.hdfcbank.insurance.hli.process.service.HLIProductService;
import com.hdfcbank.insurance.hli.util.JourneyUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.jetbrains.annotations.NotNull;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.*;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import static com.hdfcbank.insurance.hli.util.JourneyUtil.extractLeadId;


@Service
@RequiredArgsConstructor
@Slf4j
public class HLIProductServiceImpl implements HLIProductService {


    private final DecisionParameterConfig decisionParameterConfig;
    private final ProcessServiceCall processServiceCall;
    private final JourneyServiceFeignClient journeyServiceFeignClient;
    private final ObjectMapper objectMapper;

    /**
     * This method initiates the flow to fetch recommended products for a given journey.
     * <p>
     * Steps:
     * 1. Fetch journey details using the provided journey ID from the Journey Service.
     * 2. Validate if journey data exists.
     * 3. If not found, return an input validation error response.
     *
     * @return ApiResponse containing {@link HLIRecommendedProductResponse} or error details
     */
    @Override
    public ApiResponse<HLIRecommendedProductResponse> getRecommendedProducts() {
        JourneyData journeyData = JourneyContextHolder.getJourneyData();
        String leadId = extractLeadId(journeyData);
        RecommendedProductRequest recommendedRequest = RecommendedProductRequest.builder().leadId(leadId).decisionParameters(buildDecisionParameters(journeyData, decisionParameterConfig)).build();
        RecommendedProductResponse recommendedResponse = processServiceCall.recommendedProductCall(journeyData.getJourneyId(), recommendedRequest);
        log.info("Recommended product found");
        ContentGroupResponse contentResponse = processServiceCall.contentGroupCall(HLIProductMapping.mapContentGroupRequest(recommendedResponse), journeyData.getJourneyId());
        int loanTermYears = Integer.parseInt(objectMapper.convertValue(JourneyUtil.getByPath(journeyData.getJourneyDetail().getSystemData(), HLICommonConstants.GET_LOAN_TERM), String.class)) / 12;
        HLIRecommendedProductResponse mappedResponse = HLIProductMapping.recommendedResponseMapping(recommendedResponse, contentResponse, loanTermYears,journeyData);
        journeyServiceFeignClient.update(JourneyUtil.toUpdateSystemDataRequest(journeyData.getJourneyId(), HLICommonConstants.RECOMMENDED_PRODUCT, mappedResponse, JourneyStateName.RECOMMENDED_PRODUCT_SUCCESS));
        return ApiResponse.success(mappedResponse);
    }

    @Override
    public ApiResponse<RecommendedProductResponse> getInsuranceProducts() {
        JourneyData journeyData = JourneyContextHolder.getJourneyData();
        String leadId = extractLeadId(journeyData);
        RecommendedProductRequest recommendedRequest = RecommendedProductRequest.builder().leadId(leadId).decisionParameters(buildDecisionParameters(journeyData, decisionParameterConfig)).build();
        RecommendedProductResponse recommendedResponse = processServiceCall.recommendedProductCall(journeyData.getJourneyId(), recommendedRequest);
        CurateProductRequest curateProductRequest = CurateProductRequest.builder().leadId(leadId).decisionParameters(buildDecisionParameters(journeyData, decisionParameterConfig)).build();
        CurateProductResponse curateAPIResponse = processServiceCall.curateProductCall(journeyData.getJourneyId(), curateProductRequest);
        ContentGroupResponse contentResponse = processServiceCall.contentGroupCall(HLIProductMapping.toContentGroupRequest(curateAPIResponse), journeyData.getJourneyId());
        curateAPIResponse.getProducts().forEach(productDTO -> extractProductDetail(productDTO, contentResponse));
        recommendedResponse.setProducts(curateAPIResponse.getProducts());
        double annualRoi = Double.parseDouble(objectMapper.convertValue(JourneyUtil.getByPath(journeyData.getJourneyDetail().getSystemData(), HLICommonConstants.LOAN_DETAIL_MIN_RATE_OF_INTEREST), String.class));
        if(Objects.nonNull(recommendedResponse.getCombos())){
            recommendedResponse.getCombos().getFixed().forEach(fixedCombo -> {
                fixedCombo.setLoanTerm(getMaxTenure(fixedCombo));
                fixedCombo.setSumInsured(getTotalRevisedSumInsured(fixedCombo));
                fixedCombo.setTotalEmiValue(getTotalEmi(fixedCombo, annualRoi,journeyData));
            });
        }
        if(Objects.nonNull(recommendedResponse.getCombos())){
            recommendedResponse.getCombos().getFixed().forEach(fixedCombo -> {
                fixedCombo.setLoanTerm(getMaxTenure(fixedCombo));
                fixedCombo.setSumInsured(getTotalRevisedSumInsured(fixedCombo));
                fixedCombo.setTotalEmiValue(getTotalEmi(fixedCombo, annualRoi,journeyData));
            });
        }
        journeyServiceFeignClient.update(JourneyUtil.toUpdateSystemDataRequest(journeyData.getJourneyId(), HLICommonConstants.RECOMMENDED_PRODUCT, recommendedResponse, JourneyStateName.RECOMMENDED_PRODUCT_SUCCESS));
        return ApiResponse.success(recommendedResponse);
    }

    private static void extractProductDetail(Product productDTO, ContentGroupResponse contentResponse) {
        Optional<ContentGroupResponse.DataItem> optionalDataItem = contentResponse.getData().stream().filter(dataItem -> dataItem.getCode().equals(productDTO.getCode())).findFirst();
        if (optionalDataItem.isPresent() && optionalDataItem.get().getContentGroup() != null) {
            productDTO.setContentGroup(optionalDataItem.get().getContentGroup());
            if(optionalDataItem.get().getContentGroup().getSections() != null) {
                Optional<ContentGroupResponse.Section> optionalSection = optionalDataItem.get().getContentGroup().getSections().stream().filter(section -> section.getCode().equals(HLIProcessConstant.SECTION_VIEW_POLICY_DETAILS)).findFirst();
                optionalSection.ifPresent(section -> section.getDetails().forEach(detail -> {
                    productDTO.setPdfTitle(detail.getInfo());
                    productDTO.setPdfUrl(detail.getInfo3());
                }));
            }
        }
    }

    @NotNull
    private static BigDecimal getTotalEmi(RecommendedProductResponse.FixedCombo fixedCombo, double annualRoi,JourneyData journeyData) {
        AtomicReference<BigDecimal> totalEmi = new AtomicReference<>(BigDecimal.ZERO);
        List<String> tenureList = fixedCombo.getProducts().stream().map(tenure->String.valueOf(tenure.getSuggestedTenure())).toList();
        fixedCombo.getProducts().forEach(product -> {
            BigDecimal emi = HLIProductMapping.emiCalculation(tenureList,journeyData,product.getPremium().toString());
            product.setEmiValue(emi.doubleValue());
            totalEmi.updateAndGet(cur -> cur.add(emi));
        });
        return totalEmi.get().setScale(0, RoundingMode.UP);
    }

    private static double getTotalRevisedSumInsured(RecommendedProductResponse.FixedCombo fixedCombo) {
        return fixedCombo.getProducts().stream()
                .map(RecommendedProductResponse.ComboProduct::getSuggestedRevisedSumInsured)
                .filter(Objects::nonNull)
                .map(BigDecimal::doubleValue)
                .reduce(0.0, Double::sum);
    }

    private static int getMaxTenure(RecommendedProductResponse.FixedCombo fixedCombo) {
        return fixedCombo.getProducts().stream()
                .map(RecommendedProductResponse.ComboProduct::getSuggestedTenure)
                .filter(Objects::nonNull)
                .max(Integer::compareTo)
                .orElse(0);
    }

    /**
     * This method initiates the flow to fetch curate product data for a journey.
     * <p>
     * Steps:
     * 1. Retrieve journey details using journey ID.
     * 2. Validate existence of journey data.
     * 3. Return success response with curated product data or error response.
     *
     * @return ApiResponse containing {@link HLICurateProductResponse} or validation error
     */
    @Override
    public ApiResponse<HLICurateProductResponse> getCurateProducts() {
        JourneyData journeyData = JourneyContextHolder.getJourneyData();
        String leadId = extractLeadId(journeyData);
        CurateProductRequest curateProductRequest = CurateProductRequest.builder().leadId(leadId).build();
        CurateProductResponse curateAPIResponse = processServiceCall.curateProductCall(journeyData.getJourneyId(), curateProductRequest);
        log.info("Curate product response mapping started");
        return ApiResponse.success(HLIProductMapping.curateProductsResponseMapping(curateAPIResponse));
    }


    public List<RecommendedProductRequest.DecisionParameter> buildDecisionParameters(JourneyData journeyData, DecisionParameterConfig config) {

        Map<String, String> mapObject = decisionParameterConfig.getParameters();
        log.info("map Object :: {}", mapObject);

        Map<String, String> parameters = config.getParameters(); // explicitly typed

        return parameters.entrySet().stream()
                .map(entry
                        -> new RecommendedProductRequest.DecisionParameter(entry.getKey(),
                        mapDecisionParams(journeyData, entry.getValue())))
                .collect(Collectors.toList());
    }




    private String mapDecisionParams(JourneyData journeyData, String node) {

        if (!node.startsWith("getLoanDetail.customers")) {
            return (String) JourneyUtil.getByPath(journeyData.getJourneyDetail().getSystemData(), node);
        }
        JsonNode rootNode = objectMapper.valueToTree(journeyData.getJourneyDetail().getSystemData());
        JsonNode customersNode = rootNode.path("getLoanDetail").path("customers");
        // Find first customer with capacity "B"
        JsonNode customerWithB = StreamSupport.stream(customersNode.spliterator(), false).filter(c -> "B".equalsIgnoreCase(c.path("capacity")
                .asText())).findFirst().orElse(null);
        if (customerWithB == null) {
            return null;
        }
        if (node.equals("getLoanDetail.customers.capacity")) {
            return customerWithB.path("capacity").asText();
        }
        if (node.equals("getLoanDetail.customers.income.consideredForEligibility")) {
            return customerWithB.path("income").path("consideredForEligibility").asText();
        }
        return (String) JourneyUtil.getByPath(journeyData.getJourneyDetail().getSystemData(), node);
    }


}
