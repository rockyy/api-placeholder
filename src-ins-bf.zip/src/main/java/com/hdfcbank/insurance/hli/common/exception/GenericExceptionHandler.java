package com.hdfcbank.insurance.hli.common.exception;

import com.hdfcbank.adapters.clients.feign.journey.JourneyServiceFeignClient;
import com.hdfcbank.common.models.constant.MDCConstants;
import com.hdfcbank.common.models.vo.core.ApiResponse;
import com.hdfcbank.common.models.vo.core.ErrorRef;
import com.hdfcbank.exception.CoolOffLimitExceededException;
import com.hdfcbank.insurance.adapter.common.util.CustomValidationStatus;
import com.hdfcbank.insurance.hli.common.constant.HLICommonConstants;
import com.hdfcbank.insurance.hli.common.enums.HLICustomCommonApiStatusCodes;
import com.hdfcbank.insurance.hli.util.JourneyUtil;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.MDC;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.util.Arrays;
import java.util.List;


@RestControllerAdvice
@Order(1)
@Slf4j
@AllArgsConstructor
public class GenericExceptionHandler {

    private final JourneyServiceFeignClient journeyServiceFeignClient;

    @ExceptionHandler(CustomValidationException.class)
    public ResponseEntity<ApiResponse<Void>> handle(CustomValidationException e) {
        log.error("CustomValidationException:: {}", e.getMessage(), e);
        CustomValidationStatus customValidationStatus = CustomValidationStatus.builder()
                .title(e.getTitle())
                .type(e.getScreen()).build();
        customValidationStatus.setCode(HLICustomCommonApiStatusCodes.CUSTOM_VALIDATION_EXCEPTION.getCode());
        customValidationStatus.setMessage(e.getMessage());
        customValidationStatus.setErrors(e.getErrors());
        if(!(HLICommonConstants.INLINE.equalsIgnoreCase(customValidationStatus.getType()))){
            JourneyUtil.updateJourneyDetailDropOff(
                    journeyServiceFeignClient.fetch(MDC.get(MDCConstants.JOURNEY_ID)),
                    journeyServiceFeignClient,
                    customValidationStatus);
        }

        return ok(ErrorRef.customValidation(), customValidationStatus);
    }

    private ResponseEntity<ApiResponse<Void>> ok(ErrorRef errorRef, CustomValidationStatus status) {
        ApiResponse<Void> body = ApiResponse.customValidationError(errorRef, status.getType(), status.getTitle(), status.getErrors());
        return new ResponseEntity<>(body, HttpStatus.OK);
    }

    @ExceptionHandler(CoolOffLimitExceededException.class)
    public ResponseEntity<ApiResponse<Void>> handle(CoolOffLimitExceededException e) {
        log.error("CustomValidationException:: {}", e.getMessage(), e);
        String cooloffScreen = "FULL_SCREEN";
        String cooloffTitle = "Verification Failed";
        CustomValidationStatus customValidationStatus = CustomValidationStatus.builder()
                .title(cooloffTitle)
                .type(cooloffScreen).build();
        customValidationStatus.setCode(HLICustomCommonApiStatusCodes.CUSTOM_VALIDATION_EXCEPTION.getCode());
        customValidationStatus.setMessage(e.getApiResponseStatusCodeLiteral().getMessage());
        customValidationStatus.setErrors(Arrays.asList(e.getErrors()));
        JourneyUtil.updateJourneyDetailDropOff(
                journeyServiceFeignClient.fetch(MDC.get(MDCConstants.JOURNEY_ID)),
                journeyServiceFeignClient,
                customValidationStatus);
        return ok(ErrorRef.cooloff(), customValidationStatus);
    }
}
