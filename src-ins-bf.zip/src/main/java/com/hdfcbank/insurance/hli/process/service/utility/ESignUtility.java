package com.hdfcbank.insurance.hli.process.service.utility;

import tools.jackson.databind.ObjectMapper;
import com.hdfcbank.common.models.vo.journey.JourneyData;
import com.hdfcbank.insurance.adapter.process.models.response.GetLoanDetailResponse;
import com.hdfcbank.insurance.hli.common.constant.HLICommonConstants;
import com.hdfcbank.insurance.hli.process.models.BorrowersEsignDetail;
import com.hdfcbank.insurance.hli.process.models.enums.BorrowerEsignStatus;
import com.hdfcbank.insurance.hli.process.models.enums.JourneyEsignStatus;
import com.hdfcbank.insurance.hli.process.service.impl.proposalquestion.BorrowerUtility;
import com.hdfcbank.insurance.hli.util.JourneyUtil;
import lombok.experimental.UtilityClass;
import lombok.extern.slf4j.Slf4j;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@UtilityClass
@Slf4j
public class ESignUtility {

    public static BorrowersEsignDetail createBorrowerESignDetail(JourneyData journeyData, ObjectMapper objectMapper) {
        BorrowersEsignDetail borrowerESignDetail = new BorrowersEsignDetail();
        borrowerESignDetail.setJourneyEsignStatus(JourneyEsignStatus.INITIATED);
        Object loanDetail = JourneyUtil.getByPath(journeyData.getJourneyDetail().getSystemData(), HLICommonConstants.HOME_LOAN_DETAIL);
        GetLoanDetailResponse loanDetailResponse = objectMapper.convertValue(loanDetail, GetLoanDetailResponse.class);
        List<BorrowersEsignDetail.BorrowerInfo> signerInfoList = new ArrayList<>();
        loanDetailResponse.getCustomers().forEach(customer ->
            signerInfoList.add(BorrowersEsignDetail.BorrowerInfo.builder()
                    .borrower(BorrowerUtility.mapCustomerToBorrower(customer))
                    .borrowerEsignStatus(BorrowerEsignStatus.INITIATED)
                    .build()));
        borrowerESignDetail.setBorrowersInfo(signerInfoList);
        return borrowerESignDetail;
    }


    public static Optional<BorrowersEsignDetail> fetchBorrowerESignDetail(JourneyData journeyData, ObjectMapper objectMapper) {
        Object borrowerESignDetail = JourneyUtil.getByPath(journeyData.getJourneyDetail().getSystemData(), HLICommonConstants.BORROWER_ESIGN_DETAIL);
        return Optional.ofNullable(objectMapper.convertValue(borrowerESignDetail, BorrowersEsignDetail.class));


    }

}
