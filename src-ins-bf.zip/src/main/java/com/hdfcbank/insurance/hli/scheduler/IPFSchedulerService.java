package com.hdfcbank.insurance.hli.scheduler;

import tools.jackson.databind.ObjectMapper;
import com.hdfcbank.insurance.adapter.process.models.request.CancelLeadRequest;
import com.hdfcbank.insurance.adapter.process.models.request.CancelLeadsResponse;
import com.hdfcbank.insurance.adapter.process.models.request.IPFStatusRequest;
import com.hdfcbank.insurance.adapter.process.models.response.IPFStatusResponse;
import com.hdfcbank.insurance.hli.common.constant.HLICommonConstants;
import com.hdfcbank.insurance.hli.common.properties.IPFSchedulerConfig;
import com.hdfcbank.insurance.hli.process.models.SubmitFinalProposalCallback;
import com.hdfcbank.insurance.hli.process.models.enums.CallbackType;
import com.hdfcbank.insurance.hli.process.models.mapper.HLICancelLead;
import com.hdfcbank.insurance.hli.process.models.request.CallbackRequest;
import com.hdfcbank.insurance.hli.process.service.CallbackService;
import com.hdfcbank.insurance.hli.process.service.impl.ProcessServiceCall;
import com.hdfcbank.insurance.hli.scheduler.entities.PurchaseIPFStatusEntity;
import com.hdfcbank.insurance.hli.scheduler.model.IPFStatus;
import com.hdfcbank.insurance.hli.scheduler.model.Status;
import com.hdfcbank.insurance.hli.scheduler.repo.PurchaseRepo;
import com.hdfcbank.insurance.hli.util.TextSanityUtil;
import jakarta.annotation.PostConstruct;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.time.Instant;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;

@Service
@Slf4j
@RequiredArgsConstructor
public class IPFSchedulerService {


    private final ProcessServiceCall processServiceCall;
    private final PurchaseRepo purchaseRepo;
    private final CallbackService callbackService;
    private final IPFSchedulerConfig ipfSchedulerConfig;

    private ScheduledExecutorService scheduler =null;

    private static final ObjectMapper objectMapper= new ObjectMapper();
    /**
     * worker threads to call IPF
     */
    private ExecutorService asyncExecutor;

    private ScheduledFuture<?> schedulerFuture;
    @PostConstruct
    public void init() {
        asyncExecutor = new ThreadPoolExecutor(
                ipfSchedulerConfig.getConfig().getCorePoolSize(),
                ipfSchedulerConfig.getConfig().getMaximumPoolSize(),
                ipfSchedulerConfig.getConfig().getKeepTimeAlive(),
                TimeUnit.MILLISECONDS,
                new ArrayBlockingQueue<>(ipfSchedulerConfig.getConfig().getThreadCapacity()),
                new ThreadPoolExecutor.CallerRunsPolicy()
        );

        scheduler = Executors.newSingleThreadScheduledExecutor();
    }
    /**
     * Entry point triggered by REST from scheduler microservice
     */
    public void processRecords(List<PurchaseIPFStatusEntity> list) {
        ensureExecutors();
        log.info("----------- IPF Scheduler Started -----------");

        SchedulerRecordsResult result = new SchedulerRecordsResult();

        List<PurchaseIPFStatusEntity> entityList =
                (list != null && !list.isEmpty())
                        ? list
                        : purchaseRepo.findByJourneyNameAndPurchaseStatusInAndIpfStatusIn(
                        HLICommonConstants.JOURNEY_NAME,
                        List.of(Status.PURCHASED_INITIATED,Status.PURCHASED, Status.IN_PROGRESS, Status.FAILED),
                        List.of(IPFStatus.PURCHASED.getIpfStatusName(), IPFStatus.APPR.getIpfStatusName(),
                                IPFStatus.SANC.getIpfStatusName(), IPFStatus.DBFX.getIpfStatusName())
                );

        result.totalRecords = entityList.size();

        if (entityList.isEmpty()) {
            log.info("No records to process");
            return;
        }

        AtomicInteger index = new AtomicInteger(0);

        schedulerFuture = scheduler.scheduleAtFixedRate(() -> {

            int tps = ipfSchedulerConfig.getConfig().getEntitiesToProcess();

            int startIndex = index.getAndAdd(tps);

            if (startIndex >= entityList.size()) {
                schedulerFuture.cancel(false);

                CompletableFuture.runAsync(() -> shutdownExecutors(result));

                return;
            }
            submitBatch(entityList, result, startIndex, tps);

        }, ipfSchedulerConfig.getConfig().getInitialDelay(), ipfSchedulerConfig.getConfig().getEntitiesProcessDuration(), TimeUnit.SECONDS);
    }

    private void submitBatch(List<PurchaseIPFStatusEntity> entityList, SchedulerRecordsResult result, int startIndex, int tps) {
        for (int j = 0; j < tps; j++) {
            int currentIndex = startIndex + j;
            if (currentIndex >= entityList.size()) {
                break;
            }
            PurchaseIPFStatusEntity entity = entityList.get(currentIndex);
            asyncExecutor.submit(() -> processRecord(result, entity));
        }
    }

    private void shutdownExecutors(SchedulerRecordsResult result) {
        try {
            asyncExecutor.shutdown();
            asyncExecutor.awaitTermination(30, TimeUnit.SECONDS);
        } catch (Exception e) {
            log.error("Executor shutdown error", e);
        } finally {
            if (!scheduler.isShutdown()) {
                scheduler.shutdown();
            }
        }
        log.info("Scheduler completed. Final Result -> {}", result);
    }

    private void ensureExecutors() {

        if (asyncExecutor == null || asyncExecutor.isShutdown() || asyncExecutor.isTerminated()) {
            asyncExecutor = new ThreadPoolExecutor(
                    ipfSchedulerConfig.getConfig().getCorePoolSize(),
                    ipfSchedulerConfig.getConfig().getMaximumPoolSize(),
                    ipfSchedulerConfig.getConfig().getKeepTimeAlive(),
                    TimeUnit.MILLISECONDS,
                    new ArrayBlockingQueue<>(ipfSchedulerConfig.getConfig().getThreadCapacity()),
                    new ThreadPoolExecutor.CallerRunsPolicy()
            );
        }

        if (scheduler == null || scheduler.isShutdown() || scheduler.isTerminated()) {
            scheduler = Executors.newSingleThreadScheduledExecutor();
        }
    }

    /**
     * Core record processing
     */
    private void processRecord(SchedulerRecordsResult result, PurchaseIPFStatusEntity entity) {
        markInProgress(entity);

        try {
            IPFStatusRequest request = fetchIPFRecord(entity);

            log.debug("Calling IPF API for entityId={}", TextSanityUtil.sanitize(entity.getId()));

            IPFStatusResponse response =
                    processServiceCall.checkIPFStatus(
                            request,
                            entity.getProductPurchaseRequest().getLoanDetail().getJourneyId()
                    );

            if (response != null) {
                updateJourney(response, entity);
                purchaseRepo.save(entity);
                result.getResponseReceived().getAndIncrement();
            }

        } catch (Exception ex) {

            log.error("IPF call failed entityId={} error={}",
                    TextSanityUtil.sanitize(entity.getId()), ex.getMessage());
            result.getResponseFailed().getAndIncrement();
            result.getFailedReasons().add(
                    "Record Id [" + entity.getId() + "] error [" + ex.getMessage() + "]");


        }

    }


    /**
     * Mark entity IN_PROGRESS
     */
    private void markInProgress(PurchaseIPFStatusEntity entity) {
        entity.setPurchaseStatus(Status.IN_PROGRESS);
        entity.setModifiedDate(Instant.now());
        purchaseRepo.save(entity);
    }

    /**
     * Update success journey
     */
    private void updateJourney(IPFStatusResponse ipfStatusResponse, PurchaseIPFStatusEntity entity) {
        if (!StringUtils.hasText(ipfStatusResponse.getIpfStatus())) {
            return;
        }
        if (ipfStatusResponse.getIpfStatus().equalsIgnoreCase(IPFStatus.CL.getIpfStatusName())
                || ipfStatusResponse.getIpfStatus().equalsIgnoreCase(IPFStatus.CN.getIpfStatusName())) {

            cancelLeadAndUpdateJourney(
                    ipfStatusResponse.getParentFileNumber(),
                    ipfStatusResponse.getJourneyId());
        }
        //ToDo need to update journey in all cases whether its cancelled or journey is successfully completed.
        entity.setPurchaseStatus(getNewPurchaseStatus(ipfStatusResponse.getIpfStatus()));
        entity.setModifiedDate(Instant.now());
        entity.setIpfStatus(ipfStatusResponse.getIpfStatus());
        entity.setPurchaseResponse(ipfStatusResponse);
    }

    private void cancelLeadAndUpdateJourney(String loanFileNumber, String journeyId) {

        CancelLeadsResponse response = processServiceCall.cancelLead(
                CancelLeadRequest.builder().loanFileNumber(loanFileNumber).build(),
                journeyId);

        response.getSuccessCancelledLeads().forEach(s -> {
            try {
                HLICancelLead cancelLead = new HLICancelLead(s, loanFileNumber);

                callbackService.performAction(
                        CallbackRequest.builder()
                                .callbackType(CallbackType.CANCEL_LEAD)
                                .data(objectMapper.writeValueAsString(cancelLead))
                                .build());

            } catch (Exception e) {
                log.error("Cancel lead callback failed {}", e.getMessage());
            }
        });
    }

    private Status getNewPurchaseStatus(String ipfStatus) {
        return successStatusSet().contains(ipfStatus)
                ? Status.SUCCESS
                : Status.IN_PROGRESS;
    }

    private Set<String> successStatusSet() {
        return Set.of(
                IPFStatus.CL.getIpfStatusName(),
                IPFStatus.CN.getIpfStatusName(),
                IPFStatus.FD_DBMD.getIpfStatusName()
        );
    }

    private IPFStatusRequest fetchIPFRecord(PurchaseIPFStatusEntity entity) {

        var purchaseRequest = entity.getProductPurchaseRequest();
        var loanDetail = purchaseRequest.getLoanDetail();
        var productInfo = purchaseRequest.getProductInfo();

        List<IPFStatusRequest.Policy> policies = new ArrayList<>();

        addPolicyIfPresent(policies, productInfo.getBgr());
        addPolicyIfPresent(policies, productInfo.getHca());

        if (productInfo.getCpplus() != null && !productInfo.getCpplus().isEmpty()) {
            addPolicyIfPresent(policies, productInfo.getCpplus().get(0));
        }

        return IPFStatusRequest.builder()
                .journeyId(loanDetail.getJourneyId())
                .parentFileNumber(loanDetail.getParentFileNumber())
                .policy(policies)
                .build();
    }

    private void addPolicyIfPresent(
            List<IPFStatusRequest.Policy> policies,
            SubmitFinalProposalCallback.SubmitILPSProposalResponse.Product product) {

        if (product != null && product.getInsuranceQuoteId() != null) {
            policies.add(IPFStatusRequest.Policy.builder()
                    .insuranceQuoteId(product.getInsuranceQuoteId())
                    .build());
        }
    }

    @Getter
    @Setter
    @ToString
    public static class SchedulerRecordsResult {
        int totalRecords;
        private AtomicInteger responseReceived = new AtomicInteger();

        private AtomicInteger responseFailed = new AtomicInteger();
        List<String> failedReasons = Collections.synchronizedList(new ArrayList<>());
    }

}
