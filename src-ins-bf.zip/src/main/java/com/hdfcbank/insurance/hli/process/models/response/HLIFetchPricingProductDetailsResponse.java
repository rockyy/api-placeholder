package com.hdfcbank.insurance.hli.process.models.response;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class HLIFetchPricingProductDetailsResponse {
    private List<ProductWiseQuestion> productWiseQuestions;

    @Getter
    @Setter
    @Builder
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class ProductWiseQuestion {

        private String code;
        private List<ProductQuestion> questions;
    }

    @Getter
    @Setter
    @Builder
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class ProductQuestion {

        private String questionKey;
        private String question;
        private String valueType;
        private List<String> options;
        private String description;
        private Boolean canComment;
        private List<ProductQuestion> subQuestions;
        private String stage;
        private String page;
        private String section;
        private Integer sequence;
        private Validation validations;
        private SpecialOption specialOption;
        private String entityId;
        private Boolean mandatory;
        private Boolean editable;
    }

    @Getter
    @Setter
    @Builder
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class Validation {

        private String validationType;
        private String validationValue;
        private String validationMessage;
    }

    @Getter
    @Setter
    @Builder
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class SpecialOption {

        private List<String> option;
        private String message;
        private String action;
        private Object data;
    }

}
