package com.hdfcbank.insurance.hli.process.models.mapper;


import com.hdfcbank.insurance.adapter.process.models.request.PremiumQuestionRequest;
import com.hdfcbank.insurance.hli.process.models.request.HLIFetchPricingRequest;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import java.util.List;

@Mapper(componentModel = "spring")
public interface HLIFetchPricingMapper {

    HLIFetchPricingMapper INSTANCE = Mappers.getMapper(HLIFetchPricingMapper.class);

    /**
     * Maps HLIFetchPricing to PremiumQuestionRequest.
     * leadId is passed explicitly.
     */
    default PremiumQuestionRequest toPremiumQuestionRequest(String leadId, HLIFetchPricingRequest request) {
        return PremiumQuestionRequest.builder().leadId(leadId).selectedProducts(mapProducts(request.getProduct())).build();
    }

    /**
     * Map list of HLIFetchPricing.Product to list of SelectedProduct.
     */
    default List<PremiumQuestionRequest.SelectedProduct> mapProducts(List<HLIFetchPricingRequest.Product> products) {

        return products.stream().map(product -> PremiumQuestionRequest.SelectedProduct.builder()
                .code(product.getCode()).entityIds(product.getAnswers().stream()
                        .map(HLIFetchPricingRequest.Product.PricingAnswer::getEntityId).distinct()
                        .toList()).build()).toList();
    }


    /**
     * Map HLIFetchPricing.Product to PremiumQuestionRequest.SelectedProduct.
     */
    default PremiumQuestionRequest.SelectedProduct mapProduct(HLIFetchPricingRequest.Product product) {
        List<String> entityIds = product.getAnswers().stream().map(HLIFetchPricingRequest.Product.PricingAnswer::getEntityId).toList();

        return PremiumQuestionRequest.SelectedProduct.builder().code(product.getCode()).entityIds(entityIds).build();
    }
}
