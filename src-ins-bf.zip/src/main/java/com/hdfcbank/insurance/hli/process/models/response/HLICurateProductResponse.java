package com.hdfcbank.insurance.hli.process.models.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serial;
import java.io.Serializable;
import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder

public class HLICurateProductResponse implements Serializable {

    private String timestamp;
    private List<Product> products;
    private List<Customer> customers;

    @Getter
    @Setter
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class Product implements Serializable{
        private String code;
        private String name;
        private String category;
        private List<ProductConfig> productConfig;
        private List<Cover> covers;
        private List<Feature> features;
        private LivePremiumRates livePremiumRates;
        private Popularity popularity;
    }

    @Getter
    @Setter
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class ProductConfig implements Serializable{
        private String key;
        private String value;
    }

    @Getter
    @Setter
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class Cover implements Serializable{
        private String coverType;
        private Integer limit;
        private String status;
    }

    @Getter
    @Setter
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class Feature implements Serializable{
        private String code;
        private String name;
        private String description;
        private Integer order;
    }

    @Getter
    @Setter
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class LivePremiumRates implements Serializable {
        @Serial
        private static final long serialVersionUID = 1L;

        private Double age18;
        private Double age30;
        private Double age50;
    }

    @Getter
    @Setter
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class Popularity implements Serializable {
        @Serial
        private static final long serialVersionUID = 1L;

        private Integer currentHolders;
        private Integer salesThisMonth;
    }

    @Getter
    @Setter
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class Customer implements Serializable {
        @Serial
        private static final long serialVersionUID = 1L;

        private String id;
        private String name;
        private String relationToBorrower;
        private Integer activePolicies;
    }
}

