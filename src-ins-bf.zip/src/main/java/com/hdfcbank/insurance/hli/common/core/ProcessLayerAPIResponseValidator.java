package com.hdfcbank.insurance.hli.common.core;

import com.hdfcbank.common.models.constant.CommonApiErrors;
import com.hdfcbank.common.models.constant.CommonApiStatusCodes;
import com.hdfcbank.common.models.vo.core.ApiResponse;
import com.hdfcbank.common.models.vo.core.ApiResponseStatus;
import com.hdfcbank.common.models.vo.core.ApiResponseStatusCodeLiteral;
import com.hdfcbank.common.models.vo.core.ErrorRef;
import com.hdfcbank.exception.BusinessValidationException;
import com.hdfcbank.insurance.adapter.process.clients.feign.core.GenericApiResponseStatusCodeLiteral;
import com.hdfcbank.insurance.hli.common.constant.HLICommonConstants;
import com.hdfcbank.insurance.hli.common.core.models.HLIAPIRequestName;
import com.hdfcbank.insurance.hli.common.core.properties.HLIStatusCodes;
import com.hdfcbank.insurance.hli.common.enums.HLICustomCommonApiStatusCodes;
import com.hdfcbank.insurance.hli.common.exception.CustomValidationException;
import com.hdfcbank.insurance.hli.util.TextSanityUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.function.Supplier;

@Slf4j
@Component
public class ProcessLayerAPIResponseValidator implements ApplicationContextAware {


    private static FailureStateRecorder failureStateRecorder;
    private static ApplicationContext applicationContext;

    public static <T> T validateApiResponse(HLIAPIRequestName apiName, ApiResponse<T> response, Supplier<T> emptySupplier) {
        HLIStatusCodes apiStatusCodes = applicationContext.getBean(HLIStatusCodes.class);
        String code = response.getStatus().getCode();
        if (null == code){
            throw new BusinessValidationException(CommonApiStatusCodes.DOWNSTREAM_API_ERROR, ErrorRef.of(CommonApiErrors.BUSVL.name()), "error - field is null");
        }
        if (StringUtils.equals("0000", code)) {
            return response.getData();
        }
        if(StringUtils.equals("8005", code)) {
            return emptySupplier.get();
        }
        if(StringUtils.equals("8006", code)) {
            ApiResponseStatus status = response.getStatus();
            throw new CustomValidationException(HLICustomCommonApiStatusCodes.CUSTOM_VALIDATION_EXCEPTION, HLICommonConstants.DETAILS_NOT_UPDATED, HLICommonConstants.INLINE, status.getErrors());
        }
        if (StringUtils.equals("5001", code)) {
            ApiResponseStatus status= response.getStatus();
            throw new CustomValidationException(HLICustomCommonApiStatusCodes.CUSTOM_VALIDATION_EXCEPTION,
                   Objects.nonNull(status)?status.getTitle():"Oops! It's Not You, It's Us.",
                   Objects.nonNull(status)?status.getType():"FULL_SCREEN",
            Objects.nonNull(status)?status.getErrors(): List.of());
        }
        HLIStatusCodes.StatusCodeDetails statusCodeDetails = Optional.ofNullable(apiStatusCodes.getMapping())
                .map(map -> map.get(apiName.getApiName()))
                .map(statusCodeMap -> statusCodeMap.get(code))
                .orElseGet(() -> new HLIStatusCodes.StatusCodeDetails(CommonApiStatusCodes.BUSINESS_VALIDATION_ERROR.getCode(),
                        CommonApiStatusCodes.BUSINESS_VALIDATION_ERROR.getMessage(), null));

        log.warn("Error occurred in ProcessLayerAPI: {} with error code: {}, error message: {}",
                TextSanityUtil.sanitize(apiName.getApiName()),
                TextSanityUtil.sanitize(code),
                TextSanityUtil.sanitize(response.getStatus().getMessage()));

        ApiResponseStatusCodeLiteral apiResponseStatusCodeLiteral = GenericApiResponseStatusCodeLiteral.of(statusCodeDetails.getCode(),
                statusCodeDetails.getMessageKey());
        if (StringUtils.isNotBlank(statusCodeDetails.getFailureStateName())){
            failureStateRecorder.recordFailureState(apiName, statusCodeDetails.getFailureStateName());
        }
        throw new BusinessValidationException(apiResponseStatusCodeLiteral, ErrorRef.of(CommonApiErrors.BUSVL.name()), response.getStatus().getErrors().toArray(new String[0]));
    }

    public static <T> T validateApiResponse(HLIAPIRequestName apiName, ApiResponse<T> response) {
        return validateApiResponse(apiName, response, () -> null);
    }

    @Override
    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
        ProcessLayerAPIResponseValidator.applicationContext = applicationContext;
    }
}

