package com.hdfcbank.insurance.hli.process.models.request;

import jakarta.validation.constraints.NotNull;
import lombok.*;

import java.util.List;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class HLIFetchPricingRequest {
    @NotNull
    private String mode;
    // @NotNull
    private String selectedComboCode;
    @NotNull
    private List<Product> product;

    @Getter
    @Setter
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    @ToString
    public static class Product {
        @NotNull
        private String code;
        @NotNull
        private List<PricingAnswer> answers;

        @Getter
        @Setter
        @Builder
        @NoArgsConstructor
        @AllArgsConstructor
        @ToString
        public static class PricingAnswer {
            @NotNull
            private String entityId;
            @NotNull
            private String questionKey;
            @NotNull
            private String answer;
        }
    }
}
