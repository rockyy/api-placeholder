package com.hdfcbank.insurance.hli.process.service.impl;


import tools.jackson.databind.JsonNode;
import tools.jackson.databind.ObjectMapper;
import com.hdfcbank.adapters.clients.feign.journey.JourneyServiceFeignClient;
import com.hdfcbank.adapters.vo.FetchDynamicDataRequest;
import com.hdfcbank.common.models.vo.core.ApiResponse;
import com.hdfcbank.common.models.vo.core.ErrorRef;
import com.hdfcbank.common.models.vo.journey.JourneyData;
import com.hdfcbank.exception.InputValidationException;
import com.hdfcbank.insurance.adapter.common.util.CustomValidationStatus;
import com.hdfcbank.insurance.adapter.process.models.enums.DocumentType;
import com.hdfcbank.insurance.adapter.process.models.request.*;
import com.hdfcbank.insurance.adapter.process.models.response.*;
import com.hdfcbank.insurance.adapter.refgen.clients.RefGenServiceFeignClient;
import com.hdfcbank.insurance.adapter.refgen.request.RefGenRequest;
import com.hdfcbank.insurance.adapter.refgen.response.RefGenResponse;
import com.hdfcbank.insurance.hli.common.config.JourneyContextHolder;
import com.hdfcbank.insurance.hli.common.constant.HLICommonConstants;
import com.hdfcbank.insurance.hli.common.enums.HLICustomCommonApiStatusCodes;
import com.hdfcbank.insurance.hli.common.enums.JourneyStateName;
import com.hdfcbank.insurance.hli.common.exception.CustomValidationException;
import com.hdfcbank.insurance.hli.common.properties.HLIAppProperties;
import com.hdfcbank.insurance.hli.common.properties.ReturnJourneyProperties;
import com.hdfcbank.insurance.hli.process.models.BorrowersEsignDetail;
import com.hdfcbank.insurance.hli.process.models.EsignResponse;
import com.hdfcbank.insurance.hli.process.models.SignerInfo;
import com.hdfcbank.insurance.hli.process.models.SubmitFinalProposalCallback;
import com.hdfcbank.insurance.hli.process.models.enums.BorrowerEsignStatus;
import com.hdfcbank.insurance.hli.process.models.enums.HLIIdentifierType;
import com.hdfcbank.insurance.hli.process.models.enums.JourneyEsignStatus;
import com.hdfcbank.insurance.hli.process.models.enums.SourceSystem;
import com.hdfcbank.insurance.hli.process.models.mapper.GetDetailResponseMapper;
import com.hdfcbank.insurance.hli.process.models.mapper.HLIIdentifyResponseMapper;
import com.hdfcbank.insurance.hli.process.models.mapper.SubmitFinalProposalMapper;
import com.hdfcbank.insurance.hli.process.models.request.HLIIdentifyRequest;
import com.hdfcbank.insurance.hli.process.models.request.HLISubmitAnswerRequest;
import com.hdfcbank.insurance.hli.process.models.request.ResendESignRequest;
import com.hdfcbank.insurance.hli.process.models.request.ResendESignResponse;
import com.hdfcbank.insurance.hli.process.models.response.HLIIdentifyResponse;
import com.hdfcbank.insurance.hli.process.models.response.HLILGLCResponse;
import com.hdfcbank.insurance.hli.process.models.response.HLILoanDetailResponse;
import com.hdfcbank.insurance.hli.process.models.response.HLISubmitAnswerResponse;
import com.hdfcbank.insurance.hli.process.service.HLIDetailService;
import com.hdfcbank.insurance.hli.process.service.config.EsignProperties;
import com.hdfcbank.insurance.hli.process.service.utility.ESignUtility;
import com.hdfcbank.insurance.hli.scheduler.entities.PurchaseIPFStatusEntity;
import com.hdfcbank.insurance.hli.scheduler.model.IPFStatus;
import com.hdfcbank.insurance.hli.scheduler.model.Status;
import com.hdfcbank.insurance.hli.scheduler.repo.PurchaseRepo;
import com.hdfcbank.insurance.hli.util.HLIFieldMasking;
import com.hdfcbank.insurance.hli.util.JourneyUtil;
import com.hdfcbank.insurance.hli.util.TextSanityUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.tuple.Pair;
import org.jetbrains.annotations.NotNull;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.time.LocalDate;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;


@Slf4j
@RequiredArgsConstructor
@Service
public class HLIDetailServiceImpl implements HLIDetailService {

    public static final String UNSIGNED = "unsigned";
    public static final String SIGNER_INFO_DATE_FORMAT = "MMMM dd, yyyy, HH:mm";
    public static final String SOURCE = "loanidentifyrequest.source";
    public static final String ESIGN_EXPIRY_DATE = "borrowerEsignDetail.expireAt";
    public static final String ESIGN_APPLICATION_EXPIRED = "applicationExpired";
    private final HLIIdentifyResponseMapper hliIdentifyResponseMapper;
    private final JourneyServiceFeignClient journeyServiceFeignClient;
    private final ProcessServiceCall processServiceCall;
    private final GetDetailResponseMapper getDetailResponseMapper;
    private final HLIAppProperties hliAppProperties;
    private final ObjectMapper objectMapper;
    private final ReturnJourneyProperties returnJourneyProperties;
    private final RefGenServiceFeignClient refGenServiceFeignClient;
    private final PurchaseRepo purchaseRepo;
    private final SubmitFinalProposalMapper submitFinalProposalMapper;
    private final EsignProperties esignProperties;

    /**
     * This is method will send a call to validate method and there request will be validated and
     * if request is valid it will process to call identify API if not it will return with validation response.
     *
     * @param loanIdentifyRequest this is request
     * @return ApiResponse<HLIIdentifyResponse>
     */
    @Override
    public ApiResponse<HLIIdentifyResponse> identify(String journeyName, String journeyId, HLIIdentifyRequest loanIdentifyRequest) {
        log.info("Journey id is : {}", TextSanityUtil.sanitize(journeyId));
        HLIIdentifyResponse hliIdentifyMapperResponse = HLIIdentifyResponse.builder().loanFileNumber(loanIdentifyRequest.getLoanFileNumber()).build();
        journeyServiceFeignClient.saveJourney(JourneyUtil.toSaveJourneyDataRequest(journeyId, HLICommonConstants.LOAN_IDENTIFY_DETAIL_PAGE_NAME, hliIdentifyMapperResponse, JourneyStateName.ELIGIBILITY_INITIATED, journeyName, null));
        IdentifyResponse identifyResponse = getIdentifyResponse(loanIdentifyRequest, journeyId);
        hliIdentifyMapperResponse = hliIdentifyResponseMapper.toHLIIdentifyResponse(identifyResponse);
        ApiResponse<RefGenResponse> refGenResponseApiResponse = refGenServiceFeignClient.generateReferenceNumber(RefGenRequest.builder().journeyId(journeyId).journeyName(journeyName).build(), journeyId, journeyName);
        journeyServiceFeignClient.saveJourney(JourneyUtil.toSaveJourneyDataRequest(journeyId, HLICommonConstants.LOAN_IDENTIFY_DETAIL_PAGE_NAME, hliIdentifyMapperResponse, JourneyStateName.ELIGIBILITY_SUCCESS, journeyName, refGenResponseApiResponse.getData().getRefNumber()));
        journeyServiceFeignClient.update(JourneyUtil.toUpdateSystemDataRequest(journeyId, HLICommonConstants.LOAN_IDENTIFY_REQUEST, loanIdentifyRequest, JourneyStateName.ELIGIBILITY_INITIATED));
        HLIFieldMasking.fieldsMasking(hliIdentifyMapperResponse);
        return ApiResponse.success(hliIdentifyMapperResponse);
    }

    @Override
    public ApiResponse<HLILoanDetailResponse> fetchLoanDetail() {
        JourneyData journeyData = JourneyContextHolder.getJourneyData();
        log.info("Journey name is :: {}", journeyData.getJourneyName());
        String currentJourneyId = journeyData.getJourneyId();
        String journeyName = journeyData.getJourneyName();
        String loanFileNumber = JourneyUtil.getDataFromJourneyService(journeyData.getJourneyDetail().getSystemData(),
                HLICommonConstants.LOAN_FILE_NUMBER_KEY).toString();
        Pair<JourneyData, HLILoanDetailResponse.ReturnJourneyDetail> validateResult = validateReturnJourneyEligibility(loanFileNumber, journeyData.getJourneyId());
        if (validateResult.getLeft() != null)
            journeyData = validateResult.getLeft();
        String leadId = JourneyUtil.extractLeadId(journeyData);
        GetLoanDetailRequest getLoanDetailRequest = GetLoanDetailRequest.builder().referenceNumber(journeyData.getReferenceNo()).loanFileNumber(loanFileNumber).leadId(leadId).callbackUrl(hliAppProperties.getCallBackUrl()).build();
        GetLoanDetailResponse getLoanDetailResponse = processServiceCall.getLoanDetailCall(getLoanDetailRequest, journeyData.getJourneyId());
        log.info("Initiated Journey ID: {}, Journey ID post validateReturnJourneyEligibility call: {}", currentJourneyId, journeyData.getJourneyId());
        if (!StringUtils.isEmpty(leadId) && leadId.equals(getLoanDetailResponse.getLeadId())) {
            log.info("Lead ID found. Return Journey Details...");

            validateDocumentEsignEligibility(journeyData, journeyName);
            return ApiResponse.success(HLILoanDetailResponse.builder().returnJourneyDetail(validateResult.getRight()).build());

        }
        HLILoanDetailResponse hliLoanDetailResponse = getDetailResponseMapper.toResponse(getLoanDetailResponse);
        getLoanDetailResponse.getLoanEligibility().setMaxLoanInLacs(hliLoanDetailResponse.getMaxIpfLimit());
        journeyServiceFeignClient.update(JourneyUtil.toUpdateSystemDataRequest(currentJourneyId,
                HLICommonConstants.HOME_LOAN_DETAIL, getLoanDetailResponse,
                JourneyStateName.GET_DETAIL_SUCCESS));
        journeyServiceFeignClient.update(JourneyUtil.toUpdateSystemDataRequest(currentJourneyId,
                HLICommonConstants.JOURNEY_STATUS_DETAIL, Map.of(HLICommonConstants.JOURNEY_STATUS, HLICommonConstants.LEAD_STATUS_ACTIVE),
                JourneyStateName.GET_DETAIL_SUCCESS));
        return ApiResponse.success(hliLoanDetailResponse);

    }

    @Override
    public void cancelAllJourneys() {
        JourneyData journeyData = JourneyContextHolder.getJourneyData();
        String loanFileNumber = JourneyUtil.getDataFromJourneyService(journeyData.getJourneyDetail().getSystemData(),
                HLICommonConstants.LOAN_FILE_NUMBER_KEY).toString();
        List<JourneyData> journeyList = fetchJourneysByFileNumber(loanFileNumber);
        journeyList.forEach(journeyDataFromDB -> {
            if (!Objects.equals(journeyData.getJourneyId(), journeyDataFromDB.getJourneyId()))
                JourneyUtil.updateJourneyAsInactive(journeyDataFromDB, journeyServiceFeignClient);
        });
    }

    private Pair<JourneyData, HLILoanDetailResponse.ReturnJourneyDetail> validateReturnJourneyEligibility(String loanFileNumber, String journeyId) {
        List<JourneyData> journeyList = fetchJourneysByFileNumber(loanFileNumber);
        JourneyData journeyData = null;
        HLILoanDetailResponse.ReturnJourneyDetail returnJourneyDetail = null;
        for (JourneyData journeyDataFromDB : journeyList) {
            Map<String, Map<String, ?>> systemData = journeyDataFromDB.getJourneyDetail().getSystemData();
            Map<String, Object> journeyDetail = (Map<String, Object>) systemData.get(HLICommonConstants.JOURNEY_STATUS_DETAIL);
            if (journeyDetail != null && journeyDetail.get(HLICommonConstants.JOURNEY_STATUS) != null && journeyDetail.get(HLICommonConstants.JOURNEY_STATUS).equals(HLICommonConstants.LEAD_STATUS_ACTIVE)) {
                returnJourneyDetail = filterLastStateForReturnJourney(journeyDataFromDB);
                if (returnJourneyDetail != null) {
                    journeyData = journeyDataFromDB;
                    returnJourneyDetail.setOldJourneyId(journeyData.getJourneyId());
                } else {
                    if (!journeyId.equals(journeyDataFromDB.getJourneyId()))
                        JourneyUtil.updateJourneyAsInactive(journeyDataFromDB, journeyServiceFeignClient);
                }
            }
        }
        return Pair.of(journeyData, returnJourneyDetail);
    }

    private List<JourneyData> fetchJourneysByFileNumber(String loanFileNumber) {
        Map<String, Object> filters = new HashMap<>();
        filters.put(HLICommonConstants.LOAN_FILE_NUMBER_FILTER_KEY, loanFileNumber);
        List<String> projectionFields = new ArrayList<>();
        projectionFields.add("journeyId");
        projectionFields.add("journeyDetail.journeyStates");
        projectionFields.add("journeyDetail.systemData.journeyStatusDetail");
        projectionFields.add("journeyDetail.systemData.loanidentifydetails");
        projectionFields.add("journeyDetail.systemData.getLoanDetail.leadId");
        projectionFields.add("journeyDetail.systemData.borrowerEsignDetail.expireAt");
        FetchDynamicDataRequest fetchRequest = FetchDynamicDataRequest.builder().filters(filters).projectionFields(projectionFields).build();
        return journeyServiceFeignClient.fetchDynamicDataResponse(fetchRequest).getData();
    }

    private HLILoanDetailResponse.ReturnJourneyDetail filterLastStateForReturnJourney(JourneyData journeyDataFromDB) {
        return returnJourneyProperties.getReturnStates().stream()
                .filter(returnState ->
                        journeyDataFromDB.getJourneyDetail().getJourneyStates().stream()
                                .anyMatch(journeyState ->
                                        journeyState.getStateName().equals(returnState.getState())
                                )
                )
                .reduce((first, second) -> second)
                .map(returnState ->
                        HLILoanDetailResponse.ReturnJourneyDetail.builder()
                                .lastState(returnState.getState())
                                .title(returnState.getTitle())
                                .loadContext(returnState.getLoadContext())
                                .lastStateMessage(returnState.getMessage())
                                .build()
                )
                .orElse(null);
    }

    @Override
    public ApiResponse<KFSDetailResponse> fetchKFSDetail() {
        JourneyData journeyData = JourneyContextHolder.getJourneyData();
        journeyServiceFeignClient.updateJourneyState(journeyData.getJourneyId(), JourneyStateName.KFS_FETCH_INITIATED.name());
        String loanFileNumber = JourneyUtil.getDataFromJourneyService(journeyData.getJourneyDetail().getSystemData(),
                HLICommonConstants.LOAN_FILE_NUMBER_KEY).toString();
        String leadId = JourneyUtil.extractLeadId(journeyData);
        KFSDetailResponse kfsDetailResponse = processServiceCall.getKFSDetailCall(KFSDetailRequest.builder().leadId(leadId).loanFileNumber(loanFileNumber).build(), journeyData.getJourneyId());
        journeyServiceFeignClient.updateJourneyState(journeyData.getJourneyId(), JourneyStateName.KFS_FETCH_SUCCESS.name());
        return ApiResponse.success(kfsDetailResponse);
    }


    @Override
    public ApiResponse<EsignResponse> initiateEsign() {
        JourneyData journeyData = JourneyContextHolder.getJourneyData();
        String loanFileNumber = JourneyUtil.getDataFromJourneyService(journeyData.getJourneyDetail().getSystemData(),
                HLICommonConstants.LOAN_FILE_NUMBER_KEY).toString();
        String leadId = JourneyUtil.extractLeadId(journeyData);
        Optional<BorrowersEsignDetail> optionalBorrowersEsignDetail = ESignUtility.fetchBorrowerESignDetail(journeyData, objectMapper);
        if (optionalBorrowersEsignDetail.isPresent())
            return ApiResponse.success(EsignResponse.builder().borrowerEsignDetail(optionalBorrowersEsignDetail.get()).build());
        processServiceCall.initiateEsignCall(InitiateEsignRequest.builder().leadId(leadId).loanFileNumber(loanFileNumber).build(), journeyData.getJourneyId());
        BorrowersEsignDetail borrowersEsignDetail = ESignUtility.createBorrowerESignDetail(journeyData, objectMapper);
        borrowersEsignDetail.setExpireAt(LocalDate.now().plusDays(esignProperties.getExpiry()).format(DateTimeFormatter.ofPattern(HLICommonConstants.ESIGN_EXPIRY_DATE_FORMAT)));
        journeyServiceFeignClient.update(JourneyUtil.toUpdateSystemDataRequest(journeyData.getJourneyId(), HLICommonConstants.BORROWER_ESIGN_DETAIL, borrowersEsignDetail, JourneyStateName.ESIGN_INITIATED));
        return ApiResponse.success(EsignResponse.builder().borrowerEsignDetail(borrowersEsignDetail).build());
    }

    @Override
    public ApiResponse<EsignResponse> esignStatus() {
        JourneyData journeyData = JourneyContextHolder.getJourneyData();
        BorrowersEsignDetail borrowersEsignDetail = checkEsignStatus(journeyData);
        return ApiResponse.success(EsignResponse.builder().borrowerEsignDetail(borrowersEsignDetail).build());
    }

    @NotNull
    private BorrowersEsignDetail checkEsignStatus(JourneyData journeyData) {
        Optional<BorrowersEsignDetail> optionalBorrowersEsignDetail = ESignUtility.fetchBorrowerESignDetail(journeyData, objectMapper);
        if (optionalBorrowersEsignDetail.isEmpty())
            throw new RuntimeException("eSing data is missing in journey");
        BorrowersEsignDetail borrowersEsignDetail = optionalBorrowersEsignDetail.get();

        log.debug("BorrowersEsignDetail borrowersEsignDetail --->>> {} ", borrowersEsignDetail);

        if (borrowersEsignDetail.getJourneyEsignStatus().name().equals(JourneyEsignStatus.IN_PROGRESS.name())) {
            ESignStatusResponse eSignStatusResponse = processServiceCall.eSignStatus(ESignStatusRequest.builder().documentId(borrowersEsignDetail.getDocumentId()).build(), journeyData.getJourneyId());
            AtomicBoolean isPendingEsign = new AtomicBoolean(false);
            eSignStatusResponse.getSignerInfo().forEach(signerInfo -> {
                if (signerInfo.getStatus().equals(UNSIGNED)) {
                    isPendingEsign.set(true);
                    updateSignerStatus(signerInfo, borrowersEsignDetail, BorrowerEsignStatus.UNSIGNED);
                } else {
                    updateSignerStatus(signerInfo, borrowersEsignDetail, BorrowerEsignStatus.SIGNED);
                }
            });
            if (!isPendingEsign.get()) {
                borrowersEsignDetail.setJourneyEsignStatus(JourneyEsignStatus.SIGNED);
            }
        }
        journeyServiceFeignClient.update(JourneyUtil.toUpdateSystemDataRequest(journeyData.getJourneyId(), HLICommonConstants.BORROWER_ESIGN_DETAIL, borrowersEsignDetail, JourneyStateName.ESIGN_STATUS_CHECK_SUCCESS));
        return borrowersEsignDetail;
    }

    private void updateSignerStatus(ESignStatusResponse.SignerInfo signerInfo, BorrowersEsignDetail borrowersEsignDetail, BorrowerEsignStatus borrowerEsignStatus) {
        borrowersEsignDetail.getBorrowersInfo()
                .stream()
                .filter(info -> info.getSignerInfo().getSignerId().equals(signerInfo.getSignerId()))
                .forEach(info -> {
                    info.setBorrowerEsignStatus(borrowerEsignStatus);
                    if (signerInfo.getSignedAt() != null) {
                        SignerInfo signerInfoDb = info.getSignerInfo();
                        signerInfoDb.setSignedAt(convertSignerDateFormat(signerInfo.getSignedAt()));
                        info.setSignerInfo(signerInfoDb);
                    }
                });
    }

    private String convertSignerDateFormat(String signedDate) {
        ZonedDateTime zonedDateTime = ZonedDateTime.parse(signedDate);
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(SIGNER_INFO_DATE_FORMAT, Locale.ENGLISH);
        return zonedDateTime.format(formatter);
    }

    @Override
    public ApiResponse<ResendESignResponse> resendESignLink(ResendESignRequest request) {
        JourneyData journeyData = JourneyContextHolder.getJourneyData();
        BorrowersEsignDetail borrowersEsignDetail = checkEsignStatus(journeyData);
        Optional<BorrowersEsignDetail.BorrowerInfo> optionalBorrowerInfo = borrowersEsignDetail.getBorrowersInfo().stream().filter(borrowerInfo -> borrowerInfo.getBorrower().getId().equals(request.getBorrowerId())).findFirst();
        if (optionalBorrowerInfo.isPresent()) {
            if (optionalBorrowerInfo.get().getBorrowerEsignStatus().equals(BorrowerEsignStatus.SIGNED)) {
                return ApiResponse.success(ResendESignResponse.builder().status(BorrowerEsignStatus.SIGNED.getValue()).build());
            }
            ResendESignLinkRequest resendESignLinkRequest = ResendESignLinkRequest.builder()
                    .documentId(borrowersEsignDetail.getDocumentId())
                    .referenceId(String.valueOf(Instant.now().toEpochMilli()))
                    .docketId(borrowersEsignDetail.getDocketId())
                    .stakeholderId(optionalBorrowerInfo.get().getSignerInfo().getSignerId())
                    .build();
            ResendESignLinkResponse resendESignLinkResponse = processServiceCall.resendESignLink(resendESignLinkRequest, journeyData.getJourneyId());
            journeyServiceFeignClient.updateJourneyState(journeyData.getJourneyId(), JourneyStateName.ESIGN_RESEND_LINK_SUCCESS.name());
            return ApiResponse.success(ResendESignResponse.builder().status(resendESignLinkResponse.getStatus())
                    .message(resendESignLinkResponse.getMessage()).build());
        } else {
            log.error("Invalid resend eSign link request: {}", TextSanityUtil.sanitize(request.toString()));
            throw new InputValidationException(ErrorRef.inputValidation(), "Invalid borrower Id");
        }
    }

    @Override
    public ApiResponse<SubmitFinalProposalResponse> submitFinalProposal() {
        log.info("HLIDetailServiceImpl-submitFinalProposal-Init");
        JourneyData journeyData = JourneyContextHolder.getJourneyData();
        String source = JourneyUtil.getDataFromJourneyService(journeyData.getJourneyDetail().getSystemData(),
                SOURCE).toString();
        Optional<BorrowersEsignDetail> optionalBorrowersEsignDetail = ESignUtility.fetchBorrowerESignDetail(journeyData, objectMapper);
        if (optionalBorrowersEsignDetail.isEmpty())
            throw new RuntimeException("eSing data is missing in journey");
        BorrowersEsignDetail borrowersEsignDetail = optionalBorrowersEsignDetail.get();
        String loanFileNumber = JourneyUtil.getDataFromJourneyService(journeyData.getJourneyDetail().getSystemData(),
                HLICommonConstants.LOAN_FILE_NUMBER_KEY).toString();
        String leadId = JourneyUtil.extractLeadId(journeyData);
        HLILGLCResponse hlilglcResponse = objectMapper.convertValue(journeyData.getJourneyDetail().getSystemData().get(HLICommonConstants.LGLC_DETAILS), HLILGLCResponse.class);

        log.info("HLIDetailServiceImpl-submitFinalProposal-hlilglcResponse: {}", hlilglcResponse);
        HLISubmitAnswerRequest hliSubmitAnswerRequest = objectMapper.convertValue(journeyData.getJourneyDetail().getSystemData().get(HLICommonConstants.PROPOSAL_REQUEST), HLISubmitAnswerRequest.class);
        log.info("HLIDetailServiceImpl-submitFinalProposal-hliSubmitAnswerRequest: {}", hliSubmitAnswerRequest);

        SubmitFinalProposalRequest submitFinalProposalRequest = SubmitFinalProposalRequest.builder()
                .docketId(borrowersEsignDetail.getDocketId()).documentId(borrowersEsignDetail.getDocumentId())
                .esignDocumentStorageDetails(borrowersEsignDetail.getEsignDocumentStorageDetail().stream()
                        .filter(esignDocumentStorageDetail -> esignDocumentStorageDetail.getDocumentType().name().equals(DocumentType.MIF.name()))
                        .map(esignDocumentStorageDetail -> SubmitFinalProposalRequest.EsignDocumentStorageDetail.builder()
                                .documentReferenceId(esignDocumentStorageDetail.getDocumentReferenceId())
                                .signerId(esignDocumentStorageDetail.getSignerId())
                                .documentType(DocumentType.valueOf(esignDocumentStorageDetail.getDocumentType().name()))
                                .quoteId(esignDocumentStorageDetail.getQuoteId()).build()).toList())
                .loanFileNumber(loanFileNumber).sourceSystem(source)
                .leadId(leadId)
                .lglcDetails(SubmitFinalProposalRequest.LGLCDetails.builder()
                        .lgCode(hlilglcResponse.getLgCode())
                        .lifeLc(hlilglcResponse.getLifeLc() != null ? SubmitFinalProposalRequest.LGLCDetails.LifeLc.builder()
                                .lcCode(hlilglcResponse.getLifeLc().getLcCode())
                                .bancaCode(hlilglcResponse.getLifeLc().getBancaCode())
                                .leadRefNumber(hlilglcResponse.getLifeLc().getLeadRefNumber())
                                .build() : null)
                        .nonLifeLc(hlilglcResponse.getNonLifeLc() != null ? SubmitFinalProposalRequest.LGLCDetails.LifeLc.builder()
                                .lcCode(hlilglcResponse.getNonLifeLc().getLcCode())
                                .bancaCode(hlilglcResponse.getNonLifeLc().getBancaCode())
                                .leadRefNumber(hlilglcResponse.getNonLifeLc().getLeadRefNumber())
                                .build() : null)
                        .salesExeCd(hlilglcResponse.getSalesExeCd())
                        .originMode(hlilglcResponse.getOriginMode())
                        .agencyCode(determineSalesCenterOrAgencyCode(hlilglcResponse.getHSaleCenterCode(),
                                hliSubmitAnswerRequest.getAgencyCode(), hlilglcResponse.getAgencyCode()))
                        .associateCd(hlilglcResponse.getAssociateCd())
                        .filler1(hlilglcResponse.getFiller1())
                        .lgFieldLabel(hlilglcResponse.getLgFieldLabel())
                        .build())
                .signerDetails(borrowersEsignDetail.getBorrowersInfo().stream().map(signer -> SubmitFinalProposalRequest.SignerDetails.builder()
                        .partnerUid(signer.getBorrower().getId()).signerId(signer.getSignerInfo().getSignerId()).build()).toList())
                .nomineeDetails(buildNomineeDetails(hliSubmitAnswerRequest))
                .build();
        log.info("HLIDetailServiceImpl-submitFinalProposalRequest : {}", submitFinalProposalRequest);
        SubmitFinalProposalResponse submitFinalProposalResponse = processServiceCall.finalProposalSubmission(submitFinalProposalRequest, journeyData.getJourneyId());
        journeyServiceFeignClient.update(JourneyUtil.toUpdateSystemDataRequest(journeyData.getJourneyId(), HLICommonConstants.SUBMIT_FINAL_PROPOSAL_REQUEST, submitFinalProposalRequest, JourneyStateName.SUBMIT_FINAL_PROPOSAL_INITIATED));
        log.debug("inserting submit final proposal response");
        insertPurchaseRecords(loanFileNumber, journeyData);
        log.debug("inserted successfully submit final proposal response");
        return ApiResponse.success(submitFinalProposalResponse);
    }

    private String determineSalesCenterOrAgencyCode(String lcFieldLabel, String hSaleCenterCode, String agencyCode) {
        log.info("HLIDetailServiceImpl-setHsaleCenterCode : {} , {}, {}", lcFieldLabel, hSaleCenterCode, agencyCode);
        return (lcFieldLabel != null) ? hSaleCenterCode : agencyCode;
    }

    private List<SubmitFinalProposalRequest.NomineeDetails> buildNomineeDetails(HLISubmitAnswerRequest hliSubmitAnswerRequest) {
        return hliSubmitAnswerRequest.getProductWiseQuestions().stream()
                .flatMap(product -> product.getAnswers().stream()
                        .filter(answer -> "nominees".equals(answer.getQuestionKey()))
                        .map(answer -> {
                            Map<String, Object> nominee = (Map<String, Object>) answer.getAnswer();
                            String borrowerCustNumber = StringUtils.substringBefore(answer.getEntityId(), "|");
                            return SubmitFinalProposalRequest.NomineeDetails.builder()
                                    .quoteId(product.getQuoteId())
                                    .borrowerCustNumber(borrowerCustNumber)
                                    .nomineeCustNumber((String) nominee.get("cust_number"))
                                    .nomineeType((String) nominee.get("nominee_type"))
                                    .nomineeFirstName((String) nominee.get("first_name"))
                                    .nomineeLastName((String) nominee.get("last_name"))
                                    .nomineeGender((String) nominee.get("gender"))
                                    .nomineeDob((String) nominee.get("dob"))
                                    .nomineeRelation((String) nominee.get("relation")).build();
                        })).toList();
    }
    private void insertPurchaseRecords(String loanFileNumber,JourneyData journeyData){
        PurchaseIPFStatusEntity entity = PurchaseIPFStatusEntity.builder()
                .id(journeyData.getReferenceNo())
                .journeyName(HLICommonConstants.JOURNEY_NAME)
                .processType(HLICommonConstants.PURCHASE_PROCESS_TYPE)
                .createdDate(Instant.now())
                .ipfStatusHistory(List.of())
                .ipfStatus(IPFStatus.PURCHASED.getIpfStatusName())
                .productPurchaseRequest(buildProposalResponse(loanFileNumber,journeyData))
                .purchaseStatus(Status.PURCHASED_INITIATED)
                .build();
        entity = purchaseRepo.save(entity);
        log.debug("initial transactional entity saved, Id -->> {}, ", TextSanityUtil.sanitize(entity.getId()));
        log.debug("successfully inserted api2 response in db");

    }
    /**
     * This method will prepare request to invoke process end point, and send call to end point to get identify response.
     *
     * @param request
     * @param journeyId
     * @return ApiResponse<HLIIdentifyResponse>
     */
    private IdentifyResponse getIdentifyResponse(HLIIdentifyRequest request, String journeyId) {
        List<IdentifyRequest.Identifier> identifiers = new ArrayList<>();
        if (request.getSource() == SourceSystem.STATIC) {
            identifiers.add(IdentifyRequest.Identifier.builder().identifierType(HLIIdentifierType.DOB.name()).identifierValue(TextSanityUtil.sanitize(request.getDob())).build());
        }
        // Common for both STATIC and DYNAMIC
        identifiers.add(IdentifyRequest.Identifier.builder().identifierType(HLIIdentifierType.LOAN.name()).identifierValue(request.getLoanFileNumber()).build());
        IdentifyRequest identifyRequest = IdentifyRequest.builder().identifiers(identifiers).loginMethod(request.getSource().name()).build();
        return processServiceCall.identifyServiceCall(identifyRequest, journeyId);
    }
    private SubmitFinalProposalCallback.SubmitILPSProposalResponse buildProposalResponse(
            String loanFileNumber, JourneyData journeyData) {
        HLISubmitAnswerResponse hliSubmitAnswerResponse = Optional.ofNullable(objectMapper.convertValue(JourneyUtil.getByPath(journeyData.getJourneyDetail().getSystemData(), HLICommonConstants.PROPOSAL_RESPONSE), HLISubmitAnswerResponse.class)).get();
        List<HLISubmitAnswerResponse.Proposal> proposals = hliSubmitAnswerResponse.getProposals();
        return submitFinalProposalMapper.mapFinalProposal(loanFileNumber,journeyData.getReferenceNo(),proposals);
    }

    private boolean isEligibleForDocumentEsign(JourneyData journeyData) {
        JsonNode jsonNode = objectMapper.valueToTree(journeyData.getJourneyDetail().getSystemData());
        String esignExpiryDate = JourneyUtil.getValueFromJsonPath(jsonNode, ESIGN_EXPIRY_DATE);
        log.info("Extracted value for path [{}] is :: {}", ESIGN_EXPIRY_DATE, esignExpiryDate);
        if (esignExpiryDate == null || esignExpiryDate.isBlank()) {
            log.info("eSign expiry date is null or blank");
            return false;
        }
        return isDateWithinThreshold(esignExpiryDate);
    }


    private boolean isDateWithinThreshold(String date) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(HLICommonConstants.ESIGN_EXPIRY_DATE_FORMAT);
        LocalDate parsedDate = LocalDate.parse(date, formatter);
        boolean isValid = !parsedDate.isBefore(LocalDate.now());
        log.info("Parsed date: {}, Current date: {}, Is valid: {}", parsedDate, LocalDate.now(), isValid);
        return isValid;
    }

    private void validateDocumentEsignEligibility(JourneyData journeyData,String journeyName) {

        if (!isEligibleForDocumentEsign(journeyData)) {
            log.info("User is NOT eligible for document eSign " +
                            "for journeyId :: {} as eligibility validation failed.",
                    journeyData.getJourneyId());
            esignApplicationExpired(journeyName,journeyData.getJourneyId());
        }

    }

    private void esignApplicationExpired(String journeyName, String journeyId) {

        EsignProperties.FieldDetail validation = esignProperties.getExceptionMessage().getFieldsDetail().get(journeyName)
                .stream().filter(field -> ESIGN_APPLICATION_EXPIRED.equals(field.getType()))
                .findFirst().orElseThrow(() -> new RuntimeException("Validation config not found"));

        String formattedMessage = String.format(validation.getMessage(), validation.getCode());
        CustomValidationStatus customValidationStatus = CustomValidationStatus.builder()
                .title(validation.getMessageHeading())
                .type(validation.getType()).build();
        // Cancel the journey if document esign tenure expired
        JourneyUtil.updateJourneyDetailDropOff(
                journeyServiceFeignClient.fetch(journeyId),
                journeyServiceFeignClient,
                customValidationStatus);
        throw new CustomValidationException(HLICustomCommonApiStatusCodes.CUSTOM_VALIDATION_EXCEPTION, validation.getMessageHeading(),
                esignProperties.getExceptionMessage().getPopup().getFullScreen(), List.of(formattedMessage));
    }

}
