package com.hdfcbank.insurance.hli.process.service.impl;


import tools.jackson.core.JacksonException;
import tools.jackson.core.type.TypeReference;
import tools.jackson.databind.ObjectMapper;
import com.hdfcbank.adapters.clients.feign.journey.JourneyServiceFeignClient;
import com.hdfcbank.adapters.vo.FetchDynamicDataRequest;
import com.hdfcbank.common.models.constant.CommonApiStatusCodes;
import com.hdfcbank.common.models.vo.core.ApiResponse;
import com.hdfcbank.common.models.vo.core.ErrorRef;
import com.hdfcbank.common.models.vo.journey.JourneyData;
import com.hdfcbank.exception.BusinessValidationException;
import com.hdfcbank.insurance.hli.common.constant.HLICommonConstants;
import com.hdfcbank.insurance.hli.common.core.ProcessLayerAPIResponseValidator;
import com.hdfcbank.insurance.hli.common.core.models.HLIAPIRequestName;
import com.hdfcbank.insurance.hli.common.enums.JourneyStateName;
import com.hdfcbank.insurance.hli.process.models.*;
import com.hdfcbank.insurance.hli.process.models.enums.BorrowerEsignStatus;
import com.hdfcbank.insurance.hli.process.models.enums.CallbackType;
import com.hdfcbank.insurance.hli.process.models.enums.JourneyEsignStatus;
import com.hdfcbank.insurance.hli.process.models.mapper.HLICallbackPayload;
import com.hdfcbank.insurance.hli.process.models.mapper.HLICancelLead;
import com.hdfcbank.insurance.hli.process.models.mapper.SubmitFinalProposalMapper;
import com.hdfcbank.insurance.hli.process.models.request.CallbackRequest;
import com.hdfcbank.insurance.hli.process.models.response.CallbackResponse;
import com.hdfcbank.insurance.hli.process.service.CallbackService;
import com.hdfcbank.insurance.hli.process.service.config.EsignProperties;
import com.hdfcbank.insurance.hli.process.service.utility.ESignUtility;
import com.hdfcbank.insurance.hli.scheduler.model.Status;
import com.hdfcbank.insurance.hli.scheduler.repo.PurchaseRepo;
import com.hdfcbank.insurance.hli.util.JourneyUtil;
import com.hdfcbank.insurance.hli.util.TextSanityUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@Service
@RequiredArgsConstructor
@Slf4j
public class HLIActionServiceImpl implements CallbackService {

    private final JourneyServiceFeignClient journeyServiceFeignClient;
    private final ProcessServiceCall processServiceCall;
    private final SubmitFinalProposalMapper submitFinalProposalMapper;
    private final ObjectMapper objectMapper;
    private final PurchaseRepo purchaseRepo;
    private final EsignProperties esignProperties;

    @Override
    public ApiResponse<CallbackResponse> performAction(CallbackRequest request) {

        return switch (request.getCallbackType()) {
            case CANCEL_LEAD -> handleCancelLead(request);
            case ESIGN_REQUEST_SUCCESS -> handleEsignSuccess(request);
            case ESIGN_CALLBACK -> handleEsignStatusCallback(request);
            case SUBMIT_FINAL_PROPOSAL_CALLBACK -> handleSubmitFinalProposalCallback(request);
            case DROP_OFF_CALLBACK -> handleDropOffCallback(request);
        };
    }

    private ApiResponse<CallbackResponse> handleEsignStatusCallback(CallbackRequest request) {

        EsignCallbackUpdate payload = (EsignCallbackUpdate) getIdentifyClass(request);
        log.info("Esign status update Payload: {}", TextSanityUtil.sanitize(payload.toString()));

        JourneyData journeyData = journeyServiceFeignClient.fetch(payload.getJourneyId());
        Optional<BorrowersEsignDetail> optionalBorrowersEsignDetail = ESignUtility.fetchBorrowerESignDetail(journeyData, objectMapper);
        if(optionalBorrowersEsignDetail.isEmpty())
            throw new RuntimeException("eSign data is missing in journey");
        BorrowersEsignDetail borrowersEsignDetail = optionalBorrowersEsignDetail.get();
        updateStatus(borrowersEsignDetail, payload);

        journeyServiceFeignClient.update(JourneyUtil.toUpdateSystemDataRequest(journeyData.getJourneyId(), HLICommonConstants.BORROWER_ESIGN_DETAIL, borrowersEsignDetail, JourneyStateName.ESIGN_STATUS_CALLBACK_RECEIVED));
        return ApiResponse.success(CallbackResponse.builder().message("Callback received and Status Updated").build());
    }

    private ApiResponse<CallbackResponse> handleSubmitFinalProposalCallback(CallbackRequest request) {

        SubmitFinalProposalCallback payload = (SubmitFinalProposalCallback) getIdentifyClass(request);
        log.info("Submit Final Proposal Payload: {}", TextSanityUtil.sanitize(payload.toString()));

        JourneyData journeyData = journeyServiceFeignClient.fetch(payload.getJourneyId());
        journeyServiceFeignClient.update(JourneyUtil.toUpdateSystemDataRequest(journeyData.getJourneyId(), HLICommonConstants.SUBMIT_FINAL_PROPOSAL_REQUEST,
                payload.getSubmitILPSProposalRequest(), JourneyStateName.SUBMIT_FINAL_PROPOSAL_REQUESTED));
        journeyServiceFeignClient.update(JourneyUtil.toUpdateSystemDataRequest(journeyData.getJourneyId(), HLICommonConstants.SUBMIT_FINAL_PROPOSAL_RESPONSE,
                submitFinalProposalMapper.mapToFinalProposalResponse(payload.getSubmitILPSProposalResponse()), JourneyStateName.SUBMIT_FINAL_PROPOSAL_CALLBACK_RECEIVED));
        log.debug("updating submit final proposal response");
        try {
            purchaseRepo.updateStatus(payload.getJourneyId(),Status.PURCHASED,Instant.now());
        } catch (DataAccessException dataAccessException) {
            log.error("Failed to update purchase status to PURCHASED for journeyId: {}", TextSanityUtil.sanitize(payload.getJourneyId()), dataAccessException);
            throw new BusinessValidationException(ErrorRef.of(CommonApiStatusCodes.BUSINESS_VALIDATION_ERROR.getCode()),
                    CommonApiStatusCodes.BUSINESS_VALIDATION_ERROR.getMessage(), HLICommonConstants.FAILED_PURCHASE_STATUS_UPDATE);
        }
        log.debug("updated successfully submit final proposal response");
        return ApiResponse.success(CallbackResponse.builder().message("Callback received").build());
    }


    public void updateStatus(BorrowersEsignDetail borrowersEsignDetail, EsignCallbackUpdate request) {

        request.getSignerInfo().forEach(signerInfo ->
                updateSignerStatus(signerInfo, borrowersEsignDetail, BorrowerEsignStatus.SIGNED));

        boolean allSigned = borrowersEsignDetail.getBorrowersInfo().stream()
                .allMatch(info ->
                        BorrowerEsignStatus.SIGNED.equals(info.getBorrowerEsignStatus()));

        borrowersEsignDetail.setJourneyEsignStatus(allSigned ? JourneyEsignStatus.SIGNED : JourneyEsignStatus.UNSIGNED);
    }

    private void updateSignerStatus(EsignCallbackUpdate.SignerInfo signerInfo, BorrowersEsignDetail borrowersEsignDetail, BorrowerEsignStatus borrowerEsignStatus) {
        if (signerInfo == null || signerInfo.getSignerId() == null) {
            return;
        }

        borrowersEsignDetail.getBorrowersInfo()
                .stream()
                .filter(info -> info.getSignerInfo() != null)
                .filter(info -> signerInfo.getSignerId()
                        .equals(info.getSignerInfo().getSignerId()))
                .forEach(info -> info.setBorrowerEsignStatus(borrowerEsignStatus));
    }

    private ApiResponse<CallbackResponse> handleEsignSuccess(CallbackRequest request) {
        EsignCallback payload = (EsignCallback) getIdentifyClass(request);
        log.info("Esign request success Payload: {}", TextSanityUtil.sanitize(payload.toString()));
        JourneyData journeyData = journeyServiceFeignClient.fetch(payload.getJourneyId());
        BorrowersEsignDetail borrowerESignDetail = ESignUtility.createBorrowerESignDetail(journeyData, objectMapper);
        borrowerESignDetail.setDocketId(payload.getEsignResponse().getDocketId());
        borrowerESignDetail.setResponseTimeStamp(payload.getEsignResponse().getResponseTimeStamp());
        borrowerESignDetail.setDocumentId(payload.getEsignResponse().getDocumentId());
        borrowerESignDetail.setError(payload.getEsignResponse().getError());
        borrowerESignDetail.setEsignDocumentStorageDetail(payload.getEsignDocumentStorageDetail());
        borrowerESignDetail.setReferenceDocId(payload.getEsignResponse().getReferenceDocId());
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(HLICommonConstants.ESIGN_EXPIRY_DATE_FORMAT);
        borrowerESignDetail.setExpireAt(LocalDate.parse(payload.getEsignInitiatedDate(), formatter).plusDays(esignProperties.getExpiry()).format(formatter));
        borrowerESignDetail.setJourneyEsignStatus(JourneyEsignStatus.IN_PROGRESS);
        borrowerESignDetail.getBorrowersInfo().forEach(borrowerInfo -> {
            Optional<SignerInfo> signerInfo = payload.getEsignResponse().getSignerInfo().stream().filter(si -> si.getSignerRefId().equals(borrowerInfo.getBorrower().getId())).findFirst();
            if(signerInfo.isPresent()) {
                borrowerInfo.setBorrowerEsignStatus(BorrowerEsignStatus.IN_PROGRESS);
                borrowerInfo.setSignerInfo(signerInfo.get());
            }
        });
        journeyServiceFeignClient.update(JourneyUtil.toUpdateSystemDataRequest(journeyData.getJourneyId(), HLICommonConstants.BORROWER_ESIGN_DETAIL, borrowerESignDetail, JourneyStateName.ESIGN_INITIATE_CALLBACK_RECEIVED));
        updateEsignExpiryDate(journeyData, payload);
        return ApiResponse.success(CallbackResponse.builder().message("Callback received").build());
    }

    private void updateEsignExpiryDate(JourneyData journeyData, EsignCallback payload) {
        Map<String, Object> journeyStatusDetail = objectMapper.convertValue(journeyData.getJourneyDetail().getSystemData()
                .get(HLICommonConstants.JOURNEY_STATUS_DETAIL), new TypeReference<>() {
        });
        journeyStatusDetail.put(HLICommonConstants.DOCUMENT_ESIGN_EXPIRY_DATE, payload.getEsignInitiatedDate());
        // Update Mongo
        journeyServiceFeignClient.update(JourneyUtil.toUpdateSystemDataRequest(journeyData.getJourneyId(),
                HLICommonConstants.JOURNEY_STATUS_DETAIL, journeyStatusDetail, JourneyStateName.ESIGN_INITIATE_CALLBACK_RECEIVED));
    }

    private ApiResponse<CallbackResponse> handleCancelLead(CallbackRequest request) {
        HLICancelLead payload = (HLICancelLead) getIdentifyClass(request);
        log.info("Lead cancel Payload: {}", TextSanityUtil.sanitize(payload.toString()));
        return handleCancelLead(payload);
    }

    private HLICallbackPayload getIdentifyClass(CallbackRequest request) {
        CallbackType actionType = request.getCallbackType();
        Class<? extends HLICallbackPayload> payloadClass = actionType.getPayloadClass();
        log.info("Processing action: {}, Payload class: {}", actionType, payloadClass);
        try {
            return objectMapper.readValue(request.getData(), payloadClass);
        } catch (JacksonException e) {
            log.error("Error while parsing callback data: {}",e.getMessage(),e);
            throw new RuntimeException(e);
        }
    }

    private ApiResponse<CallbackResponse> handleCancelLead(HLICancelLead payload) {

        FetchDynamicDataRequest fetchRequest = FetchDynamicDataRequest.builder().operationType("AND").filters(getFilters(payload)).build();
        List<JourneyData> journeyList = ProcessLayerAPIResponseValidator.validateApiResponse(HLIAPIRequestName.ACTION,
                journeyServiceFeignClient.fetchDynamicDataResponse(fetchRequest));
        journeyList.forEach(journeyData -> JourneyUtil.updateJourneyAsInactive(journeyData,journeyServiceFeignClient));
        return ApiResponse.success(
                CallbackResponse.builder().message("Success").build()
        );
    }

    private Map<String, Object> getFilters(HLICancelLead payload) {
        Map<String, Object> leadMap = new HashMap<>();
        leadMap.put(HLICommonConstants.LEAD_ID_FILTER_KEY, payload.getLeadId());
        leadMap.put(HLICommonConstants.LOAN_FILE_NUMBER_FILTER_KEY, payload.getLoanFileNumber());
        return leadMap;
    }

    private ApiResponse<CallbackResponse> handleDropOffCallback(CallbackRequest request) {

        DropOffCallback payload = (DropOffCallback) getIdentifyClass(request);
        log.info("Drop Off Payload: {}", TextSanityUtil.sanitize(payload.toString()));

        JourneyUtil.updateJourneyDetailDropOff(
                journeyServiceFeignClient.fetch(payload.getJourneyId()),
                journeyServiceFeignClient,
                payload.getCustomValidationStatus());

        return ApiResponse.success(CallbackResponse.builder().message("Success").build());
    }
}

