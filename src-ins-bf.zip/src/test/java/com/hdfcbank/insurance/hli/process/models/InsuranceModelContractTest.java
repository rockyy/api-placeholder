package com.hdfcbank.insurance.hli.process.models;

import com.hdfcbank.insurance.adapter.process.models.response.PremiumQuestionResponse;
import com.hdfcbank.insurance.hli.process.models.mapper.HLIFetchPricingProductDetailsMapper;
import com.hdfcbank.insurance.hli.process.models.request.HLIFetchPricingRequest;
import com.hdfcbank.insurance.hli.process.models.request.HLISubmitAnswerRequest;
import com.hdfcbank.insurance.hli.process.models.response.HLICurateProductResponse;
import org.junit.jupiter.api.Test;
import org.mapstruct.factory.Mappers;
import tools.jackson.databind.ObjectMapper;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class InsuranceModelContractTest {
    private final ObjectMapper mapper = new ObjectMapper();

    @Test
    void pricingAnswersKeepExistingJsonPropertyNamesAndValues() {
        var input = mapper.readTree("""
                {"mode":"INITIATE_QUOTES","product":[{"code":"HDFC_3D","answers":[
                  {"entityId":"C1","questionKey":"sum_insured","answer":"100000"}]}]}
                """);

        var request = mapper.treeToValue(input, HLIFetchPricingRequest.class);
        var output = mapper.valueToTree(request);

        assertEquals("100000", request.getProduct().getFirst().getAnswers().getFirst().getAnswer());
        assertEquals(input.get("product"), output.get("product"));
    }

    @Test
    void proposalAnswersKeepStructuredJsonValues() {
        var input = mapper.readTree("""
                {"questionType":"PROPOSAL","mode":"INITIATE","productWiseQuestions":[
                  {"quoteId":"Q1","answers":[{"entityId":"C1","questionKey":"nominees",
                    "answer":{"name":"Nominee","share":100}}]}]}
                """);

        var request = mapper.treeToValue(input, HLISubmitAnswerRequest.class);
        var output = mapper.valueToTree(request);

        assertEquals(input.get("productWiseQuestions"), output.get("productWiseQuestions"));
    }

    @Test
    void pricingQuestionMapperKeepsQuestionPropertyAndExistingSubquestionPolicy() {
        var question = PremiumQuestionResponse.ProductWiseQuestion.Question.builder()
                .questionKey("sum_insured").question("Loan amount?").entityId("C1").build();
        var response = PremiumQuestionResponse.builder().productWiseQuestions(List.of(
                PremiumQuestionResponse.ProductWiseQuestion.builder().code("HDFC_3D")
                        .questions(List.of(question)).build())).build();

        var mapped = Mappers.getMapper(HLIFetchPricingProductDetailsMapper.class).mapToApiResponse(response);
        var mappedQuestion = mapped.getProductWiseQuestions().getFirst().getQuestions().getFirst();
        var json = mapper.valueToTree(mappedQuestion);

        assertEquals("Loan amount?", mappedQuestion.getQuestion());
        assertEquals("Loan amount?", json.path("question").asText());
        assertEquals("sum_insured", json.path("questionKey").asText());
        assertNull(mappedQuestion.getSubQuestions());
    }

    @Test
    void esignErrorBindsAndSerializesThroughAccessors() {
        var callback = mapper.readValue("""
                {"journeyId":"J1","esignResponse":{"status":"FAILED","error":"Signing failed"}}
                """, EsignCallback.class);

        assertEquals("Signing failed", callback.getEsignResponse().getError());
        callback.getEsignResponse().setError("Updated error");
        assertEquals("Updated error", mapper.valueToTree(callback).path("esignResponse").path("error").asText());
    }

    @Test
    void curatedResponseSerializationRetainsCustomersPremiumRatesAndPopularity() throws Exception {
        var response = HLICurateProductResponse.builder().timestamp("2026-10-29T00:00:00Z")
                .customers(List.of(HLICurateProductResponse.Customer.builder().id("C1").name("Customer")
                        .relationToBorrower("SELF").activePolicies(2).build()))
                .products(List.of(HLICurateProductResponse.Product.builder().code("HDFC_3D")
                        .livePremiumRates(HLICurateProductResponse.LivePremiumRates.builder()
                                .age18(10.0).age30(20.0).age50(30.0).build())
                        .popularity(HLICurateProductResponse.Popularity.builder()
                                .currentHolders(100).salesThisMonth(5).build()).build())).build();
        var bytes = new ByteArrayOutputStream();
        try (var output = new ObjectOutputStream(bytes)) {
            output.writeObject(response);
        }

        HLICurateProductResponse restored;
        try (var input = new ObjectInputStream(new ByteArrayInputStream(bytes.toByteArray()))) {
            restored = (HLICurateProductResponse) input.readObject();
        }

        assertEquals(mapper.valueToTree(response), mapper.valueToTree(restored));
        assertEquals("C1", restored.getCustomers().getFirst().getId());
        assertEquals(20.0, restored.getProducts().getFirst().getLivePremiumRates().getAge30());
        assertEquals(100, restored.getProducts().getFirst().getPopularity().getCurrentHolders());
    }
}
