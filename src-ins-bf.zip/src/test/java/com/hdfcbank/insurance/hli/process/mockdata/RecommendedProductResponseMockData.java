package com.hdfcbank.insurance.hli.process.mockdata;


import com.hdfcbank.insurance.adapter.process.models.Product;
import com.hdfcbank.insurance.adapter.process.models.response.RecommendedProductResponse;

import java.util.List;

public class RecommendedProductResponseMockData {

    public static RecommendedProductResponse buildMockResponse() {
        return RecommendedProductResponse.builder().products(List.of(buildMockProduct())).combos(buildMockCombos()).build();
    }

    public static Product buildMockProduct() {
        return Product.builder().code("PROD001").name("Health Shield Premium").averageRating(4).totalRatings(250).recalculationStatus("COMPLETED").insuranceCompany(buildMockInsuranceCompany()).productConfigs(List.of(buildMockProductConfig())).category(buildMockCategory()).visualizationCategory("HEALTH_CATEGORY").policyStartDelay(5).isBreakInSupport(true).addons(List.of("Addon1", "Addon2")).features(List.of(buildMockFeature())).build();
    }

    public static Product.InsuranceCompany buildMockInsuranceCompany() {
        return Product.InsuranceCompany.builder().name("HDFC ERGO").logo("https://cdn.hdfc.com/logo.png").companyCode("HDFC001").build();
    }

    public static Product.ProductConfig buildMockProductConfig() {
        return Product.ProductConfig.builder().key("SumInsured").value("500000").build();
    }

    public static Product.Category buildMockCategory() {
        return Product.Category.builder().id(10).categoryName("Health Insurance").templateName("Health_Template").code("HLT").userInfoTemplate("USER_HEALTH").categoryGroup("Retail").lineOfBusiness("Health").build();
    }

    public static Product.Feature buildMockFeature() {
        return Product.Feature.builder().name("No Claim Bonus").description("Get bonus for every claim-free year").minSA(50000L).maxSA(1000000L).minAge(18).maxAge(65).value("Available").order(1).code("NCB").build();
    }

    public static RecommendedProductResponse.Combos buildMockCombos() {
        return RecommendedProductResponse.Combos.builder().fixed(List.of(buildMockFixedCombo())).build();
    }

    public static RecommendedProductResponse.FixedCombo buildMockFixedCombo() {
        return RecommendedProductResponse.FixedCombo.builder().comboCode("COMBO001").comboName("Family Health Combo").products(List.of(buildMockComboProduct())).totalPremium(12000.0).logo("https://cdn.hdfc.com/combo_logo.png").description("Includes top health and accident covers").build();
    }

    public static RecommendedProductResponse.ComboProduct buildMockComboProduct() {
        return RecommendedProductResponse.ComboProduct.builder().code("CP001").suggestedSumInsured("500000").suggestedPlan("Gold").suggestedTenure(2).basePremium(10000.0).tax(2000.0).premium(12000.0).build();
    }

}

