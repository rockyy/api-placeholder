package com.hdfcbank.insurance.hli.common.aspect;

import com.hdfcbank.adapters.clients.feign.journey.JourneyServiceFeignClient;
import com.hdfcbank.common.models.constant.RequestHeaders;
import com.hdfcbank.common.models.vo.journey.JourneyData;
import com.hdfcbank.common.models.vo.journey.JourneyState;
import com.hdfcbank.exception.BusinessValidationException;
import com.hdfcbank.insurance.hli.common.annotation.ValidateJourney;
import com.hdfcbank.insurance.hli.common.config.JourneyContextHolder;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.aop.aspectj.annotation.AspectJProxyFactory;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import java.util.Arrays;
import static com.hdfcbank.insurance.hli.common.enums.JourneyStateName.*;
import static com.hdfcbank.insurance.hli.support.JourneyTestData.*;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class ValidateJourneyAspectTest {
    private JourneyServiceFeignClient journeyClient;
    private JourneyData journeyData;
    private JourneyEndpoints endpoints;

    @BeforeEach
    void setUp() {
        journeyData = journey();
        journeyClient = mock(JourneyServiceFeignClient.class);
        when(journeyClient.fetch(JOURNEY_ID)).thenReturn(journeyData);
        var request = new MockHttpServletRequest();
        request.addHeader(RequestHeaders.JOURNEY_ID, JOURNEY_ID);
        RequestContextHolder.setRequestAttributes(new ServletRequestAttributes(request));
        var factory = new AspectJProxyFactory(new JourneyEndpoints());
        factory.addAspect(new ValidateJourneyAspect(journeyClient));
        endpoints = factory.getProxy();
    }

    @AfterEach
    void cleanUp() {
        JourneyContextHolder.clear();
        RequestContextHolder.resetRequestAttributes();
    }

    @Test
    void validJourneyIsAvailableDuringCallAndClearedAfterward() {
        states("VALIDATE_OTP_SUCCESS");
        assertSame(journeyData, endpoints.required());
        assertNull(JourneyContextHolder.getJourneyData());
    }

    @Test
    void missingRequiredStateRejectsRequest() {
        states("SEND_OTP_SUCCESS");
        assertThrows(BusinessValidationException.class, endpoints::required);
        assertNull(JourneyContextHolder.getJourneyData());
    }

    @Test
    void forbiddenStateRejectsRequest() {
        states("VALIDATE_OTP_SUCCESS", "BUSINESS_VALIDATION_FAILED");
        assertThrows(BusinessValidationException.class, endpoints::forbidden);
    }

    @Test
    void anyMatchingStateIsSufficient() {
        states("ESIGN_STATUS_CALLBACK_RECEIVED");
        assertSame(journeyData, endpoints.anyState());
    }

    @Test
    void noMatchingAlternativeStateRejectsRequest() {
        states("SEND_OTP_SUCCESS");
        assertThrows(BusinessValidationException.class, endpoints::anyState);
    }

    @Test
    void missingJourneyRejectsRequest() {
        when(journeyClient.fetch(JOURNEY_ID)).thenReturn(null);
        assertThrows(BusinessValidationException.class, endpoints::required);
    }

    @Test
    void contextIsClearedWhenTargetThrows() {
        states("VALIDATE_OTP_SUCCESS");
        assertThrows(IllegalStateException.class, endpoints::failing);
        assertNull(JourneyContextHolder.getJourneyData());
    }

    private void states(String... values) {
        journeyData.getJourneyDetail().setJourneyStates(Arrays.stream(values)
                .map(s -> JourneyState.builder().stateName(s).build()).toList());
    }

    static class JourneyEndpoints {
        @ValidateJourney(shouldExists = VALIDATE_OTP_SUCCESS)
        public JourneyData required() {
            return JourneyContextHolder.getJourneyData();
        }

        @ValidateJourney(shouldNotExists = BUSINESS_VALIDATION_FAILED)
        public void forbidden() {
            // The test exercises the aspect's forbidden-state check before this no-op target runs.
        }

        @ValidateJourney(hasAny = {ESIGN_STATUS_CHECK_SUCCESS, ESIGN_STATUS_CALLBACK_RECEIVED})
        public JourneyData anyState() {
            return JourneyContextHolder.getJourneyData();
        }

        @ValidateJourney(shouldExists = VALIDATE_OTP_SUCCESS)
        public void failing() {
            throw new IllegalStateException("downstream failure");
        }
    }
}
