package com.hdfcbank.insurance.hli.common.exception;

import com.hdfcbank.adapters.clients.feign.journey.JourneyServiceFeignClient;
import com.hdfcbank.adapters.vo.UpdateSystemDataJourneyRequest;
import com.hdfcbank.common.models.constant.MDCConstants;
import com.hdfcbank.exception.CoolOffLimitExceededException;
import com.hdfcbank.insurance.adapter.common.util.CustomValidationStatus;
import com.hdfcbank.insurance.hli.common.enums.HLICustomCommonApiStatusCodes;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.slf4j.MDC;
import org.springframework.http.HttpStatus;
import java.util.List;
import java.util.Map;
import static com.hdfcbank.insurance.hli.support.JourneyTestData.*;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class GenericExceptionHandlerTest {
    private final JourneyServiceFeignClient client = mock(JourneyServiceFeignClient.class);
    private final GenericExceptionHandler handler = new GenericExceptionHandler(client);

    @AfterEach
    void clearMdc() { MDC.clear(); }

    @Test
    void inlineValidationReturnsErrorWithoutDroppingJourney() {
        var response = handler.handle(validation("INLINE"));
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals("INLINE", response.getBody().getStatus().getType());
        assertEquals("Not eligible", response.getBody().getStatus().getTitle());
        assertEquals(List.of("eligibility failed"), response.getBody().getStatus().getErrors());
        verifyNoInteractions(client);
    }

    @Test
    void fullScreenValidationMarksJourneyInactiveAndStoresDropOffReason() {
        MDC.put(MDCConstants.JOURNEY_ID, JOURNEY_ID);
        when(client.fetch(JOURNEY_ID)).thenReturn(journey());
        var response = handler.handle(validation("FULL_SCREEN"));
        assertEquals(HttpStatus.OK, response.getStatusCode());
        var request = ArgumentCaptor.forClass(UpdateSystemDataJourneyRequest.class);
        verify(client).update(request.capture());
        assertEquals("DROP_OFF_CUSTOMER_EXCLUDED", request.getValue().getJourneyState().getStateName());
        var status = (Map<?, ?>) request.getValue().getData().get("journeyStatusDetail");
        assertEquals("InActive", status.get("status"));
        var reason = (CustomValidationStatus) status.get("journeyDropOff");
        assertEquals("Not eligible", reason.getTitle());
        assertEquals(List.of("eligibility failed"), reason.getErrors());
    }

    @Test
    void coolingLimitReturnsVerificationErrorAndDropsJourney() {
        MDC.put(MDCConstants.JOURNEY_ID, JOURNEY_ID);
        when(client.fetch(JOURNEY_ID)).thenReturn(journey());
        var exception = mock(CoolOffLimitExceededException.class);
        when(exception.getApiResponseStatusCodeLiteral()).thenReturn(HLICustomCommonApiStatusCodes.CUSTOM_VALIDATION_EXCEPTION);
        when(exception.getErrors()).thenReturn(new String[]{"attempt limit reached"});
        var response = handler.handle(exception);
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals("Verification Failed", response.getBody().getStatus().getTitle());
        assertEquals("FULL_SCREEN", response.getBody().getStatus().getType());
        assertEquals(List.of("attempt limit reached"), response.getBody().getStatus().getErrors());
        verify(client).update(any(UpdateSystemDataJourneyRequest.class));
    }

    private CustomValidationException validation(String screen) {
        return new CustomValidationException(HLICustomCommonApiStatusCodes.CUSTOM_VALIDATION_EXCEPTION,
                "Not eligible", screen, List.of("eligibility failed"));
    }
}
