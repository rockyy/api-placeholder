package com.hdfcbank.insurance.hli.process.service.impl.proposalquestion;

import com.hdfcbank.insurance.adapter.process.models.response.ProposalQuestionResponse;
import org.junit.jupiter.api.Test;
import java.util.Arrays;
import java.util.List;
import static com.hdfcbank.insurance.hli.support.ProposalQuestionTestData.*;
import static org.junit.jupiter.api.Assertions.*;

class ProposalQuestionMappingTest {
    @Test
    void groupsBorrowerQuestionsAndQuotesAndAssignsPropertyQuestionsOnlyToPrimaryBorrower() {
        var response = HLIProposalQuestionsResponseMapper.getHliProposalQuestionResponse(
                journeyWithBorrowers().getJourneyDetail(), questions(), pricing());
        assertEquals(List.of("B1", "C2"), response.getBorrowers().stream().map(b -> b.getBorrower().getId()).toList());
        var primary = response.getBorrowers().getFirst();
        assertEquals(2, primary.getProducts().size());
        assertEquals("QB", primary.getProducts().getFirst().getQuoteId());
        assertEquals(2, primary.getProducts().getFirst().getProductQuestions().size());
        assertEquals("QP", primary.getProducts().getLast().getQuoteId());
        assertEquals(List.of("C2", "X3"), primary.getProducts().getFirst().getNominee().getOptions()
                .stream().map(n -> n.getId()).toList());
        var coBorrower = response.getBorrowers().getLast();
        assertEquals(1, coBorrower.getProducts().size());
        assertEquals("QC", coBorrower.getProducts().getFirst().getQuoteId());
        assertEquals("health", coBorrower.getProducts().getFirst().getProductQuestions().getFirst().getQuestionKey());
    }

    @Test
    void listToMapFiltersEntityAndPropertyCaseInsensitively() {
        var mapped = ProposalQuestionListToMapMapper.toProductQuestionMap(questions(), "b1", "prop1");
        assertEquals(2, mapped.get("LIFE").size());
        assertEquals(1, mapped.get("PROPERTY").size());
    }

    @Test
    void listToMapHandlesMissingResponseProductsAndQuestionLists() {
        assertTrue(ProposalQuestionListToMapMapper.toProductQuestionMap(null, "B1", "PROP1").isEmpty());
        assertTrue(ProposalQuestionListToMapMapper.toProductQuestionMap(new ProposalQuestionResponse(), "B1", "PROP1").isEmpty());
        var response = ProposalQuestionResponse.builder().productWiseQuestions(List.of(
                ProposalQuestionResponse.ProductWiseQuestions.builder().code("").build(),
                ProposalQuestionResponse.ProductWiseQuestions.builder().code("EMPTY").build())).build();
        var mapped = ProposalQuestionListToMapMapper.toProductQuestionMap(response, "B1", "PROP1");
        assertEquals(1, mapped.size());
        assertTrue(mapped.get("EMPTY").isEmpty());
    }

    @Test
    void nomineeOptionsOmitNullCustomersAndHandleEmptyInput() {
        assertTrue(NomineeUtility.getProposalNominee(null).getOptions().isEmpty());
        var nominee = NomineeUtility.getProposalNominee(Arrays.asList(customer("C1", "C"), null));
        assertEquals(1, nominee.getOptions().size());
        assertEquals("C1", nominee.getOptions().getFirst().getId());
    }
}
