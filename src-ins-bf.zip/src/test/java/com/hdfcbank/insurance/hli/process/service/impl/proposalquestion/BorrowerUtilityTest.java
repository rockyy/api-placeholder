package com.hdfcbank.insurance.hli.process.service.impl.proposalquestion;

import com.hdfcbank.insurance.adapter.process.models.response.GetLoanDetailResponse;
import org.junit.jupiter.api.Test;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Locale;
import static org.junit.jupiter.api.Assertions.*;

class BorrowerUtilityTest {
    @Test
    void nomineesExcludeSelfMinorsAndInvalidDatesAndIncludeEighteenthBirthday() {
        var selected = customer("C1", LocalDate.now().minusYears(40).format(DateTimeFormatter.ofPattern("dd/MM/yyyy")));
        var adult = customer("C2", LocalDate.now().minusYears(18).format(DateTimeFormatter.ofPattern("dd/MM/yyyy")));
        var minor = customer("C3", LocalDate.now().minusYears(18).plusDays(1).format(DateTimeFormatter.ofPattern("dd/MM/yyyy")));
        var older = customer("C4", LocalDate.now().minusYears(30).format(DateTimeFormatter.ofPattern("dd-MMM-yyyy", Locale.ENGLISH)));
        var result = BorrowerUtility.getListOfNomineeForBorrower(
                List.of(selected, adult, minor, older, customer("C5", "invalid"), customer("C6", null)), selected);
        assertEquals(List.of("C2", "C4"), result.stream().map(GetLoanDetailResponse.Customer::getNumber).toList());
    }

    @Test
    void missingBorrowersOrSelectedBorrowerReturnNoNominees() {
        assertTrue(BorrowerUtility.getListOfNomineeForBorrower(null, customer("C1", null)).isEmpty());
        assertTrue(BorrowerUtility.getListOfNomineeForBorrower(List.of(), null).isEmpty());
    }

    @Test
    void borrowerMappingTrimsAndJoinsNameParts() {
        var customer = customer("C1", "15/01/1988");
        customer.setFirstName(" Test ");
        customer.setMiddleName(" Middle ");
        customer.setLastName(" User ");
        customer.setMobile("9876543210");
        var result = BorrowerUtility.mapCustomerToBorrower(customer);
        assertEquals("Test Middle User", result.getName());
        assertEquals("C1", result.getId());
        assertEquals("15/01/1988", result.getDateOfBirth());
        assertEquals("9876543210", result.getMobileNumber());
        assertNull(BorrowerUtility.mapCustomerToBorrower(null));
    }

    private GetLoanDetailResponse.Customer customer(String id, String dob) {
        return GetLoanDetailResponse.Customer.builder().number(id).dateOfBirth(dob).build();
    }
}
