package com.hdfcbank.insurance.hli.process.validators;

import com.hdfcbank.insurance.hli.process.models.request.HLIFetchPricingRequest;
import jakarta.validation.ConstraintValidatorContext;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.NullAndEmptySource;
import org.junit.jupiter.params.provider.ValueSource;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class HLIFetchPricingValidatorTest {
    private final HLIFetchPricingValidator validator = new HLIFetchPricingValidator();
    private final ConstraintValidatorContext context = mock(ConstraintValidatorContext.class, RETURNS_DEEP_STUBS);

    @Test
    void acceptsCompletePricingRequest() {
        assertTrue(validator.isValid(validRequest(), context));
        verifyNoInteractions(context);
    }

    @Test
    void rejectsNullRequest() {
        assertFalse(validator.isValid(null, context));
    }

    @ParameterizedTest
    @NullAndEmptySource
    @ValueSource(strings = {" ", "\t"})
    void rejectsMissingOrBlankMode(String mode) {
        var request = validRequest();
        request.setMode(mode);
        assertFalse(validator.isValid(request, context));
        verify(context.buildConstraintViolationWithTemplate("Mode must not be blank")).addPropertyNode("mode");
    }

    @Test
    void rejectsMissingAndEmptyProducts() {
        var request = validRequest();
        request.setProduct(null);
        assertFalse(validator.isValid(request, context));
        request.setProduct(List.of());
        assertFalse(validator.isValid(request, context));
    }

    @ParameterizedTest
    @NullAndEmptySource
    @ValueSource(strings = " ")
    void rejectsMissingOrBlankProductCode(String code) {
        var request = validRequest();
        request.getProduct().getFirst().setCode(code);
        assertFalse(validator.isValid(request, context));
        verify(context.buildConstraintViolationWithTemplate("Product code must not be blank"))
                .addPropertyNode("product[0].code");
    }

    @Test
    void rejectsDuplicateProductCode() {
        var request = validRequest();
        request.setProduct(List.of(request.getProduct().getFirst(), request.getProduct().getFirst()));
        assertFalse(validator.isValid(request, context));
        verify(context.buildConstraintViolationWithTemplate("Duplicate product code: HDFC_3D"))
                .addPropertyNode("product[1].code");
    }

    @Test
    void rejectsMissingAndEmptyAnswerLists() {
        var request = validRequest();
        request.getProduct().getFirst().setAnswers(null);
        assertFalse(validator.isValid(request, context));
        request.getProduct().getFirst().setAnswers(List.of());
        assertFalse(validator.isValid(request, context));
    }

    @ParameterizedTest
    @ValueSource(strings = {"entityId", "questionKey", "answer"})
    void rejectsMissingAndBlankAnswerFields(String field) {
        var request = validRequest();
        var answer = request.getProduct().getFirst().getAnswers().getFirst();
        switch (field) {
            case "entityId" -> answer.setEntityId(null);
            case "questionKey" -> answer.setQuestionKey(null);
            default -> answer.setAnswer(null);
        }
        assertFalse(validator.isValid(request, context));
        switch (field) {
            case "entityId" -> answer.setEntityId(" ");
            case "questionKey" -> answer.setQuestionKey(" ");
            default -> answer.setAnswer(" ");
        }
        assertFalse(validator.isValid(request, context));
    }

    private HLIFetchPricingRequest validRequest() {
        var answer = HLIFetchPricingRequest.Product.PricingAnswer.builder()
                .entityId("C123").questionKey("sum_insured").answer("100000").build();
        return HLIFetchPricingRequest.builder().mode("INITIATE_QUOTES")
                .product(List.of(HLIFetchPricingRequest.Product.builder().code("HDFC_3D")
                        .answers(List.of(answer)).build())).build();
    }
}
