package com.hdfcbank.customerconsent.event.infrastructure.config;

import com.hdfcbank.customerconsent.event.properties.SqsProperties;
import org.junit.jupiter.api.Test;
import org.springframework.test.util.ReflectionTestUtils;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.sqs.SqsAsyncClient;

import static org.junit.jupiter.api.Assertions.assertEquals;

class SqsAsyncConfigTest {
    @Test
    void createsClientWithConfiguredRegion() {
        SqsProperties properties = new SqsProperties();
        properties.setRegion("ap-south-1");
        SqsAsyncConfig config = new SqsAsyncConfig();
        ReflectionTestUtils.setField(config, "sqsProperties", properties);
        try (SqsAsyncClient client = config.sqsAsyncClient()) {
            assertEquals(Region.AP_SOUTH_1, client.serviceClientConfiguration().region());
            assertEquals("sqs", client.serviceName());
        }
    }
}
