package com.hdfcbank.customerconsent.event.infrastructure;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import software.amazon.awssdk.services.sqs.SqsAsyncClient;
import software.amazon.awssdk.services.sqs.model.SendMessageRequest;
import software.amazon.awssdk.services.sqs.model.SendMessageResponse;

import java.util.concurrent.CompletableFuture;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class SqsAsyncSendMessageTest {
    @Mock private SqsAsyncClient client;
    @InjectMocks private SqsAsyncSendMessage sender;

    @Test
    void sendsQueueUrlAndBody() {
        when(client.sendMessage(any(SendMessageRequest.class)))
                .thenReturn(CompletableFuture.completedFuture(SendMessageResponse.builder().messageId("message-1").build()));
        sender.sendMessage("https://sqs.example.test/queue", "{\"consent\":true}");
        verify(client).sendMessage(argThat((SendMessageRequest request) ->
                "https://sqs.example.test/queue".equals(request.queueUrl())
                        && "{\"consent\":true}".equals(request.messageBody())));
    }

    @Test
    void containsAsynchronousSendFailure() {
        when(client.sendMessage(any(SendMessageRequest.class)))
                .thenReturn(CompletableFuture.failedFuture(new IllegalStateException("queue unavailable")));
        assertDoesNotThrow(() -> sender.sendMessage("queue-url", "{}"));
        verify(client).sendMessage(any(SendMessageRequest.class));
    }

    @Test
    void returnsBeforeFutureCompletes() {
        CompletableFuture<SendMessageResponse> result = new CompletableFuture<>();
        when(client.sendMessage(any(SendMessageRequest.class))).thenReturn(result);
        sender.sendMessage("queue-url", "{}");
        assertFalse(result.isDone());
        assertTrue(result.complete(SendMessageResponse.builder().messageId("message-1").build()));
    }

    @Test
    void propagatesSynchronousClientFailure() {
        IllegalStateException failure = new IllegalStateException("client closed");
        when(client.sendMessage(any(SendMessageRequest.class))).thenThrow(failure);
        assertSame(failure, assertThrows(IllegalStateException.class, () -> sender.sendMessage("queue-url", "{}")));
    }
}
