package com.hdfcbank.customerconsent.event.exception;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class CustomerConsentUnifyExceptionTest {
    @Test
    void preservesMessageWithoutCause() {
        CustomerConsentUnifyException exception = new CustomerConsentUnifyException("consent failed");
        assertEquals("consent failed", exception.getMessage());
        assertNull(exception.getCause());
    }

    @Test
    void preservesMessageAndCause() {
        IllegalStateException cause = new IllegalStateException("database unavailable");
        CustomerConsentUnifyException exception = new CustomerConsentUnifyException("consent failed", cause);
        assertEquals("consent failed", exception.getMessage());
        assertSame(cause, exception.getCause());
    }
}
