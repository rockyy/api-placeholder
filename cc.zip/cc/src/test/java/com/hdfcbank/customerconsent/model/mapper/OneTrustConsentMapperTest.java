package com.hdfcbank.customerconsent.model.mapper;

import com.hdfcbank.customerconsent.exception.ConsentNotFoundException;
import com.hdfcbank.customerconsent.model.SubmitCustomerConsentRequest;
import com.hdfcbank.customerconsent.model.SubmitOneTrustConsentRequest;
import com.hdfcbank.customerconsent.properties.CustomerConsentProperties;
import com.hdfcbank.starter.commons.exception.BadRequestException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.NullSource;
import org.junit.jupiter.params.provider.ValueSource;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

class OneTrustConsentMapperTest {
    private final OneTrustConsentMapper mapper = new OneTrustConsentMapper();
    private CustomerConsentProperties.ConsentGroup group;
    private CustomerConsentProperties.Consent accepted;
    private CustomerConsentProperties.Consent declined;

    @BeforeEach
    void setUp() {
        accepted = consent("accepted", "purpose-accepted");
        declined = consent("declined", "purpose-declined");
        group = new CustomerConsentProperties.ConsentGroup();
        group.setApplicationName("Consent application");
        group.setRequestInformation("Request information");
        group.setItems(List.of(accepted, declined));
        CustomerConsentProperties.Service service = new CustomerConsentProperties.Service();
        service.setConsents(Map.of("journey", group));
        CustomerConsentProperties properties = new CustomerConsentProperties();
        properties.setService(service);
        ReflectionTestUtils.setField(mapper, "customerConsentProperties", properties);
    }

    @Test
    void mapsCustomerDetailsAndBothConsentDecisions() {
        SubmitCustomerConsentRequest request = request("+919876543210");
        SubmitOneTrustConsentRequest actual = mapper.getSubmitOneTrustConsentRequest(request);
        assertAll(() -> assertEquals("+919876543210", actual.getIdentifier()),
                () -> assertEquals("Mobile", actual.getIdentifierType()),
                () -> assertEquals("2026-01-02T10:00:00Z", actual.getInteractionDate()),
                () -> assertEquals("Request information", actual.getRequestInformation()),
                () -> assertEquals("Consent application", actual.getCustomPayload().getApplicationName()),
                () -> assertEquals("AAAAA0000A", actual.getDsDataElements().getPan()),
                () -> assertEquals("Test", actual.getDsDataElements().getFirstName()),
                () -> assertEquals("Customer", actual.getDsDataElements().getLastName()),
                () -> assertEquals("1990-01-01", actual.getDsDataElements().getDateOfBirth()));
        assertEquals(2, actual.getPurposes().size());
        assertEquals("purpose-accepted", actual.getPurposes().getFirst().getId());
        assertEquals("CONFIRMED", actual.getPurposes().getFirst().getTransactionType());
        assertEquals("purpose-declined", actual.getPurposes().getLast().getId());
        assertEquals("NOTGIVEN", actual.getPurposes().getLast().getTransactionType());
        assertTrue(actual.getPurposes().getFirst().getCustomPreferences().isEmpty());
    }

    @Test
    void mapsPreferencesAndOptions() {
        CustomerConsentProperties.Option option = new CustomerConsentProperties.Option();
        option.setId("email");
        CustomerConsentProperties.Preference preference = new CustomerConsentProperties.Preference();
        preference.setId("channel");
        preference.setOptions(List.of(option));
        accepted.getPurposes().getFirst().setPreference(List.of(preference));
        SubmitOneTrustConsentRequest actual = mapper.getSubmitOneTrustConsentRequest(request("+919876543210"));
        SubmitOneTrustConsentRequest.CustomPreference mapped = actual.getPurposes().getFirst().getCustomPreferences().getFirst();
        assertEquals("channel", mapped.getId());
        assertEquals(List.of("email"), mapped.getOptions());
    }

    @Test
    void usesEmptyOptionsWhenPreferenceHasNoOptions() {
        CustomerConsentProperties.Preference preference = new CustomerConsentProperties.Preference();
        preference.setId("channel");
        accepted.getPurposes().getFirst().setPreference(List.of(preference));
        SubmitOneTrustConsentRequest actual = mapper.getSubmitOneTrustConsentRequest(request("+919876543210"));
        assertTrue(actual.getPurposes().getFirst().getCustomPreferences().getFirst().getOptions().isEmpty());
    }

    @Test
    void returnsConfiguredJourneysAndItems() {
        Map<String, List<CustomerConsentProperties.Consent>> actual = mapper.getAllConsents();
        assertEquals(1, actual.size());
        assertSame(group.getItems(), actual.get("journey"));
    }

    @ParameterizedTest
    @NullSource
    @ValueSource(strings = {"", "9876543210", "+449876543210", "+91987654321", "+9198765432100", "+91abcdefghij", " +919876543210"})
    void rejectsMissingOrInvalidIdentifier(String identifier) {
        BadRequestException error = assertThrows(BadRequestException.class,
                () -> mapper.getSubmitOneTrustConsentRequest(request(identifier)));
        assertEquals(identifier == null ? "Please input identifier"
                : "Invalid mobile number format. Please input a valid number starting with +91.", error.getReason());
    }

    @Test
    void rejectsUnknownJourney() {
        SubmitCustomerConsentRequest request = request("+919876543210");
        request.setJourneyName("missing");
        ConsentNotFoundException error = assertThrows(ConsentNotFoundException.class,
                () -> mapper.getSubmitOneTrustConsentRequest(request));
        assertEquals("No consents found for journey: missing", error.getMessage());
    }

    @Test
    void rejectsJourneyWithNoConfiguredConsents() {
        group.setItems(List.of());
        assertThrows(ConsentNotFoundException.class,
                () -> mapper.getSubmitOneTrustConsentRequest(request("+919876543210")));
    }

    @Test
    void ignoresUnknownConsentKeys() {
        List<SubmitOneTrustConsentRequest.Purpose> actual = mapper.GetConfirmedNotGivenConsentsList(
                List.of(decision("unknown", true)), group.getItems());
        assertTrue(actual.isEmpty());
    }

    @Test
    void mapsNoPurposesWhenCustomerHasNoDecisions() {
        assertTrue(mapper.GetConfirmedNotGivenConsentsList(List.of(), group.getItems()).isEmpty());
    }

    @Test
    void deduplicatesRepeatedAcceptedKeys() {
        List<SubmitOneTrustConsentRequest.Purpose> actual = mapper.GetConfirmedNotGivenConsentsList(
                List.of(decision("accepted", true), decision("accepted", true)), group.getItems());
        assertEquals(1, actual.size());
        assertEquals("purpose-accepted", actual.getFirst().getId());
    }

    @Test
    void preservesConfiguredPurposeOrderWithinEachDecisionType() {
        CustomerConsentProperties.Purpose second = new CustomerConsentProperties.Purpose();
        second.setId("second-purpose");
        accepted.setPurposes(List.of(accepted.getPurposes().getFirst(), second));
        List<SubmitOneTrustConsentRequest.Purpose> actual = mapper.GetConfirmedNotGivenConsentsList(
                List.of(decision("declined", false), decision("accepted", true)), group.getItems());
        assertEquals(List.of("purpose-accepted", "second-purpose", "purpose-declined"),
                actual.stream().map(SubmitOneTrustConsentRequest.Purpose::getId).toList());
    }

    private static CustomerConsentProperties.Consent consent(String id, String purposeId) {
        CustomerConsentProperties.Purpose purpose = new CustomerConsentProperties.Purpose();
        purpose.setId(purposeId);
        CustomerConsentProperties.Consent consent = new CustomerConsentProperties.Consent();
        consent.setId(id);
        consent.setPurposes(List.of(purpose));
        return consent;
    }

    private static SubmitCustomerConsentRequest.Consent decision(String key, boolean acceptance) {
        return SubmitCustomerConsentRequest.Consent.builder().key(key).acceptance(acceptance).build();
    }

    private static SubmitCustomerConsentRequest request(String identifier) {
        return SubmitCustomerConsentRequest.builder().journeyId("journey-1").journeyName("journey")
                .customerDetails(SubmitCustomerConsentRequest.CustomerDetail.builder()
                        .pan("AAAAA0000A").firstName("Test").lastName("Customer").dateOfBirth("1990-01-01")
                        .identifier(identifier).identifierType("Mobile").consentsCapturedDate("2026-01-02T10:00:00Z")
                        .consents(List.of(decision("accepted", true), decision("declined", false))).build()).build();
    }
}
