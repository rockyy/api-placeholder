package com.hdfcbank.customerconsent.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.hdfcbank.customerconsent.handler.CustomerConsentHandler;
import com.hdfcbank.customerconsent.model.SubmitCustomerConsentRequest;
import io.awspring.cloud.sqs.listener.acknowledgement.Acknowledgement;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.slf4j.MDC;
import reactor.core.publisher.Mono;
import reactor.core.publisher.Sinks;

import java.util.Map;
import java.util.concurrent.atomic.AtomicReference;

import static com.hdfcbank.starter.commons.constant.RequestHeaders.JOURNEY_ID;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class CustomerConsentConsumerTest {
    private static final String JSON = "{\"journeyId\":\"journey-1\"}";
    @Mock private ObjectMapper objectMapper;
    @Mock private CustomerConsentHandler handler;
    @Mock private Acknowledgement acknowledgement;
    @InjectMocks private CustomerConsentConsumer consumer;
    private Map<String, String> originalMdc;

    @BeforeEach
    void saveMdc() {
        originalMdc = MDC.getCopyOfContextMap();
    }

    @AfterEach
    void restoreMdc() {
        MDC.clear();
        if (originalMdc != null) {
            MDC.setContextMap(originalMdc);
        }
    }

    @Test
    void passesJourneyContextAndAcknowledgesProcessedMessage() throws JsonProcessingException {
        SubmitCustomerConsentRequest request = request();
        when(objectMapper.readValue(JSON, SubmitCustomerConsentRequest.class)).thenReturn(request);
        AtomicReference<String> journeyContext = new AtomicReference<>();
        when(handler.submitCustomerConsents(request)).thenReturn(Mono.deferContextual(context -> {
            journeyContext.set(context.get(JOURNEY_ID));
            return Mono.just(-1L);
        }));
        MDC.put("test-key", "test-value");
        consumer.consumeEvent(JSON, Map.of("MessageId", "message-1"), acknowledgement);
        assertEquals("journey-1", journeyContext.get());
        assertNull(MDC.get("test-key"));
        verify(acknowledgement).acknowledge();
    }

    @Test
    void processesMessageWithoutMessageIdHeader() throws JsonProcessingException {
        SubmitCustomerConsentRequest request = request();
        when(objectMapper.readValue(JSON, SubmitCustomerConsentRequest.class)).thenReturn(request);
        when(handler.submitCustomerConsents(request)).thenReturn(Mono.just(-1L));
        consumer.consumeEvent(JSON, Map.of(), acknowledgement);
        verify(handler).submitCustomerConsents(request);
        verify(acknowledgement).acknowledge();
    }

    @Test
    void acknowledgesAfterSubscriptionBeforeAsynchronousProcessingCompletes() throws JsonProcessingException {
        SubmitCustomerConsentRequest request = request();
        when(objectMapper.readValue(JSON, SubmitCustomerConsentRequest.class)).thenReturn(request);
        Sinks.One<Long> result = Sinks.one();
        when(handler.submitCustomerConsents(request)).thenReturn(result.asMono());
        consumer.consumeEvent(JSON, Map.of("MessageId", "message-1"), acknowledgement);
        verify(acknowledgement).acknowledge();
        assertEquals(Sinks.EmitResult.OK, result.tryEmitValue(-1L));
    }

    @Test
    void doesNotAcknowledgeMalformedJson() throws JsonProcessingException {
        when(objectMapper.readValue(JSON, SubmitCustomerConsentRequest.class))
                .thenThrow(new JsonProcessingException("invalid json") { });
        assertDoesNotThrow(() -> consumer.consumeEvent(JSON, Map.of(), acknowledgement));
        verifyNoInteractions(handler, acknowledgement);
    }

    @Test
    void doesNotAcknowledgeRequestWithMissingCustomerDetails() throws JsonProcessingException {
        when(objectMapper.readValue(JSON, SubmitCustomerConsentRequest.class)).thenReturn(new SubmitCustomerConsentRequest());
        assertDoesNotThrow(() -> consumer.consumeEvent(JSON, Map.of(), acknowledgement));
        verifyNoInteractions(handler, acknowledgement);
    }

    @Test
    void containsAcknowledgementFailure() throws JsonProcessingException {
        SubmitCustomerConsentRequest request = request();
        when(objectMapper.readValue(JSON, SubmitCustomerConsentRequest.class)).thenReturn(request);
        when(handler.submitCustomerConsents(request)).thenReturn(Mono.just(-1L));
        doThrow(new IllegalStateException("acknowledgement failed")).when(acknowledgement).acknowledge();
        assertDoesNotThrow(() -> consumer.consumeEvent(JSON, Map.of(), acknowledgement));
        verify(acknowledgement).acknowledge();
    }

    private static SubmitCustomerConsentRequest request() {
        return SubmitCustomerConsentRequest.builder().journeyId("journey-1")
                .customerDetails(SubmitCustomerConsentRequest.CustomerDetail.builder()
                        .firstName("Test").lastName("Customer").build()).build();
    }
}
