package com.hdfcbank.customerconsent.event.processor;

import com.hdfcbank.customerconsent.adapter.CustomerConsentAdapter;
import com.hdfcbank.customerconsent.event.exception.CustomerConsentUnifyException;
import com.hdfcbank.customerconsent.event.model.CommonJourneyStates;
import com.hdfcbank.customerconsent.event.model.entity.CustomerConsentEntity;
import com.hdfcbank.customerconsent.event.repository.CustomerConsentRepository;
import com.hdfcbank.customerconsent.event.service.JourneyService;
import com.hdfcbank.customerconsent.model.SubmitCustomerConsentRequest;
import com.hdfcbank.customerconsent.model.SubmitOneTrustConsentRequest;
import com.hdfcbank.customerconsent.model.SubmitOneTrustConsentResponse;
import com.hdfcbank.customerconsent.properties.CustomerConsentProperties;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.time.Instant;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class CustomerConsentEventProcessorTest {
    private static final String JOURNEY_ID = "journey-1";
    private static final String CONSENT_ID = "first-second";
    @Mock private JourneyService journeyService;
    @Mock private CustomerConsentAdapter adapter;
    @Mock private CustomerConsentRepository repository;
    @InjectMocks private CustomerConsentEventProcessor processor;
    private final SubmitOneTrustConsentRequest mapped = new SubmitOneTrustConsentRequest();
    private final SubmitCustomerConsentRequest request = SubmitCustomerConsentRequest.builder()
            .journeyId(JOURNEY_ID).customerDetails(SubmitCustomerConsentRequest.CustomerDetail.builder()
                    .consents(List.of(SubmitCustomerConsentRequest.Consent.builder().key("first").acceptance(true).build(),
                            SubmitCustomerConsentRequest.Consent.builder().key("second").acceptance(false).build()))
                    .build()).build();

    @BeforeEach
    void setUp() {
        CustomerConsentProperties.AttemptCount attempts = new CustomerConsentProperties.AttemptCount();
        attempts.setMinAttemptCount(1);
        attempts.setMaxAttemptCount(3);
        CustomerConsentProperties properties = new CustomerConsentProperties();
        properties.setAttemptCount(attempts);
        ReflectionTestUtils.setField(processor, "customerConsentProperties", properties);
    }

    @Test
    void savesNewSuccessfulConsentAndRecordsStatesInOrder() {
        when(adapter.submitCustomerConsents(mapped, CONSENT_ID)).thenReturn(Mono.just(new SubmitOneTrustConsentResponse("receipt")));
        stubUpsert(Mono.empty());
        StepVerifier.create(processor.processConsents(mapped, JOURNEY_ID, request)).expectNext(-1L).verifyComplete();
        CustomerConsentEntity saved = captureSaved();
        assertAll(() -> assertNull(saved.getId()),
                () -> assertEquals(JOURNEY_ID, saved.getJourneyId()),
                () -> assertEquals(CONSENT_ID, saved.getConsentId()),
                () -> assertSame(request, saved.getConsentRequest()),
                () -> assertEquals("SUCCESS", saved.getStatus()),
                () -> assertEquals(1, saved.getAttemptCount()));
        var order = inOrder(journeyService, adapter, repository);
        order.verify(journeyService).recordJourneyState(JOURNEY_ID, CommonJourneyStates.ONE_TRUST_API_INITIATED);
        order.verify(adapter).submitCustomerConsents(mapped, CONSENT_ID);
        order.verify(journeyService).recordJourneyState(JOURNEY_ID, CommonJourneyStates.ONE_TRUST_API_SUCCESS);
        order.verify(repository).findByJourneyIdAndConsentId(JOURNEY_ID, CONSENT_ID);
        order.verify(repository).save(saved);
        verify(repository, never()).updateConsentEntity(anyString(), anyString(), anyInt());
    }

    @Test
    void savesFailureWhenReceiptIsMissing() {
        when(adapter.submitCustomerConsents(mapped, CONSENT_ID)).thenReturn(Mono.just(new SubmitOneTrustConsentResponse()));
        stubUpsert(Mono.empty());
        StepVerifier.create(processor.processConsents(mapped, JOURNEY_ID, request)).expectNext(-1L).verifyComplete();
        assertEquals("FAILURE", captureSaved().getStatus());
        verify(journeyService).recordJourneyState(JOURNEY_ID, CommonJourneyStates.ONE_TRUST_API_FAILURE);
        verify(journeyService, never()).recordJourneyState(JOURNEY_ID, CommonJourneyStates.ONE_TRUST_API_SUCCESS);
    }

    @Test
    void treatsEmptyReceiptAsPresent() {
        when(adapter.submitCustomerConsents(mapped, CONSENT_ID)).thenReturn(Mono.just(new SubmitOneTrustConsentResponse("")));
        stubUpsert(Mono.empty());
        StepVerifier.create(processor.processConsents(mapped, JOURNEY_ID, request)).expectNext(-1L).verifyComplete();
        assertEquals("SUCCESS", captureSaved().getStatus());
    }

    @Test
    void updatesExistingEntityWithoutChangingIdentifiersOrCreatedTimestamp() {
        CustomerConsentEntity existing = new CustomerConsentEntity("original-journey", new SubmitCustomerConsentRequest(),
                "FAILURE", 3, "original-consent");
        existing.setId("document-1");
        existing.setCreatedOn(Instant.parse("2026-01-01T00:00:00Z"));
        when(adapter.submitCustomerConsents(mapped, CONSENT_ID)).thenReturn(Mono.just(new SubmitOneTrustConsentResponse("receipt")));
        stubUpsert(Mono.just(existing));
        StepVerifier.create(processor.processConsents(mapped, JOURNEY_ID, request)).expectNext(-1L).verifyComplete();
        CustomerConsentEntity saved = captureSaved();
        assertSame(existing, saved);
        assertAll(() -> assertEquals("document-1", saved.getId()),
                () -> assertEquals("original-journey", saved.getJourneyId()),
                () -> assertEquals("original-consent", saved.getConsentId()),
                () -> assertEquals(Instant.parse("2026-01-01T00:00:00Z"), saved.getCreatedOn()),
                () -> assertEquals(1, saved.getAttemptCount()),
                () -> assertEquals("SUCCESS", saved.getStatus()),
                () -> assertSame(request, saved.getConsentRequest()));
    }

    @Test
    void persistsFailureAfterReactiveAdapterError() {
        when(adapter.submitCustomerConsents(mapped, CONSENT_ID)).thenReturn(Mono.error(new IllegalStateException("remote failed")));
        stubUpsert(Mono.empty());
        StepVerifier.create(processor.processConsents(mapped, JOURNEY_ID, request)).expectNext(-1L).verifyComplete();
        assertEquals("FAILURE", captureSaved().getStatus());
        verify(journeyService).recordJourneyState(JOURNEY_ID, CommonJourneyStates.ONE_TRUST_API_FAILURE);
    }

    @Test
    void wrapsSynchronousAdapterExceptionWithCause() {
        IllegalArgumentException failure = new IllegalArgumentException("invalid downstream request");
        when(adapter.submitCustomerConsents(mapped, CONSENT_ID)).thenThrow(failure);
        CustomerConsentUnifyException actual = assertThrows(CustomerConsentUnifyException.class,
                () -> processor.processConsents(mapped, JOURNEY_ID, request));
        assertEquals("Unexpected error while updating consents. JourneyId: journey-1", actual.getMessage());
        assertSame(failure, actual.getCause());
        verifyNoInteractions(repository);
    }

    @Test
    void doesNotSaveOrRecordCompletionForEmptyAdapterResponse() {
        when(adapter.submitCustomerConsents(mapped, CONSENT_ID)).thenReturn(Mono.empty());
        StepVerifier.create(processor.processConsents(mapped, JOURNEY_ID, request)).verifyComplete();
        verify(journeyService).recordJourneyState(JOURNEY_ID, CommonJourneyStates.ONE_TRUST_API_INITIATED);
        verifyNoMoreInteractions(journeyService);
        verifyNoInteractions(repository);
    }

    @Test
    void surfacesDatabaseLookupFailureAfterFailureFallback() {
        IllegalStateException failure = new IllegalStateException("lookup unavailable");
        when(adapter.submitCustomerConsents(mapped, CONSENT_ID)).thenReturn(Mono.just(new SubmitOneTrustConsentResponse("receipt")));
        when(repository.findByJourneyIdAndConsentId(JOURNEY_ID, CONSENT_ID)).thenReturn(Mono.error(failure));
        StepVerifier.create(processor.processConsents(mapped, JOURNEY_ID, request))
                .expectErrorSatisfies(error -> {
                    assertInstanceOf(CustomerConsentUnifyException.class, error);
                    assertEquals("Error while saving consent in db", error.getMessage());
                    assertSame(failure, error.getCause());
                }).verify();
        verify(repository, times(2)).findByJourneyIdAndConsentId(JOURNEY_ID, CONSENT_ID);
        verify(repository, never()).save(any(CustomerConsentEntity.class));
    }

    @Test
    void surfacesDatabaseSaveFailureAfterFailureFallback() {
        IllegalStateException failure = new IllegalStateException("save unavailable");
        when(adapter.submitCustomerConsents(mapped, CONSENT_ID)).thenReturn(Mono.just(new SubmitOneTrustConsentResponse("receipt")));
        when(repository.findByJourneyIdAndConsentId(JOURNEY_ID, CONSENT_ID)).thenReturn(Mono.empty());
        when(repository.save(any(CustomerConsentEntity.class))).thenReturn(Mono.error(failure));
        StepVerifier.create(processor.processConsents(mapped, JOURNEY_ID, request))
                .expectErrorSatisfies(error -> {
                    assertInstanceOf(CustomerConsentUnifyException.class, error);
                    assertSame(failure, error.getCause());
                }).verify();
        verify(repository, times(2)).save(any(CustomerConsentEntity.class));
        verify(journeyService).recordJourneyState(JOURNEY_ID, CommonJourneyStates.ONE_TRUST_API_FAILURE);
    }

    @Test
    void persistsFailureWhenSuccessStateNotificationFails() {
        when(adapter.submitCustomerConsents(mapped, CONSENT_ID)).thenReturn(Mono.just(new SubmitOneTrustConsentResponse("receipt")));
        doAnswer(invocation -> {
            if (invocation.getArgument(1) == CommonJourneyStates.ONE_TRUST_API_SUCCESS) {
                throw new IllegalStateException("journey queue unavailable");
            }
            return null;
        }).when(journeyService).recordJourneyState(eq(JOURNEY_ID), any(CommonJourneyStates.class));
        stubUpsert(Mono.empty());
        StepVerifier.create(processor.processConsents(mapped, JOURNEY_ID, request)).expectNext(-1L).verifyComplete();
        assertEquals("FAILURE", captureSaved().getStatus());
    }

    private void stubUpsert(Mono<CustomerConsentEntity> existing) {
        when(repository.findByJourneyIdAndConsentId(JOURNEY_ID, CONSENT_ID)).thenReturn(existing);
        when(repository.save(any(CustomerConsentEntity.class))).thenAnswer(invocation -> Mono.just(invocation.getArgument(0)));
    }

    private CustomerConsentEntity captureSaved() {
        ArgumentCaptor<CustomerConsentEntity> captor = ArgumentCaptor.forClass(CustomerConsentEntity.class);
        verify(repository).save(captor.capture());
        return captor.getValue();
    }
}
