package com.hdfcbank.customerconsent.scheduler;

import com.hdfcbank.customerconsent.event.infrastructure.sender.MessageSender;
import com.hdfcbank.customerconsent.event.model.entity.CustomerConsentEntity;
import com.hdfcbank.customerconsent.event.repository.CustomerConsentRepository;
import com.hdfcbank.customerconsent.model.SubmitCustomerConsentRequest;
import com.hdfcbank.customerconsent.properties.CustomerConsentProperties;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Sinks;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class CustomerConsentSchedulerTest {
    @Mock private CustomerConsentRepository repository;
    @Mock private MessageSender sender;
    @InjectMocks private CustomerConsentScheduler scheduler;

    @BeforeEach
    void setUp() {
        CustomerConsentProperties.SubmitConsentQueue queue = new CustomerConsentProperties.SubmitConsentQueue();
        queue.setTopic("consent-queue");
        CustomerConsentProperties properties = new CustomerConsentProperties();
        properties.setFailedCountLimit(25);
        properties.setSubmitConsentQueue(queue);
        ReflectionTestUtils.setField(scheduler, "customerConsentProperties", properties);
    }

    @Test
    void skipsSendingWhenNoFailedConsentsExist() {
        when(repository.findByStatusWithLimit("FAILURE", 25)).thenReturn(Flux.empty());
        scheduler.scheduleTask();
        verify(repository).findByStatusWithLimit("FAILURE", 25);
        verifyNoInteractions(sender);
    }

    @Test
    void requeuesEachFailedConsentWithItsOriginalRequest() {
        SubmitCustomerConsentRequest first = SubmitCustomerConsentRequest.builder().journeyId("first").build();
        SubmitCustomerConsentRequest second = SubmitCustomerConsentRequest.builder().journeyId("second").build();
        when(repository.findByStatusWithLimit("FAILURE", 25)).thenReturn(Flux.just(entity(first), entity(second)));
        scheduler.scheduleTask();
        verify(sender).send("consent-queue", first);
        verify(sender).send("consent-queue", second);
        verifyNoMoreInteractions(sender);
        verify(repository, never()).save(any(CustomerConsentEntity.class));
    }

    @Test
    void subscribesToAsynchronousRepositoryResults() {
        Sinks.Many<CustomerConsentEntity> results = Sinks.many().unicast().onBackpressureBuffer();
        when(repository.findByStatusWithLimit("FAILURE", 25)).thenReturn(results.asFlux());
        scheduler.scheduleTask();
        SubmitCustomerConsentRequest request = new SubmitCustomerConsentRequest();
        assertEquals(Sinks.EmitResult.OK, results.tryEmitNext(entity(request)));
        verifyNoInteractions(sender);
        assertEquals(Sinks.EmitResult.OK, results.tryEmitComplete());
        verify(sender).send("consent-queue", request);
    }

    private static CustomerConsentEntity entity(SubmitCustomerConsentRequest request) {
        CustomerConsentEntity entity = new CustomerConsentEntity();
        entity.setConsentRequest(request);
        return entity;
    }
}
