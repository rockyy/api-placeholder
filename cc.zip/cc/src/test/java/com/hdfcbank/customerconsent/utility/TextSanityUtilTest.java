package com.hdfcbank.customerconsent.utility;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.NullAndEmptySource;

import static org.junit.jupiter.api.Assertions.assertEquals;

class TextSanityUtilTest {
    @ParameterizedTest
    @NullAndEmptySource
    void preservesNullAndEmptyText(String text) {
        assertEquals(text, TextSanityUtil.sanitize(text));
    }

    @ParameterizedTest
    @CsvSource({"plain text,plain text", "' a  b ',' a  b '", "'a\tb','a b'",
            "'a\nb','a b'", "'a\rb','a b'", "'a\t\n\rb','a b'"})
    void replacesEachRunOfControlCharactersWithOneSpace(String input, String expected) {
        assertEquals(expected, TextSanityUtil.sanitize(input));
    }
}
