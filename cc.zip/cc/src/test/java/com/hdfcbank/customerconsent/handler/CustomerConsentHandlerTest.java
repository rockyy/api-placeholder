package com.hdfcbank.customerconsent.handler;

import com.hdfcbank.customerconsent.model.JourneyConsentRequest;
import com.hdfcbank.customerconsent.model.JourneyConsentResponse;
import com.hdfcbank.customerconsent.model.SubmitCustomerConsentRequest;
import com.hdfcbank.customerconsent.service.CustomerConsentService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class CustomerConsentHandlerTest {
    @Mock private CustomerConsentService service;
    @InjectMocks private CustomerConsentHandler handler;

    @Test
    void delegatesJourneyFetch() {
        JourneyConsentResponse response = JourneyConsentResponse.builder().build();
        when(service.getJourneyConsents("journey")).thenReturn(Mono.just(response));
        StepVerifier.create(handler.getJourneyConsents(new JourneyConsentRequest("journey")))
                .expectNext(response).verifyComplete();
        verify(service).getJourneyConsents("journey");
    }

    @Test
    void propagatesFetchFailure() {
        IllegalStateException failure = new IllegalStateException("fetch failed");
        when(service.getJourneyConsents("journey")).thenReturn(Mono.error(failure));
        StepVerifier.create(handler.getJourneyConsents(new JourneyConsentRequest("journey")))
                .expectErrorMatches(error -> error == failure).verify();
    }

    @Test
    void delegatesSubmission() {
        SubmitCustomerConsentRequest request = new SubmitCustomerConsentRequest();
        when(service.submitCustomerConsents(request)).thenReturn(Mono.just(-1L));
        StepVerifier.create(handler.submitCustomerConsents(request)).expectNext(-1L).verifyComplete();
        verify(service).submitCustomerConsents(request);
    }

    @Test
    void propagatesSubmissionFailure() {
        SubmitCustomerConsentRequest request = new SubmitCustomerConsentRequest();
        IllegalStateException failure = new IllegalStateException("submit failed");
        when(service.submitCustomerConsents(request)).thenReturn(Mono.error(failure));
        StepVerifier.create(handler.submitCustomerConsents(request))
                .expectErrorMatches(error -> error == failure).verify();
    }
}
