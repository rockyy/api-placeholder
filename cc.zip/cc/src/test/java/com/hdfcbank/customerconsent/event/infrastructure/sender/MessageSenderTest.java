package com.hdfcbank.customerconsent.event.infrastructure.sender;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.hdfcbank.customerconsent.event.infrastructure.SqsAsyncSendMessage;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class MessageSenderTest {
    @Mock private ObjectMapper objectMapper;
    @Mock private SqsAsyncSendMessage sqs;
    @InjectMocks private MessageSender sender;

    @Test
    void sendsSerializedObjectToRequestedDestination() throws JsonProcessingException {
        Object payload = new Object();
        when(objectMapper.writeValueAsString(payload)).thenReturn("{\"value\":1}");
        sender.send("queue-url", payload);
        verify(sqs).sendMessage("queue-url", "{\"value\":1}");
    }

    @Test
    void wrapsSerializationFailureAndDoesNotSend() throws JsonProcessingException {
        Object payload = new Object();
        JsonProcessingException failure = new JsonProcessingException("cannot serialize") { };
        when(objectMapper.writeValueAsString(payload)).thenThrow(failure);
        RuntimeException error = assertThrows(RuntimeException.class, () -> sender.send("queue-url", payload));
        assertSame(failure, error.getCause());
        verifyNoInteractions(sqs);
    }

    @Test
    void propagatesSynchronousTransportFailure() throws JsonProcessingException {
        Object payload = new Object();
        when(objectMapper.writeValueAsString(payload)).thenReturn("{}");
        IllegalStateException failure = new IllegalStateException("queue unavailable");
        doThrow(failure).when(sqs).sendMessage("queue-url", "{}");
        assertSame(failure, assertThrows(IllegalStateException.class, () -> sender.send("queue-url", payload)));
    }
}
