package com.hdfcbank.customerconsent.event.repository;

import com.hdfcbank.customerconsent.event.model.entity.CustomerConsentEntity;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.mongodb.core.ReactiveMongoTemplate;
import org.springframework.data.mongodb.core.query.Query;
import reactor.core.publisher.Flux;
import reactor.test.StepVerifier;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class CustomerConsentCustomRepositoryImplTest {
    @Mock private ReactiveMongoTemplate template;
    @InjectMocks private CustomerConsentCustomRepositoryImpl repository;

    @Test
    void filtersByStatusAndAppliesLimit() {
        CustomerConsentEntity entity = new CustomerConsentEntity();
        when(template.find(any(Query.class), eq(CustomerConsentEntity.class))).thenReturn(Flux.just(entity));
        StepVerifier.create(repository.findByStatusWithLimit("FAILURE", 25)).expectNext(entity).verifyComplete();
        ArgumentCaptor<Query> captor = ArgumentCaptor.forClass(Query.class);
        verify(template).find(captor.capture(), eq(CustomerConsentEntity.class));
        assertEquals("FAILURE", captor.getValue().getQueryObject().getString("status"));
        assertEquals(25, captor.getValue().getLimit());
    }

    @Test
    void returnsEmptyWhenNoMatchingDocumentsExist() {
        when(template.find(any(Query.class), eq(CustomerConsentEntity.class))).thenReturn(Flux.empty());
        StepVerifier.create(repository.findByStatusWithLimit("FAILURE", 25)).verifyComplete();
    }

    @Test
    void propagatesDatabaseError() {
        IllegalStateException failure = new IllegalStateException("database unavailable");
        when(template.find(any(Query.class), eq(CustomerConsentEntity.class))).thenReturn(Flux.error(failure));
        StepVerifier.create(repository.findByStatusWithLimit("FAILURE", 25))
                .expectErrorMatches(error -> error == failure).verify();
    }
}
