package com.hdfcbank.customerconsent.adapter;

import com.hdfcbank.customerconsent.model.SubmitOneTrustConsentRequest;
import com.hdfcbank.customerconsent.properties.CustomerConsentProperties;
import com.hdfcbank.starter.commons.exception.DownstreamServiceException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.reactive.function.client.ClientResponse;
import org.springframework.web.reactive.function.client.ExchangeFunction;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.net.URI;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

class CustomerConsentAdapterTest {
    private final ExchangeFunction exchange = mock(ExchangeFunction.class);
    private final CustomerConsentAdapter adapter = new CustomerConsentAdapter();
    private final SubmitOneTrustConsentRequest request = SubmitOneTrustConsentRequest.builder().identifier("+919876543210").build();

    @BeforeEach
    void setUp() {
        CustomerConsentProperties.OneTrustDetails details = new CustomerConsentProperties.OneTrustDetails();
        details.setServiceUrl("https://onetrust.example.test/consents");
        CustomerConsentProperties properties = new CustomerConsentProperties();
        properties.setOneTrustDetails(details);
        ReflectionTestUtils.setField(adapter, "customerConsentProperties", properties);
        ReflectionTestUtils.setField(adapter, "webClient", WebClient.builder().exchangeFunction(exchange).build());
    }

    @Test
    void postsRequestWithJourneyHeaderAndReadsReceipt() {
        when(exchange.exchange(any())).thenReturn(Mono.just(response(HttpStatus.OK, "{\"receipt\":\"receipt-1\"}")));
        StepVerifier.create(adapter.submitCustomerConsents(request, "journey-1"))
                .assertNext(actual -> assertEquals("receipt-1", actual.getReceipt())).verifyComplete();
        verify(exchange).exchange(argThat(actual -> actual.method() == HttpMethod.POST
                && URI.create("https://onetrust.example.test/consents").equals(actual.url())
                && "journey-1".equals(actual.headers().getFirst("x-journey-id"))));
    }

    @ParameterizedTest
    @ValueSource(ints = {400, 401, 429, 500, 503})
    void mapsHttpErrorsToDownstreamServiceException(int status) {
        when(exchange.exchange(any())).thenReturn(Mono.just(response(HttpStatus.valueOf(status), "error body")));
        StepVerifier.create(adapter.submitCustomerConsents(request, "journey-1"))
                .expectErrorSatisfies(error -> {
                    DownstreamServiceException actual = assertInstanceOf(DownstreamServiceException.class, error);
                    assertEquals("One trust is throwing error", actual.getReason());
                }).verify();
    }

    @Test
    void propagatesNonSuccessNonErrorStatus() {
        when(exchange.exchange(any())).thenReturn(Mono.just(response(HttpStatus.FOUND, "redirect")));
        StepVerifier.create(adapter.submitCustomerConsents(request, "journey-1"))
                .expectErrorSatisfies(error -> {
                    WebClientResponseException actual = assertInstanceOf(WebClientResponseException.class, error);
                    assertEquals(HttpStatus.FOUND, actual.getStatusCode());
                }).verify();
    }

    @Test
    void completesWithoutReceiptForEmptySuccessfulBody() {
        when(exchange.exchange(any())).thenReturn(Mono.just(ClientResponse.create(HttpStatus.NO_CONTENT).build()));
        StepVerifier.create(adapter.submitCustomerConsents(request, "journey-1")).verifyComplete();
    }

    @Test
    void propagatesTransportError() {
        IllegalStateException failure = new IllegalStateException("connection failed");
        when(exchange.exchange(any())).thenReturn(Mono.error(failure));
        StepVerifier.create(adapter.submitCustomerConsents(request, "journey-1"))
                .expectErrorMatches(error -> error == failure).verify();
    }

    @Test
    void rejectsNullRequestBeforeCallingRemoteService() {
        IllegalArgumentException error = assertThrows(IllegalArgumentException.class,
                () -> adapter.submitCustomerConsents(null, "journey-1"));
        assertEquals("SubmitOneTrustConsentRequest cannot be null", error.getMessage());
        verifyNoInteractions(exchange);
    }

    private static ClientResponse response(HttpStatus status, String body) {
        return ClientResponse.create(status).header("Content-Type", MediaType.APPLICATION_JSON_VALUE).body(body).build();
    }
}
