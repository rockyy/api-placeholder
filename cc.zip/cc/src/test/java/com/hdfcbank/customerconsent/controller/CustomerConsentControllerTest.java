package com.hdfcbank.customerconsent.controller;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.hdfcbank.customerconsent.handler.CustomerConsentHandler;
import com.hdfcbank.customerconsent.model.JourneyConsentRequest;
import com.hdfcbank.customerconsent.model.JourneyConsentResponse;
import com.hdfcbank.starter.commons.model.core.ApiResponseStatus;
import com.hdfcbank.starter.commons.model.core.ApiResponseStatusCode;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.reactive.config.EnableWebFlux;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.web.reactive.server.WebTestClient;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class CustomerConsentControllerTest {
    @Mock private CustomerConsentHandler handler;
    @InjectMocks private CustomerConsentController controller;
    private AnnotationConfigApplicationContext context;

    @AfterEach
    void closeContext() {
        if (context != null) {
            context.close();
        }
    }

    private WebTestClient client() {
        context = new AnnotationConfigApplicationContext();
        context.getBeanFactory().registerSingleton("customerConsentHandler", handler);
        context.registerBean(CustomerConsentController.class, () -> controller);
        context.register(WebConfig.class);
        context.refresh();
        return WebTestClient.bindToApplicationContext(context).build();
    }

    @Configuration(proxyBeanMethods = false)
    @EnableWebFlux
    static class WebConfig { }

    @Test
    void returnsOkWithHandlerResponse() {
        JourneyConsentRequest request = new JourneyConsentRequest("journey");
        JourneyConsentResponse response = JourneyConsentResponse.builder().build();
        when(handler.getJourneyConsents(request)).thenReturn(Mono.just(response));
        StepVerifier.create(controller.getJourneyConsents(request)).assertNext(actual -> {
            assertEquals(HttpStatus.OK, actual.getStatusCode());
            assertSame(response, actual.getBody());
        }).verifyComplete();
    }

    @Test
    void propagatesHandlerError() {
        JourneyConsentRequest request = new JourneyConsentRequest("journey");
        IllegalStateException failure = new IllegalStateException("fetch failed");
        when(handler.getJourneyConsents(request)).thenReturn(Mono.error(failure));
        StepVerifier.create(controller.getJourneyConsents(request))
                .expectErrorMatches(error -> error == failure).verify();
    }

    @Test
    void completesWithoutResponseWhenHandlerIsEmpty() {
        JourneyConsentRequest request = new JourneyConsentRequest("journey");
        when(handler.getJourneyConsents(request)).thenReturn(Mono.empty());
        StepVerifier.create(controller.getJourneyConsents(request)).verifyComplete();
    }

    @Test
    void exposesFetchRouteAndSerializesResponse() {
        JourneyConsentResponse response = JourneyConsentResponse.builder()
                .status(new ApiResponseStatus(ApiResponseStatusCode.SUCCESS))
                .data(List.of(JourneyConsentResponse.Consent.builder().key("consent-1").build())).build();
        when(handler.getJourneyConsents(any(JourneyConsentRequest.class))).thenReturn(Mono.just(response));
        client().post()
                .uri("/api/v1/customer-consent/fetch").contentType(MediaType.APPLICATION_JSON)
                .bodyValue(new JourneyConsentRequest("journey")).exchange()
                .expectStatus().isOk().expectBody().consumeWith(result -> {
                    JsonNode actual = assertDoesNotThrow(() -> new ObjectMapper().readTree(result.getResponseBody()));
                    assertEquals("0000", actual.at("/status/code").asText());
                    assertEquals(1, actual.get("data").size());
                    assertEquals("consent-1", actual.at("/data/0/key").asText());
                });
        verify(handler).getJourneyConsents(argThat(request -> "journey".equals(request.getJourneyName())));
    }

    @Test
    void rejectsMalformedJsonBeforeCallingHandler() {
        client().post()
                .uri("/api/v1/customer-consent/fetch").contentType(MediaType.APPLICATION_JSON)
                .bodyValue("{").exchange().expectStatus().isBadRequest();
        verifyNoInteractions(handler);
    }
}
