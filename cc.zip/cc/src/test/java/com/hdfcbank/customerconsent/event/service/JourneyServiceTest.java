package com.hdfcbank.customerconsent.event.service;

import com.hdfcbank.customerconsent.event.infrastructure.sender.MessageSender;
import com.hdfcbank.customerconsent.event.model.CommonJourneyStates;
import com.hdfcbank.customerconsent.event.model.UpdateJourneyDataRequest;
import com.hdfcbank.customerconsent.event.properties.JourneyApiProperties;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.EnumSource;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import java.time.Instant;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class JourneyServiceTest {
    @Mock private MessageSender sender;
    @InjectMocks private JourneyService service;

    @BeforeEach
    void setUp() {
        JourneyApiProperties.Journey journey = new JourneyApiProperties.Journey();
        journey.setTopic("journey-queue");
        JourneyApiProperties properties = new JourneyApiProperties();
        properties.setJourney(journey);
        ReflectionTestUtils.setField(service, "journeyApiProperties", properties);
    }

    @ParameterizedTest
    @EnumSource(CommonJourneyStates.class)
    void sendsJourneyStateAndCurrentTimestamp(CommonJourneyStates state) {
        Instant before = Instant.now();
        service.recordJourneyState("journey-1", state);
        Instant after = Instant.now();
        ArgumentCaptor<Object> captor = ArgumentCaptor.forClass(Object.class);
        verify(sender).send(eq("journey-queue"), captor.capture());
        UpdateJourneyDataRequest<?> request = assertInstanceOf(UpdateJourneyDataRequest.class, captor.getValue());
        assertEquals("journey-1", request.getJourneyId());
        assertEquals(state.name(), request.getJourneyState().getStateName());
        Instant created = request.getJourneyState().getCreatedOn().toInstant();
        assertFalse(created.isBefore(before.truncatedTo(java.time.temporal.ChronoUnit.MILLIS)));
        assertFalse(created.isAfter(after));
        assertNull(request.getData());
    }

    @Test
    void propagatesSendFailure() {
        IllegalStateException failure = new IllegalStateException("queue unavailable");
        doThrow(failure).when(sender).send(eq("journey-queue"), any(UpdateJourneyDataRequest.class));
        assertSame(failure, assertThrows(IllegalStateException.class,
                () -> service.recordJourneyState("journey-1", CommonJourneyStates.ONE_TRUST_API_FAILURE)));
    }
}
