package com.hdfcbank.customerconsent.service;

import com.hdfcbank.customerconsent.event.processor.CustomerConsentEventProcessor;
import com.hdfcbank.customerconsent.model.JourneyConsentResponse;
import com.hdfcbank.customerconsent.model.SubmitCustomerConsentRequest;
import com.hdfcbank.customerconsent.model.SubmitOneTrustConsentRequest;
import com.hdfcbank.customerconsent.model.mapper.OneTrustConsentMapper;
import com.hdfcbank.customerconsent.properties.CustomerConsentProperties;
import com.hdfcbank.starter.commons.exception.DownstreamServiceException;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class CustomerConsentServiceTest {
    @Mock private CustomerConsentProperties customerConsentProperties;
    @Mock private OneTrustConsentMapper oneTrustConsentMapper;
    @Mock private CustomerConsentEventProcessor customerConsentEventProcessor;
    @InjectMocks private CustomerConsentService service;

    @Test
    void mapsConsentFieldsAndUsesDefaultHypertextWhenAbsent() {
        CustomerConsentProperties.HtmlTemplate template = new CustomerConsentProperties.HtmlTemplate();
        template.setHyperText("default link");
        when(customerConsentProperties.getHtmlTemplate()).thenReturn(template);
        CustomerConsentProperties.Consent consent = new CustomerConsentProperties.Consent();
        consent.setId("consent-1");
        consent.setShortDescription("Consent title");
        consent.setLongDescription("Consent description");
        consent.setMandatory("true");
        consent.setType("checkbox");
        consent.setHeadingText("Heading");
        CustomerConsentProperties.Purpose purpose = new CustomerConsentProperties.Purpose();
        purpose.setId("purpose-1");
        consent.setPurposes(List.of(purpose));
        when(oneTrustConsentMapper.getAllConsents()).thenReturn(Map.of("journey", List.of(consent)));

        StepVerifier.create(service.getJourneyConsents("journey"))
                .assertNext(response -> {
                    assertEquals("0000", response.getStatus().getCode());
                    assertEquals(1, response.getData().size());
                    JourneyConsentResponse.Consent actual = response.getData().getFirst();
                    assertAll(() -> assertEquals("consent-1", actual.getKey()),
                            () -> assertEquals("Consent title", actual.getTitle()),
                            () -> assertEquals("Consent description", actual.getDescription()),
                            () -> assertEquals("true", actual.getMandatory()),
                            () -> assertEquals("checkbox", actual.getType()),
                            () -> assertEquals("Heading", actual.getHeadingText()),
                            () -> assertEquals("default link", actual.getHyperText()),
                            () -> assertEquals(List.of("purpose-1"), actual.getConsentPurposeIds()));
                }).verifyComplete();
    }

    @Test
    void preservesExplicitHypertextAndHandlesMissingPurposes() {
        CustomerConsentProperties.HtmlTemplate template = new CustomerConsentProperties.HtmlTemplate();
        template.setHyperText("default link");
        when(customerConsentProperties.getHtmlTemplate()).thenReturn(template);
        CustomerConsentProperties.Consent consent = new CustomerConsentProperties.Consent();
        consent.setHyperText("custom link");
        when(oneTrustConsentMapper.getAllConsents()).thenReturn(Map.of("journey", List.of(consent)));

        StepVerifier.create(service.getJourneyConsents("journey"))
                .assertNext(response -> {
                    assertEquals("custom link", response.getData().getFirst().getHyperText());
                    assertTrue(response.getData().getFirst().getConsentPurposeIds().isEmpty());
                }).verifyComplete();
    }

    @Test
    void returnsDownstreamErrorForUnknownJourney() {
        when(oneTrustConsentMapper.getAllConsents()).thenReturn(Map.of());
        StepVerifier.create(service.getJourneyConsents("missing"))
                .expectErrorSatisfies(error -> {
                    DownstreamServiceException actual = assertInstanceOf(DownstreamServiceException.class, error);
                    assertEquals("An error occurred while retrieving consents: No consents found for journey: missing",
                            actual.getReason());
                }).verify();
    }

    @Test
    void returnsDownstreamErrorForEmptyJourney() {
        when(oneTrustConsentMapper.getAllConsents()).thenReturn(Map.of("journey", List.of()));
        StepVerifier.create(service.getJourneyConsents("journey"))
                .expectError(DownstreamServiceException.class).verify();
    }

    @Test
    void wrapsMapperFailure() {
        when(oneTrustConsentMapper.getAllConsents()).thenThrow(new IllegalStateException("configuration unavailable"));
        StepVerifier.create(service.getJourneyConsents("journey"))
                .expectErrorSatisfies(error -> {
                    DownstreamServiceException actual = assertInstanceOf(DownstreamServiceException.class, error);
                    assertEquals("An error occurred while retrieving consents: configuration unavailable", actual.getReason());
                }).verify();
    }

    @Test
    void submitsMappedRequestWithOriginalJourneyAndRequest() {
        SubmitCustomerConsentRequest request = SubmitCustomerConsentRequest.builder().journeyId("journey-1").build();
        SubmitOneTrustConsentRequest mapped = new SubmitOneTrustConsentRequest();
        when(oneTrustConsentMapper.getSubmitOneTrustConsentRequest(request)).thenReturn(mapped);
        when(customerConsentEventProcessor.processConsents(mapped, "journey-1", request)).thenReturn(Mono.just(-1L));
        StepVerifier.create(service.submitCustomerConsents(request)).expectNext(-1L).verifyComplete();
        verify(customerConsentEventProcessor).processConsents(mapped, "journey-1", request);
    }

    @Test
    void propagatesSubmissionFailure() {
        SubmitCustomerConsentRequest request = SubmitCustomerConsentRequest.builder().journeyId("journey-1").build();
        SubmitOneTrustConsentRequest mapped = new SubmitOneTrustConsentRequest();
        IllegalStateException failure = new IllegalStateException("save failed");
        when(oneTrustConsentMapper.getSubmitOneTrustConsentRequest(request)).thenReturn(mapped);
        when(customerConsentEventProcessor.processConsents(mapped, "journey-1", request)).thenReturn(Mono.error(failure));
        StepVerifier.create(service.submitCustomerConsents(request)).expectErrorMatches(error -> error == failure).verify();
    }

    @Test
    void doesNotProcessRequestWhenMappingFails() {
        SubmitCustomerConsentRequest request = new SubmitCustomerConsentRequest();
        IllegalArgumentException failure = new IllegalArgumentException("invalid request");
        when(oneTrustConsentMapper.getSubmitOneTrustConsentRequest(request)).thenThrow(failure);
        assertSame(failure, assertThrows(IllegalArgumentException.class, () -> service.submitCustomerConsents(request)));
        verifyNoInteractions(customerConsentEventProcessor);
    }
}
