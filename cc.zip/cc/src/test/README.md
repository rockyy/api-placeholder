# Customer consent unit tests

Run with JDK 25 and Maven using the team's repository settings for the private
`com.hdfcbank` dependencies:

```sh
mvn -Dmaven.gitcommitid.skip=true clean verify
```

The Git metadata skip is needed for this exported directory, which has no `.git`.
Use `mvn test` in a Git checkout to run tests and generate coverage without the
verification gate. Add `-o` when all dependencies are cached locally.

The suite uses Mockito and Reactor StepVerifier without starting the full
application, MongoDB, SQS listeners, or remote HTTP services. Controller routing
checks use an isolated WebFlux context with a mocked handler. The SQS configuration
test constructs and closes a client without making requests. Mockito is installed
as a test JVM agent; the subclass mock maker avoids requiring inline mocks.

Tests cover consent retrieval and submission, identifier validation, accepted and
declined purposes and preferences, OneTrust HTTP responses and transport errors,
consent upserts and persistence failures, journey state messages, serialization,
SQS acknowledgements, scheduled requeueing, and log text sanitization.

The tests preserve current behavior: the processor sends the joined consent keys
to the adapter's header argument, accepts any non-null receipt, resets the attempt
count on upsert, and returns `-1L` after saving. The consumer acknowledges after
subscribing, before asynchronous processing necessarily completes. These tests do
not change those contracts.

Surefire results are written to `target/surefire-reports`. JaCoCo HTML and XML
reports are generated in `target/site/jacoco` during `test`; `verify` enforces
80% line and 50% branch coverage per package. Only application startup
(`CustomerConsent`) and the generated empty MapStruct subclass
(`OneTrustConsentMapperImpl`) are excluded. Handwritten mapper logic remains in
scope. Keep JaCoCo report/check exclusions and Sonar coverage exclusions aligned.
Sonar imports the XML report and Surefire results; the server-side quality gate
must still run through the configured Jenkins Sonar scan.
