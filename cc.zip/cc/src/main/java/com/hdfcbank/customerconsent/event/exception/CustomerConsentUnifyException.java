package com.hdfcbank.customerconsent.event.exception;

public class CustomerConsentUnifyException extends RuntimeException {
    public CustomerConsentUnifyException(String message) {
        super(message);
    }

    public CustomerConsentUnifyException(String message, Throwable cause) {
        super(message, cause);
    }
}