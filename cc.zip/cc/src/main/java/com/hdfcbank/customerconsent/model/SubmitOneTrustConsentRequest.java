package com.hdfcbank.customerconsent.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;
import lombok.experimental.SuperBuilder;
import java.util.List;

@Getter
@Setter
@SuperBuilder
@AllArgsConstructor
@NoArgsConstructor
public class SubmitOneTrustConsentRequest {
    private String identifier;
    private String identifierType;
    private String interactionDate;
    private String requestInformation;
    private List<Purpose> purposes;
    private DsDataElements dsDataElements;
    private CustomPayload customPayload;
    @Getter
    @Setter
    @AllArgsConstructor
    @NoArgsConstructor
    @Builder
    public static class Purpose {
        @JsonProperty("Id")
        private String id;
        @JsonProperty("TransactionType")
        private String transactionType;
        @JsonProperty("CustomPreferences")
        private List<CustomPreference> customPreferences;
    }
    @Getter
    @Setter
    @AllArgsConstructor
    @NoArgsConstructor
    @Builder
    public static class CustomPreference {
        @JsonProperty("Id")
        private String id;
        @JsonProperty("Options")
        private List<String> options;
    }
    @Getter
    @Setter
    @AllArgsConstructor
    @NoArgsConstructor
    @Builder
    public static class DsDataElements {
        @JsonProperty("PAN")
        private String pan;
        @JsonProperty("FirstName")
        private String firstName;
        @JsonProperty("LastName")
        private String lastName;
        @JsonProperty("Date of Birth")
        private String dateOfBirth;
    }
    @Getter
    @Setter
    @AllArgsConstructor
    @NoArgsConstructor
    @Builder
    public static class CustomPayload {
        @JsonProperty("Application Name")
        private String applicationName;
    }
}
