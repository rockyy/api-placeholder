package com.hdfcbank.customerconsent.event.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.SuperBuilder;

@Getter
@Setter
@SuperBuilder
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class UpdateJourneyDataRequest<T> {
    private String journeyId;
    private JourneyState journeyState;
    private Profile profile;
    private String dataType;
    private T data;
}
