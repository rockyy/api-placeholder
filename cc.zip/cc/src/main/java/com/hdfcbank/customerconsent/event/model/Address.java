package com.hdfcbank.customerconsent.event.model;


import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.SuperBuilder;

@Getter
@Setter
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class Address {
    private String type;
    private String address1;
    private String address2;
    private String address3;
    private String address4;
    private String zipCode;
    private String city;
    private String state;
    private String country;
}