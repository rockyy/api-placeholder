package com.hdfcbank.customerconsent.adapter;

import com.hdfcbank.customerconsent.model.*;
import com.hdfcbank.customerconsent.properties.CustomerConsentProperties;
import com.hdfcbank.starter.commons.exception.DownstreamServiceException;
import com.hdfcbank.starter.commons.logging.Loggable;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

@Slf4j
@Component
public class CustomerConsentAdapter {
    @Autowired
    private WebClient webClient;
    @Autowired
    private CustomerConsentProperties customerConsentProperties;
    @Loggable
    public Mono<SubmitOneTrustConsentResponse> submitCustomerConsents(SubmitOneTrustConsentRequest submitOneTrustConsentRequest, String journeyId) throws DownstreamServiceException {
        if (submitOneTrustConsentRequest == null) {
            throw new IllegalArgumentException("SubmitOneTrustConsentRequest cannot be null");
        }
        return webClient.post()
                .uri(customerConsentProperties.getOneTrustDetails().getServiceUrl())
                .header("x-journey-id", journeyId)
                .body(BodyInserters.fromValue(submitOneTrustConsentRequest))
                .exchangeToMono(
                        response -> {
                            log.info("response status code: {}", response.statusCode());
                            if (response.statusCode().is2xxSuccessful()) {
                                return response.bodyToMono(SubmitOneTrustConsentResponse.class);
                            } else if (response.statusCode().isError()) {
                                return response.createException().map(exp -> {
                                    log.error("error while calling one trust service, statusCode: {}, body: {}", exp.getStatusCode(), exp.getResponseBodyAsString());
                                    throw new DownstreamServiceException("One trust is throwing error");
                                });
                            }
                            return response.createException().flatMap(Mono::error);
                        }
                );
    }
}
