package com.hdfcbank.customerconsent.event.infrastructure;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import software.amazon.awssdk.services.sqs.SqsAsyncClient;
import software.amazon.awssdk.services.sqs.model.SendMessageRequest;


@Service
@Slf4j
public class SqsAsyncSendMessage {


    @Autowired
    @Qualifier("sqsAsyncClient")
    private SqsAsyncClient sqsAsyncClient;

    public void sendMessage(String topic,String request){

        SendMessageRequest sendMessageRequest = SendMessageRequest.builder()
                .queueUrl(topic)
                .messageBody(request)
                .build();

        long starttime = System.currentTimeMillis();
        sqsAsyncClient.sendMessage(sendMessageRequest)
                .thenAccept(response -> {
                    log.info("Message sent with ID: {}", response.messageId());
                    long endtime = System.currentTimeMillis();
                    log.info("Time Taken to produce message through sqsAsyncClient {}", (endtime - starttime));
                })
                .exceptionally(e -> {
                    log.error("Failed to send message", e);
                    return null;
                });

    }

}
