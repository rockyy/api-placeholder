package com.hdfcbank.customerconsent.event.model;

import com.hdfcbank.customerconsent.event.model.entity.CustomerConsentEntity;
import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ConsentLookupResult {
    private boolean found;
    private CustomerConsentEntity consent;
}