package com.hdfcbank.customerconsent.model;

import com.hdfcbank.starter.commons.model.core.ApiResponse;
import lombok.*;
import lombok.experimental.SuperBuilder;

import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@SuperBuilder
public class JourneyConsentResponse extends ApiResponse<List<JourneyConsentResponse.Consent>> {
    private List<Consent> consents;
    @Builder
    @Setter
    @Getter
    public static class Consent{
        private String key;
        private String title;
        private String mandatory;
        private String type;
        private String headingText;
        private String hyperText;
        private String description;
        private List<String> consentPurposeIds;
    }
}
