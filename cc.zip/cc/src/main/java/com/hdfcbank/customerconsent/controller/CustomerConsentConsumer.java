package com.hdfcbank.customerconsent.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.hdfcbank.customerconsent.handler.CustomerConsentHandler;
import com.hdfcbank.customerconsent.model.SubmitCustomerConsentRequest;
import com.hdfcbank.customerconsent.utility.TextSanityUtil;
import io.awspring.cloud.sqs.annotation.SqsListener;
import io.awspring.cloud.sqs.listener.acknowledgement.Acknowledgement;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.handler.annotation.Headers;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;
import reactor.util.context.Context;

import java.util.Map;

import static com.hdfcbank.starter.commons.constant.RequestHeaders.JOURNEY_ID;

@Component
@Slf4j
public class CustomerConsentConsumer {
    @Autowired
    private ObjectMapper objectMapper;

    @Autowired
    private CustomerConsentHandler customerConsentHandler;

    @SqsListener(value = "${api.submitConsentQueue.topic}", acknowledgementMode = "MANUAL")
    public void consumeEvent(@Payload String requestJSON, @Headers Map<String, Object> headers, Acknowledgement acknowledgement) {
        String messageId = headers.get("MessageId") != null ? headers.get("MessageId").toString() : "UNKNOWN";
        log.info("Received SQS message. MessageId: {}, Payload: {}", TextSanityUtil.sanitize(messageId), TextSanityUtil.sanitize(requestJSON));
        try {
            SubmitCustomerConsentRequest submitCustomerConsentRequest = objectMapper.readValue(requestJSON, SubmitCustomerConsentRequest.class);
            log.info("Request: JourneyId: {}, CustomerFirstName: {}, CustomerLastName: {}",
                    TextSanityUtil.sanitize(submitCustomerConsentRequest.getJourneyId()),
                    TextSanityUtil.sanitize(submitCustomerConsentRequest.getCustomerDetails().getFirstName()),
                    TextSanityUtil.sanitize(submitCustomerConsentRequest.getCustomerDetails().getLastName()));
            boolean isProcessed = processMessageCustomerConsent(submitCustomerConsentRequest);
            if (isProcessed) {
                acknowledgement.acknowledge();
                log.info("Message successfully acknowledged. MessageId: {}", messageId);
            } else {
                log.warn("Message processing failed. It will be retried. MessageId: {}", messageId);
            }
        } catch (JsonProcessingException e) {
            log.error("Send Consents to One trust failing with error : {}, MessageId: {}, e :{}", e.getMessage(),messageId,e);
        } catch (Exception e) {
            log.error("Unexpected error while processing message. MessageId: {} {}", messageId, e);
        }
    }
    private boolean processMessageCustomerConsent(SubmitCustomerConsentRequest submitCustomerConsentRequest) {
        try {
            Mono.deferContextual(contextView -> {
                Context context = Context.of(JOURNEY_ID, submitCustomerConsentRequest.getJourneyId())
                        .putAll(contextView);
                return customerConsentHandler.submitCustomerConsents(submitCustomerConsentRequest)
                        .contextWrite(context)
                        .doFinally(signalType -> MDC.clear());
            }).subscribe();
            return true;
        } catch (Exception e) {
            log.error("processMessageCustomerConsent: Error processing message", e);
            return false;
        }
    }
}
