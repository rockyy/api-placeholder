package com.hdfcbank.customerconsent.scheduler;

import com.hdfcbank.customerconsent.event.infrastructure.sender.MessageSender;
import com.hdfcbank.customerconsent.event.model.entity.CustomerConsentEntity;
import com.hdfcbank.customerconsent.event.repository.CustomerConsentRepository;
import com.hdfcbank.customerconsent.model.SubmitCustomerConsentRequest;
import com.hdfcbank.customerconsent.properties.CustomerConsentProperties;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import static com.hdfcbank.customerconsent.event.model.OneTrustStatus.FAILURE;

@Slf4j
@Component
public class CustomerConsentScheduler {

    @Autowired
    private CustomerConsentRepository customerConsentRepository;

    @Autowired
    private MessageSender consentMessageSender;

    @Autowired
    private CustomerConsentProperties customerConsentProperties;

    @Scheduled(cron = "${service.unify.status.cron}")
    public void scheduleTask() {
        log.info("Starting scheduled job to process failed consents");
        customerConsentRepository.findByStatusWithLimit(FAILURE.toString(), customerConsentProperties.getFailedCountLimit())
                .collectList()
                .flatMap(consents -> {
                    if (consents.isEmpty()) {
                        log.info("No failed consents found, skipping the retry job.");
                        return Mono.empty();
                    }
                    return Flux.fromIterable(consents)
                            .flatMap((consent)->{
                                submitCustomerConsentWithRetry(consent);
                                return Mono.just(true);
                            })
                            .then();
                })
                .doOnTerminate(() -> log.info("Scheduled job finished"))
                .subscribe();
    }

    private void submitCustomerConsentWithRetry(CustomerConsentEntity consent) {
        SubmitCustomerConsentRequest submitRequest = consent.getConsentRequest();
        consentMessageSender.send(customerConsentProperties.getSubmitConsentQueue().getTopic(),
                submitRequest);
    }
}
