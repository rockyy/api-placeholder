package com.hdfcbank.customerconsent.event.repository;

import com.hdfcbank.customerconsent.event.model.entity.CustomerConsentEntity;
import reactor.core.publisher.Flux;

public interface CustomerConsentCustomRepository {
    Flux<CustomerConsentEntity> findByStatusWithLimit(String status, int limit);
}
