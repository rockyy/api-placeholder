package com.hdfcbank.customerconsent.event.model.entity;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.hdfcbank.customerconsent.model.SubmitCustomerConsentRequest;
import lombok.*;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.Instant;


@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
@RequiredArgsConstructor
@Document(collection = "customer-consents")
public class CustomerConsentEntity {
    @Id
    private String id;
    private String journeyId;
    private SubmitCustomerConsentRequest consentRequest;
    private String status;
    private int attemptCount;
    private String consentId;
    @CreatedDate
    private Instant createdOn;

    @LastModifiedDate
    private Instant updatedOn;
    public CustomerConsentEntity(String journeyId, SubmitCustomerConsentRequest consentRequest, String status, int attemptCount,String consentId) {
        this.journeyId = journeyId;
        this.consentRequest = consentRequest;
        this.status = status;
        this.attemptCount = attemptCount;
        this.consentId = consentId;
    }
}
