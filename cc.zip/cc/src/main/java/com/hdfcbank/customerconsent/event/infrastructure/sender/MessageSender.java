package com.hdfcbank.customerconsent.event.infrastructure.sender;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.hdfcbank.customerconsent.event.infrastructure.SqsAsyncSendMessage;
import com.hdfcbank.customerconsent.utility.TextSanityUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Slf4j
@Component
public class MessageSender {

    @Autowired
    private SqsAsyncSendMessage sqsAsyncSendMessage;

    @Autowired
    private ObjectMapper objectMapper;

    public void send(String destination, Object object) {
        try {
            String json = objectMapper.writeValueAsString(object);
            log.info("Sending message {} to destination {}", TextSanityUtil.sanitize(json), TextSanityUtil.sanitize(destination));
            sqsAsyncSendMessage.sendMessage(destination, json);
        } catch (JsonProcessingException e) {
            throw new RuntimeException(e);
        }
    }

}
