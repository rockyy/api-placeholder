package com.hdfcbank.customerconsent.model.mapper;

import com.hdfcbank.customerconsent.exception.ConsentNotFoundException;
import com.hdfcbank.customerconsent.model.SubmitCustomerConsentRequest;
import com.hdfcbank.customerconsent.model.SubmitOneTrustConsentRequest;
import com.hdfcbank.customerconsent.properties.CustomerConsentProperties;
import com.hdfcbank.starter.commons.exception.BadRequestException;
import lombok.extern.slf4j.Slf4j;
import org.mapstruct.Mapper;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.*;
import java.util.stream.Collectors;

@Mapper
@Slf4j
public class OneTrustConsentMapper {
    @Autowired
    private CustomerConsentProperties customerConsentProperties;

    public SubmitOneTrustConsentRequest getSubmitOneTrustConsentRequest(SubmitCustomerConsentRequest submitCustomerConsentRequest) {
        validateSubmitCustomerConsentRequest(submitCustomerConsentRequest);
        Map<String, List<CustomerConsentProperties.Consent>> allConsents = getAllConsents();
        List<CustomerConsentProperties.Consent> nonFilteredJourneyAllConsents =
                getJourneySpecificConsents(allConsents, submitCustomerConsentRequest);
        if (nonFilteredJourneyAllConsents.isEmpty()) {
            throw new ConsentNotFoundException("No consents found for journey: " + submitCustomerConsentRequest.getJourneyName());
        }
        List<SubmitCustomerConsentRequest.Consent> customerConsents =
                submitCustomerConsentRequest.getCustomerDetails().getConsents();
        List<SubmitOneTrustConsentRequest.Purpose> submitOneTrustConsentRequestPurposes =
                GetConfirmedNotGivenConsentsList(customerConsents, nonFilteredJourneyAllConsents);
        SubmitCustomerConsentRequest.CustomerDetail submitCustomerConsentRequestCustomerDetails =
                submitCustomerConsentRequest.getCustomerDetails();
        SubmitOneTrustConsentRequest.DsDataElements submitOneTrustConsentRequestDsDataElements =
                SubmitOneTrustConsentRequestDsDataElementsMapper(submitCustomerConsentRequestCustomerDetails);

        Map<String, CustomerConsentProperties.ConsentGroup> consents = customerConsentProperties.getService().getConsents();
        CustomerConsentProperties.ConsentGroup consentGroup = consents.get(submitCustomerConsentRequest.getJourneyName());
        String requestInformation = consentGroup.getRequestInformation();
        SubmitOneTrustConsentRequest.CustomPayload submitOneTrustConsentRequestCustomPayload =
                submitOneTrustConsentRequestCustomPayloadMapper(consentGroup);

        return SubmitOneTrustConsentRequest
                .builder()
                .identifier(submitCustomerConsentRequest.getCustomerDetails().getIdentifier())
                .identifierType(submitCustomerConsentRequest.getCustomerDetails().getIdentifierType())
                .dsDataElements(submitOneTrustConsentRequestDsDataElements)
                .interactionDate(submitCustomerConsentRequest.getCustomerDetails().getConsentsCapturedDate())
                .purposes(submitOneTrustConsentRequestPurposes)
                .requestInformation(requestInformation)
                .customPayload(submitOneTrustConsentRequestCustomPayload)
                .build();
    }

    private Set<String> getConfirmedCustomerConsentIds(List<SubmitCustomerConsentRequest.Consent> customerConsents) {
        return customerConsents.stream()
                .filter(SubmitCustomerConsentRequest.Consent::isAcceptance)
                .map(SubmitCustomerConsentRequest.Consent::getKey)
                .collect(Collectors.toSet());
    }

    private Set<String> getNotConfirmedCustomerConsentIds(List<SubmitCustomerConsentRequest.Consent> customerConsents) {
        return customerConsents.stream()
                .filter(consent -> !consent.isAcceptance())
                .map(SubmitCustomerConsentRequest.Consent::getKey)
                .collect(Collectors.toSet());
    }

    private List<SubmitOneTrustConsentRequest.Purpose> convertToSubmitPurposes(
            List<CustomerConsentProperties.Consent> journeyConsents, String transactionType) {
        return journeyConsents.stream()
                .flatMap(consent -> consent.getPurposes().stream())
                .map(consentPurpose -> {
                    List<SubmitOneTrustConsentRequest.CustomPreference> customPreferences = consentPurpose.getPreference() != null ?
                            consentPurpose.getPreference().stream()
                                    .map(consentPreference -> {
                                        List<String> options = consentPreference.getOptions() != null ?
                                                consentPreference.getOptions().stream()
                                                        .map(CustomerConsentProperties.Option::getId)
                                                        .collect(Collectors.toList()) : new ArrayList<>();
                                        return SubmitOneTrustConsentRequest.CustomPreference.builder()
                                                .id(consentPreference.getId())
                                                .options(options)
                                                .build();
                                    })
                                    .collect(Collectors.toList()) : new ArrayList<>();

                    return SubmitOneTrustConsentRequest.Purpose.builder()
                            .id(consentPurpose.getId())
                            .transactionType(transactionType)
                            .customPreferences(customPreferences)
                            .build();
                })
                .collect(Collectors.toList());
    }

    private List<CustomerConsentProperties.Consent> filterJourneyConsents(
            List<CustomerConsentProperties.Consent> allConsents, Set<String> consentIds) {
        return allConsents.stream()
                .filter(consent -> consentIds.contains(consent.getId()))
                .collect(Collectors.toList());
    }

    private void validateSubmitCustomerConsentRequest(SubmitCustomerConsentRequest submitCustomerConsentRequest) {
        if (submitCustomerConsentRequest.getCustomerDetails().getIdentifier() == null) {
            throw new BadRequestException("Please input identifier");
        }
        if (!submitCustomerConsentRequest.getCustomerDetails().getIdentifier().matches("^\\+91\\d{10}$")) {
            throw new BadRequestException("Invalid mobile number format. Please input a valid number starting with +91.");
        }
    }

    public Map<String, List<CustomerConsentProperties.Consent>> getAllConsents() {
        Map<String, CustomerConsentProperties.ConsentGroup> consentGroups = customerConsentProperties.getService().getConsents();
        Map<String, List<CustomerConsentProperties.Consent>> allConsents = new HashMap<>();
        for (Map.Entry<String, CustomerConsentProperties.ConsentGroup> entry : consentGroups.entrySet()) {
            allConsents.put(entry.getKey(), entry.getValue().getItems());
        }
        return allConsents;
    }

    private List<CustomerConsentProperties.Consent> getJourneySpecificConsents(Map<String, List<CustomerConsentProperties.Consent>> allConsents, SubmitCustomerConsentRequest submitCustomerConsentRequest) {
        List<CustomerConsentProperties.Consent> nonFilteredJourneyAllConsents =
                allConsents.getOrDefault(submitCustomerConsentRequest.getJourneyName(), Collections.emptyList());
        return nonFilteredJourneyAllConsents;
    }

    public List<SubmitOneTrustConsentRequest.Purpose> GetConfirmedNotGivenConsentsList(
            List<SubmitCustomerConsentRequest.Consent> customerConsents,
            List<CustomerConsentProperties.Consent> nonFilteredJourneyAllConsents) {
        Set<String> confirmedCustomerConsentIds = getConfirmedCustomerConsentIds(customerConsents);
        List<CustomerConsentProperties.Consent> journeyAllConsentsConfirmed = filterJourneyConsents(nonFilteredJourneyAllConsents, confirmedCustomerConsentIds);
        List<SubmitOneTrustConsentRequest.Purpose> submitOneTrustConsentRequestPurposes = convertToSubmitPurposes(journeyAllConsentsConfirmed, "CONFIRMED");

        Set<String> notConfirmedCustomerConsentIds = getNotConfirmedCustomerConsentIds(customerConsents);
        List<CustomerConsentProperties.Consent> journeyAllConsentsNotGiven = filterJourneyConsents(nonFilteredJourneyAllConsents, notConfirmedCustomerConsentIds);
        submitOneTrustConsentRequestPurposes.addAll(convertToSubmitPurposes(journeyAllConsentsNotGiven, "NOTGIVEN"));
        return submitOneTrustConsentRequestPurposes;
    }

    public SubmitOneTrustConsentRequest.DsDataElements SubmitOneTrustConsentRequestDsDataElementsMapper(
            SubmitCustomerConsentRequest.CustomerDetail submitCustomerConsentRequestCustomerDetails) {
        SubmitOneTrustConsentRequest.DsDataElements submitOneTrustConsentRequestDsDataElements = SubmitOneTrustConsentRequest
                .DsDataElements
                .builder()
                .dateOfBirth(submitCustomerConsentRequestCustomerDetails.getDateOfBirth())
                .pan(submitCustomerConsentRequestCustomerDetails.getPan())
                .firstName(submitCustomerConsentRequestCustomerDetails.getFirstName())
                .lastName(submitCustomerConsentRequestCustomerDetails.getLastName())
                .build();
        return submitOneTrustConsentRequestDsDataElements;
    }

    public SubmitOneTrustConsentRequest.CustomPayload submitOneTrustConsentRequestCustomPayloadMapper(
            CustomerConsentProperties.ConsentGroup consentGroup) {
        SubmitOneTrustConsentRequest.CustomPayload submitOneTrustConsentRequestCustomPayload = SubmitOneTrustConsentRequest
                .CustomPayload
                .builder()
                .applicationName(consentGroup.getApplicationName())
                .build();
        return submitOneTrustConsentRequestCustomPayload;
    }

}