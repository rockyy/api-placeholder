package com.hdfcbank.customerconsent.event.properties;

import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Getter
@Setter
@Configuration
@ConfigurationProperties("api")
public class JourneyApiProperties {
    private Journey journey;
    @Getter
    @Setter
    public static class Journey {
        private String topic;
        private String queueUrl;
    }
}
