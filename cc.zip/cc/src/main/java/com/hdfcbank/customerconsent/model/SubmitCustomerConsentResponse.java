package com.hdfcbank.customerconsent.model;

import com.hdfcbank.starter.commons.model.core.ApiResponse;
import lombok.*;
import lombok.experimental.SuperBuilder;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@SuperBuilder
public class SubmitCustomerConsentResponse extends ApiResponse<SubmitCustomerConsentResponse.Receipt> {
    private Receipt receipt;
    @Builder
    @Setter
    @Getter
    @AllArgsConstructor
    @NoArgsConstructor
    public static class Receipt{
        private String receipt;
    }
}
