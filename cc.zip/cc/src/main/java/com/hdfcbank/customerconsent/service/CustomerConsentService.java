package com.hdfcbank.customerconsent.service;

import com.hdfcbank.customerconsent.event.processor.CustomerConsentEventProcessor;
import com.hdfcbank.customerconsent.exception.ConsentNotFoundException;
import com.hdfcbank.customerconsent.model.JourneyConsentResponse;
import com.hdfcbank.customerconsent.model.SubmitCustomerConsentRequest;
import com.hdfcbank.customerconsent.model.SubmitOneTrustConsentRequest;
import com.hdfcbank.customerconsent.model.mapper.OneTrustConsentMapper;
import com.hdfcbank.customerconsent.properties.CustomerConsentProperties;
import com.hdfcbank.starter.commons.exception.DownstreamServiceException;
import com.hdfcbank.starter.commons.model.core.ApiResponseStatus;
import com.hdfcbank.starter.commons.model.core.ApiResponseStatusCode;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

import java.util.*;
import java.util.stream.Collectors;

@Service
@Slf4j
public class CustomerConsentService {
    @Autowired
    CustomerConsentProperties customerConsentProperties;
    @Autowired
    private OneTrustConsentMapper oneTrustConsentMapper;

    @Autowired
    private CustomerConsentEventProcessor customerConsentEventProcessor;
    public Mono<JourneyConsentResponse> getJourneyConsents(String journeyName) {

        try {
            Map<String, List<CustomerConsentProperties.Consent>> allConsents = oneTrustConsentMapper.getAllConsents();
            List<CustomerConsentProperties.Consent> journeyAllConsents = allConsents.getOrDefault(journeyName, Collections.emptyList());
            if (journeyAllConsents.isEmpty()) {
                throw new ConsentNotFoundException("No consents found for journey: " + journeyName);
            }
            List<JourneyConsentResponse.Consent> journeyConsentsList = journeyAllConsents.stream()
                    .map(consent -> JourneyConsentResponse.Consent.builder()
                            .key(consent.getId())
                            .title(consent.getShortDescription())
                            .mandatory(consent.getMandatory())
                            .type(consent.getType())
                            .headingText(consent.getHeadingText())
                            .hyperText(Optional.ofNullable(consent.getHyperText())
                                    .orElse(customerConsentProperties.getHtmlTemplate().getHyperText()))
                            .description(consent.getLongDescription())
                            .consentPurposeIds(consent.getPurposes()!=null?consent.getPurposes().stream().map(purpose -> purpose.getId()).collect(Collectors.toList()) : new ArrayList<>())
                            .build())
                    .collect(Collectors.toList());

            JourneyConsentResponse journeyConsentResponse = JourneyConsentResponse.builder()
                    .status(new ApiResponseStatus(ApiResponseStatusCode.SUCCESS))
                    .data(journeyConsentsList)
                    .build();

            return Mono.just(journeyConsentResponse);

        } catch (Exception ex) {
            return Mono.error(new DownstreamServiceException("An error occurred while retrieving consents: " + ex.getMessage()));
        }
    }


    public Mono<Long> submitCustomerConsents(SubmitCustomerConsentRequest submitCustomerConsentRequest){
        SubmitOneTrustConsentRequest submitOneTrustConsentRequest = oneTrustConsentMapper
                .getSubmitOneTrustConsentRequest(submitCustomerConsentRequest);
        return customerConsentEventProcessor.processConsents(submitOneTrustConsentRequest, submitCustomerConsentRequest.getJourneyId(), submitCustomerConsentRequest);
    }

}
