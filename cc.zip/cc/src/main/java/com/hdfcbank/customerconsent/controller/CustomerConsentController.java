package com.hdfcbank.customerconsent.controller;

import com.hdfcbank.customerconsent.handler.CustomerConsentHandler;
import com.hdfcbank.customerconsent.model.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Mono;

@RestController
@RequestMapping("/api/v1/customer-consent")
@Slf4j
public class CustomerConsentController {

    @Autowired
    private CustomerConsentHandler customerConsentHandler;

    @PostMapping("/fetch")
    public Mono<ResponseEntity<JourneyConsentResponse>> getJourneyConsents(@RequestBody JourneyConsentRequest journeyConsentRequest) {
        Mono<JourneyConsentResponse> journeyConsentResponse = customerConsentHandler.getJourneyConsents(journeyConsentRequest);
        return journeyConsentResponse.map(ResponseEntity::ok);
    }

}
