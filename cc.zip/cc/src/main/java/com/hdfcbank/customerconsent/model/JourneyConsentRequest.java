package com.hdfcbank.customerconsent.model;

import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class JourneyConsentRequest {
    private String journeyName;
}
