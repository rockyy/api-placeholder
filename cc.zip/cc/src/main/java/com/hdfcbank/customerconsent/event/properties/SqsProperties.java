package com.hdfcbank.customerconsent.event.properties;

import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Getter
@Setter
@Configuration
@ConfigurationProperties("service.aws")
public class SqsProperties {
    private String region;
}
