package com.hdfcbank.customerconsent;

import com.hdfcbank.starter.commons.util.SSLHelperUtil;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;
import reactor.core.publisher.Hooks;

@EnableScheduling
@SpringBootApplication(excludeName = "org.springframework.boot.actuate.autoconfigure.tracing.zipkin.ZipkinAutoConfiguration")
public class CustomerConsent {
    public static void main(String args[]){
        SSLHelperUtil.setupSSLProperties();
        Hooks.enableAutomaticContextPropagation();
        SpringApplication.run(CustomerConsent.class, args);
    }
}
