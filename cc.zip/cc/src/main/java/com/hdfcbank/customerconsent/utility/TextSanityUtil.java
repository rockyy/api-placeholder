package com.hdfcbank.customerconsent.utility;

import lombok.experimental.UtilityClass;

@UtilityClass
public class TextSanityUtil {

    //Create to resolve log forging issue (checkmarx)
    public static String sanitize(String request)
    {
        if(null != request)
            return request.replaceAll("[\\t\\n\\r]+"," ");
        return null;
    }
}
