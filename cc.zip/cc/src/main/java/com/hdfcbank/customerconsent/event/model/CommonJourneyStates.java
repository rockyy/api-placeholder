package com.hdfcbank.customerconsent.event.model;

import lombok.Getter;

@Getter
public enum CommonJourneyStates {
    ONE_TRUST_API_INITIATED,
    ONE_TRUST_API_SUCCESS,
    ONE_TRUST_API_FAILURE;

    public String name = name();
}
