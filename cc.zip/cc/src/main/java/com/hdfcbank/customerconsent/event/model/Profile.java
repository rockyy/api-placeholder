package com.hdfcbank.customerconsent.event.model;


import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.hdfcbank.starter.commons.constant.DateTimeConstants;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;
import java.util.List;

@Getter
@Setter
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Profile {

    private String accountId;
    private String sourceId;
    private String branchCode;
    private String address1;
    private String address2;
    private String address3;
    private String address4;
    private String city;
    private String country;
    private String state;
    private String zipCode;
    private String customerMobileNo;
    private String customerFullName;
    private String customerResidencePhoneNo;
    private String customerType;
    private int customerDependents;
    private String name;
    private String mobileNumber;
    private String address;
    private String email;
    private String employmentType;
    private String employerName;
    private String age;
    private String middleNames;
    private String surName;
    private String type;
    private String panNumber;
    private String sasId;
    private String dateOfBirth;
    private String number;
    private String aanNumber;
    private String mpnIdentity;
    private String pseudoCustomerId;
    private String customerId;
    private String emailId;
    private String officialEmailId;
    private String crmLeadKey;
    private String card4Digits;
    private boolean isStaff;
    private String resiPhone;
    private String offPhone;

    @JsonFormat(pattern = DateTimeConstants.DATE_TIME_FORMAT)
    private LocalDateTime lastAccessTime;
    private List<Address> addresses;
    private String firstName;
    private String middleName;
    private String lastName;
    private String dob;
    private String gender;
    private String maritalStatus;
    private String title;
    private String fullName;
    private String shortName;
    private String motherMaidenName;
    private String pinCode;
    private String customerProfession;
    private int customerAnnualIncome;
    private String accountNumber;
    private String accountStatus;
    private String kyc;
    private boolean panValid;
    private String loginType;
    private String spouseName;
    private String motherName;
    private String fatherName;
    private String identifierName;
    private String nrFlag;
    private String phoneNo;
    private String kycDate;
    private String ethnicCode;
    private String grossIncDesc;


}