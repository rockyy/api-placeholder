package com.hdfcbank.customerconsent.event.repository;

import com.hdfcbank.customerconsent.event.model.entity.CustomerConsentEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.ReactiveMongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import reactor.core.publisher.Flux;

public class CustomerConsentCustomRepositoryImpl implements CustomerConsentCustomRepository {

    @Autowired
    private ReactiveMongoTemplate mongoTemplate;

    @Override
    public Flux<CustomerConsentEntity> findByStatusWithLimit(String status, int limit) {
        Query query = new Query();
        query.addCriteria(Criteria.where("status").is(status));
        query.limit(limit);
        return mongoTemplate.find(query, CustomerConsentEntity.class);
    }
}
