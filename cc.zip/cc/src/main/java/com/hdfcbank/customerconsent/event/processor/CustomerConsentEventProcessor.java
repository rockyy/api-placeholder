package com.hdfcbank.customerconsent.event.processor;

import com.hdfcbank.customerconsent.adapter.CustomerConsentAdapter;
import com.hdfcbank.customerconsent.event.exception.CustomerConsentUnifyException;
import com.hdfcbank.customerconsent.event.model.CommonJourneyStates;
import com.hdfcbank.customerconsent.event.model.entity.CustomerConsentEntity;
import com.hdfcbank.customerconsent.event.repository.CustomerConsentRepository;
import com.hdfcbank.customerconsent.event.service.JourneyService;
import com.hdfcbank.customerconsent.model.SubmitCustomerConsentRequest;
import com.hdfcbank.customerconsent.model.SubmitOneTrustConsentRequest;
import com.hdfcbank.customerconsent.model.SubmitOneTrustConsentResponse;
import com.hdfcbank.customerconsent.properties.CustomerConsentProperties;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;


import java.util.stream.Collectors;

import static com.hdfcbank.customerconsent.event.model.OneTrustStatus.FAILURE;
import static com.hdfcbank.customerconsent.event.model.OneTrustStatus.SUCCESS;

@Slf4j
@Component
public class CustomerConsentEventProcessor {

    @Autowired
    private JourneyService journeyService;

    @Autowired
    private CustomerConsentAdapter customerConsentAdapter;

    @Autowired
    private CustomerConsentRepository customerConsentRepository;

    @Autowired
    private CustomerConsentProperties customerConsentProperties;

    public Mono<Long> processConsents(SubmitOneTrustConsentRequest submitOneTrustConsentRequest, String journeyId, SubmitCustomerConsentRequest submitCustomerConsentRequest) {
        String consentId = submitCustomerConsentRequest.getCustomerDetails().getConsents().stream().map(SubmitCustomerConsentRequest.Consent::getKey).collect(Collectors.joining("-"));
        log.info("Consent ID is :: {}",consentId);
        return initiateConsentProcess(submitOneTrustConsentRequest, journeyId, submitCustomerConsentRequest,consentId);

    }

    private Mono<Long> initiateConsentProcess(SubmitOneTrustConsentRequest submitOneTrustConsentRequest, String journeyId, SubmitCustomerConsentRequest submitCustomerConsentRequest,String consentId) {
        journeyService.recordJourneyState(journeyId, CommonJourneyStates.ONE_TRUST_API_INITIATED);
        try{
            return customerConsentAdapter.submitCustomerConsents(submitOneTrustConsentRequest, consentId)
                    .flatMap(submitOneTrustConsentResponse -> {
                        if (isConsentResponseValid(submitOneTrustConsentResponse)) {
                            journeyService.recordJourneyState(journeyId, CommonJourneyStates.ONE_TRUST_API_SUCCESS);
                            return saveConsent(journeyId, submitCustomerConsentRequest, SUCCESS.toString(), customerConsentProperties.getAttemptCount().getMinAttemptCount(),consentId);
                        } else {
                            journeyService.recordJourneyState(journeyId, CommonJourneyStates.ONE_TRUST_API_FAILURE);
                            return saveConsent(journeyId, submitCustomerConsentRequest, FAILURE.toString(), customerConsentProperties.getAttemptCount().getMinAttemptCount(),consentId);
                        }
                    })
                    .onErrorResume(error -> {
                        log.error("Error during consent process for journeyId: {}: {}", journeyId, error.getMessage(), error);
                        journeyService.recordJourneyState(journeyId, CommonJourneyStates.ONE_TRUST_API_FAILURE);
                        log.info("saving failed consent");
                        return saveConsent(journeyId, submitCustomerConsentRequest, FAILURE.toString(), customerConsentProperties.getAttemptCount().getMinAttemptCount(),consentId);
                    });
        }
        catch (Exception e){
            String errorMessage = "Unexpected error while updating consents. JourneyId: " + journeyId;
            throw new CustomerConsentUnifyException(errorMessage, e);
        }
    }

    private boolean isConsentResponseValid(SubmitOneTrustConsentResponse response) {
        return response.getReceipt() != null;
    }

    private Mono<Long> saveConsent(String journeyId,
                                   SubmitCustomerConsentRequest consentRequest,
                                   String status,
                                   int attemptCount,
                                   String consentId) {

        return customerConsentRepository
                .findByJourneyIdAndConsentId(journeyId, consentId)
                .defaultIfEmpty(new CustomerConsentEntity())   // create new if not found
                .flatMap(existing -> {

                    if (existing.getId() == null) {
                        existing.setJourneyId(journeyId);
                        existing.setConsentId(consentId);
                    }

                    existing.setConsentRequest(consentRequest);
                    existing.setStatus(status);
                    existing.setAttemptCount(attemptCount);
                    return customerConsentRepository.save(existing)
                            .doOnSuccess(saved ->
                                    log.info("Consent UPSERT successful: {}", saved))
                            .doOnError(err ->
                                    log.error("Error during UPSERT: {}", err.getMessage()));
                })
                .thenReturn(-1L)
                .onErrorResume(e -> {
                    log.error("Error while saving consent", e);
                    throw new CustomerConsentUnifyException("Error while saving consent in db", e);
                });
    }

}
