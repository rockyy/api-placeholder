package com.hdfcbank.customerconsent.event.service;

import com.hdfcbank.customerconsent.event.infrastructure.sender.MessageSender;
import com.hdfcbank.customerconsent.event.model.CommonJourneyStates;
import com.hdfcbank.customerconsent.event.model.JourneyState;
import com.hdfcbank.customerconsent.event.model.UpdateJourneyDataRequest;
import com.hdfcbank.customerconsent.utility.TextSanityUtil;
import com.hdfcbank.customerconsent.event.properties.JourneyApiProperties;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;

@Slf4j
@Service
public class JourneyService {
    @Autowired
    private MessageSender messageSender;
    @Autowired
    private JourneyApiProperties journeyApiProperties;

    public void recordJourneyState(String journeyId, CommonJourneyStates journeyStates) {
        log.info("Recording journeyState {} for journeyId {} ", TextSanityUtil.sanitize(journeyStates.getName()), TextSanityUtil.sanitize(journeyId));
        UpdateJourneyDataRequest<Void> request = new UpdateJourneyDataRequest<>();
        JourneyState journeyState = new JourneyState(journeyStates.name(), new Date());
        request.setJourneyId(journeyId);
        request.setJourneyState(journeyState);
        messageSender.send(journeyApiProperties.getJourney().getTopic(), request);
    }
}
