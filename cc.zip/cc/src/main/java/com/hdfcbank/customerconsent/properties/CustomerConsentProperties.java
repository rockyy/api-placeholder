package com.hdfcbank.customerconsent.properties;

import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import java.util.List;
import java.util.Map;

@Getter
@Setter
@Configuration
@ConfigurationProperties("api")
public class CustomerConsentProperties {
    private AttemptCount attemptCount;
    @Getter
    @Setter
    public static class AttemptCount{
        private int minAttemptCount;
        private int maxAttemptCount;
    }

    private int failedCountLimit;

    private SubmitConsentQueue submitConsentQueue;
    @Getter
    @Setter
    public static class SubmitConsentQueue{
        private String topic;
        private String queueUrl;
    }
    private OneTrustDetails oneTrustDetails;
    @Getter
    @Setter
    public static class OneTrustDetails {
        private String serviceUrl;
    }
    private HtmlTemplate htmlTemplate;
    @Getter
    @Setter
    public static class HtmlTemplate{
        private String hyperText;
    }
    private Service service;
    @Getter
    @Setter
    public static class Service {
        private Map<String, ConsentGroup> consents;
    }

    @Getter
    @Setter
    public static class ConsentGroup {
        private String applicationName;
        private String requestInformation;
        private List<Consent> items;
    }
    @Getter
    @Setter
    public static class Consent{
        private String id;
        private String mandatory;
        private String type;
        private String hyperText;
        private String headingText;
        private String shortDescription;
        private String longDescription;
        private List<Purpose> purposes;
    }
    @Getter
    @Setter
    public static class Purpose{
        private String id;
        private String title;
        private List<Preference> preference;
    }
    @Getter
    @Setter
    public static class Preference{
        private String id;
        private String title;
        private List<Option> options;
    }
    @Getter
    @Setter
    public static class Option{
        private String id;
        private String name;
    }
}
