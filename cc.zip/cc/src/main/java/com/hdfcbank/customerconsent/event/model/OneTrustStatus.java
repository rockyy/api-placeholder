package com.hdfcbank.customerconsent.event.model;

import lombok.Getter;

@Getter
public enum OneTrustStatus {
    SUCCESS,
    FAILURE,
    COMPLETE_FAILURE
}
