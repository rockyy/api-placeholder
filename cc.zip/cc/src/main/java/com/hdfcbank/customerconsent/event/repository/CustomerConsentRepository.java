package com.hdfcbank.customerconsent.event.repository;

import com.hdfcbank.customerconsent.event.model.entity.CustomerConsentEntity;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.data.mongodb.repository.ReactiveMongoRepository;
import org.springframework.data.mongodb.repository.Update;
import org.springframework.data.repository.query.Param;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

public interface CustomerConsentRepository extends ReactiveMongoRepository<CustomerConsentEntity, String>, CustomerConsentCustomRepository {
    Flux<CustomerConsentEntity> findByStatus(String status);

    @Query("{ 'journeyId': :#{#journeyId}, 'consentId': :#{#consentId} }")
    Mono<CustomerConsentEntity> findByJourneyIdAndConsentId(
            @Param("journeyId") String journeyId, @Param("consentId") String consentId
    );

    @Query("{'journeyId': :#{#journeyId}}")
    @Update("{'$set': {" +
            "'status': :#{#status}, " +
            "'attemptCount': :#{#attemptCount}" +
            "}}")
    Mono<Long> updateConsentEntity(
            @Param("journeyId") String journeyId,
            @Param("status") String status,
            @Param("attemptCount") int attemptCount
    );

}
