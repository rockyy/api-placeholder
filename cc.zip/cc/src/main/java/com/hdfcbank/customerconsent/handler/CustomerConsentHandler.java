package com.hdfcbank.customerconsent.handler;

import com.hdfcbank.customerconsent.model.*;
import com.hdfcbank.customerconsent.service.CustomerConsentService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

@Component
@Slf4j
public class CustomerConsentHandler {
    @Autowired
    private CustomerConsentService customerConsentService;
    public Mono<JourneyConsentResponse> getJourneyConsents(JourneyConsentRequest journeyConsentRequest){
        return customerConsentService.getJourneyConsents(journeyConsentRequest.getJourneyName());
    }
    public Mono<Long> submitCustomerConsents(SubmitCustomerConsentRequest submitCustomerConsentRequest){
        return customerConsentService.submitCustomerConsents(submitCustomerConsentRequest);
    }
}
