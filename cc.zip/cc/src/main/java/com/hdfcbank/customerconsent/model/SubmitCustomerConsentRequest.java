package com.hdfcbank.customerconsent.model;


import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.NotBlank;
import lombok.*;
import lombok.experimental.SuperBuilder;

import java.util.List;

@Getter
@Setter
@SuperBuilder
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class SubmitCustomerConsentRequest {
    private String journeyId;
    private String journeyName;
    private CustomerDetail customerDetails;
    @Getter
    @Setter
    @Builder
    @ToString
    public static class CustomerDetail{
        private String pan;
        private String firstName;
        private String lastName;
        private String dateOfBirth;
        @NotBlank(message="identifier is required")
        private String identifier;
        private String identifierType;
        private List<Consent> consents;
        private String consentsCapturedDate;
    }
    @Getter
    @Setter
    @Builder
    @ToString
    public static class Consent{
        private String key;
        @JsonProperty("acceptance")
        private boolean acceptance;
    }
}


