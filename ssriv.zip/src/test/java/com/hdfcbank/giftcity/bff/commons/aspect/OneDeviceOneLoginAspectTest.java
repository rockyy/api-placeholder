package com.hdfcbank.giftcity.bff.commons.aspect;

import com.hdfcbank.giftcity.bff.commons.config.JourneyConfigProperties;
import com.hdfcbank.giftcity.bff.commons.utility.OneDeviceCacheUtility;
import com.hdfcbank.giftcity.bff.commons.utility.TextSanityUtil;
import com.hdfcbank.giftcity.bff.customer.model.IdentifyCustomerRequest;
import com.hdfcbank.giftcity.bff.infrastructure.service.JourneyService;
import org.aspectj.lang.ProceedingJoinPoint;
import org.junit.jupiter.api.*;
import org.mockito.MockedStatic;

import java.time.ZonedDateTime;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import ch.qos.logback.classic.Level;
import ch.qos.logback.classic.Logger;
import org.slf4j.LoggerFactory;

public class OneDeviceOneLoginAspectTest {

    private OneDeviceOneLoginAspect aspect;
    private OneDeviceCacheUtility cacheUtility;
    private JourneyConfigProperties journeyConfig;
    private JourneyService journeyService;
    private ProceedingJoinPoint joinPoint;
    private IdentifyCustomerRequest request;

    @BeforeAll
    static void muteAspectLogs() {
        Logger log = (Logger) LoggerFactory.getLogger(OneDeviceOneLoginAspect.class);
        log.setLevel(Level.OFF);
    }

    @BeforeEach
    void setUp() {
        aspect = new OneDeviceOneLoginAspect();
        cacheUtility = mock(OneDeviceCacheUtility.class);
        journeyConfig = mock(JourneyConfigProperties.class);
        journeyService = mock(JourneyService.class);
        joinPoint = mock(ProceedingJoinPoint.class);

        aspect.oneDeviceCacheUtility = cacheUtility;
        aspect.journeysDetail = journeyConfig;
        aspect.journeyService = journeyService;

        request = new IdentifyCustomerRequest();
        request.setMobileNo("9999999999");
        request.setIdentifierValue("1990-01-01");
    }

    // ------------------------------------------------------------------------------------------------
    //        CASE 1 — Session NOT changed → validateDevice MUST NOT run
    // ------------------------------------------------------------------------------------------------
    @Test
    void test_oneDeviceOneLogin_sessionNotChanged() throws Throwable {

        String token = "TOKEN123";

        JourneyConfigProperties.JourneyConfig cfg = new JourneyConfigProperties.JourneyConfig();
        JourneyConfigProperties.EventDetail detail = new JourneyConfigProperties.EventDetail();
        detail.setEnabled(true);
        cfg.setOneDeviceOneLogin(detail);

        when(journeyConfig.getJourneys()).thenReturn(Map.of("JOURNEY", cfg));

        OneDeviceCacheUtility.OneDeviceOneLoginDetail cached =
                new OneDeviceCacheUtility.OneDeviceOneLoginDetail(ZonedDateTime.now(), token);

        when(cacheUtility.deviceLoggedIn(any(), any(), any(), any(), any()))
                .thenReturn(cached);

        when(joinPoint.getArgs()).thenReturn(new Object[]{request, token, "JOURNEY"});
        when(joinPoint.proceed()).thenReturn("SUCCESS");

        try (MockedStatic<TextSanityUtil> san = mockStatic(TextSanityUtil.class)) {

            san.when(() -> TextSanityUtil.sanitize(anyString()))
                    .thenReturn("SANITIZED");

            Object result = aspect.oneDeviceOneLogin(joinPoint);

            //        Assertions
            assertEquals("SUCCESS", result);
            verify(cacheUtility, never()).validateDevice(any(), any(), anyString());
            verify(joinPoint).proceed();
        }
    }

    // ------------------------------------------------------------------------------------------------
    //        CASE 2 — Session changed + feature enabled → validateDevice MUST run
    // ------------------------------------------------------------------------------------------------
    @Test
    void test_oneDeviceOneLogin_sessionChanged_featureEnabled() throws Throwable {

        String oldToken = "OLD";
        String newToken = "NEW";

        JourneyConfigProperties.JourneyConfig cfg = new JourneyConfigProperties.JourneyConfig();
        JourneyConfigProperties.EventDetail detail = new JourneyConfigProperties.EventDetail();
        detail.setEnabled(true);
        cfg.setOneDeviceOneLogin(detail);

        when(journeyConfig.getJourneys()).thenReturn(Map.of("JOURNEY", cfg));

        OneDeviceCacheUtility.OneDeviceOneLoginDetail cached =
                new OneDeviceCacheUtility.OneDeviceOneLoginDetail(ZonedDateTime.now(), oldToken);

        when(cacheUtility.deviceLoggedIn(any(), any(), any(), any(), any()))
                .thenReturn(cached);

        when(joinPoint.getArgs()).thenReturn(new Object[]{request, newToken, "JOURNEY"});
        when(joinPoint.proceed()).thenReturn("SUCCESS");

        try (MockedStatic<TextSanityUtil> san = mockStatic(TextSanityUtil.class)) {

            san.when(() -> TextSanityUtil.sanitize(anyString()))
                    .thenReturn("SANITIZED");

            Object result = aspect.oneDeviceOneLogin(joinPoint);

            //        Assertions
            assertEquals("SUCCESS", result);
            verify(cacheUtility, times(1))
                    .validateDevice(any(), any(), eq(newToken));
            verify(joinPoint).proceed();
        }
    }

    // ------------------------------------------------------------------------------------------------
    //        CASE 3 — Session changed + feature disabled → validateDevice MUST NOT run
    // ------------------------------------------------------------------------------------------------
    @Test
    void test_oneDeviceOneLogin_sessionChanged_featureDisabled() throws Throwable {

        String oldToken = "OLD";
        String newToken = "NEW";

        JourneyConfigProperties.JourneyConfig cfg = new JourneyConfigProperties.JourneyConfig();
        JourneyConfigProperties.EventDetail detail = new JourneyConfigProperties.EventDetail();
        detail.setEnabled(false);
        cfg.setOneDeviceOneLogin(detail);

        when(journeyConfig.getJourneys()).thenReturn(Map.of("JOURNEY", cfg));

        OneDeviceCacheUtility.OneDeviceOneLoginDetail cached =
                new OneDeviceCacheUtility.OneDeviceOneLoginDetail(ZonedDateTime.now(), oldToken);

        when(cacheUtility.deviceLoggedIn(any(), any(), any(), any(), any()))
                .thenReturn(cached);

        when(joinPoint.getArgs()).thenReturn(new Object[]{request, newToken, "JOURNEY"});
        when(joinPoint.proceed()).thenReturn("SUCCESS");

        try (MockedStatic<TextSanityUtil> san = mockStatic(TextSanityUtil.class)) {

            san.when(() -> TextSanityUtil.sanitize(anyString()))
                    .thenReturn("SANITIZED");

            Object result = aspect.oneDeviceOneLogin(joinPoint);

            //        Assertions
            assertEquals("SUCCESS", result);
            verify(cacheUtility, never()).validateDevice(any(), any(), anyString());
            verify(joinPoint).proceed();
        }
    }
}