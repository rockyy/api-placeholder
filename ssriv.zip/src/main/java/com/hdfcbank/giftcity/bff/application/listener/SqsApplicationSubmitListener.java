package com.hdfcbank.giftcity.bff.application.listener;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.hdfcbank.common.models.vo.journey.JourneyData;
import com.hdfcbank.giftcity.bff.application.events.SqsCustomerSubmitPayload;
import com.hdfcbank.giftcity.bff.application.service.BackgroundEventPublisherService;
import com.hdfcbank.giftcity.bff.commons.enums.CommonJourneyStates;
import com.hdfcbank.giftcity.bff.commons.exception.handler.DownstreamResponseHandler;
import com.hdfcbank.giftcity.bff.commons.handler.Handler;
import com.hdfcbank.giftcity.bff.commons.handler.HandlerContext;
import com.hdfcbank.giftcity.bff.commons.handler.HandlerResult;
import com.hdfcbank.giftcity.bff.commons.handler.HandlersFactory;
import com.hdfcbank.giftcity.bff.commons.utility.MDCLoggerUtil;
import com.hdfcbank.giftcity.bff.commons.utility.TextSanityUtil;
import com.hdfcbank.giftcity.bff.infrastructure.service.JourneyService;
import io.awspring.cloud.sqs.annotation.SqsListener;
import io.awspring.cloud.sqs.listener.acknowledgement.Acknowledgement;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.messaging.handler.annotation.Headers;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import static com.hdfcbank.giftcity.bff.application.events.BackgroundEvents.*;

@Service
@Slf4j
@RequiredArgsConstructor
public class SqsApplicationSubmitListener {

    private final ObjectMapper objectMapper;
    private final JourneyService journeyService;
    private final HandlersFactory handlersFactory;
    private final BackgroundEventPublisherService backgroundEventPublisherService;

    @Value("${api.background-tasks-fifo.queueUrl}")
    private String backgroundTasksQueue;

    @SqsListener(value = "${api.submit.queueUrl}", acknowledgementMode = "MANUAL")
    public void sqsCustomerValidateListener(@Payload String requestJSON, @Headers Map<String, Object> headers, Acknowledgement acknowledgement) {
        String messageId = headers.get("MessageId") != null ? headers.get("MessageId").toString() : "UNKNOWN";
        headers.forEach((k, v) -> log.info("SqsApplicationSubmitListener headers {} = {}", k, v));
        int retryCount = headers.get("Sqs_Msa_ApproximateReceiveCount") != null ? Integer.parseInt(headers.get("Sqs_Msa_ApproximateReceiveCount").toString()) : 1;
        log.info("Received SQS message. MessageId: {}, Payload: {}, Retry Count {}", TextSanityUtil.sanitize(messageId), TextSanityUtil.sanitize(requestJSON), retryCount);
        JourneyData journeyData = null;
        try {
            SqsCustomerSubmitPayload sqsCustomerValidatePayload = objectMapper.readValue(requestJSON, SqsCustomerSubmitPayload.class);
            log.info("Test submit listener for the journey Id {}", sqsCustomerValidatePayload.getJourneyId());
            // Set data in JourneyContextHolder
            journeyData =journeyService.fetchJourney(sqsCustomerValidatePayload.getJourneyId());
            MDCLoggerUtil.populateMDC(journeyData);
            // Set comman HandlerContext for all validators!
            HandlerContext handlerContext = HandlerContext.builder()
                    .journeyData(journeyData)
                    .data(new HashMap<>())
                    .build();

            List<Handler<?>> handlerList = handlersFactory.getHandlers(journeyData.getJourneyName(),
                    Handler.HandlerType.CUSTOMER_POST_SUBMIT);

            boolean isProcessed = callHandlers(handlerList, handlerContext);
            if (isProcessed) {
                triggerBackgroundActions(sqsCustomerValidatePayload.getJourneyId(), journeyData.getProfile().getCustomerId());
                log.info("Message successfully acknowledged. MessageId: {}", messageId);
            }
            acknowledgement.acknowledge();

        } catch (JsonProcessingException e) {
            log.error("Failed to parse JSON. MessageId: {}", messageId, e);
        } catch (Exception e) {
            log.error("Unexpected error while processing message. MessageId: {}", messageId, e);
            if (retryCount > 3) {
                journeyService.updateJourneyDetailDropOff(journeyData, DownstreamResponseHandler
                                .handleResponse(null, null, false,
                                        journeyData.getJourneyName())
                        , CommonJourneyStates.SUBMIT_HANDLERS_FAILURE);
                acknowledgement.acknowledge();
            }
        }
    }

    private void triggerBackgroundActions(String journeyId, String customerId) {
        log.info("Triggering background SQS message with journey ID {} and Queue Url {}", journeyId, backgroundTasksQueue);

        /*
            Trigger all background events on fifo queue for processing
         */

        backgroundEventPublisherService.sendBackgroundEvent(journeyId, customerId, AOF_WITH_ANNEXTURE_UPLOAD, new HashMap<>());
        backgroundEventPublisherService.sendBackgroundEvent(journeyId, customerId, AOF_WITHOUT_ANNEXTURE_UPLOAD, new HashMap<>());
        backgroundEventPublisherService.sendBackgroundEvent(journeyId, customerId, DPCFTP_UPLOAD, new HashMap<>());
        backgroundEventPublisherService.sendBackgroundEvent(journeyId, customerId, FTS_ACCOUNT_OPENING, new HashMap<>());

    }
  
    private boolean callHandlers(List<Handler<?>> handlerList, HandlerContext handlerContext) {

        if (CollectionUtils.isEmpty(handlerList)) {
            return true;
        }

        String journeyId = handlerContext.getJourneyData().getJourneyId();
        for (Handler<?> handler : handlerList) {
            log.info("Handler name {} and type {}", handler.getName(), handler.getType());
            if (handler.preConditions(handlerContext)) {
                HandlerResult<?> result = handler.handle(handlerContext);
                if (result == null) {
                    continue;
                }
                handlerContext.getData().put(handler.getName(), result);
                if (result.isSuccess()) {
                    journeyService.recordJourneyState(journeyId, handler.successState());
                    handlerContext.setJourneyData(journeyService.fetchJourney(journeyId));
                } else {
                    journeyService.updateJourneyDetailDropOff(handlerContext.getJourneyData(),
                            result.getApiResponseStatus(), handler.failureState());
                    return false;
                }
            }
            else{
                log.error("Preconditions not met for : Handler name {} and type {}", handler.getName(), handler.getType());
            }
        }
        return true;
    }
}
