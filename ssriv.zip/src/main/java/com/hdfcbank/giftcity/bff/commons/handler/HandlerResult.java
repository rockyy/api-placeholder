package com.hdfcbank.giftcity.bff.commons.handler;

import com.hdfcbank.giftcity.bff.commons.enums.CommonJourneyStates;
import com.hdfcbank.giftcity.bff.commons.model.CustomValidationStatus;
import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor(staticName = "of")
public class HandlerResult<T> {
    private CustomValidationStatus apiResponseStatus;
    private T result;
    private boolean success;
}
