package com.hdfcbank.giftcity.bff.customer.validator;

import com.hdfcbank.giftcity.bff.customer.model.IdentifierType;
import com.hdfcbank.giftcity.bff.customer.model.IdentifyCustomerRequest;
import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;
import lombok.extern.slf4j.Slf4j;

import java.time.LocalDate;
import java.time.format.DateTimeParseException;

import static com.hdfcbank.giftcity.bff.commons.constant.CommonConstants.*;


@Slf4j
public class IdentifierValidator implements ConstraintValidator<ValidIdentifier, IdentifyCustomerRequest> {

    ValidIdentifier constraint;

    @Override
    public void initialize(ValidIdentifier constraintAnnotation) {
        this.constraint=constraintAnnotation;
    }

    @Override
    public boolean isValid(IdentifyCustomerRequest request, ConstraintValidatorContext context) {
        String identifierValue = request.getIdentifierValue();

        boolean  valid=true;
        if (IdentifierType.DOB.name().equals(request.getIdentifierName())) {


            if (identifierValue != null) {
                try {
                    LocalDate.parse(request.getIdentifierValue(), DATE_TIME_FORMATTER);
                    valid=true;
                }catch (DateTimeParseException e){
                  valid=false;
                }
            }
            else {

                valid = false;
            }

            if (!valid) {
                context.disableDefaultConstraintViolation();
                context.buildConstraintViolationWithTemplate(DOB_NOT_VALID)
                        .addPropertyNode(IDENTIFIER_VALUE)
                        .addConstraintViolation();
            }
            return valid;
        } else if (IdentifierType.PAN.name().equals(request.getIdentifierName())) {
            String value = identifierValue;
            valid = value.matches(PAN_PATTERN);

            if (!valid) {

                context.disableDefaultConstraintViolation();
                context.buildConstraintViolationWithTemplate(PAN_NOT_VALID)
                        .addPropertyNode(IDENTIFIER_VALUE)
                        .addConstraintViolation();
            }

            return valid;
        }
        return true;
    }
}