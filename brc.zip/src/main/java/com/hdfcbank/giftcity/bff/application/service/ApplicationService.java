package com.hdfcbank.giftcity.bff.application.service;

import com.hdfcbank.giftcity.bff.customer.model.ApplicationSubmitResponse;
import com.hdfcbank.giftcity.bff.customer.model.InquireSubmitResponse;

public interface ApplicationService {

    public ApplicationSubmitResponse applicationSubmit(String journeyId);
    public InquireSubmitResponse inquireSubmit(String journeyId);
}
