package com.hdfcbank.giftcity.bff.commons.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.hdfcbank.common.models.vo.core.ApiResponseStatus;
import com.hdfcbank.common.models.vo.core.ApiResponseStatusCodeLiteral;
import com.hdfcbank.common.models.vo.core.ErrorRef;
import lombok.*;
import lombok.experimental.SuperBuilder;

import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class CustomValidationStatus extends ApiResponseStatus implements ApiResponseStatusCodeLiteral {
    private String title;
    private String message;
    private String code;
    private String type;

    /**
     * Converts base ApiResponseStatus → CustomValidationStatus
     */
    public static CustomValidationStatus build(ApiResponseStatus responseStatus) {
        return build(
                responseStatus.getCode(),
                ErrorRef.of(responseStatus.getErrorRef()),
                null,
                responseStatus.getMessage(),
                null,
                responseStatus.getErrors()
        );
    }

    private static CustomValidationStatus build(
            String statusCode,
            ErrorRef errorRef,
            String title,
            String message,
            String type,
            List<String> errors
    ) {
        CustomValidationStatus status = new CustomValidationStatus();

        // Base fields
        status.setCode(statusCode);
        status.setMessage(message);
        status.setErrorRef(errorRef.getJourneyIdAlias());
        status.setErrors(errors);

        // Extended fields
        status.setTitle(title);
        status.setType(type);

        return status;
    }
}

