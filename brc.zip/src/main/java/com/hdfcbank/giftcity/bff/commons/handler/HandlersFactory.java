package com.hdfcbank.giftcity.bff.commons.handler;

import com.hdfcbank.giftcity.bff.commons.config.JourneyConfigProperties;
import com.hdfcbank.giftcity.bff.commons.utility.TextSanityUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Objects;
import java.util.Optional;

@Service
@Slf4j
@RequiredArgsConstructor
public class HandlersFactory {

    private final List<JourneyHandler> handlers;
    private final JourneyConfigProperties journeyConfigProperties;


    public List<JourneyHandler> getHandlers(String journeyName, Handler.HandlerType handlerType) {
        List<String> handlerNames=journeyConfigProperties.getJourneys().get(journeyName).getHandlers();

        return handlers.stream()
                .filter(Objects::nonNull)
                .filter(handler -> handler.getType().equals(handlerType))
                .filter(handler -> handlerNames.contains(handler.getName().name()))
                .toList();
    }

    public Optional<JourneyHandler> getHandlers(String journeyName, Handler.HandlerType handlerType, String handlerName) {
        log.info("Get handlers for this journey {} and type {}", TextSanityUtil.sanitize(journeyName), handlerType);
        List<String> handlerNames=journeyConfigProperties.getJourneys().get(journeyName).getHandlers();

        return handlers.stream()
                .filter(Objects::nonNull)
                .filter(handler -> handler.getType().equals(handlerType))
                .filter(handler -> handlerNames.contains(handler.getName().name()))
                .filter(handler -> handler.getName().name().equals(handlerName))
                .findAny();
    }
}
