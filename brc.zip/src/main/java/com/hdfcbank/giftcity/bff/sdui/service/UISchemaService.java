package com.hdfcbank.giftcity.bff.sdui.service;

import com.hdfcbank.common.models.vo.core.ApiResponse;
import com.hdfcbank.common.models.vo.core.ApiResponseStatus;
import com.hdfcbank.common.models.vo.core.ApiResponseStatusCode;
import com.hdfcbank.common.models.vo.core.ErrorRef;
import com.hdfcbank.exception.DownstreamApiException;
import com.hdfcbank.giftcity.bff.commons.config.SduiConfiguration;
import com.hdfcbank.giftcity.bff.commons.constant.CommonConstants;
import com.hdfcbank.giftcity.bff.commons.utility.ClaimUtil;
import com.hdfcbank.giftcity.bff.commons.utility.TextSanityUtil;
import com.hdfcbank.giftcity.bff.sdui.entity.UISchemaEntity;
import com.hdfcbank.giftcity.bff.sdui.feign.DataSourceFeignClient;
import com.hdfcbank.giftcity.bff.sdui.feign.DynamicFeignFactory;
import com.hdfcbank.giftcity.bff.sdui.model.DataSource;
import com.hdfcbank.giftcity.bff.sdui.model.DataSourceRequest;
import com.hdfcbank.giftcity.bff.sdui.model.DataSourceRequestType;
import com.hdfcbank.giftcity.bff.sdui.model.UiSchemaApiResponse;
import com.hdfcbank.giftcity.bff.sdui.repository.UISchemaRepository;
import feign.FeignException;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import tools.jackson.core.type.TypeReference;
import tools.jackson.databind.JsonNode;
import tools.jackson.databind.ObjectMapper;

import java.util.HashMap;
import java.util.List;
import java.util.Map;


@Slf4j
@Service
@AllArgsConstructor
public class UISchemaService {

    private final UISchemaRepository schemaRepository;
    private final DynamicFeignFactory dynamicFeignFactory;
    private final SduiConfiguration sduiConfiguration;
    private final ObjectMapper objectMapper;

    public UISchemaEntity getUISchemaEntity(String page, String version) {
        log.info("Fetch UISchemaEntity by Page {} and Version {}", TextSanityUtil.sanitize(page), TextSanityUtil.sanitize(version));
        return schemaRepository.findByPageAndSchemaVersion(page, version).orElse(null);
    }

    public ResponseEntity<UiSchemaApiResponse> getPageDetails(String pageId, JsonNode requestBody) {

        UISchemaEntity schemaEntity = getUISchemaEntity(pageId, sduiConfiguration.getVersion());

        if (schemaEntity == null) {
            return ResponseEntity.ok(buildNoDataResponse("Ui Schema not found"));
        }

        Map<String, JsonNode> data = fetchDataSources(schemaEntity.getDataSources(), requestBody);
        if (data.isEmpty()) {
            return ResponseEntity.ok(buildNoDataResponse("No data found"));
        }
        return ResponseEntity.ok(buildSuccessResponse(schemaEntity, data));
    }

    private Map<String, JsonNode> fetchDataSources(List<String> dataSourcesRequested, JsonNode requestBody) {

        Map<String, JsonNode> data = new HashMap<>();
        if (dataSourcesRequested == null || dataSourcesRequested.isEmpty()) {
            return data;
        }
        for (String dataSourceReq : dataSourcesRequested) {
            DataSource config = buildDataSourceRequest(dataSourceReq);
            if (config == null || config.getUrl() == null || config.getUrl().isEmpty() || config.getUrl().isBlank()) {
                continue;
            }
            JsonNode dataSourceBody = requestBody == null ? null : requestBody.path(CommonConstants.DATA_SOURCES).path(dataSourceReq);

            JsonNode response = callDataSource(config, dataSourceBody);
            if (response != null) {
                data.put(dataSourceReq, response);
            }
        }
        return data;
    }

    private JsonNode callDataSource(DataSource dataSource, JsonNode dataSourceBody) {
        log.info("Calling datasource API: {}", TextSanityUtil.sanitize(dataSource.getUrl()));
        try {
            DataSourceRequest<JsonNode> request = buildRequest(dataSourceBody);
            DataSourceFeignClient dataSourceFeignClient = dynamicFeignFactory.getClient(dataSource.getUrl(), request.getHeaders());

            ApiResponse<JsonNode> response = dataSourceFeignClient.callDataSourceAPI(request.getBody());
            return response != null ? response.getData() : null;

        } catch (FeignException e) {
            log.error("Feign error for URI {}: {}", TextSanityUtil.sanitize(dataSource.getUrl()), TextSanityUtil.sanitize(e.getMessage()), e);
            throw new DownstreamApiException(ErrorRef.downstreamApiError(), "DownStream Api error.");
        } catch (Exception e) {
            log.error("Exception during call datasource {}", TextSanityUtil.sanitize(e.getMessage()), e);
            throw new DownstreamApiException(ErrorRef.unknown(), "Unknown error.");
        }
    }

    private DataSourceRequest<JsonNode> buildRequest(JsonNode dataSourceBody) {

        DataSourceRequest<JsonNode> request = new DataSourceRequest<>();
        request.setDataSourceRequestType(DataSourceRequestType.API_CALL);
        request.setBody(objectMapper.createObjectNode());
        if (dataSourceBody == null || dataSourceBody.isNull()) {
            return request;
        }
        JsonNode bodyNode = dataSourceBody.path(CommonConstants.BODY);
        JsonNode headersNode = dataSourceBody.path(CommonConstants.HEADERS);

        if (!bodyNode.isMissingNode() && !bodyNode.isNull()) {
            request.setBody(bodyNode);
        }
        if (headersNode.isArray() && !headersNode.isEmpty()) {
            request.setHeaders(
                    objectMapper.convertValue(headersNode, new TypeReference<>() {
                    })
            );
        }
        return request;
    }

    private UiSchemaApiResponse buildSuccessResponse(UISchemaEntity schemaEntity, Map<String, JsonNode> data) {

        return UiSchemaApiResponse.builder()
                .status(new ApiResponseStatus(ApiResponseStatusCode.SUCCESS))
                .layout(ClaimUtil.convertToJsonNode(schemaEntity.getSchemaJson()))
                .data(ClaimUtil.convertToJsonNode(data))
                .build();
    }

    private UiSchemaApiResponse buildNoDataResponse(String errorMessage) {
        ApiResponseStatus apiResponseStatus = new ApiResponseStatus(ApiResponseStatusCode.INVALID_REQUEST);
        apiResponseStatus.setErrors(List.of(errorMessage));

        return UiSchemaApiResponse.builder().status(apiResponseStatus).build();
    }

    private DataSource buildDataSourceRequest(String dataSource) {
        return sduiConfiguration.getDataSources()
                .entrySet()
                .stream()
                .filter(entry -> entry.getKey().equalsIgnoreCase(dataSource))
                .map(Map.Entry::getValue)
                .findFirst()
                .orElse(null);
    }
}
