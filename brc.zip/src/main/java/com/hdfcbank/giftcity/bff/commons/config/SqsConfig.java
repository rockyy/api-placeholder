package com.hdfcbank.giftcity.bff.commons.config;

import com.hdfcbank.giftcity.bff.consent.config.AwsProperties;
import com.hdfcbank.giftcity.bff.consent.config.ConsentsApiProperties;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableAsync;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.sqs.SqsClient;

import java.net.URI;

@Configuration
@EnableAsync
public class SqsConfig {

    @Autowired
    private ConsentsApiProperties consentsApiProperties;

    @Value("${api.customer-validate.queueUrl}")
    private String customerValidateQueUrl;

    @Value("${api.submit.queueUrl}")
    private String submitQueueUrl;

    @Value("${api.background-tasks-fifo.queueUrl}")
    private String backgroundTasksQueueFifo;

    @Autowired
    private AwsProperties awsProperties;

    @Bean("customerValidate")
    public SqsClient customerValidate() {
        return SqsClient.builder()
                .region(Region.of(awsProperties.getRegion()))
                .endpointOverride(URI.create(customerValidateQueUrl))
                .build();
    }

    @Bean("applicationSubmit")
    public SqsClient applicationSubmit() {
        return SqsClient.builder()
                .region(Region.of(awsProperties.getRegion()))
                .endpointOverride(URI.create(submitQueueUrl))
                .build();
    }

    @Bean("backgroundTasksSqsClient")
    public SqsClient backgroundTasksSqsClient() {
        return SqsClient.builder()
                .region(Region.of(awsProperties.getRegion()))
                .endpointOverride(URI.create(backgroundTasksQueueFifo))
                .build();
    }

    @Bean("consentsSqsClient")
    public SqsClient sqsClient() {
        return SqsClient.builder()
                .region(Region.of(awsProperties.getRegion()))
                .endpointOverride(URI.create(consentsApiProperties.getQueueUrl()))
                .build();
    }
}