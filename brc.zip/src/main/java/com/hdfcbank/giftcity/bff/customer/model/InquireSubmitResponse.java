package com.hdfcbank.giftcity.bff.customer.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.hdfcbank.common.models.vo.core.ApiResponse;
import lombok.*;
import lombok.experimental.SuperBuilder;

@Getter
@Setter
@SuperBuilder
public class InquireSubmitResponse extends ApiResponse<InquireSubmitResponse.InquireSubmit> {

    @Getter
    @Setter
    @ToString
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class InquireSubmit {
        private InquireSubmitResponse.SubmitStatus status;
        private String applicationNumber;
    }

    public enum SubmitStatus {
        SUCCESS,
        IN_PROGRESS
    }
}
