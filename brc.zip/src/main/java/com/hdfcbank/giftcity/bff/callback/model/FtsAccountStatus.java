package com.hdfcbank.giftcity.bff.callback.model;

import lombok.AllArgsConstructor;
import lombok.Getter;


@Getter
@AllArgsConstructor
public enum FtsAccountStatus {
    SUCCESS("000", "Success"),
    REJECT("888", "Reject"),
    ORIGINALS_RECEIVED("900", "Originals Received"),
    ORIGINALS_NOT_RECEIVED("901", "Originals Not Received");

    private final String code;
    private final String description;

    public static FtsAccountStatus fromCode(String statusCode) {
        for (FtsAccountStatus status : values()) {
            if (status.code.equals(statusCode)) {
                return status;
            }
        }
        return null;
    }
}