package com.hdfcbank.giftcity.bff.commons.model;


import org.springframework.data.annotation.Id;
import lombok.Data;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "journeyData")
@Data
public class JourneyDetails {

    @Id
    private String id;

}
