package com.hdfcbank.giftcity.bff.callback.handlers;

import com.hdfcbank.common.models.vo.journey.JourneyData;
import com.hdfcbank.giftcity.bff.account.service.AccountService;
import com.hdfcbank.giftcity.bff.commons.enums.CommonJourneyStates;
import com.hdfcbank.giftcity.bff.commons.enums.JourneyPageName;
import com.hdfcbank.giftcity.bff.commons.exception.handler.DownstreamResponseHandler;
import com.hdfcbank.giftcity.bff.commons.handler.Handler;
import com.hdfcbank.giftcity.bff.commons.handler.HandlerContext;
import com.hdfcbank.giftcity.bff.commons.handler.HandlerResult;
import com.hdfcbank.giftcity.bff.commons.model.FcGcProfile;
import com.hdfcbank.giftcity.bff.commons.utility.TextSanityUtil;
import com.hdfcbank.giftcity.bff.infrastructure.service.JourneyService;
import com.hdfcbank.service.adapters.vo.account.UpdateFccAccountResponseBFF;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.Optional;

import static com.hdfcbank.giftcity.bff.commons.enums.CommonJourneyStates.*;

@Slf4j
@Service
@RequiredArgsConstructor
public class RemoveAccountFreezeHandler implements Handler<UpdateFccAccountResponseBFF> {

    private final AccountService accountService;

    @Override
    public boolean preConditions(HandlerContext handlerContext) {
        return hasJourneyState(handlerContext, FTS_SUCCESS_CALLBACK.name());
    }

    @Override
    public HandlerResult<UpdateFccAccountResponseBFF> handle(HandlerContext handlerContext) {

        log.info("inside Aof Email Handler ");
        JourneyData journeyData = handlerContext.getJourneyData();

        try {

            //Extract accountNumber from journey's GIFT_CITY_DETAIL PAGE
            Optional<String> accountNumberOpt = JourneyService.extractFromJourney(
                    journeyData,
                    JourneyPageName.CUSTOMER_FC_GIFT_CITY_DETAIL.getPageName(),
                    FcGcProfile.class,
                    FcGcProfile::getAccountNumber);

            if (accountNumberOpt.isEmpty()) {
                log.warn("Account number not found for journeyId={}", TextSanityUtil.sanitize(journeyData.getJourneyId()));
                return HandlerResult.<UpdateFccAccountResponseBFF>of(DownstreamResponseHandler
                        .handleResponse(null,
                                HandlerName.FCC_ACCOUNT_UNFREEZE.name(),
                                false, journeyData.getJourneyName()), null, false);
            }

            String accountNumber = accountNumberOpt.get();

            UpdateFccAccountResponseBFF response =
                    accountService.removeAccountFreeze(accountNumber, journeyData.getJourneyId());

            //Check if freeze removal was successful
            boolean success =
                    response.getData() != null
                            && response.getData().getTransactionStatus() != null
                            && response.getData().getTransactionStatus().isSuccess();

            if (success) {
                return HandlerResult.of(null,
                        response, true);
            }

            return HandlerResult.of(DownstreamResponseHandler
                            .handleResponse(response, HandlerName.FCC_ACCOUNT_UNFREEZE.name(),
                                    false, journeyData.getJourneyName()),
                    response, false);

        } catch (Throwable e) {
            return HandlerResult.<UpdateFccAccountResponseBFF>of(DownstreamResponseHandler
                    .handleResponse(null,
                            HandlerName.FCC_ACCOUNT_UNFREEZE.name(),
                            false, journeyData.getJourneyName()), null, false);
        }

    }

    @Override
    public HandlerType getType() {
        return HandlerType.BACKGROUND_TASKS_POST_SUBMIT_SUCCESS;
    }

    @Override
    public HandlerName getName() {
        return HandlerName.FCC_ACCOUNT_UNFREEZE;
    }

    @Override
    public CommonJourneyStates successState() {
        return FCC_ACCOUNT_UNFREEZE_SUCCESS;
    }

    @Override
    public CommonJourneyStates failureState() {
        return FCC_ACCOUNT_UNFREEZE_FAILURE;
    }

}

