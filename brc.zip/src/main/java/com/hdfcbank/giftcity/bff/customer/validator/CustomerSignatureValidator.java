package com.hdfcbank.giftcity.bff.customer.validator;

import com.hdfcbank.common.models.vo.journey.JourneyData;
import com.hdfcbank.giftcity.bff.commons.enums.CommonJourneyStates;
import com.hdfcbank.giftcity.bff.commons.enums.JourneyPageName;
import com.hdfcbank.giftcity.bff.commons.model.FcIndiaProfile;
import com.hdfcbank.giftcity.bff.commons.properties.CustomValidationProperties;
import com.hdfcbank.giftcity.bff.commons.validation.*;
import com.hdfcbank.giftcity.bff.customer.constants.CustomerConstants;
import com.hdfcbank.service.adapters.vo.customer.FetchSignatureResponse;
import com.hdfcbank.giftcity.bff.customer.service.CustomerService;
import com.hdfcbank.giftcity.bff.infrastructure.service.JourneyService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static com.hdfcbank.giftcity.bff.commons.enums.CommonJourneyStates.CUSTOMER_SIGNATURE_FETCH_FAILURE;
import static com.hdfcbank.giftcity.bff.commons.enums.CommonJourneyStates.CUSTOMER_SIGNATURE_FETCH_SUCCESS;

@Service
@RequiredArgsConstructor
public class CustomerSignatureValidator extends AbstractCommanValidator implements Validator {

    public static final String SUCCESS_CODE = "0000";
    public static final String UNKNOWN_ERROR = "9999";
    private final CustomValidationProperties customValidationProperties;
    private final CustomerService customerService;

    @Override
    public Optional<ValidationResult> validate(ValidatorContext context) {
        JourneyData journeyData = context.getJourneyData();

        if (journeyData != null) {
            FcIndiaProfile.Profile profile = JourneyService.extractFromJourney(
                    journeyData,
                    JourneyPageName.CUSTOMER_FC_INDIA_DETAIL.getPageName(),
                    FcIndiaProfile.class,
                    fcIndiaProfile -> Optional.ofNullable(fcIndiaProfile.getProfiles())
                            .filter(list -> !list.isEmpty())
                            .map(list -> list.get(0))
                            .orElse(null)
            ).orElse(null);

            FetchSignatureResponse fetchSignatureResponse = customerService.fetchSignature(profile.getCustomerId(),journeyData.getJourneyId());

            if (SUCCESS_CODE.equals(fetchSignatureResponse.getStatus().getCode()) && !fetchSignatureResponse.getData().getSignature().isEmpty()) {
                context.getData().put(ValidatorContext.ContextKey.CUSTOMER_SIGNATURE,fetchSignatureResponse.getData().getSignature());
                return Optional.of(ValidationResult.of(null, true));

            } else {
                return Optional.of(ValidationResult.of(getErrors(context.getJourneyData().getJourneyName(), fetchSignatureResponse, customValidationProperties,CUSTOMER_SIGNATURE),  false));

            }
        }
        return Optional.of(ValidationResult.of(getErrors(context.getJourneyData().getJourneyName(), null, customValidationProperties,CUSTOMER_SIGNATURE), false));

    }

    @Override
    public ValidatorType type() {
        return ValidatorType.POST_CUSTOMER_VALIDATION;
    }

    @Override
    public String name() {
       return CustomerConstants.POST_SIGNATURE_VALIDATION;
    }

    @Override
    public CommonJourneyStates successState() {
        return CUSTOMER_SIGNATURE_FETCH_SUCCESS;
    }

    @Override
    public CommonJourneyStates failureState() {
        return CUSTOMER_SIGNATURE_FETCH_FAILURE;
    }

    @Override
    public boolean isMandatory() {
        return true;
    }
}
