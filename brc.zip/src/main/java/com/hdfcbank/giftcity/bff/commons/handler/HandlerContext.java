package com.hdfcbank.giftcity.bff.commons.handler;

import com.hdfcbank.common.models.vo.journey.JourneyData;
import lombok.*;

import java.util.HashMap;
import java.util.Map;

@Getter
@Setter
@AllArgsConstructor
@Builder
@NoArgsConstructor
public class HandlerContext {

    private JourneyData journeyData;
    // The exposed map keeps HashMap's null-key and iteration behavior for existing callers.
    @SuppressWarnings("java:S1640")
    private Map<Handler.HandlerName, Object> data = new HashMap<>();
    private Map<String,Object> properties= new HashMap<>();

}
