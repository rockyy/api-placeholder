package com.hdfcbank.giftcity.bff.customer.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.*;


@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class FetchAccountDownStreamRequest {
    public boolean accountNoMask;
    public String accountType;
    public String identifierName;
    public String indentifierValue;
    public String mobileNo;
}

