package com.hdfcbank.giftcity.bff.customer.utility;

import com.hdfcbank.common.models.vo.journey.JourneyData;
import com.hdfcbank.giftcity.bff.commons.enums.CommonJourneyStates;
import com.hdfcbank.giftcity.bff.commons.exception.CustomValidationException;
import com.hdfcbank.giftcity.bff.commons.model.CustomValidationStatus;
import com.hdfcbank.giftcity.bff.commons.utility.TextSanityUtil;
import com.hdfcbank.giftcity.bff.customer.model.CustomerApiStatusCode;
import com.hdfcbank.giftcity.bff.infrastructure.service.JourneyService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.List;

@Slf4j
@Component
public class ValidationFailureHandler {
    private final JourneyService journeyService;

    public ValidationFailureHandler(JourneyService journeyService) {
        this.journeyService = journeyService;
    }

    public void dropOnValidationFailure(String journeyId,
                                        CustomerApiStatusCode code,
                                        String message, CommonJourneyStates journeyState) {

        JourneyData journeyData = journeyService.fetchJourney(journeyId);
        CustomValidationStatus customValidationStatus = CustomValidationStatus.builder()
                .title(code.getMessage())
                .code(code.getCode())
                .message(message)
                .build();
        journeyService.updateJourneyDetailDropOff(journeyData, customValidationStatus, journeyState);

        log.warn("Validation failed → dropping. JourneyId={}, Code={}, Message={}",
                TextSanityUtil.sanitize(journeyId),
                code,
                TextSanityUtil.sanitize(message));

        throw new CustomValidationException(customValidationStatus);
    }
}
