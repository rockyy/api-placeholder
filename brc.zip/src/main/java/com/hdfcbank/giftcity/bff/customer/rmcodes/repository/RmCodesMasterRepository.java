package com.hdfcbank.giftcity.bff.customer.rmcodes.repository;

import com.hdfcbank.giftcity.bff.customer.rmcodes.entity.RmCodesMasterEntity;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface RmCodesMasterRepository extends MongoRepository<RmCodesMasterEntity, String> {

    Optional<RmCodesMasterEntity> findByRmPortfolioCode(String rmPortfolioCode);

    Optional<RmCodesMasterEntity> findByEmployeeCode(String employeeCode);
}