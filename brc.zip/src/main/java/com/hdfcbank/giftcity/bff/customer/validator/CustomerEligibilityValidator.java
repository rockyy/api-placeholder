package com.hdfcbank.giftcity.bff.customer.validator;

import com.hdfcbank.common.models.vo.journey.JourneyData;
import com.hdfcbank.giftcity.bff.commons.constant.CommonConstants;
import com.hdfcbank.giftcity.bff.commons.enums.CommonJourneyStates;
import com.hdfcbank.giftcity.bff.commons.enums.JourneyPageName;
import com.hdfcbank.giftcity.bff.commons.model.FcIndiaProfile;
import com.hdfcbank.giftcity.bff.commons.properties.CustomValidationProperties;
import com.hdfcbank.giftcity.bff.commons.validation.*;
import com.hdfcbank.giftcity.bff.customer.constants.CustomerConstants;
import com.hdfcbank.giftcity.bff.infrastructure.service.JourneyService;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.*;

import static com.hdfcbank.giftcity.bff.commons.enums.CommonJourneyStates.FC_INDIA_ELIGIBILITY_FAILURE;
import static com.hdfcbank.giftcity.bff.commons.enums.CommonJourneyStates.FC_INDIA_ELIGIBILITY_SUCCESS;

@Service
@RequiredArgsConstructor
public class CustomerEligibilityValidator extends AbstractCommanValidator implements Validator {

    private final CustomValidationProperties customValidationProperties;

    @Override
    public Optional<ValidationResult> validate(ValidatorContext context) {

        JourneyData journeyData = context.getJourneyData();

        //        CHANGE #1 — Early return for null journeyData reduces nesting,
        // eliminates one IF block, lowering cognitive complexity.
        if (journeyData == null) {
            return Optional.empty();
        }

        String journeyName = journeyData.getJourneyName();

        //        CHANGE #2 — Extraction logic kept same,
        // but kept outside main method to reduce cognitive complexity.
        FcIndiaProfile.Profile profile = JourneyService.extractFromJourney(
                journeyData,
                JourneyPageName.CUSTOMER_FC_INDIA_DETAIL.getPageName(),
                FcIndiaProfile.class,
                fcIndiaProfile -> Optional.ofNullable(fcIndiaProfile.getProfiles())
                        .filter(list -> !list.isEmpty())
                        .map(list -> list.get(0))
                        .orElse(null)
        ).orElse(null);

        //        CHANGE #3 — Create list and call helper method to populate fields.
        // This moves ~40 complexity points out of validate().
        List<CustomValidationProperties.FieldDetail> fieldDetails = new ArrayList<>();
        populateEligibilityFieldDetails(fieldDetails, journeyName, profile);

        //        CHANGE #4 — remove nulls after population
        fieldDetails.removeIf(Objects::isNull);

        //        CHANGE #5 — simplified EMPTY check:
        if (fieldDetails.isEmpty()) {
            return Optional.of(ValidationResult.of(null, true));
        }

        //        CHANGE #6 — final result creation unchanged but made cleaner
        return Optional.of(
                ValidationResult.of(
                        getErrors(journeyName, fieldDetails, customValidationProperties),
                        false
                )
        );
    }

    //        CHANGE #7 — This new method extracted from original validate()
    // This massively reduces cognitive complexity inside validate().
    private void populateEligibilityFieldDetails(
            List<CustomValidationProperties.FieldDetail> fieldDetails,
            String journeyName,
            FcIndiaProfile.Profile profile) {

        //        All original validation calls preserved, no logic modifications.
        fieldDetails.add(validateData(CommonConstants.PAN_STATUS, profile.getPanStatus(), customValidationProperties, journeyName));
        fieldDetails.add(validateData(CommonConstants.REF_CUST_NUM, profile.getRefCustItNum(), customValidationProperties, journeyName));
        fieldDetails.add(validateData(CommonConstants.REF_CUST_EMAIL, profile.getRefCustEmail(), customValidationProperties, journeyName));
        fieldDetails.add(validateData(CommonConstants.KYC_STATUS, profile.getKycStatus(), customValidationProperties, journeyName));
        fieldDetails.add(validateData(CommonConstants.MEMO_SEVERITY, profile.getMemoSevrity(), customValidationProperties, journeyName));

        //        Extracted repeated null + empty check into simple ternaries
        String idDocTyp = (profile.getCustomerFATCADetails() == null || profile.getCustomerFATCADetails().isEmpty()) ?
                null : profile.getCustomerFATCADetails().get(0).getIdDocTyp();
        fieldDetails.add(validateData(CommonConstants.FACTA_COMPLIANCE, idDocTyp, customValidationProperties, journeyName));

        String datAnnexure = (profile.getCustomerFATCADetails() == null || profile.getCustomerFATCADetails().isEmpty()) ?
                null : profile.getCustomerFATCADetails().get(0).getDatAnnexure();
        fieldDetails.add(validateData(CommonConstants.FACTA_COMPLIANCE, datAnnexure, customValidationProperties, journeyName));

        String productType = profile.getCustomerAccountDetails().isEmpty() ? null :
                profile.getCustomerAccountDetails().get(0).getProductType();
        String accountStatus = profile.getCustomerAccountDetails().isEmpty() ? null :
                profile.getCustomerAccountDetails().get(0).getAccountStatus();

        fieldDetails.add(validateData(CommonConstants.ACTIVE_NRE_NRO_ACCOUNT, productType, customValidationProperties, journeyName));
        fieldDetails.add(validateData(CommonConstants.ACTIVE_NRE_NRO_ACCOUNT, accountStatus, customValidationProperties, journeyName));

        fieldDetails.add(validateForeignAddress(journeyName, profile, customValidationProperties));
        fieldDetails.add(validateData(CommonConstants.PASSPORT_NOT_AVAILABLE, idDocTyp, customValidationProperties, journeyName));

        fieldDetails.add(validatePassportExpiry(journeyName, profile, customValidationProperties));
        fieldDetails.add(validateVisaExpiry(journeyName, profile, customValidationProperties));

        //        FATCA detail extraction simplified:
        FcIndiaProfile.CustomerFATCADetail fatca =
                (profile.getCustomerFATCADetails() == null || profile.getCustomerFATCADetails().isEmpty())
                        ? new FcIndiaProfile.CustomerFATCADetail()
                        : profile.getCustomerFATCADetails().get(0);

        //        Rest unchanged:
        fieldDetails.add(validateData(CommonConstants.NATIONALITY, profile.getNationality().getCode(), customValidationProperties, journeyName));
        fieldDetails.add(validateData(CommonConstants.COUNTRY_OF_TAX_RESIDENCY, fatca.getCodTaxCntry1(), customValidationProperties, journeyName));
        fieldDetails.add(validateData(CommonConstants.TAX_ID_NUMBER, fatca.getTinNo1(), customValidationProperties, journeyName));
        fieldDetails.add(validateData(CommonConstants.TAX_ID_TYPE, fatca.getTypTinNo1(), customValidationProperties, journeyName));
        fieldDetails.add(validateData(CommonConstants.PLACE_OF_BIRTH, fatca.getNamCityBirth(), customValidationProperties, journeyName));
        fieldDetails.add(validateData(CommonConstants.COUNTRY_OF_BIRTH, fatca.getCodCntryBirth(), customValidationProperties, journeyName));
        fieldDetails.add(validateData(CommonConstants.FATHER_NAME, fatca.getNamCustFather(), customValidationProperties, journeyName));
        fieldDetails.add(validateData(CommonConstants.MOTHER_NAME, profile.getMotherMaidenName(), customValidationProperties, journeyName));
        fieldDetails.add(validateData(CommonConstants.ADDRESS_OF_TAX_PURPOSE, fatca.getAddrTaxReporting1(), customValidationProperties, journeyName));
        fieldDetails.add(validateData(CommonConstants.FULL_NAME, profile.getName(), customValidationProperties, journeyName));
        fieldDetails.add(validateData(CommonConstants.DATE_OF_BIRTH, profile.getDob(), customValidationProperties, journeyName));
        fieldDetails.add(validateData(CommonConstants.PAN, profile.getPanNumber(), customValidationProperties, journeyName));
        fieldDetails.add(validateData(CommonConstants.COMMUNICATION_ADDRESS, communicationAddress(profile), customValidationProperties, journeyName));
        fieldDetails.add(validateData(CommonConstants.PERMANENT_ADDRESS, permanentAddress(profile), customValidationProperties, journeyName));
    }

    @Override
    public ValidatorType type() {
        return ValidatorType.POST_CUSTOMER_VALIDATION;
    }

    @Override
    public String name() {
        return CustomerConstants.POST_CUSTOMER_VALIDATOR;
    }

    @Override
    public CommonJourneyStates successState() {
        return FC_INDIA_ELIGIBILITY_SUCCESS;
    }

    @Override
    public CommonJourneyStates failureState() {
        return FC_INDIA_ELIGIBILITY_FAILURE;
    }

    @Override
    public boolean isMandatory() {
        return true;
    }

    // Validation helper methods (unchanged)

    protected CustomValidationProperties.FieldDetail validateForeignAddress(String journeyName, FcIndiaProfile.Profile profile, CustomValidationProperties customValidationProperties) {

        String namCustadrCntry= profile.getNamCustadrCntry();
        String namPermadrCntry = profile.getNamPermadrCntry();

        CustomValidationProperties.FieldDetail fieldDetail = getFieldDetail(journeyName, CommonConstants.FOREIGN_ADDRESS, customValidationProperties);
        if (fieldDetail == null) {
            return null;
        }
        if (fieldDetail.isMandatory()) {

            boolean isMailingForeign = StringUtils.isNotBlank(namCustadrCntry)
                    && !CustomerConstants.INDIA.equalsIgnoreCase(namCustadrCntry.trim());

            boolean isPermanentForeign = StringUtils.isNotBlank(namPermadrCntry)
                    && !CustomerConstants.INDIA.equalsIgnoreCase(namPermadrCntry.trim());

            if (!isMailingForeign && !isPermanentForeign) {
                return fieldDetail;
            }
        }
        return null;
    }

    protected CustomValidationProperties.FieldDetail validatePassportExpiry(String journeyName, FcIndiaProfile.Profile profile, CustomValidationProperties customValidationProperties) {

        CustomValidationProperties.FieldDetail fieldDetail = getFieldDetail(journeyName, CommonConstants.PASSPORT_EXPIRY, customValidationProperties);
        String idDocExpDat = profile.getCustomerFATCADetails() == null || profile.getCustomerFATCADetails().isEmpty() ? null : profile.getCustomerFATCADetails().get(0).getIdDocExpDat();
        if (fieldDetail == null) {
            return null;
        }

        if (fieldDetail.isMandatory() && StringUtils.isEmpty(idDocExpDat)) {
            return fieldDetail;
        }
        if (idDocExpDat != null) {
            try {
                DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMdd");
                LocalDate expiryDate = LocalDate.parse(idDocExpDat, formatter);
                LocalDate thresholdDate = LocalDate.now().plusDays(Integer.parseInt(CustomerConstants.PASSPORT_DATE_EXPIRE));
                if (!expiryDate.isAfter(thresholdDate)) {
                    return fieldDetail;
                }

            } catch (DateTimeParseException e) {
                fieldDetail.setMessage("Invalid date format");
                return fieldDetail;
            }
        }
        return null;
    }

    protected CustomValidationProperties.FieldDetail validateVisaExpiry(String journeyName, FcIndiaProfile.Profile profile, CustomValidationProperties customValidationProperties) {

        CustomValidationProperties.FieldDetail fieldDetail = getFieldDetail(journeyName, CommonConstants.VISA_EXPIRY, customValidationProperties);
        String datExpiryVisa = profile.getCustomerFATCADetails() == null || profile.getCustomerFATCADetails().isEmpty() ? null : profile.getCustomerFATCADetails().get(0).getDatExpiryVisa();
        if (fieldDetail == null) {
            return null;
        }
        if (datExpiryVisa != null) {
            try {
                DateTimeFormatter formatter = DateTimeFormatter.ofPattern(CommonConstants.CASA_DATE_FORMAT);
                LocalDate expiryDate = LocalDate.parse(datExpiryVisa, formatter);
                LocalDate thresholdDate = LocalDate.now().plusDays(Integer.parseInt(CustomerConstants.PASSPORT_DATE_EXPIRE));
                if (!expiryDate.isAfter(thresholdDate)) {
                    return fieldDetail;
                }

            } catch (DateTimeParseException e) {
                fieldDetail.setMessage("Invalid date format");
                return fieldDetail;
            }
        }
        return null;
    }

    private String permanentAddress(FcIndiaProfile.Profile profile) {
        return StringUtils.trimToNull(
                String.join(" ",
                        StringUtils.defaultString(profile.getAddress()),
                        StringUtils.defaultString(profile.getCity()),
                        StringUtils.defaultString(profile.getState()),
                        profile.getCountry() != null ? StringUtils.defaultString(profile.getCountry().getDescription()) : ""
                )
        );
    }

    private String communicationAddress(FcIndiaProfile.Profile profile) {
        return StringUtils.trimToNull(
                String.join(" ",
                        StringUtils.defaultString(profile.getMailingAddress1()),
                        StringUtils.defaultString(profile.getMailingCity()),
                        StringUtils.defaultString(profile.getMailingState()),
                        profile.getMailingCountry() != null ? StringUtils.defaultString(profile.getMailingCountry().getDescription()) : "",
                        StringUtils.defaultString(profile.getMailingPinCode())
                )
        );
    }
}