package com.hdfcbank.giftcity.bff.sdui.model;

import lombok.*;

import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@ToString
public class DataSourceRequest<T> {
    private DataSourceRequestType dataSourceRequestType;
    private T body;
    private List<Header> headers;
}
