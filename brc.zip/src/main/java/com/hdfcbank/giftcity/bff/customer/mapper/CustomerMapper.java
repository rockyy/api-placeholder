package com.hdfcbank.giftcity.bff.customer.mapper;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hdfcbank.giftcity.bff.commons.utility.TextSanityUtil;
import com.hdfcbank.giftcity.bff.customer.utility.CustomerUtil;
import com.hdfcbank.service.adapters.vo.customer.FetchCasaRequest;
import com.hdfcbank.giftcity.bff.commons.constant.CommonConstants;
import com.hdfcbank.giftcity.bff.commons.utility.CommonUtil;
import com.hdfcbank.giftcity.bff.customer.config.CustomerApiProperties;
import com.hdfcbank.giftcity.bff.customer.constants.CustomerConstants;
import com.hdfcbank.giftcity.bff.customer.model.IdentifierType;
import com.hdfcbank.giftcity.bff.customer.model.IdentifyCustomerRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.hdfcbank.service.adapters.vo.customer.IdentifyGCCustomerRequest;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Component
public class CustomerMapper {

    @Autowired
    private CustomerApiProperties customerApiProperties;

    @Autowired
    private ObjectMapper objectMapper;

    public FetchCasaRequest toFetchCasaRequest(IdentifyCustomerRequest request,String journeyName) {
        return FetchCasaRequest.builder()
                .isd(request.getIsd())
                .mobileNumber(TextSanityUtil.sanitize(request.getMobileNo()))
                .dob(request.getIdentifierName().equals(IdentifierType.DOB.name())? CustomerUtil.sanitizeDob(request.getIdentifierValue()): "")
                .pan(request.getIdentifierName().equals(IdentifierType.PAN.name())? CustomerUtil.sanitizePan(request.getIdentifierValue()): "")
                .journeyName(TextSanityUtil.sanitize(journeyName))
                .build();
    }


    public IdentifyGCCustomerRequest toGcRequest(IdentifyCustomerRequest request) {

        List<IdentifyGCCustomerRequest.CustomerParam> params = new ArrayList<>();
        params.add(new IdentifyGCCustomerRequest.CustomerParam(CustomerConstants.MOBILE_NO, request.getFullMobileNumber()));

        if (IdentifierType.DOB.name().equals(request.getIdentifierName())) {
            params.add(new IdentifyGCCustomerRequest.CustomerParam(CustomerConstants.DOB, CommonUtil.formatDob(request.getIdentifierValue())));
        } else if (IdentifierType.PAN.name().equals(request.getIdentifierName())) {
            params.add(new IdentifyGCCustomerRequest.CustomerParam(CustomerConstants.PAN, TextSanityUtil.sanitize(request.getIdentifierValue())));
        }

        IdentifyGCCustomerRequest gcRequest = new IdentifyGCCustomerRequest();
        gcRequest.setCustParams(params);
        return gcRequest;
    }
}
