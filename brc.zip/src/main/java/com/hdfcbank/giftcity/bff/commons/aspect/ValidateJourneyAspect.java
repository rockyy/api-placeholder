package com.hdfcbank.giftcity.bff.commons.aspect;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hdfcbank.adapters.clients.feign.journey.JourneyServiceFeignClient;
import com.hdfcbank.common.models.constant.RequestHeaders;
import com.hdfcbank.common.models.vo.core.ErrorRef;
import com.hdfcbank.common.models.vo.journey.JourneyData;
import com.hdfcbank.common.models.vo.journey.JourneyState;
import com.hdfcbank.exception.BusinessValidationException;
import com.hdfcbank.giftcity.bff.commons.annotation.ValidateJourney;
import com.hdfcbank.giftcity.bff.commons.config.JourneyContextHolder;
import com.hdfcbank.giftcity.bff.commons.constant.CommonConstants;
import com.hdfcbank.giftcity.bff.commons.enums.CommonJourneyStates;
import com.hdfcbank.giftcity.bff.commons.enums.CustomCommonApiStatusCodes;
import com.hdfcbank.giftcity.bff.commons.exception.CustomValidationException;
import com.hdfcbank.giftcity.bff.commons.model.CustomValidationStatus;
import com.hdfcbank.giftcity.bff.commons.properties.CustomValidationProperties;
import com.hdfcbank.giftcity.bff.commons.utility.TextSanityUtil;
import com.hdfcbank.giftcity.bff.infrastructure.service.JourneyService;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import java.util.*;

@Aspect
@Component
@RequiredArgsConstructor
@Slf4j
public class ValidateJourneyAspect {

    private final JourneyServiceFeignClient journeyService;
    private final CustomValidationProperties customValidationProperties;
    private final ObjectMapper objectMapper;

    @Before("@annotation(com.hdfcbank.giftcity.bff.commons.annotation.ValidateJourney)")
    public void validateJourney(JoinPoint joinPoint) {
        MethodSignature signature = (MethodSignature) joinPoint.getSignature();
        ValidateJourney validateJourney = signature.getMethod().getAnnotation(ValidateJourney.class);
        String journeyId = extractJourneyIdFromHeader();
        log.info("Journey Id is :: {}", TextSanityUtil.sanitize(journeyId));

        JourneyData journeyData = journeyService.fetch(journeyId);
        if (journeyData == null) {
            throw new BusinessValidationException(
                    ErrorRef.of(CustomCommonApiStatusCodes.JOURNEY_DETAILS_NOT_FOUND.getCode()),
                    CustomCommonApiStatusCodes.JOURNEY_DETAILS_NOT_FOUND.getMessage());
        }

        List<String> journeyStates = journeyData.getJourneyDetail()
                .getJourneyStates()
                .stream()
                .map(JourneyState::getStateName)
                .toList();

        checkDropOffState(journeyData, journeyStates, validateJourney.successStates());
        validateJourneyState(journeyStates, validateJourney, journeyId);
        JourneyContextHolder.setJourneyData(journeyData);
    }

    /**
     * **REFACTORED METHOD TO REDUCE COGNITIVE COMPLEXITY**
     * Extracted helper methods:
     * - isSuccessState()
     * - getCustomValidations()
     * - hasDropOffState()
     * - getDropOffObject()
     * - handleDropOffObject()
     * - handleMissingDropOff()
     * - extractCustomValidationStatus()
     */
    private void checkDropOffState(
            JourneyData journeyData,
            List<String> journeyStates,
            CommonJourneyStates[] commonJourneyStates) {

        // Extracted success state logic
        if (isSuccessState(commonJourneyStates, journeyStates)) {
            return;
        }

        // Extracted custom validation fetch logic
        CustomValidationProperties.CustomValidations customValidations =
                getCustomValidations(journeyData);

        if (customValidations == null || customValidations.getDropOffStates() == null) {
            return;
        }

        Set<String> dropOffStateSet = new HashSet<>(customValidations.getDropOffStates());

        // Extracted journey state check
        if (!hasDropOffState(journeyStates, dropOffStateSet)) {
            return;
        }

        if (journeyData.getJourneyDetail() == null ||
                journeyData.getJourneyDetail().getSystemData() == null) {
            return;
        }

        // Extracted dropOff lookup logic
        Object dropOff = getDropOffObject(journeyData);

        if (dropOff != null) {
            handleDropOffObject(dropOff); // Extracted handling
        } else {
            handleMissingDropOff(journeyData, journeyStates, dropOffStateSet); // Extracted handling
        }
    }

    // NEW REFACTORED METHOD — reduces early nested complexity
    private boolean isSuccessState(CommonJourneyStates[] states, List<String> journeyStates) {
        List<String> successStates = Arrays.stream(states)
                .map(CommonJourneyStates::getEnumName)
                .toList();

        return !successStates.isEmpty() && journeyStates.containsAll(successStates);
    }

    // NEW REFACTORED METHOD — isolates validation fetching
    private CustomValidationProperties.CustomValidations getCustomValidations(JourneyData journeyData) {
        return Optional.ofNullable(customValidationProperties.getJourneys())
                .map(j -> j.get(journeyData.getJourneyName()))
                .orElse(null);
    }

    // NEW REFACTORED METHOD — isolates drop-off-state check
    private boolean hasDropOffState(List<String> journeyStates, Set<String> dropOffStateSet) {
        return journeyStates.stream().anyMatch(dropOffStateSet::contains);
    }

    // NEW REFACTORED METHOD — isolates dropOff object extraction
    private Object getDropOffObject(JourneyData journeyData) {
        Map<String, Map<String, ?>> systemData = journeyData.getJourneyDetail().getSystemData();
        return JourneyService.getByPath(
                systemData,
                CommonConstants.JOURNEY_STATUS_DETAIL + "." + CommonConstants.JOURNEY_DROP_OFF);
    }

    // NEW REFACTORED METHOD — isolates conversion logic
    private void handleDropOffObject(Object dropOff) {
        CustomValidationStatus customValidationStatus = extractCustomValidationStatus(dropOff);
        if (customValidationStatus != null) {
            throw new CustomValidationException(customValidationStatus);
        }
    }

    // NEW REFACTORED METHOD — isolates missing dropOff fallback
    private void handleMissingDropOff(
            JourneyData journeyData,
            List<String> journeyStates,
            Set<String> dropOffStateSet) {

        Optional<String> matchingState = journeyStates.stream()
                .filter(dropOffStateSet::contains)
                .findFirst();

        if (matchingState.isPresent()) {
            log.error("Required journey {} is in failed state for journeyId: {}",
                    matchingState.get(), journeyData.getJourneyId());
            stateFailedException(matchingState.get());
        }
    }

    // NEW REFACTORED METHOD — isolates object-to-status conversion
    private CustomValidationStatus extractCustomValidationStatus(Object dropOff) {

        if (dropOff instanceof List<?> dropOffList) {
            if (dropOffList.isEmpty()) {
                return null;
            }
            Object lastDropOff = dropOffList.get(dropOffList.size() - 1);
            return objectMapper.convertValue(lastDropOff, CustomValidationStatus.class);
        }

        return objectMapper.convertValue(dropOff, CustomValidationStatus.class);
    }

    private void validateJourneyState(List<String> journeyStates, ValidateJourney validateJourney, String journeyId) {

        for (CommonJourneyStates state : validateJourney.shouldExists()) {
            if (!journeyStates.contains(state.name())) {
                log.error("Required journey state missing for journeyId: {}", TextSanityUtil.sanitize(journeyId));
                stateNotMaintainedException();
            }
        }

        for (CommonJourneyStates state : validateJourney.shouldNotExists()) {
            if (journeyStates.contains(state.name())) {
                log.error("Journey state should not be present for journeyId: {}", TextSanityUtil.sanitize(journeyId));
                stateNotMaintainedException();
            }
        }

        if (validateJourney.hasAny().length > 0) {
            boolean foundAny = Arrays.stream(validateJourney.hasAny())
                    .map(CommonJourneyStates::name)
                    .anyMatch(journeyStates::contains);

            if (!foundAny) {
                log.error("None of the expected states are present for journeyId: {}. Expected any of: {}",
                        TextSanityUtil.sanitize(journeyId), Arrays.toString(validateJourney.hasAny()));
                stateNotMaintainedException();
            }
        }
    }

    private void stateNotMaintainedException() {
        throw new BusinessValidationException(
                ErrorRef.of(CustomCommonApiStatusCodes
                        .JOURNEY_STATE_NOT_MAINTAINED.getCode()),
                CustomCommonApiStatusCodes
                        .JOURNEY_STATE_NOT_MAINTAINED.getMessage());
    }

    private void stateFailedException(String failedState) {
        throw new BusinessValidationException(
                ErrorRef.of(CustomCommonApiStatusCodes
                        .JOURNEY_STATE_FAILED.getCode()),
                String.format(CustomCommonApiStatusCodes
                        .JOURNEY_STATE_FAILED.getMessage(), failedState));
    }

    @After("@annotation(com.hdfcbank.giftcity.bff.commons.annotation.ValidateJourney)")
    public void clearJourneyContext() {
        JourneyContextHolder.clear();
    }

    private String extractJourneyIdFromHeader() {
        ServletRequestAttributes attributes = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
        if (attributes == null) {
            log.error("RequestAttributes is null — cannot extract header");
            return null;
        }
        HttpServletRequest request = attributes.getRequest();
        return request.getHeader(RequestHeaders.JOURNEY_ID);
    }
}