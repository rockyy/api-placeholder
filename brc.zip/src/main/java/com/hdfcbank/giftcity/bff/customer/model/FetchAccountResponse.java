package com.hdfcbank.giftcity.bff.customer.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.hdfcbank.common.models.vo.core.ApiResponse;
import lombok.*;
import lombok.experimental.SuperBuilder;

import java.util.List;

@Getter
@Setter
@SuperBuilder
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class FetchAccountResponse extends ApiResponse<FetchAccountResponse.FetchAccountDetails> {



    @Getter
    @Setter
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class FetchAccountDetails {
       private List<AccountResponse> accounts;

    }
}
