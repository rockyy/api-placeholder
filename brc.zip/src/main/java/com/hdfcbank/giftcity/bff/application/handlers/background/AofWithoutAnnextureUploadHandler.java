package com.hdfcbank.giftcity.bff.application.handlers.background;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hdfcbank.adapters.vo.DocumentSecurity;
import com.hdfcbank.adapters.vo.DocumentUploadedResponse;
import com.hdfcbank.adapters.vo.GenerateDocumentRequest;
import com.hdfcbank.common.models.vo.core.ApiResponse;
import com.hdfcbank.common.models.vo.journey.JourneyData;
import com.hdfcbank.giftcity.bff.commons.enums.CommonJourneyStates;
import com.hdfcbank.giftcity.bff.commons.exception.handler.DownstreamResponseHandler;
import com.hdfcbank.giftcity.bff.commons.handler.Handler;
import com.hdfcbank.giftcity.bff.commons.handler.HandlerContext;
import com.hdfcbank.giftcity.bff.commons.handler.HandlerResult;
import com.hdfcbank.giftcity.bff.commons.model.FtsDetails;
import com.hdfcbank.giftcity.bff.customer.config.CustomerApiProperties;
import com.hdfcbank.giftcity.bff.customer.mapper.AofDocumentMapper;
import com.hdfcbank.giftcity.bff.customer.model.AofWithAnnextureData;
import com.hdfcbank.giftcity.bff.infrastructure.service.JourneyService;
import com.hdfcbank.adapters.clients.feign.document.DocumentFeignClient;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Service;

import static com.hdfcbank.giftcity.bff.commons.enums.CommonJourneyStates.*;
import static com.hdfcbank.giftcity.bff.commons.enums.JourneyPageName.FTS_DETAILS;


@Slf4j
@Service
@RequiredArgsConstructor
@Order(5)
public class AofWithoutAnnextureUploadHandler implements Handler<DocumentUploadedResponse> {

    private final DocumentFeignClient documentFeignClient;
    private final AofDocumentMapper mapper;
    private final JourneyService journeyService;
    private final CustomerApiProperties customerApiProperties;

    private static final String SUCCESS = "0000";

    @Override
    public boolean preConditions(HandlerContext handlerContext) {
        return hasJourneyState(handlerContext, CommonJourneyStates.CREATE_FCC_CUSTOMER_SIGNATURE_SUCCESS.name());
    }

    @Override
    public HandlerResult<DocumentUploadedResponse> handle(HandlerContext handlerContext) {

        JourneyData journeyData = handlerContext.getJourneyData();
        try {

            log.info("Background handler triggered {}, for journeyId={}", getName(), journeyData.getJourneyId());

            String branchName = customerApiProperties.getAofDetails().getBranchName();
            String branchCode = customerApiProperties.getAofDetails().getBranchCode();
            String productCode = customerApiProperties.getAofDetails().getProductCode();


            GenerateDocumentRequest<AofWithAnnextureData> aofOnlyRequest = mapper.toRequestAofOnly(journeyData, branchName, branchCode, productCode);
            aofOnlyRequest.setDocumentSecurity(new DocumentSecurity(true));

            ApiResponse<DocumentUploadedResponse> aofOnlyResponse =
                    documentFeignClient.fetchGenerateAndUploadResponse(
                            journeyData.getJourneyId(),
                            journeyData.getJourneyName(),
                            aofOnlyRequest
                    );

            boolean aofOnlySuccess = aofOnlyResponse.getStatus() != null && SUCCESS.equals(aofOnlyResponse.getStatus().getCode());

            if (!aofOnlySuccess) {
                log.error("AOF ONLY failed code={} errors={}", aofOnlyResponse.getStatus().getCode(), aofOnlyResponse.getStatus().getErrors());

                return HandlerResult.of(
                        DownstreamResponseHandler.handleResponse(
                                aofOnlyResponse,
                                HandlerName.AOF_WITHOUT_ANNEXTURE_UPLOAD.name(),
                                false,
                                journeyData.getJourneyName()
                        ),
                        aofOnlyResponse.getData(),
                        false
                );
            }

            log.info("AOF ONLY docRef={}", aofOnlyResponse.getData().getDocRef());

            FtsDetails ftsDetails = JourneyService.extractFromJourney(journeyData, FTS_DETAILS.getPageName(), FTS_DETAILS.getPageClassName(), x -> (FtsDetails)x).orElse(new FtsDetails());
            ftsDetails.setAofWithoutAnnextureDocRef(aofOnlyResponse.getData().getDocRef());

            journeyService.updateJourney(journeyData.getJourneyId(), FTS_DETAILS.getPageName(), ftsDetails, CommonJourneyStates.AOF_WITHOUT_ANNEXTURE_UPLOAD_SUCCESS);

            return HandlerResult.of(null, aofOnlyResponse.getData(), true);


        } catch (Throwable e) {
            log.error("Exception while calling documentServiceFeignClient service", e);
            return HandlerResult.of(DownstreamResponseHandler.handleResponse(null, HandlerName.AOF_WITHOUT_ANNEXTURE_UPLOAD.name(), false,
                    journeyData.getJourneyName()), null, false);
        }

    }

    @Override
    public HandlerType getType() {
        return HandlerType.BACKGROUND_TASKS_POST_SUBMIT_SUCCESS;
    }

    @Override
    public HandlerName getName() {
        return HandlerName.AOF_WITHOUT_ANNEXTURE_UPLOAD;
    }

    @Override
    public CommonJourneyStates successState() {
        return AOF_WITHOUT_ANNEXTURE_UPLOAD_SUCCESS;
    }

    @Override
    public CommonJourneyStates failureState() {
        return AOF_WITHOUT_ANNEXTURE_UPLOAD_FAILURE;
    }
}
