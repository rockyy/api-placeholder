package com.hdfcbank.giftcity.bff.commons.validation;

import com.hdfcbank.common.models.vo.journey.JourneyData;
import lombok.*;

import java.util.HashMap;
import java.util.Map;

@Getter
@Setter
@AllArgsConstructor
@Builder
@NoArgsConstructor
public class ValidatorContext {

    private JourneyData journeyData;
    // The exposed map keeps HashMap's null-key and iteration behavior for existing callers.
    @SuppressWarnings("java:S1640")
    private Map<ContextKey, Object> data = new HashMap<>();

    public enum ContextKey {
        CUSTOMER_SIGNATURE,
        CKYC_DETAILS,
        UCIC_DETAILS,
    }
}
