package com.hdfcbank.giftcity.bff.callback.model;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class FtsStatusCallbackRequest {

    @NotBlank(message = "barCode is mandatory")
    @Size(max = 50, message = "barCode must not exceed 50 characters")
    private String barCode;

    @Valid
    @NotNull(message = "status is mandatory")
    private Status status;

    @Getter
    @Setter
    @ToString
    public static class Status {

        @NotBlank(message = "status.code is mandatory")
        @Pattern(
                regexp = "^(000|888|900|901)$",
                message = "status.code must be one of: 000, 888, 900, 901"
        )
        private String code;

        @NotBlank(message = "status.desc is mandatory")
        @Size(max = 50, message = "status.desc must not exceed 50 characters")
        private String desc;
    }
}