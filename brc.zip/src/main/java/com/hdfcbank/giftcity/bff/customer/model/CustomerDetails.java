package com.hdfcbank.giftcity.bff.customer.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.*;
import lombok.experimental.SuperBuilder;

import java.time.LocalDate;
import java.util.List;

@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor
@SuperBuilder
public class CustomerDetails {

    private CustomerProfile customerProfile;
    private FatcaDetails fatcaDetails;
    private EmploymentFinancial employmentFinancial;
    private FinancialProducts financialProducts;


    @Getter
    @Setter
    @ToString
    @AllArgsConstructor
    @NoArgsConstructor
    @Builder
    public static class CustomerProfile {
        private String fullName;
        private String gender;
        private String dob;
        private String email;
        private String panNumber;
        private String mobileNumber;
        private String title;
        private String communicationAddress;
        private String permanentAddress;

    }

    @Getter
    @Setter
    @ToString
    @AllArgsConstructor
    @NoArgsConstructor
    @Builder
    public static class CustomerAddress {
        @JsonInclude(JsonInclude.Include.NON_NULL)
        private String type;
        private String address1;
        private String address2;
        private String city;
        private String state;
        private String pinCode;

    }

    @Getter
    @Setter
    @ToString
    @AllArgsConstructor
    @NoArgsConstructor
    @Builder
    public static class FatcaDetails {

        private String nationality;
        private TaxResidency taxResidency;
        private TaxResidency taxResidency2;
        private TaxResidency taxResidency3;
        private String placeOfBirth;
        private String countryOfBirth;
        private String fatherName;
        private String motherName;
        private String addressForTaxPurpose;
        private MaritalStatus maritalStatus;
        private String spouseName;
        private ResidentialType residenceType;

    }

    @Getter
    @Setter
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class EmploymentFinancial {

        private String pep;
        private Qualification qualification;
        private String occupation;
        private String workExperience;
        private String industry;
        private String industryVariation;
        private String employerBusinessName;
        private String designation;
        private String specialisation;
        private String annualIncome;
        private String netWorth;
        private String sourceOfIncome;
        private String employerAddress1;
        private String employerAddress2;
        private String employerAddress3;
        private String employerAddress4;
        private String employerPinCode;
        private String purposeOfAccount;
        private String currency;
        private String monthlyTransactions;
        private String monthlyAmount;
        @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
        private LocalDate employedSince;
    }

    @Getter
    @Setter
    @ToString
    @AllArgsConstructor
    @NoArgsConstructor
    @Builder
    public static class TaxResidency {
        private String countryOfTaxResidency;
        private String taxIdNumber;
        private String taxIdType;
    }

    @Getter
    @Setter
    @ToString
    @AllArgsConstructor
    @NoArgsConstructor
    @Builder
    public static class FinancialProducts {
        private List<String> products;
    }

    @Getter
    @Setter
    @ToString
    @AllArgsConstructor
    @NoArgsConstructor
    @Builder
    public static class MaritalStatus {
        private String key;
        private String id;
        private String status;
    }

    @Getter
    @Setter
    @ToString
    @AllArgsConstructor
    @NoArgsConstructor
    @Builder
    public static class ResidentialType {
        private String key;
        private String id;
        private String type;
    }

    @Getter
    @Setter
    @ToString
    @AllArgsConstructor
    @NoArgsConstructor
    @Builder
    public static class Qualification {
        private String key;
        private String id;
        private String type;
    }
}
