package com.hdfcbank.giftcity.bff.account.controller;

import com.hdfcbank.service.adapters.vo.account.CreateCustomerAccountResponse;
import com.hdfcbank.giftcity.bff.account.model.NomineeResponse;
import com.hdfcbank.giftcity.bff.account.service.AccountService;
import com.hdfcbank.giftcity.bff.commons.annotation.ValidateJourney;
import com.hdfcbank.starter.logging.annotations.JourneyId;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import static com.hdfcbank.giftcity.bff.commons.enums.CommonJourneyStates.FACTIVA_ELIGIBLE_SUCCESS;
import static com.hdfcbank.giftcity.bff.commons.enums.CommonJourneyStates.OTP_GENERATE_SUCCESS;

@RestController
@RequestMapping("/api/v1/gcbff/accounts")
@RequiredArgsConstructor
public class AccountController {

    private final AccountService accountService;

    @ValidateJourney(shouldExists = {OTP_GENERATE_SUCCESS,FACTIVA_ELIGIBLE_SUCCESS})
    @PostMapping("/nominee")
    public ResponseEntity<NomineeResponse> getNominee(@JourneyId String journeyId) {
        return ResponseEntity.ok(accountService.getNominee(journeyId));
    }

}

