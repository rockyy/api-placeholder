package com.hdfcbank.giftcity.bff.customer.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.hdfcbank.common.models.vo.core.ApiResponse;
import lombok.*;
import lombok.experimental.SuperBuilder;

import java.util.List;

@Getter
@SuperBuilder
public class IdentifyCustomerResponse extends ApiResponse<IdentifyCustomerResponse.IdentifyCustomerDetail> {

    @Getter
    @Setter
    @ToString
    @SuperBuilder
    @NoArgsConstructor
    @AllArgsConstructor
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class IdentifyCustomerDetail {
        private String txnRef;
        private String journeyId;
        private String correlationId;
        private boolean existingCustomer;
        private Integer retryOtpAttemptsConsumed;
        private Integer retryOtpAttemptsLeft;
        private Integer verifyOtpAttemptsConsumed;
        private Integer verifyOtpAttemptsLeft;
        private Integer eligibleAccounts;
        private CustomerProfileResponse.CustomerProfile profile;
    }
}

