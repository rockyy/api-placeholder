package com.hdfcbank.giftcity.bff.application.handlers.background;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hdfcbank.adapters.vo.DocumentUploadedResponse;
import com.hdfcbank.adapters.vo.GenerateDocumentRequest;
import com.hdfcbank.common.models.vo.core.ApiResponse;
import com.hdfcbank.common.models.vo.journey.JourneyData;
import com.hdfcbank.giftcity.bff.commons.enums.CommonJourneyStates;
import com.hdfcbank.giftcity.bff.commons.exception.handler.DownstreamResponseHandler;
import com.hdfcbank.giftcity.bff.commons.handler.Handler;
import com.hdfcbank.giftcity.bff.commons.handler.HandlerContext;
import com.hdfcbank.giftcity.bff.commons.handler.HandlerResult;
import com.hdfcbank.giftcity.bff.commons.model.FtsDetails;
import com.hdfcbank.giftcity.bff.customer.config.CustomerApiProperties;
import com.hdfcbank.giftcity.bff.customer.mapper.AofDocumentMapper;
import com.hdfcbank.giftcity.bff.customer.model.AofWithAnnextureData;
import com.hdfcbank.giftcity.bff.infrastructure.service.JourneyService;
import com.hdfcbank.adapters.clients.feign.document.DocumentFeignClient;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Service;

import static com.hdfcbank.giftcity.bff.commons.enums.CommonJourneyStates.*;
import static com.hdfcbank.giftcity.bff.commons.enums.JourneyPageName.FTS_DETAILS;


@Slf4j
@Service
@RequiredArgsConstructor
@Order(4)
public class AofWithAnnextureUploadHandler implements Handler<DocumentUploadedResponse> {

    private final DocumentFeignClient documentFeignClient;
    private final AofDocumentMapper mapper;
    private final JourneyService journeyService;
    private final CustomerApiProperties customerApiProperties;

    private static final String SUCCESS = "0000";

    @Override
    public boolean preConditions(HandlerContext handlerContext) {
        return hasJourneyState(handlerContext, CommonJourneyStates.CREATE_FCC_CUSTOMER_SIGNATURE_SUCCESS.name());
    }

    @Override
    public HandlerResult<DocumentUploadedResponse> handle(HandlerContext handlerContext) {

        JourneyData journeyData = handlerContext.getJourneyData();
        try {

            log.info("Background handler triggered {}, for journeyId={}", getName(), journeyData.getJourneyId());

            String branchName = customerApiProperties.getAofDetails().getBranchName();
            String branchCode = customerApiProperties.getAofDetails().getBranchCode();
            String productCode = customerApiProperties.getAofDetails().getProductCode();

            GenerateDocumentRequest<AofWithAnnextureData> aofWithCraRequest = mapper.toRequestWithCra(journeyData, branchName, branchCode, productCode);


            ApiResponse<DocumentUploadedResponse> aofCraResponse =
                    documentFeignClient.fetchGenerateAndUploadResponse(
                            journeyData.getJourneyId(),
                            journeyData.getJourneyName(),
                            aofWithCraRequest
                    );

            boolean aofCraSuccess = aofCraResponse.getStatus() != null && SUCCESS.equals(aofCraResponse.getStatus().getCode());

            if (!aofCraSuccess) {
                log.error("AOF+CRA failed code={} errors={}", aofCraResponse.getStatus().getCode(), aofCraResponse.getStatus().getErrors());

                return HandlerResult.of(
                        DownstreamResponseHandler.handleResponse(
                                aofCraResponse,
                                HandlerName.AOF_WITH_ANNEXTURE_UPLOAD.name(),
                                false,
                                journeyData.getJourneyName()
                        ),
                        aofCraResponse.getData(),
                        false
                );
            }

            log.info("AOF+CRA docRef={}", aofCraResponse.getData().getDocRef());

            FtsDetails ftsDetails = JourneyService.extractFromJourney(
                    journeyData,
                    FTS_DETAILS.getPageName(),
                    FTS_DETAILS.getPageClassName(),
                    AofWithAnnextureUploadHandler::castToFtsDetails
            ).orElse(new FtsDetails());

            ftsDetails.setAofWithAnnextureDocRef(aofCraResponse.getData().getDocRef());

            journeyService.updateJourney(journeyData.getJourneyId(), FTS_DETAILS.getPageName(), ftsDetails, CommonJourneyStates.AOF_WITH_ANNEXTURE_UPLOAD_SUCCESS);

            return HandlerResult.of(null, aofCraResponse.getData(), true);


        } catch (Throwable e) {
            log.error("Exception while calling documentServiceFeignClient service", e);
            return HandlerResult.<DocumentUploadedResponse>of(DownstreamResponseHandler.handleResponse(null, HandlerName.AOF_WITH_ANNEXTURE_UPLOAD.name(), false,
                    journeyData.getJourneyName()), null, false);
        }

    }

    private static FtsDetails castToFtsDetails(Object value) {
        return (FtsDetails) value;
    }

    @Override
    public HandlerType getType() {
        return HandlerType.BACKGROUND_TASKS_POST_SUBMIT_SUCCESS;
    }

    @Override
    public HandlerName getName() {
        return HandlerName.AOF_WITH_ANNEXTURE_UPLOAD;
    }

    @Override
    public CommonJourneyStates successState() {
        return AOF_WITH_ANNEXTURE_UPLOAD_SUCCESS;
    }

    @Override
    public CommonJourneyStates failureState() {
        return AOF_WITH_ANNEXTURE_UPLOAD_FAILURE;
    }
}
