package com.hdfcbank.giftcity.bff.consent.config;

import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Getter
@Setter
@Configuration
@ConfigurationProperties("service.aws")
public class AwsProperties {
    private String region;
}
