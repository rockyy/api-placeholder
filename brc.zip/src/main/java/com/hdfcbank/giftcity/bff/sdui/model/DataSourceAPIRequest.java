package com.hdfcbank.giftcity.bff.sdui.model;

import lombok.*;

@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class DataSourceAPIRequest {

    private String journeyId;
}
