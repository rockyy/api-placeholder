package com.hdfcbank.giftcity.bff.customer.rmcodes.service;

import com.hdfcbank.giftcity.bff.customer.rmcodes.entity.RmCodesMasterEntity;
import com.hdfcbank.giftcity.bff.customer.rmcodes.repository.RmCodesMasterRepository;
import com.hdfcbank.service.adapters.clients.feign.customer.CustomerServiceFeignClient;
import com.hdfcbank.service.adapters.vo.customer.RmDetailsResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Function;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class RmCodesMasterService {

    private final RmCodesMasterRepository rmCodesMasterRepository;
    private final CustomerServiceFeignClient customerServiceFeignClient;

    public void saveOrUpdateRmCodes() {

        List<RmCodesMasterEntity> entityList = Optional
                .ofNullable(customerServiceFeignClient.fetchRmDetails())
                .map(RmDetailsResponse::getData)
                .map(RmDetailsResponse::getResponseString)
                .map(RmDetailsResponse.ResponseString::getRmDetails)
                .orElse(Collections.emptyList())
                .stream()
                .map(rm -> RmCodesMasterEntity.builder()
                        .employeeCode(rm.getEmployeeCode())
                        .rmPortfolioCode(rm.getRmPortfolioCode())
                        .employeeName(rm.getEmployeeName())
                        .build())
                .toList();

        if (entityList.isEmpty()) {
            log.info("No RM codes received from downstream");
            return;
        }

        // Log duplicate employee codes received from downstream
        Map<String, Long> duplicateEmployeeCodes = entityList.stream()
                .collect(Collectors.groupingBy(
                        RmCodesMasterEntity::getEmployeeCode,
                        Collectors.counting()))
                .entrySet()
                .stream()
                .filter(entry -> entry.getValue() > 1)
                .collect(Collectors.toMap(
                        Map.Entry::getKey,
                        Map.Entry::getValue));

        if (!duplicateEmployeeCodes.isEmpty()) {
            log.warn("Duplicate employee codes received from downstream: {}", duplicateEmployeeCodes);
        }

        // Remove duplicates (keep latest occurrence)
        entityList = entityList.stream()
                .collect(Collectors.toMap(
                        RmCodesMasterEntity::getEmployeeCode,
                        Function.identity(),
                        (e1, e2) -> e2))
                .values()
                .stream()
                .toList();

        try {
            log.info("Deleting existing RM codes. Existing records will be refreshed.");

            rmCodesMasterRepository.deleteAll();
            rmCodesMasterRepository.saveAll(entityList);

            log.info("RM Codes refreshed successfully. Total unique records saved: {}", entityList.size());

        } catch (Exception ex) {
            log.error("Error while saving/updating RM codes", ex);
        }
    }
}