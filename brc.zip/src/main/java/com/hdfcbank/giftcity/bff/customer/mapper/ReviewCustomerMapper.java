package com.hdfcbank.giftcity.bff.customer.mapper;


import com.hdfcbank.common.models.vo.journey.JourneyData;
import com.hdfcbank.giftcity.bff.commons.enums.JourneyPageName;
import com.hdfcbank.giftcity.bff.commons.model.FcIndiaProfile;
import com.hdfcbank.giftcity.bff.commons.utility.CommonUtil;
import com.hdfcbank.giftcity.bff.customer.constants.CustomerConstants;
import com.hdfcbank.giftcity.bff.customer.model.CustomerDetails;
import com.hdfcbank.giftcity.bff.customer.model.ReviewCustomerResponse;
import com.hdfcbank.giftcity.bff.customer.utility.CustomerUtil;
import com.hdfcbank.giftcity.bff.infrastructure.service.JourneyService;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Map;
import java.util.Optional;

@Mapper(componentModel = "spring")
public interface ReviewCustomerMapper {

    Logger log = LoggerFactory.getLogger(ReviewCustomerMapper.class);

    @Mapping(target = "employmentFinancial", expression = "java(mapEmployment(customerUserInputs))")
    @Mapping(target = "financialProducts", expression = "java(mapFinancialProducts(customerUserInputs))")
    @Mapping(target = "fatcaDetails", expression = "java(mapFatca(customerUserInputs))")
    @Mapping(target = "nomineeDetail", expression = "java(mapNomineeFromPage(nomineeUserInputs, journeyData))")
    @Mapping(target = "customerProfile", ignore = true)
    @Mapping(target = "branchDetails", ignore = true)
    ReviewCustomerResponse.ReviewCustomerDetails mapToReviewDetails(
            Map<String, Object> customerUserInputs,
            Map<String, Object> nomineeUserInputs,
            JourneyData journeyData
    );

    @Mapping(target = "nationality", source = "incoming.nationality")
    @Mapping(target = "taxResidency", source = "incoming.taxResidency", qualifiedByName = "maskTaxResidency")
    @Mapping(target = "taxResidency2", source = "incoming.taxResidency2", qualifiedByName = "maskTaxResidency")
    @Mapping(target = "taxResidency3", source = "incoming.taxResidency3", qualifiedByName = "maskTaxResidency")
    @Mapping(target = "placeOfBirth", source = "incoming.placeOfBirth")
    @Mapping(target = "countryOfBirth", source = "incoming.countryOfBirth")
    @Mapping(target = "fatherName", source = "incoming.fatherName")
    @Mapping(target = "motherName", source = "incoming.motherName")
    @Mapping(target = "addressForTaxPurpose", source = "incoming.addressForTaxPurpose")
    // keep these from existing
    @Mapping(target = "maritalStatus", source = "existing.maritalStatus")
    @Mapping(target = "spouseName", source = "existing.spouseName")
    @Mapping(target = "residenceType", source = "existing.residenceType")
    CustomerDetails.FatcaDetails mergeFatcaDetails(CustomerDetails.FatcaDetails existing,
                                                   CustomerDetails.FatcaDetails incoming);


    default CustomerDetails.EmploymentFinancial mapEmployment(Map<String, Object> userInputs) {
        if (isEmpty(userInputs)) return null;
        return CustomerUtil.convert(userInputs.get("employment"), CustomerDetails.EmploymentFinancial.class);
    }

    default CustomerDetails.FinancialProducts mapFinancialProducts(Map<String, Object> userInputs) {
        if (isEmpty(userInputs)) return null;
        return CustomerUtil.convert(userInputs.get("financialProducts"), CustomerDetails.FinancialProducts.class);
    }

    default CustomerDetails.FatcaDetails mapFatca(Map<String, Object> userInputs) {
        if (isEmpty(userInputs)) return null;
        return CustomerUtil.convert(userInputs.get("fatca"),
                CustomerDetails.FatcaDetails.class);
    }

    default ReviewCustomerResponse.ReviewCustomerDetails.NomineeDetail mapNomineeFromPage(
            Map<String, Object> nomineeUserInputs,
            JourneyData journeyData) {

        if (isEmpty(nomineeUserInputs)) {
            return null;
        }

        Object nomineeDetail = nomineeUserInputs.get("nomineeDetail");

        if (nomineeDetail == null) {
            return null;
        }

        FcIndiaProfile.Profile profile = JourneyService.extractFromJourney(
                journeyData,
                JourneyPageName.CUSTOMER_FC_INDIA_DETAIL.getPageName(),
                FcIndiaProfile.class,
                fcIndiaProfile -> Optional.ofNullable(fcIndiaProfile.getProfiles())
                        .filter(list -> !list.isEmpty())
                        .map(list -> list.get(0))
                        .orElse(null)
        ).orElse(null);

        ReviewCustomerResponse.ReviewCustomerDetails.NomineeDetail response =
                CustomerUtil.convert(
                        nomineeDetail,
                        ReviewCustomerResponse.ReviewCustomerDetails.NomineeDetail.class
                );

        if (response == null || profile == null || response.getNominee() == null) {
            return response;
        }

        ReviewCustomerResponse.ReviewCustomerDetails.Nominee nominee =
                CustomerUtil.getNomineeFromProfile(response.getNominee(), profile);

        if (response.getGuardian() == null) {
            return response;
        }

        ReviewCustomerResponse.ReviewCustomerDetails.Nominee guardian =
                response.getGuardian();

        if (Boolean.TRUE.equals(guardian.getAddressSameAsNominee()) && nominee != null) {

            guardian.setAddressLine1(nominee.getAddressLine1());
            guardian.setAddressLine2(nominee.getAddressLine2());
            guardian.setAddressLine3(nominee.getAddressLine3());
            guardian.setAddressLine4(nominee.getAddressLine4());
            guardian.setCountry(nominee.getCountry());
            guardian.setState(nominee.getState());
            guardian.setCity(nominee.getCity());
            guardian.setPincode(nominee.getPincode());
            guardian.setMaskedPermanentAddress(nominee.getMaskedPermanentAddress());
        }

        return response;
    }

    default boolean isEmpty(Map<String, Object> map) {
        return map == null || map.isEmpty();
    }

    @Named("maskTaxResidency")
    default CustomerDetails.TaxResidency maskTaxResidency(CustomerDetails.TaxResidency source) {
        if (source == null) {
            return null;
        }

        return CustomerDetails.TaxResidency.builder()
                .countryOfTaxResidency(source.getCountryOfTaxResidency())
                .taxIdType(source.getTaxIdType())
                .taxIdNumber(source.getTaxIdNumber() == null
                        ? null
                        : CommonUtil.mask(source.getTaxIdNumber(), 4))
                .build();
    }
}
