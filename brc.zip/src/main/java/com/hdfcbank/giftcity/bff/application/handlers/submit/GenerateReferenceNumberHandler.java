package com.hdfcbank.giftcity.bff.application.handlers.submit;

import com.hdfcbank.adapters.clients.feign.refgen.clients.RefGenServiceFeignClient;
import com.hdfcbank.adapters.clients.feign.refgen.request.RefGenRequest;
import com.hdfcbank.adapters.clients.feign.refgen.response.RefGenResponse;
import com.hdfcbank.common.models.vo.core.ApiResponse;
import com.hdfcbank.common.models.vo.journey.JourneyData;
import com.hdfcbank.giftcity.bff.commons.enums.CommonJourneyStates;
import com.hdfcbank.giftcity.bff.commons.exception.handler.DownstreamResponseHandler;
import com.hdfcbank.giftcity.bff.commons.handler.Handler;
import com.hdfcbank.giftcity.bff.commons.handler.HandlerContext;
import com.hdfcbank.giftcity.bff.commons.handler.HandlerResult;
import com.hdfcbank.giftcity.bff.infrastructure.service.JourneyService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Service;

import static com.hdfcbank.giftcity.bff.commons.enums.CommonJourneyStates.CREATE_APPLICATION_NUMBER_FAILURE;
import static com.hdfcbank.giftcity.bff.commons.enums.CommonJourneyStates.CREATE_APPLICATION_NUMBER_SUCCESS;

@Slf4j
@Service
@RequiredArgsConstructor
@Order(1)
public class GenerateReferenceNumberHandler implements Handler<String> {

    private final RefGenServiceFeignClient refGenServiceFeignClient;
    private final JourneyService journeyService;

    @Override
    public boolean preConditions(HandlerContext handlerContext) {
        return isSuccess(handlerContext, HandlerName.RISK_ANALYSIS);
    }

    @Override
    public HandlerResult<String> handle(HandlerContext handlerContext) {

        JourneyData journeyData = handlerContext.getJourneyData();
        try {

            ApiResponse<RefGenResponse> response = refGenServiceFeignClient.generateReferenceNumber(
                    new RefGenRequest(journeyData.getJourneyId(),
                            journeyData.getJourneyName()), journeyData.getJourneyId(),
                    journeyData.getJourneyName());

            if (response != null && response.getData().getRefNumber() != null) {

                journeyData.setReferenceNo(response.getData().getRefNumber());
                journeyService.saveJourney(journeyData);
                return HandlerResult.of(null,
                         response.getData().getRefNumber(), true);
            }

            return HandlerResult.<String>of(DownstreamResponseHandler
                            .handleResponse(response, HandlerName.CREATE_REFERENCE_NUMBER.name(),
                                    false, journeyData.getJourneyName()),
                    null, false);

        } catch (Throwable e) {
            return HandlerResult.<String>of(DownstreamResponseHandler
                            .handleResponse(null,
                                    HandlerName.CREATE_REFERENCE_NUMBER.name(),
                                    false, journeyData.getJourneyName()),
                    null, false);
        }
    }

    @Override
    public HandlerType getType() {
        return HandlerType.CUSTOMER_POST_SUBMIT;
    }

    @Override
    public HandlerName getName() {
        return HandlerName.CREATE_REFERENCE_NUMBER;
    }

    @Override
    public CommonJourneyStates successState() {
        return CREATE_APPLICATION_NUMBER_SUCCESS;
    }

    @Override
    public CommonJourneyStates failureState() {
        return CREATE_APPLICATION_NUMBER_FAILURE;
    }
}
