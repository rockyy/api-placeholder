package com.hdfcbank.giftcity.bff.customer.mapper;

import com.hdfcbank.common.models.vo.journey.Address;
import com.hdfcbank.common.models.vo.journey.JourneyData;
import com.hdfcbank.giftcity.bff.commons.enums.JourneyPageName;
import com.hdfcbank.giftcity.bff.commons.model.FcIndiaProfile;
import com.hdfcbank.giftcity.bff.commons.utility.CommonUtil;
import com.hdfcbank.giftcity.bff.customer.config.ReviewCustomerProperties;
import com.hdfcbank.giftcity.bff.customer.model.CustomerDetails;
import com.hdfcbank.giftcity.bff.infrastructure.service.JourneyService;
import com.hdfcbank.giftcity.bff.master.mapper.CountryMapper;
import io.micrometer.common.util.StringUtils;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Mapper(componentModel = "spring", uses = CountryMapper.class)
public abstract class ViewCustomerMapper {

    @Autowired
    protected ReviewCustomerProperties reviewCustomerProperties;


    @Mapping(target = "dob", source = "profile.dob")
    @Mapping(
            target = "email",
            expression = "java(com.hdfcbank.giftcity.bff.commons.utility.CommonUtil.maskEmail(profile.getEmail(),1,3))"
    )
    @Mapping(target = "gender", source = "profile.gender")
    @Mapping(
            target = "mobileNumber",
            expression = "java(com.hdfcbank.giftcity.bff.commons.utility.CommonUtil.maskMobile(journeyData.getMobileNumber(), journeyData.getIsd()))"
    )
    @Mapping(target = "fullName", source = "journeyData.profile.fullName")
    @Mapping(target = "title", source = "profile.customerTitle")
    @Mapping(
            target = "panNumber",
            expression = "java(com.hdfcbank.giftcity.bff.commons.utility.CommonUtil.maskPan(profile.getPanNumber()))"
    )
    @Mapping(
            target = "communicationAddress",
            expression = "java(toSingleLineMailingAddress(profile))"
    )
    @Mapping(
            target = "permanentAddress",
            expression = "java(toSingleLinePermanentAddress(profile))"
    )
    protected abstract CustomerDetails.CustomerProfile mapCustomerProfile(
            JourneyData journeyData,
            FcIndiaProfile.Profile profile
    );

    @Mapping(target = "annualIncome", ignore = true)
    @Mapping(target = "employerBusinessName", source = "profile.employerName")
    @Mapping(target = "occupation", source = "profile.customerProfession")
    @Mapping(target = "currency", ignore = true)
    @Mapping(target = "employerAddress1", ignore = true)
    @Mapping(target = "employerAddress2", ignore = true)
    @Mapping(target = "employerAddress3", ignore = true)
    @Mapping(target = "employerAddress4", ignore = true)
    @Mapping(target = "employerPinCode", ignore = true)
    @Mapping(target = "specialisation", ignore = true)
    @Mapping(target = "designation", ignore = true)
    @Mapping(target = "pep", ignore = true)
    @Mapping(target = "industry", ignore = true)
    @Mapping(target = "industryVariation", ignore = true)
    @Mapping(target = "monthlyAmount", ignore = true)
    @Mapping(target = "monthlyTransactions", ignore = true)
    @Mapping(target = "netWorth", ignore = true)
    @Mapping(target = "purposeOfAccount", source = "reviewCustomerProperties.purposeOfAccount")
    @Mapping(target = "qualification", ignore = true)
    @Mapping(target = "sourceOfIncome", ignore = true)
    @Mapping(target = "workExperience", ignore = true)
    @Mapping(target = "employedSince", ignore = true)
    protected abstract CustomerDetails.EmploymentFinancial mapEmploymentFinancial(
            JourneyData journeyData,
            FcIndiaProfile.Profile profile,
            ReviewCustomerProperties reviewCustomerProperties
    );

    @Mapping(target = "placeOfBirth", source = "fatca.namCityBirth")
    @Mapping(target = "countryOfBirth", source = "fatca.codCntryBirth")
    @Mapping(target = "fatherName", source = "fatca.namCustFather")
    @Mapping(target = "motherName", source = "profile.motherMaidenName")
    @Mapping(target = "spouseName", source = "fatca.namSpouseCust")
    @Mapping(target = "addressForTaxPurpose", source = "fatca.addrTaxReporting1")
    @Mapping(target = "maritalStatus", expression = """
            java(
                CustomerDetails.MaritalStatus.builder()
                        .status(profile.getMaritalStatus())
                        .build()
            )
            """)
    @Mapping(target = "residenceType", expression = """
            java(
                CustomerDetails.ResidentialType.builder()
                        .type(profile.getAddressTypeConsidered())
                        .build()
            )
            """)
    @Mapping(target = "nationality", source = "profile.txtCustNATNLTY", qualifiedByName = "descriptionFromCode")
    @Mapping(
            target = "taxResidency",
            expression = "java(buildTaxResidency(fatca.getCodTaxCntry1(), fatca.getTinNo1(), fatca.getTypTinNo1()))"
    )
    @Mapping(
            target = "taxResidency2",
            expression = "java(buildTaxResidency(fatca.getCodTaxCntry2(), fatca.getTinNo2(), fatca.getTypTinNo2()))"
    )
    @Mapping(
            target = "taxResidency3",
            expression = "java(buildTaxResidency(fatca.getCodTaxCntry3(), fatca.getTinNo3(), fatca.getTypTinNo3()))"
    )
    protected abstract CustomerDetails.FatcaDetails mapFatcaDetails(
            FcIndiaProfile.Profile profile,
            FcIndiaProfile.CustomerFATCADetail fatca
    );

    @Mapping(target = "pinCode", source = "zipCode")
    public abstract CustomerDetails.CustomerAddress toCustomerAddress(Address address);

    protected FcIndiaProfile.Profile getFcProfile(JourneyData journeyData) {

        return JourneyService.extractFromJourney(
                        journeyData,
                        JourneyPageName.CUSTOMER_FC_INDIA_DETAIL.getPageName(),
                        FcIndiaProfile.class,
                        fcIndiaProfile -> Optional.ofNullable(fcIndiaProfile.getProfiles())
                                .filter(list -> !list.isEmpty())
                                .map(list -> list.get(0))
                                .orElse(null)
                )
                .orElse(null);
    }

    protected CustomerDetails.TaxResidency buildTaxResidency(String country, String taxId, String taxIdType) {
        return CustomerDetails.TaxResidency.builder()
                .countryOfTaxResidency(country)
                .taxIdNumber(taxId == null
                        ? null
                        : CommonUtil.mask(taxId, 4))
                .taxIdType(taxIdType)
                .build();
    }

    protected String toSingleLineMailingAddress(FcIndiaProfile.Profile profile) {
        return buildAddress(
                profile.getMailingAddress1(),
                profile.getMailingAddress2(),
                profile.getMailingAddress3(),
                profile.getMailingCity(),
                profile.getMailingState(),
                profile.getMailingCountry() == null ? null : profile.getMailingCountry().getDescription(),
                profile.getMailingPinCode()
        );
    }

    protected String toSingleLinePermanentAddress(FcIndiaProfile.Profile profile) {

        String fullAddress = Stream.of(
                        profile.getAddress(),
                        profile.getAddress1(),
                        profile.getAddress2(),
                        profile.getAddress3())
                .filter(StringUtils::isNotBlank)
                .collect(Collectors.joining(", "));

        String maskedAddress = CommonUtil.maskAddress(fullAddress);

        return buildAddress(
                maskedAddress,
                profile.getCity(),
                profile.getState(),
                profile.getCountry() == null ? null : profile.getCountry().getDescription(),
                profile.getPinCode()
        );
    }

    protected String buildAddress(String... fields) {
        return Stream.of(fields)
                .filter(value -> value != null && !value.trim().isEmpty())
                .collect(Collectors.joining(", "));
    }

    public CustomerDetails.CustomerProfile journeyDetailsMapper(JourneyData journeyData) {
        FcIndiaProfile.Profile profile = getFcProfile(journeyData);
        if (profile == null) {
            return null;
        }
        return mapCustomerProfile(journeyData, profile);
    }

    public CustomerDetails.EmploymentFinancial employmentFinancialDetailsMapper(JourneyData journeyData) {
        FcIndiaProfile.Profile profile = getFcProfile(journeyData);
        if (profile == null) {
            return null;
        }
        return mapEmploymentFinancial(journeyData, profile, reviewCustomerProperties);
    }

    public CustomerDetails.FatcaDetails journeyFactaDetailsMapper(JourneyData journeyData) {
        FcIndiaProfile.Profile profile = getFcProfile(journeyData);
        if (profile == null || profile.getCustomerFATCADetails() == null || profile.getCustomerFATCADetails().isEmpty()) {
            return null;
        }
        return mapFatcaDetails(profile, profile.getCustomerFATCADetails().get(0));
    }
}