package com.hdfcbank.giftcity.bff.customer.model;

import lombok.*;
import lombok.experimental.SuperBuilder;


import lombok.*;
import lombok.experimental.SuperBuilder;
import java.util.List;

@Getter
@Setter
@ToString
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class FactivaDedupeResponse {

    private Status status;
    private Data data;

    @Getter
    @Setter
    @ToString
    @SuperBuilder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class Status {
        private String code;
        private String message;
    }

    @Getter
    @Setter
    @ToString
    @SuperBuilder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class Data {

        private MatchGroup factiva;
        private MatchGroup negativeList;
        private MatchGroup dotList;
        private MatchGroup mhaList;

        private String matchCombination;
        private String mhaMatch;
        private String neglistMatch;
        private String factivaMatch;
        private String dotMatch;

    }

    @Getter
    @Setter
    @ToString
    @SuperBuilder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class MatchGroup {
        private List<MatchParameter> matchParameter;
    }

    @Getter
    @Setter
    @ToString
    @SuperBuilder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class MatchParameter {
        private String matchParameterName;
        private String matchParameterValue;
    }
}