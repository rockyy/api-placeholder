package com.hdfcbank.giftcity.bff.sdui.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import net.javacrumbs.shedlock.core.*;

import org.bson.Document;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.context.SmartLifecycle;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Query;

import org.springframework.stereotype.Component;
import tools.jackson.databind.JsonNode;
import tools.jackson.databind.ObjectMapper;


import java.time.Duration;
import java.time.Instant;
import java.util.Optional;

@Component
@RequiredArgsConstructor
@Slf4j
public class UiSchemaLoader implements ApplicationRunner {

    @Qualifier("blockingMongoTemplate")
    private final MongoTemplate mongoTemplate;
    private final ObjectMapper objectMapper;
    private static final String COLLECTION = "ui_schemas";
    private final LockProvider lockProvider;

    @Override
    public void run(ApplicationArguments args) throws Exception {
        new DefaultLockingTaskExecutor(lockProvider);
        LockConfiguration config = new LockConfiguration(Instant.now(),
                "startup-lock",
                Duration.ofHours(3), // lockAtMostFor
                Duration.ofSeconds(5) // lockAtLeastFor
        );
        Optional<SimpleLock> lock = lockProvider.lock(config);
        if (lock.isPresent()) {
            try {
                performTask();
            } catch (Exception e) {
                throw new IllegalStateException("Failed to perform UI schema loading task", e);
            }
        }
    }

    public void performTask() throws Exception {

        log.info("MongoCollectionLoader Injected MongoTemplate bean type: {}", mongoTemplate.getClass().getName());
        log.info("MongoCollectionLoader Injected MongoTemplate super class    : {}", mongoTemplate.getClass().getSuperclass().getName());

        if (mongoTemplate.collectionExists(COLLECTION)) {
            long deletedCount = mongoTemplate.remove(new Query(), COLLECTION).getDeletedCount();

            log.info("Deleted {} existing UI schema documents.", deletedCount);
        } else {
            log.info("Collection [{}] does not exist. It will be created during insert.", COLLECTION);
        }

        Resource[] resources = new PathMatchingResourcePatternResolver().getResources("classpath:sd-ui/*.json");

        for (Resource resource : resources) {

            JsonNode json = objectMapper.readTree(resource.getInputStream());

            Document document = Document.parse(objectMapper.writeValueAsString(json));

            mongoTemplate.getCollection(COLLECTION).insertOne(document);

            log.info("Inserted UI schema [{}].", resource.getFilename());
        }

        log.info("UI schema initialization completed.");
    }



}