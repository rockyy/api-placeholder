package com.hdfcbank.giftcity.bff.commons.model;

import lombok.*;
import org.springframework.data.annotation.Id;

import java.util.Date;
import java.util.List;

@Getter
@Setter
public class JourneyCustomerProjection {

    @Id
    private String id;

    private JourneyDetailProjection journeyDetail;

    @Getter
    @Setter
    public static class JourneyDetailProjection {

        private SystemDataProjection systemData;

        private List<JourneyStateProjection> journeyStates;
    }

    @Getter
    @Setter
    public static class JourneyStateProjection {

        private String stateName;

        private Date createdOn;
    }

    @Getter
    @Setter
    public static class SystemDataProjection {

        private FcIndiaProfileProjection fcIndiaProfile;
    }

    @Getter
    @Setter
    public static class FcIndiaProfileProjection {

        private List<ProfilesProjection> profiles;
    }

    @Getter
    @Setter
    public static class ProfilesProjection {

        private String customerId;
    }
}