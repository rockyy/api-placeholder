package com.hdfcbank.giftcity.bff.customer.service.impl;

import com.hdfcbank.annotations.CoolingPeriodStore;
import com.hdfcbank.giftcity.bff.infrastructure.entity.CoolingPeriodDetailsEntity;
import com.hdfcbank.giftcity.bff.infrastructure.repository.CoolingPeriodDetailsRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.time.Duration;
import java.time.Instant;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@Slf4j
@Service
@RequiredArgsConstructor
public class CoolingPeriodService implements CoolingPeriodStore {
    private final CoolingPeriodDetailsRepository coolingPeriodDetailsRepository;

    @Override
    public int getConsumedAttempts(Map<String, String> identifiers) {
        return coolingPeriodDetailsRepository.findById(identifiers)
                .map(CoolingPeriodDetailsEntity::getNoOfAttempts)
                .orElse(0);
    }

    @Override
    public void updateConsumeAttempts(Map<String, String> identifiers, int attempts, Duration ttl) {
        try {
            Optional<CoolingPeriodDetailsEntity> entity = coolingPeriodDetailsRepository.findById(identifiers);

            Date now = new Date();
            Date expireAt = getExpireDate(ttl);

            if (entity.isPresent()) {
                coolingPeriodDetailsRepository.updateAttempts(identifiers, now, attempts, expireAt);
            } else {
                coolingPeriodDetailsRepository.save(CoolingPeriodDetailsEntity.builder()
                        .id(identifiers)
                        .createdDate(now)
                        .noOfAttempts(attempts)
                        .expireAt(expireAt)
                        .build()
                );
            }

        } catch (Exception e) {
            log.error("Failed to update consume attempts for identifiers: {}", identifiers, e);
            throw new IllegalStateException("Unable to update consume attempts", e);
        }
    }

    @Override
    public Date getExpireAt(Map<String, String> identifiers) {
        return coolingPeriodDetailsRepository.findById(identifiers)
                .map(CoolingPeriodDetailsEntity::getExpireAt)
                .orElseGet(Date::new);
    }

    @Override
    public void deleteEntity(List<Map<String, String>> identifiers) {
        try {
            identifiers.forEach(
                    coolingPeriodDetailsRepository::deleteByMapId);
        }
        catch (Exception ex) {
            log.error("Failed deleting cooling period entries", ex);
        }
    }

    private Date getExpireDate(Duration duration) {
        Instant updatedInstant = Instant.now().plus(duration);
        return Date.from(updatedInstant);
    }
}