package com.hdfcbank.giftcity.bff.commons.exception.handler;

import com.hdfcbank.common.models.vo.core.ApiResponse;
import com.hdfcbank.common.models.vo.core.ApiResponseStatus;
import com.hdfcbank.common.models.vo.core.ErrorRef;
import com.hdfcbank.exception.CoolOffLimitExceededException;
import com.hdfcbank.exception.handler.GlobalExceptionHandler;
import com.hdfcbank.giftcity.bff.commons.constant.CommonConstants;
import com.hdfcbank.giftcity.bff.commons.enums.CustomCommonApiStatusCodes;
import com.hdfcbank.giftcity.bff.commons.exception.CustomValidationException;
import com.hdfcbank.giftcity.bff.commons.exception.LimitExceededException;
import com.hdfcbank.giftcity.bff.commons.exception.OTPValidationException;
import com.hdfcbank.giftcity.bff.commons.exception.SOATokenException;
import com.hdfcbank.giftcity.bff.commons.model.InspireApiResponse;
import com.hdfcbank.service.adapters.commons.exception.CustomValidationAdapterException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import java.util.List;

@ControllerAdvice
@Slf4j
public class CustomerExceptionHandler implements GlobalExceptionHandler {

    private static final String EXCEPTION_OCCURRED_LOG = "Exception occurred: {}";


     public <T extends Exception> void logException(String source, T exception) {
         log.error(EXCEPTION_OCCURRED_LOG, source, exception);
    }

    @Override
    public <T extends Throwable> void logThrowable(String source, T throwable) {
         log.error(EXCEPTION_OCCURRED_LOG, source, throwable);
    }

    public <T extends Exception> void logException(T exception) {
        log.error(EXCEPTION_OCCURRED_LOG, exception.getMessage(), exception);
    }

    public <T extends Throwable> void logThrowable(T throwable) {
        log.error("Throwable Exception occurred: {}", throwable.getMessage(), throwable);
    }

    @ExceptionHandler(value = LimitExceededException.class)
    public ResponseEntity<ApiResponse<?>> handleRetryLimitExceeded(LimitExceededException e) {
        logException(e);
        ApiResponse<?> response = ApiResponse.builder()
                .status(new ApiResponseStatus(e.getCustomerApiStatusCode()))
                .build();
        return new ResponseEntity<>(response, HttpStatus.OK);
    }


    @ExceptionHandler(CustomValidationException.class)
    public ResponseEntity<ApiResponse<?>> handleCustomValidationException(CustomValidationException e) {

        logException(e);
        InspireApiResponse<?> response =
                InspireApiResponse.customValidationError(
                        e.getApiResponseStatusCodeLiteral(),
                        ErrorRef.inputValidation().asString(),
                        e.getTitle(),
                        e.getErrors()!=null ? List.of(e.getErrors().toArray(new String[0])):null
                );
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @ExceptionHandler(CustomValidationAdapterException.class)
    public ResponseEntity<ApiResponse<?>> handleCustomValidationException(CustomValidationAdapterException e) {

        // Preserve the adapter's status and errors with an empty title and HTTP 200.
        // Routing through DownstreamResponseHandler requires a separate adapter contract change.
        logException(e);
        InspireApiResponse<?> response =
                InspireApiResponse.customValidationError(
                        e.getApiResponseStatusCodeLiteral(),
                        ErrorRef.inputValidation().asString(),
                        //e.getTitle(),
                        "",
                        e.getErrors()!=null ? List.of(e.getErrors().toArray(new String[0])):null
                );
        return new ResponseEntity<>(response, HttpStatus.OK);
    }
//CustomValidationAdapterException
    @ExceptionHandler(OTPValidationException.class)
    public ResponseEntity<ApiResponse<?>> handleSoaTokenException(OTPValidationException e) {
        logException(e);
        ApiResponse<?> response = ApiResponse.builder()
                .status(new ApiResponseStatus(e.getApiResponseStatusCodeLiteral()))
                .build();
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @ExceptionHandler(SOATokenException.class)
    public ResponseEntity<ApiResponse<?>> handleSoaTokenException(SOATokenException e) {
        logException(e);
        ApiResponse<?> response = ApiResponse.builder()
                .status(new ApiResponseStatus(e.getApiResponseStatusCodeLiteral()))
                .build();
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @ExceptionHandler(CoolOffLimitExceededException.class)
    public ResponseEntity<ApiResponse<?>> handle(CoolOffLimitExceededException e) {
        logException("CoolOffLimitExceededException", e);
        ApiResponse<?> response = ApiResponse.businessValidationError(CustomCommonApiStatusCodes.COOL_OFF_LIMIT_EXCEEDED_ERROR, e.getErrorRef(), e.getErrors());
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @ExceptionHandler(NomineeException.class)
    public ResponseEntity<ApiResponse<?>> handleNomineeException(NomineeException e) {
        logException(e);
        ApiResponse<?> response = ApiResponse.builder()
                .status(new ApiResponseStatus(e.getStatus()))
                .build();
        return new ResponseEntity<>(response, HttpStatus.OK);
    }
}
