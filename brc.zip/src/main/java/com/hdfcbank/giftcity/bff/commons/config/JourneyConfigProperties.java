package com.hdfcbank.giftcity.bff.commons.config;

import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import java.util.Collections;
import java.util.List;
import java.util.Map;

@Getter
@Setter
@Configuration
@ConfigurationProperties(prefix = "app")
public class JourneyConfigProperties {

    private Map<String, JourneyConfig> journeys = Collections.emptyMap();


    @Getter
    @Setter
    public static class JourneyConfig {
        private List<ErrorMapping> errorMapping = Collections.emptyList();
        private List<String> handlers = Collections.emptyList();
        private EventDetail oneDeviceOneLogin;
    }

    @Getter
    @Setter
    public static class ErrorMapping {
        private String downstreamErrorCode;
        private String category;
        private String errorCode;
        private String messageHeading;
        private String message;
    }

    @Getter
    @Setter
    public static class EventDetail {
        private boolean enabled;
        private String mode;
        private List<String> decision;

    }
}
