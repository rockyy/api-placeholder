package com.hdfcbank.giftcity.bff.customer.model;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.*;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class RiskAssessmentPageData {

    private Integer totalWeightedScore;
    private String cddLevel;

    private RiskBlock customerRisk;
    private RiskBlock jurisdictionRisk;
    private RiskBlock interfaceRisk;
    private RiskBlock productRisk;
    private RiskBlock adverseMediaRisk;
    private RiskBlock transactionRisk;

    @Getter
    @Setter
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class RiskBlock {
        private Integer score;
        private String assessment;
        private Integer weightedScore;
    }
}
