package com.hdfcbank.giftcity.bff.commons.enums;

import com.hdfcbank.giftcity.bff.callback.model.FtsCallbackPageData;
import com.hdfcbank.giftcity.bff.commons.model.FcGcProfile;
import com.hdfcbank.giftcity.bff.commons.model.FcIndiaProfile;
import com.hdfcbank.giftcity.bff.commons.model.FtsDetails;
import com.hdfcbank.giftcity.bff.customer.model.IdentifyCustomerRequest;

import com.hdfcbank.service.adapters.vo.account.FTSAccountOpeningApiResponse;
import com.hdfcbank.giftcity.bff.customer.model.RiskAssessmentPageData;
import com.hdfcbank.service.adapters.vo.customer.FetchKycResponse;
import com.hdfcbank.service.adapters.vo.customer.UcicApiResponse;
import lombok.Generated;

public enum JourneyPageName {

    CUSTOMER_FC_INDIA_DETAIL("fcIndiaProfile", FcIndiaProfile.class),
    CUSTOMER_FC_GIFT_CITY_DETAIL("fcGiftCityProfile", FcGcProfile.class),

    FTS_ACCOUNT_OPENING("ftsAccOpeningDetails", FTSAccountOpeningApiResponse.ResponseString.class),

    IDENTIFY_CUSTOMER_REQUEST("identityCustomerRequest", IdentifyCustomerRequest.class),
    FTS_STATUS_CALLBACK("ftsStatusCallback", FtsCallbackPageData.class),
    FTS_DETAILS("FtsDetails", FtsDetails.class),

    KYC_DETAILS("CKYCDetails",FetchKycResponse.class),
    RISK_ASSESSMENT("riskAssessment", RiskAssessmentPageData.class),
    UCIC_DETAILS("UCICDetails", UcicApiResponse.class);


    private final String page;
    private final Class<?> pageClassName;


    public String getPageName() {
        return this.page;
    }

    public String getName() {
        return this.name();
    }

    public Class<?> getPageClassName(){
        return this.pageClassName;
    }

    @Generated
    private JourneyPageName(String page, Class<?> pageClassName) {
        this.page = page;
        this.pageClassName = pageClassName;
    }
}

