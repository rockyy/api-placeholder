package com.hdfcbank.giftcity.bff.commons.exception;

import com.hdfcbank.common.models.vo.core.ApiResponseStatusCodeLiteral;
import com.hdfcbank.giftcity.bff.commons.enums.CustomCommonApiStatusCodes;
import com.hdfcbank.giftcity.bff.commons.model.CustomValidationStatus;
import com.hdfcbank.giftcity.bff.customer.model.CustomerApiStatusCode;
import lombok.Getter;
import org.apache.commons.lang3.StringUtils;

import java.util.List;

@Getter
public class CustomValidationException extends RuntimeException {

    private final ApiResponseStatusCodeLiteral apiResponseStatusCodeLiteral;
    private final List<String> errors;
    private final String title;
    private final String screen = null;

    public CustomValidationException(CustomerApiStatusCode customerApiStatusCode, List<String> errors) {
        super(StringUtils.join(",",errors));
        this.apiResponseStatusCodeLiteral = customerApiStatusCode;
        this.errors = errors;
        this.title = null;
    }


    public CustomValidationException(CustomCommonApiStatusCodes commonApiStatusCodes, List<String> errors) {
        super(StringUtils.join(",",errors));
        this.apiResponseStatusCodeLiteral = commonApiStatusCodes;
        this.errors = errors;
        this.title = null;
    }

    public CustomValidationException(CustomValidationStatus status) {
        super(StringUtils.join(",", status.getErrors()));
        this.apiResponseStatusCodeLiteral = status;
        this.errors = status.getErrors();
        this.title = status.getTitle();
    }
}
