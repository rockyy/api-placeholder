package com.hdfcbank.giftcity.bff.infrastructure.entity;

import lombok.*;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.Date;
import java.util.Map;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Document(collection = "cooloff")
@Builder
public class CoolingPeriodDetailsEntity {

    @Id
    private Map<String, String> id;
    private String mobileNumber;
    private String dob;
    private String journeyName;
    private String responseType;
    private int noOfAttempts = 0;
    private Date createdDate;
    private Date modifiedDate;
    @Indexed(name = "expire_index", expireAfterSeconds = 10)
    private Date expireAt;

}
