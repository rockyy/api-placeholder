package com.hdfcbank.giftcity.bff.commons.enums;

import com.hdfcbank.common.models.vo.core.ApiResponseStatusCodeLiteral;
import lombok.Getter;

@Getter
public enum CustomCommonApiStatusCodes implements ApiResponseStatusCodeLiteral {

    SUCCESS("0000", "success"),
    DATA_NOT_FOUND("8001", "Data not found"),
    JOURNEY_DETAILS_NOT_FOUND("8000","Journey details not found for the given journey ID"),
    JOURNEY_STATE_NOT_MAINTAINED("8000","Journey state not maintained for this journey ID"),
    JOURNEY_STATE_FAILED("9999","Journey state %s failed for this journey ID"),
    CUSTOM_VALIDATION_EXCEPTION("5001", "failed"),
    COOL_OFF_LIMIT_EXCEEDED_ERROR("8008", "cooloff.limit.exceeded.error");
    private final String code;
    private final String message;


    CustomCommonApiStatusCodes(final String code, final String message) {
        this.code = code;
        this.message = message;
    }
}
