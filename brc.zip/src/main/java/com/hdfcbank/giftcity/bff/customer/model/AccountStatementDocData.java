package com.hdfcbank.giftcity.bff.customer.model;

import lombok.*;

import java.math.BigDecimal;
import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class AccountStatementDocData {

    private BigDecimal closingBal;
    private BigDecimal totalDebits;
    private BigDecimal totalCredits;
    private AccountDetails accountDetails;
    private List<TransactionData> transactions;
    private String transactionMessage;

    @Getter
    @Setter
    @NoArgsConstructor
    @AllArgsConstructor
    @ToString
    public static class AccountDetails {

        private String branchName;
        private String branchAddress;
        private String branchCity;
        private String branchState;
        private String branchTelNo;
        private Integer amountODLimit;
        private String currency;
        private String nomination;
        private String ifscCode;
        private String branchCode;
        private String prodTypeDesc;
        private String accountNumber;
        private String customerId;
        private String customerName;
        private String customerAddress;
        private String customerCity;
        private String customerState;
        private String customerPinCode;
        private String productType;
        private String accountStatus;
        private String accountOpenDate;
        private String currentDate;
        private String dateStmtFrom;
        private String dateStmtTo;
    }

    @Getter
    @Setter
    @NoArgsConstructor
    @AllArgsConstructor
    @ToString
    public static class TransactionData {
        private String txnDate;
        private String narration;
        private String chequeRefNo;
        private String valueDate;
        private BigDecimal withdrawalAmount;
        private BigDecimal depositAmount;

    }
}
