package com.hdfcbank.giftcity.bff.callback.model;

import com.hdfcbank.common.models.vo.core.ApiResponse;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.SuperBuilder;

@Getter
@Setter
@AllArgsConstructor
@SuperBuilder
public class FtsStatusCallbackResponse extends ApiResponse<FtsStatusCallbackResponse.FtsStatusCallback> {

    @Getter
    @Setter
    @SuperBuilder
    public static class FtsStatusCallback {
        private String barCode;
    }
}