package com.hdfcbank.giftcity.bff.customer.validator;

import com.hdfcbank.common.models.vo.core.ApiResponse;
import com.hdfcbank.common.models.vo.journey.JourneyData;
import com.hdfcbank.giftcity.bff.commons.enums.CommonJourneyStates;
import com.hdfcbank.giftcity.bff.commons.model.CustomValidationStatus;
import com.hdfcbank.giftcity.bff.commons.properties.CustomValidationProperties;
import com.hdfcbank.giftcity.bff.commons.utility.TextSanityUtil;
import com.hdfcbank.giftcity.bff.commons.validation.*;
import com.hdfcbank.giftcity.bff.customer.constants.CustomerConstants;
import com.hdfcbank.giftcity.bff.customer.mapper.FactivaDedupeMapper;
import com.hdfcbank.service.adapters.vo.customer.FactivaCheckApiResponse;
import com.hdfcbank.service.adapters.vo.customer.FactivaDedupeRequest;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import com.hdfcbank.service.adapters.clients.feign.customer.CustomerServiceFeignClient;

import java.util.*;

import static com.hdfcbank.giftcity.bff.commons.enums.CommonJourneyStates.FACTIVA_ELIGIBLE_FAILURE;
import static com.hdfcbank.giftcity.bff.commons.enums.CommonJourneyStates.FACTIVA_ELIGIBLE_SUCCESS;
import static com.hdfcbank.giftcity.bff.customer.constants.CustomerConstants.DEDUPE_FAILURE;
import static com.hdfcbank.giftcity.bff.customer.constants.CustomerConstants.DEDUPE_SUCCESS;

@Service
@RequiredArgsConstructor
@Slf4j
public class FactivaValidator extends AbstractCommanValidator implements Validator {


    private final CustomerServiceFeignClient customerFCFeignClient;
    private final FactivaDedupeMapper factivaDedupeMapper;
    private final CustomValidationProperties customValidationProperties;

    @Override
    public Optional<ValidationResult> validate(ValidatorContext context) {

        JourneyData journeyData = context.getJourneyData();
        String journeyName = journeyData.getJourneyName();

        try {
            FactivaCheckApiResponse response = callFactiva(journeyData);
            return handleResponse(response, journeyName);

        } catch (Exception e) {
            log.error("Exception in {} for journey {}", name(), journeyData.getReferenceNo(), e);
            return buildFailure(journeyName, null);
        }
    }

    private FactivaCheckApiResponse callFactiva(JourneyData journeyData) {

        FactivaDedupeRequest request = factivaDedupeMapper.toRequest(journeyData,journeyData.getProfile());

        return customerFCFeignClient.customerFactivaDedupe(request, journeyData.getJourneyId());
    }

    private Optional<ValidationResult> handleResponse(FactivaCheckApiResponse response, String journeyName) {

        if (response == null || response.getStatus() == null) {
            return buildFailure(journeyName, response);
        }

        String statusCode = response.getStatus().getCode();

        log.info("status code coming {}", TextSanityUtil.sanitize(statusCode));

        if (DEDUPE_FAILURE.equals(statusCode)) {
            return buildFailure(journeyName, response);
        }

        if (DEDUPE_SUCCESS.equals(statusCode)) {
            return buildSuccess();
        }

        return buildFailure(journeyName, response);
    }

    private Optional<ValidationResult> buildSuccess() {
        return Optional.of(ValidationResult.of(null,  true));
    }

    private Optional<ValidationResult> buildFailure(String journeyName, ApiResponse<?> apiResponse) {

        CustomValidationStatus errorStatus =
                getErrors(journeyName , apiResponse, customValidationProperties, CUSTOMER_FACTIVA);
        log.info("check status  120 {}",TextSanityUtil.sanitize(errorStatus.getCode()));

        return Optional.of(ValidationResult.of(errorStatus,  false));
    }

    @Override
    public ValidatorType type() {
        return ValidatorType.POST_CUSTOMER_VALIDATION;
    }

    @Override
    public String name() {
        return CustomerConstants.POST_FACTIVA_VALIDATOR;
    }

    @Override
    public CommonJourneyStates successState() {
        return FACTIVA_ELIGIBLE_SUCCESS;
    }

    @Override
    public CommonJourneyStates failureState() {
        return FACTIVA_ELIGIBLE_FAILURE;
    }

    @Override
    public boolean isMandatory() {
        return true;
    }
}
