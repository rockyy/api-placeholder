package com.hdfcbank.giftcity.bff.communication.service.impl;

import com.hdfcbank.adapters.vo.GenerateOtpRequest;
import com.hdfcbank.adapters.vo.GenerateOtpResponse;
import com.hdfcbank.adapters.vo.VerifyOtpRequest;
import com.hdfcbank.adapters.vo.VerifyOtpResponse;
import com.hdfcbank.giftcity.bff.communication.service.CommunicationService;
import com.hdfcbank.giftcity.bff.communication.mapper.CommunicationMapper;
import com.hdfcbank.giftcity.bff.customer.config.CustomerApiProperties;
import com.hdfcbank.giftcity.bff.customer.model.ValidateCustomerRequest;
import com.hdfcbank.giftcity.bff.communication.CommunicationServiceAdapter;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.Map;

import static com.hdfcbank.giftcity.bff.customer.constants.CustomerConstants.*;

@Service
@RequiredArgsConstructor
public class CommunicationServiceImpl implements CommunicationService {

    private final CommunicationServiceAdapter communicationServiceAdapter;
    private final CommunicationMapper communicationMapper;
    private final CustomerApiProperties customerApiProperties;


    @Override
    public GenerateOtpResponse sendOtp(String mobile, String email, String journeyName, String journeyId) {
        String templateId = customerApiProperties.getTemplateId().get(journeyName).get(SEND);

        GenerateOtpRequest request = communicationMapper.toGenerateOtpRequest(mobile, email, templateId);

        return communicationServiceAdapter.sendCommunication(request, journeyId, false);
    }

    @Override
    public GenerateOtpResponse resendOtp(String mobile, String email, String journeyName, String journeyId) {

        String templateId = customerApiProperties.getTemplateId().get(journeyName).get(RESEND);

        GenerateOtpRequest request = communicationMapper.toGenerateOtpRequest(mobile, email, templateId);

        return communicationServiceAdapter.sendCommunication(request, journeyId, true);
    }

    @Override
    public VerifyOtpResponse verifyOtp(ValidateCustomerRequest request, String journeyId) {

        Map<String, String> serviceDefaults = customerApiProperties.getGenerateAndDispatchOtp().getServiceDefaults();

        VerifyOtpRequest verifyRequest = communicationMapper.toVerifyOtpRequest(request,serviceDefaults);

        return communicationServiceAdapter.verifyOtp(verifyRequest, journeyId);

    }
}
