package com.hdfcbank.giftcity.bff.customer.validator;

import com.hdfcbank.common.models.vo.journey.JourneyData;
import com.hdfcbank.giftcity.bff.commons.enums.CommonJourneyStates;
import com.hdfcbank.giftcity.bff.commons.properties.CustomValidationProperties;
import com.hdfcbank.giftcity.bff.commons.validation.*;
import com.hdfcbank.giftcity.bff.customer.constants.CustomerConstants;
import com.hdfcbank.giftcity.bff.customer.service.CustomerService;
import com.hdfcbank.service.adapters.vo.customer.FetchKycResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.Optional;

import static com.hdfcbank.giftcity.bff.commons.enums.CommonJourneyStates.CUSTOMER_CKYC_FETCH_FAILURE;
import static com.hdfcbank.giftcity.bff.commons.enums.CommonJourneyStates.CUSTOMER_CKYC_FETCH_SUCCESS;

@Service
@RequiredArgsConstructor
public class CKYCValidator extends AbstractCommanValidator implements Validator {

    public static final String SUCCESS_CODE = "0000";
    public static final String UNKNOWN_ERROR = "9999";

    private final CustomValidationProperties customValidationProperties;
    private final CustomerService customerService;

    @Override
    public Optional<ValidationResult> validate(ValidatorContext context) {
        JourneyData journeyData = context.getJourneyData();

        if (journeyData != null) {

            FetchKycResponse fetchKycResponse =
                    customerService.fetchKYC(journeyData.getProfile().getCustomerId());

            if (SUCCESS_CODE.equals(fetchKycResponse.getStatus().getCode())) {

                context.getData().put(
                        ValidatorContext.ContextKey.CKYC_DETAILS,
                        fetchKycResponse.getData()
                );

                return Optional.of(ValidationResult.of(null, true));

            } else {
                return Optional.of(
                        ValidationResult.of(
                                getErrors(
                                        journeyData.getJourneyName(),
                                        fetchKycResponse,
                                        customValidationProperties,
                                        CKYC
                                ),
                                false
                        )
                );
            }
        }

        // journeyData may be null. So we safely determine journeyName.
        String journeyName = journeyData != null ? journeyData.getJourneyName() : "UNKNOWN_JOURNEY";

        return Optional.of(
                ValidationResult.of(
                        getErrors(
                                journeyName,
                                null,
                                customValidationProperties,
                                CKYC
                        ),
                        false
                )
        );
    }

    @Override
    public ValidatorType type() {
        return ValidatorType.POST_CUSTOMER_VALIDATION;
    }

    @Override
    public String name() {
        return CustomerConstants.KYC_VALIDATION;
    }

    @Override
    public CommonJourneyStates successState() {
        return CUSTOMER_CKYC_FETCH_SUCCESS;
    }

    @Override
    public CommonJourneyStates failureState() {
        return CUSTOMER_CKYC_FETCH_FAILURE;
    }

    @Override
    public boolean isMandatory() {
        return false;
    }
}