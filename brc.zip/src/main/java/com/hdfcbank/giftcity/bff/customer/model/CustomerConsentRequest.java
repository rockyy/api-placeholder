package com.hdfcbank.giftcity.bff.customer.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.hdfcbank.giftcity.bff.customer.validator.ValidIdentifier;
import lombok.*;
import lombok.experimental.SuperBuilder;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@SuperBuilder
@ValidIdentifier
public class CustomerConsentRequest {
    @NonNull
    private String key;
    @JsonProperty("acceptance")
    private boolean acceptance;
}
