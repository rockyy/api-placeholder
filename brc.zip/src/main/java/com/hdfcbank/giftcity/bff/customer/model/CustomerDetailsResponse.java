package com.hdfcbank.giftcity.bff.customer.model;

import com.hdfcbank.common.models.vo.core.ApiResponse;
import lombok.*;
import lombok.experimental.SuperBuilder;

@Getter
@Setter
@ToString
@SuperBuilder
@NoArgsConstructor
public class CustomerDetailsResponse extends ApiResponse<CustomerDetails> {

}
