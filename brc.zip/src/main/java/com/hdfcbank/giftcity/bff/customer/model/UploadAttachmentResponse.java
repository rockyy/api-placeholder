package com.hdfcbank.giftcity.bff.customer.model;

import com.hdfcbank.common.models.vo.core.ApiResponse;
import lombok.*;
import lombok.experimental.SuperBuilder;

@Getter
@Setter
@ToString
@SuperBuilder
@NoArgsConstructor
public class UploadAttachmentResponse extends ApiResponse<UploadAttachmentResponse.UploadAttachmentDetail> {

    @Getter
    @Setter
    @SuperBuilder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class UploadAttachmentDetail {
        private String filename;
        private String reference;
    }
}
