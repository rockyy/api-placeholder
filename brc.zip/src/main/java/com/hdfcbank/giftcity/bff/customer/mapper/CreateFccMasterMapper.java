package com.hdfcbank.giftcity.bff.customer.mapper;

import com.hdfcbank.giftcity.bff.customer.config.CreateFccMastersConfig;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
@RequiredArgsConstructor
public class CreateFccMasterMapper {

    private static final String DEFAULT_VALUE = "Others";

    private final CreateFccMastersConfig config;

    public String resolveOccupation(String occupationType) {

        if (isBlank(occupationType)) {
            return DEFAULT_VALUE;
        }

        return config.getOccupationMapping().stream()
                .filter(mapping ->
                        mapping.getOccupationType().equalsIgnoreCase(occupationType))
                .map(CreateFccMastersConfig.OccupationMapping::getFccOccupation)
                .findFirst()
                .orElse(DEFAULT_VALUE);
    }

    public String resolveOccupationNew(String occupationType, String designation) {

        if (isBlank(occupationType)) {
            return DEFAULT_VALUE;
        }

        Optional<String> exactMatch = config.getOccupationNewMapping().stream()
                .filter(mapping ->
                        mapping.getOccupationType().equalsIgnoreCase(occupationType)
                                && !isBlank(mapping.getDesignation())
                                && mapping.getDesignation().equalsIgnoreCase(designation))
                .map(CreateFccMastersConfig.OccupationNewMapping::getFccOccupationNew)
                .findFirst();

        return exactMatch.orElseGet(() -> config.getOccupationNewMapping().stream()
                .filter(mapping ->
                        mapping.getOccupationType().equalsIgnoreCase(occupationType)
                                && isBlank(mapping.getDesignation()))
                .map(CreateFccMastersConfig.OccupationNewMapping::getFccOccupationNew)
                .findFirst()
                .orElse(DEFAULT_VALUE));

    }

    public String resolveIndustry(String industryType) {

        if (isBlank(industryType)) {
            return DEFAULT_VALUE;
        }

        return config.getIndustryMapping().stream()
                .filter(mapping ->
                        mapping.getIndustryType().equalsIgnoreCase(industryType))
                .map(CreateFccMastersConfig.IndustryMapping::getFccIndustry)
                .findFirst()
                .orElse(industryType);
    }

    public String resolveNatureOfBusiness(String industryVariation) {

        if (isBlank(industryVariation)) {
            return DEFAULT_VALUE;
        }

        return config.getNatureOfBusinessMapping().stream()
                .filter(mapping ->
                        mapping.getIndustryVariation().equalsIgnoreCase(industryVariation))
                .map(CreateFccMastersConfig.NatureOfBusinessMapping::getNatureOfBusiness)
                .findFirst()
                .orElse(industryVariation);
    }

    private boolean isBlank(String value) {
        return value == null || value.trim().isEmpty();
    }
}