package com.hdfcbank.giftcity.bff.sdui.entity;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.mongodb.core.index.CompoundIndex;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Document(collection = "ui_schemas")
@CompoundIndex(name = "unique_page_version_idx", def = "{'page': 1, 'schemaVersion': 1}", unique = true)
public class UISchemaEntity {

    @Id
    private String id;

    private String page;

    private String schemaVersion;

    private boolean active;

    private Map<String, Object> schemaJson;

    private List<String> dataSources;

    @CreatedDate
    private LocalDateTime createdAt;

    @LastModifiedDate
    private LocalDateTime updatedAt;
}