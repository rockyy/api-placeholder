package com.hdfcbank.giftcity.bff.master.models;

import jakarta.validation.constraints.NotEmpty;
import lombok.*;

import java.util.List;
import java.util.Map;

@Getter
@Setter
@Builder
@EqualsAndHashCode
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class MasterDataFetchRequest {
    @NotEmpty
    private String masterName;
    private int pageNo;
    private int pageSize;
    private List<String> selectors;
    private Map<String, String> exactMatch;
    private Map<String, String> anyMatch;
    private Map<String, String> startsWith;
    private Map<String, String> endsWith;
    private List<String> sortBy;
    private boolean asc;
    private Map<String, String> filterOperations;
}
