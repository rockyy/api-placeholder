package com.hdfcbank.giftcity.bff.customer.model;


import com.fasterxml.jackson.annotation.JsonInclude;
import com.hdfcbank.common.models.vo.core.ApiResponse;
import lombok.*;
import lombok.experimental.SuperBuilder;

@Getter
@Setter
@ToString
@SuperBuilder
public class ReviewCustomerResponse extends ApiResponse<ReviewCustomerResponse.ReviewCustomerDetails> {

    @Getter
    @Setter
    @ToString
    @NoArgsConstructor
    @AllArgsConstructor
    @SuperBuilder
    public static class ReviewCustomerDetails extends CustomerDetails {

        private NomineeDetail nomineeDetail;
        private BranchDetail branchDetails;

        @Getter
        @Setter
        @NoArgsConstructor
        @AllArgsConstructor
        @Builder
        @JsonInclude(JsonInclude.Include.NON_NULL)
        public static class NomineeDetail {
            private boolean noNominee;
            private boolean minorNominee;
            private Nominee nominee;
            private Nominee guardian;
        }

        @Getter
        @Setter
        @NoArgsConstructor
        @AllArgsConstructor
        @Builder
        public static class BranchDetail {
            private String branchName;
            private String branchAddress;
            private String branchCode;
        }

        @Getter
        @Setter
        @NoArgsConstructor
        @AllArgsConstructor
        @Builder
        public static class Nominee {

            private String prefix;
            private String name;
            private String mobileNumber;
            private String emailId;
            private String relation;
            private String dob;
            private Boolean addressFromProfile;
            private Boolean addressSameAsNominee;
            private String addressFromProfileType;
            private String addressLine1;
            private String addressLine2;
            private String addressLine3;
            private String addressLine4;
            private String addressCode;
            private String country;
            private String state;
            private String city;
            private String pincode;
            private String minorFlag;
            private String maskedPermanentAddress;

        }
    }
}
