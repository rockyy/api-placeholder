package com.hdfcbank.giftcity.bff.customer.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hdfcbank.adapters.vo.GenerateOtpResponse;
import com.hdfcbank.adapters.vo.VerifyOtpResponse;
import com.hdfcbank.common.models.vo.core.ApiResponseStatus;
import com.hdfcbank.common.models.vo.core.ApiResponseStatusCode;
import com.hdfcbank.common.models.vo.core.ErrorRef;
import com.hdfcbank.common.models.vo.journey.JourneyData;
import com.hdfcbank.common.models.vo.journey.JourneyDetail;
import com.hdfcbank.common.models.vo.journey.JourneyState;
import com.hdfcbank.common.models.vo.mdc.MDCValues;
import com.hdfcbank.exception.DownstreamApiException;
import com.hdfcbank.giftcity.bff.commons.config.JourneyContextHolder;
import com.hdfcbank.giftcity.bff.commons.constant.CommonConstants;
import com.hdfcbank.giftcity.bff.commons.enums.CommonJourneyStates;
import com.hdfcbank.giftcity.bff.commons.enums.CustomCommonApiStatusCodes;
import com.hdfcbank.giftcity.bff.commons.enums.JourneyPageName;
import com.hdfcbank.giftcity.bff.commons.exception.CustomValidationException;
import com.hdfcbank.giftcity.bff.commons.exception.OTPValidationException;
import com.hdfcbank.giftcity.bff.commons.exception.handler.DownstreamResponseHandler;
import com.hdfcbank.giftcity.bff.commons.mapper.FcProfileMapper;
import com.hdfcbank.giftcity.bff.commons.model.CustomValidationStatus;
import com.hdfcbank.giftcity.bff.commons.properties.CustomValidationProperties;
import com.hdfcbank.giftcity.bff.commons.utility.TextSanityUtil;
import com.hdfcbank.giftcity.bff.commons.validation.JourneyDataProcessor;
import com.hdfcbank.giftcity.bff.commons.validation.ValidatorType;
import com.hdfcbank.giftcity.bff.communication.OtpResponseHandler;
import com.hdfcbank.giftcity.bff.communication.service.CommunicationService;
import com.hdfcbank.giftcity.bff.customer.config.CustomerApiProperties;
import com.hdfcbank.giftcity.bff.customer.config.ReviewCustomerProperties;
import com.hdfcbank.giftcity.bff.customer.events.SqsCustomerValidateMessage;
import com.hdfcbank.giftcity.bff.customer.events.SqsCustomerValidatePayload;
import com.hdfcbank.giftcity.bff.customer.mapper.CustomerMapper;
import com.hdfcbank.giftcity.bff.customer.mapper.ReviewCustomerMapper;
import com.hdfcbank.giftcity.bff.customer.mapper.ViewCustomerMapper;
import com.hdfcbank.giftcity.bff.customer.model.*;
import com.hdfcbank.giftcity.bff.customer.utility.CustomerUtil;
import com.hdfcbank.giftcity.bff.customer.utility.JourneyDataProcessorFactory;
import com.hdfcbank.giftcity.bff.customer.utility.ValidationFailureHandler;
import com.hdfcbank.giftcity.bff.infrastructure.service.JourneyService;
import com.hdfcbank.service.adapters.clients.feign.customer.CustomerServiceFeignClient;
import com.hdfcbank.service.adapters.vo.customer.CustomerSignatureRequest;
import com.hdfcbank.service.adapters.vo.customer.FetchSignatureResponse;
import com.hdfcbank.service.adapters.vo.customer.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import software.amazon.awssdk.services.sqs.SqsClient;
import software.amazon.awssdk.services.sqs.model.MessageAttributeValue;
import software.amazon.awssdk.services.sqs.model.SendMessageRequest;
import software.amazon.awssdk.services.sqs.model.SendMessageResponse;

import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;
import org.apache.commons.lang3.StringUtils;

import com.hdfcbank.giftcity.bff.commons.utility.ValidationHelper;
import java.time.Period;
import java.util.List;

import static com.hdfcbank.common.models.constant.CommonConstants.JOURNEY_ID;
import static com.hdfcbank.giftcity.bff.commons.constant.CommonConstants.IDENTIFY_CUSTOMER;
import static com.hdfcbank.giftcity.bff.commons.enums.JourneyPageName.IDENTIFY_CUSTOMER_REQUEST;
import static com.hdfcbank.giftcity.bff.customer.constants.CustomerConstants.*;

@Slf4j
@Service
@RequiredArgsConstructor
public class CustomerService {

    private final JourneyDataProcessorFactory journeyDataProcessorFactory;

    private final CustomerApiProperties customerApiProperties;
    private final CustomValidationProperties customValidationProperties;
    private final CustomerMapper customerMapper;
    private final JourneyService journeyService;
    private final CustomerServiceFeignClient customerFCFeignClient;
    private final CustomerServiceFeignClient customerServiceFeignClient;
    private final FcProfileMapper fcProfileMapper;
    private final ValidationFailureHandler validationFailureHandler;
    private final ViewCustomerMapper viewCustomerMapper;
    private final CommunicationService communicationService;
    private final OtpResponseHandler otpResponseHandler;
    private final SqsClient customerValidate;
    private final ObjectMapper objectMapper;
    @Value("${api.customer-validate.queueUrl}")
    private String customerValidateQueUrl;
    private final ReviewCustomerMapper reviewCustomerMapper;
    private final ReviewCustomerProperties reviewCustomerProperties;
    private final ValidationHelper validationHelper;

    public CloseCustomerResponse closeFccCustomer(
            String customerNumber,
            String journeyId) {

        log.info("Calling customer-service to close FCC customer: customerNumber={}", TextSanityUtil.sanitize(customerNumber));
        CloseCustomerRequest request =
                CloseCustomerRequest.builder()
                        .customerNumber(customerNumber)
                        .build();
        return customerServiceFeignClient.closeFccCustomer(
                request,
                journeyId);
    }


    public IdentifyCustomerResponse identifyCustomer(IdentifyCustomerRequest request, String journeyId, String journeyName) throws DownstreamApiException {

        log.info("Identify started with request ");
        JourneyDataProcessor processor = journeyDataProcessorFactory.getJourneyDataValidation();
        processor.validateRequest(request, journeyId);
        journeyService.saveJourney(toSaveJourneyData(CommonJourneyStates.CUSTOMER_ONBOARDING_INITIATED.name(), request, journeyId, journeyName, IDENTIFY_CUSTOMER_REQUEST.getPageName()));

        log.info("Fetching customer profile from FC india");
        FetchCasaResponse fetchCasaResponse = identifyCustomer(customerMapper.toFetchCasaRequest(request, journeyName), journeyId);

        validateFetchCasaResponse(fetchCasaResponse, journeyName, journeyId);

        journeyService.updateJourney(journeyId, JourneyPageName.CUSTOMER_FC_INDIA_DETAIL.getPageName(), fcProfileMapper.toFcIndiaProfile(fetchCasaResponse.getData()), CommonJourneyStates.CUSTOMER_FC_DETAIL_CAPTURED);

        log.info("Fetching customer profile from FC Gift city");
        FetchCasaResponse.Profile profile = processPostFcIndiaFlow(fetchCasaResponse, request, journeyId, journeyName);

        return processOtpAndBuildResponse(journeyId, journeyName, profile, request);
    }

    private void validateFetchCasaResponse(FetchCasaResponse response, String journeyName, String journeyId) {

        if (response == null || response.getStatus() == null) {
            log.info("Null response/status from GC API");
            validationFailureHandler.dropOnValidationFailure(
                    journeyId,
                    CustomerApiStatusCode.DOWNSTREAM_API_ERROR,
                    "Null response/status from fetch casa aml API",
                    CommonJourneyStates.DROP_OFF_CUSTOMER_EXCLUDED);

            throw new DownstreamApiException(ErrorRef.downstreamApiError(), "Null response/status from GC API");
        }

        ApiResponseStatus status = response.getStatus();

        if (!CommonConstants.SUCCESS_CODE.equalsIgnoreCase(status.getCode())) {

            log.info("FetchCasa API returned unsuccessful response");

            JourneyData journeyData = journeyService.fetchJourney(journeyId);
            CustomValidationStatus customValidationStatus = DownstreamResponseHandler.handleResponse(
                    response,
                    IDENTIFY_CUSTOMER,
                    false,
                    journeyName
            );

            journeyService.updateJourneyDetailDropOff(journeyData, customValidationStatus, CommonJourneyStates.DROP_OFF_CUSTOMER_EXCLUDED);
            throw new CustomValidationException(customValidationStatus);
        }

        if (response.getData() == null) {

            log.info("FetchCasa returned success status but customer data is null");

            validationFailureHandler.dropOnValidationFailure(
                    journeyId,
                    CustomerApiStatusCode.DOWNSTREAM_API_ERROR,
                    "FetchCasa returned success status but customer data is null",
                    CommonJourneyStates.DROP_OFF_CUSTOMER_EXCLUDED);

            DownstreamResponseHandler.handleResponse(
                    response,
                    IDENTIFY_CUSTOMER,
                    true,
                    journeyName
            );
            return;
        }
        validateCustomerAge(response, journeyName, journeyId);
    }

    private void validateCustomerAge(FetchCasaResponse response, String journeyName, String journeyId) {

        if (response.getData() == null
                || CollectionUtils.isEmpty(
                response.getData().getProfiles())) {
            return;
        }

        FetchCasaResponse.Profile profile =
                response.getData()
                        .getProfiles()
                        .get(0);

        Integer age = null;

        String dob = CustomerUtil.sanitizeDob(profile.getDob());

        if (StringUtils.isNotBlank(dob)) {
            age = Period.between(
                            LocalDate.parse(dob),
                            LocalDate.now())
                    .getYears();
        }

        CustomValidationProperties.FieldDetail field =
                validationHelper.validateRange(
                        CommonConstants.AGE,
                        age,
                        journeyName);

        if (field != null) {

            CustomValidationStatus validationStatus =
                    validationHelper.getErrors(
                            journeyName,
                            List.of(field),
                            customValidationProperties);


            journeyService.updateJourneyDetailDropOff(journeyService.fetchJourney(journeyId), validationStatus, CommonJourneyStates.DROP_OFF_CUSTOMER_EXCLUDED);

            throw new CustomValidationException(validationStatus);
        }
    }

    private JourneyData toSaveJourneyData(String journeyState, IdentifyCustomerRequest identityRequest, String journeyId, String journeyName, String pageName) {

        Map<String, Object> dataMap = new HashMap<>();
        dataMap.put(pageName, identityRequest);

        return JourneyData.builder()
                .journeyId(journeyId)
                .journeyName(journeyName)
                .mobileNumber(identityRequest.getMobileNo())
                .isd(identityRequest.getIsd())

                .journeyDetail(JourneyDetail.builder()
                        .journeyStates(List.of(JourneyState.builder()
                                .stateName(journeyState)
                                .createdOn(new Date())
                                .build()))
                        .systemData(Map.of(pageName, dataMap))
                        .build()).build();
    }

    private FetchCasaResponse.Profile processPostFcIndiaFlow(FetchCasaResponse fetchCasaResponse, IdentifyCustomerRequest request, String journeyId, String journeyName) {

        List<FetchCasaResponse.Profile> profiles = fetchCasaResponse.getData().getProfiles();

        FetchCasaResponse.Profile profile = extractCustomerProfile(profiles, request, journeyName,journeyId);
        JourneyDataProcessor processor = journeyDataProcessorFactory.getJourneyDataValidation();
        processor.validateCustomerEligibility(journeyId, profile);

        journeyService.updateProfile(journeyId, CommonJourneyStates.CUSTOMER_PROFILE_SUCCESS, profile);

        IdentifyGCCustomerResponse gcResponse = fetchGcCustomer(request, journeyId);
        processor.validateEtbCustomer(gcResponse, journeyId);
        journeyService.updateJourney(journeyId, JourneyPageName.CUSTOMER_FC_GIFT_CITY_DETAIL.getPageName(), fcProfileMapper.toFcGcProfile(gcResponse.getData()), CommonJourneyStates.CUSTOMER_FC_GC_DETAIL_CAPTURED);
        return profile;
    }

    private IdentifyGCCustomerResponse fetchGcCustomer(IdentifyCustomerRequest request, String journeyId) {

        return customerFCFeignClient.fetchGcCustomer(customerMapper.toGcRequest(request), journeyId);
    }

    private FetchCasaResponse.Profile extractCustomerProfile(List<FetchCasaResponse.Profile> profiles, IdentifyCustomerRequest request, String journeyName,String journeyId) {

        String allowedCustomerTypes = customerApiProperties.getCustomerTypes().get(journeyName).get(ALLOWED);

        List<FetchCasaResponse.Profile> filteredProfiles = filterProfilesByCustomerTypes(profiles, allowedCustomerTypes);

        if (filteredProfiles.isEmpty()) {
            validationFailureHandler.dropOnValidationFailure(journeyId,
                    CustomerApiStatusCode.NO_ELIGIBLE_CUSTOMER,
                    "No ELIGIBLE Customer Found", CommonJourneyStates.CUSTOMER_NOT_ELIGIBILE
            );
        }
        return fetchCustomerProfile(filteredProfiles, request);
    }

    private IdentifyCustomerResponse processOtpAndBuildResponse(String journeyId, String journeyName, FetchCasaResponse.Profile profile, IdentifyCustomerRequest request) {

        GenerateOtpResponse generateOtpResponse = communicationService.sendOtp(request.getFullMobileNumber(), profile.getEmail(), journeyName, journeyId);

        HandleGenerateOtpResponse handleRequest =
                HandleGenerateOtpResponse.builder()
                        .mobileNumber(request.getFullMobileNumber())
                        .dob(profile.getDob())
                        .journeyId(journeyId)
                        .isRetry(false)
                        .eligibleAccounts(profile.getEligibleAccounts())
                        .build();

        return otpResponseHandler.handleGenerateOtpResponse(handleRequest, generateOtpResponse, journeyId, profile.getEmail());

    }

    public InquireEligibilityResponse customerInquireEligibility(String journeyId) {
        log.info("Verify journey states for the journey ID {}", TextSanityUtil.sanitize(journeyId));
        List<String> successJourneyStates = List.of(
                CommonJourneyStates.FC_INDIA_ELIGIBILITY_SUCCESS.name(),
                CommonJourneyStates.FACTIVA_ELIGIBLE_SUCCESS.name(),
                CommonJourneyStates.CUSTOMER_SIGNATURE_FETCH_SUCCESS.name()
        );

        JourneyData journeyData = JourneyContextHolder.getJourneyData();
        if (journeyData == null
                || journeyData.getJourneyDetail() == null
                || journeyData.getJourneyDetail().getJourneyStates() == null) {
            throw new CustomValidationException(CustomCommonApiStatusCodes.JOURNEY_DETAILS_NOT_FOUND,
                    List.of(CustomCommonApiStatusCodes.JOURNEY_DETAILS_NOT_FOUND.getMessage()));
        }

        Set<String> journeyStateSet = journeyData.getJourneyDetail()
                .getJourneyStates()
                .stream()
                .map(JourneyState::getStateName)
                .collect(Collectors.toSet());

        boolean allSuccess = journeyStateSet.containsAll(successJourneyStates);

        return buildEnquiryResponse(allSuccess
                ? InquireEligibilityResponse.JourneyStatus.SUCCESS
                : InquireEligibilityResponse.JourneyStatus.IN_PROGRESS
        );
    }

    private InquireEligibilityResponse buildEnquiryResponse(InquireEligibilityResponse.JourneyStatus journeyStatus) {
        return InquireEligibilityResponse.builder()
                .status(new ApiResponseStatus(ApiResponseStatusCode.SUCCESS))
                .data(InquireEligibilityResponse.InquireEligibility.builder()
                        .status(journeyStatus)
                        .build())
                .build();
    }


    public List<FetchCasaResponse.Profile> filterProfilesByCustomerTypes(
            List<FetchCasaResponse.Profile> profiles,
            String customerTypes) {

        Set<String> allowedTypes = Arrays.stream(customerTypes.split(","))
                .map(String::trim)
                .map(String::toUpperCase)
                .collect(Collectors.toSet());

        log.info("customerTypes={}",
                TextSanityUtil.sanitize(customerTypes));

        log.info(
                "Allowed customer types={}",
                allowedTypes.stream()
                        .map(TextSanityUtil::sanitize)
                        .toList()
        );

        return profiles.stream()
                .filter(profile -> {

                    String customerType = profile.getCustomerType();
                    boolean isCustomerAccountEmpty = (profile.getCustomerAccountDetails() == null || profile.getCustomerAccountDetails().isEmpty());
                    log.info("Is customer accounts list empty {}", (profile.getCustomerAccountDetails() == null || profile.getCustomerAccountDetails().isEmpty()));
                    boolean accountStatusMatched = false;
                    if (!isCustomerAccountEmpty) {
                        List<String> accountStatus = profile.getCustomerAccountDetails()
                                .stream()
                                .map(FetchCasaResponse.CustomerAccountDetail::getAccountStatus)
                                .toList();

                        accountStatusMatched = !accountStatus.isEmpty() && accountStatus.contains(CommonConstants.VALID_ACCOUNT_STATUS_CODE);
                    }

                    boolean customerTypeMatched = customerType != null && allowedTypes.contains(customerType.trim().toUpperCase(Locale.ROOT));


                    log.info(
                            "Profile evaluation :: customerType={}, customerTypeMatched={}, accountStatusMatched={}, isCustomerAccountEmpty={}",
                            TextSanityUtil.sanitize(customerType),
                            customerTypeMatched,
                            accountStatusMatched,
                            isCustomerAccountEmpty
                    );

                    return customerTypeMatched
                            && accountStatusMatched;
                })
                .collect(Collectors.toList());
    }

    private FetchCasaResponse.Profile fetchCustomerProfile(
            List<FetchCasaResponse.Profile> profiles,
            IdentifyCustomerRequest request) {

        FetchCasaResponse.Profile profile = Optional.ofNullable(profiles)
                .filter(list -> !list.isEmpty())
                .map(list -> list.get(0))
                .orElseGet(() -> FetchCasaResponse.Profile.builder()
                        .mobileNumber(TextSanityUtil.sanitize(request.getMobileNo()))
                        .build());
        profile.setIdentifierName(request.getIdentifierName());
        return profile;
    }

    public FetchCasaResponse identifyCustomer(FetchCasaRequest request, String journeyId) {
        return customerFCFeignClient.identifyCustomer(request, journeyId);
    }

    public ValidateCustomerResponse validateCustomer(ValidateCustomerRequest request, String journeyId) {
        JourneyData journeyData = JourneyContextHolder.getJourneyData();
        log.info("inside validate OTP validateCustomer service class ");
        VerifyOtpResponse response = communicationService.verifyOtp(request, journeyId);

        if (OtpApiStatusCode.SUCCESS.getCode().equals(response.getStatus().getCode())) {
            publishCustomerValidatorMessage(journeyId);
        }
        return otpResponseHandler.handleVerifyOtpResponse(request, response, journeyData);
    }

    public IdentifyCustomerResponse resendOtp(String journeyId) {

        try {
            JourneyData journeyData = JourneyContextHolder.getJourneyData();
            String journeyName = journeyData.getJourneyName();
            String fullMobileNumber = (journeyData.getIsd() != null && !journeyData.getIsd().isBlank() ? journeyData.getIsd() : "") + journeyData.getMobileNumber();

            GenerateOtpResponse generateOtpResponse = communicationService.resendOtp(fullMobileNumber,journeyData.getProfile().getEmailId(),journeyName,journeyId);

            return otpResponseHandler.handleGenerateOtpResponse(fullMobileNumber, journeyData.getProfile().getDob(), generateOtpResponse, journeyId, true);
        } catch (Exception ex) {
            throw new OTPValidationException(OtpApiStatusCode.RESEND_OTP_FAILED, ex);
        }
    }


    public CustomerDetailsResponse getCustomerDetails() {

        JourneyData journeyData = JourneyContextHolder.getJourneyData();
        if (journeyData != null) {
            return CustomerDetailsResponse.builder()
                    .data(CustomerDetails.builder()
                            .customerProfile(viewCustomerMapper.journeyDetailsMapper(journeyData))
                            .fatcaDetails(viewCustomerMapper.journeyFactaDetailsMapper(journeyData))
                            .employmentFinancial(viewCustomerMapper.employmentFinancialDetailsMapper(journeyData))
                            .financialProducts(CustomerDetails.FinancialProducts.builder()
                                    .products(reviewCustomerProperties.getFinancialProducts())
                                    .build()
                            )
                            .build())
                    .status(ApiResponseStatus.success())
                    .build();
        }
        return CustomerDetailsResponse.builder()
                .status(new ApiResponseStatus(CustomCommonApiStatusCodes.JOURNEY_DETAILS_NOT_FOUND))
                .build();
    }

    public ReviewCustomerResponse getReviewCustomerDetails() {

        JourneyData journeyData = JourneyContextHolder.getJourneyData();
        if (journeyData == null) {
            return ReviewCustomerResponse.builder()
                    .status(new ApiResponseStatus(CustomCommonApiStatusCodes.JOURNEY_DETAILS_NOT_FOUND))
                    .build();
        }
        Map<String, Object> customerUserInputs =
                JourneyService.getDomainPageUserInputs(journeyData, CUSTOMER_DETAILS);

        Map<String, Object> nomineeUserInputs =
                JourneyService.getDomainPageUserInputs(journeyData, NOMINEE_DETAILS);

        ReviewCustomerResponse.ReviewCustomerDetails data = reviewCustomerMapper.mapToReviewDetails(
                customerUserInputs, nomineeUserInputs, journeyData);

        if (data == null) {
            data = new ReviewCustomerResponse.ReviewCustomerDetails();
        }
        data.setCustomerProfile(viewCustomerMapper.journeyDetailsMapper(journeyData));
        data.setBranchDetails(ReviewCustomerResponse.ReviewCustomerDetails.BranchDetail.builder()
                .branchName(reviewCustomerProperties.getBranchName())
                .branchCode(reviewCustomerProperties.getBranchCode())
                .branchAddress(reviewCustomerProperties.getBranchAddress())
                .build());
        if (data.getFatcaDetails() != null) {
            data.setFatcaDetails(
                    reviewCustomerMapper.mergeFatcaDetails(
                            data.getFatcaDetails(),
                            viewCustomerMapper.journeyFactaDetailsMapper(journeyData)
                    )
            );
        } else {
            data.setFatcaDetails(viewCustomerMapper.journeyFactaDetailsMapper(journeyData));
        }


        return ReviewCustomerResponse.builder()
                .status(ApiResponseStatus.success())
                .data(data)
                .build();
    }

    private void publishCustomerValidatorMessage(String journeyId) {

        log.info("Publishing validate SQS message with journey ID {} and Queue Url {}", TextSanityUtil.sanitize(journeyId), TextSanityUtil.sanitize(customerValidateQueUrl));
        try {
            SqsCustomerValidateMessage sqsOtpValidatorMessageRequest = SqsCustomerValidateMessage.builder()
                    .type(ValidatorType.POST_CUSTOMER_VALIDATION)
                    .payload(SqsCustomerValidatePayload.builder()
                            .journeyId(journeyId)
                            .build())
                    .build();
            String message = objectMapper.writeValueAsString(sqsOtpValidatorMessageRequest);

            log.info("Preparing to send message to SQS. Message body: {}", TextSanityUtil.sanitize(message));

            SendMessageRequest sendMessageRequest = SendMessageRequest.builder()
                    .queueUrl(customerValidateQueUrl)
                    .messageBody(message)
                    .messageAttributes(Map.of(
                            JOURNEY_ID,
                            MessageAttributeValue.builder()
                                    .dataType("String")
                                    .stringValue(MDCValues.getJourneyId())
                                    .build()
                    ))
                    .build();

            SendMessageResponse response = customerValidate.sendMessage(sendMessageRequest);
            log.info("Message sent to queue: {}, messageId: {}, MD5: {}",
                    TextSanityUtil.sanitize(customerValidateQueUrl),
                    TextSanityUtil.sanitize(response.messageId()),
                    TextSanityUtil.sanitize(response.md5OfMessageBody())
            );
        } catch (Exception e) {
            log.error("Error sending customer validator message to SQS queue {}", customerValidateQueUrl, e);
        }
    }

    public FetchSignatureResponse fetchSignature(String customerId,String journeyId) {
        CustomerSignatureRequest request = new CustomerSignatureRequest();
        request.setCustomerId(customerId);
        return customerFCFeignClient.fetchSignature(request,journeyId);
    }

    public FetchKycResponse fetchKYC(String customerId) {
        FetchKycRequest request = new FetchKycRequest();
        request.setCustomerId(customerId);
        return customerFCFeignClient.fetchKyc(request);
    }
}