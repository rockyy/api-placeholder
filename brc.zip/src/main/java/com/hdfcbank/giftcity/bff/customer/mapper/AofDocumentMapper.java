package com.hdfcbank.giftcity.bff.customer.mapper;

import com.hdfcbank.adapters.vo.GenerateDocumentRequest;
import com.hdfcbank.common.models.vo.journey.JourneyData;
import com.hdfcbank.giftcity.bff.commons.constant.CommonConstants;
import com.hdfcbank.giftcity.bff.commons.model.FcGcProfile;
import com.hdfcbank.giftcity.bff.commons.model.FcIndiaProfile;
import com.hdfcbank.giftcity.bff.commons.model.MasterDataValue;
import com.hdfcbank.giftcity.bff.commons.utility.CommonUtil;
import com.hdfcbank.giftcity.bff.customer.constants.CustomerConstants;
import com.hdfcbank.giftcity.bff.customer.model.AofWithAnnextureData;
import com.hdfcbank.giftcity.bff.customer.model.ReviewCustomerResponse;
import com.hdfcbank.giftcity.bff.customer.model.RiskAssessmentPageData;
import com.hdfcbank.giftcity.bff.customer.utility.CustomerUtil;
import com.hdfcbank.giftcity.bff.infrastructure.service.JourneyService;
import org.mapstruct.*;

import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static com.hdfcbank.giftcity.bff.customer.constants.CustomerConstants.*;


@Mapper(
        componentModel = "spring",
        imports = {CustomerConstants.class, CustomerUtil.class, CommonUtil.class, FcIndiaProfile.class, FcGcProfile.class, CommonConstants.class, java.time.LocalDate.class,
                MasterDataValue.class, Optional.class},
        nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS,
        nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE,
        unmappedTargetPolicy = ReportingPolicy.IGNORE
)
public interface AofDocumentMapper {

    @Mapping(target = "generateType", constant = CustomerConstants.TIF)
    @Mapping(target = "responseType", constant = CustomerConstants.ATTACHMENT)
    @Mapping(target = "templateId", constant = CustomerConstants.CUSTOMER_AML_AOF_WITH_CRA_TEMPLATE)
    @Mapping(target = "targetFileName", expression = "java(buildFileNameWithCra(journeyData))")
    @Mapping(target = "data", expression = "java(toDataWithCra(journeyData, branchName, branchCode, productCode))")
    GenerateDocumentRequest<AofWithAnnextureData> toRequestWithCra(JourneyData journeyData, String branchName, String branchCode, String productCode);


    @Mapping(target = "generateType", constant = CustomerConstants.PDF)
    @Mapping(target = "responseType", constant = CustomerConstants.ATTACHMENT)
    @Mapping(target = "templateId", constant = CustomerConstants.CUSTOMER_AML_AOF_TEMPLATE)
    @Mapping(target = "targetFileName", expression = "java(buildFileNameAofOnly(journeyData))")
    @Mapping(target = "data", expression = "java(toAofOnlyData(journeyData, branchName, branchCode, productCode))")
    GenerateDocumentRequest<AofWithAnnextureData> toRequestAofOnly(JourneyData journeyData, String branchName, String branchCode, String productCode);


    default AofWithAnnextureData toDataWithCra(JourneyData journeyData, String branchName, String branchCode, String productCode) {
        RiskAssessmentPageData risk = CustomerUtil.getRiskAssessment(journeyData);
        AofWithAnnextureData data = new AofWithAnnextureData();
        data.setAof(toAofData(journeyData, branchName, branchCode, productCode));
        data.setRiskAnalysis(
                toRiskAnalysis(
                        risk,
                        CustomerUtil.getPrimaryProfile(journeyData)
                                .map(FcIndiaProfile.Profile::getName)
                                .orElse(null),
                        journeyData
                )
        );
        return data;
    }

    default AofWithAnnextureData toAofOnlyData(JourneyData journeyData, String branchName, String branchCode, String productCode) {
        AofWithAnnextureData data = new AofWithAnnextureData();
        data.setAof(toAofData(journeyData, branchName, branchCode, productCode));
        data.setRiskAnalysis(null);
        return data;
    }

    default String buildFileNameWithCra(JourneyData journeyData) {
        return CustomerConstants.AOF_WITH_ANNEXTURE_PREFIX + journeyData.getJourneyId() + CustomerConstants.TIF_EXTENSION;
    }

    default String buildFileNameAofOnly(JourneyData journeyData) {
        return CustomerConstants.AOF_WITHOUT_ANNEXTURE_PREFIX + journeyData.getJourneyId() + CustomerConstants.PDF_EXTENSION;
    }

    @Mapping(target = "dateOfApplication", expression = "java(LocalDate.now().format(CommonConstants.DATE_OF_APPLICATION))")

    @Mapping(target = "newCustomer", expression = "java(CustomerConstants.UNCHECKED)")
    @Mapping(target = "existingCustomer", expression = "java(CustomerConstants.CHECKED)")

    @Mapping(target = "customerId", expression = "java(getProfileValue(journeyData, FcIndiaProfile.Profile::getCustomerId))")

    @Mapping(target = "residentIndian", expression = "java(CustomerConstants.UNCHECKED)")
    @Mapping(target = "nonResidentIndian", expression = "java(CustomerConstants.CHECKED)")
    @Mapping(target = "foreignNational", expression = "java(CustomerConstants.UNCHECKED)")

    @Mapping(target = "singleNameAccount", expression = "java(CustomerConstants.CHECKED)")
    @Mapping(target = "jointNameAccount", expression = "java(CustomerConstants.UNCHECKED)")

    @Mapping(target = "realEstate", expression = "java(CustomerConstants.UNCHECKED)")
    @Mapping(target = "forexDealer", expression = "java(CustomerConstants.UNCHECKED)")
    @Mapping(target = "assessedProfessional", expression = "java(CustomerConstants.UNCHECKED)")
    @Mapping(target = "clientRetailInvestor", expression = "java(CustomerConstants.CHECKED)")
    @Mapping(target = "accreditedInvestor ", expression = "java(CustomerConstants.UNCHECKED)")


    @Mapping(target = "fullName", expression = "java(getProfileValue(journeyData, FcIndiaProfile.Profile::getName))")

    @Mapping(target = "fccCustomerNo",
            expression = "java(CustomerUtil.getFCGiftCityProfile(journeyData).map(FcGcProfile::getCustomerNumber).orElse(null))")

    @Mapping(target = "fccAccountNo",
            expression = "java(CustomerUtil.getFCGiftCityProfile(journeyData).map(FcGcProfile::getAccountNumber).orElse(null))")


    @Mapping(target = "salutationMr", expression = "java(checkCustomerTitle(journeyData, CustomerConstants.TITLE_MR))")
    @Mapping(target = "salutationMs", expression = "java(checkCustomerTitle(journeyData, CustomerConstants.TITLE_MS))")
    @Mapping(target = "salutationDr", expression = "java(checkCustomerTitle(journeyData, CustomerConstants.TITLE_DR))")
    @Mapping(target = "salutationOther", expression = "java(checkCustomerTitle(journeyData, CustomerConstants.TITLE_OTHER))")


    @Mapping(target = "firstName", expression = "java(getProfileValue(journeyData, FcIndiaProfile.Profile::getCustomerFirstName))")
    @Mapping(target = "middleName", expression = "java(getProfileValue(journeyData, FcIndiaProfile.Profile::getMiddleNames))")
    @Mapping(target = "lastName", expression = "java(getProfileValue(journeyData, FcIndiaProfile.Profile::getCustomerLastName))")

    @Mapping(target = "dob", expression = "java(CommonUtil.formatDob(getProfileValue(journeyData, FcIndiaProfile.Profile::getDob)))")
    @Mapping(target = "countryBirth", expression = "java(getFatcaValue(journeyData, FcIndiaProfile.CustomerFATCADetail::getCodCntryBirth))")

    @Mapping(target = "male", expression = "java(getGenderFlag(journeyData, CustomerConstants.MALE))")
    @Mapping(target = "female", expression = "java(getGenderFlag(journeyData, CustomerConstants.FEMALE))")

    @Mapping(target = "maritalSingle", expression = "java(checkMaritalStatus(journeyData, CustomerConstants.SINGLE))")
    @Mapping(target = "maritalMarried", expression = "java(checkMaritalStatus(journeyData, CustomerConstants.MARRIED))")
    @Mapping(target = "maritalDivorced", expression = "java(checkDivorcedOrSeparated(journeyData))")
    @Mapping(target = "maritalWidowed", expression = "java(checkMaritalStatus(journeyData, CustomerConstants.WIDOWED))")


    @Mapping(target = "placeBirth", expression = "java(getFatcaValue(journeyData, FcIndiaProfile.CustomerFATCADetail::getNamCityBirth))")
    @Mapping(target = "nationality", expression = "java(getProfileValue(journeyData, FcIndiaProfile.Profile::getTxtCustNATNLTY))")

    @Mapping(target = "spouseName", expression = "java(CustomerUtil.getValueByPath(journeyData, CustomerConstants.CUSTOMER_DETAILS, CustomerConstants.FATCA_SPOUSE_NAME_PATH))")

    @Mapping(target = "passportNumber", expression = "java(getFatcaValue(journeyData, FcIndiaProfile.CustomerFATCADetail::getIdDocNum))")
    @Mapping(target = "psptIssueDate", expression = "java(CommonUtil.formatDob(getFatcaValue(journeyData, FcIndiaProfile.CustomerFATCADetail::getDatPsptIssue)))")
    @Mapping(target = "psptExpiryDate", expression = "java(CommonUtil.formatPassportDob(getFatcaValue(journeyData, FcIndiaProfile.CustomerFATCADetail::getIdDocExpDat)))")

    @Mapping(target = "secondary", expression = "java(getQualificationFlag(journeyData, CustomerConstants.QUALIFICATION_SECONDARY))")
    @Mapping(target = "higherSecondary", expression = "java(getQualificationFlag(journeyData, CustomerConstants.QUALIFICATION_HIGHER_SECONDARY))")
    @Mapping(target = "graduate", expression = "java(getQualificationFlag(journeyData, CustomerConstants.QUALIFICATION_GRADUATE))")
    @Mapping(target = "postGraduate", expression = "java(getQualificationFlag(journeyData, CustomerConstants.QUALIFICATION_POST_GRADUATE))")
    @Mapping(target = "qualificationOther", expression = "java(getQualificationFlag(journeyData, CustomerConstants.QUALIFICATION_OTHER))")

    @Mapping(target = "mailingAddress", expression = "java(CustomerUtil.getPrimaryProfile(journeyData).map(p -> joinAddress(p.getMailingAddress1(), p.getMailingAddress2(), p.getMailingAddress3())).orElse(null))")
    @Mapping(target = "mailingAddressCity",
            expression = "java(joinAddress(" +
                    "getProfileValue(journeyData, FcIndiaProfile.Profile::getMailingCity)," +
                    "getProfileValue(journeyData, FcIndiaProfile.Profile::getMailingState)))")


    @Mapping(target = "mailingAddressCountry", expression = "java(Optional.ofNullable(getProfileValue(journeyData, FcIndiaProfile.Profile::getMailingCountry)).map(MasterDataValue::getCode).orElse(null))")
    @Mapping(target = "mailingAddressZip", expression = "java(getProfileValue(journeyData, FcIndiaProfile.Profile::getMailingPinCode))")

    @Mapping(target = "permanentAddress", expression = "java(CustomerUtil.getPrimaryProfile(journeyData).map(p -> joinAddress(p.getAddress(), p.getAddress2(), p.getAddress3())).orElse(null))")
    @Mapping(target = "permanentAddressCity",
            expression = "java(joinAddress(" +
                    "getProfileValue(journeyData, FcIndiaProfile.Profile::getCity)," +
                    "getProfileValue(journeyData, FcIndiaProfile.Profile::getState)))")
    @Mapping(target = "permanentAddressCountry", expression = "java(Optional.ofNullable(getProfileValue(journeyData, FcIndiaProfile.Profile::getCountry)).map(MasterDataValue::getCode).orElse(null))")
    @Mapping(target = "permanentAddressZip", expression = "java(getProfileValue(journeyData, FcIndiaProfile.Profile::getPinCode))")

    @Mapping(target = "emailId", expression = "java(getProfileValue(journeyData, FcIndiaProfile.Profile::getRefCustEmail))")
    @Mapping(target = "mobileNumber", expression = "java(getProfileValue(journeyData, FcIndiaProfile.Profile::getMobileNumber))")

    @Mapping(target = "salaried", expression = "java(getOccupationFlag(journeyData, CustomerConstants.OCCUPATION_SALARIED))")
    @Mapping(target = "selfEmployed", expression = "java(getOccupationFlag(journeyData, CustomerConstants.OCCUPATION_SELF_EMPLOYED_BUSINESS))")
    @Mapping(target = "housewife", expression = "java(getOccupationFlag(journeyData, CustomerConstants.OCCUPATION_HOUSEWIFE))")
    @Mapping(target = "professional", expression = "java(getOccupationFlag(journeyData, CustomerConstants.OCCUPATION_PROFESSIONAL))")
    @Mapping(target = "retired", expression = "java(getOccupationFlag(journeyData, CustomerConstants.OCCUPATION_RETIRED))")
    @Mapping(target = "student", expression = "java(getOccupationFlag(journeyData, CustomerConstants.OCCUPATION_STUDENT))")
    @Mapping(target = "occupationOther", expression = "java(getOccupationFlag(journeyData, CustomerConstants.OCCUPATION_OTHER))")

    @Mapping(target = "nameOfEmployer", expression = "java(CustomerUtil.getValueByPath(journeyData, CustomerConstants.CUSTOMER_DETAILS, CustomerConstants.EMPLOYMENT_EMPLOYER_NAME_PATH))")
    @Mapping(target = "designation", expression = "java(getDesignation(journeyData))")
    @Mapping(target = "workExperience", expression = "java(CustomerUtil.getValueByPath(journeyData, CustomerConstants.CUSTOMER_DETAILS, CustomerConstants.EMPLOYMENT_WORK_EXPERIENCE_PATH))")
    @Mapping(target = "addressOfEmployer",
            expression = "java(joinAddress(" +
                    "CustomerUtil.getValueByPath(journeyData, CustomerConstants.CUSTOMER_DETAILS, CustomerConstants.EMPLOYMENT_EMPLOYER_ADDRESS1_PATH)," +
                    "CustomerUtil.getValueByPath(journeyData, CustomerConstants.CUSTOMER_DETAILS, CustomerConstants.EMPLOYMENT_EMPLOYER_ADDRESS2_PATH), " +
                    "CustomerUtil.getValueByPath(journeyData, CustomerConstants.CUSTOMER_DETAILS, CustomerConstants.EMPLOYMENT_EMPLOYER_ADDRESS3_PATH), " +
                    "CustomerUtil.getValueByPath(journeyData, CustomerConstants.CUSTOMER_DETAILS, CustomerConstants.EMPLOYMENT_EMPLOYER_ADDRESS4_PATH)))")


    @Mapping(target = "manufacturing", expression = "java(getIndustryFlag(journeyData, CustomerConstants.INDUSTRY_MANUFACTURING))")
    @Mapping(target = "mfrDescription", expression = "java(getIndustryDescription(journeyData, CustomerConstants.INDUSTRY_MANUFACTURING))")
    @Mapping(target = "retailTrading", expression = "java(getIndustryFlag(journeyData, CustomerConstants.INDUSTRY_RETAIL_TRADE))")
    @Mapping(target = "rtlDescription", expression = "java(getIndustryDescription(journeyData, CustomerConstants.INDUSTRY_RETAIL_TRADE))")
    @Mapping(target = "importExport", expression = "java(getIndustryFlag(journeyData, CustomerConstants.INDUSTRY_IMPORT_EXPORT))")
    @Mapping(target = "ieoDescription", expression = "java(getIndustryDescription(journeyData, CustomerConstants.INDUSTRY_IMPORT_EXPORT))")
    @Mapping(target = "hotelRestaurant", expression = "java(getIndustryFlag(journeyData, CustomerConstants.INDUSTRY_HOTEL_AND_RESTAURANT))")
    @Mapping(target = "industryOther", expression = "java(getIndustryFlag(journeyData, CustomerConstants.INDUSTRY_OTHER))")
    @Mapping(target = "otherDescription", expression = "java(getIndustryDescription(journeyData, CustomerConstants.INDUSTRY_OTHER))")
    @Mapping(target = "itConsultancy", expression = "java(getITCIndustryFlag(journeyData))")
    @Mapping(target = "publicServices", expression = "java(getPSFIndustryFlag(journeyData))")
    @Mapping(target = "financeBanking", expression = "java(getFBIIndustryFlag(journeyData))")

    @Mapping(target = "annualIncome", expression = "java(CustomerUtil.getValueByPath(journeyData, CustomerConstants.CUSTOMER_DETAILS, CustomerConstants.EMPLOYMENT_ANNUAL_INCOME_PATH))")
    @Mapping(target = "employerPinCode", expression = "java(CustomerUtil.getValueByPath(journeyData, CustomerConstants.CUSTOMER_DETAILS, CustomerConstants.EMPLOYMENT_PIN_CODE_PATH))")
    @Mapping(target = "netWorth", expression = "java(CustomerUtil.getValueByPath(journeyData, CustomerConstants.CUSTOMER_DETAILS, CustomerConstants.EMPLOYMENT_NET_WORTH_PATH))")

    @Mapping(target = "sourceEarningFromWork", expression = "java(getSourceOfIncomeFlag(journeyData, CustomerConstants.SOURCE_EARNING_FROM_WORK))")
    @Mapping(target = "sourceBusinessIncome", expression = "java(getSourceOfIncomeFlag(journeyData, CustomerConstants.SOURCE_EARNING_FROM_BUSINESS))")
    @Mapping(target = "sourceInheritance", expression = "java(getSourceOfIncomeFlag(journeyData, CustomerConstants.SOURCE_INHERITANCE))")
    @Mapping(target = "sourceInvestmentIncome", expression = "java(getSourceOfIncomeFlag(journeyData, CustomerConstants.SOURCE_INVESTMENT))")
    @Mapping(target = "sourceSaleOfAsset", expression = "java(getSourceOfIncomeFlag(journeyData, CustomerConstants.SOURCE_SALE_OF_AN_ASSET))")
    @Mapping(target = "sourceLottery", expression = "java(getSourceOfIncomeFlag(journeyData, CustomerConstants.SOURCE_LOTTERY))")
    @Mapping(target = "sourceEarningFromSpouseFamily", expression = "java(getSourceOfIncomeFlag(journeyData, CustomerConstants.SOURCE_EARNING_FROM_SPOUSE_FAMILY))")

    @Mapping(target = "residenceOwned", expression = "java(checkResidenceType(journeyData, CustomerConstants.RESIDENCE_OWNED))")
    @Mapping(target = "residenceRented", expression = "java(checkResidenceType(journeyData, CustomerConstants.RESIDENCE_RENTED_LEASED))")
    @Mapping(target = "residenceAncestral", expression = "java(checkResidenceType(journeyData, CustomerConstants.RESIDENCE_ANCESTRAL_FAMILY))")
    @Mapping(target = "residenceCompany", expression = "java(checkResidenceType(journeyData, CustomerConstants.RESIDENCE_COMPANY))")
    @Mapping(target = "residenceOther", expression = "java(checkResidenceType(journeyData, CustomerConstants.RESIDENCE_OTHER))")

    @Mapping(target = "purposeOffshoreDeposit", expression = "java(checkPurposeOfAccount(journeyData, CustomerConstants.PURPOSE_OFFSHORE_DEPOSIT))")
    @Mapping(target = "purposeInvestment", expression = "java(checkPurposeOfAccount(journeyData, CustomerConstants.PURPOSE_INVESTMENT))")
    @Mapping(target = "purposeLoan", expression = "java(checkPurposeOfAccount(journeyData, CustomerConstants.PURPOSE_APPLY_FOR_LOAN))")
    @Mapping(target = "purposeOther", expression = "java(checkPurposeOfAccount(journeyData, CustomerConstants.PURPOSE_OTHER))")

    @Mapping(
            target = "numberOfTransactions",
            expression = "java(java.util.Optional.ofNullable(CustomerUtil.convertToDouble(CustomerUtil.getValueByPath(journeyData, CustomerConstants.CUSTOMER_DETAILS, CustomerConstants.EMPLOYMENT_MONTHLY_TRANSACTION_PATH)))" +
                    ".map(Double::intValue).orElse(null))"
    )

    @Mapping(
            target = "transactionAmount",
            expression = "java(java.util.Optional.ofNullable(CustomerUtil.convertToDouble(CustomerUtil.getValueByPath(journeyData, CustomerConstants.CUSTOMER_DETAILS, CustomerConstants.EMPLOYMENT_MONTHLY_AMOUNT_PATH)))" +
                    ".map(Double::longValue).orElse(null))"
    )

    @Mapping(target = "pepY", expression = "java(checkPepFlag(journeyData, CustomerConstants.PEP_YES))")
    @Mapping(target = "pepN", expression = "java(checkPepFlag(journeyData, CustomerConstants.PEP_NO))")

    @Mapping(target = "cntryTax1", expression = "java(getFatcaValue(journeyData, FcIndiaProfile.CustomerFATCADetail::getCodTaxCntry1))")
    @Mapping(target = "cntryTax2", expression = "java(getFatcaValue(journeyData, FcIndiaProfile.CustomerFATCADetail::getCodTaxCntry2))")
    @Mapping(target = "cntryTax3", expression = "java(getFatcaValue(journeyData, FcIndiaProfile.CustomerFATCADetail::getCodTaxCntry3))")

    @Mapping(target = "taxID1", expression = "java(getFatcaValue(journeyData, FcIndiaProfile.CustomerFATCADetail::getTinNo1))")
    @Mapping(target = "taxID2", expression = "java(getFatcaValue(journeyData, FcIndiaProfile.CustomerFATCADetail::getTinNo2))")
    @Mapping(target = "taxID3", expression = "java(getFatcaValue(journeyData, FcIndiaProfile.CustomerFATCADetail::getTinNo3))")

    @Mapping(target = "currencyUsd", expression = "java(checkCurrency(journeyData, CustomerConstants.USD))")
    @Mapping(target = "currencyGbp", expression = "java(checkCurrency(journeyData, CustomerConstants.GBP))")
    @Mapping(target = "currencyEur", expression = "java(checkCurrency(journeyData, CustomerConstants.EUR))")
    @Mapping(target = "currencyAud", expression = "java(checkCurrency(journeyData, CustomerConstants.AUD))")
    @Mapping(target = "currencyCad", expression = "java(checkCurrency(journeyData, CustomerConstants.CAD))")
    @Mapping(target = "currencyOther", expression = "java(checkCurrency(journeyData, CustomerConstants.OTHER))")

    @Mapping(target = "otherCurrency", expression = "java(getOtherCurrency(journeyData))")

    @Mapping(target = "nomineeY", expression = "java(checkNominee(journeyData, false))")
    @Mapping(target = "nomineeN", expression = "java(checkNominee(journeyData, true))")

    @Mapping(target = "nomineeName", expression = "java(getNomineeName(journeyData))")
    @Mapping(target = "nomineeAddress", expression = "java(getNomineeAddress(journeyData))")
    @Mapping(target = "nomineeCity", expression = "java(getNomineeCity(journeyData))")
    @Mapping(target = "nomineeState", expression = "java(getNomineeState(journeyData))")
    @Mapping(target = "nomineeCountry", expression = "java(getNomineeCountry(journeyData))")
    @Mapping(target = "nomineePinCode", expression = "java(getNomineePinCode(journeyData))")
    @Mapping(target = "nomineeMobile", expression = "java(getNomineeMobile(journeyData))")
    @Mapping(target = "nomineeEmail", expression = "java(getNomineeEmail(journeyData))")
    @Mapping(target = "nomineeRelation", expression = "java(getNomineeRelation(journeyData))")
    @Mapping(target = "nomineeDob", expression = "java(CommonUtil.formatDob(getNomineeDob(journeyData)))")

    @Mapping(target = "guardianName", expression = "java(getGuardianName(journeyData))")
    @Mapping(target = "guardianAddress", expression = "java(getGuardianAddress(journeyData))")

    @Mapping(target = "accountNumber", expression = "java(CustomerUtil.getPrimaryProfile(journeyData).map(p -> p.getCustomerAccountDetails().get(0).getAccountNumber()).orElse(null))")
    @Mapping(target = "branchName", expression = "java(branchName)")
    @Mapping(target = "branchCode", expression = "java(branchCode)")
    @Mapping(target = "productCode", expression = "java(productCode)")
    @Mapping(target = "portfolioCode", expression = "java(getLgCode(journeyData))")
    @Mapping(target = "ftf", expression = "java(mapftfCheckbox(journeyData))")
    @Mapping(target = "nftf", expression = "java(mapNftfCheckbox(journeyData))")
    @Mapping(target = "occupationSince", expression = "java(CommonUtil.formatDob(CustomerUtil.getValueByPath(journeyData, CustomerConstants.CUSTOMER_DETAILS, CustomerConstants.EMPLOYMENT_OCCUPATION_SINCE_PATH)))")

    AofWithAnnextureData.AofData toAofData(JourneyData journeyData, String branchName, String branchCode, String productCode);

    @Mapping(target = "fullName", source = "fullName")

    @Mapping(target = "customerRisk", expression = "java(getScore(risk.getCustomerRisk()))")
    @Mapping(target = "jurisdictionRisk", expression = "java(getScore(risk.getJurisdictionRisk()))")
    @Mapping(target = "interfaceRisk", expression = "java(getScore(risk.getInterfaceRisk()))")
    @Mapping(target = "productRisk", expression = "java(getScore(risk.getProductRisk()))")
    @Mapping(target = "adverseRisk", expression = "java(getScore(risk.getAdverseMediaRisk()))")
    @Mapping(target = "expRisk", expression = "java(getScore(risk.getTransactionRisk()))")

    @Mapping(target = "weightedCustomerRisk", expression = "java(getWeighted(risk.getCustomerRisk()))")
    @Mapping(target = "weightedJurisdictionRisk", expression = "java(getWeighted(risk.getJurisdictionRisk()))")
    @Mapping(target = "weightedInterfaceRisk", expression = "java(getWeighted(risk.getInterfaceRisk()))")
    @Mapping(target = "weightedProductRisk", expression = "java(getWeighted(risk.getProductRisk()))")
    @Mapping(target = "weightedAdverseRisk", expression = "java(getWeighted(risk.getAdverseMediaRisk()))")
    @Mapping(target = "weightedExpRisk", expression = "java(getWeighted(risk.getTransactionRisk()))")

    @Mapping(target = "customerRiskHigh", expression = "java(getHigh(risk.getCustomerRisk()))")
    @Mapping(target = "customerRiskMedium", expression = "java(getMedium(risk.getCustomerRisk()))")
    @Mapping(target = "customerRiskLow", expression = "java(getLow(risk.getCustomerRisk()))")

    @Mapping(target = "jurisdictionRiskHigh", expression = "java(getHigh(risk.getJurisdictionRisk()))")
    @Mapping(target = "jurisdictionRiskMedium", expression = "java(getMedium(risk.getJurisdictionRisk()))")
    @Mapping(target = "jurisdictionRiskLow", expression = "java(getLow(risk.getJurisdictionRisk()))")

    @Mapping(target = "interfaceRiskHigh", expression = "java(getHigh(risk.getInterfaceRisk()))")
    @Mapping(target = "interfaceRiskLow", expression = "java(getLow(risk.getInterfaceRisk()))")

    @Mapping(target = "productRiskMedium", expression = "java(getMedium(risk.getProductRisk()))")

    @Mapping(target = "adverseRiskLow", expression = "java(getLow(risk.getAdverseMediaRisk()))")

    @Mapping(target = "expRiskHigh", expression = "java(getHigh(risk.getTransactionRisk()))")
    @Mapping(target = "expRiskMed", expression = "java(getMedium(risk.getTransactionRisk()))")
    @Mapping(target = "expRiskLow", expression = "java(getLow(risk.getTransactionRisk()))")

    @Mapping(target = "totalWeightedScore", expression = "java(getTotal(risk.getTotalWeightedScore()))")
    @Mapping(target = "totalCddLevel", source = "risk.cddLevel")
    @Mapping(target = "pep", expression = "java(mapPepCheckbox(journeyData))")
    @Mapping(target = "cnftf", expression = "java(mapNftfCheckbox(journeyData))")
    AofWithAnnextureData.RiskAnalysisData toRiskAnalysis(RiskAssessmentPageData risk, String fullName, JourneyData journeyData);

    default ReviewCustomerResponse.ReviewCustomerDetails.Nominee getJourneyNominee(JourneyData journeyData) {

        ReviewCustomerResponse.ReviewCustomerDetails.NomineeDetail nomineeDetail =
                CustomerUtil.getNomineeDetailFromJourneyData(journeyData);

        return nomineeDetail != null ? nomineeDetail.getNominee() : null;
    }

    default boolean isAddressFromProfile(JourneyData journeyData) {

        String value = CustomerUtil.getValueByPath(
                journeyData,
                CustomerConstants.NOMINEE_DETAILS,
                CustomerConstants.NOMINEE_ADDRESS_FROM_PROFILE_PATH
        );

        return Boolean.parseBoolean(value);
    }

    default boolean isGuardianAddressSameAsNominee(JourneyData journeyData) {

        String value = CustomerUtil.getValueByPath(
                journeyData,
                CustomerConstants.NOMINEE_DETAILS,
                CustomerConstants.GUARDIAN_ADDRESS_SAME_AS_NOMINEE_PATH
        );

        return Boolean.parseBoolean(value);
    }

    default String getNomineeName(JourneyData journeyData) {

        if (isAddressFromProfile(journeyData)) {
            ReviewCustomerResponse.ReviewCustomerDetails.Nominee nominee = getJourneyNominee(journeyData);
            return nominee != null ? nominee.getName() : null;
        }

        return CustomerUtil.getValueByPath(journeyData,
                CustomerConstants.NOMINEE_DETAILS,
                CustomerConstants.NOMINEE_NAME_PATH);
    }

    default String getNomineeAddress(JourneyData journeyData) {

        if (isAddressFromProfile(journeyData)) {

            ReviewCustomerResponse.ReviewCustomerDetails.Nominee nominee = getJourneyNominee(journeyData);

            return nominee == null ? null : joinAddress(
                    nominee.getAddressLine1(),
                    nominee.getAddressLine2(),
                    nominee.getAddressLine3(),
                    nominee.getAddressLine4());
        }

        return joinAddress(
                CustomerUtil.getValueByPath(journeyData, CustomerConstants.NOMINEE_DETAILS, CustomerConstants.NOMINEE_ADDRESS1_PATH),
                CustomerUtil.getValueByPath(journeyData, CustomerConstants.NOMINEE_DETAILS, CustomerConstants.NOMINEE_ADDRESS2_PATH),
                CustomerUtil.getValueByPath(journeyData, CustomerConstants.NOMINEE_DETAILS, CustomerConstants.NOMINEE_ADDRESS3_PATH),
                CustomerUtil.getValueByPath(journeyData, CustomerConstants.NOMINEE_DETAILS, CustomerConstants.NOMINEE_ADDRESS4_PATH));
    }

    default String getNomineeCity(JourneyData journeyData) {

        if (isAddressFromProfile(journeyData)) {
            ReviewCustomerResponse.ReviewCustomerDetails.Nominee nominee = getJourneyNominee(journeyData);
            return nominee != null ? nominee.getCity() : null;
        }

        return CustomerUtil.getValueByPath(journeyData,
                CustomerConstants.NOMINEE_DETAILS,
                CustomerConstants.NOMINEE_CITY_PATH);
    }

    default String getNomineeState(JourneyData journeyData) {

        if (isAddressFromProfile(journeyData)) {
            ReviewCustomerResponse.ReviewCustomerDetails.Nominee nominee = getJourneyNominee(journeyData);
            return nominee != null ? nominee.getState() : null;
        }

        return CustomerUtil.getValueByPath(journeyData,
                CustomerConstants.NOMINEE_DETAILS,
                CustomerConstants.NOMINEE_STATE_PATH);
    }

    default String getNomineeCountry(JourneyData journeyData) {

        if (isAddressFromProfile(journeyData)) {
            ReviewCustomerResponse.ReviewCustomerDetails.Nominee nominee = getJourneyNominee(journeyData);
            return nominee != null ? nominee.getCountry() : null;
        }

        return CustomerUtil.getValueByPath(journeyData,
                CustomerConstants.NOMINEE_DETAILS,
                CustomerConstants.NOMINEE_COUNTRY_PATH);
    }

    default String getNomineePinCode(JourneyData journeyData) {

        if (isAddressFromProfile(journeyData)) {
            ReviewCustomerResponse.ReviewCustomerDetails.Nominee nominee = getJourneyNominee(journeyData);
            return nominee != null ? nominee.getPincode() : null;
        }

        return CustomerUtil.getValueByPath(journeyData,
                CustomerConstants.NOMINEE_DETAILS,
                CustomerConstants.NOMINEE_PINCODE_PATH);
    }

    default String getNomineeMobile(JourneyData journeyData) {

        if (isAddressFromProfile(journeyData)) {
            ReviewCustomerResponse.ReviewCustomerDetails.Nominee nominee = getJourneyNominee(journeyData);
            return nominee != null ? nominee.getMobileNumber() : null;
        }

        return CustomerUtil.getValueByPath(journeyData,
                CustomerConstants.NOMINEE_DETAILS,
                CustomerConstants.NOMINEE_MOBILE_PATH);
    }

    default String getNomineeEmail(JourneyData journeyData) {

        if (isAddressFromProfile(journeyData)) {
            ReviewCustomerResponse.ReviewCustomerDetails.Nominee nominee = getJourneyNominee(journeyData);
            return nominee != null ? nominee.getEmailId() : null;
        }

        return CustomerUtil.getValueByPath(journeyData,
                CustomerConstants.NOMINEE_DETAILS,
                CustomerConstants.NOMINEE_EMAIL_PATH);
    }

    default String getNomineeRelation(JourneyData journeyData) {

        if (isAddressFromProfile(journeyData)) {
            ReviewCustomerResponse.ReviewCustomerDetails.Nominee nominee = getJourneyNominee(journeyData);
            return nominee != null ? nominee.getRelation() : null;
        }

        return CustomerUtil.getValueByPath(journeyData,
                CustomerConstants.NOMINEE_DETAILS,
                CustomerConstants.NOMINEE_RELATION_PATH);
    }

    default String getNomineeDob(JourneyData journeyData) {

        if (isAddressFromProfile(journeyData)) {
            ReviewCustomerResponse.ReviewCustomerDetails.Nominee nominee = getJourneyNominee(journeyData);
            return nominee != null ? nominee.getDob() : null;
        }

        return CustomerUtil.getValueByPath(journeyData,
                CustomerConstants.NOMINEE_DETAILS,
                CustomerConstants.NOMINEE_DOB_PATH);
    }

    default String getGuardianName(JourneyData journeyData) {

        if (isGuardianAddressSameAsNominee(journeyData)) {
            return getNomineeName(journeyData);
        }

        return CustomerUtil.getValueByPath(
                journeyData,
                CustomerConstants.NOMINEE_DETAILS,
                CustomerConstants.GUARDIAN_NAME_PATH);
    }

    default String getGuardianAddress(JourneyData journeyData) {

        if (isGuardianAddressSameAsNominee(journeyData)) {
            return getNomineeAddress(journeyData);
        }

        return joinAddress(
                CustomerUtil.getValueByPath(journeyData, CustomerConstants.NOMINEE_DETAILS, CustomerConstants.GUARDIAN_ADDRESS1_PATH),
                CustomerUtil.getValueByPath(journeyData, CustomerConstants.NOMINEE_DETAILS, CustomerConstants.GUARDIAN_ADDRESS2_PATH),
                CustomerUtil.getValueByPath(journeyData, CustomerConstants.NOMINEE_DETAILS, CustomerConstants.GUARDIAN_ADDRESS3_PATH),
                CustomerUtil.getValueByPath(journeyData, CustomerConstants.NOMINEE_DETAILS, CustomerConstants.GUARDIAN_ADDRESS4_PATH),
                CustomerUtil.getValueByPath(journeyData, CustomerConstants.NOMINEE_DETAILS, CustomerConstants.GUARDIAN_PIN_CODE));
    }


    default String getDesignation(JourneyData journeyData) {

        String designation = CustomerUtil.getValueByPath(
                journeyData,
                CustomerConstants.CUSTOMER_DETAILS,
                CustomerConstants.EMPLOYMENT_DESIGNATION_PATH
        );

        String specialisation = CustomerUtil.getValueByPath(
                journeyData,
                CustomerConstants.CUSTOMER_DETAILS,
                CustomerConstants.EMPLOYMENT_SPECIALISATION_PATH
        );

        return designation != null && !designation.isBlank()
                ? designation
                : specialisation;
    }

    default String getScore(RiskAssessmentPageData.RiskBlock block) {
        return block != null && block.getScore() != null ? String.valueOf(block.getScore()) : null;
    }

    default String getWeighted(RiskAssessmentPageData.RiskBlock block) {
        return block != null && block.getWeightedScore() != null ? String.valueOf(block.getWeightedScore()) : null;
    }

    default String getTotal(Integer value) {
        return value != null ? String.valueOf(value) : null;
    }

    default String getHigh(RiskAssessmentPageData.RiskBlock b) {
        return (b != null && CustomerConstants.HIGH.equalsIgnoreCase(b.getAssessment())) ? String.valueOf(b.getScore()) : null;
    }

    default String getMedium(RiskAssessmentPageData.RiskBlock b) {
        return (b != null && CustomerConstants.MEDIUM.equalsIgnoreCase(b.getAssessment())) ? String.valueOf(b.getScore()) : null;
    }

    default String getLow(RiskAssessmentPageData.RiskBlock b) {
        return (b != null && CustomerConstants.LOW.equalsIgnoreCase(b.getAssessment())) ? String.valueOf(b.getScore()) : null;
    }


    default FcIndiaProfile.CustomerFATCADetail getFatca(JourneyData journeyData) {
        return CustomerUtil.getPrimaryProfile(journeyData)
                .map(FcIndiaProfile.Profile::getCustomerFATCADetails)
                .filter(list -> !list.isEmpty())
                .map(list -> list.get(0))
                .orElse(null);
    }

    default <T> T getProfileValue(JourneyData journeyData, Function<FcIndiaProfile.Profile, T> extractor) {
        return CustomerUtil.getPrimaryProfile(journeyData)
                .map(extractor)
                .orElse(null);
    }

    default String  getFatcaValue(JourneyData journeyData, Function<FcIndiaProfile.CustomerFATCADetail, String> extractor) {
        return Optional.ofNullable(getFatca(journeyData))
                .map(extractor)
                .orElse(null);
    }

    default Integer getFatcaInteger(JourneyData journeyData, Function<FcIndiaProfile.CustomerFATCADetail, String> extractor) {

        return Optional.ofNullable(getFatca(journeyData))
                .map(extractor)
                .map(String::trim)
                .map(Integer::valueOf)
                .orElse(null);
    }

    default String getCheckboxValue(String actualValue, String expectedValue) {
        return expectedValue.equalsIgnoreCase(actualValue)
                ? CustomerConstants.CHECKED
                : CustomerConstants.UNCHECKED;
    }

    default String getQualificationFlag(JourneyData journeyData, String expectedQualification) {

        String qualification = CustomerUtil.getValueByPath(
                journeyData,
                CustomerConstants.CUSTOMER_DETAILS,
                CustomerConstants.EMPLOYMENT_QUALIFICATION_PATH
        );

        if (CustomerConstants.QUALIFICATION_OTHER.equalsIgnoreCase(expectedQualification)) {

            return !CustomerConstants.QUALIFICATION_SECONDARY.equalsIgnoreCase(qualification)
                    && !CustomerConstants.QUALIFICATION_HIGHER_SECONDARY.equalsIgnoreCase(qualification)
                    && !CustomerConstants.QUALIFICATION_GRADUATE.equalsIgnoreCase(qualification)
                    && !CustomerConstants.QUALIFICATION_POST_GRADUATE.equalsIgnoreCase(qualification)
                    ? CustomerConstants.CHECKED
                    : CustomerConstants.UNCHECKED;
        }

        return getCheckboxValue(qualification, expectedQualification);
    }

    default String getOccupationFlag(JourneyData journeyData, String expectedOccupation) {

        String occupation = CustomerUtil.getValueByPath(
                journeyData,
                CustomerConstants.CUSTOMER_DETAILS,
                CustomerConstants.EMPLOYMENT_OCCUPATION_PATH
        );

        if (CustomerConstants.OCCUPATION_OTHER.equalsIgnoreCase(expectedOccupation)) {

            return !CustomerConstants.OCCUPATION_SALARIED.equalsIgnoreCase(occupation)
                    && !CustomerConstants.OCCUPATION_SELF_EMPLOYED_BUSINESS.equalsIgnoreCase(occupation)
                    && !CustomerConstants.OCCUPATION_HOUSEWIFE.equalsIgnoreCase(occupation)
                    && !CustomerConstants.OCCUPATION_PROFESSIONAL.equalsIgnoreCase(occupation)
                    && !CustomerConstants.OCCUPATION_RETIRED.equalsIgnoreCase(occupation)
                    && !CustomerConstants.OCCUPATION_STUDENT.equalsIgnoreCase(occupation)
                    ? CustomerConstants.CHECKED
                    : CustomerConstants.UNCHECKED;
        }

        return getCheckboxValue(occupation, expectedOccupation);
    }

    default String getIndustryFlag(JourneyData journeyData, String expectedIndustry) {

        String industry = CustomerUtil.getValueByPath(
                journeyData,
                CustomerConstants.CUSTOMER_DETAILS,
                CustomerConstants.EMPLOYMENT_INDUSTRY_PATH
        );

        if (CustomerConstants.INDUSTRY_OTHER.equalsIgnoreCase(expectedIndustry)) {

            if (industry == null || industry.isBlank()) {
                return CustomerConstants.UNCHECKED;
            }

            return !CustomerConstants.INDUSTRY_MANUFACTURING.equalsIgnoreCase(industry)
                    && !CustomerConstants.INDUSTRY_RETAIL_TRADE.equalsIgnoreCase(industry)
                    && !CustomerConstants.INDUSTRY_IMPORT_EXPORT.equalsIgnoreCase(industry)
                    && !CustomerConstants.INDUSTRY_HOTEL_AND_RESTAURANT.equalsIgnoreCase(industry)
                    && !CustomerConstants.INDUSTRY_INFORMATION_TECHNOLOGY.equalsIgnoreCase(industry)
                    && !CustomerConstants.INDUSTRY_CONSULTANCY.equalsIgnoreCase(industry)
                    && !CustomerConstants.INDUSTRY_PUBLIC_SERVICES.equalsIgnoreCase(industry)
                    && !CustomerConstants.INDUSTRY_FINANCE_BANKING_INSURANCE.equalsIgnoreCase(industry)
                    ? CustomerConstants.CHECKED
                    : CustomerConstants.UNCHECKED;
        }

        return getCheckboxValue(industry, expectedIndustry);
    }

    default String getIndustryDescription(JourneyData journeyData, String expectedIndustry) {

        if (!CustomerConstants.CHECKED.equals(getIndustryFlag(journeyData, expectedIndustry))) {
            return null;
        }

        return CustomerUtil.getValueByPath(
                journeyData,
                CustomerConstants.CUSTOMER_DETAILS,
                CustomerConstants.EMPLOYMENT_INDUSTRY_VARIATION_PATH
        );
    }

    default String getITCIndustryFlag(JourneyData journeyData) {

        String industry = CustomerUtil.getValueByPath(
                journeyData,
                CustomerConstants.CUSTOMER_DETAILS,
                CustomerConstants.EMPLOYMENT_INDUSTRY_PATH
        );

        return CustomerConstants.INDUSTRY_INFORMATION_TECHNOLOGY.equalsIgnoreCase(industry)
                || CustomerConstants.INDUSTRY_CONSULTANCY.equalsIgnoreCase(industry)
                ? CustomerConstants.CHECKED
                : CustomerConstants.UNCHECKED;
    }

    default String getPSFIndustryFlag(JourneyData journeyData) {

        String industry = CustomerUtil.getValueByPath(
                journeyData,
                CustomerConstants.CUSTOMER_DETAILS,
                CustomerConstants.EMPLOYMENT_INDUSTRY_PATH
        );

        return CustomerConstants.INDUSTRY_PUBLIC_SERVICES.equalsIgnoreCase(industry)
                ? CustomerConstants.CHECKED
                : CustomerConstants.UNCHECKED;
    }

    default String getFBIIndustryFlag(JourneyData journeyData) {

        String industry = CustomerUtil.getValueByPath(
                journeyData,
                CustomerConstants.CUSTOMER_DETAILS,
                CustomerConstants.EMPLOYMENT_INDUSTRY_PATH
        );

        return CustomerConstants.INDUSTRY_FINANCE_BANKING_INSURANCE.equalsIgnoreCase(industry)
                ? CustomerConstants.CHECKED
                : CustomerConstants.UNCHECKED;
    }

    default String getSourceOfIncomeFlag(JourneyData journeyData, String expectedSource) {

        String source = CustomerUtil.getValueByPath(
                journeyData,
                CustomerConstants.CUSTOMER_DETAILS,
                CustomerConstants.EMPLOYMENT_SOURCE_OF_INCOME_PATH
        );

        return getCheckboxValue(source, expectedSource);
    }

    default String checkResidenceType(JourneyData journeyData, String expectedValue) {

        String residenceType = CustomerUtil.getValueByPath(
                journeyData,
                CustomerConstants.CUSTOMER_DETAILS,
                CustomerConstants.FATCA_RESIDENCE_TYPE_PATH
        );

        if (CustomerConstants.RESIDENCE_OTHER.equalsIgnoreCase(expectedValue)) {

            return !CustomerConstants.RESIDENCE_OWNED.equalsIgnoreCase(residenceType)
                    && !CustomerConstants.RESIDENCE_RENTED_LEASED.equalsIgnoreCase(residenceType)
                    && !CustomerConstants.RESIDENCE_ANCESTRAL_FAMILY.equalsIgnoreCase(residenceType)
                    && !CustomerConstants.RESIDENCE_COMPANY.equalsIgnoreCase(residenceType)
                    ? CustomerConstants.CHECKED
                    : CustomerConstants.UNCHECKED;
        }

        return getCheckboxValue(residenceType, expectedValue);
    }



    default String checkPurposeOfAccount(JourneyData journeyData, String expectedValue) {

        String purpose = CustomerUtil.getValueByPath(
                journeyData,
                CustomerConstants.CUSTOMER_DETAILS,
                CustomerConstants.EMPLOYMENT_PURPOSE_OF_ACCOUNT_PATH
        );

        if (CustomerConstants.PURPOSE_OTHER.equalsIgnoreCase(expectedValue)) {

            return !CustomerConstants.PURPOSE_OFFSHORE_DEPOSIT.equalsIgnoreCase(purpose)
                    && !CustomerConstants.PURPOSE_INVESTMENT.equalsIgnoreCase(purpose)
                    && !CustomerConstants.PURPOSE_APPLY_FOR_LOAN.equalsIgnoreCase(purpose)
                    ? CustomerConstants.CHECKED
                    : CustomerConstants.UNCHECKED;
        }

        return getCheckboxValue(purpose, expectedValue);
    }

    default String checkPepFlag(JourneyData journeyData, String expectedValue) {

        String pep = CustomerUtil.getValueByPath(
                journeyData,
                CustomerConstants.CUSTOMER_DETAILS,
                CustomerConstants.PEP_PATH
        );

        return getCheckboxValue(pep, expectedValue);
    }

    default String checkCurrency(JourneyData journeyData, String expectedCurrency) {

        String currency = CustomerUtil.getValueByPath(
                journeyData,
                CustomerConstants.CUSTOMER_DETAILS,
                CustomerConstants.EMPLOYMENT_CURRENCY_PATH
        );

        if (CustomerConstants.OTHER.equalsIgnoreCase(expectedCurrency)) {

            return !CustomerConstants.USD.equalsIgnoreCase(currency)
                    && !CustomerConstants.GBP.equalsIgnoreCase(currency)
                    && !CustomerConstants.EUR.equalsIgnoreCase(currency)
                    && !CustomerConstants.AUD.equalsIgnoreCase(currency)
                    && !CustomerConstants.CAD.equalsIgnoreCase(currency)
                    ? CustomerConstants.CHECKED
                    : CustomerConstants.UNCHECKED;
        }

        return getCheckboxValue(currency, expectedCurrency);
    }

    default String getOtherCurrency(JourneyData journeyData) {

        String currency = CustomerUtil.getValueByPath(
                journeyData,
                CustomerConstants.CUSTOMER_DETAILS,
                CustomerConstants.EMPLOYMENT_CURRENCY_PATH
        );

        if (currency == null) return null;

        if (CustomerConstants.USD.equalsIgnoreCase(currency)
                || CustomerConstants.GBP.equalsIgnoreCase(currency)
                || CustomerConstants.EUR.equalsIgnoreCase(currency)
                || CustomerConstants.AUD.equalsIgnoreCase(currency)
                || CustomerConstants.CAD.equalsIgnoreCase(currency)) {
            return null;
        }

        return currency;
    }

    default String checkCustomerTitle(JourneyData journeyData, String expectedTitle) {

        String title = getProfileValue(journeyData, FcIndiaProfile.Profile::getCustomerTitle);

        if (CustomerConstants.TITLE_OTHER.equalsIgnoreCase(expectedTitle)) {

            return !CustomerConstants.TITLE_MR.equalsIgnoreCase(title)
                    && !CustomerConstants.TITLE_MS.equalsIgnoreCase(title)
                    && !CustomerConstants.TITLE_DR.equalsIgnoreCase(title)
                    ? CustomerConstants.CHECKED
                    : CustomerConstants.UNCHECKED;
        }

        return getCheckboxValue(title, expectedTitle);
    }

    default String checkMaritalStatus(JourneyData journeyData, String expectedStatus) {

        String status = CustomerUtil.getValueByPath(
                journeyData,
                CustomerConstants.CUSTOMER_DETAILS,
                CustomerConstants.FATCA_MARITAL_STATUS_PATH
        );

        return getCheckboxValue(status, expectedStatus);
    }

    default String getGenderFlag(JourneyData journeyData, String expectedGender) {
        String gender = getProfileValue(journeyData, FcIndiaProfile.Profile::getTxtCustSex);
        return getCheckboxValue(gender, expectedGender);
    }

    default String joinAddress(String... parts) {
        String address = Stream.of(parts)
                .filter(s -> s != null && !s.trim().isEmpty())
                .collect(Collectors.joining(", "));
        return address.isEmpty() ? null : address;
    }

    default String checkNominee(JourneyData journeyData, boolean expectedValue) {

        String raw = CustomerUtil.getValueByPath(
                journeyData,
                CustomerConstants.NOMINEE_DETAILS,
                CustomerConstants.NOMINEE_NO_NOMINEE_PATH
        );

        if (raw == null)  return CustomerConstants.UNCHECKED;
        boolean noNominee = Boolean.parseBoolean(raw);

        return noNominee == expectedValue ? CustomerConstants.CHECKED : CustomerConstants.UNCHECKED;
    }

    default String getLgCode(JourneyData journeyData) {
        Map<String, Object> customerUserInputs = JourneyService.getDomainPageUserInputs(journeyData, REVIEW_DETAILS);

        if (customerUserInputs == null || customerUserInputs.isEmpty()) {
            return MKTG;
        }

        String lgCode = Objects.toString(customerUserInputs.get(LG_CODE_PATH), "").trim();
        return lgCode.isEmpty() ? MKTG : lgCode;
    }


    default String mapPepCheckbox(JourneyData journeyData) {
        String pep = CustomerUtil.getValueByPath(journeyData, CustomerConstants.CUSTOMER_DETAILS, CustomerConstants.EMPLOYMENT_PEP_PATH);
        return CustomerConstants.YES.equalsIgnoreCase(pep) ? CustomerConstants.CHECKED: CustomerConstants.UNCHECKED;
    }


    default String mapNftfCheckbox(JourneyData journeyData) {

        String profileKycType = getProfileValue(journeyData, FcIndiaProfile.Profile::getKycType);
        return CustomerConstants.NFTF.equalsIgnoreCase(profileKycType) ?  CustomerConstants.CHECKED: CustomerConstants.UNCHECKED;
    }

    default String mapftfCheckbox(JourneyData journeyData) {

        String profileKycType = getProfileValue(journeyData, FcIndiaProfile.Profile::getKycType);
        return CustomerConstants.FTF.equalsIgnoreCase(profileKycType) ?  CustomerConstants.CHECKED: CustomerConstants.UNCHECKED;
    }

    default String checkDivorcedOrSeparated(JourneyData journeyData) {

        String status = CustomerUtil.getValueByPath(journeyData, CustomerConstants.CUSTOMER_DETAILS, CustomerConstants.FATCA_MARITAL_STATUS_PATH);
        return CustomerConstants.DIVORCED.equalsIgnoreCase(status) || CustomerConstants.SEPARATED.equalsIgnoreCase(status) ? CustomerConstants.CHECKED : CustomerConstants.UNCHECKED;
    }

}
