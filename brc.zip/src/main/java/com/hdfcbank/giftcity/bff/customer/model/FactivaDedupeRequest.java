package com.hdfcbank.giftcity.bff.customer.model;

import lombok.*;

@Builder
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class FactivaDedupeRequest {
    private String requestorUserID;
    private String customerName;
    private String dateOfBirth;
    private String emailID;
    private String mobileNo;
    private String panNo;
}