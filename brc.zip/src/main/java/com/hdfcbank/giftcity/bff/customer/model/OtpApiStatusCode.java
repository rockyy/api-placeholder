package com.hdfcbank.giftcity.bff.customer.model;

import com.hdfcbank.common.models.vo.core.ApiResponseStatusCodeLiteral;
import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum OtpApiStatusCode implements ApiResponseStatusCodeLiteral {
    SUCCESS("0000", "Success"),
    INVALID_REQUEST("9000", "Request failed"),
    OTP_MISMATCHED("8003", "OTP_MISMATCHED"),
    OTP_EXPIRED("8004", "OTP_EXPIRED"),
    INTERNAL_SERVER_ERROR("9000", "Internal server error"),
    DOWNSTREAM_ERROR("9001", "Downstream api error"),
    OTP_FAILED("9002", "OTP_FAILED"),
    SOA_TOKEN_FAILURE("9100", "Failed to fetch SOA token"),
    SOA_INVALID_RESPONSE("9101", "Invalid response from SOA API"),
    RESEND_OTP_FAILED("9102", "Resend OTP failed"),
    COMMUNICATION_SERVICE_ERROR("9103","Communication service returned error"),
    VERIFY_OTP_FAILED("9104","Verify OTP Failed"),
    FAILED("9003","FAILED");


    private final String code;
    private final String message;

    public static OtpApiStatusCode getCustomerApiStatus(String statusCode) {
        for (OtpApiStatusCode apiStatusCode : values()) {
            if (apiStatusCode.getCode().equals(statusCode)) {
                return apiStatusCode;
            }

        }
        return FAILED;
    }
}
