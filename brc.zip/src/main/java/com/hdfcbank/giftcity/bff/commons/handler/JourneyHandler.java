package com.hdfcbank.giftcity.bff.commons.handler;

import com.hdfcbank.giftcity.bff.commons.enums.CommonJourneyStates;

/** Common execution contract for handlers with different response types. */
public interface JourneyHandler {

    boolean preConditions(HandlerContext handlerContext);
    HandlerOutcome handle(HandlerContext handlerContext);
    Handler.HandlerType getType();
    Handler.HandlerName getName();
    CommonJourneyStates successState();
    CommonJourneyStates failureState();
}
