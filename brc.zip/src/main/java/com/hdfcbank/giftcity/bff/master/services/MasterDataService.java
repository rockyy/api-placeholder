package com.hdfcbank.giftcity.bff.master.services;

import com.hdfcbank.adapters.clients.feign.master.MasterDataFeignClient;
import com.hdfcbank.adapters.vo.FetchMasterDataRequest;
import com.hdfcbank.common.models.vo.core.PageDetail;
import com.hdfcbank.giftcity.bff.master.models.MasterDataFetchRequest;
import com.hdfcbank.giftcity.bff.master.mapper.MasterDataMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@RequiredArgsConstructor
public class MasterDataService {
    private final MasterDataFeignClient masterDataFeignClient;
    private final MasterDataMapper masterDataMapper;
    private static final String CACHE_NAME = "master-data-api-response";


    @Cacheable(cacheNames = CACHE_NAME,
            key = "#request",
            unless = "#result == null || #result.content.isEmpty()")
    public PageDetail fetch(MasterDataFetchRequest request) {
        FetchMasterDataRequest fetchMasterDataRequest = masterDataMapper.toFetchMasterDataRequest(request);
        return masterDataFeignClient.fetchData(fetchMasterDataRequest);
    }
}
