package com.hdfcbank.giftcity.bff.application.listener;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hdfcbank.common.models.vo.journey.JourneyData;
import com.hdfcbank.giftcity.bff.application.events.SqsBackgroundTaskEvent;
import com.hdfcbank.giftcity.bff.commons.enums.CommonJourneyStates;
import com.hdfcbank.giftcity.bff.commons.exception.handler.DownstreamResponseHandler;
import com.hdfcbank.giftcity.bff.commons.handler.Handler;
import com.hdfcbank.giftcity.bff.commons.handler.HandlerContext;
import com.hdfcbank.giftcity.bff.commons.handler.HandlerOutcome;
import com.hdfcbank.giftcity.bff.commons.handler.HandlersFactory;
import com.hdfcbank.giftcity.bff.commons.utility.MDCLoggerUtil;
import com.hdfcbank.giftcity.bff.commons.utility.TextSanityUtil;
import com.hdfcbank.giftcity.bff.infrastructure.service.JourneyService;
import io.awspring.cloud.sqs.annotation.SqsListener;
import io.awspring.cloud.sqs.listener.acknowledgement.Acknowledgement;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.messaging.handler.annotation.Headers;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

@Service
@Slf4j
@RequiredArgsConstructor
public class SqsBackgroundEventsListener {

    private final ObjectMapper objectMapper;
    private final HandlersFactory handlersFactory;
    private final JourneyService journeyService;

    @SqsListener(value = "${api.background-tasks-fifo.queueUrl}", acknowledgementMode = "MANUAL")
    public void sqsBackgroundEventsListener(@Payload String requestJSON, @Headers Map<String, Object> headers, Acknowledgement acknowledgement) {
        String messageId = headers.get("MessageId") != null ? headers.get("MessageId").toString() : "UNKNOWN";
        headers.forEach((k, v) -> log.info("SqsBackgroundEventsListener headers {} = {}", k, v));
        int retryCount = headers.get("Sqs_Msa_ApproximateReceiveCount") != null ? Integer.parseInt(headers.get("Sqs_Msa_ApproximateReceiveCount").toString()) : 1;
        log.info("Received SQS message. MessageId: {}, Payload: {}, Retry Count {}", TextSanityUtil.sanitize(messageId), TextSanityUtil.sanitize(requestJSON), retryCount);
        JourneyData journeyData = null;
        try {
            SqsBackgroundTaskEvent sqsBackgroundTaskEvent = objectMapper.readValue(requestJSON, SqsBackgroundTaskEvent.class);
            String journeyId = sqsBackgroundTaskEvent.getJourneyId();
            log.info("SqsBackgroundEventsListener for the journey Id {}", journeyId);

            journeyData = journeyService.fetchJourney(journeyId);
            MDCLoggerUtil.populateMDC(journeyData);

            // Set common HandlerContext for all validators!
            HandlerContext handlerContext = HandlerContext.builder()
                    .journeyData(journeyData)
                    .properties(sqsBackgroundTaskEvent.getProperties())
                    .data(new HashMap<>())
                    .build();

            handlersFactory.getHandlers(journeyData.getJourneyName(),
                    Handler.HandlerType.BACKGROUND_TASKS_POST_SUBMIT_SUCCESS, sqsBackgroundTaskEvent.getEvent().getHandlerName().name()).ifPresentOrElse(
                    handler -> {
                        log.info("Handler name {} and type {}", handler.getName(), handler.getType());
                        if (handler.preConditions(handlerContext)) {
                            HandlerOutcome result = handler.handle(handlerContext);
                            if (result == null) {
                                return;
                            }
                            if (result.isSuccess()) {
                                journeyService.recordJourneyState(journeyId, handler.successState());
                                acknowledgement.acknowledge();
                            } else {
                                log.warn("Message processing failed. It will be retried. MessageId: {}", messageId);
                                journeyService.updateJourneyDetailDropOff(journeyService.fetchJourney(journeyId),
                                        result.getApiResponseStatus(), handler.failureState());
                            }
                        } else {
                            log.info("Pre conditions not met for Handler name {} and type {}", handler.getName(), handler.getType());
                        }
                    },
                    acknowledgement::acknowledge
            );


        } catch (Exception e) {
            log.error("Unexpected error while processing message, MessageId: {} , it will be retried .. ", messageId, e);
            journeyService.updateJourneyDetailDropOff(journeyData, DownstreamResponseHandler
                            .handleResponse(null, null, false,
                                    journeyData.getJourneyName())
                    , CommonJourneyStates.BACKGROUND_TASKS_HANDLER_FAILURE);
        }
    }
}
