package com.hdfcbank.giftcity.bff.commons.properties;

import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import java.util.List;
import java.util.Map;

@Getter
@Setter
@Configuration
@ConfigurationProperties("custom-validations")
public class CustomValidationProperties {

    Map<String, CustomValidations> journeys;

    @Getter
    @Setter
    public static class CustomValidations {
        private String defaultMessageHeading;
        private String defaultMessage;
        private List<String> validators;
        private List<String> dropOffStates;
        private List<FieldDetail> fieldsDetail;

    }

    @Getter
    @Setter
    public static class DownStreamMapping {
        private String type;
        private String code;
        private String category;
        private String messageHeading;
        private String message;
    }



    @Getter
    @Setter
    public static class FieldDetail {
        private String type;
        private String code;
        private int length;
        private String allowedRegex;
        private List<String> allowedValues;
        private List<String> notAllowedValues;
        private boolean mandatory;
        private String messageHeading;
        private String message;
        private int min;
        private int max;
    }

}
