package com.hdfcbank.giftcity.bff.consent.config;

import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Getter
@Setter
@Configuration
@ConfigurationProperties("api.consents")
public class ConsentsApiProperties {
    private String productCode;
    private String journeyName;
    private String queueUrl;
}
