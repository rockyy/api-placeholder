package com.hdfcbank.giftcity.bff.customer.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class AofWithAnnextureData {

    private AofData aof;
    private RiskAnalysisData riskAnalysis;

    @Getter
    @Setter
    @ToString
    public static class AofData {

        private String dateOfApplication;

        @JsonProperty("NC")
        private String newCustomer;
        @JsonProperty("EC")
        private String existingCustomer;

        @JsonProperty("RE")
        private String realEstate;
        @JsonProperty("FD")
        private String forexDealer;
        @JsonProperty("AP")
        private String assessedProfessional;
        @JsonProperty("CI")
        private String clientRetailInvestor;
        @JsonProperty("AI")
        private String accreditedInvestor;

        private String ftf;
        private String nftf;


        @JsonProperty("customerID")
        private String customerId;

        private String fccCustomerNo;

        private String fccAccountNo;

        @JsonProperty("RI")
        private String residentIndian;
        @JsonProperty("NR")
        private String nonResidentIndian;
        @JsonProperty("FN")
        private String foreignNational;


        @JsonProperty("SN")
        private String singleNameAccount;
        @JsonProperty("JN")
        private String jointNameAccount;

        private String fullName;

        @JsonProperty("SMR")
        private String salutationMr;
        @JsonProperty("SMS")
        private String salutationMs;
        @JsonProperty("SDR")
        private String salutationDr;
        @JsonProperty("SOTH")
        private String salutationOther;

        private String firstName;
        private String middleName;
        private String lastName;

        private String dob;
        private String countryBirth;


        @JsonProperty("M")
        private String male;
        @JsonProperty("F")
        private String female;


        @JsonProperty("SG")
        private String maritalSingle;
        @JsonProperty("MR")
        private String maritalMarried;
        @JsonProperty("DV")
        private String maritalDivorced;
        @JsonProperty("WD")
        private String maritalWidowed;

        private String placeBirth;
        private String nationality;
        private String spouseName;

        private String passportNumber;
        private String psptIssueDate;
        private String psptExpiryDate;

        @JsonProperty("S")
        private String secondary;
        @JsonProperty("HS")
        private String higherSecondary;
        @JsonProperty("G")
        private String graduate;
        @JsonProperty("PG")
        private String postGraduate;
        @JsonProperty("OT")
        private String qualificationOther;

        private String mailingAddress;
        private String mailingAddressCity;
        private String mailingAddressCountry;
        private String mailingAddressZip;

        private String permanentAddress;
        private String permanentAddressCity;
        private String permanentAddressCountry;
        private String permanentAddressZip;

        private String emailId;

        private String mobileNumber;


        @JsonProperty("SLR")
        private String salaried;
        @JsonProperty("SEMP")
        private String selfEmployed;
        @JsonProperty("HSW")
        private String housewife;
        @JsonProperty("PRF")
        private String professional;
        @JsonProperty("RTD")
        private String retired;
        @JsonProperty("STD")
        private String student;
        @JsonProperty("OTOCC")
        private String occupationOther;

        private String nameOfEmployer;
        private String designation;
        private String workExperience;
        private String addressOfEmployer;


        @JsonProperty("MFR")
        private String manufacturing;
        private String mfrDescription;
        @JsonProperty("RTT")
        private String retailTrading;
        private String rtlDescription;
        @JsonProperty("IEO")
        private String importExport;
        private String ieoDescription;
        @JsonProperty("HRC")
        private String hotelRestaurant;
        @JsonProperty("OEMP")
        private String industryOther;
        private String otherDescription;
        @JsonProperty("ITC")
        private String itConsultancy;
        @JsonProperty("PSF")
        private String publicServices;
        @JsonProperty("FBI")
        private String financeBanking;


        private String annualIncome;
        private String netWorth;

        @JsonProperty("EFW")
        private String sourceEarningFromWork;
        @JsonProperty("EFB")
        private String sourceBusinessIncome;
        @JsonProperty("INH")
        private String sourceInheritance;
        @JsonProperty("INV")
        private String sourceInvestmentIncome;
        @JsonProperty("SOP")
        private String sourceSaleOfAsset;
        @JsonProperty("LOT")
        private String sourceLottery;
        @JsonProperty("EFSF")
        private String sourceEarningFromSpouseFamily;

        @JsonProperty("ROWN")
        private String residenceOwned;
        @JsonProperty("RRN")
        private String residenceRented;
        @JsonProperty("RANC")
        private String residenceAncestral;
        @JsonProperty("RCOM")
        private String residenceCompany;
        @JsonProperty("ROTH")
        private String residenceOther;


        @JsonProperty("POD")
        private String purposeOffshoreDeposit;
        @JsonProperty("PINV")
        private String purposeInvestment;
        @JsonProperty("PAL")
        private String purposeLoan;
        @JsonProperty("POTH")
        private String purposeOther;


        private Integer numberOfTransactions;
        private Long transactionAmount;

        private String pepY;
        private String pepN;

        private String cntryTax1;
        private String taxID1;

        private String cntryTax2;
        private String taxID2;

        private String cntryTax3;
        private String taxID3;


        @JsonProperty("CUSD")
        private String currencyUsd;
        @JsonProperty("CGBP")
        private String currencyGbp;
        @JsonProperty("CEUR")
        private String currencyEur;
        @JsonProperty("CAUD")
        private String currencyAud;
        @JsonProperty("CCAD")
        private String currencyCad;
        @JsonProperty("COTH")
        private String currencyOther;
        private String otherCurrency;

        private String nomineeY;
        private String nomineeN;

        private String nomineeName;
        private String nomineeAddress;
        private String nomineeCity;
        private String nomineeState;
        private String nomineeCountry;
        private String nomineePinCode;
        private String nomineeMobile;
        private String nomineeEmail;
        private String nomineeRelation;
        private String nomineeDob;

        private String guardianName;
        private String guardianAddress;

        private String portfolioCode;
        private String accountNumber;
        private String branchName;
        private String branchCode;
        private String productCode;
        private String employerPinCode;
        private String occupationSince;

    }

    @Getter
    @Setter
    @NoArgsConstructor
    @AllArgsConstructor
    @ToString
    public static class RiskAnalysisData {

        @JsonProperty("fullName")
        private String fullName;

        @JsonProperty("customer_risk_high")
        private String customerRiskHigh;
        @JsonProperty("customer_risk_medium")
        private String customerRiskMedium;
        @JsonProperty("customer_risk_low")
        private String customerRiskLow;

        @JsonProperty("jurisdiction_risk_high")
        private String jurisdictionRiskHigh;
        @JsonProperty("jurisdiction_risk_medium")
        private String jurisdictionRiskMedium;
        @JsonProperty("jurisdiction_risk_low")
        private String jurisdictionRiskLow;

        @JsonProperty("interface_risk_high")
        private String interfaceRiskHigh;
        @JsonProperty("interface_risk_low")
        private String interfaceRiskLow;

        @JsonProperty("product_risk_high")
        private String productRiskHigh;
        @JsonProperty("product_risk_medium")
        private String productRiskMedium;
        @JsonProperty("product_risk_low")
        private String productRiskLow;

        @JsonProperty("adverse_risk_high")
        private String adverseRiskHigh;
        @JsonProperty("adverse_risk_low")
        private String adverseRiskLow;

        @JsonProperty("exp_risk_high")
        private String expRiskHigh;
        @JsonProperty("exp_risk_med")
        private String expRiskMed;
        @JsonProperty("exp_risk_low")
        private String expRiskLow;

        @JsonProperty("customer_risk")
        private String customerRisk;
        @JsonProperty("jurisdiction_risk")
        private String jurisdictionRisk;
        @JsonProperty("interface_risk")
        private String interfaceRisk;
        @JsonProperty("product_risk")
        private String productRisk;
        @JsonProperty("adverse_risk")
        private String adverseRisk;
        @JsonProperty("exp_risk")
        private String expRisk;

        @JsonProperty("weighted_customer_risk")
        private String weightedCustomerRisk;
        @JsonProperty("weighted_jurisdiction_risk")
        private String weightedJurisdictionRisk;
        @JsonProperty("weighted_interface_risk")
        private String weightedInterfaceRisk;
        @JsonProperty("weighted_product_risk")
        private String weightedProductRisk;
        @JsonProperty("weighted_adverse_risk")
        private String weightedAdverseRisk;
        @JsonProperty("weighted_exp_risk")
        private String weightedExpRisk;

        @JsonProperty("total_weighted_risk")
        private String totalWeightedScore;


        @JsonProperty("total_cdd_level")
        private String totalCddLevel;

        private String pep;
        private String cnftf;
    }
}
