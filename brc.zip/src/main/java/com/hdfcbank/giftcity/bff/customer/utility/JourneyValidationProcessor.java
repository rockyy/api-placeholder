package com.hdfcbank.giftcity.bff.customer.utility;

import com.hdfcbank.common.models.vo.journey.JourneyData;
import com.hdfcbank.common.models.vo.mdc.MDCValues;
import com.hdfcbank.giftcity.bff.commons.constant.CommonConstants;
import com.hdfcbank.giftcity.bff.commons.enums.CommonJourneyStates;
import com.hdfcbank.giftcity.bff.commons.exception.CustomValidationException;
import com.hdfcbank.giftcity.bff.commons.model.CustomValidationStatus;
import com.hdfcbank.giftcity.bff.commons.properties.CustomValidationProperties;
import com.hdfcbank.giftcity.bff.commons.utility.ValidationHelper;
import com.hdfcbank.giftcity.bff.commons.validation.JourneyDataProcessor;
import com.hdfcbank.giftcity.bff.customer.model.CustomerApiStatusCode;
import com.hdfcbank.giftcity.bff.customer.model.IdentifyCustomerRequest;
import com.hdfcbank.service.adapters.vo.customer.FetchCasaResponse;
import com.hdfcbank.service.adapters.vo.customer.IdentifyGCCustomerResponse;
import com.hdfcbank.giftcity.bff.infrastructure.service.JourneyService;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.*;

import static com.hdfcbank.giftcity.bff.commons.constant.CommonConstants.*;

@Component
public class JourneyValidationProcessor implements JourneyDataProcessor {

    @Autowired
    ValidationFailureHandler validationFailureHandler;

    @Autowired
    CustomValidationProperties customValidationProperties;

    @Autowired
    private JourneyService journeyService;

    @Autowired
    protected ValidationHelper validationHelper;

    protected void manageValidationViolation(List<CustomValidationProperties.FieldDetail> fieldDetails, String journeyId) {

        if (fieldDetails != null && !fieldDetails.isEmpty()) {

            JourneyData journeyData = journeyService.fetchJourney(journeyId);
            CustomValidationStatus customValidationStatus =
                    validationHelper.getErrors(journeyData.getJourneyName(), fieldDetails, customValidationProperties);

            journeyService.updateJourneyDetailDropOff(
                    journeyData,
                    customValidationStatus,
                    CommonJourneyStates.DROP_OFF_CUSTOMER_EXCLUDED
            );

            throw new CustomValidationException(CustomerApiStatusCode.CUSTOM_VALIDATION_EXCEPTION,
                    customValidationStatus.getErrors());
        }
    }

    private static List<String> getErrors(List<CustomValidationProperties.FieldDetail> fieldDetails,
                                          CustomValidationProperties customValidationProperties) {

        List<String> errors = new ArrayList<>();

        for (CustomValidationProperties.FieldDetail fieldDetail : fieldDetails) {
            if (fieldDetail.getMessage() != null) {
                errors.add(fieldDetail.getMessageHeading());
                errors.add(fieldDetail.getType() + " (" + fieldDetail.getCode() + ") - "
                        + String.format(fieldDetail.getMessage(), fieldDetail.getCode()));

            } else {

                String journeyName = MDCValues.getJourneyName();
                errors.add(customValidationProperties.getJourneys().get(journeyName).getDefaultMessageHeading());
                errors.add(fieldDetail.getType() + " (" + fieldDetail.getCode() + ") - "
                        + String.format(customValidationProperties.getJourneys().get(journeyName).getDefaultMessage(),
                        fieldDetail.getCode()));
            }
        }

        return errors;
    }

    public void validateRequest(IdentifyCustomerRequest request, String journeyId) {

        List<CustomValidationProperties.FieldDetail> fieldDetails = new ArrayList<>();

        fieldDetails.add(validateData(MOBILE_NO, request.getMobileNo(), customValidationProperties,
                MDCValues.getJourneyName()));

        String identifierName = request.getIdentifierName();

        if ("DOB".equalsIgnoreCase(identifierName)) {
            fieldDetails.add(validateData("dob", request.getIdentifierValue(), customValidationProperties,
                    MDCValues.getJourneyName()));

        } else if ("PAN".equalsIgnoreCase(identifierName)) {
            fieldDetails.add(validateData("pan", request.getIdentifierValue(), customValidationProperties,
                    MDCValues.getJourneyName()));
        } else {
            fieldDetails.add(validateData("identifierName", identifierName, customValidationProperties,
                    MDCValues.getJourneyName()));
        }

        fieldDetails.removeIf(Objects::isNull);

        manageValidationViolation(fieldDetails, journeyId);
    }

    @Override
    public void validate(FetchCasaResponse.Profile profile, String journeyId) {

        List<CustomValidationProperties.FieldDetail> fieldDetails = new ArrayList<>();

        int lastSpaceIndex = profile.getName().trim().lastIndexOf(" ");
        if (lastSpaceIndex == -1) {
            fieldDetails.add(validateData(FIRST_NAME, profile.getName(), customValidationProperties,
                    MDCValues.getJourneyName()));
        } else {
            fieldDetails.add(validateData(FIRST_NAME, profile.getName().substring(0, lastSpaceIndex),
                    customValidationProperties, MDCValues.getJourneyName()));

            fieldDetails.add(validateData(LAST_NAME, profile.getName().substring(lastSpaceIndex + 1),
                    customValidationProperties, MDCValues.getJourneyName()));
        }

        fieldDetails.add(validateData(NAME, profile.getName(), customValidationProperties,
                MDCValues.getJourneyName()));
        fieldDetails.add(validateData(GENDER, profile.getGender(), customValidationProperties,
                MDCValues.getJourneyName()));
        fieldDetails.add(validateData(EMAIL, profile.getEmail(), customValidationProperties,
                MDCValues.getJourneyName()));
        fieldDetails.add(validateData(KYC_STATUS, profile.getKycStatus(), customValidationProperties,
                MDCValues.getJourneyName()));
        fieldDetails.add(validateData(PAN, profile.getPanNumber(), customValidationProperties,
                MDCValues.getJourneyName()));

        fieldDetails.removeAll(Collections.singleton(null));

        manageValidationViolation(fieldDetails, journeyId);
    }

    //       CHANGE: Cognitive Complexity reduced by extracting nested checks into helper method
    //       CHANGE: Early return for !isPresent() reduces nesting
    //       CHANGE: Removed lowerValue & regex logic from this method
    protected CustomValidationProperties.FieldDetail validateData(String type, String value,
                                                                  CustomValidationProperties customValidationProperties, String journeyName) {

        Optional<CustomValidationProperties.FieldDetail> fieldDetailOptional =
                customValidationProperties.getJourneys().get(journeyName)
                        .getFieldsDetail()
                        .stream()
                        .filter(fd -> fd.getType().equals(type))
                        .findFirst();

        //       CHANGE: Early return to reduce nesting
        if (!fieldDetailOptional.isPresent()) {
            return null;
        }

        CustomValidationProperties.FieldDetail fieldDetail = fieldDetailOptional.get();

        //       CHANGE: Mandatory check left intact (no complexity increase)
        if (fieldDetail.isMandatory() && StringUtils.isEmpty(value)) {
            return fieldDetail;
        }

        //       CHANGE: All non-null validations moved to a separate helper method
        if (value != null) {
            return validateNonNullValue(value, fieldDetail);
        }

        return null;
    }

    //       CHANGE: Extracted method to reduce cognitive complexity in validateData()
    //       CHANGE: This method performs allowedValues, length, and regex validations
    private CustomValidationProperties.FieldDetail validateNonNullValue(String value,
                                                                        CustomValidationProperties.FieldDetail fieldDetail) {

        String lowerValue = value.toLowerCase(Locale.ROOT);

        if (fieldDetail.getAllowedValues() != null &&
                !fieldDetail.getAllowedValues().contains(lowerValue)) {
            return fieldDetail;
        }

        if (value.length() > fieldDetail.getLength()) {
            return fieldDetail;
        }

        String regex = fieldDetail.getAllowedRegex();
        if (regex != null && !value.matches(regex)) {
            return fieldDetail;
        }

        return null;
    }

    @Override
    public void validateCustomerEligibility(String journeyId, FetchCasaResponse.Profile profile) {

        String customerType = profile.getCustomerType() != null
                ? profile.getCustomerType().trim()
                : null;

        if (!isEligibleCustomer(customerType, profile.getFlgBlocked())) {
            validationFailureHandler.dropOnValidationFailure(
                    journeyId,
                    CustomerApiStatusCode.NO_ELIGIBLE_CUSTOMER,
                    "We couldn’t verify your details. Please try again or use a different verification method",
                    CommonJourneyStates.CUSTOMER_NOT_ELIGIBILE
            );
        }
    }

    @Override
    public void validateEtbCustomer(IdentifyGCCustomerResponse gcResponse, String journeyId) {

        if (gcResponse != null && gcResponse.getData() != null && isEtbCustomer(gcResponse)) {
            validationFailureHandler.dropOnValidationFailure(
                    journeyId,
                    CustomerApiStatusCode.NO_ELIGIBLE_GCCUSTOMER,
                    "We couldn’t verify your details. Please try again or use a different verification method.",
                    CommonJourneyStates.FCC_IDENTIFY_FAILURE
            );
        }
    }

    private boolean isEligibleCustomer(String customerType, String blockedFlag) {
        return CommonConstants.BUSINESS_CUST_TYP.equalsIgnoreCase(customerType)
                && !CommonConstants.INVALID_FLAG_BLOCKED.equalsIgnoreCase(blockedFlag);
    }

    private boolean isEtbCustomer(IdentifyGCCustomerResponse gcResponse) {
        return gcResponse.getData().getEtb() == null ||
                CommonConstants.ETB.equalsIgnoreCase(gcResponse.getData().getEtb());
    }
}