package com.hdfcbank.giftcity.bff.infrastructure.properties;

import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Getter
@Setter
@Configuration
@ConfigurationProperties("api.journey.creation")
public class JourneyProperties {
    private JourneyIdCreationDetails journeyId;
    private String journeyName;
    private String userDataCookieName;
    private String journeyStateJmsDestination;
    private String queueUrl;

    @Getter
    @Setter
    public static class JourneyIdCreationDetails {
        private String creationPattern;
        private String createBefore;
    }
}
