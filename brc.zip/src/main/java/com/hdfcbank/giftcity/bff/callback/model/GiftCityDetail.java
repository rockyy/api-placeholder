package com.hdfcbank.giftcity.bff.callback.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.*;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@ToString
@JsonIgnoreProperties(ignoreUnknown =  true)
public class GiftCityDetail {

    private  String customerID;
    private  String accountNumber;
}
