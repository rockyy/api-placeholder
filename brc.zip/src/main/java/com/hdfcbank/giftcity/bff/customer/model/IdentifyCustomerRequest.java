package com.hdfcbank.giftcity.bff.customer.model;

import com.hdfcbank.common.models.validation.annotation.ValueOfEnum;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import lombok.*;
import lombok.experimental.SuperBuilder;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@SuperBuilder
@ToString
public class IdentifyCustomerRequest {

    @NotBlank(message = "identifierName is mandatory")
    @ValueOfEnum(IdentifierType.class)
    private String identifierName;

    @NotBlank(message = "identifierValue is mandatory")
    private String identifierValue;

    @NotBlank(message = "mobileNo is mandatory")
    @Pattern(regexp = "\\d{5,20}", message = "Invalid mobile number")
    private String mobileNo;

    @Pattern(regexp = "\\d{0,5}", message = "Invalid ISD code")
    private String isd;

    private boolean sso;

    public String getFullMobileNumber() {
        String effectiveIsd = (isd == null || isd.isBlank()) ? "" : isd;
        return effectiveIsd + mobileNo;
    }
}
