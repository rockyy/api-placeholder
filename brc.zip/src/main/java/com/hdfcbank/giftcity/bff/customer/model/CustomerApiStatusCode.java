package com.hdfcbank.giftcity.bff.customer.model;

import com.hdfcbank.common.models.vo.core.ApiResponseStatusCodeLiteral;
import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum CustomerApiStatusCode implements ApiResponseStatusCodeLiteral {
    MATCHED("0000", "OTP matched"),

    FAILED("9004", "OTP failed"),
    OTP_MISMATCHED("8003", "OTP_MISMATCHED"),
    OTP_EXPIRED("8004", "OTP_EXPIRED"),
    UNKNOWN("9999", "Oops! Something doesn't seem right."),
    NO_EXISTING_CUSTOMER("8005", "No Existing Customer Found"),
    NO_ELIGIBLE_CUSTOMER("8006", "No Eligible customer Found"),
    NO_ELIGIBLE_GCCUSTOMER("8006", "Existing customer in FC GC"),
    OTP_LIMIT_EXCEEDED("8008", "You have reached maximum number of attempts, kindly retry after #{T(org.apache.commons.lang3.time.DurationFormatUtils).formatDurationWords(@coolingPeriodProperties.properties['verifyOtp'].ttl.toMillis(), true, true)}"),
    OTP_FLOODED("8010", "OTP is under cool off, Please try after %s seconds"),
    RETRY_LIMIT_EXCEEDED("8008", "You have reached maximum number of attempts, kindly retry after #{T(org.apache.commons.lang3.time.DurationFormatUtils).formatDurationWords(@coolingPeriodProperties.properties['resendOtp'].ttl.toMillis(), true, true)}"),
    IDCOM_FAIL("8008", "You have reached maximum number of attempts, kindly retry after #{T(org.apache.commons.lang3.time.DurationFormatUtils).formatDurationWords(@coolingPeriodProperties.properties['idcomFailure'].ttl.toMillis(), true, true)}"),
    DUPLICATE_SESSION("8009", "You are logged in at another device, duplicate session not allowed"),
  //  REKYC_NON_COMPLIANT_CUSTOMER("9005", "As your KYC is not complete"),
    FC_DATA_NOT_AVAILABLE("8013", "Please connect with the nearest branch to buy the policy."),


    REKYC_NON_COMPLIANT_CUSTOMER("8011", "As your KYC is not complete"),
    CUSTOM_VALIDATION_EXCEPTION("8001", "Invalid request "),
    CONSENT_FAILED("9003", "CONSENT_FAILED"),
    PAN_NOT_AVAILABLE("9008", "PAN_NOT_AVAILABLE"),
    EMAIL_NOT_AVAILABLE("9009","EMAIL_NOT_AVAILABLE" ),
    KYC_PENDING("9010","EMAIL_NOT_AVAILABLE" ),
    ETB_NRI_VALIDATION_FAILED("9011","ETB_NRI_VALIDATION_FAILED" ),
    REFERENCE_GENERATION_FAILED("9012", "REFERENCE_GENERATION_FAILED"),

    DOWNSTREAM_API_ERROR("9999","Downstream_Error"),
    INVALID_PAN("9013", "PAN_VALIDATION_FAILED"),
    PAN_INOPERATIVE("9014","PAN_INOPERATIVE" ),
    KYC_NOT_COMPLIANT("9015", "KYC_NOT_COMPLIANT"),
    INVALID_REQUEST("9020", "INVALID_REQUEST"),
    VARIFICATION_FAILED("9030","VARIFICATION_FAILED" ),
    FACTIVA_MATCH_FOUND("9031","FACTIVA_MATCH_FOUND"),
    FACTIVA_NULL_RESPONSE("9032","FACTIVA_NULL_RESPONSE"),
    CUSTDATA_MISSING_INVALID("9033", "Missing or invalid customer details"),
    CUSTDATA_DUPLICATE_REQUEST("9034", "Duplicate request number"),
    CUSTDATA_SOURCE_UNAVAILABLE("9035", "Source system not available"),
    DEDUPE_SUCCESS("201", "Dedupe Success No Match Found"),
    DEDUPE_FAILURE("200", "Dedupe Failure Match Found"),
    NOMINEE_FAILURE("9007", "Failed to fetch the nominee details for the customer."),
    NOMINEE_NOT_FOUND("9016", "Nominee not found for this account number");

    private final String code;
    private final String message;

    public static CustomerApiStatusCode getCustomerApiStatus(String statusCode) {
        for (CustomerApiStatusCode apiStatusCode : values()) {
            if (apiStatusCode.getCode().equals(statusCode)) {
                return apiStatusCode;
            }

        }
        return FAILED;
    }
}