package com.hdfcbank.giftcity.bff.commons.constant;

import java.time.format.DateTimeFormatter;

public class CommonConstants {

    private CommonConstants() {
    }

    public static final String BRANCH_CODE = "branchCode";
    public static final String BRANCH_NAME = "branchName";
    public static final String ACCOUNT_CLASS = "accountClass";
    public static final String LOCATION = "location";
    public static final String COMMUNICATION_MEDIA = "communicationMedia";
    public static final String ACCOUNT_TYPE = "accountType";
    public static final String NO_CREDIT_STATUS = "noCreditStatus";
    public static final String NO_DEBIT_STATUS = "noDebitStatus";
    public static final String CUSTOMER_NUMBER = "customerNumber";
    public static final DateTimeFormatter ACCOUNT_OPEN_DATE_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd");
    public static final DateTimeFormatter DATE_OF_APPLICATION = DateTimeFormatter.ofPattern("dd/MM/yyyy");
    public static final String YES = "Y";
    public static final String NO = "N";

    public static final String IDENTIFY_CUSTOMER = "IDENTIFY_CUSTOMER";
    public static final String SUCCESS_CODE = "0000";
    public static final String AGE = "age";




    public static final String DEBIT_UN_FREEZE = "N";
    public static final String CREDIT_UN_FREEZE = "N";
    public static final String JOURNEY_STATUS = "status";
    public static final String JOURNEY_DROP_OFF = "journeyDropOff";
    public static final String BUSINESS_CUST_TYP = "O";
    public static final String INVALID_FLAG_BLOCKED = "Y";
    public static final String JOURNEY_STATUS_DETAIL = "journeyStatusDetail";
    public static final String CASA_DATE_FORMAT = "yyyyMMdd";
    public static final String PAN_PATTERN = "[A-Z]{5}\\d{4}[A-Z]";
    public static final String DOB_NOT_VALID = "dob is not valid";
    public static final String PAN_NOT_VALID = "pan is not valid";
    public static final String IDENTIFIER_VALUE = "identifierValue";

    public static final String MOBILE_NO = "mobileNo";

    public static final DateTimeFormatter DATE_TIME_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd");
    public static final DateTimeFormatter DATE_TIME_FORMATTER_KYC = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
    public static final String ETB = "Y";
    public static final String VALID_ACCOUNT_STATUS_CODE = "8";

    public static final String FIRST_NAME = "firstName";
    public static final String LAST_NAME = "lastName";
    public static final String NAME = "name";
    public static final String GENDER = "gender";
    public static final String EMAIL = "email";
    public static final String PAN = "pan";
    public static final String KYC_STATUS = "kycStatus";
    public static final String DROPOFF_REASON = "DROPOFF_REASON";
    public static final String DROPOFF_EXCLUSIONS = "DROPOFF_EXCLUSIONS";
    public static final String UTC = "UTC";
    public static final String CAPTURED_DATE_OUTPUT_FORMAT = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'";

    public static final String MEMO_SEVERITY = "memoSeverity";
    public static final String PAN_STATUS = "panStatus";
    public static final String REF_CUST_EMAIL="refCustEmail";
    public static final String JOURNEY_NAME = "GCA_ETB";
    public static final String FOREIGN_ADDRESS= "foreignAddress";
    public static final String ACTIVE_NRE_NRO_ACCOUNT ="activeNreNroAccount";
    public static final String FACTA_COMPLIANCE="fatcaCompliance";
    public static final String VISA_EXPIRY = "visaExpiry";
    public static final String PASSPORT_EXPIRY = "passportExpiry";
    public static final String PASSPORT_NOT_AVAILABLE = "passportNotAvailable";
    public static final String REF_CUST_NUM = "refCustItNum";

    public static final String SIGNATURE = "Signature";
    public static final String DEFAULT_SIGID ="1" ;
    public static final String DEFAULT_REP_TOACC = "Y";
    public static final String EXT_REF_NUM = "extRefNum";
    public static final String DATA_SOURCES = "dataSources";
    public static final String BODY = "body";
    public static final String HEADERS = "headers";
    public static final String AUTHORIZATION = "Authorization";
    public static final String BEARER = "Bearer ";
    public static final String CONTENT_TYPE = "Content-Type";
    public static final String ACCEPT = "Accept";
    public static final String USER_AGENT = "User-Agent";
    public static final String APPLICATION_JSON = "application/json";

    public static final String CC_SOURCE = "source";
    public static final String CC_UBSCOMP = "ubscomp";
    public static final String CC_USERID = "userid";
    public static final String CC_BRANCH = "branch";
    public static final String CC_EXT_REF_NUM = "extrefnum";
    public static final String CC_CTYPE = "cType";
    public static final String CCATEG = "ccateg";
    public static final String CC_MEDIA = "media";
    public static final String CC_IND_CNTR_TX_RS1 = "IND_CNTR_TX_RS1";
    public static final String CC_IND_CNTR_TX_RS2 = "IND_CNTR_TX_RS2";
    public static final String CC_IND_CNTR_TX_RS3 = "IND_CNTR_TX_RS3";

    public static final String CC_IND_CNTR_TX_RS4 = "IND_CNTR_TX_RS4";

    public static final String IND_TIN_ISSUED_BY_CNTR_1 = "IND_TIN_ISSUED_BY_CNTR_1";
    public static final String IND_TIN_ISSUED_BY_CNTR_2 = "IND_TIN_ISSUED_BY_CNTR_2";
    public static final String IND_TIN_ISSUED_BY_CNTR_3 = "IND_TIN_ISSUED_BY_CNTR_3";
    public static final String IND_TIN_ISSUED_BY_CNTR_4 = "IND_TIN_ISSUED_BY_CNTR_4";

    public static final String RM_CODE = "RM_CODE";
    public static final String SOURCING_BR_CODE = "SOURCING_BR_CODE";
    public static final String SOURCING_BRANCH = "SOURCING_BRANCH";

    public static final String CC_IND_TIN_1 = "IND_TIN_1";
    public static final String CC_IND_TIN_ISSUED_BY_CNTR_1 = "IND_TIN_ISSUED_BY_CNTR_1";
    public static final String CC_PEP_NONPEP = "PEP__NONPEP";
    public static final String CC_ANNUAL_INCOME = "ANNUAL_INCOME";
    public static final String NETWORTH_ON_RECORD_USD = "NETWORTH_ON_RECORD_(USD_MIO)";
    public static final String IND_TIN_1 = "IND_TIN_1";

    public static final String IND_TIN_2 = "IND_TIN_2";
    public static final String IND_TIN_3 = "IND_TIN_3";
    public static final String IND_TIN_4 = "IND_TIN_4";




    public static final DateTimeFormatter YYYYMMDD_FORMATTER = DateTimeFormatter.ofPattern(CASA_DATE_FORMAT);
    public static final String ACCEPTED_MAXIMUM_TRANSACTIONS ="ACCEPTED_MAXIMUM_TRANSACTIONS";
    public static final String ANTICIPATED_MNTLY_TXN_AMT_USD = "ANTICIPATED_MNTLY_TXN_AMT_USD";
    public static final String FTF_OR_NFTF = "FTF OR NFTF";
    public static final String DEFAULT_LGCODE = "defaultLgCode";
    public static final String CC_TRADE_TRANSACTION_CUSTOMER = "TRADE_TRANSACTION_CUSTOMER";
    public static final String CC_RISK_CATEGORY = "RISK_CATEGORY";
    public static final String CC_LAST_REKYC_DATE = "LAST_REKYC_DATE";
    public static final String MISCD = "misCd";
    public static final String MISCLS = "misCls";
    public static final String BRANCH = "branch";
    public static final String RESSTATUS = "resStatus";
    public static final String LANGUAGE = "language";
    public static final String PI = "PI";
    public static final String EMPCODE = "empCode";
    public static final String EMPDESC = "empDesc";
    public static final String LOC = "loc";
    public static final String CC_CLIENT_DECLARED_NETWORTH_USD_MIO = "CLIENT_DECLARED_NETWORTH_(USD_MIO)";

    public static final String CC_NON_PEP = "Non-PEP";
    public static final String CC_PEP = "PEP";

    public static final String TRADE_TRANSACTION_CUSTOMER = "tradeTransactionCustomer";
    public static final String TRACK_LIMITS = "trackLimits";
    public static final String TAX_CODE1 = "taxCode1";
    public static final String CUST_RELATION_CUSTOMER_AUS = "cust_relation_customer_aus";
    public static final String IMAGE_TYPE_HEADER = "image/tif";
    public static final String IMAGE_PNG_TYPE_HEADER = "image/png";
    public static final String NATIONALITY = "nationality";
    public static final String COUNTRY_OF_TAX_RESIDENCY = "countryOfTaxResidency";
    public static final String TAX_ID_NUMBER = "taxIdNumber";
    public static final String TAX_ID_TYPE = "taxIdType";
    public static final String PLACE_OF_BIRTH = "placeOfBirth";
    public static final String COUNTRY_OF_BIRTH = "countryOfBirth";
    public static final String FATHER_NAME = "fathersName";
    public static final String MOTHER_NAME = "mothersName";
    public static final String ADDRESS_OF_TAX_PURPOSE = "addressOfTaxPurpose";
    public static final String FULL_NAME = "fullName";
    public static final String DATE_OF_BIRTH = "dateOfBirth";
    public static final String COMMUNICATION_ADDRESS = "communicationAddress";
    public static final String PERMANENT_ADDRESS = "permanentAddress";

    public static final String ACCOUNT_STATEMENT_NO_ACCOUNT = "accountStatementNoAccount";
    public static final String ACCOUNT_STATEMENT_MAX_ACCOUNT_EXCEEDED = "accountStatementMaxAccountExceeded";
    public static final int ACCOUNT_STATEMENT_MAX_ACCOUNT_COUNT = 2;

    public static final String FIRST_REM_MAIL_TEMPLATE = "gca-mail-alert-1-send";
    public static final String SECOND_REM_MAIL_TEMPLATE = "gca-mail-alert-2-send";
    public static final String THIRD_REM_MAIL_TEMPLATE = "gca-mail-alert-3-send";

    public static final String FIRST_REM_SMS_TEMPLATE = "gca-sms-alert-1-send";
    public static final String SECOND_REM_SMS_TEMPLATE = "gca-sms-alert-2-send";
    public static final String THIRD_REM_SMS_TEMPLATE = "gca-sms-alert-3-send";

    public static final String FIRST_REMINDER_DAY = "firstReminderDay";
    public static final String SECOND_REMINDER_DAY = "secondReminderDay";
    public static final String THIRD_REMINDER_DAY = "thirdReminderDay";
    public static final String MAX_REMINDER_ELIGIBILITY_DAYS = "maxReminderEligibilityDays";

    public static final String SMS_TEMPLATE = "sms-template";
    public static final String EMAIL_TEMPLATE = "email-template";
    public static final String FTS_INQUIRE = "fts-inquire";

    public static final String FTS_REJECT_CALLBACK_SMS_TEMPLATE = "gca-sms-acc-rej";
    public static final String FTS_REJECT_CALLBACK_EMAIL_TEMPLATE = "gca-email-acc-rej";

    public static final String JPEG = "image/jpeg";
    public static final String PNG = "image/png";

    public static final String HEADER_IMG = "hdr_img.jpg";
    public static final String HEADER_CID = "hdr_img";

    public static final String CALL_US_IMG = "call_us.png";
    public static final String CALL_US_CID = "call_us";

    public static final String WHATSAPP_IMG = "wa_logo.png";
    public static final String WHATSAPP_CID = "wa_logo";

    public static final String MOBILE_APP_IMG = "mobile_app.png";
    public static final String MOBILE_APP_CID = "mobile_app";

    public static final String INTERNET_BANKING_IMG = "internet_bank.png";
    public static final String INTERNET_BANKING_CID = "internet_bank";

    public static final String BRANCH_LOCATOR_IMG = "branch_locator.png";
    public static final String BRANCH_LOCATOR_CID = "branch_locator";


    public static final String CUST_ID = "CUST_ID";
    public static final String AC_OPENING_CASE_NO = "AC_OPENING_CASE_NO";
    public static final String IND_MOBILE_CNTR_CD = "IND_MOBILE_CNTR_CD";
    public static final String IND_MOBILE_PHONE_NUMBER = "IND_MOBILE_PHONE_NUMBER";


}
