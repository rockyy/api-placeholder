package com.hdfcbank.giftcity.bff.customer.controller;

import com.hdfcbank.annotations.CoolingPeriod;
import com.hdfcbank.annotations.CoolingPeriodType;
import com.hdfcbank.annotations.CoolingPeriods;
import com.hdfcbank.annotations.ValidationPhase;
import com.hdfcbank.common.models.vo.core.ApiErrorResponse;
import com.hdfcbank.exception.DownstreamApiException;

import com.hdfcbank.giftcity.bff.commons.annotation.OneDeviceOneLogin;
import com.hdfcbank.giftcity.bff.commons.annotation.ValidateJourney;
import com.hdfcbank.giftcity.bff.commons.utility.TextSanityUtil;
import com.hdfcbank.giftcity.bff.customer.model.*;
import com.hdfcbank.giftcity.bff.customer.rmcodes.service.RmCodesMasterService;
import com.hdfcbank.giftcity.bff.customer.service.CustomerService;

import com.hdfcbank.starter.logging.annotations.JourneyId;
import com.hdfcbank.starter.logging.annotations.JourneyName;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


import static com.hdfcbank.giftcity.bff.commons.enums.CommonJourneyStates.OTP_GENERATE_SUCCESS;
import static com.hdfcbank.giftcity.bff.commons.enums.CommonJourneyStates.OTP_VALIDATE_SUCCESS;

@Slf4j
@RestController
@RequestMapping("${api.giftcity.base-path}/customer")
public class CustomerController {

    @Autowired
     CustomerService customerService;

    @Autowired
    private RmCodesMasterService rmCodesMasterService;


    @ApiResponses({
            @ApiResponse(responseCode = "401", content = @Content(schema = @Schema)),
            @ApiResponse(responseCode = "200 - 0000", description = "success",
                    content = @Content(mediaType = "application/json",
                            schema = @Schema(implementation = IdentifyCustomerResponse.class))),
            @ApiResponse(responseCode = "200 - 9002", description = "Downstream api error",
                    content = @Content(mediaType = "application/json",
                            schema = @Schema(implementation = ApiErrorResponse.class))),
            @ApiResponse(responseCode = "500 - 9999", description = "Internal server error",
                    content = @Content(mediaType = "application/json",
                            schema = @Schema(implementation = ApiErrorResponse.class))),
            @ApiResponse(responseCode = "400 - 8001", description = "Bad Request",
                    content = @Content(mediaType = "application/json",
                            schema = @Schema(implementation = ApiErrorResponse.class)))
    })
    @CoolingPeriods(
            {
                    @CoolingPeriod(
                            type = CoolingPeriodType.SEND_OTP,
                            journeyName = "#journeyName",
                            identifierNames = {"mobileNumber", "journeyName","isd"},
                            identifierValues = {
                                    "#request.mobileNo",
                                    "#journeyName",
                                    "#request.isd"
                            },
                            attemptsLeftFillerField = "retryOtpAttemptsLeft",
                            attemptsConsumedFillerField = "retryOtpAttemptsConsumed",
                            incorrectAttemptCondition = "#false"

                    ),
                    @CoolingPeriod(
                            type = CoolingPeriodType.VALIDATE_OTP,
                            journeyName = "#journeyName",
                            identifierNames = {"mobileNumber", "journeyName","isd"},
                            identifierValues = {
                                    "#request.mobileNo",
                                    "#journeyName",
                                    "#request.isd"
                            },
                            attemptsLeftFillerField = "verifyOtpAttemptsLeft",
                            attemptsConsumedFillerField = "verifyOtpAttemptsConsumed",
                            incorrectAttemptCondition = "#true",
                            dropOnAttemptReach = true

                    )
            })
    @PostMapping("/identify")
    @OneDeviceOneLogin
    public ResponseEntity<IdentifyCustomerResponse> identifyCustomer(@Valid @RequestBody IdentifyCustomerRequest request,
                                                                     @RequestHeader(value = "Authorization", required = true) String authorization,
                                                                     @JourneyName String journeyName,
                                                                     @JourneyId String journeyId) throws DownstreamApiException {
        return ResponseEntity.ok(customerService.identifyCustomer(request, journeyId, journeyName));
    }


    @PostMapping("/inquire-eligibility")
    @ValidateJourney(shouldExists = {OTP_VALIDATE_SUCCESS})
    public ResponseEntity<InquireEligibilityResponse> inquireCustomer(@JourneyId String journeyId) {

        return ResponseEntity.ok(customerService.customerInquireEligibility(journeyId));
    }

    @ApiResponses({
            @ApiResponse(responseCode = "401", content = @Content(schema = @Schema)),
            @ApiResponse(responseCode = "200 - 0000", description = "Success",
                    content = @Content(mediaType = "application/json",
                            schema = @Schema(implementation = ValidateCustomerResponse.class))),
            @ApiResponse(responseCode = "200 - 9002", description = "Downstream API Error",
                    content = @Content(mediaType = "application/json",
                            schema = @Schema(implementation = ApiErrorResponse.class))),
            @ApiResponse(responseCode = "500 - 9999", description = "Internal Server Error",
                    content = @Content(mediaType = "application/json",
                            schema = @Schema(implementation = ApiErrorResponse.class))),
            @ApiResponse(responseCode = "400 - 8001", description = "Bad Request",
                    content = @Content(mediaType = "application/json",
                            schema = @Schema(implementation = ApiErrorResponse.class)))
    })

    @CoolingPeriods(
            {
                    @CoolingPeriod(
                            type = CoolingPeriodType.SEND_OTP,
                            journeyName = "#journeyName",
                            identifierNames = {"mobileNumber", "journeyName","isd"},
                            identifierValues = {
                                  "#journeyData.mobileNumber",
                                    "#journeyName",
                                    "#journeyData.isd"
                            },
                            attemptsLeftFillerField = "retryOtpAttemptsLeft",
                            attemptsConsumedFillerField = "retryOtpAttemptsConsumed",
                            incorrectAttemptCondition = "#true",
                            validationPhase = ValidationPhase.AFTER
                    ),
                    @CoolingPeriod(
                            type = CoolingPeriodType.VALIDATE_OTP,
                            journeyName = "#journeyName",
                            identifierNames = {"mobileNumber", "journeyName","isd"},
                            identifierValues = {
                                    "#journeyData.mobileNumber",
                                    "#journeyName",
                                    "#journeyData.isd"
                            },
                            attemptsLeftFillerField = "verifyOtpAttemptsLeft",
                            attemptsConsumedFillerField = "verifyOtpAttemptsConsumed",
                            incorrectAttemptCondition = "#output.body.data.otpValidated",
                            validationPhase = ValidationPhase.AFTER,
                            dropOnAttemptReach = true,
                            clearCoolingPeriod = true
                    )
            }
    )
    @ValidateJourney(shouldExists = {OTP_GENERATE_SUCCESS} , shouldNotExists ={OTP_VALIDATE_SUCCESS})
    @PostMapping("/validate")
    public ResponseEntity<ValidateCustomerResponse> validateCustomer(
            @JourneyId String journeyId,
            @JourneyName String journeyName,
            @Valid @RequestBody ValidateCustomerRequest request) {
        ValidateCustomerResponse response = customerService.validateCustomer(request, journeyId);
        return ResponseEntity.ok(response);
    }


    @ApiResponses({
            @ApiResponse(responseCode = "401", content = @Content(schema = @Schema)),
            @ApiResponse(responseCode = "200 - 0000", description = "success",
                    content = @Content(mediaType = "application/json",
                            schema = @Schema(implementation = IdentifyCustomerResponse.class))),
            @ApiResponse(responseCode = "200 - 9002", description = "Downstream api error",
                    content = @Content(mediaType = "application/json",
                            schema = @Schema(implementation = ApiErrorResponse.class))),
            @ApiResponse(responseCode = "500 - 9999", description = "Internal server error",
                    content = @Content(mediaType = "application/json",
                            schema = @Schema(implementation = ApiErrorResponse.class))),
            @ApiResponse(responseCode = "400 - 8001", description = "Bad Request",
                    content = @Content(mediaType = "application/json",
                            schema = @Schema(implementation = ApiErrorResponse.class)))
    })
    @CoolingPeriods(
            {
                    @CoolingPeriod(
                            type = CoolingPeriodType.SEND_OTP,
                            journeyName = "#journeyName",
                            identifierNames = {"mobileNumber", "journeyName","isd"},
                            identifierValues = {
                                    "#journeyData.mobileNumber",
                                    "#journeyName",
                                    "#journeyData.isd"
                            },
                            attemptsLeftFillerField = "retryOtpAttemptsLeft",
                            attemptsConsumedFillerField = "retryOtpAttemptsConsumed",
                            incorrectAttemptCondition = "#false"
                    ),
                    @CoolingPeriod(
                            type = CoolingPeriodType.VALIDATE_OTP,
                            journeyName = "#journeyName",
                            identifierNames = {"mobileNumber", "journeyName","isd"},
                            identifierValues = {
                                    "#journeyData.mobileNumber",
                                    "#journeyName",
                                    "#journeyData.isd"
                            },
                            attemptsLeftFillerField = "verifyOtpAttemptsLeft",
                            attemptsConsumedFillerField = "verifyOtpAttemptsConsumed",
                            incorrectAttemptCondition = "#true",
                            dropOnAttemptReach = true
                    )
            })
    @PostMapping("/resendOtp")
    @ValidateJourney(shouldExists = {OTP_GENERATE_SUCCESS})
    public ResponseEntity<IdentifyCustomerResponse> resendOtp(
            @RequestHeader(value = "x-journey-id") String journeyId, @JourneyName String journeyName) {
        log.info("Entered resendOtp with journeyId {}", TextSanityUtil.sanitize(journeyId));
        IdentifyCustomerResponse response = customerService.resendOtp(journeyId);
        return ResponseEntity.ok(response);
    }

    @ValidateJourney(shouldExists = {OTP_GENERATE_SUCCESS})
    @PostMapping("/view")
    public ResponseEntity<CustomerDetailsResponse> getCustomerDetails(@JourneyId String journeyId) {
        log.info("Fetch customer details by journey Id {}", TextSanityUtil.sanitize(journeyId));
        return ResponseEntity.ok(customerService.getCustomerDetails());
    }

    @ValidateJourney(shouldExists = {OTP_GENERATE_SUCCESS})
    @PostMapping("/review")
    public ResponseEntity<ReviewCustomerResponse> getReviewCustomerDetails(@JourneyId String journeyId) {
        log.info("Fetch review customer details by journey Id {}", TextSanityUtil.sanitize(journeyId));
        return ResponseEntity.ok(customerService.getReviewCustomerDetails());
    }

}
