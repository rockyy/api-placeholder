package com.hdfcbank.giftcity.bff.commons.utility;

import lombok.SneakyThrows;
import lombok.experimental.UtilityClass;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import software.amazon.awssdk.thirdparty.jackson.core.JsonProcessingException;
import tools.jackson.core.type.TypeReference;
import tools.jackson.databind.JsonNode;
import tools.jackson.databind.ObjectMapper;
import tools.jackson.databind.exc.JsonNodeException;

import java.util.Base64;
import java.util.Map;

@Slf4j
@UtilityClass
public class ClaimUtil {

    private static final ObjectMapper objectMapper = new ObjectMapper();

    @SneakyThrows
    public static Map<String, Object> extractAccessToken(String accessToken) {
        String payload = accessToken.split("\\.")[1];
        byte[] decoded = Base64.getDecoder().decode(payload);
        TypeReference<Map<String, Object>> typeReference = new TypeReference<>() {};
        return objectMapper.readValue(new String(decoded), typeReference);
    }


    public static boolean compareClaim(Map<String, Object> claims, String claimName, String value) {
        Object claimValue = claims.get(claimName);
        if (null != claimValue && null != value) {
            if (claimValue.equals(value)) {
                return true;
            }
            String hash = HashUtil.hash(value);
            if (claimValue.equals(hash)) {
                return true;
            }
        }
        return false;
    }

    public static String getMaskString(String toMask, int place) {
        String maskChar = "*";
        String maskString = StringUtils.repeat(maskChar, place);
        return StringUtils.overlay(toMask, maskString, 0, place);
    }

    public static JsonNode convertToJsonNode(Object object) {
        return object == null
                ? objectMapper.createObjectNode()
                : objectMapper.valueToTree(object);
    }

    public static String toJson(Object object, String journeyId) {
        try {
            return objectMapper.writeValueAsString(object);
        } catch (JsonNodeException e) {
            log.error("JSON serialization failed for journeyId: {}",
                    TextSanityUtil.sanitize(journeyId), e);
            throw new IllegalStateException("Failed to serialize callback payload", e);
        }
    }
}
