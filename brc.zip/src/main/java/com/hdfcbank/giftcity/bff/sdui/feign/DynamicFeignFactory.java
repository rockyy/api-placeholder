package com.hdfcbank.giftcity.bff.sdui.feign;

import com.hdfcbank.common.models.vo.mdc.MDCValues;
import com.hdfcbank.giftcity.bff.commons.constant.CommonConstants;
import com.hdfcbank.giftcity.bff.sdui.model.Header;
import feign.Feign;
import feign.RequestInterceptor;
import feign.okhttp.OkHttpClient;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.cloud.openfeign.support.FeignHttpMessageConverters;
import org.springframework.cloud.openfeign.support.SpringDecoder;
import org.springframework.cloud.openfeign.support.SpringEncoder;
import org.springframework.cloud.openfeign.support.SpringMvcContract;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class DynamicFeignFactory {
    private final OkHttpClient feignClient;

    private final ObjectProvider<FeignHttpMessageConverters> messageConverters;

    public DynamicFeignFactory(
            OkHttpClient feignClient,
            ObjectProvider<FeignHttpMessageConverters> messageConverters) {

        this.feignClient = feignClient;
        this.messageConverters = messageConverters;
    }

    public DataSourceFeignClient getClient(String url, List<Header> headers) {

        RequestInterceptor authInterceptor = requestTemplate -> {

            requestTemplate.header(CommonConstants.AUTHORIZATION, CommonConstants.BEARER + MDCValues.getAccessToken());

            requestTemplate.header(
                    CommonConstants.CONTENT_TYPE,
                    CommonConstants.APPLICATION_JSON
            );

            requestTemplate.header(
                    CommonConstants.ACCEPT,
                    CommonConstants.APPLICATION_JSON
            );

            requestTemplate.header(
                    CommonConstants.USER_AGENT,
                    MDCValues.getUserAgent()
            );

            if (headers != null) {
                for (Header header : headers) {
                    requestTemplate.header(
                            header.getKey(),
                            header.getValue()
                    );
                }
            }
        };

        return Feign.builder()
                .client(feignClient)
                .encoder(new SpringEncoder(messageConverters))
                .decoder(new SpringDecoder(messageConverters))
                .contract(new SpringMvcContract())
                .requestInterceptor(authInterceptor)
                .target(DataSourceFeignClient.class, url);
    }
}

