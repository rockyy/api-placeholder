package com.hdfcbank.giftcity.bff.infrastructure.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hdfcbank.adapters.clients.feign.journey.JourneyServiceFeignClient;
import com.hdfcbank.adapters.vo.FetchDynamicDataRequest;
import com.hdfcbank.adapters.vo.JourneyUpdateResponse;
import com.hdfcbank.adapters.vo.UpdateSystemDataJourneyRequest;
import com.hdfcbank.common.models.vo.core.ApiResponse;
import com.hdfcbank.common.models.vo.journey.*;
import com.hdfcbank.giftcity.bff.commons.constant.CommonConstants;
import com.hdfcbank.giftcity.bff.commons.enums.CommonJourneyStates;
import com.hdfcbank.giftcity.bff.commons.utility.TextSanityUtil;
import com.hdfcbank.giftcity.bff.customer.constants.CustomerConstants;
import com.hdfcbank.service.adapters.vo.customer.FetchCasaResponse;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.function.Function;

@Service
@Slf4j
@AllArgsConstructor
public class JourneyService {
    private static final ObjectMapper MAPPER = new ObjectMapper();

    private JourneyServiceFeignClient journeyServiceFeignClient;

    public static final String DEAFULT_MOBILE = "0000000000";

    public static Object getByPath(Object root, String path) {
        if (root == null || path == null) return null;
        return extract(root, path.split("\\."), 0);
    }

    @SuppressWarnings("unchecked")
    private static Object extract(Object current, String[] parts, int index) {
        if (current == null) return null;
        if (index == parts.length) return current;
        String key = parts[index];
        // ---- CASE 1: MAP ----
        if (current instanceof Map) {
            Map<String, Object> map = (Map<String, Object>) current;
            Object next = map.get(key);
            return extract(next, parts, index + 1);
        }
        // ---- CASE 2: LIST ----
        if (current instanceof List<?> list) {

            List<Object> result = new ArrayList<>();
            for (Object element : list) {
                Object value = extract(element, parts, index);
                if (value != null) result.add(value);
            }
            return result.get(0);
        }
        // ---- CASE 3: Primitive (String/Number/etc.) ----
        return current;
    }

    @SuppressWarnings("unchecked")
    public static Map<String, Object> convertToMap(Object input) {
        if (input == null) {
            return Collections.emptyMap();
        }
        // If already a Map → cast and convert child elements
        if (input instanceof Map) {
            Map<String, Object> original = (Map<String, Object>) input;
            Map<String, Object> result = new HashMap<>();

            for (Map.Entry<String, Object> entry : original.entrySet()) {
                result.put(entry.getKey(), convertValue(entry.getValue()));
            }
            return result;
        }
        // If not a map/document, return empty
        return Collections.emptyMap();
    }

    private static Object convertValue(Object value) {
        if (value == null) return null;
        if (value instanceof Map) {
            return convertToMap(value);
        }
        if (value instanceof List<?> list) {
            return new ArrayList<>(list);
        }
        // simple values: String, Integer, Double, Boolean, etc.
        return value;
    }

    public ApiResponse<?> saveJourney(JourneyData journeyData) {
        return journeyServiceFeignClient.saveJourney(journeyData);
    }

    public JourneyData fetchJourney(String journeyId) {
        return journeyServiceFeignClient.fetch(journeyId);
    }

    public ApiResponse<JourneyUpdateResponse> updateJourney(UpdateSystemDataJourneyRequest updateSystemDataJourneyRequest) {
        return journeyServiceFeignClient.updateResponse(updateSystemDataJourneyRequest);
    }

    public void updateJourneyState(String journeyId, String journeyState){
        journeyServiceFeignClient.updateJourneyState(journeyId, journeyState);
    }

    public <T> void updateJourney(String journeyId, String pageName, T data, CommonJourneyStates journeyStateName) {
        updateJourney(toUpdateSystemDataRequest(journeyId, pageName, data, journeyStateName));
    }

    public void updateProfile(String journeyId, CommonJourneyStates journeyStates, FetchCasaResponse.Profile profile) {

        UpdateSystemDataJourneyRequest request = new UpdateSystemDataJourneyRequest();

        JourneyState journeyState = new JourneyState(journeyStates.name(), new Date(), "");

        request.setJourneyId(journeyId);
        request.setJourneyState(journeyState);
        request.setProfile(toProfile(profile));
        updateJourney(request);
    }

    /**
     * This method is used to perform mapping for Journey update request.
     *
     * @param journeyId
     * @param pageName
     * @param data
     * @param journeyStateName
     * @return UpdateSystemDataJourneyRequest
     */
    public <T> UpdateSystemDataJourneyRequest toUpdateSystemDataRequest(String journeyId, String pageName, T data, CommonJourneyStates journeyStateName) {
        Map<String, T> dataMap = new HashMap<>();
        dataMap.put(pageName, data);
        return UpdateSystemDataJourneyRequest.builder().journeyId(journeyId).journeyState(toJourneyState(journeyStateName.name())).data(dataMap).dataType(JourneyDetailsDataType.SYSTEM_DATA).build();
    }

    public <T> void updateJourneyDetailDropOff(JourneyData journeyData, T apiResponseStatus) {
        Map<String, Map<String, ?>> systemData = journeyData.getJourneyDetail().getSystemData();

        @SuppressWarnings("unchecked") Map<String, Object> journeyDetail = (Map<String, Object>) systemData.getOrDefault(CommonConstants.JOURNEY_STATUS_DETAIL, new HashMap<>());

        journeyDetail.put(CommonConstants.JOURNEY_STATUS, CommonConstants.JOURNEY_DROP_OFF);
        journeyDetail.put(CommonConstants.JOURNEY_DROP_OFF, apiResponseStatus);

        journeyServiceFeignClient.update(toUpdateSystemDataRequest(journeyData.getJourneyId(), CommonConstants.JOURNEY_STATUS_DETAIL, journeyDetail, CommonJourneyStates.BUSINESS_VALIDATION_FAILED));
    }

    public static <T> Optional<T> extractFromJourney(JourneyData journeyData, String pageName, Class<T> targetClass) {
        return Optional.ofNullable(journeyData)
                .map(JourneyData::getJourneyDetail)
                .map(JourneyDetail::getSystemData)
                .map(data -> data.get(pageName))
                .map(raw -> MAPPER.convertValue(raw, targetClass));
    }

    public static <T, R> Optional<R> extractFromJourney(
            JourneyData journeyData,
            String pageName,
            Class<T> targetClass,
            Function<T, R> extractor
    ) {
        return Optional.ofNullable(journeyData)
                .map(JourneyData::getJourneyDetail)
                .map(JourneyDetail::getSystemData)
                .map(data -> data.get(pageName))
                .map(raw -> MAPPER.convertValue(raw, targetClass))
                .map(extractor);
    }

    public Object getDataFromJourneyService(Map<String, ?> systemData, String keyPath) {
        if (systemData == null || keyPath == null || keyPath.isEmpty()) {
            return "";
        }
        String[] keys = keyPath.split("\\.");
        Object current = systemData;
        for (String key : keys) {
            if (!(current instanceof Map<?, ?> currentMap)) {
                return "";
            }
            current = currentMap.get(key);

            if (current == null) {
                return "";
            }
        }
        return current;
    }

    private JourneyState toJourneyState(String stateName) {
        return JourneyState.builder().createdOn(new Date()).stateName(stateName).build();
    }


    private Profile toProfile(FetchCasaResponse.Profile profile) {

        return Profile.builder().firstName(profile.getName())
                .dob(profile.getDob())
                .gender(profile.getGender())
                .fullName(profile.getName())
                .title(profile.getCustomerTitle())
                .addresses(List.of(Address.builder()
                                .type(CustomerConstants.PERMANENT_ADDRESS_TYPE)
                                .address1(profile.getAddress())
                                .address2(profile.getAddress2())
                                .city(profile.getCity())
                                .state(profile.getState())
                                .zipCode(profile.getPinCode())
                                .build(),
                        Address.builder()
                                .type(CustomerConstants.MAILING_ADDRESS_TYPE)
                                .address1(profile.getMailingAddress1())
                                .address2(profile.getMailingAddress2())
                                .city(profile.getMailingCity())
                                .state(profile.getMailingState())
                                .zipCode(profile.getMailingPinCode())
                                .build()))
                .pinCode(profile.getPinCode())
                .emailId(profile.getEmail())
                .panNumber(profile.getPanNumber())
                .identifierName(profile.getIdentifierName())
                .customerType(profile.getCustomerType())
                .ethnicCode(profile.getEthnicCode())
                .customerId(profile.getCustomerId())
                .build();
    }
    public void recordJourneyState(String journeyId, CommonJourneyStates journeyStates) {
        log.info("Recording journeyState {} for journeyId {} ", TextSanityUtil.sanitize(journeyStates.enumName), TextSanityUtil.sanitize(journeyId));
        journeyServiceFeignClient.updateJourneyState(journeyId,journeyStates.name());
    }

    @SuppressWarnings("unchecked")
    public <T> void updateJourneyDetailDropOff(JourneyData journeyData, T apiResponseStatus, CommonJourneyStates journeyStateName) {

        Map<String, Map<String, ?>> systemData = journeyData.getJourneyDetail().getSystemData();

        if (systemData == null) {
            systemData = new HashMap<>();
        }

        Map<String, Object> journeyDetail =
                (Map<String, Object>) systemData.computeIfAbsent(
                        CommonConstants.JOURNEY_STATUS_DETAIL,
                        k -> new HashMap<>());

        Object dropOffObj = journeyDetail.get(CommonConstants.JOURNEY_DROP_OFF);

        List<T> journeyDropOff;

        if (dropOffObj == null) {
            journeyDropOff = new ArrayList<>();
        } else if (dropOffObj instanceof List<?>) {
            journeyDropOff = (List<T>) dropOffObj;
        } else {
            journeyDropOff = new ArrayList<>();
            journeyDropOff.add((T) dropOffObj);
        }

        journeyDropOff.add(apiResponseStatus);

        journeyDetail.put(CommonConstants.JOURNEY_DROP_OFF, new ArrayList<>(new LinkedHashSet<>(journeyDropOff)));
        systemData.put(CommonConstants.JOURNEY_STATUS_DETAIL, journeyDetail);

        UpdateSystemDataJourneyRequest request =
                UpdateSystemDataJourneyRequest.builder()
                        .journeyId(journeyData.getJourneyId())
                        .journeyState(toJourneyState(journeyStateName.name()))
                        .dataType(JourneyDetailsDataType.SYSTEM_DATA)
                        .data(systemData)
                        .build();

        journeyServiceFeignClient.update(request);
    }

    public Optional<JourneyData> fetchJourneyByReferenceNo(String referenceNo) {

        Map<String, Object> filters = Map.of("referenceNo", referenceNo);

        FetchDynamicDataRequest request = FetchDynamicDataRequest.builder()
                .operationType("AND")
                .filters(filters)
                .build();

        List<JourneyData> journeyList = fetchDynamicJourneyData(request);

        if (journeyList != null && !journeyList.isEmpty()) {
            return Optional.of(journeyList.get(0));
        }

        return Optional.empty();
    }

    public List<JourneyData> fetchDynamicJourneyData(FetchDynamicDataRequest request) {
        ApiResponse<List<JourneyData>> response =
                journeyServiceFeignClient.fetchDynamicDataResponse(request);

        journeyServiceFeignClient.handleErrors(response.getStatus());

        return response.getData();
    }

    public static Map<String, Object> getDomainPageUserInputs(JourneyData journeyData, String pageName) {
        return Optional.ofNullable(journeyData)
                .map(JourneyData::getJourneyDetail)
                .map(JourneyDetail::getDomainData)
                .map(domainData -> domainData.get(pageName))
                .map(JourneyPage::getUserInputs)
                .orElseGet(Collections::emptyMap);
    }
}
