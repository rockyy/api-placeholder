package com.hdfcbank.giftcity.bff.customer.utility;

import com.hdfcbank.giftcity.bff.commons.validation.JourneyDataProcessor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class JourneyDataProcessorFactory {

    @Autowired
    JourneyValidationProcessor casaJourneyDataProcessor;

    public JourneyDataProcessor getJourneyDataValidation() {
        return casaJourneyDataProcessor;
    }
}
