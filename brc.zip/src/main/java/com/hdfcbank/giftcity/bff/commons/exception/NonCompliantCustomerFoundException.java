package com.hdfcbank.giftcity.bff.commons.exception;

import org.springframework.http.HttpStatus;

public class NonCompliantCustomerFoundException extends Exception {

    public NonCompliantCustomerFoundException(String message) {
        super();
    }

    public NonCompliantCustomerFoundException(HttpStatus status, String message) {
        super();
    }

    public NonCompliantCustomerFoundException(HttpStatus status, String message, Throwable e) {
        // Preserve the existing exception contract: status, message and cause are not retained.
    }
}
