package com.hdfcbank.giftcity.bff.application.handlers.submit;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.hdfcbank.giftcity.bff.commons.enums.JourneyPageName;
import com.hdfcbank.giftcity.bff.commons.model.FcGcProfile;
import com.hdfcbank.giftcity.bff.customer.constants.CustomerConstants;
import com.hdfcbank.service.adapters.clients.feign.account.AccountServiceFeignClient;
import com.hdfcbank.service.adapters.vo.account.CreateCustomerAccountRequest;
import com.hdfcbank.service.adapters.vo.account.CreateCustomerAccountResponse;
import com.hdfcbank.common.models.vo.journey.JourneyData;
import com.hdfcbank.giftcity.bff.account.mapper.CreateCustomerAccountMapper;
import com.hdfcbank.giftcity.bff.commons.enums.CommonJourneyStates;
import com.hdfcbank.giftcity.bff.commons.exception.handler.DownstreamResponseHandler;
import com.hdfcbank.giftcity.bff.commons.handler.Handler;
import com.hdfcbank.giftcity.bff.commons.handler.HandlerContext;
import com.hdfcbank.giftcity.bff.commons.handler.HandlerResult;
import com.hdfcbank.giftcity.bff.commons.model.FcIndiaProfile;
import com.hdfcbank.giftcity.bff.customer.config.CustomerApiProperties;
import com.hdfcbank.giftcity.bff.customer.model.ReviewCustomerResponse;
import com.hdfcbank.giftcity.bff.customer.utility.CustomerUtil;
import com.hdfcbank.giftcity.bff.infrastructure.service.JourneyService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Service;

import java.util.Map;
import java.util.Optional;
import java.util.function.Function;

import static com.hdfcbank.giftcity.bff.commons.enums.CommonJourneyStates.CREATE_FCC_CUSTOMER_ACCOUNT_FAILURE;
import static com.hdfcbank.giftcity.bff.commons.enums.CommonJourneyStates.CREATE_FCC_CUSTOMER_ACCOUNT_SUCCESS;
import static com.hdfcbank.giftcity.bff.customer.constants.CustomerConstants.*;

@Slf4j
@Service
@RequiredArgsConstructor
@Order(3)
public class CreateCustomerAccountHandler implements Handler<CreateCustomerAccountResponse> {

    private final CustomerApiProperties customerApiProperties;
    private final JourneyService journeyService;
    private final AccountServiceFeignClient accountServiceFeignClient;
    private final CreateCustomerAccountMapper createCustomerAccountMapper;

    private static final String SUCCESS = "0000";

    @Override
    public boolean preConditions(HandlerContext handlerContext) {
        return isSuccess(handlerContext, HandlerName.CREATE_CUSTOMER);
    }

    @Override
    public HandlerResult<CreateCustomerAccountResponse> handle(HandlerContext handlerContext) {
        JourneyData journeyData = handlerContext.getJourneyData();
        try {
            log.info("Calling Account Service createCustomerAccount API");
            Map<String, String> serviceDefaults = customerApiProperties.getCreateFccCustomerAccount().getServiceDefaults();
            FcIndiaProfile.Profile fcProfile = CustomerUtil.getPrimaryProfile(journeyData).orElse(null);
            String customerNumber = CustomerUtil.getFCGiftCityProfile(journeyData)
                    .map(FcGcProfile::getCustomerNumber)
                    .orElse(null);

            ReviewCustomerResponse.ReviewCustomerDetails.NomineeDetail nomineeDetail = CustomerUtil.getNomineeDetailFromJourneyData(journeyData);
            ReviewCustomerResponse.ReviewCustomerDetails.Nominee nomineeDetails = nomineeDetail != null ? nomineeDetail.getNominee() : null;
            ReviewCustomerResponse.ReviewCustomerDetails.Nominee guardianDetails = nomineeDetail != null ? nomineeDetail.getGuardian() : null;

            String currency =  CustomerUtil.getValueByPath(journeyData, CustomerConstants.CUSTOMER_DETAILS, EMPLOYMENT_CURRENCY_PATH);

            CreateCustomerAccountRequest request = createCustomerAccountMapper.toRequest(journeyData, customerNumber, fcProfile, nomineeDetail, nomineeDetails, guardianDetails, serviceDefaults, currency);


            CreateCustomerAccountResponse response = accountServiceFeignClient.createFccCustomerAccount(request, journeyData.getJourneyId());


            if (SUCCESS.equals(response.getStatus().getCode())) {
                    Optional<FcGcProfile> fcGcProfile = JourneyService.extractFromJourney(
                            journeyData,
                            JourneyPageName.CUSTOMER_FC_GIFT_CITY_DETAIL.getPageName(),
                            FcGcProfile.class,
                            Function.identity()
                    );

                    fcGcProfile.ifPresent(profile -> {
                        profile.setAccountNumber(response.getData().getAccountNumber());

                        journeyService.updateJourney(
                                journeyData.getJourneyId(),
                                JourneyPageName.CUSTOMER_FC_GIFT_CITY_DETAIL.getPageName(),
                                profile,
                                CommonJourneyStates.CUSTOMER_FC_GC_DETAIL_CAPTURED
                        );
                    });
                return HandlerResult.of(null, response, true);
            }
            log.error("CreateCustomerAccount failed with code={} errors={}", response.getStatus().getCode(), response.getStatus().getErrors());
            return HandlerResult.of(DownstreamResponseHandler.handleResponse(response, HandlerName.CREATE_ACCOUNT.name(), false,
                    journeyData.getJourneyName()), response, false);
        } catch (Throwable ex) {
            log.error("Exception while creating FCC customer account", ex);
            return HandlerResult.<CreateCustomerAccountResponse>of(DownstreamResponseHandler.handleResponse(null, HandlerName.CREATE_ACCOUNT.name(), false,
                    journeyData.getJourneyName()), null, false);
        }
    }

    @Override
    public HandlerType getType() {
        return HandlerType.CUSTOMER_POST_SUBMIT;
    }

    @Override
    public HandlerName getName() {
        return HandlerName.CREATE_ACCOUNT;
    }

    @Override
    public CommonJourneyStates successState() {
        return CREATE_FCC_CUSTOMER_ACCOUNT_SUCCESS;
    }

    @Override
    public CommonJourneyStates failureState() {
        return CREATE_FCC_CUSTOMER_ACCOUNT_FAILURE;
    }

}
