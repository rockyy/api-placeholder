package com.hdfcbank.giftcity.bff.commons.exception;

import com.hdfcbank.common.models.vo.core.ApiResponseStatusCodeLiteral;
import lombok.Getter;

@Getter
public class SOATokenException extends RuntimeException {

    private final ApiResponseStatusCodeLiteral apiResponseStatusCodeLiteral;

    public SOATokenException(ApiResponseStatusCodeLiteral statusCode) {
        super(statusCode.getMessage());
        this.apiResponseStatusCodeLiteral = statusCode;
    }

    public SOATokenException(ApiResponseStatusCodeLiteral statusCode, Throwable cause) {
        super(statusCode.getMessage(), cause);
        this.apiResponseStatusCodeLiteral = statusCode;
    }
}