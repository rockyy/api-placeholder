package com.hdfcbank.giftcity.bff.account.service;

import com.hdfcbank.adapters.vo.FetchDynamicDataRequest;
import com.hdfcbank.common.models.vo.journey.JourneyData;
import com.hdfcbank.giftcity.bff.commons.constant.CommonConstants;
import com.hdfcbank.giftcity.bff.commons.enums.CommonJourneyStates;
import com.hdfcbank.giftcity.bff.commons.exception.handler.DownstreamResponseHandler;
import com.hdfcbank.giftcity.bff.commons.model.CustomValidationStatus;
import com.hdfcbank.giftcity.bff.commons.model.FtsDetails;
import com.hdfcbank.giftcity.bff.commons.utility.MDCLoggerUtil;
import com.hdfcbank.giftcity.bff.commons.utility.TextSanityUtil;
import com.hdfcbank.giftcity.bff.customer.model.CustomerApiStatusCode;
import com.hdfcbank.giftcity.bff.infrastructure.service.JourneyService;
import com.hdfcbank.service.adapters.vo.account.FTSApplicationInquireApiResponse;
import com.hdfcbank.service.adapters.vo.account.FTSApplicationInquireRequest;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.*;

import static com.hdfcbank.giftcity.bff.commons.enums.JourneyPageName.FTS_DETAILS;

@Service
@Slf4j
@RequiredArgsConstructor
public class FtsApplicationInquireService {

    private final AccountService accountService;
    private final JourneyService journeyService;

    public static final String FTS_ENQUIRY_STATUS_PROCESSED = "Processed";
    public static final String FTS_ENQUIRY_STATUS_REJECTED = "Rejected";
    public static final String FTS_ENQUIRY_STATUS_PENDING = "Pending";
    public static final String SUCCESS_CODE = "0000";

    // MAIN SCHEDULER METHOD
    public void inquireApplicationsAndUpdateJourneyState() {

        log.info("Starting FTS application inquiry scheduler.");

        try {
            List<JourneyData> journeyList =
                    Optional.ofNullable(journeyService.fetchDynamicJourneyData(buildJourneyStateFilterRequest()))
                            .orElse(Collections.emptyList());

            log.info("Found {} journey(s) eligible for FTS application inquiry.", journeyList.size());

            for (JourneyData journeyData : journeyList) {

                MDCLoggerUtil.populateMDC(journeyData);

                String journeyId = TextSanityUtil.sanitize(journeyData.getJourneyId());

                //         NEW METHOD CALLED HERE — replaces the entire inner try/catch
                processSingleJourneySafely(journeyData, journeyId);
            }

        } catch (Exception ex) {
            log.error("Unexpected error occurred while executing FTS application inquiry.", ex);
        }

        log.info("Completed FTS application inquiry scheduler.");
    }


    //         NEW METHOD EXTRACTED FROM THE NESTED TRY BLOCK
    // --------------------------------------------------------
    // This method wraps the original inner try/catch. No logic changed.
    private void processSingleJourneySafely(JourneyData journeyData, String journeyId) {
        try {
            // Original inner logic
            processSingleJourney(journeyData, journeyId);

        } catch (Exception ex) {

            log.error("Error processing journeyId={}.", journeyId, ex);

            // Original catch block preserved exactly
            journeyService.updateJourneyDetailDropOff(
                    journeyData,
                    DownstreamResponseHandler.handleResponse(
                            null,
                            CommonConstants.FTS_INQUIRE,
                            false,
                            journeyData.getJourneyName()
                    ),
                    CommonJourneyStates.FTS_AOF_INQUIRE_FAILURE
            );
        }
    }

    //         ORIGINAL JOURNEY PROCESS LOGIC — NO CHANGE
    private void processSingleJourney(JourneyData journeyData, String journeyId) {

        log.info("Processing journeyId={}", journeyId);

        FtsDetails.FtsAccountOpeningDetails details = extractOpeningDetails(journeyData);

        if (isMissingAcknowledgement(details)) {
            log.warn("Skipping journeyId={} as acknowledgement number is missing.", journeyId);
            return;
        }

        String acknowledgementNo = details.getAcknowledgementNo();

        FTSApplicationInquireApiResponse response =
                performFtsInquiry(journeyData, journeyId, acknowledgementNo);

        if (!isValidResponse(response)) {

            log.warn("Received invalid FTS inquiry response for journeyId={}, acknowledgementNo={}",
                    journeyId,
                    TextSanityUtil.sanitize(acknowledgementNo)
            );

            journeyService.updateJourneyDetailDropOff(
                    journeyData,
                    DownstreamResponseHandler.handleResponse(
                            response,
                            CommonConstants.FTS_INQUIRE,
                            false,
                            journeyData.getJourneyName()),
                    CommonJourneyStates.FTS_AOF_INQUIRE_FAILURE
            );

            return;
        }

        String enquiryStatus =
                response.getData().getResponseString().getEnquiryStatus();

        log.info("Received enquiryStatus={} for journeyId={}",
                TextSanityUtil.sanitize(enquiryStatus),
                journeyId);

        handleEnquiryStatus(journeyData, journeyId, response, enquiryStatus);

        journeyService.recordJourneyState(
                journeyData.getJourneyId(),
                CommonJourneyStates.FTS_AOF_INQUIRE_SUCCESS
        );
    }


    // HELPER: Extract Opening Details
    private FtsDetails.FtsAccountOpeningDetails extractOpeningDetails(JourneyData journeyData) {
        return JourneyService.extractFromJourney(
                        journeyData,
                        FTS_DETAILS.getPageName(),
                        FTS_DETAILS.getPageClassName(),
                        x -> (FtsDetails) x)
                .map(FtsDetails::getFtsAccountOpeningDetails)
                .orElse(null);
    }

    private boolean isMissingAcknowledgement(FtsDetails.FtsAccountOpeningDetails details) {
        return details == null || details.getAcknowledgementNo() == null;
    }

    // HELPER: Execute the API Inquiry Call
    private FTSApplicationInquireApiResponse performFtsInquiry(
            JourneyData journeyData, String journeyId, String acknowledgementNo) {

        log.info("Invoking FTS inquiry API for journeyId={}, acknowledgementNo={}",
                journeyId,
                TextSanityUtil.sanitize(acknowledgementNo));

        FTSApplicationInquireRequest request = new FTSApplicationInquireRequest();
        request.setAcknowledgementNo(acknowledgementNo);

        return accountService.ftsApplicationInquire(request, journeyData.getJourneyId());
    }

    // HELPER: Validate Response Structure
    private boolean isValidResponse(FTSApplicationInquireApiResponse response) {
        return response != null
                && response.getStatus() != null
                && SUCCESS_CODE.equalsIgnoreCase(response.getStatus().getCode())
                && response.getData() != null
                && response.getData().getResponseString() != null;
    }

    // HELPER: Handle Enquiry Status Branching
    private void handleEnquiryStatus(
            JourneyData journeyData,
            String journeyId,
            FTSApplicationInquireApiResponse response,
            String enquiryStatus) {

        if (FTS_ENQUIRY_STATUS_PROCESSED.equalsIgnoreCase(enquiryStatus)) {

            journeyService.updateJourneyState(
                    journeyData.getJourneyId(),
                    CommonJourneyStates.FTS_AOF_SUBMIT_SUCCESS.name()
            );

            log.info("Updated journeyId={} to journeyState={}",
                    journeyId,
                    CommonJourneyStates.FTS_AOF_SUBMIT_SUCCESS.name());

        } else if (FTS_ENQUIRY_STATUS_REJECTED.equalsIgnoreCase(enquiryStatus)) {

            CustomValidationStatus validationStatus = CustomValidationStatus.builder()
                    .title(CustomerApiStatusCode.UNKNOWN.getMessage())
                    .code(Optional.ofNullable(
                                    response.getData().getResponseString().getErrorCode()
                            ).map(Object::toString)
                            .orElse(""))
                    .message(response.getData().getResponseString().getEnquiryRejectReason())
                    .build();

            journeyService.updateJourneyDetailDropOff(
                    journeyData,
                    validationStatus,
                    CommonJourneyStates.FTS_AOF_SUBMIT_FAILURE
            );

            log.info("Updated journeyId={} to failure journeyState={}",
                    journeyId,
                    CommonJourneyStates.FTS_AOF_SUBMIT_FAILURE.name());

        } else {
            log.info("No journey state update required for journeyId={} with enquiryStatus={}",
                    journeyId,
                    TextSanityUtil.sanitize(enquiryStatus));
        }
    }

    // HELPER: Build Mongo Journey Filter Request
    private FetchDynamicDataRequest buildJourneyStateFilterRequest() {

        Map<String, Object> stateNameFilter = new HashMap<>();
        stateNameFilter.put("$eq", CommonJourneyStates.FTS_AOF_POSTED_SUCCESS.name());
        stateNameFilter.put("$nin", List.of(
                CommonJourneyStates.FTS_AOF_SUBMIT_SUCCESS.name(),
                CommonJourneyStates.FTS_AOF_SUBMIT_FAILURE.name()
        ));

        Map<String, Object> filters = new HashMap<>();
        filters.put("journeyDetail.journeyStates.stateName", stateNameFilter);

        return FetchDynamicDataRequest.builder()
                .operationType("AND")
                .filters(filters)
                .build();
    }
}