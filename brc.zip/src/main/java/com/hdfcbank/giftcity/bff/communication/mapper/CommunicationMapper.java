package com.hdfcbank.giftcity.bff.communication.mapper;

import com.hdfcbank.adapters.vo.GenerateOtpRequest;
import com.hdfcbank.adapters.vo.VerifyOtpRequest;
import com.hdfcbank.giftcity.bff.commons.utility.TextSanityUtil;
import com.hdfcbank.giftcity.bff.customer.config.CustomerApiProperties;
import com.hdfcbank.giftcity.bff.customer.model.ValidateCustomerRequest;
import com.hdfcbank.giftcity.bff.customer.utility.CustomerUtil;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.Map;

@Component
@RequiredArgsConstructor
public class CommunicationMapper {


    private final CustomerApiProperties customerApiProperties;

    public GenerateOtpRequest toGenerateOtpRequest(String mobileNumber, String email, String templateId) {

        Map<String, String> serviceDefaults =
                customerApiProperties.getGenerateAndDispatchOtp().getServiceDefaults();

        return GenerateOtpRequest.builder()
                .mobileNumber(TextSanityUtil.sanitize(mobileNumber))
                .emailId(CustomerUtil.sanitizeEmail(email))
                .messageType(TextSanityUtil.sanitize(serviceDefaults.getOrDefault("messageType", "SMS")))
                .templateId(TextSanityUtil.sanitize(templateId))
                .channel(TextSanityUtil.sanitize(serviceDefaults.get("channel")))
                .build();
    }

    public VerifyOtpRequest toVerifyOtpRequest(ValidateCustomerRequest request, Map<String, String> serviceDefaults) {
        return VerifyOtpRequest.builder()
                .otpValue(CustomerUtil.sanitizeOtp(request.getOtp()))
                .messageType(TextSanityUtil.sanitize(serviceDefaults.getOrDefault("messageType", "SMS")))
                .channel(TextSanityUtil.sanitize(serviceDefaults.get("channel")))
                .txnRef(TextSanityUtil.sanitize(request.getTxnRef()))
                .build();
    }

}
