package com.hdfcbank.giftcity.bff.customer.model;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ProfileDetails {

    private String proposerFirstName;
    private String proposerLastName;
    private String proposerEmail;
    private String proposerPhoneNumber;
    private String proposerDob;
    private String proposerGender;
    private String pincode;
    private String state;
    private String city;
    private String addressLine1;
    private String addressLine2;
    private String proposerPan;
    private String proposerTitle;

}
