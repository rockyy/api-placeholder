package com.hdfcbank.giftcity.bff.commons.handler;

import com.hdfcbank.giftcity.bff.commons.model.CustomValidationStatus;

/** Execution status shared by all handler result types. */
public interface HandlerOutcome {

    CustomValidationStatus getApiResponseStatus();
    boolean isSuccess();
}
