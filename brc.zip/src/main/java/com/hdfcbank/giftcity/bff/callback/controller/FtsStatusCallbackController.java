package com.hdfcbank.giftcity.bff.callback.controller;

import com.hdfcbank.giftcity.bff.callback.model.FtsStatusCallbackRequest;
import com.hdfcbank.giftcity.bff.callback.model.FtsStatusCallbackResponse;
import com.hdfcbank.giftcity.bff.callback.service.FtsStatusCallbackService;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@RestController
@RequestMapping("${api.giftcity.base-path}/callback")
public class FtsStatusCallbackController {

    @Autowired
    private FtsStatusCallbackService service;


    @PostMapping("/fts-status")
    public ResponseEntity<FtsStatusCallbackResponse> processFtsStatusCallback(
            @Valid @RequestBody FtsStatusCallbackRequest request) {

        log.info("Incoming /fts-status callback ");

        return ResponseEntity.ok(service.processFtsStatusCallback(request));
    }
}



