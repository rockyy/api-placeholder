package com.hdfcbank.giftcity.bff.customer.mapper;

import com.hdfcbank.common.models.vo.journey.JourneyData;
import com.hdfcbank.giftcity.bff.commons.model.MasterDataValue;
import com.hdfcbank.giftcity.bff.customer.constants.CustomerConstants;
import com.hdfcbank.giftcity.bff.commons.model.FcIndiaProfile;
import com.hdfcbank.giftcity.bff.customer.utility.CustomerUtil;
import com.hdfcbank.service.adapters.vo.customer.CustomerRiskAnalysisRequest;
import org.mapstruct.*;

@Mapper(
        componentModel = "spring",
        imports = {CustomerConstants.class, CustomerUtil.class, FcIndiaProfile.class, MasterDataValue.class},
        nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS,
        nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE,
        unmappedTargetPolicy = ReportingPolicy.IGNORE
)
public interface CustomerRiskAnalysisMapper {

    @Mapping(target = "occupation", expression = "java(CustomerUtil.getValueByPath(journeyData, CustomerConstants.CUSTOMER_DETAILS,  CustomerConstants.EMPLOYMENT_OCCUPATION_PATH))")
    @Mapping(target = "industry", expression = "java(CustomerUtil.getValueByPath(journeyData,  CustomerConstants.CUSTOMER_DETAILS,  CustomerConstants.EMPLOYMENT_INDUSTRY_PATH))")
    @Mapping(target = "sourceOfIncome", expression = "java(CustomerUtil.getValueByPath(journeyData,  CustomerConstants.CUSTOMER_DETAILS,  CustomerConstants.EMPLOYMENT_SOURCE_OF_INCOME_PATH))")
    @Mapping(target = "kycType", expression = "java(CustomerUtil.getPrimaryProfile(journeyData).map(FcIndiaProfile.Profile::getKycType).orElse(null))")
    @Mapping(target = "mailingCountry",  expression = "java(CustomerUtil.getPrimaryProfile(journeyData).map(FcIndiaProfile.Profile::getMailingCountry).map(MasterDataValue::getCode).orElse(null))")
    @Mapping(target = "annualTransactionAmountUsd", expression = "java(CustomerUtil.convertToDouble(CustomerUtil.getValueByPath(journeyData,  CustomerConstants.CUSTOMER_DETAILS,  CustomerConstants.EMPLOYMENT_MONTHLY_AMOUNT_PATH)))")
    @Mapping(target = "pep", expression = "java(CustomerUtil.getValueByPath(journeyData,  CustomerConstants.CUSTOMER_DETAILS,  CustomerConstants.EMPLOYMENT_PEP_PATH))")

    CustomerRiskAnalysisRequest.CustomerDetails toCustomerDetails(JourneyData journeyData);

    default CustomerRiskAnalysisRequest toRequest(JourneyData journeyData) {
        CustomerRiskAnalysisRequest request = new CustomerRiskAnalysisRequest();
        request.setCustomerDetails(toCustomerDetails(journeyData));
        return request;
    }
}

