package com.hdfcbank.giftcity.bff.customer.mapper;

import com.hdfcbank.common.models.vo.journey.Profile;
import com.hdfcbank.giftcity.bff.commons.model.FcIndiaProfile;
import com.hdfcbank.service.adapters.vo.customer.UcicRequest;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring")
public interface UcicRequestMapper {

    @Mapping(source = "name", target = "customerName")
    @Mapping(source = "panNumber", target = "panNo")
    UcicRequest toRequest(FcIndiaProfile.Profile profile);

}