package com.hdfcbank.giftcity.bff.customer.mapper;

import com.hdfcbank.common.models.vo.journey.JourneyData;
import com.hdfcbank.common.models.vo.journey.Profile;
import com.hdfcbank.giftcity.bff.commons.constant.CommonConstants;
import com.hdfcbank.giftcity.bff.commons.model.FcIndiaProfile;
import com.hdfcbank.giftcity.bff.commons.utility.CommonUtil;
import com.hdfcbank.giftcity.bff.customer.model.CustomerDetails;
import com.hdfcbank.giftcity.bff.customer.model.RiskAssessmentPageData;
import com.hdfcbank.giftcity.bff.customer.utility.CustomerUtil;
import com.hdfcbank.giftcity.bff.infrastructure.service.JourneyService;
import com.hdfcbank.giftcity.bff.master.mapper.CountryMapper;
import com.hdfcbank.service.adapters.vo.customer.FccCustomerRequest;
import com.hdfcbank.service.adapters.vo.customer.FetchKycResponse;
import io.micrometer.common.util.StringUtils;
import org.mapstruct.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeParseException;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static com.hdfcbank.giftcity.bff.commons.constant.CommonConstants.*;
import static com.hdfcbank.giftcity.bff.customer.constants.CustomerConstants.NO;
import static com.hdfcbank.giftcity.bff.customer.constants.CustomerConstants.YES;
import static com.hdfcbank.giftcity.bff.customer.constants.CustomerConstants.*;


@Mapper(componentModel = "spring", unmappedTargetPolicy = ReportingPolicy.IGNORE, imports = {CommonConstants.class, CommonUtil.class}, uses = CountryMapper.class)
public interface CreateFCCCustomerMapper {

    Logger log = LoggerFactory.getLogger(CreateFCCCustomerMapper.class);

    @BeanMapping(ignoreByDefault = true)
    @Mapping(target = "ctype", expression = "java(getValue(serviceDefaults, CommonConstants.CC_CTYPE))")
    @Mapping(target = "name", source = "fcProfile.name")
    @Mapping(target = "addrLn1", source = "fcProfile.mailingAddress1")
    @Mapping(target = "addrLn2", source = "fcProfile.mailingAddress2")
    @Mapping(target = "addrLn3", source = "fcProfile.mailingAddress3")
    @Mapping(
            target = "addrLn4",
            expression =
                    "java(joinAddress(" +
                            "fcProfile.getMailingCity(), " +
                            "fcProfile.getMailingState(), " +
                            "(fcProfile.getMailingCountry() != null ? " +
                            "fcProfile.getMailingCountry().getDescription() : null)" +
                            "))")
    @Mapping(target = "corresAddCity", source = "fcProfile.mailingCity")
    @Mapping(target = "corresAddState", source = "fcProfile.mailingState")
    @Mapping(target = "corresPinCode", source = "fcProfile.mailingPinCode")
    @Mapping(target = "country", source = "fcProfile.mailingCountry", qualifiedByName = "codeFromMasterData")
    @Mapping(target = "nationality", source = "fcProfile.txtCustNATNLTY")
    @Mapping(target = "ccateg", expression = "java(getValue(serviceDefaults, CommonConstants.CCATEG))")
    @Mapping(target = "media", expression = "java(getValue(serviceDefaults, CommonConstants.CC_MEDIA))")
    @Mapping(target = "cifCreationDate", expression = "java(java.time.LocalDate.now())")
    @Mapping(target = "paddress", expression = "java(mapPAddress(fcProfile))")
    @Mapping(target = "custPersonal", expression = "java(mapCustPersonal(fcProfile, journeyData, profile, customerUserInputs,serviceDefaults,createFccMasterMapper))")
    @Mapping(target = "employed", expression = "java(mapEmployed(mapEmployment(customerUserInputs), fcProfile,createFccMasterMapper,customerUserInputs))")
    @Mapping(target = "newEmp", expression = "java(mapNewEmp(serviceDefaults, mapEmployment(customerUserInputs)))")
    @Mapping(target = "udfDetails", expression = "java(mapUdf(fcProfile, customerUserInputs,serviceDefaults,riskAssessmentPageData, journeyData))")
    @Mapping(target = "custMis", expression = "java(buildCustMis(serviceDefaults))")
    @Mapping(target = "rmLinkage", expression = "java(buildRmLinkage(journeyData,serviceDefaults))")
    @Mapping(target = "compositeMis", expression = "java(buildCompositeMis(serviceDefaults))")
    @Mapping(target = "custText", expression = "java(mapCustText(mapEmployment(customerUserInputs)))")
    @Mapping(target = "custAml", expression = "java(mapCustAml(mapEmployment(customerUserInputs)))")

    @Mapping(target = "individual", expression = "java(mapIndividual(mapEmployment(customerUserInputs),createFccMasterMapper))")

    @Mapping(target = "SName", expression = "java(CommonUtil.generateRefNumber(CommonConstants.PI))")
    // Keep the generated short name until the FCC naming contract is confirmed.
    // Location uses the profile country; the former configuration-based mapping is obsolete.
    @Mapping(target = "location", source = "fcProfile.namCustadrCntry")
    @Mapping(target = "trackLimits", expression = "java(getValue(serviceDefaults, CommonConstants.TRACK_LIMITS))")
    @Mapping(target = "taxCode1", expression = "java(getValue(serviceDefaults, CommonConstants.TAX_CODE1))")
    @Mapping(target = "ucicNo", source = "ucicNo")
    @Mapping(target = "ckycNo", expression = "java(getCkycNo(journeyData))")
    @Mapping(target = "ckycDate", expression = "java(getdateOfKycUpdate(journeyData))")
    // Explicit taxCountry mapping remains disabled pending the FCC field contract.
    @Mapping(target = "typeOfDis", expression = "java(getTypeOfDis(journeyData))")
    FccCustomerRequest toRequest(@Context JourneyData journeyData, Profile profile, FcIndiaProfile.Profile fcProfile, @Context Map<String, String> serviceDefaults,
                                 Map<String, Object> customerUserInputs, CreateFccMasterMapper createFccMasterMapper,
                                 RiskAssessmentPageData riskAssessmentPageData, String ucicNo);

    @BeanMapping(ignoreByDefault = true)
    @Mapping(target = "ifSalariedEmployedWith", expression = "java(getIfSalariedEmployedWith(employment))")
    @Mapping(target = "employerBusinessIndustry", expression = "java(mapEmployerBusinessIndustry(mapEmployment(customerUserInputs),createFccMasterMapper))")
    @Mapping(target = "natureOfBusiness", expression = "java(createFccMasterMapper.resolveNatureOfBusiness(employment.getIndustryVariation()))")
    @Mapping(target = "selfEmployedProfession", expression = "java(getSelfEmployedProfession(employment))")
    @Mapping(target = "selfEmployedSince", source = "employment.employedSince")
    FccCustomerRequest.Employed mapEmployed(CustomerDetails.EmploymentFinancial employment, FcIndiaProfile.Profile fcProfile, CreateFccMasterMapper createFccMasterMapper, Map<String, Object> customerUserInputs);

    @BeanMapping(ignoreByDefault = true)
    @Mapping(target = "add1", expression = "java(getFatcaField(fcProfile, f -> f.getTxtEmpadrAdd1()))")
    @Mapping(target = "add2", expression = "java(getFatcaField(fcProfile, f -> f.getTxtEmpadrAdd2()))")
    @Mapping(target = "add3", expression = "java(getFatcaField(fcProfile, f -> f.getTxtEmpadrAdd3()))")
    @Mapping(target = "pinCode", expression = "java(getFatcaField(fcProfile, f -> f.getTxtEmpadrZip()))")
    FccCustomerRequest.PAddress mapPAddress(FcIndiaProfile.Profile fcProfile);


    @Mapping(target = "empCode", expression = "java(getValue(serviceDefaults, CommonConstants.EMPCODE))")
    @Mapping(target = "empDesc", source = "employment.employerBusinessName")
    FccCustomerRequest.NewEmp mapNewEmp(Map<String, String> serviceDefaults, CustomerDetails.EmploymentFinancial employment);

    @BeanMapping(ignoreByDefault = true)
    @Mapping(target = "firstName", source = "fcProfile.customerFirstName")
    @Mapping(target = "lastName", source = "fcProfile.customerLastName")
    @Mapping(target = "fatherFirstName", expression = "java(getFatcaField(fcProfile, f -> f.getNamCustFather()))")
    @Mapping(target = "dob", expression = "java(parseLocalDate(profile.getDob()))")
    @Mapping(target = "gender", source = "fcProfile.txtCustSex")
    @Mapping(target = "emailId", expression = "java(profile.getEmailId())")
    @Mapping(target = "benefAddr1", source = "fcProfile.mailingAddress1")
    @Mapping(target = "benefAddr2", source = "fcProfile.mailingAddress2")
    @Mapping(target = "addrs3", source = "fcProfile.mailingAddress3")
    @Mapping(target = "mobileNumber", expression = "java(journeyData.getMobileNumber())")
    @Mapping(target = "dCountry", source = "fcProfile.namCustadrCntry")
    @Mapping(target = "dAdd1", source = "fcProfile.address")
    @Mapping(target = "dAdd2", source = "fcProfile.address2")
    @Mapping(target = "dAdd3", source = "fcProfile.address3")
    @Mapping(target = "dAdd4", source = "fcProfile.address4")
    @Mapping(
            target = "addrs4",
            expression =
                    "java(joinAddress(" +
                            "fcProfile.getState(), " +
                            "fcProfile.getCity(), " +
                            "(fcProfile.getCountry() != null ? " +
                            "fcProfile.getCountry().getDescription() : null)" +
                            "))")
    @Mapping(target = "permanentAddressCity", source = "fcProfile.city")
    @Mapping(target = "permanentAddressState", source = "fcProfile.state")
    @Mapping(target = "placeOfBirth", expression = "java(getFatcaField(fcProfile, f -> f.getNamCityBirth()))")
    @Mapping(target = "pCountry", source = "fcProfile.country.code")
    @Mapping(target = "pPinCode", source = "fcProfile.pinCode")
    @Mapping(target = "motherMaidenName", source = "fcProfile.motherMaidenName")
    @Mapping(target = "birthCountry", expression = "java(getFatcaField(fcProfile, f -> f.getCodCntryBirth()))")
    @Mapping(target = "panNumber", source = "fcProfile.refCustItNum")
    @Mapping(target = "mobIsdNo", expression = "java(journeyData.getIsd())")
    @Mapping(target = "resStatus", expression = "java(getValue(serviceDefaults, CommonConstants.RESSTATUS))")
    @Mapping(target = "language", expression = "java(getValue(serviceDefaults, CommonConstants.LANGUAGE))")
    @Mapping(target = "custDomestic", expression = "java(mapCustDomestic(profile, fcProfile, mapEmployment(customerUserInputs), mapFatca(customerUserInputs)))")
    @Mapping(target = "pptNo", expression = "java(getFatcaField(fcProfile, FcIndiaProfile.CustomerFATCADetail::getIdDocNum))")
    @Mapping(target = "pptExpDt", expression = "java(parseLocalDateYYYYMMDD(getFatcaField(fcProfile, FcIndiaProfile.CustomerFATCADetail::getIdDocExpDat)))")
    @Mapping(target = "custProf", expression = "java(mapCustProf(fcProfile, mapEmployment(customerUserInputs),createFccMasterMapper))")
    FccCustomerRequest.CustPersonal mapCustPersonal(FcIndiaProfile.Profile fcProfile, @Context JourneyData journeyData, Profile profile, Map<String, Object> customerUserInputs, Map<String, String> serviceDefaults, CreateFccMasterMapper createFccMasterMapper);


    @BeanMapping(ignoreByDefault = true)
    @Mapping(target = "educationStatus", source = "employment.qualification", qualifiedByName = "mapQualification")
    @Mapping(target = "accomodate", source = "fatca.residenceType", qualifiedByName = "mapResidenceType")
    @Mapping(target = "maritalStatus", source = "fatca.maritalStatus", qualifiedByName = "mapMaritalStatus")
    @Mapping(target = "spouseName", source = "fatca.spouseName")
    FccCustomerRequest.CustDomestic mapCustDomestic(Profile profile, FcIndiaProfile.Profile fcProfile, CustomerDetails.EmploymentFinancial employment, CustomerDetails.FatcaDetails fatca);


    @BeanMapping(ignoreByDefault = true)
    @Mapping(target = "textDesc", expression = "java(getTdesc(employment))")
    FccCustomerRequest.CustText mapCustText(CustomerDetails.EmploymentFinancial employment);


    @BeanMapping(ignoreByDefault = true)
    @Mapping(target = "purposeOfAccount", source = "purposeOfAccount")
    FccCustomerRequest.CustAml mapCustAml(CustomerDetails.EmploymentFinancial employment);


    @Mapping(target = "currentDesig", expression = "java(getCurrentDesignation(employment))")
    @Mapping(target = "empTenure", source = "employment.workExperience")
    @Mapping(target = "add1", source = "employment.employerAddress1")
    @Mapping(target = "add2", source = "employment.employerAddress2")
    @Mapping(target = "add3", source = "employment.employerAddress3")
    @Mapping(target = "address4", source = "employment.employerAddress4")
    @Mapping(target = "pinCode", source = "employment.employerPinCode")
    FccCustomerRequest.CustProf mapCustProf(FcIndiaProfile.Profile fcProfile, CustomerDetails.EmploymentFinancial employment, CreateFccMasterMapper createFccMasterMapper);


    default FccCustomerRequest.Individual mapIndividual(
            CustomerDetails.EmploymentFinancial employment,
            CreateFccMasterMapper createFccMasterMapper) {
        if (employment == null) {
            return null;
        }

        return FccCustomerRequest.Individual.builder()
                .occupationNew(createFccMasterMapper.resolveOccupationNew(employment.getOccupation(), employment.getDesignation()))
                .occupation(createFccMasterMapper.resolveOccupation(employment.getOccupation())).build();
    }


    @Named("mapUdf")
    default List<FccCustomerRequest.UdfDetails> mapUdf(FcIndiaProfile.Profile fcProfile, Map<String, Object> customerUserInputs, Map<String, String> serviceDefaults, RiskAssessmentPageData riskAssessmentPageData, JourneyData journeyData) {

        CustomerDetails.EmploymentFinancial employment = mapEmployment(customerUserInputs);
        return List.of(
                udf(
                        CommonConstants.CC_IND_CNTR_TX_RS1,
                        serviceDefaults.getOrDefault("location", "IN")
                ),
                udf(
                        CommonConstants.CC_IND_CNTR_TX_RS2,
                        getFatcaField(fcProfile, FcIndiaProfile.CustomerFATCADetail::getCodTaxCntry1)
                ),
                udf(
                        CommonConstants.CC_IND_CNTR_TX_RS3,
                        getFatcaField(fcProfile, FcIndiaProfile.CustomerFATCADetail::getCodTaxCntry2)
                ),
                udf(

                        CommonConstants.IND_TIN_ISSUED_BY_CNTR_1,
                        serviceDefaults.getOrDefault("location", "IN")
                ),
                udf(
                        CommonConstants.IND_TIN_ISSUED_BY_CNTR_2,
                        getFatcaField(fcProfile, FcIndiaProfile.CustomerFATCADetail::getCodTaxCntry1)
                ),
                udf(
                        CommonConstants.IND_TIN_ISSUED_BY_CNTR_3,
                        getFatcaField(fcProfile, FcIndiaProfile.CustomerFATCADetail::getCodTaxCntry2)
                ),
                udf(
                        CommonConstants.CC_TRADE_TRANSACTION_CUSTOMER,
                        tradeTransactionCustomerValue(serviceDefaults)
                ),
                udf(
                        CommonConstants.CC_RISK_CATEGORY,
                        riskAssessmentPageData != null && riskAssessmentPageData.getCddLevel() != null
                                ? riskAssessmentPageData.getCddLevel().substring(0, 1).toUpperCase()
                                + riskAssessmentPageData.getCddLevel().substring(1).toLowerCase()
                                : null
                ),
                udf(
                        CommonConstants.CC_LAST_REKYC_DATE,
                        LocalDate.now().toString()
                ),
                udf(
                        CommonConstants.CC_PEP_NONPEP,
                        pepClassification(employment)
                ),
                udf(
                        CommonConstants.CC_ANNUAL_INCOME,
                        employment != null ? employment.getAnnualIncome() : null
                ),
                udf(
                        CommonConstants.NETWORTH_ON_RECORD_USD,
                        CustomerUtil.getValueByPath(journeyData, CUSTOMER_DETAILS, EMPLOYMENT_NET_WORTH_PATH)
                ),
                udf(
                        CommonConstants.IND_TIN_1,
                        fcProfile.getPanNumber()
                ),
                udf(
                        CommonConstants.IND_TIN_2,
                        getFatcaField(fcProfile, FcIndiaProfile.CustomerFATCADetail::getTinNo1)
                ),
                udf(
                        CommonConstants.IND_TIN_3,
                        getFatcaField(fcProfile, FcIndiaProfile.CustomerFATCADetail::getTinNo2)
                ),
                udf(
                        CommonConstants.CUST_RELATION_CUSTOMER_AUS,
                        getValue(serviceDefaults, CommonConstants.CUST_RELATION_CUSTOMER_AUS)
                ),
                udf(
                        CommonConstants.ACCEPTED_MAXIMUM_TRANSACTIONS,
                        employment != null ? employment.getMonthlyTransactions() : null
                ),
                udf(
                        CommonConstants.ANTICIPATED_MNTLY_TXN_AMT_USD,
                        employment != null ? employment.getMonthlyAmount() : null
                ),
                udf(
                        CommonConstants.FTF_OR_NFTF,
                        fcProfile.getKycType()
                ),
                udf(

                        CommonConstants.CUST_ID,
                        fcProfile.getCustomerId()
                ),
                udf(
                        CommonConstants.AC_OPENING_CASE_NO,
                        journeyData.getReferenceNo()
                )
        );
    }

    private String tradeTransactionCustomerValue(Map<String, String> serviceDefaults) {
        if ("Y".equalsIgnoreCase(getValue(serviceDefaults, CommonConstants.TRADE_TRANSACTION_CUSTOMER))) {
            return YES;
        }
        if ("N".equalsIgnoreCase(getValue(serviceDefaults, CommonConstants.TRADE_TRANSACTION_CUSTOMER))) {
            return NO;
        }
        return getValue(serviceDefaults, CommonConstants.TRADE_TRANSACTION_CUSTOMER);
    }

    private String pepClassification(CustomerDetails.EmploymentFinancial employment) {
        if (employment == null) {
            return null;
        }
        return "Yes".equalsIgnoreCase(employment.getPep()) ? CC_PEP : CC_NON_PEP;
    }

    default String joinAddress(String... parts) {
        String address = Stream.of(parts)
                .filter(StringUtils::isNotBlank)
                .collect(Collectors.joining(", "));

        return StringUtils.isNotBlank(address) ? address : null;
    }

    default FccCustomerRequest.CustMis buildCustMis(Map<String, String> defaults) {

        return FccCustomerRequest.CustMis.builder().branchCode((getValue(defaults, CommonConstants.CC_BRANCH))).build();
    }

    default FccCustomerRequest.RmLinkage buildRmLinkage(JourneyData journeyData, Map<String, String> defaults) {
        Map<String, Object> customerUserInputs =
                JourneyService.getDomainPageUserInputs(journeyData, REVIEW_DETAILS);

        if (customerUserInputs == null || customerUserInputs.isEmpty()) {
            return null;
        }

        String lgCode = Optional.ofNullable(customerUserInputs.get(LG_CODE_PATH))
                .map(Object::toString)
                .filter(s -> !s.isBlank())
                .orElse(getValue(defaults, CommonConstants.DEFAULT_LGCODE));

        return FccCustomerRequest.RmLinkage.builder()
                .rmlg(lgCode)
                .rmlc(lgCode)
                .build();
    }

    default FccCustomerRequest.CompositeMis buildCompositeMis(Map<String, String> defaults) {

        return FccCustomerRequest.CompositeMis.builder().misCls((getValue(defaults, CommonConstants.MISCLS)))
                .misCd((getValue(defaults, CommonConstants.MISCD))).build();
    }

    default FccCustomerRequest.UdfDetails udf(String fieldName, Object fieldValue) {

        String value = null;

        if (fieldValue != null) {
            if (fieldValue instanceof Boolean) {
                value = (Boolean) fieldValue ? YES : NO;
            } else {
                value = String.valueOf(fieldValue);
            }
        }

        return FccCustomerRequest.UdfDetails.builder().fieldName(fieldName).fieldValue(value).build();
    }

    default String getValue(Map<String, String> defaults, String key) {

        return Optional.ofNullable(defaults).map(m -> m.get(key)).orElse(null);
    }

    default <T> T getFatcaField(FcIndiaProfile.Profile profile, Function<FcIndiaProfile.CustomerFATCADetail, T> mapper) {

        if (profile == null || profile.getCustomerFATCADetails() == null || profile.getCustomerFATCADetails().isEmpty()) {
            return null;
        }

        return mapper.apply(profile.getCustomerFATCADetails().get(0));
    }

    default LocalDate parseLocalDate(String date) {

        if (date == null || date.isBlank()) {
            return null;
        }

        return LocalDate.parse(date);
    }

    default LocalDate parseLocalDateYYYYMMDD(String date) {

        if (date == null || date.isBlank()) {
            return null;
        }

        return LocalDate.parse(date, YYYYMMDD_FORMATTER);
    }


    default CustomerDetails.EmploymentFinancial mapEmployment(Map<String, Object> userInputs) {

        if (userInputs == null || userInputs.isEmpty()) {
            return null;
        }

        return CustomerUtil.convert(userInputs.get(EMPLOYMENT), CustomerDetails.EmploymentFinancial.class);
    }

    default String getTdesc(CustomerDetails.EmploymentFinancial employment) {

        StringBuilder sb = new StringBuilder("SOURCESOFWEALTHORINCOME-");
        sb.append(employment.getSourceOfIncome()).append(" PURPOSEOFACCOUNT - ").append(employment.getPurposeOfAccount());
        return sb.toString();
    }


    default CustomerDetails.FatcaDetails mapFatca(Map<String, Object> userInputs) {

        if (userInputs == null || userInputs.isEmpty()) {
            return null;
        }

        return CustomerUtil.convert(userInputs.get(FATCA), CustomerDetails.FatcaDetails.class);
    }

    @Named("mapQualification")
    default String mapQualification(CustomerDetails.Qualification value) {
        if (value == null) {
            return null;
        }
        return value.getKey();
    }

    @Named("mapResidenceType")
    default String mapResidenceType(CustomerDetails.ResidentialType value) {
        if (value == null) {
            return null;
        }
        return value.getKey();
    }

    @Named("mapMaritalStatus")
    default String mapMaritalStatus(CustomerDetails.MaritalStatus value) {
        if (value == null) {
            return null;
        }

        return value.getKey();
    }

    default String getIfSalariedEmployedWith(
            CustomerDetails.EmploymentFinancial employment) {

        return null;
    }

    default String getSelfEmployedProfession(CustomerDetails.EmploymentFinancial employment) {
        if (SELF_EMPLOYED.equalsIgnoreCase(employment.getOccupation())) {
            return employment.getSpecialisation();
        }
        return null;
    }

    default String mapEmployerBusinessIndustry(
            CustomerDetails.EmploymentFinancial employment,
            CreateFccMasterMapper createFccMasterMapper) {

        if (employment == null) {
            return null;
        }

        return createFccMasterMapper.resolveIndustry(employment.getIndustry());
    }

    default String getCkycNo(JourneyData journeyData) {
        return CustomerUtil.getCkycDetails(journeyData)
                .map(FetchKycResponse.FetchCBRCodesDetails::getCkycId)
                .orElse(null);
    }

    default String getTypeOfDis(JourneyData journeyData) {
        return CustomerUtil.getCkycDetails(journeyData)
                .map(FetchKycResponse.FetchCBRCodesDetails::getUniqueDisabilityIdNo)
                .orElse(null);
    }

    // Accept yyyy-MM-dd HH:mm:ss; absent, blank or unparseable values remain unmapped.
    default LocalDate getdateOfKycUpdate(JourneyData journeyData) {
        return CustomerUtil.getCkycDetails(journeyData)
                .map(FetchKycResponse.FetchCBRCodesDetails::getDateOfKycUpdate)
                .filter(date -> date != null && !date.isBlank())
                .map(date -> {
                    try {
                        return LocalDateTime.parse(date, DATE_TIME_FORMATTER_KYC).toLocalDate();
                    } catch (DateTimeParseException ex) {
                        log.error("Unexpected dateOfKycUpdate format received: '{}'. Expected format: yyyy-MM-dd HH:mm:ss", date, ex);
                        return null;
                    }
                })
                .orElse(null);
    }


    default String getCurrentDesignation(CustomerDetails.EmploymentFinancial employment) {
        if (employment == null || employment.getOccupation() == null) {
            return null;
        }

        if (SALARIED.equalsIgnoreCase(employment.getOccupation())) {
            return employment.getDesignation();
        }

        return employment.getSpecialisation();
    }

}
