package com.hdfcbank.giftcity.bff.application.handlers.background;

import com.hdfcbank.adapters.clients.feign.document.DocumentFeignClient;
import com.hdfcbank.adapters.vo.DocumentUploadedResponse;
import com.hdfcbank.adapters.vo.GenerateDocumentRequest;
import com.hdfcbank.common.models.vo.core.ApiResponse;
import com.hdfcbank.common.models.vo.journey.JourneyData;
import com.hdfcbank.giftcity.bff.commons.constant.CommonConstants;
import com.hdfcbank.giftcity.bff.commons.enums.CommonJourneyStates;
import com.hdfcbank.giftcity.bff.commons.exception.handler.DownstreamResponseHandler;
import com.hdfcbank.giftcity.bff.commons.handler.Handler;
import com.hdfcbank.giftcity.bff.commons.handler.HandlerContext;
import com.hdfcbank.giftcity.bff.commons.handler.HandlerResult;
import com.hdfcbank.giftcity.bff.commons.model.FcIndiaProfile;
import com.hdfcbank.giftcity.bff.commons.model.FtsDetails;
import com.hdfcbank.giftcity.bff.commons.properties.CustomValidationProperties;
import com.hdfcbank.giftcity.bff.commons.utility.ValidationHelper;
import com.hdfcbank.giftcity.bff.commons.validation.ValidationResult;
import com.hdfcbank.giftcity.bff.customer.config.CustomerApiProperties;
import com.hdfcbank.giftcity.bff.customer.mapper.AccountStatementDocumentMapper;
import com.hdfcbank.giftcity.bff.customer.model.AccountStatementDocData;
import com.hdfcbank.giftcity.bff.customer.utility.CustomerUtil;
import com.hdfcbank.giftcity.bff.infrastructure.service.JourneyService;
import com.hdfcbank.service.adapters.clients.feign.account.AccountServiceFeignClient;
import com.hdfcbank.service.adapters.vo.account.ViewAccountStatementRequest;
import com.hdfcbank.service.adapters.vo.account.ViewAccountStatementResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import static com.hdfcbank.giftcity.bff.commons.enums.CommonJourneyStates.*;
import static com.hdfcbank.giftcity.bff.commons.enums.JourneyPageName.FTS_DETAILS;

//commented below annotations to mark this handler disable. currently not using it.
@Slf4j
//@Service
@RequiredArgsConstructor
//@Order(4)
public class AccountStatementsFetchHandler implements Handler<DocumentUploadedResponse> {

    private final AccountServiceFeignClient accountServiceFeignClient;
    private final DocumentFeignClient documentFeignClient;
    private final AccountStatementDocumentMapper mapper;
    private final JourneyService journeyService;
    private final CustomerApiProperties customerApiProperties;
    private final CustomValidationProperties customValidationProperties;
    private final ValidationHelper validationHelper;

    private static final String SUCCESS = "0000";

    @Override
    public boolean preConditions(HandlerContext handlerContext) {
        return hasJourneyState(handlerContext, CommonJourneyStates.CREATE_FCC_CUSTOMER_SIGNATURE_SUCCESS.name())
                && !hasJourneyState(handlerContext, CUSTOMER_ACCOUNT_STATEMENTS_FETCH_SUCCESS.name());
    }

    @Override
    public HandlerResult<DocumentUploadedResponse> handle(HandlerContext handlerContext) {

        JourneyData journeyData = handlerContext.getJourneyData();

        try {

            log.info("Background handler triggered {}, for journeyId={}", getName(), journeyData.getJourneyId());

            List<FcIndiaProfile.CustomerAccountDetail> accountDetails =
                    CustomerUtil.getPrimaryProfile(journeyData)
                            .map(FcIndiaProfile.Profile::getCustomerAccountDetails)
                            .orElse(Collections.emptyList());

            String txtType = customerApiProperties.getAccountStatementConfig().getTxnType();
            Integer statementDays = customerApiProperties.getAccountStatementConfig().getStatementDays();
            Map<String, String> nominationMappings = customerApiProperties.getAccountStatementConfig().getNominationMappings();

            ValidationResult validationResult = validateAccountDetails(journeyData, accountDetails);

            if (!validationResult.isSuccess()) {
                return HandlerResult.of(
                        validationResult.getApiResponseStatus(),
                        null,
                        false
                );
            }

            // Sonar-compliant fix — static method reference instead of lambda
            FtsDetails ftsDetails = JourneyService.extractFromJourney(
                    journeyData,
                    FTS_DETAILS.getPageName(),
                    FTS_DETAILS.getPageClassName(),
                    AccountStatementsFetchHandler::castToFtsDetails   // STATIC reference
            ).orElse(new FtsDetails());

            DocumentUploadedResponse lastUploadedResponse = null;
            ftsDetails.setAccountStatement1DocRef(new ArrayList<>());
            ftsDetails.setAccountStatement2DocRef(new ArrayList<>());

            for (int accountIndex = 0; accountIndex < accountDetails.size(); accountIndex++) {

                FcIndiaProfile.CustomerAccountDetail accountDetail = accountDetails.get(accountIndex);

                ViewAccountStatementRequest accountStatementRequest =
                        mapper.toViewAccountStatementRequest(journeyData, accountDetail, txtType, statementDays);

                ViewAccountStatementResponse accountStatementResponse =
                        accountServiceFeignClient.getAccountStatement(accountStatementRequest, journeyData.getJourneyId());

                boolean accountStatementSuccess =
                        accountStatementResponse.getStatus() != null
                                && SUCCESS.equals(accountStatementResponse.getStatus().getCode());

                if (!accountStatementSuccess) {

                    return HandlerResult.of(
                            DownstreamResponseHandler.handleResponse(
                                    accountStatementResponse,
                                    HandlerName.ACCOUNT_STATEMENTS_FETCH.name(),
                                    false,
                                    journeyData.getJourneyName()
                            ),
                            null,
                            false
                    );
                }

                List<GenerateDocumentRequest<AccountStatementDocData>> documentRequests =
                        getDocumentRequests(
                                journeyData,
                                accountDetail,
                                accountStatementResponse.getData(),
                                accountIndex + 1,
                                statementDays,
                                nominationMappings
                        );

                for (GenerateDocumentRequest<AccountStatementDocData> documentRequest : documentRequests) {
                    HandlerResult<DocumentUploadedResponse> result =
                            uploadDocumentAndUpdateFTSDetails(
                                    documentRequest,
                                    journeyData,
                                    ftsDetails,
                                    accountIndex
                            );

                    lastUploadedResponse = result.getResult();

                    if (!result.isSuccess()) {
                        return result;
                    }
                }
            }

            journeyService.updateJourney(
                    journeyData.getJourneyId(),
                    FTS_DETAILS.getPageName(),
                    ftsDetails,
                    CommonJourneyStates.CUSTOMER_ACCOUNT_STATEMENTS_FETCH_SUCCESS
            );

            return HandlerResult.of(null, lastUploadedResponse, true);

        } catch (Throwable e) {

            log.error("Exception while calling AccountStatementsFetchHandler", e);

            return HandlerResult.of(
                    DownstreamResponseHandler.handleResponse(
                            null,
                            HandlerName.ACCOUNT_STATEMENTS_FETCH.name(),
                            false,
                            journeyData.getJourneyName()
                    ),
                    null,
                    false
            );
        }
    }

    // Static helper method used for Sonar-compliant Function reference
    private static FtsDetails castToFtsDetails(Object value) {
        return (FtsDetails) value;
    }

    private HandlerResult<DocumentUploadedResponse> uploadDocumentAndUpdateFTSDetails(
            GenerateDocumentRequest<AccountStatementDocData> documentRequest,
            JourneyData journeyData,
            FtsDetails ftsDetails,
            int accountIndex) {

        ApiResponse<DocumentUploadedResponse> documentResponse =
                documentFeignClient.fetchGenerateAndUploadResponse(
                        journeyData.getJourneyId(),
                        journeyData.getJourneyName(),
                        documentRequest
                );

        boolean documentSuccess = documentResponse.getStatus() != null
                && SUCCESS.equals(documentResponse.getStatus().getCode());

        if (!documentSuccess) {

            return HandlerResult.of(
                    DownstreamResponseHandler.handleResponse(
                            documentResponse,
                            HandlerName.ACCOUNT_STATEMENTS_FETCH.name(),
                            false,
                            journeyData.getJourneyName()
                    ),
                    documentResponse.getData(),
                    false
            );
        }

        String docRef = documentResponse.getData().getDocRef();

        if (accountIndex == 0) {
            ftsDetails.getAccountStatement1DocRef().add(docRef);
        } else {
            ftsDetails.getAccountStatement2DocRef().add(docRef);
        }

        return HandlerResult.of(null, documentResponse.getData(), true);
    }

    private List<GenerateDocumentRequest<AccountStatementDocData>> getDocumentRequests(
            JourneyData journeyData,
            FcIndiaProfile.CustomerAccountDetail accountDetail,
            ViewAccountStatementResponse.ViewAccountStatementData data,
            int accountIndex,
            Integer statementDays,
            Map<String, String> nominationMappings) {

        List<GenerateDocumentRequest<AccountStatementDocData>> results = new ArrayList<>();

        int statementsLimitCount = customerApiProperties.getAccountStatementConfig().getStatementsDocumentSplitCount();
        List<ViewAccountStatementResponse.Transaction> txList = data.getTransactions();

        if (CollectionUtils.isEmpty(txList)) {
            results.add(
                    mapper.toAccountStatementDocumentRequest(
                            journeyData,
                            accountDetail,
                            data,
                            accountIndex,
                            0,
                            statementDays,
                            nominationMappings
                    )
            );
            return results;
        }

        int totalChunks = (int) Math.ceil(txList.size() / (double) statementsLimitCount);

        List<ViewAccountStatementResponse.ViewAccountStatementData> statements =
                IntStream.range(0, totalChunks)
                        .mapToObj(i -> {

                            int start = i * statementsLimitCount;
                            int end = Math.min(start + statementsLimitCount, txList.size());
                            List<ViewAccountStatementResponse.Transaction> chunk = txList.subList(start, end);

                            return new ViewAccountStatementResponse.ViewAccountStatementData(
                                    data.getCurrency(),
                                    data.getClosingBal(),
                                    new ArrayList<>(chunk)
                            );
                        })
                        .collect(Collectors.toList());

        for (int fileIndex = 0; fileIndex < statements.size(); fileIndex++) {
            results.add(
                    mapper.toAccountStatementDocumentRequest(
                            journeyData,
                            accountDetail,
                            statements.get(fileIndex),
                            accountIndex,
                            fileIndex,
                            statementDays,
                            nominationMappings
                    )
            );
        }

        return results;
    }

    private ValidationResult validateAccountDetails(
            JourneyData journeyData,
            List<FcIndiaProfile.CustomerAccountDetail> accountDetails) {

        List<CustomValidationProperties.FieldDetail> fieldDetails = new ArrayList<>();

        if (CollectionUtils.isEmpty(accountDetails)) {
            fieldDetails.add(
                    validationHelper.validateData(
                            CommonConstants.ACCOUNT_STATEMENT_NO_ACCOUNT,
                            null,
                            customValidationProperties,
                            journeyData.getJourneyName()
                    )
            );
        } else if (accountDetails.size() > CommonConstants.ACCOUNT_STATEMENT_MAX_ACCOUNT_COUNT) {
            fieldDetails.add(
                    validationHelper.validateData(
                            CommonConstants.ACCOUNT_STATEMENT_MAX_ACCOUNT_EXCEEDED,
                            null,
                            customValidationProperties,
                            journeyData.getJourneyName()
                    )
            );
        }

        fieldDetails.removeIf(Objects::isNull);

        if (fieldDetails.isEmpty()) {
            return ValidationResult.of(null, true);
        }

        return ValidationResult.of(
                validationHelper.getErrors(
                        journeyData.getJourneyName(),
                        fieldDetails,
                        customValidationProperties
                ),
                false
        );
    }

    @Override
    public HandlerType getType() {
        return HandlerType.BACKGROUND_TASKS_POST_SUBMIT_SUCCESS;
    }

    @Override
    public HandlerName getName() {
        return HandlerName.ACCOUNT_STATEMENTS_FETCH;
    }

    @Override
    public CommonJourneyStates successState() {
        return CUSTOMER_ACCOUNT_STATEMENTS_FETCH_SUCCESS;
    }

    @Override
    public CommonJourneyStates failureState() {
        return CUSTOMER_ACCOUNT_STATEMENTS_FETCH_FAILURE;
    }
}