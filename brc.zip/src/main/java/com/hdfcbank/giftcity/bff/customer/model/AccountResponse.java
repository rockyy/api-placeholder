package com.hdfcbank.giftcity.bff.customer.model;


import lombok.*;

import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AccountResponse {

    private String accountId;
    private String accountNumber;
    private String productName;
    private String datAcctOpen;
    private Branch branch;
    private List<NomineeDetail> nomineeDetails;



    @Getter
    @Setter
    @Builder
    public static class Branch {
        private String addressLine1;
        private String addressLine2;
        private String addressLine3;
        private String branchCode;
        private String branchName;
        private String branchCity;
        private String branchCountry;
        private String branchTelNo;
    }

    @Getter
    @Setter
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class NomineeDetail {
        private String name;
        private String dob;
    }


}
