package com.hdfcbank.giftcity.bff.commons.aspect;

import com.hdfcbank.giftcity.bff.commons.config.JourneyConfigProperties;
import com.hdfcbank.giftcity.bff.commons.utility.OneDeviceCacheUtility;
import com.hdfcbank.giftcity.bff.commons.utility.TextSanityUtil;
import com.hdfcbank.giftcity.bff.customer.model.IdentifyCustomerRequest;
import com.hdfcbank.giftcity.bff.infrastructure.service.JourneyService;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.time.ZonedDateTime;
import java.util.Arrays;

@Aspect
@Component
@Slf4j
public class OneDeviceOneLoginAspect {
    @Autowired
    OneDeviceCacheUtility oneDeviceCacheUtility;
    @Autowired
    JourneyConfigProperties journeysDetail;

    @Autowired
    JourneyService journeyService;

    @Around("@annotation(com.hdfcbank.giftcity.bff.commons.annotation.OneDeviceOneLogin)")
    @Order(1)
    @SneakyThrows
    public Object oneDeviceOneLogin(ProceedingJoinPoint joinPoint) {
        log.info("Here in one device");
        Object[] args = joinPoint.getArgs();

        IdentifyCustomerRequest request = Arrays.stream(args)
                .filter(IdentifyCustomerRequest.class::isInstance)
                .map(IdentifyCustomerRequest.class::cast)
                .findFirst()
                .orElseThrow(() -> new IllegalArgumentException("IdentifyCustomerRequest is required"));

        log.info("request {}", TextSanityUtil.sanitize(request.toString()));

        String authorization = (String) Arrays.stream(args)
                .filter(String.class::isInstance)
                .findFirst()
                .orElse(null);
        log.info("Token {}", TextSanityUtil.sanitize(authorization));

        String journeyName = (String) Arrays.stream(args)
                .filter(String.class::isInstance)
                .toList()
                .get(1);

        boolean sessionChanged = isSessionChanged(request.getMobileNo(), request.getIdentifierValue(), journeyName, authorization);

        if (!sessionChanged) {
            return joinPoint.proceed();

        }

        if (journeysDetail.getJourneys().get(journeyName).getOneDeviceOneLogin().isEnabled()) {
            ZonedDateTime currentTime = ZonedDateTime.now();
            oneDeviceCacheUtility.validateDevice(
                    oneDeviceCacheUtility.deviceLoggedIn(
                            request.getMobileNo(),
                            request.getIdentifierValue(),
                            journeyName,
                            authorization,
                            currentTime),
                    currentTime,
                    authorization
            );
        }

        return joinPoint.proceed();


    }


    private boolean isSessionChanged(String mobileNumber, String dob, String journeyName, String authorization) {
        OneDeviceCacheUtility.OneDeviceOneLoginDetail oneDeviceOneLoginDetail = oneDeviceCacheUtility.deviceLoggedIn(mobileNumber, dob, journeyName, authorization, ZonedDateTime.now());
        log.info("Access token in cache '{}' and access token in request '{}'", TextSanityUtil.sanitize(oneDeviceOneLoginDetail.getAccessToken()), TextSanityUtil.sanitize(authorization));
        return !oneDeviceOneLoginDetail.getAccessToken().equals(authorization);
    }
}
