package com.hdfcbank.giftcity.bff.customer.model;

import com.hdfcbank.common.models.validation.annotation.ValueOfEnum;
import jakarta.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter

public class FetchAccountRequest {

    @NotBlank
    @ValueOfEnum(AccountType.class)
    private String accountType;
}
