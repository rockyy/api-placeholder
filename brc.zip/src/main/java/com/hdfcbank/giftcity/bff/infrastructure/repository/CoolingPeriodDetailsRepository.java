package com.hdfcbank.giftcity.bff.infrastructure.repository;

import com.hdfcbank.giftcity.bff.infrastructure.entity.CoolingPeriodDetailsEntity;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.data.mongodb.repository.Update;
import org.springframework.data.repository.query.Param;

import java.util.Date;
import java.util.Map;


public interface CoolingPeriodDetailsRepository extends MongoRepository<CoolingPeriodDetailsEntity, Map<String, String>> {
    @Query("{'_id' : :#{#id}}")
    @Update("{'$set': {'modifiedDate': :#{#modifiedDate},'noOfAttempts': :#{#noOfAttempts}, 'expireAt': :#{#expireAt} }}")
    Long updateAttempts(@Param("id") Map<String, String> id, @Param("modifiedDate") Date modifiedDate, @Param("noOfAttempts") int noOfAttempts, @Param("expireAt") Date expireAt);

    @Query(value = "{ '_id.journeyName': ?#{#id['journeyName']}, " +
            "  '_id.coolingPeriodType': ?#{#id['coolingPeriodType']}, " +
            "  '_id.loanFileNumber': ?#{#id['loanFileNumber']} }", delete = true)
    void deleteByMapId(@Param("id") Map<String, String> id);
}