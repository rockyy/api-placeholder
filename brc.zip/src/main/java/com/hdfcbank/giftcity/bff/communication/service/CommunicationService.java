package com.hdfcbank.giftcity.bff.communication.service;

import com.hdfcbank.adapters.vo.GenerateOtpResponse;
import com.hdfcbank.adapters.vo.VerifyOtpResponse;
import com.hdfcbank.giftcity.bff.customer.model.ValidateCustomerRequest;

public interface CommunicationService {
    GenerateOtpResponse sendOtp(String mobile, String email, String journeyName, String journeyId);

    GenerateOtpResponse resendOtp(String mobile, String email, String journeyName, String journeyId);

    VerifyOtpResponse verifyOtp(ValidateCustomerRequest request, String journeyId);
}
