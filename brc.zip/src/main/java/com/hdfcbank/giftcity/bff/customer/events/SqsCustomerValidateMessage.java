package com.hdfcbank.giftcity.bff.customer.events;

import com.hdfcbank.giftcity.bff.commons.validation.ValidatorType;
import lombok.*;

@Getter
@Setter
@Builder
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class SqsCustomerValidateMessage {

    private ValidatorType type;
    private SqsCustomerValidatePayload payload;
}
