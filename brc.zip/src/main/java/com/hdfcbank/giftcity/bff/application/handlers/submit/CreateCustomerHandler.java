package com.hdfcbank.giftcity.bff.application.handlers.submit;

import com.hdfcbank.giftcity.bff.commons.model.FtsDetails;
import com.hdfcbank.giftcity.bff.customer.mapper.CreateFccMasterMapper;
import com.hdfcbank.giftcity.bff.customer.model.RiskAssessmentPageData;
import com.hdfcbank.giftcity.bff.customer.utility.CustomerUtil;
import com.hdfcbank.service.adapters.clients.feign.customer.CustomerServiceFeignClient;
import com.hdfcbank.service.adapters.vo.customer.FccCustomerRequest;
import com.hdfcbank.service.adapters.vo.customer.FccCustomerResponse;
import com.hdfcbank.common.models.vo.journey.JourneyData;
import com.hdfcbank.common.models.vo.journey.Profile;
import com.hdfcbank.giftcity.bff.commons.enums.CommonJourneyStates;
import com.hdfcbank.giftcity.bff.commons.enums.JourneyPageName;
import com.hdfcbank.giftcity.bff.commons.exception.handler.DownstreamResponseHandler;
import com.hdfcbank.giftcity.bff.commons.handler.Handler;
import com.hdfcbank.giftcity.bff.commons.handler.HandlerContext;
import com.hdfcbank.giftcity.bff.commons.handler.HandlerResult;
import com.hdfcbank.giftcity.bff.commons.model.FcGcProfile;
import com.hdfcbank.giftcity.bff.commons.model.FcIndiaProfile;
import com.hdfcbank.giftcity.bff.customer.config.CustomerApiProperties;
import com.hdfcbank.giftcity.bff.customer.mapper.CreateFCCCustomerMapper;
import com.hdfcbank.giftcity.bff.infrastructure.service.JourneyService;
import com.hdfcbank.service.adapters.vo.customer.UcicApiResponse;
import com.hdfcbank.service.adapters.vo.customer.UcicRequest;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Service;

import java.util.Map;
import java.util.Optional;
import java.util.function.Function;

import static com.hdfcbank.giftcity.bff.commons.enums.CommonJourneyStates.CREATE_FCC_CUSTOMER_FAILURE;
import static com.hdfcbank.giftcity.bff.commons.enums.CommonJourneyStates.CREATE_FCC_CUSTOMER_SUCCESS;
import static com.hdfcbank.giftcity.bff.customer.constants.CustomerConstants.CUSTOMER_DETAILS;

@Slf4j
@Service
@RequiredArgsConstructor
@Order(2)
public class CreateCustomerHandler implements Handler<FccCustomerResponse> {

    private final CustomerApiProperties customerApiProperties;
    private final CreateFCCCustomerMapper createFCCCustomerMapper;
    private final CustomerServiceFeignClient customerServiceFeignClient;
    private final JourneyService journeyService;
    private final CreateFccMasterMapper createFccMasterMapper;

    private static final String SUCCESS = "0000";

    @Override
    public boolean preConditions(HandlerContext handlerContext) {
        return isSuccess(handlerContext, HandlerName.RISK_ANALYSIS)
                && isSuccess(handlerContext, HandlerName.CREATE_REFERENCE_NUMBER);
    }

    @Override
    public HandlerResult<FccCustomerResponse> handle(HandlerContext handlerContext) {
        JourneyData journeyData = handlerContext.getJourneyData();
        try {
            Profile journeyDataProfile = journeyData.getProfile();
            FcIndiaProfile.Profile fcProfile = JourneyService.extractFromJourney(journeyData,
                            JourneyPageName.CUSTOMER_FC_INDIA_DETAIL.getPageName(),
                            FcIndiaProfile.class,
                            fcIndiaProfile -> Optional.ofNullable(fcIndiaProfile.getProfiles())
                                    .filter(list -> !list.isEmpty())
                                    .map(list -> list.get(0))
                                    .orElse(null))
                    .orElse(null);
            Map<String, String> serviceDefaults = customerApiProperties.getCreateFccCustomer().getServiceDefaults();
            Map<String, Object> customerUserInputs = JourneyService.getDomainPageUserInputs(journeyData, CUSTOMER_DETAILS);

            String ucicNo = CustomerUtil.getUcicDetails(journeyData)
                    .map(UcicApiResponse.UcicSummaryResponse::getUcic)
                    .orElse(null);

            RiskAssessmentPageData risk = CustomerUtil.getRiskAssessment(journeyData);

            FccCustomerRequest fccCustomerRequest = createFCCCustomerMapper.toRequest(journeyData, journeyDataProfile, fcProfile, serviceDefaults,customerUserInputs, createFccMasterMapper,risk,ucicNo);
            FccCustomerResponse response = customerServiceFeignClient.createFCCCustomer(fccCustomerRequest, journeyData.getJourneyId());

            if(response.getStatus().getCode().equals(SUCCESS)) {

                Optional<FcGcProfile> fcGcProfile = JourneyService.extractFromJourney(
                        journeyData,
                        JourneyPageName.CUSTOMER_FC_GIFT_CITY_DETAIL.getPageName(),
                        FcGcProfile.class,
                        Function.identity()
                );

                fcGcProfile.ifPresent(profile -> {
                    profile.setCustomerNumber(response.getData().getCustomerId());

                    journeyService.updateJourney(
                            journeyData.getJourneyId(),
                            JourneyPageName.CUSTOMER_FC_GIFT_CITY_DETAIL.getPageName(),
                            profile,
                            CommonJourneyStates.CUSTOMER_FC_GC_DETAIL_CAPTURED
                    );
                });

                return HandlerResult.of(null, response, true);
            }
            log.error("FCC Create Customer failed with code={} errors={}", response.getStatus().getCode(), response.getStatus().getErrors());
            return HandlerResult.of(DownstreamResponseHandler
                            .handleResponse(response, HandlerName.CREATE_CUSTOMER.name(),
                                    false, journeyData.getJourneyName()),
                    response, false);

        } catch (Throwable e) {
            log.error("Exception in create customer", e);
            return HandlerResult.<FccCustomerResponse>of(DownstreamResponseHandler
                    .handleResponse(null,
                            HandlerName.CREATE_CUSTOMER.name(),
                            false, journeyData.getJourneyName()), null, false);
        }
    }

    @Override
    public HandlerType getType() {
        return HandlerType.CUSTOMER_POST_SUBMIT;
    }

    @Override
    public HandlerName getName() {
        return HandlerName.CREATE_CUSTOMER;
    }

    @Override
    public CommonJourneyStates successState() {
        return CREATE_FCC_CUSTOMER_SUCCESS;
    }

    @Override
    public CommonJourneyStates failureState() {
        return CREATE_FCC_CUSTOMER_FAILURE;
    }
}
