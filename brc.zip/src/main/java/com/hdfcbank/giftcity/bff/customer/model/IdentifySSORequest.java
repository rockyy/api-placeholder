package com.hdfcbank.giftcity.bff.customer.model;

import jakarta.validation.constraints.NotEmpty;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class IdentifySSORequest {

    @NotEmpty
    private String token;
}
