package com.hdfcbank.giftcity.bff.customer.model;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class HandleGenerateOtpResponse {

    String mobileNumber;
    String dob;
    String journeyId;
    boolean isRetry;
    int eligibleAccounts;
}
