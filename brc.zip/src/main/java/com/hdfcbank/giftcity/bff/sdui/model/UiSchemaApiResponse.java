package com.hdfcbank.giftcity.bff.sdui.model;


import com.hdfcbank.common.models.vo.core.ApiResponse;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import lombok.experimental.SuperBuilder;
import tools.jackson.databind.JsonNode;

@Getter
@Setter
@ToString
@SuperBuilder
public class UiSchemaApiResponse extends ApiResponse<JsonNode> {

    private JsonNode layout;
}
