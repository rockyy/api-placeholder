package com.hdfcbank.giftcity.bff.application.handlers.submit;

import com.hdfcbank.common.models.vo.journey.JourneyData;
import com.hdfcbank.giftcity.bff.commons.enums.CommonJourneyStates;
import com.hdfcbank.giftcity.bff.commons.enums.JourneyPageName;
import com.hdfcbank.giftcity.bff.commons.exception.handler.DownstreamResponseHandler;
import com.hdfcbank.giftcity.bff.commons.handler.Handler;
import com.hdfcbank.giftcity.bff.commons.handler.HandlerContext;
import com.hdfcbank.giftcity.bff.commons.handler.HandlerResult;
import com.hdfcbank.giftcity.bff.commons.utility.TextSanityUtil;
import com.hdfcbank.giftcity.bff.customer.mapper.CustomerRiskAnalysisMapper;
import com.hdfcbank.giftcity.bff.infrastructure.service.JourneyService;
import com.hdfcbank.service.adapters.clients.feign.customer.CustomerServiceFeignClient;
import com.hdfcbank.service.adapters.vo.customer.CustomerRiskAnalysisRequest;
import com.hdfcbank.service.adapters.vo.customer.CustomerRiskAnalysisResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Service;

import static com.hdfcbank.giftcity.bff.commons.enums.CommonJourneyStates.CUSTOMER_RISK_ASSESSMENT_FAILURE;
import static com.hdfcbank.giftcity.bff.commons.enums.CommonJourneyStates.CUSTOMER_RISK_ASSESSMENT_SUCCESS;


@Slf4j
@Service
@RequiredArgsConstructor
@Order(0)
public class RiskAssessmentHandler implements Handler<CustomerRiskAnalysisResponse> {

    private final CustomerServiceFeignClient customerServiceFeignClient;
    private final CustomerRiskAnalysisMapper customerRiskAnalysisMapper;
    private final JourneyService journeyService;
    private static final String SUCCESS = "0000";

    @Override
    public boolean preConditions(HandlerContext handlerContext) {
        return true;
    }

    @Override
    public HandlerResult<CustomerRiskAnalysisResponse> handle(HandlerContext handlerContext) {

        JourneyData journeyData = handlerContext.getJourneyData();
        try {

            log.info("Background handler triggered {}, for journeyId={}", getName(), journeyData.getJourneyId());

            CustomerRiskAnalysisRequest request = customerRiskAnalysisMapper.toRequest(journeyData);

            log.info("Final RiskAssessment request from BFF={}", request);

            CustomerRiskAnalysisResponse response = customerServiceFeignClient.getCustomerRiskAnalysis(request, journeyData.getJourneyId());

            log.info("Risk Response received for journeyId={}, response={}", journeyData.getJourneyId(), TextSanityUtil.sanitize(response.toString()));

            boolean success = response.getStatus() != null && SUCCESS.equals(response.getStatus().getCode());

            if (success) {
                journeyService.updateJourney(
                        journeyData.getJourneyId(),
                        JourneyPageName.RISK_ASSESSMENT.getPageName(),
                        response.getData(),
                        CUSTOMER_RISK_ASSESSMENT_SUCCESS);

                return HandlerResult.of(null, response, true);
            }

            log.error("CustomerRiskAnalysis failed with code={} errors={}", response.getStatus().getCode(), response.getStatus().getErrors());
            return HandlerResult.of(DownstreamResponseHandler.handleResponse(response, HandlerName.RISK_ANALYSIS.name(), false,
                    journeyData.getJourneyName()), response, false);


        } catch (Throwable e) {
            log.error("Exception while calling CustomerRiskAnalysis service", e);
            return HandlerResult.<CustomerRiskAnalysisResponse>of(DownstreamResponseHandler.handleResponse(null, HandlerName.RISK_ANALYSIS.name(), false,
                    journeyData.getJourneyName()), null, false);
        }

    }

    @Override
    public HandlerType getType() {
        return HandlerType.CUSTOMER_POST_SUBMIT;
    }

    @Override
    public HandlerName getName() {
        return HandlerName.RISK_ANALYSIS;
    }

    @Override
    public CommonJourneyStates successState() {
        return CUSTOMER_RISK_ASSESSMENT_SUCCESS;
    }

    @Override
    public CommonJourneyStates failureState() {
        return CUSTOMER_RISK_ASSESSMENT_FAILURE;
    }
}
