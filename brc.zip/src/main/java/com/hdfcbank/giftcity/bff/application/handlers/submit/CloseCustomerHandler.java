package com.hdfcbank.giftcity.bff.application.handlers.submit;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hdfcbank.service.adapters.clients.feign.customer.CustomerServiceFeignClient;
import com.hdfcbank.service.adapters.vo.customer.CloseCustomerRequest;
import com.hdfcbank.service.adapters.vo.customer.CloseCustomerResponse;
import com.hdfcbank.service.adapters.vo.customer.FccCustomerResponse;
import com.hdfcbank.common.models.vo.journey.JourneyData;
import com.hdfcbank.giftcity.bff.commons.enums.CommonJourneyStates;
import com.hdfcbank.giftcity.bff.commons.exception.handler.DownstreamResponseHandler;
import com.hdfcbank.giftcity.bff.commons.handler.Handler;
import com.hdfcbank.giftcity.bff.commons.handler.HandlerContext;
import com.hdfcbank.giftcity.bff.commons.handler.HandlerResult;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Service;

import static com.hdfcbank.giftcity.bff.commons.enums.CommonJourneyStates.CLOSE_FCC_CUSTOMER_FAILURE;
import static com.hdfcbank.giftcity.bff.commons.enums.CommonJourneyStates.CLOSE_FCC_CUSTOMER_SUCCESS;


@Slf4j
@Service
@RequiredArgsConstructor
@Order(5)
public class CloseCustomerHandler implements Handler<CloseCustomerResponse> {

    private final CustomerServiceFeignClient customerServiceFeignClient;
    private static final String SUCCESS = "0000";

    @Override
    public boolean preConditions(HandlerContext handlerContext) {
        return isSuccess(handlerContext, HandlerName.CREATE_CUSTOMER)
                && !isSuccess(handlerContext, HandlerName.CREATE_ACCOUNT);
    }

    @Override
    public HandlerResult<CloseCustomerResponse> handle(HandlerContext handlerContext) {

        JourneyData journeyData = handlerContext.getJourneyData();
        try {
            FccCustomerResponse customerResponse = getResult(handlerContext, HandlerName.CREATE_CUSTOMER, FccCustomerResponse.class);
            CloseCustomerResponse response = customerServiceFeignClient.closeFccCustomer(CloseCustomerRequest.builder()
                    .customerNumber(customerResponse.getData().getCustomerId())
                    .build(), journeyData.getJourneyId());

            if (response.getStatus().getCode().equals(SUCCESS)) {

                return HandlerResult.of(null, response, true);
            }

            return HandlerResult.of(DownstreamResponseHandler
                            .handleResponse(response, HandlerName.CLOSE_CUSTOMER.name(),
                                    false, journeyData.getJourneyName()),
                    response, false);

        } catch (Throwable e) {
            return HandlerResult.<CloseCustomerResponse>of(DownstreamResponseHandler
                            .handleResponse(null,
                                    HandlerName.CLOSE_CUSTOMER.name(),
                                    false, journeyData.getJourneyName()),
                    null,
                     false);
        }
    }

    @Override
    public HandlerType getType() {
        return HandlerType.CUSTOMER_POST_SUBMIT;
    }

    @Override
    public HandlerName getName() {
        return HandlerName.CLOSE_CUSTOMER;
    }

    @Override
    public CommonJourneyStates successState() {
        return CLOSE_FCC_CUSTOMER_SUCCESS;
    }

    @Override
    public CommonJourneyStates failureState() {
        return CLOSE_FCC_CUSTOMER_FAILURE;
    }
}
