package com.hdfcbank.giftcity.bff.application.mapper;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hdfcbank.common.models.vo.journey.JourneyData;
import com.hdfcbank.common.models.vo.journey.Profile;
import com.hdfcbank.giftcity.bff.commons.model.FcGcProfile;
import com.hdfcbank.giftcity.bff.commons.model.FtsDetails;
import com.hdfcbank.giftcity.bff.customer.config.CustomerApiProperties;
import com.hdfcbank.giftcity.bff.customer.constants.CustomerConstants;
import com.hdfcbank.giftcity.bff.customer.utility.CustomerUtil;
import com.hdfcbank.service.adapters.vo.account.FTSAccountOpeningRequest;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;
import org.springframework.beans.factory.annotation.Autowired;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Locale;

@Mapper(
        componentModel = "spring",
        imports = {
                LocalDate.class,
                DateTimeFormatter.class,
                CustomerConstants.class
        })
public abstract class FTSAccountOpeningMapper {

    @Autowired
    protected ObjectMapper objectMapper;
    @Autowired
    protected CustomerApiProperties customerApiProperties;

    @Mapping(target = "barcode", source = "journeyData.referenceNo")
    @Mapping(
            target = "accountNumber",
            expression = "java(getAccountNumber(journeyData))"
    )
    @Mapping(target = "panNumber", source = "profile.panNumber")
    @Mapping(
            target = "accountOpenedDate",
            expression = "java(LocalDate.now().format(DateTimeFormatter.ofPattern(\"dd-MMM-yyyy\")))")
    @Mapping(
            target = "accountActivationDate",
            expression = "java(LocalDate.now().format(DateTimeFormatter.ofPattern(\"dd-MMM-yyyy\")))"
    )
    @Mapping(target = "accountNo1", constant = "")
    @Mapping(target = "accountNo2", constant = "")
    @Mapping(target = "accountNo3", constant = "")
    @Mapping(target = "accountNo4", constant = "")
    @Mapping(target = "zipFilePath", source = "ftsDetails.uploadedZipFileLocation")
    @Mapping(target = "holderInfo", source = "holderInfoList")
    @Mapping(target = "leadNumber", constant = "")
    @Mapping(target = "scanningLocation", constant = "")
    @Mapping(target = "cMatchedRemark", constant = "Authorised")
    @Mapping(target = "reimbursementAcno", constant = "")
    public abstract FTSAccountOpeningRequest toFTSAccountOpeningRequest(
            JourneyData journeyData,
            Profile profile,
            FtsDetails ftsDetails,
            List<FTSAccountOpeningRequest.HolderInfo> holderInfoList
    );

    @Mapping(
            target = "customerId",
            expression = "java(getCustomerId(journeyData))"
    )
    @Mapping(
            target = "customerDob",
            source = "profile.dob",
            qualifiedByName = "formatDob"
    )
    @Mapping(target = "imagePath", source = "imagePath")
    @Mapping(
            target = "docTypeId",
            source = "docTypeKey",
            qualifiedByName = "docTypeIdResolver")
    @Mapping(
            target = "fileName",
            source = "docTypeKey",
            qualifiedByName = "fileNameResolver")
    @Mapping(target = "customerName", source = "profile.fullName")
    @Mapping(
            target = "docValidation",
            expression = "java(getDocValidation())")
    @Mapping(
            target = "aofProofTagging",
            source = "docTypeKey",
            qualifiedByName = "aofProofTaggingResolver")
    public abstract FTSAccountOpeningRequest.HolderInfo toHolderInfo(
            JourneyData journeyData,
            Profile profile,
            String imagePath,
            String docTypeKey
    );

    @Named("aofProofTaggingResolver")
    protected String getAofProofTagging(String docTypeKey) {

        switch (docTypeKey) {
            case CustomerConstants.ACCOUNT_STATEMENT1_DOC_REF:
            case CustomerConstants.ACCOUNT_STATEMENT2_DOC_REF:
                return CustomerConstants.AOF_PROOF_TAGGING_POA;

            default:
                return CustomerConstants.AOF_PROOF_TAGGING_OTHER;
        }
    }

    @Named("docTypeIdResolver")
    protected String getDocTypeId(String docTypeKey) {

        CustomerApiProperties.AOFDetails aofDetails =
                customerApiProperties.getAofDetails();

        switch (docTypeKey) {
            case CustomerConstants.AOF_WITH_ANNEXTURE_DOC_REF:
                return aofDetails.getAofOpeningDocId();

            case CustomerConstants.ACCOUNT_STATEMENT1_DOC_REF:
            case CustomerConstants.ACCOUNT_STATEMENT2_DOC_REF:
                return aofDetails.getAccStatementDocId();

            case CustomerConstants.CUSTOMER_SIGNATURE_DOC_REF:
                return aofDetails.getClientSignatureDocId();

            default:
                return "";
        }
    }

    @Named("fileNameResolver")
    protected String getFileName(String docTypeKey) {

        CustomerApiProperties.AOFDetails aofDetails =
                customerApiProperties.getAofDetails();

        switch (docTypeKey) {
            case CustomerConstants.AOF_WITH_ANNEXTURE_DOC_REF:
                return aofDetails.getAofOpeningFileName();

            case CustomerConstants.ACCOUNT_STATEMENT1_DOC_REF:
            case CustomerConstants.ACCOUNT_STATEMENT2_DOC_REF:
                return aofDetails.getAccStatementFileName();

            case CustomerConstants.CUSTOMER_SIGNATURE_DOC_REF:
                return aofDetails.getClientSignatureFileName();

            default:
                return "";
        }
    }

    protected String getDocValidation() {
        return customerApiProperties.getAofDetails().getDocValidation();
    }

    protected String getAccountNumber(JourneyData journeyData) {
        return CustomerUtil.getFCGiftCityProfile(journeyData)
                .map(FcGcProfile::getAccountNumber)
                .orElse(null);
    }

    protected String getCustomerId(JourneyData journeyData) {
        return CustomerUtil.getFCGiftCityProfile(journeyData)
                .map(FcGcProfile::getCustomerNumber)
                .orElse(null);
    }
    @Named("formatDob")
    protected String formatDob(String dob) {
        if (dob == null || dob.isBlank()) {
            return null;
        }

        return LocalDate.parse(dob)
                .format(DateTimeFormatter.ofPattern("dd-MMM-yyyy", Locale.ENGLISH));
    }
}