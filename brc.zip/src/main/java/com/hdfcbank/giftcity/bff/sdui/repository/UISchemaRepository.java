package com.hdfcbank.giftcity.bff.sdui.repository;



import com.hdfcbank.giftcity.bff.sdui.entity.UISchemaEntity;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface UISchemaRepository extends MongoRepository<UISchemaEntity, String> {

    Optional<UISchemaEntity> findByPageAndSchemaVersion(String page, String schemaVersion);
}
