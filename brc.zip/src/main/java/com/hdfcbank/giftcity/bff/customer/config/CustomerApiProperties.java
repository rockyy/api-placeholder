package com.hdfcbank.giftcity.bff.customer.config;

import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import java.util.Map;

@Getter
@Setter
@Configuration
@ConfigurationProperties("api")
public class CustomerApiProperties {
    private ApiDetails generateAndDispatchOtp;
    private ApiDetails verifyOtp;
    private ApiDetails fetchCasa;
    private ApiDetails fetchGcIdentify;
    private ApiDetails accountDetails;
    private ApiDetails fetchProfile;
    private ApiDetails uploadAttachment;
    private Map<String,Map<String,String>> templateId;
    private Map<String,Map<String,String>> customerTypes;
    private ApiDetails createFccCustomer;
    private ApiDetails createFccCustomerAccount;
    private AOFDetails aofDetails;
    private ConfigDetails accountStatementConfig;
    private ApiDetails aofPendingDocumentEmailAlert;
    private ApiDetails aofPendingDocumentSmsAlert;


    @Getter
    @Setter
    public static class AOFDetails {
        private String sigImagePath;
        private String accImagePath;
        private String acc2ImagePath;
        private String aofImagePath;

        private String aofOpeningDocId;
        private String accStatementDocId;
        private String clientSignatureDocId;

        private String aofOpeningFileName;
        private String accStatementFileName;
        private String clientSignatureFileName;

        private String docValidation;
        private String branchName;
        private String branchCode;
        private String productCode;

    }

    @Getter
    @Setter
    public static class ConfigDetails {
        private String txnType;
        private Integer statementDays;
        private Integer statementsDocumentSplitCount;
        private Map<String, String> nominationMappings;
    }

    @Getter
    @Setter
    public static class ApiDetails {
        private String serviceUrl;
        private Map<String, String> serviceDefaults;
    }
}
