package com.hdfcbank.giftcity.bff.account.model;

import com.hdfcbank.common.models.vo.core.ApiResponse;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.SuperBuilder;


@Getter
@Setter
@AllArgsConstructor
@SuperBuilder
public class NomineeResponse extends ApiResponse<NomineeResponse.NomineeDetailsResponse> {

    @Getter
    @Setter
    @SuperBuilder
    public static class NomineeDetailsResponse {

        private NomineeDetails nomineeDetails;

        @Getter
        @Setter
        @SuperBuilder
        public static class NomineeDetails {

            private String nomineeName;
            private String relation;
            private String dateOfBirth;

            private String txtNomAdrAdd1;
            private String txtNomAdrAdd2;
            private String txtNomAdrAdd3;
            private String nomAdrCity;
            private String nomAdrState;
            private String nomAdrCntry;
            private String nomAdrZip;

            private String nomPhoneCountry;
            private String nomPhoneMobile;
            private String nomEmailId;

            private String namGuardian;
            private String guardNomineeRelation;

            private String guardAdrAdd1;
            private String guardAdrAdd2;
            private String guardAdrAdd3;
            private String guardAdrCity;
            private String guardAdrState;
            private String guardAdrCntry;
            private String guardAdrZip;

            private String guardPhoneCntry;
            private String guardPhoneMobile;
            private String guardEmailId;

            private String guardDatOfBirth;
        }
    }
}
