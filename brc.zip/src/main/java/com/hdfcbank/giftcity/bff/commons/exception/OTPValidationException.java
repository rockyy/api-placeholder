package com.hdfcbank.giftcity.bff.commons.exception;

import com.hdfcbank.common.models.vo.core.ApiResponseStatusCodeLiteral;
import lombok.Getter;

@Getter
public class OTPValidationException extends RuntimeException {

    private final ApiResponseStatusCodeLiteral apiResponseStatusCodeLiteral;

    public OTPValidationException(ApiResponseStatusCodeLiteral statusCode) {
        super(statusCode.getMessage());
        this.apiResponseStatusCodeLiteral = statusCode;
    }

    public OTPValidationException(ApiResponseStatusCodeLiteral statusCode, Throwable cause) {
        super(statusCode.getMessage(), cause);
        this.apiResponseStatusCodeLiteral = statusCode;
    }
}