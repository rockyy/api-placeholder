package com.hdfcbank.giftcity.bff.customer.config;

import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import java.util.List;

@Getter
@Setter
@Configuration
@ConfigurationProperties(prefix = "app.review-customer")
public class ReviewCustomerProperties {

    private String branchName;
    private String branchCode;
    private String branchAddress;
    private String purposeOfAccount;
    private List<String> financialProducts;
}
