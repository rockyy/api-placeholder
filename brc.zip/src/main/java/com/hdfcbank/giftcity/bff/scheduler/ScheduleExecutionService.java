package com.hdfcbank.giftcity.bff.scheduler;

import com.hdfcbank.giftcity.bff.account.service.FtsApplicationInquireService;
import com.hdfcbank.giftcity.bff.application.service.BackgroundEventPublisherService;
import com.hdfcbank.giftcity.bff.application.service.impl.ApplicationServiceImpl;
import com.hdfcbank.giftcity.bff.customer.config.CustomerApiProperties;
import com.hdfcbank.giftcity.bff.customer.rmcodes.service.RmCodesMasterService;
import com.hdfcbank.giftcity.bff.commons.repository.JourneyRepository;
import com.hdfcbank.job.scheduler.common.model.ExecutionStatus;
import com.hdfcbank.job.scheduler.common.model.JobSchedule;
import com.hdfcbank.job.scheduler.common.service.DistributedSchedulingExecutionService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

@Slf4j
@Service
@Primary
@AllArgsConstructor
public class ScheduleExecutionService implements DistributedSchedulingExecutionService {

    @Autowired
    private RmCodesMasterService rmCodesMasterService;

    @Autowired
    private ApplicationServiceImpl applicationService;

    @Autowired
    private FtsApplicationInquireService applicationInquireService;

    @Override
    public ExecutionStatus execute(JobSchedule jobSchedule) {
        if(jobSchedule.getJobName().equals(JobName.LG_LC_MASTERSYNC.name())){
            log.info("Scheduler Started For LG_LC_MASTERSYNC -->> "+ LocalDateTime.now());
            rmCodesMasterService.saveOrUpdateRmCodes();
            log.info("Scheduler Ended For LG_LC_MASTERSYNC->> "+ LocalDateTime.now());
            return ExecutionStatus.COMPLETED;
        }

        if(jobSchedule.getJobName().equals(JobName.AOF_SUBMISSION_PENDING.name())){
            log.info("Scheduler Started For AOF_SUBMISSION_PENDING->> "+ LocalDateTime.now());
            applicationService.processAofSubmissionAlertReminders();
            log.info("Scheduler Ended For AOF_SUBMISSION_PENDING->> "+ LocalDateTime.now());
            return ExecutionStatus.COMPLETED;
        }

        if(jobSchedule.getJobName().equals(JobName.FTS_APPLICATION_INQUIRE.name())){
            log.info("Scheduler Started For FTS_APPLICATION_INQUIRE->> "+ LocalDateTime.now());
            applicationInquireService.inquireApplicationsAndUpdateJourneyState();
            log.info("Scheduler Ended For FTS_APPLICATION_INQUIRE->> "+ LocalDateTime.now());
            return ExecutionStatus.COMPLETED;
        }

        log.info("Scheduler Started For UNKNOWN {} {}-->> ", jobSchedule.getJobName(), LocalDateTime.now());
        return ExecutionStatus.COMPLETED;
    }

    enum JobName{
        LG_LC_MASTERSYNC,
        FTS_APPLICATION_INQUIRE,
        AOF_SUBMISSION_PENDING;
    }
}
