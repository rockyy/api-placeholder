package com.hdfcbank.giftcity.bff.customer.model;

import com.hdfcbank.common.models.vo.core.ApiResponse;
import lombok.*;

@Getter
@Setter
@ToString
public class FetchSignatureResponse extends ApiResponse<FetchSignatureResponse.SignatureDetails> {

    @Getter
    @Setter
    @ToString
    @AllArgsConstructor
    @NoArgsConstructor
    @Builder
    public static class SignatureDetails {

        private String customerId;
        private String signature;
    }
}
