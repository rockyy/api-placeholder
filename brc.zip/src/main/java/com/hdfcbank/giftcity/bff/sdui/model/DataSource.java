package com.hdfcbank.giftcity.bff.sdui.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DataSource {
    private String url;
    private String version;
}
