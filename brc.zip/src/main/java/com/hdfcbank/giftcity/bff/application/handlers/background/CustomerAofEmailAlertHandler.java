package com.hdfcbank.giftcity.bff.application.handlers.background;


import com.hdfcbank.adapters.clients.feign.communication.CommunicationFeignClient;
import com.hdfcbank.adapters.vo.*;
import com.hdfcbank.common.models.vo.journey.JourneyData;
import com.hdfcbank.common.models.vo.journey.JourneyState;
import com.hdfcbank.giftcity.bff.commons.enums.CommonJourneyStates;
import com.hdfcbank.giftcity.bff.commons.exception.handler.DownstreamResponseHandler;
import com.hdfcbank.giftcity.bff.commons.file.InlineImage;
import com.hdfcbank.giftcity.bff.commons.handler.Handler;
import com.hdfcbank.giftcity.bff.commons.handler.HandlerContext;
import com.hdfcbank.giftcity.bff.commons.handler.HandlerResult;
import com.hdfcbank.giftcity.bff.commons.model.FcIndiaProfile;
import com.hdfcbank.giftcity.bff.commons.utility.EmailHeaderAttachmentUtil;
import com.hdfcbank.giftcity.bff.commons.utility.TextSanityUtil;
import com.hdfcbank.giftcity.bff.customer.config.CustomerApiProperties;
import com.hdfcbank.giftcity.bff.customer.utility.CustomerUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.util.ArrayList;
import java.util.List;

import static com.hdfcbank.giftcity.bff.commons.constant.CommonConstants.*;
import static com.hdfcbank.giftcity.bff.commons.enums.CommonJourneyStates.*;

@Slf4j
@Service
@RequiredArgsConstructor
public class CustomerAofEmailAlertHandler implements Handler<EmailMessageSuccess> {

    private final CommunicationFeignClient communicationFeignClient;
    private final EmailHeaderAttachmentUtil emailHeaderAttachmentUtil;

    private static final String SUCCESS = "0000";
    private static final String EMAIL = "EMAIL";

    @Override
    public boolean preConditions(HandlerContext handlerContext) {
        return hasJourneyState(handlerContext, FTS_SUCCESS_CALLBACK.name())
                && !hasJourneyState(handlerContext, FTS_DOCS_RECEIVED_CALLBACK.name());
    }

    @Override
    public HandlerResult<EmailMessageSuccess> handle(HandlerContext handlerContext) {

        log.info("inside pending Email alert handler ");
        JourneyData journeyData = handlerContext.getJourneyData();

        try {

            FcIndiaProfile.Profile fcProfile =
                    CustomerUtil.getPrimaryProfile(journeyData).orElse(null);

            String journeyId = journeyData.getJourneyId();
            String emailTemplateId = (String) handlerContext.getProperties().get(EMAIL_TEMPLATE);

                    log.info("getting email template is {}", TextSanityUtil.sanitize(emailTemplateId));

                    List<InlineImage> inlineImages = List.of(
                    emailHeaderAttachmentUtil.prepareInlineImage(HEADER_IMG, JPEG, HEADER_CID),
                    emailHeaderAttachmentUtil.prepareInlineImage(CALL_US_IMG, PNG, CALL_US_CID),
                    emailHeaderAttachmentUtil.prepareInlineImage(WHATSAPP_IMG, PNG, WHATSAPP_CID),
                    emailHeaderAttachmentUtil.prepareInlineImage(MOBILE_APP_IMG, PNG, MOBILE_APP_CID),
                    emailHeaderAttachmentUtil.prepareInlineImage(INTERNET_BANKING_IMG, PNG, INTERNET_BANKING_CID),
                    emailHeaderAttachmentUtil.prepareInlineImage(BRANCH_LOCATOR_IMG, PNG, BRANCH_LOCATOR_CID));

            List<UploadAttachmentResponse.UploadAttachmentDetail> attachments = new ArrayList<>();
            for (InlineImage inlineImage : inlineImages) {

                UploadAttachmentResponse uploadResponse =
                        communicationFeignClient.uploadAttachmentFile(
                                inlineImage.getFile(),
                                journeyId
                        );

                if (uploadResponse == null || uploadResponse.getData() == null) {
                    throw new IllegalStateException(
                            "Failed to upload inline image : " + TextSanityUtil.sanitize(inlineImage.getCid())
                    );
                }

                attachments.add(
                        UploadAttachmentResponse.UploadAttachmentDetail.builder()
                                .filename(uploadResponse.getData().getFilename())
                                .reference(uploadResponse.getData().getReference())
                                .imageCidName(inlineImage.getCid())
                                .build()
                );
            }


            EmailDetails emailDetails =
                    EmailDetails.builder()
                            .to(new String[]{
                                    journeyData.getProfile().getEmailId()
                            })
                            .cc(new String[]{})
                            .attachments(attachments)
                            .build();

            SendMessageRequest emailRequest =
                    SendMessageRequest.builder()
                            .messageType(EMAIL)
                            .channel(EMAIL)
                            .mobileNumber(journeyData.getIsd().concat(journeyData.getMobileNumber()))
                            .customerName(fcProfile.getName())
                            .emailId(journeyData.getProfile().getEmailId())
                            .templateId(emailTemplateId)
                            .targetSystem(TargetSystemType.SMTP.name())
                            .emailDetails(emailDetails)
                            .build();

            log.info("before getting call to sendEmail ");

            EmailMessageSuccess response =
                    communicationFeignClient.sendEmail(emailRequest,journeyId);

            log.info("after success call to sendEmail ");

            if (response != null && response.getStatus() != null && SUCCESS.equals(response.getStatus().getCode())) {

                return HandlerResult.of(null, response, true);
            }

            return HandlerResult.of(DownstreamResponseHandler.handleResponse(response, HandlerName.AOF_SUBMISSION_EMAIL_ALERT.name(), false, journeyData.getJourneyName()), response, false);

        } catch (Exception ex) {

            log.error("Error while sending AOF pending Email", ex);

            return HandlerResult.<EmailMessageSuccess>of(DownstreamResponseHandler.handleResponse(null, HandlerName.AOF_SUBMISSION_EMAIL_ALERT.name(), false, journeyData.getJourneyName()), null, false);
        }
    }

    @Override
    public HandlerType getType() {
        return HandlerType.BACKGROUND_TASKS_POST_SUBMIT_SUCCESS;
    }

    @Override
    public HandlerName getName() {
        return HandlerName.AOF_SUBMISSION_EMAIL_ALERT;
    }

    @Override
    public CommonJourneyStates successState() {
        return CUSTOMER_AOF_SUBMISSION_EMAIL_ALERT_SUCCESS;
    }

    @Override
    public CommonJourneyStates failureState() {
        return CUSTOMER_AOF_SUBMISSION_EMAIL_ALERT_FAILURE;
    }
}
