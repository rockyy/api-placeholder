package com.hdfcbank.giftcity.bff.customer.utility;


import lombok.extern.slf4j.Slf4j;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Component;


@Component
@Slf4j
public class CustomerCacheUtility {
    @Cacheable(cacheNames = {"sso-details"}, key = "#authCode")
    public String getSSODetails(String ssoDetails, String authCode)
    {
        return ssoDetails;
    }


}
