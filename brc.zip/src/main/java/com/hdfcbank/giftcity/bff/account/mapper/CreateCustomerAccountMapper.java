package com.hdfcbank.giftcity.bff.account.mapper;

import com.hdfcbank.common.models.vo.journey.JourneyData;
import com.hdfcbank.giftcity.bff.customer.constants.CustomerConstants;
import com.hdfcbank.giftcity.bff.customer.utility.CustomerUtil;
import com.hdfcbank.giftcity.bff.infrastructure.service.JourneyService;
import com.hdfcbank.service.adapters.vo.account.CreateCustomerAccountRequest;
import com.hdfcbank.giftcity.bff.commons.constant.CommonConstants;
import com.hdfcbank.giftcity.bff.commons.model.FcIndiaProfile;
import com.hdfcbank.giftcity.bff.customer.model.ReviewCustomerResponse;
import com.hdfcbank.service.adapters.vo.account.CustomerAccountDetails;
import io.micrometer.common.util.StringUtils;

import org.mapstruct.*;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static com.hdfcbank.giftcity.bff.commons.constant.CommonConstants.*;
import static com.hdfcbank.giftcity.bff.customer.constants.CustomerConstants.*;

@Mapper(
        componentModel = "spring",
        imports = {LocalDate.class, DateTimeFormatter.class, CommonConstants.class, CustomerConstants.class, CustomerUtil.class},
        nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS,
        nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE,
        unmappedTargetPolicy = ReportingPolicy.IGNORE
)
public interface CreateCustomerAccountMapper {


    @Mapping(target = "branchCode",  expression = "java(getValue(serviceDefaults, CommonConstants.BRANCH_CODE))")
    @Mapping(target = "accountClass", expression = "java(getValue(serviceDefaults, CommonConstants.ACCOUNT_CLASS))")
    @Mapping(target = "location",  expression = "java(getValue(serviceDefaults, CommonConstants.LOCATION))")
    @Mapping(target = "communicationMedia", expression = "java(getValue(serviceDefaults, CommonConstants.COMMUNICATION_MEDIA))")
    @Mapping(target = "accountType",  expression = "java(getValue(serviceDefaults, CommonConstants.ACCOUNT_TYPE))")
    @Mapping(target = "noCreditStatus", expression = "java(getValue(serviceDefaults, CommonConstants.NO_CREDIT_STATUS))")
    @Mapping(target = "noDebitStatus",  expression = "java(getValue(serviceDefaults, CommonConstants.NO_DEBIT_STATUS))")
    @Mapping(source = "fcProfile.name", target = "customerName")
    @Mapping(source = "fcProfile.name", target = "accountDescription")
    // Explicit alternateAccountNumber mapping remains disabled after downstream duplicate-record errors.
    // Its configuration decision is tracked in docs/sonar-review.md.
    @Mapping(source = "fcProfile.mailingAddress1", target = "addressLine1")
    @Mapping(source = "fcProfile.mailingAddress2", target = "addressLine2")
    @Mapping(source = "fcProfile.mailingAddress3", target = "addressLine3")
    @Mapping(target = "addressLine4", ignore = true)
    // Explicit accountOpenDate mapping remains disabled pending the holiday-date contract.
    @Mapping(target = "udfDetails", expression = "java(mapUdfDetails(journeyData, serviceDefaults))")

    @Mapping(target = "nominee", expression = "java(mapNominee(nomineeDetail != null && nomineeDetail.isMinorNominee(), nomineeDetails, guardianDetails, journeyData))")

    CreateCustomerAccountRequest toRequest(
            @Context JourneyData journeyData,
            String customerNumber,
            FcIndiaProfile.Profile fcProfile,
            ReviewCustomerResponse.ReviewCustomerDetails.NomineeDetail nomineeDetail,
            ReviewCustomerResponse.ReviewCustomerDetails.Nominee nomineeDetails,
            ReviewCustomerResponse.ReviewCustomerDetails.Nominee guardianDetails,
            @Context Map<String, String> serviceDefaults,
            String currency
    );

    /*
     * NOMINEE LIST MAPPING
     */
    default List<CreateCustomerAccountRequest.Nominee> mapNominee(
            boolean minorNominee,
            ReviewCustomerResponse.ReviewCustomerDetails.Nominee nominee,
            ReviewCustomerResponse.ReviewCustomerDetails.Nominee guardianDetails,
            JourneyData journeyData
    ) {
        if (nominee == null) {
            return null;
        }
        CreateCustomerAccountRequest.Nominee nomineeRequest = new CreateCustomerAccountRequest.Nominee();
        CreateCustomerAccountRequest.NomineeDetails nomineeDetails = toNomineeDetails(nominee, journeyData);
        nomineeDetails.setMinorFlag(minorNominee ? CommonConstants.YES : CommonConstants.NO);
        nomineeRequest.setNomineeDetails(nomineeDetails);

        /*
         * SEND GUARDIAN ONLY FOR MINOR NOMINEE
         */
        if (minorNominee){
            nomineeRequest.setGuardianDetails(toGuardianDetails(guardianDetails, journeyData));
        }
        return List.of(nomineeRequest);
    }

    /*
     * NOMINEE DETAILS MAPPING
     */
    @Mapping(source = "name", target = "nomineeName")
    @Mapping(source = "dob", target = "dateOfBirth")
    @Mapping(source = "relation", target = "relationshipType")
    @Mapping(source = "pincode", target = "pinCode")
    @Mapping(
            target = "addressLine1",
            expression = "java(getNomineeAddressLine1(journeyData))")
    @Mapping(
            target = "addressLine2",
            expression = "java(getNomineeAddressLine2(journeyData))")
    @Mapping(
            target = "addressLine3",
            expression = "java(getNomineeAddressLine3(journeyData))")
    @Mapping(
            target = "addressLine4",
            expression = "java(getNomineeAddressLine4(journeyData))")
    CreateCustomerAccountRequest.NomineeDetails toNomineeDetails(ReviewCustomerResponse.ReviewCustomerDetails.Nominee nominee,  @Context JourneyData journeyData);

    /*
     * GUARDIAN DETAILS MAPPING
     */
    @Mapping(target = "guardianName", source = "name")
    @Mapping(target = "guardianRelationship", source = "relation")
    @Mapping(target = "guardianAddressCode", source = "addressCode")
    @Mapping(
            target = "guardianAddressLine1",
            expression = "java(getGuardianAddress1(journeyData))")
    @Mapping(
            target = "guardianAddressLine2",
            expression = "java(getGuardianAddress2(journeyData))")
    @Mapping(
            target = "guardianAddressLine3",
            expression = "java(getGuardianAddress3(journeyData))")
    @Mapping(
            target = "guardianAddressLine4",
            expression = "java(getGuardianAddress4(journeyData))")
    @Mapping(target = "guardianPincode", source = "pincode")
    CreateCustomerAccountRequest.GuardianDetails toGuardianDetails(ReviewCustomerResponse.ReviewCustomerDetails.Nominee guardian, @Context JourneyData journeyData);

    default ReviewCustomerResponse.ReviewCustomerDetails.Nominee getJourneyNominee(JourneyData journeyData) {

        ReviewCustomerResponse.ReviewCustomerDetails.NomineeDetail nomineeDetail =
                CustomerUtil.getNomineeDetailFromJourneyData(journeyData);

        return nomineeDetail != null ? nomineeDetail.getNominee() : null;
    }

    default boolean isAddressFromProfile(JourneyData journeyData) {

        String value = CustomerUtil.getValueByPath(
                journeyData,
                CustomerConstants.NOMINEE_DETAILS,
                CustomerConstants.NOMINEE_ADDRESS_FROM_PROFILE_PATH
        );

        return Boolean.parseBoolean(value);
    }

    default boolean isGuardianAddressSameAsNominee(JourneyData journeyData) {

        String value = CustomerUtil.getValueByPath(
                journeyData,
                CustomerConstants.NOMINEE_DETAILS,
                CustomerConstants.GUARDIAN_ADDRESS_SAME_AS_NOMINEE_PATH
        );

        return Boolean.parseBoolean(value);
    }


    default String getNomineeAddressLine1(JourneyData journeyData) {

        if (isAddressFromProfile(journeyData)) {
            ReviewCustomerResponse.ReviewCustomerDetails.Nominee nominee = getJourneyNominee(journeyData);
            return nominee != null ? nominee.getAddressLine1() : null;
        }

        return CustomerUtil.getValueByPath(
                journeyData,
                CustomerConstants.NOMINEE_DETAILS,
                CustomerConstants.NOMINEE_ADDRESS1_PATH);
    }

    default String getNomineeAddressLine2(JourneyData journeyData) {

        if (isAddressFromProfile(journeyData)) {
            ReviewCustomerResponse.ReviewCustomerDetails.Nominee nominee = getJourneyNominee(journeyData);
            return nominee != null ? nominee.getAddressLine2() : null;
        }

        return CustomerUtil.getValueByPath(
                journeyData,
                CustomerConstants.NOMINEE_DETAILS,
                CustomerConstants.NOMINEE_ADDRESS2_PATH);
    }

    default String getNomineeAddressLine3(JourneyData journeyData) {

        if (isAddressFromProfile(journeyData)) {
            ReviewCustomerResponse.ReviewCustomerDetails.Nominee nominee = getJourneyNominee(journeyData);
            return nominee != null ? nominee.getAddressLine3() : null;
        }

        return CustomerUtil.getValueByPath(
                journeyData,
                CustomerConstants.NOMINEE_DETAILS,
                CustomerConstants.NOMINEE_ADDRESS3_PATH);
    }

    default String getNomineeAddressLine4(JourneyData journeyData) {

        if (isAddressFromProfile(journeyData)) {
            ReviewCustomerResponse.ReviewCustomerDetails.Nominee nominee = getJourneyNominee(journeyData);
            return nominee != null ? nominee.getAddressLine4() : null;
        }

        return CustomerUtil.getValueByPath(
                journeyData,
                CustomerConstants.NOMINEE_DETAILS,
                CustomerConstants.NOMINEE_ADDRESS4_PATH);
    }

    default String getGuardianAddress1(JourneyData journeyData) {

        if (isGuardianAddressSameAsNominee(journeyData)) {
            return getNomineeAddressLine1(journeyData);
        }

        return CustomerUtil.getValueByPath(
                journeyData,
                CustomerConstants.NOMINEE_DETAILS,
                CustomerConstants.GUARDIAN_ADDRESS1_PATH);
    }

    default String getGuardianAddress2(JourneyData journeyData) {

        if (isGuardianAddressSameAsNominee(journeyData)) {
            return getNomineeAddressLine2(journeyData);
        }

        return CustomerUtil.getValueByPath(
                journeyData,
                CustomerConstants.NOMINEE_DETAILS,
                CustomerConstants.GUARDIAN_ADDRESS2_PATH);
    }

    default String getGuardianAddress3(JourneyData journeyData) {

        if (isGuardianAddressSameAsNominee(journeyData)) {
            return getNomineeAddressLine3(journeyData);
        }

        return CustomerUtil.getValueByPath(
                journeyData,
                CustomerConstants.NOMINEE_DETAILS,
                CustomerConstants.GUARDIAN_ADDRESS3_PATH);
    }

    default String getGuardianAddress4(JourneyData journeyData) {

        if (isGuardianAddressSameAsNominee(journeyData)) {
            return getNomineeAddressLine4(journeyData);
        }

        return CustomerUtil.getValueByPath(
                journeyData,
                CustomerConstants.NOMINEE_DETAILS,
                CustomerConstants.GUARDIAN_ADDRESS4_PATH);
    }


    /*
     * SERVICE DEFAULT VALUE
     */
    default String getValue(
            Map<String, String> serviceDefaults,
            String key
    ) {
        if (serviceDefaults == null) {
            return null;
        }
        return serviceDefaults.get(key);
    }

    /*
     * ALTERNATE ACCOUNT NUMBER
     */
    default String getAlternateAccountNumber(FcIndiaProfile.Profile fcProfile) {
        return Optional.ofNullable(fcProfile.getCustomerAccountDetails())
                .filter(list -> !list.isEmpty())
                .map(list -> list.get(0))
                .map(FcIndiaProfile.CustomerAccountDetail::getAccountNumber)
                .orElse(null);
    }

    default String buildStateCity(String state, String city) {
        String value = Stream.of(state, city)
                .filter(StringUtils::isNotBlank)
                .collect(Collectors.joining(", "));

        return StringUtils.isNotBlank(value) ? value : null;
    }

    default List<CreateCustomerAccountRequest.UdfDetail> mapUdfDetails(
            JourneyData journeyData,  Map<String, String> serviceDefaults) {

        Map<String, Object> customerUserInputs =
                JourneyService.getDomainPageUserInputs(
                        journeyData,
                        REVIEW_DETAILS);

        if (customerUserInputs == null || customerUserInputs.isEmpty()) {
            return null;
        }

        List<CreateCustomerAccountRequest.UdfDetail> udfDetails =
                new ArrayList<>();

        addUdf(udfDetails, RM_CODE,
                customerUserInputs.get(LG_CODE_PATH));


        addUdf(udfDetails, SOURCING_BR_CODE,
                getValue(serviceDefaults, CommonConstants.BRANCH_CODE));

        addUdf(udfDetails, SOURCING_BRANCH,
                getValue(serviceDefaults, BRANCH_NAME));

        return udfDetails.isEmpty() ? null : udfDetails;
    }

    default void addUdf(
            List<CreateCustomerAccountRequest.UdfDetail> udfDetails,
            String fieldName,
            Object value) {

        if (value != null) {
            udfDetails.add(
                    CreateCustomerAccountRequest.UdfDetail.builder()
                            .fieldName(fieldName)
                            .fieldValue(String.valueOf(value))
                            .build());
        }
    }
}
