package com.hdfcbank.giftcity.bff.commons.handler;

import com.hdfcbank.common.models.vo.journey.JourneyData;
import com.hdfcbank.common.models.vo.journey.JourneyDetail;
import com.hdfcbank.common.models.vo.journey.JourneyState;

import java.util.Objects;
import java.util.Optional;
import java.util.List;



public interface Handler<T> extends JourneyHandler {

    @Override
    HandlerResult<T> handle(HandlerContext handlerContext);

    enum HandlerType {
        CUSTOMER_POST_SUBMIT,
        BACKGROUND_TASKS_POST_SUBMIT_SUCCESS
    }

    enum HandlerName {
        CREATE_CUSTOMER,
        CREATE_SIGNATURE,
        CREATE_ACCOUNT,
        CLOSE_CUSTOMER,
        RISK_ANALYSIS,
        FTS_ACCOUNT_OPENING,
        CREATE_REFERENCE_NUMBER,
        DPCFTP_UPLOAD,
        FETCH_NOMINEE,
        CUSTOMER_AOF_EMAIL_NOTIFY,
        AOF_WITH_ANNEXTURE_UPLOAD,
        AOF_WITHOUT_ANNEXTURE_UPLOAD,
        ACCOUNT_STATEMENTS_FETCH,
        FCC_ACCOUNT_UNFREEZE,
        AOF_SUBMISSION_SMS_ALERT,
        AOF_SUBMISSION_EMAIL_ALERT,
        FTS_REJECT_CALLBACK_SMS,
        FTS_REJECT_CALLBACK_EMAIL,
        PURGE_DOCUMENTS
    }

    default boolean hasJourneyState(
            HandlerContext context,
            String stateName
    ) {

        return Optional.ofNullable(context.getJourneyData())
                .map(JourneyData::getJourneyDetail)
                .map(JourneyDetail::getJourneyStates)
                .stream()
                .flatMap(List::stream)
                .filter(Objects::nonNull)
                .map(JourneyState::getStateName)
                .anyMatch(stateName::equalsIgnoreCase);
    }
    default boolean isSuccess(HandlerContext context, HandlerName handlerName) {

        return Optional.ofNullable(
                        context.getData().get(handlerName)
                )
                .filter(HandlerResult.class::isInstance)
                .map(HandlerResult.class::cast)
                .map(HandlerResult::isSuccess)
                .orElse(false);
    }

    default <R> R getResult(HandlerContext context, HandlerName handlerName, Class<R> clazz) {
        return Optional.ofNullable(context.getData().get(handlerName))
                .filter(HandlerResult.class::isInstance)
                .map(HandlerResult.class::cast)
                .map(HandlerResult::getResult)
                .filter(clazz::isInstance)
                .map(clazz::cast)
                .orElse(null);
    }
}
