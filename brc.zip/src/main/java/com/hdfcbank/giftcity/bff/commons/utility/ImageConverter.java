package com.hdfcbank.giftcity.bff.commons.utility;

import com.hdfcbank.giftcity.bff.commons.enums.ImageFormat;
import lombok.experimental.UtilityClass;
import lombok.extern.slf4j.Slf4j;

import javax.imageio.ImageIO;
import javax.imageio.ImageReader;
import javax.imageio.stream.ImageInputStream;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Iterator;

@Slf4j
@UtilityClass
public class ImageConverter {

    public static byte[] convertImage(byte[] imageBytes,
                                      ImageFormat targetFormat,
                                            int maxWidth,
                                      int maxHeight) throws IOException {

        BufferedImage image = ImageIO.read(new ByteArrayInputStream(imageBytes));
        if (image == null) {
            throw new IOException("Unsupported image format");
        }

        BufferedImage resizedImage = resizeImage(image, maxWidth, maxHeight);

        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        if (!ImageIO.write(resizedImage, targetFormat.name(), baos)) {
            throw new IOException("No ImageIO writer found for format: " + targetFormat);
        }

        return baos.toByteArray();
    }

    private static BufferedImage resizeImage(BufferedImage originalImage, int maxWidth, int maxHeight) {

        int width = originalImage.getWidth();
        int height = originalImage.getHeight();

        double scale = Math.min((double) maxWidth / width, (double) maxHeight / height);

        if (scale >= 1.0) {
            return originalImage;
        }

        int newWidth = (int) (width * scale);
        int newHeight = (int) (height * scale);

        BufferedImage resized = new BufferedImage(newWidth, newHeight, BufferedImage.TYPE_INT_RGB);

        Graphics2D g2d = resized.createGraphics();
        g2d.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
        g2d.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        g2d.drawImage(originalImage, 0, 0, newWidth, newHeight, null);
        g2d.dispose();

        return resized;
    }

    public static boolean isImageFormat(byte[] imageBytes, ImageFormat format) throws IOException {

        try (ImageInputStream input = ImageIO.createImageInputStream(new ByteArrayInputStream(imageBytes))) {

            Iterator<ImageReader> readers = ImageIO.getImageReaders(input);

            if (!readers.hasNext()) {
                throw new IOException("Unsupported image format.");
            }

            ImageReader reader = readers.next();
            try {
                reader.setInput(input);

                String actualFormat = reader.getFormatName();
                log.info("Identified image format {}", TextSanityUtil.sanitize(actualFormat));

                if (actualFormat == null) {
                    throw new IOException("Unable to determine image format.");
                }

                return format.name().equalsIgnoreCase(actualFormat);

            } finally {
                reader.dispose();
            }
        }
    }
}