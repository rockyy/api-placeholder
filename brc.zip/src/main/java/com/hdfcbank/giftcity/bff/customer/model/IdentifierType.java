package com.hdfcbank.giftcity.bff.customer.model;

public enum IdentifierType {
    DOB, PAN, CUSTOMER_ID;
}