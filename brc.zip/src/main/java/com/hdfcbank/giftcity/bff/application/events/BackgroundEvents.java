package com.hdfcbank.giftcity.bff.application.events;

import com.hdfcbank.giftcity.bff.commons.handler.Handler;
import lombok.Getter;

@Getter
public enum BackgroundEvents {

    RISK_ANALYSIS(Handler.HandlerName.RISK_ANALYSIS),
    AOF_WITH_ANNEXTURE_UPLOAD(Handler.HandlerName.AOF_WITH_ANNEXTURE_UPLOAD),
    AOF_WITHOUT_ANNEXTURE_UPLOAD(Handler.HandlerName.AOF_WITHOUT_ANNEXTURE_UPLOAD),
    DPCFTP_UPLOAD(Handler.HandlerName.DPCFTP_UPLOAD),
    FTS_ACCOUNT_OPENING(Handler.HandlerName.FTS_ACCOUNT_OPENING),
    FCC_ACCOUNT_UNFREEZE(Handler.HandlerName.FCC_ACCOUNT_UNFREEZE),
    CUSTOMER_AOF_EMAIL_NOTIFY(Handler.HandlerName.CUSTOMER_AOF_EMAIL_NOTIFY),
    ACCOUNT_STATEMENTS_FETCH(Handler.HandlerName.ACCOUNT_STATEMENTS_FETCH),
    AOF_SUBMISSION_SMS_ALERT(Handler.HandlerName.AOF_SUBMISSION_SMS_ALERT),
    AOF_SUBMISSION_EMAIL_ALERT(Handler.HandlerName.AOF_SUBMISSION_EMAIL_ALERT),
    FTS_REJECT_CALLBACK_SMS(Handler.HandlerName.FTS_REJECT_CALLBACK_SMS),
    FTS_REJECT_CALLBACK_EMAIL(Handler.HandlerName.FTS_REJECT_CALLBACK_EMAIL),
    PURGE_DOCUMENTS(Handler.HandlerName.PURGE_DOCUMENTS)
    ;


    private final Handler.HandlerName handlerName;

    BackgroundEvents(Handler.HandlerName handlerName) {
        this.handlerName = handlerName;
    }

}