package com.hdfcbank.giftcity.bff.commons.utility;

import lombok.experimental.UtilityClass;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.expression.BeanExpressionContextAccessor;
import org.springframework.context.expression.BeanFactoryResolver;
import org.springframework.expression.Expression;
import org.springframework.expression.ExpressionParser;
import org.springframework.expression.common.TemplateParserContext;
import org.springframework.expression.spel.standard.SpelExpressionParser;
import org.springframework.expression.spel.support.StandardEvaluationContext;

import java.util.Map;

@Slf4j
@UtilityClass
public class ExpressionEvaluationUtil {

    public static String evaluate(String expression) {
        return evaluate(expression, null);
    }

    public static String evaluate(String expression, Object rootObject) {
        return evaluate(expression, rootObject, String.class);
    }

    public static <T> T evaluate(String expression, Object rootObject, Class<T> clazz) {
        if (null == rootObject) {
            rootObject = Map.of();
        }
        ExpressionParser parser = new SpelExpressionParser();
        Expression exp = parser.parseExpression(expression, new TemplateParserContext());
        StandardEvaluationContext context = new StandardEvaluationContext(rootObject);
        context.setBeanResolver(new BeanFactoryResolver(AppContextUtil.getApplicationContext().getAutowireCapableBeanFactory()));
        context.addPropertyAccessor(new BeanExpressionContextAccessor());
        return exp.getValue(context, clazz);
    }

}