package com.hdfcbank.giftcity.bff.master.mapper;

import com.hdfcbank.common.models.vo.core.PageDetail;
import com.hdfcbank.giftcity.bff.commons.model.MasterDataValue;
import com.hdfcbank.giftcity.bff.commons.utility.TextSanityUtil;
import com.hdfcbank.giftcity.bff.master.models.MasterDataFetchRequest;
import com.hdfcbank.giftcity.bff.master.services.MasterDataService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.mapstruct.Named;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Slf4j
@Service
@RequiredArgsConstructor
public class CountryMapper {

    private static final String COUNTRY_MASTER = "country_master";
    private static final String COUNTRY_NAME_SELECTOR = "Name";
    private static final String ISO_KEY = "ISO";
    private static final String NAME = "name";

    private final MasterDataService masterDataService;

    @Named("masterDataFromCode")
    public MasterDataValue masterDataFromCode(String code) {

        if (code == null || code.isBlank()) {
            return null;
        }

        try {
            MasterDataFetchRequest request = buildRequest(code);

            PageDetail pageDetail = masterDataService.fetch(request);

            String description = pageDetail.getContent().stream()
                    .findFirst()
                    .map(item -> ((Map<String, Object>) item).get(NAME))
                    .map(Object::toString)
                    .orElse(code);

            return MasterDataValue.builder()
                    .code(code)
                    .description(description)
                    .build();

        } catch (Exception ex) {
            log.error("Failed to fetch country details for code {}", TextSanityUtil.sanitize(code), ex);

            return MasterDataValue.builder()
                    .code(code)
                    .description(code)
                    .build();
        }
    }

    @Named("descriptionFromCode")
    public String descriptionFromCode(String code) {
        return masterDataFromCode(code).getDescription();
    }

    @Named("descriptionFromMasterData")
    public String descriptionFromMasterData(MasterDataValue value) {
        return value != null ? value.getDescription() : null;
    }

    @Named("codeFromMasterData")
    public String codeFromMasterData(MasterDataValue value) {
        return value != null ? value.getCode() : null;
    }

    private MasterDataFetchRequest buildRequest(String countryCode) {
        return MasterDataFetchRequest.builder()
                .masterName(COUNTRY_MASTER)
                .selectors(List.of(COUNTRY_NAME_SELECTOR))
                .exactMatch(Map.of(ISO_KEY, countryCode))
                .asc(true)
                .build();
    }
}
