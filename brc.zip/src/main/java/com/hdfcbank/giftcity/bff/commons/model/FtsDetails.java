package com.hdfcbank.giftcity.bff.commons.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.*;
import lombok.experimental.SuperBuilder;

import java.util.List;

@Getter
@Setter
@ToString
@SuperBuilder
@NoArgsConstructor
public class FtsDetails {
    private String customerSignatureDocRef;

    @JsonFormat(with=JsonFormat.Feature.ACCEPT_SINGLE_VALUE_AS_ARRAY)
    private List<String> accountStatement1DocRef;

    @JsonFormat(with=JsonFormat.Feature.ACCEPT_SINGLE_VALUE_AS_ARRAY)
    private List<String> accountStatement2DocRef;

    private String aofWithAnnextureDocRef;
    private String aofWithoutAnnextureDocRef;
    private String uploadedZipFileLocation;
    private List<String> accountStatement1UploadedFiles;
    private List<String> accountStatement2UploadedFiles;

    private FtsCallbackPageData ftsCallbackPageData;
    private FtsAccountOpeningDetails ftsAccountOpeningDetails;

    @Setter
    @Getter
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class FtsAccountOpeningDetails{
        private String status;

        private String rejectReason;

        private String acknowledgementNo;

        private String errorCode;

    }

    @Setter
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class FtsCallbackPageData {

        private  String barCode;
        private  String statusCode;
        private  String statusDesc;
    }
}
