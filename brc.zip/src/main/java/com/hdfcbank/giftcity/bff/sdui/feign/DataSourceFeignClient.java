package com.hdfcbank.giftcity.bff.sdui.feign;

import com.hdfcbank.common.models.vo.core.ApiResponse;

import com.hdfcbank.giftcity.bff.sdui.model.DataSourceRequest;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import tools.jackson.databind.JsonNode;


public interface DataSourceFeignClient {

    @PostMapping
    ApiResponse<JsonNode> callDataSourceAPI(@RequestBody Object request);
}
