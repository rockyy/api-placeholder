package com.hdfcbank.giftcity.bff.commons.enums;

public enum ImageFormat {
    PNG,
    TIF,
    GIF,
    JPG
}
