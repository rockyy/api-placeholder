package com.hdfcbank.giftcity.bff.callback.service;
import com.hdfcbank.giftcity.bff.application.events.BackgroundEvents;
import com.hdfcbank.giftcity.bff.application.service.BackgroundEventPublisherService;
import com.hdfcbank.giftcity.bff.commons.utility.TextSanityUtil;
import com.hdfcbank.service.adapters.vo.customer.CloseCustomerResponse;
import com.hdfcbank.common.models.vo.core.ApiResponseStatus;
import com.hdfcbank.common.models.vo.journey.JourneyData;
import com.hdfcbank.common.models.vo.mdc.MDCValues;
import com.hdfcbank.giftcity.bff.callback.model.*;


import com.hdfcbank.giftcity.bff.commons.enums.CommonJourneyStates;
import com.hdfcbank.giftcity.bff.commons.enums.CustomCommonApiStatusCodes;
import com.hdfcbank.giftcity.bff.commons.enums.JourneyPageName;
import com.hdfcbank.giftcity.bff.commons.model.FcGcProfile;
import com.hdfcbank.giftcity.bff.customer.service.CustomerService;
import com.hdfcbank.giftcity.bff.infrastructure.service.JourneyService;


import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import static com.hdfcbank.giftcity.bff.commons.constant.CommonConstants.*;

@Slf4j
@Service
@RequiredArgsConstructor
public class FtsStatusCallbackService {

    private final JourneyService journeyService;
    private final CustomerService customerService;
    private final BackgroundEventPublisherService backgroundEventPublisherService;

    @Value("${api.background-tasks-fifo.queueUrl}")
    private String backgroundTasksQueue;

    public FtsStatusCallbackResponse processFtsStatusCallback(FtsStatusCallbackRequest request) {

        // STEP 1: resolve inbound FTS status
        FtsAccountStatus status = FtsAccountStatus.fromCode(request.getStatus().getCode());

        if(status == null) {
            log.warn("Invalid FTS status code received: code={}, barCode={}",
                    TextSanityUtil.sanitize(request.getStatus().getCode()),
                    TextSanityUtil.sanitize(request.getBarCode()));
            return ack(request.getBarCode());
        }

        // STEP 2: fetch journey by reference number (barcode)
        Optional<JourneyData> journeyOpt =
                journeyService.fetchJourneyByReferenceNo(request.getBarCode());

        if(journeyOpt.isEmpty()) {
            log.warn("No journey found for barcode: {}", TextSanityUtil.sanitize(request.getBarCode()));
            return ack(request.getBarCode());
        }

        JourneyData journeyData = journeyOpt.get();
        MDCValues.setJourneyId(journeyData.getJourneyId());
        MDCValues.setJourneyName(journeyData.getJourneyName());

        // STEP 3: save callback payload to journey
        saveCallbackPayloadToJourney(journeyData.getJourneyId(),request);


        // STEP 4: execute business handler for resolved status
        try {
            processFtsChecks(status,request,journeyData);
        } catch (Exception ex) {
            log.error("FTS business handler failed for barcode: {}, journeyId={}",
                    TextSanityUtil.sanitize(request.getBarCode()),
                    TextSanityUtil.sanitize(journeyData.getJourneyId()),
                    ex);
            journeyService.recordJourneyState(
                    journeyData.getJourneyId(),
                    CommonJourneyStates.FTS_CALLBACK_PROCESSING_FAILED);
        }

        return ack(request.getBarCode());
    }

    private void saveCallbackPayloadToJourney(String journeyId,FtsStatusCallbackRequest request){

        FtsCallbackPageData pageData = FtsCallbackPageData.builder()
                .barCode(request.getBarCode())
                .statusCode(request.getStatus().getCode())
                .statusDesc(request.getStatus().getDesc())
                .build();

        journeyService.updateJourney(
                journeyId,
                JourneyPageName.FTS_STATUS_CALLBACK.getPageName(),
                pageData,
                CommonJourneyStates.FTS_CALLBACK_RECEIVED);
    }

    private void processFtsChecks(FtsAccountStatus status,FtsStatusCallbackRequest request,JourneyData journeyData) {

        switch (status) {
            case SUCCESS -> handleSuccessCase(journeyData);
            case REJECT -> handleRejectCase(request,journeyData);
            case ORIGINALS_RECEIVED -> handleOriginalsReceived(request,journeyData);
            case ORIGINALS_NOT_RECEIVED -> handleOriginalsNotReceived(request,journeyData);
            default -> log.warn("Unhandled FTS status code found: {}",status);
        }
    }

    private void handleSuccessCase(JourneyData journeyData) {
        
        journeyService.recordJourneyState(
                journeyData.getJourneyId(),
                CommonJourneyStates.FTS_SUCCESS_CALLBACK);

        backgroundEventPublisherService.sendBackgroundEvent(journeyData.getJourneyId(),journeyData.getProfile().getCustomerId(),BackgroundEvents.FCC_ACCOUNT_UNFREEZE,new HashMap<>() );
        backgroundEventPublisherService.sendBackgroundEvent(journeyData.getJourneyId(),journeyData.getProfile().getCustomerId(),BackgroundEvents.CUSTOMER_AOF_EMAIL_NOTIFY, new HashMap<>());
        backgroundEventPublisherService.sendBackgroundEvent(journeyData.getJourneyId(), journeyData.getProfile().getCustomerId(), BackgroundEvents.PURGE_DOCUMENTS, new HashMap<>());
    }

    private void handleRejectCase(FtsStatusCallbackRequest request,JourneyData journeyData) {

        String journeyId = journeyData.getJourneyId();

        journeyService.recordJourneyState(
                journeyId,
                CommonJourneyStates.FTS_REJECT_CALLBACK);
        log.info("REJECT case executed for barCode={}", TextSanityUtil.sanitize(request.getBarCode()));

        Map<String, Object> properties = Map.of(
                SMS_TEMPLATE, FTS_REJECT_CALLBACK_SMS_TEMPLATE,
                EMAIL_TEMPLATE, FTS_REJECT_CALLBACK_EMAIL_TEMPLATE
        );

        backgroundEventPublisherService.sendBackgroundEvent(journeyData.getJourneyId(),journeyData.getProfile().getCustomerId(),BackgroundEvents.FTS_REJECT_CALLBACK_SMS,properties);
        backgroundEventPublisherService.sendBackgroundEvent(journeyData.getJourneyId(),journeyData.getProfile().getCustomerId(),BackgroundEvents.FTS_REJECT_CALLBACK_EMAIL,properties);
        backgroundEventPublisherService.sendBackgroundEvent(journeyData.getJourneyId(), journeyData.getProfile().getCustomerId(), BackgroundEvents.PURGE_DOCUMENTS, new HashMap<>());

        Optional<String> customerNumberOpt = JourneyService.extractFromJourney(
                journeyData,
                JourneyPageName.CUSTOMER_FC_GIFT_CITY_DETAIL.getPageName(),
                FcGcProfile.class,
                FcGcProfile::getCustomerNumber);

        if(customerNumberOpt.isEmpty()) {
            log.warn("Customer number not found for journeyId={}", TextSanityUtil.sanitize(journeyId));
            return;
        }

        String customerNumber = customerNumberOpt.get();

        log.info("customerNumber fetched={}",TextSanityUtil.sanitize(customerNumber));

        CloseCustomerResponse response =
                customerService.closeFccCustomer(customerNumber,journeyId);

        boolean success =
                response != null
                        && response.getData() != null
                        && response.getData().getTransactionStatus() != null
                        && response.getData().getTransactionStatus().isSuccess();

        if(success) {
            log.info("FCC customer close successful for customerNumber={}",TextSanityUtil.sanitize(customerNumber));
            journeyService.recordJourneyState(
                    journeyId,
                    CommonJourneyStates.FCC_CLOSE_CUSTOMER_SUCCESS);
        } else {
            log.error("FCC customer close failed for customerNumber={}",TextSanityUtil.sanitize(customerNumber));
            journeyService.recordJourneyState(
                    journeyId,
                    CommonJourneyStates.FCC_CLOSE_CUSTOMER_FAILURE);
        }
    }

    private void handleOriginalsReceived(FtsStatusCallbackRequest request,JourneyData journeyData) {

        journeyService.recordJourneyState(
                journeyData.getJourneyId(),
                CommonJourneyStates.FTS_DOCS_RECEIVED_CALLBACK);
        log.info("ORIGINALS RECEIVED case executed for barCode={}", TextSanityUtil.sanitize(request.getBarCode()));
    }

    private void handleOriginalsNotReceived(FtsStatusCallbackRequest request,JourneyData journeyData) {

        journeyService.recordJourneyState(
                journeyData.getJourneyId(),
                CommonJourneyStates.FTS_DOCS_NOT_RECEIVED_CALLBACK);
        log.info("ORIGINALS NOT RECEIVED case executed for barCode={}", TextSanityUtil.sanitize(request.getBarCode()));
    }

    private FtsStatusCallbackResponse ack(String barCode) {
        return FtsStatusCallbackResponse.builder()
                .data(FtsStatusCallbackResponse.FtsStatusCallback.builder().barCode(barCode).build())
                .status(new ApiResponseStatus(CustomCommonApiStatusCodes.SUCCESS))
                .build();
    }
}