package com.hdfcbank.giftcity.bff.commons.validation;


import com.hdfcbank.giftcity.bff.commons.properties.CustomValidationProperties;
import com.hdfcbank.giftcity.bff.infrastructure.service.JourneyService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

@Service
@Slf4j
@RequiredArgsConstructor
public class ValidatorsFactory {

    private final List<Validator> validators;
    private final CustomValidationProperties customValidationProperties;

    public List<Validator> getValidators(String journeyName, ValidatorType validatorType) {
        List<String> validatorNames = customValidationProperties.getJourneys().get(journeyName).getValidators();
        if (validatorNames.isEmpty() || validatorType == null) {
            return Collections.emptyList();
        }
        return validators.stream().filter(validator -> validatorNames.contains(validator.name())
                && validator.type().equals(validatorType)).toList();
    }
}
