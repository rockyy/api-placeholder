package com.hdfcbank.giftcity.bff.commons.validation;


import com.hdfcbank.common.models.vo.core.ApiResponse;
import com.hdfcbank.giftcity.bff.commons.exception.handler.DownstreamResponseHandler;
import com.hdfcbank.giftcity.bff.commons.model.CustomValidationStatus;
import com.hdfcbank.giftcity.bff.commons.properties.CustomValidationProperties;
import com.hdfcbank.giftcity.bff.commons.utility.ValidationHelper;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;
import java.util.Optional;

public abstract class AbstractCommanValidator {

    @Autowired
    protected ValidationHelper validationHelper;



    public static final String CUSTOMER_FACTIVA = "CUSTOMER_FACTIVA";
    public static final String CUSTOMER_SIGNATURE = "CUSTOMER_SIGNATURE";
    public static final String CUSTOMER_UCIC = "CUSTOMER_UCIC";
    public static final String CKYC = "CKYC";

    public static final String UNKNOWN = "9999";
    protected CustomValidationProperties.FieldDetail validateData(String type, String value, CustomValidationProperties customValidationProperties, String journeyName) {
        return validationHelper.validateData(
                type,
                value,
                customValidationProperties,
                journeyName
        );
    }

    protected CustomValidationStatus getErrors(String journeyName, List<CustomValidationProperties.FieldDetail> fieldDetails, CustomValidationProperties customValidationProperties) {
        return validationHelper.getErrors(
                journeyName,
                fieldDetails,
                customValidationProperties
        );
    }
    public CustomValidationProperties.FieldDetail getFieldDetail(String journeyName, String type, CustomValidationProperties customValidationProperties) {
        return Optional.ofNullable(customValidationProperties)
                .map(CustomValidationProperties::getJourneys)
                .map(m -> m.get(journeyName))
                .map(CustomValidationProperties.CustomValidations::getFieldsDetail)
                .filter(list -> !list.isEmpty())
                .flatMap(list -> list.stream()
                        .filter(fd -> fd != null && type.equalsIgnoreCase(fd.getType()))
                        .findFirst())
                .orElse(null);
    }


    // Keep the protected extension point used by validators and subclass overrides.
    // Downstream response handling does not use the field-validation configuration.
    @SuppressWarnings("java:S1172")
    protected CustomValidationStatus getErrors(String journeyName, ApiResponse<?> apiResponse, CustomValidationProperties customValidationProperties, String category) {

        return DownstreamResponseHandler
                .handleResponse(apiResponse,
                        category,
                        false, journeyName);

    }

}
