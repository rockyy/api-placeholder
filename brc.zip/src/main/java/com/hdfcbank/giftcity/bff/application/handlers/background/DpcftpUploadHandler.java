package com.hdfcbank.giftcity.bff.application.handlers.background;

import com.hdfcbank.common.models.vo.journey.JourneyData;
import com.hdfcbank.giftcity.bff.commons.enums.CommonJourneyStates;
import com.hdfcbank.giftcity.bff.commons.exception.handler.DownstreamResponseHandler;
import com.hdfcbank.giftcity.bff.commons.handler.Handler;
import com.hdfcbank.giftcity.bff.commons.handler.HandlerContext;
import com.hdfcbank.giftcity.bff.commons.handler.HandlerResult;
import com.hdfcbank.giftcity.bff.commons.model.FtsDetails;
import com.hdfcbank.giftcity.bff.infrastructure.service.JourneyService;
import com.hdfcbank.model.SFTPTransferRequest;
import com.hdfcbank.model.SFTPTransferResponse;
import com.hdfcbank.service.SftpService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static com.hdfcbank.giftcity.bff.commons.enums.CommonJourneyStates.DPCFTP_UPLOAD_FAILURE;
import static com.hdfcbank.giftcity.bff.commons.enums.CommonJourneyStates.DPCFTP_UPLOAD_SUCCESS;
import static com.hdfcbank.giftcity.bff.commons.enums.JourneyPageName.FTS_DETAILS;


@Slf4j
@Service
@RequiredArgsConstructor
@Order(3)
public class DpcftpUploadHandler implements Handler<SFTPTransferResponse> {

    private static final String SUCCESS = "0000";
    private static final String SIGNATURE_FILE_NAME = "Signature.tif";
    private static final String AOF_WITH_ANNEXURE_FILE_NAME = "AOF_With_Annexure.tif";
    private static final boolean ZIP_FILES = true;
    private final SftpService sftpService;
    private final JourneyService journeyService;


    @Override
    public boolean preConditions(HandlerContext handlerContext) {
        return hasJourneyState(handlerContext, CommonJourneyStates.AOF_WITHOUT_ANNEXTURE_UPLOAD_SUCCESS.name());
    }

    @Override
    public HandlerResult<SFTPTransferResponse> handle(HandlerContext handlerContext) {

        JourneyData journeyData = handlerContext.getJourneyData();

        try {

            log.info("Background handler triggered : {}", getName());

            FtsDetails ftsDetails = JourneyService.extractFromJourney(
                            journeyData,
                            FTS_DETAILS.getPageName(),
                            (Class<FtsDetails>) FTS_DETAILS.getPageClassName())
                    .orElse(null);

            if (ftsDetails == null || isAnyDocumentMissing(ftsDetails)) {
                log.error("Required FTS document references are missing");
                return buildFailureResponse(journeyData, null);
            }

            List<SFTPTransferRequest.DocumentRefs> documentRefs = buildDocumentRefs(ftsDetails);


            SFTPTransferRequest request = SFTPTransferRequest.builder()
                    .zipFiles(ZIP_FILES)
                    .zippedFileName(journeyData.getReferenceNo())
                    .targetFolderName(String.valueOf(LocalDate.now().getDayOfMonth()))
                    .docRefIds(documentRefs)
                    .build();

            SFTPTransferResponse response = sftpService.transferDocumentsToSftp(
                    journeyData.getJourneyId(),
                    journeyData.getJourneyName(),
                    request);

            if (response != null
                    && response.getStatus() != null
                    && SUCCESS.equals(response.getStatus().getCode())) {

                ftsDetails.setUploadedZipFileLocation(response.getData().getUploadedFolderPath());
                journeyService.updateJourney(journeyData.getJourneyId(), FTS_DETAILS.getPageName(),
                        ftsDetails, CommonJourneyStates.DPCFTP_UPLOAD_SUCCESS);

                return HandlerResult.of(null, response, true);
            }

            return buildFailureResponse(journeyData, response);

        } catch (Exception ex) {
            log.error("Error while processing SFTP transfer", ex);
            return buildFailureResponse(journeyData, null);
        }
    }

    private boolean isAnyDocumentMissing(FtsDetails ftsDetails) {

        return (Stream.of(
                        ftsDetails.getCustomerSignatureDocRef(),
                        ftsDetails.getAofWithAnnextureDocRef(),
                        ftsDetails.getAofWithoutAnnextureDocRef()
                )
                .anyMatch(docRef -> docRef == null || docRef.isBlank()));
    }

    private List<SFTPTransferRequest.DocumentRefs> buildDocumentRefs(FtsDetails ftsDetails) {

        List<SFTPTransferRequest.DocumentRefs> combined = new ArrayList<>();
        List<SFTPTransferRequest.DocumentRefs> files =  Stream.of(
                        buildDocumentRef(
                                ftsDetails.getCustomerSignatureDocRef(),
                                SIGNATURE_FILE_NAME),
                        buildDocumentRef(
                                ftsDetails.getAofWithAnnextureDocRef(),
                                AOF_WITH_ANNEXURE_FILE_NAME)
                ).filter(Objects::nonNull)
                .toList();

        combined.addAll(files);


        return combined;
    }

    private SFTPTransferRequest.DocumentRefs buildDocumentRef(String docRef, String targetFileName) {

        return SFTPTransferRequest.DocumentRefs.builder()
                .docRef(docRef)
                .targetFileName(targetFileName)
                .build();
    }

    private HandlerResult<SFTPTransferResponse> buildFailureResponse(JourneyData journeyData, SFTPTransferResponse response) {

        return HandlerResult.<SFTPTransferResponse>of(
                DownstreamResponseHandler.handleResponse(
                        response,
                        getName().name(),
                        false,
                        journeyData.getJourneyName()),
                null,
                false);
    }

    @Override
    public HandlerType getType() {
        return HandlerType.BACKGROUND_TASKS_POST_SUBMIT_SUCCESS;
    }

    @Override
    public HandlerName getName() {
        return HandlerName.DPCFTP_UPLOAD;
    }

    @Override
    public CommonJourneyStates successState() {
        return DPCFTP_UPLOAD_SUCCESS;
    }

    @Override
    public CommonJourneyStates failureState() {
        return DPCFTP_UPLOAD_FAILURE;
    }
}
