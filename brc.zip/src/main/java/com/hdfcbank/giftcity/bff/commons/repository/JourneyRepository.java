package com.hdfcbank.giftcity.bff.commons.repository;


import com.hdfcbank.giftcity.bff.commons.model.JourneyCustomerProjection;
import com.hdfcbank.giftcity.bff.commons.model.JourneyDetails;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.List;

@Repository
public interface JourneyRepository extends MongoRepository<JourneyDetails, String> {

    @Query(
            value = """
            {
              "journeyDetail.journeyStates": {
                $elemMatch: {
                  stateName: ?1,
                  createdOn: { $gte: ?0 }
                }
              },
              "journeyDetail.journeyStates.stateName": {
                $nin: [?2]
              }
            }
            """,
            fields = """
            {
              '_id': 1,
              'journeyDetail.systemData.fcIndiaProfile.profiles.customerId': 1,
              'journeyDetail.journeyStates.stateName': 1,
              'journeyDetail.journeyStates.createdOn': 1
            }
            """
    )
    List<JourneyCustomerProjection> findEligibleJourneys(
            Date cutoffDate,
            String successState,
            String excludedState);
}