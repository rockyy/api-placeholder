package com.hdfcbank.giftcity.bff.customer.model;

import com.fasterxml.jackson.databind.JsonNode;

public class SSODetails {

    private JsonNode payload;

    public SSODetails() {
    }

    public JsonNode getPayload() {
        return this.payload;
    }

    public void setPayload(final JsonNode payload) {
        this.payload = payload;
    }
}
