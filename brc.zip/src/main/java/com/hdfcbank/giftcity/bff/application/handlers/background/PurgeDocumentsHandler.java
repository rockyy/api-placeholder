package com.hdfcbank.giftcity.bff.application.handlers.background;

import com.hdfcbank.adapters.clients.feign.document.DocumentFeignClient;
import com.hdfcbank.adapters.vo.*;
import com.hdfcbank.common.models.vo.journey.JourneyData;
import com.hdfcbank.giftcity.bff.commons.enums.CommonJourneyStates;
import com.hdfcbank.giftcity.bff.commons.handler.Handler;
import com.hdfcbank.giftcity.bff.commons.handler.HandlerContext;
import com.hdfcbank.giftcity.bff.commons.handler.HandlerResult;
import com.hdfcbank.giftcity.bff.commons.model.FtsDetails;
import com.hdfcbank.common.models.vo.core.ApiResponse;
import com.hdfcbank.giftcity.bff.infrastructure.service.JourneyService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import java.util.ArrayList;
import java.util.List;

import static com.hdfcbank.giftcity.bff.commons.enums.CommonJourneyStates.*;
import static com.hdfcbank.giftcity.bff.commons.enums.JourneyPageName.FTS_DETAILS;

@Slf4j
@Service
@RequiredArgsConstructor
public class PurgeDocumentsHandler implements Handler<DeleteDocumentResponse> {

    private final DocumentFeignClient documentFeignClient;

    @Override
    public boolean preConditions(HandlerContext handlerContext) {
        return true;
    }

    @Override
    public HandlerResult<DeleteDocumentResponse> handle(HandlerContext handlerContext) {

        JourneyData journeyData = handlerContext.getJourneyData();

        try {
            FtsDetails ftsDetails = JourneyService.extractFromJourney(
                    journeyData,
                    FTS_DETAILS.getPageName(),
                    FtsDetails.class
            ).orElseGet(FtsDetails::new);

            // CHANGE #1 — Extracted the inline list-building into a separate helper method
            // Previously: documentRefs = new ArrayList<>(); followed by add() and addAll() calls inline
            List<String> documentRefs = buildDocumentRefs(ftsDetails);

            // CHANGE #2 — This code is unchanged; simply uses the extracted list
            if (documentRefs.isEmpty()) {
                log.info("No generated documents found for deletion.");
                return HandlerResult.<DeleteDocumentResponse>of(null, null, true);
            }

            ApiResponse<DeleteDocumentResponse> failureResponse = null;
            List<String> failedDocs = new ArrayList<>();

            // CHANGE #3 — Loop now calls deleteDocument()
            // Previously: Entire deletion logic existed inside this for-loop as nested try/catch/if blocks
            for (String docRef : documentRefs) {
                failureResponse = deleteDocument(journeyData, docRef, failureResponse, failedDocs);
            }

            // No change — kept as-is
            if (failedDocs.isEmpty()) {
                log.info("Successfully deleted all generated documents.");
                return HandlerResult.<DeleteDocumentResponse>of(null, null, true);
            }

            // No change — kept exactly as original
            log.error("Document cleanup completed with failures. FailedCount={}, FailedDocuments={}",
                    failedDocs.size(), failedDocs);

            return HandlerResult.of(null,
                    failureResponse != null ? failureResponse.getData() : null,
                    false);

        } catch (Exception ex) {

            // No change — kept exactly as original
            log.error("Exception while deleting generated documents", ex);
            return HandlerResult.<DeleteDocumentResponse>of(null, null, false);
        }
    }

    /**
     * CHANGE #1 — NEW HELPER METHOD
     * Extracted the documentRefs building block from handle() to reduce cognitive complexity.
     * No logic changed, only moved.
     */
    private List<String> buildDocumentRefs(FtsDetails ftsDetails) {
        List<String> refs = new ArrayList<>();
        refs.add(ftsDetails.getCustomerSignatureDocRef());
        refs.add(ftsDetails.getAofWithAnnextureDocRef());
        refs.add(ftsDetails.getAofWithoutAnnextureDocRef());
        refs.addAll(ftsDetails.getAccountStatement1DocRef());
        refs.addAll(ftsDetails.getAccountStatement2DocRef());
        return refs;
    }

    /**
     * CHANGE #3 — NEW HELPER METHOD
     * This method contains exactly the same logic previously inside the for-loop,
     * but moved here to flatten nesting and reduce cognitive complexity.
     * No behavior or flow changed.
     */
    private ApiResponse<DeleteDocumentResponse> deleteDocument(
            JourneyData journeyData,
            String documentRef,
            ApiResponse<DeleteDocumentResponse> failureResponse,
            List<String> failedDocs) {

        // Previously inline inside loop — now extracted
        if (!StringUtils.hasText(documentRef)) {
            return failureResponse;
        }

        try {
            // Same code as before
            DeleteDocumentRequest request =
                    DeleteDocumentRequest.builder().key(documentRef).build();

            ApiResponse<DeleteDocumentResponse> response =
                    documentFeignClient.deleteFile(journeyData.getJourneyName(), request);

            boolean deleted = response != null
                    && response.getData() != null
                    && response.getData().isDeleted();

            // Same success block
            if (deleted) {
                log.info("Successfully deleted documentRef={}", documentRef);
                return failureResponse;
            }

            // Same failure block
            failedDocs.add(documentRef);

            if (failureResponse == null && response != null) {
                failureResponse = response;
            }

            log.error("Failed deleting documentRef={}, reason={}",
                    documentRef,
                    response != null && response.getData() != null
                            ? response.getData().getFailureReason()
                            : "Unknown");

        } catch (Exception ex) {
            // Same exception handling
            failedDocs.add(documentRef);
            log.error("Exception while deleting documentRef={}", documentRef, ex);
        }

        return failureResponse;
    }

    @Override
    public HandlerType getType() {
        return HandlerType.BACKGROUND_TASKS_POST_SUBMIT_SUCCESS;
    }

    @Override
    public HandlerName getName() {
        return HandlerName.PURGE_DOCUMENTS;
    }

    @Override
    public CommonJourneyStates successState() {
        return PURGE_DOCUMENTS_SUCCESS;
    }

    @Override
    public CommonJourneyStates failureState() {
        return PURGE_DOCUMENTS_FAILURE;
    }
}