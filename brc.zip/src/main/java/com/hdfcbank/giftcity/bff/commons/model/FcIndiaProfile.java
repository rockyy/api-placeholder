package com.hdfcbank.giftcity.bff.commons.model;

import lombok.*;
import lombok.experimental.SuperBuilder;

import java.util.List;


@Getter
@Setter
@ToString
public class FcIndiaProfile {


    private String existingCustomer;
    private String eligibleCustomer;
    private List<Profile> profiles;

    @Getter
    @Setter
    @SuperBuilder
    @NoArgsConstructor
    @ToString
    public static class Profile {
        private String name;
        private String dob;
        private String pinCode;
        private String customerId;
        private String mobileNumber;
        private String address;
        private String address1;
        private String address2;
        private String address3;
        private String address4;

        private String state;
        private String city;
        private MasterDataValue country;
        private String zipCode;
        private String branchCode;

        private String sasId;
        private String panNumber;
        private String email;
        private String aadhaarNumber;

        private String accountId;
        private String sourceId;

        private String flgBlocked;
        private String identifierName;
        private String addressTypeConsidered;

        private String customerType;
        private String customerTitle;
        private int customerDependents;

        private String employmentType;
        private String employerName;
        private String gender;
        private String age;
        private String maritalStatus;
        private String middleNames;
        private String firstName;
        private String surName;
        private String type;

        private String customerMobileNo;
        private String customerFullName;
        private String customerResidencePhoneNo;
        private String customerProfession;
        private int customerAnnualIncome;
        private Integer eligibleAccounts;
        private String refCustPhone;
        private String refPhoneMobile;

        private String mailingAddress1;
        private String mailingAddress2;
        private String mailingAddress3;
        private String mailingCity;
        private String mailingState;
        private MasterDataValue mailingCountry;
        private String mailingPinCode;

        private String ethnicCode;
        private String refCustItNum;
        private String namPermadrCntry;
        private String memoSevrity;
        private String namCustadrCntry;
        private String txtCustNATNLTY;
        private String customerFirstName;
        private String customerLastName;
        private String txtCustSex;
        private List<CustomerAccountDetail> customerAccountDetails;
        private List<CustomerMemoDetail> customerMemoDetails;
        private List<CustomerFATCADetail> customerFATCADetails;
        private List<CustomerAMLDetail> customerAMLDetails;

        private String panStatus;
        private String refCustEmail;
        private String kycStatus;
        private String codTypeKYC;
        private MasterDataValue nationality;
        private String customerMiddleName;
        private String motherMaidenName;
        private String refResPhoneArea;
        private String txtCustPrefix;
        private String kycType;
    }

    @Getter
    @Setter
    @SuperBuilder
    @NoArgsConstructor
    @ToString
    public static class CustomerAccountDetail {
        private String accountStatus;
        private String accountNumber;
        private String productTypeDescription;
        private String codAcctCustRel;
        private String codProdType;
        private String nomineeName;
        private String nomineeDob;
        private String datAcctOpen;
        private String productType;
        private String prodFrqChqThresholdLim;
        private String flagATM;
        private String flgNet;
        private String availableBalance;
        private String netBalance;
        private Integer amountODLimit;
        private String customerId;
        private String branchName;
        private String branchAddressLine1;
        private String branchAddressLine2;
        private String branchAddressLine3;
        private String branchCity;
        private String branchState;
        private String branchTelNo;
        private String ifscCode;
        private String micrCode;
        private String branchCode;
        private String prodTypeDesc;
    }

    @Getter
    @Setter
    public static class CustomerMemoDetail {
        private String flgSeverity;
    }

    @Getter
    @Setter
    public static class CustomerAMLDetail {
        private String amlDate2;
        private String grossIncDesc;
        private String annualTurnover;
        private String grossIncome;
        private String riskProfile;
        private String incomeSource;
        private String namCcy;
    }


    @Getter
    @Setter
    public static class CustomerFATCADetail {
        private String codTaxCntry1;
        private String codTaxCntry2;
        private String codTaxCntry3;
        private String codTaxCntry4;
        private String codTaxCntry5;
        private String tinNo1;
        private String tinNo2;
        private String tinNo3;
        private String typTinNo1;
        private String typTinNo2;
        private String typTinNo3;
        private String namCityBirth;
        private String codCntryBirth;
        private String namCustFather;
        private String namCustMaiden;
        private String namSpouseCust;
        private String addrTaxReporting1;
        private String idDocNum;
        private String idDocTyp;
        private String idDocExpDat;
        private String datExpiryVisa;
        private String datAnnexure;
        private String txtEmpadrAdd1;
        private String txtEmpadrAdd2;
        private String txtEmpadrAdd3;
        private String txtEmpadrZip;

        private String refCustPspt;
        private String datPsptIssue;
        private String datPsptExpiry;
        private String addrTyp;

    }

}
