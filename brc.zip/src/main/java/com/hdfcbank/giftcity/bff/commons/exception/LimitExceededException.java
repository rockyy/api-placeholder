package com.hdfcbank.giftcity.bff.commons.exception;

import com.hdfcbank.common.models.vo.core.ApiResponseStatusCodeLiteral;
import com.hdfcbank.giftcity.bff.customer.model.CustomerApiStatusCode;
import lombok.Getter;

@Getter
public class LimitExceededException extends RuntimeException{
    private final ApiResponseStatusCodeLiteral customerApiStatusCode;
    private final String attemptExceededMessage;

    public LimitExceededException(CustomerApiStatusCode customerApiStatusCode, String attemptExceededMessage) {
        this.customerApiStatusCode = customerApiStatusCode;
        this.attemptExceededMessage = attemptExceededMessage;
    }
    public LimitExceededException(String message, ApiResponseStatusCodeLiteral customerApiStatusCode) {
        super(message);
        this.customerApiStatusCode = customerApiStatusCode;
        this.attemptExceededMessage = customerApiStatusCode.getMessage();
    }

    public LimitExceededException(String message, CustomerApiStatusCode customerApiStatusCode, String attemptExceededMessage) {
        super(message);
        this.customerApiStatusCode = customerApiStatusCode;
        this.attemptExceededMessage = attemptExceededMessage;
    }

    public LimitExceededException(String message, Throwable cause, CustomerApiStatusCode customerApiStatusCode, String attemptExceededMessage) {
        super(message, cause);
        this.customerApiStatusCode = customerApiStatusCode;
        this.attemptExceededMessage = attemptExceededMessage;
    }

    public LimitExceededException(Throwable cause, CustomerApiStatusCode customerApiStatusCode, String attemptExceededMessage) {
        super(cause);
        this.customerApiStatusCode = customerApiStatusCode;
        this.attemptExceededMessage = attemptExceededMessage;
    }

    public LimitExceededException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace, CustomerApiStatusCode customerApiStatusCode, String attemptExceededMessage) {
        super(message, cause, enableSuppression, writableStackTrace);
        this.customerApiStatusCode = customerApiStatusCode;
        this.attemptExceededMessage = attemptExceededMessage;
    }
}
