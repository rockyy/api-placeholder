package com.hdfcbank.giftcity.bff.commons.annotation;
import com.hdfcbank.giftcity.bff.commons.enums.CommonJourneyStates;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
public @interface ValidateJourney {
    CommonJourneyStates[] shouldExists() default {};
    CommonJourneyStates[] shouldNotExists() default {};
    CommonJourneyStates[] hasAny() default {};
    CommonJourneyStates[] successStates() default {};
}
