package com.hdfcbank.giftcity.bff.customer.model;

public enum AccountType {

    SAVING,
    CURRENT
}
