package com.hdfcbank.giftcity.bff.customer.model;


import lombok.*;

@Getter
@Setter
@ToString
public class CustomerSignatureRequest {

    private String customerId;
}

