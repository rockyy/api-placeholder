package com.hdfcbank.giftcity.bff.commons.file;

import lombok.AllArgsConstructor;
import lombok.Getter;
import org.springframework.web.multipart.MultipartFile;

@Getter
@AllArgsConstructor
public class InlineImage {

    private final String cid;

    private final MultipartFile file;
}