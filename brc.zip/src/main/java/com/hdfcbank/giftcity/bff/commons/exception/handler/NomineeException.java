package com.hdfcbank.giftcity.bff.commons.exception.handler;

import com.hdfcbank.common.models.vo.core.ApiResponseStatusCodeLiteral;
import lombok.Getter;

@Getter
public class NomineeException extends RuntimeException {

    private final ApiResponseStatusCodeLiteral status;

    public NomineeException(ApiResponseStatusCodeLiteral status) {
        super(status.getMessage());
        this.status = status;
    }
}
