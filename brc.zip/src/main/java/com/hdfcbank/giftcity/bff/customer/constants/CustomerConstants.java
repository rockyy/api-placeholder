package com.hdfcbank.giftcity.bff.customer.constants;

import java.time.format.DateTimeFormatter;

public class CustomerConstants {

    public static final String PERMANENT_ADDRESS_TYPE = "permanent";

    public static final String MAILING_ADDRESS_TYPE = "mailing";

    public static final String PROFILE_DETAILS_UPDATED="PROFILE_DETAILS_UPDATED";

    public static final String DROPOFF_REASON="dropOffReason";

    public static final String EXCLUSION_FIELDS = "exclusionFields";

    public static final String CUSTOMER_SIGNATURE = "customerSignature";

    public static final String DROP_OFF_CUSTOMER_EXCLUDED="DROP_OFF_CUSTOMER_EXCLUDED";

    public static final String DROP_OFF="DROP_OFF";

    public static final String DROPOFF_EXCLUSIONS="dropOffExclusions";

    public static final String RESEND = "resend";

    public static final String SEND = "send";

    public static final String ALLOWED = "allowed";
    public static final String PROFILE_DETAILS = "profileDetails";

    public static final String CASA_DROPOFF_REASON = "casaDropOffReason";

    public static final String SSO="sso";
    public static final String PAN="PAN";

    public static final String PAN_NO="pan";
    public static final String MOBILE_NO="MobileNumber";
    public static final String DOB="dob";
    public static final String CUST_ID="custID";


    public static final String NR_CUSTOMER_TYPE = "O";
    public static final String BLOCKED_FLAG = "Y";
    public static final String PROFILES = "profiles";
    public static final String OPERATIVE = "Operative";
    public static final String INDIA = "IN";
    public static final String NRE = "N";
    public static final String NRO = "O";
    public static final String ACCOUNT_STATUS = "8";
    public static final String PASSPORT_DATE_EXPIRE = "45";
    public static final String MEMO_SEVERITY = "H";
    public static final String POST_CUSTOMER_VALIDATOR = "postCustomerValidator";
    public static final String POST_SIGNATURE_VALIDATION ="postSignatureValidator" ;
    public static final String KYC_VALIDATION ="kycValidator" ;
    public static final String POST_FACTIVA_VALIDATOR = "postFactivaValidator";
    public static final String POST_UCIC_VALIDATOR = "postUcicValidator";
    public static final String DEDUPE_SUCCESS = "201";
    public static final String DEDUPE_FAILURE = "200";
    public static final String ZERO = "0";


    public static final String UCIC_SUCCESS_201 = "201";
    public static final String UCIC_SUCCESS_200 = "200";
    public static final String UCIC_SUCCESS_222 = "222";
    public static final String TIF = "TIF";
    public static final String PDF = "PDF";
    public static final String ATTACHMENT = "ATTACHMENT";
    public static final String AOF_WITHOUT_ANNEXTURE_PREFIX = "AOF_WITHOUT_ANNEXTURE_";
    public static final String AOF_WITH_ANNEXTURE_PREFIX = "AOF_WITH_ANNEXTURE_";
    public static final String TIF_EXTENSION = ".tif";

    public static final String PDF_EXTENSION = ".pdf";
    public static final String CUSTOMER_AML_AOF_WITH_CRA_TEMPLATE = "document-templates-CRA_AOF_Template.docx";
    public static final String CUSTOMER_AML_AOF_TEMPLATE = "document-templates-AOF_Template.docx";

    public static final String ACCOUNT_STATEMENT_TEMPLATE = "document-templates-ACCOUNT_STATEMENT_Template.docx";
    public static final String ACCOUNT_STATEMENT_PREFIX = "ACCOUNT_STATEMENT_";
    public static final String ACCOUNT_STATEMENT_NO_TRANSACTIONS_FOUND = "No transactions found in the requested period";



    public static final String HIGH = "HIGH";
    public static final String MEDIUM = "MEDIUM";
    public static final String LOW = "LOW";

    public static final String DEBIT = "D";
    public static final String CREDIT = "C";

    public static final DateTimeFormatter DD_MM_YYYY_FORMATTER = DateTimeFormatter.ofPattern("dd/MM/yyyy");

    // AOF Checkbox Values
    public static final String CHECKED = "\u2611";
    public static final String UNCHECKED = "\u2610";

    public static final String NFTF = "NFTF";
    public static final String FTF = "FTF";

    // Journey Paths
    public static final String REVIEW_DETAILS = "review_details";
    public static final String LG_CODE_PATH = "lgCode";
    public static final String MKTG = "MKTG";


    public static final String CUSTOMER_DETAILS = "customer_details";
    public static final String NOMINEE_DETAILS = "nominee_details";
    public static final String EMPLOYMENT_CURRENCY_PATH = "employment.currency";
    public static final String EMPLOYMENT_PEP_PATH = "employment.pep";

    public static final String AOF_PROOF_TAGGING_OTHER = "OTHER";
    public static final String AOF_PROOF_TAGGING_POA = "POA";

    public static final String EMPLOYMENT_OCCUPATION_PATH = "employment.occupation";
    public static final String EMPLOYMENT_OCCUPATION_SINCE_PATH = "employment.employedSince";
    public static final String EMPLOYMENT_INDUSTRY_PATH = "employment.industry";
    public static final String EMPLOYMENT_INDUSTRY_VARIATION_PATH = "employment.industryVariation";
    public static final String EMPLOYMENT_MONTHLY_AMOUNT_PATH = "employment.monthlyAmount";
    public static final String EMPLOYMENT_QUALIFICATION_PATH = "employment.qualification.type";
    public static final String EMPLOYMENT_SOURCE_OF_INCOME_PATH = "employment.sourceOfIncome";
    public static final String EMPLOYMENT_PURPOSE_OF_ACCOUNT_PATH = "employment.purposeOfAccount";


    public static final String EMPLOYMENT_ANNUAL_INCOME_PATH = "employment.annualIncome";
    public static final String EMPLOYMENT_NET_WORTH_PATH = "employment.netWorth";
    public static final String EMPLOYMENT_MONTHLY_TRANSACTION_PATH = "employment.monthlyTransactions";
    public static final String EMPLOYMENT_PIN_CODE_PATH = "employment.employerPinCode";

    public static final String EMPLOYMENT_EMPLOYER_NAME_PATH = "employment.employerBusinessName";
    public static final String EMPLOYMENT_EMPLOYER_ADDRESS1_PATH = "employment.employerAddress1";
    public static final String EMPLOYMENT_EMPLOYER_ADDRESS2_PATH = "employment.employerAddress2";
    public static final String EMPLOYMENT_EMPLOYER_ADDRESS3_PATH = "employment.employerAddress3";
    public static final String EMPLOYMENT_EMPLOYER_ADDRESS4_PATH = "employment.employerAddress4";
    public static final String EMPLOYMENT_EMPLOYER_PIN_CODE = "employment.employerPinCode";
    public static final String EMPLOYMENT_DESIGNATION_PATH = "employment.designation";
    public static final String EMPLOYMENT_SPECIALISATION_PATH = "employment.specialisation";
    public static final String EMPLOYMENT_WORK_EXPERIENCE_PATH = "employment.workExperience";

    public static final String FATCA_SPOUSE_NAME_PATH = "fatca.spouseName";
    public static final String FATCA_RESIDENCE_TYPE_PATH = "fatca.residenceType.type";

    public static final String PEP_PATH = "employment.pep";

    public static final String NOMINEE_NAME_PATH = "nomineeDetail.nominee.name";
    public static final String NOMINEE_ADDRESS_FROM_PROFILE_PATH = "nomineeDetail.nominee.addressFromProfile";
    public static final String NOMINEE_NO_NOMINEE_PATH = "nomineeDetail.noNominee";
    public static final String NOMINEE_ADDRESS1_PATH = "nomineeDetail.nominee.addressLine1";
    public static final String NOMINEE_ADDRESS2_PATH = "nomineeDetail.nominee.addressLine2";
    public static final String NOMINEE_ADDRESS3_PATH = "nomineeDetail.nominee.addressLine3";
    public static final String NOMINEE_ADDRESS4_PATH = "nomineeDetail.nominee.addressLine4";
    public static final String NOMINEE_CITY_PATH = "nomineeDetail.nominee.city";
    public static final String NOMINEE_STATE_PATH = "nomineeDetail.nominee.state";
    public static final String NOMINEE_COUNTRY_PATH = "nomineeDetail.nominee.country";
    public static final String NOMINEE_PINCODE_PATH = "nomineeDetail.nominee.pincode";
    public static final String NOMINEE_MOBILE_PATH = "nomineeDetail.nominee.mobileNumber";
    public static final String NOMINEE_EMAIL_PATH = "nomineeDetail.nominee.emailId";
    public static final String NOMINEE_RELATION_PATH = "nomineeDetail.nominee.relation";
    public static final String NOMINEE_DOB_PATH = "nomineeDetail.nominee.dob";

    public static final String GUARDIAN_NAME_PATH = "nomineeDetail.guardian.name";
    public static final String GUARDIAN_ADDRESS_SAME_AS_NOMINEE_PATH = "nomineeDetail.guardian.addressSameAsNominee";
    public static final String GUARDIAN_ADDRESS1_PATH = "nomineeDetail.guardian.addressLine1";
    public static final String GUARDIAN_ADDRESS2_PATH = "nomineeDetail.guardian.addressLine2";
    public static final String GUARDIAN_ADDRESS3_PATH = "nomineeDetail.guardian.addressLine3";
    public static final String GUARDIAN_ADDRESS4_PATH = "nomineeDetail.guardian.addressLine4";
    public static final String GUARDIAN_PIN_CODE = "nomineeDetail.guardian.pincode";


    // Gender Values
    public static final String MALE = "M";
    public static final String FEMALE = "F";

    // Marital Status Values
    public static final String SINGLE = "Single";
    public static final String MARRIED = "Married";
    public static final String DIVORCED = "Divorced";
    public static final String SEPARATED = "Separated";
    public static final String WIDOWED = "Widowed";

    // Qualification Values
    public static final String QUALIFICATION_SECONDARY = "Secondary";
    public static final String QUALIFICATION_HIGHER_SECONDARY = "Higher Secondary";
    public static final String QUALIFICATION_GRADUATE = "Graduate";
    public static final String QUALIFICATION_POST_GRADUATE = "Post Graduate";
    public static final String QUALIFICATION_OTHER = "OTHERS";

    // Occupation Values
    public static final String OCCUPATION_SALARIED = "Salaried";
    public static final String OCCUPATION_SELF_EMPLOYED_BUSINESS = "Self Employed/Business";
    public static final String OCCUPATION_HOUSEWIFE = "Housewife";
    public static final String OCCUPATION_PROFESSIONAL = "Professional";
    public static final String OCCUPATION_RETIRED = "Retired";
    public static final String OCCUPATION_STUDENT = "Student";
    public static final String OCCUPATION_OTHER = "OTHERS";

    // Industry Values
    public static final String INDUSTRY_MANUFACTURING = "Manufacturing";
    public static final String INDUSTRY_RETAIL_TRADE = "Retail Trading";
    public static final String INDUSTRY_IMPORT_EXPORT = "Import/Export";
    public static final String INDUSTRY_INFORMATION_TECHNOLOGY = "Information Technology";
    public static final String INDUSTRY_CONSULTANCY = "Consultancy";
    public static final String INDUSTRY_HOTEL_AND_RESTAURANT = "Hotels and Restaurants";
    public static final String INDUSTRY_PUBLIC_SERVICES = "Public Services";
    public static final String INDUSTRY_FINANCE_BANKING_INSURANCE = "Finance / Banking / Insurance";
    public static final String INDUSTRY_OTHER = "Others";

    // Source Of Income
    public static final String SOURCE_EARNING_FROM_WORK = "Earning from Work";
    public static final String SOURCE_EARNING_FROM_BUSINESS = "Earning from Business";
    public static final String SOURCE_INHERITANCE = "Inheritance";
    public static final String SOURCE_INVESTMENT = "Investment";
    public static final String SOURCE_SALE_OF_AN_ASSET = "Sale of an Asset";
    public static final String SOURCE_LOTTERY = "Winning lottery/Prize Money";
    public static final String SOURCE_EARNING_FROM_SPOUSE_FAMILY = "Earning from Spouse/Family";



    // Residence Type
    public static final String RESIDENCE_OWNED = "Owned";
    public static final String RESIDENCE_RENTED_LEASED = "Rented/Leased";
    public static final String RESIDENCE_ANCESTRAL_FAMILY = "Family owned";
    public static final String RESIDENCE_COMPANY = "Company provided";
    public static final String RESIDENCE_OTHER = "OTHERS";

    // Purpose Of Account
    public static final String PURPOSE_OFFSHORE_DEPOSIT = "Offshore Deposit";
    public static final String PURPOSE_INVESTMENT = "Investment";
    public static final String PURPOSE_APPLY_FOR_LOAN = "Applying for Loan";
    public static final String PURPOSE_OTHER = "OTHERS";

    // Currency Values
    public static final String USD = "USD";
    public static final String GBP = "GBP";
    public static final String EUR = "EUR";
    public static final String AUD = "AUD";
    public static final String CAD = "CAD";
    public static final String OTHER = "OTHERS";

    public static final String PEP_YES = "Yes";
    public static final String PEP_NO = "No";

    public static final String TITLE_MR = "Mr";
    public static final String TITLE_MS = "Ms";
    public static final String TITLE_DR = "Dr";
    public static final String TITLE_OTHER = "OTHERS";

    public static final String FATCA_MARITAL_STATUS_PATH = "fatca.maritalStatus.status";

    // DOCREF
    public static final String ACCOUNT_STATEMENT1_DOC_REF = "accountStatement1DocRef";
    public static final String ACCOUNT_STATEMENT2_DOC_REF = "accountStatement2DocRef";
    public static final String CUSTOMER_SIGNATURE_DOC_REF = "customerSignatureDocRef";
    public static final String AOF_WITH_ANNEXTURE_DOC_REF = "aofWithAnnextureDocRef";
    public static final String PERMANENT = "PERMANENT";
    public static final String SALARIED = "Salaried";
    public static final String SELF_EMPLOYED = "Self Employed/Business";
    public static final String FATCA = "fatca";
    public static final String EMPLOYMENT = "employment";
    public static final String YES = "YES";
    public static final String NO = "NO";

    // added a private constructor to hide the implicit public one from sonar issues
    private CustomerConstants() {
    }

}
