package com.hdfcbank.giftcity.bff.application.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hdfcbank.giftcity.bff.application.events.BackgroundEvents;
import com.hdfcbank.giftcity.bff.application.events.SqsBackgroundTaskEvent;
import com.hdfcbank.giftcity.bff.commons.utility.TextSanityUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import software.amazon.awssdk.services.sqs.SqsClient;
import software.amazon.awssdk.services.sqs.model.MessageAttributeValue;
import software.amazon.awssdk.services.sqs.model.SendMessageResponse;

import java.util.Map;

import static com.hdfcbank.common.models.constant.CommonConstants.JOURNEY_ID;


@Component
@Slf4j
@RequiredArgsConstructor
public class BackgroundEventPublisherService {

    private final ObjectMapper objectMapper;
    private final SqsClient backgroundTasksSqsClient;

    @Value("${api.background-tasks-fifo.queueUrl}")
    private String backgroundTasksQueue;

    public void sendBackgroundEvent(String journeyId, String customerId, BackgroundEvents event, Map<String, Object> properties) {
        try {
            SqsBackgroundTaskEvent sqsBackgroundTaskEvent = SqsBackgroundTaskEvent.builder()
                    .journeyId(journeyId)
                    .event(event)
                    .properties(properties)
                    .build();
            String message = objectMapper.writeValueAsString(sqsBackgroundTaskEvent);
            log.info("Preparing to send message to SQS. Message body: {}", TextSanityUtil.sanitize(message));

            software.amazon.awssdk.services.sqs.model.SendMessageRequest sendMessageRequest = software.amazon.awssdk.services.sqs.model.SendMessageRequest.builder()
                    .queueUrl(backgroundTasksQueue)
                    .messageBody(message)
                    .messageAttributes(Map.of(
                            JOURNEY_ID,
                            MessageAttributeValue.builder()
                                    .dataType("String")
                                    .stringValue(journeyId)
                                    .build()
                    ))
                    .messageGroupId(journeyId + "-" + customerId)
                    .messageDeduplicationId(journeyId + "-" + event.name())
                    .build();

            SendMessageResponse response = backgroundTasksSqsClient.sendMessage(sendMessageRequest);
            log.info("Message sent to queue: {}, messageId: {}, MD5: {}",
                    TextSanityUtil.sanitize(backgroundTasksQueue),
                    TextSanityUtil.sanitize(response.messageId()),
                    TextSanityUtil.sanitize(response.md5OfMessageBody())
            );
        } catch (Exception e) {
            log.error("Error sending customer submit message to SQS queue {}", backgroundTasksQueue, e);
        }
    }

}
