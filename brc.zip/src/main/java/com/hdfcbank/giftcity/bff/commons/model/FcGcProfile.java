package com.hdfcbank.giftcity.bff.commons.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.hdfcbank.common.models.vo.core.ApiResponse;
import lombok.*;
import lombok.experimental.SuperBuilder;

import java.util.List;

@Getter
@Setter
@ToString
@SuperBuilder
@NoArgsConstructor
public class FcGcProfile extends ApiResponse<FcGcProfile> {

    @JsonProperty("ETB")
    private String etb;
    @JsonProperty("customerID")
    private String customerId;
    private String accountNumber;
    private String accountStatus;
    private String customerNumber;
    private String customerSignatureDocRef;
    private List<String> linkedAccounts;
    private List<CustomerParam> custParams;

    @Getter
    @Setter
    @ToString
    @AllArgsConstructor
    @NoArgsConstructor
    @Builder
    public static class CustomerParam {
        private String paramName;
        private String paramValue;
    }
}
