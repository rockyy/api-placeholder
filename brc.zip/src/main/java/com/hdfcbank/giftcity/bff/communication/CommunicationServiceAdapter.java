package com.hdfcbank.giftcity.bff.communication;


import com.hdfcbank.adapters.clients.feign.communication.CommunicationFeignClient;
import com.hdfcbank.adapters.vo.GenerateOtpRequest;
import com.hdfcbank.adapters.vo.GenerateOtpResponse;
import com.hdfcbank.adapters.vo.VerifyOtpRequest;
import com.hdfcbank.adapters.vo.VerifyOtpResponse;
import com.hdfcbank.giftcity.bff.commons.enums.CommonJourneyStates;
import com.hdfcbank.giftcity.bff.commons.exception.OTPValidationException;
import com.hdfcbank.giftcity.bff.commons.utility.TextSanityUtil;
import com.hdfcbank.giftcity.bff.customer.model.OtpApiStatusCode;
import com.hdfcbank.giftcity.bff.infrastructure.service.JourneyService;
import feign.FeignException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;


@Service
@Slf4j
@RequiredArgsConstructor
public class CommunicationServiceAdapter {

    private final JourneyService journeyService;
    private final CommunicationFeignClient communicationFeignClient;

    public GenerateOtpResponse sendCommunication(GenerateOtpRequest generateOtpRequest, String journeyId, boolean isResend) {
        if (isResend) {
            journeyService.recordJourneyState(journeyId, CommonJourneyStates.RESEND_OTP_SEND_INITIATED);
        } else {
            journeyService.recordJourneyState(journeyId, CommonJourneyStates.OTP_SEND_INITIATED);
        }
        try {
            GenerateOtpResponse response = communicationFeignClient.sendOtp(generateOtpRequest,journeyId);

            if (response == null) {
                recordFailureState(journeyId, isResend);

                throw new OTPValidationException(OtpApiStatusCode.SOA_INVALID_RESPONSE);
            }

            return response;

        } catch (FeignException ex) {
            log.info("sendCommunication FeignException error", ex);
            recordFailureState(journeyId, isResend);

            log.error("Communication Service error. statusCode:{} responseBody:{}", ex.status(), TextSanityUtil.sanitize(ex.contentUTF8()));


            throw new OTPValidationException(OtpApiStatusCode.COMMUNICATION_SERVICE_ERROR, ex);

        } catch (Exception ex) {
            log.info("sendCommunication Exception error", ex);
            recordFailureState(journeyId, isResend);

            log.error("Unexpected exception while calling Communication Service", ex);

            throw new OTPValidationException(OtpApiStatusCode.OTP_FAILED, ex);
        }
    }


    private void recordFailureState(String journeyId, boolean isResend) {
        if (isResend) {
            journeyService.recordJourneyState(journeyId, CommonJourneyStates.OTP_RESEND_FAILURE);
        } else {
            journeyService.recordJourneyState(journeyId, CommonJourneyStates.OTP_GENERATE_FAILURE);
        }
    }

    public VerifyOtpResponse verifyOtp(VerifyOtpRequest verifyOtpRequest, String journeyId) {
        log.info("checking journey id {}", TextSanityUtil.sanitize(journeyId));
        journeyService.recordJourneyState(journeyId, CommonJourneyStates.VALIDATE_OTP_INITIATED);
        log.info("inside validatr OTP adapter for connection established ");
        try {
            VerifyOtpResponse response = communicationFeignClient.verifyOtp(verifyOtpRequest,journeyId);

            if (response == null) {
                log.info("error coming in communicationFeignClient");
                journeyService.recordJourneyState(journeyId, CommonJourneyStates.OTP_VALIDATE_FAILURE);
                throw new OTPValidationException(OtpApiStatusCode.SOA_INVALID_RESPONSE);
            }

                return response;

        } catch (FeignException ex) {
            journeyService.recordJourneyState(journeyId, CommonJourneyStates.OTP_VALIDATE_FAILURE);

            log.error("Feign error while calling communication service. statusCode:{} body:{}", ex.status(), TextSanityUtil.sanitize(ex.contentUTF8()), ex);

            throw new OTPValidationException(OtpApiStatusCode.VERIFY_OTP_FAILED, ex);

        } catch (Exception ex) {
            journeyService.recordJourneyState(journeyId, CommonJourneyStates.OTP_VALIDATE_FAILURE);
            log.error("Unexpected error while calling communication service", ex);
            throw new OTPValidationException(OtpApiStatusCode.VERIFY_OTP_FAILED, ex);
        }
    }

}
