package com.hdfcbank.giftcity.bff.commons.config;

import lombok.extern.slf4j.Slf4j;
import org.springframework.core.convert.converter.Converter;
import org.springframework.data.convert.ReadingConverter;
import org.springframework.stereotype.Component;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

@ReadingConverter
@Component
@Slf4j
public class StringToDateConverter implements Converter<String, Date> {

    private static final String FORMAT_ISO_MILLIS_TZ = "yyyy-MM-dd'T'HH:mm:ss.SSSX";
    private static final String FORMAT_ISO_TZ = "yyyy-MM-dd'T'HH:mm:ssX";
    private static final String FORMAT_SPACE_SEPARATED = "yyyy-MM-dd HH:mm:ss";
    private static final String FORMAT_DATE_ONLY = "yyyy-MM-dd";
    private static final String ISO_DATE_PREFIX = "ISODate(";
    private static final String ISO_DATE_SUFFIX = ")";

    private final ThreadLocal<SimpleDateFormat[]> threadLocalFormats = ThreadLocal.withInitial(() -> new SimpleDateFormat[]{
            new SimpleDateFormat(FORMAT_ISO_MILLIS_TZ),
            new SimpleDateFormat(FORMAT_ISO_TZ),
            new SimpleDateFormat(FORMAT_SPACE_SEPARATED),
            new SimpleDateFormat(FORMAT_DATE_ONLY)
    });

    @Override
    public Date convert(String source) {
        if (source == null || source.trim().isEmpty()) {
            throw new IllegalArgumentException("Input date string is null or empty");
        }

        String normalizedSource = normalizeSource(source);

        try {
            for (SimpleDateFormat format : threadLocalFormats.get()) {
                try {
                    return format.parse(normalizedSource);
                } catch (ParseException e) {
                    log.error("Failed to parse date '{}' with format '{}'", normalizedSource, format.toPattern());
                }
            }
        } finally {
            threadLocalFormats.remove();
        }

        throw new IllegalArgumentException("Unparseable date string: " + source);
    }

    private String normalizeSource(String source) {
        source = source.trim();

        if (source.startsWith(ISO_DATE_PREFIX) && source.endsWith(ISO_DATE_SUFFIX)) {
            source = source.substring(ISO_DATE_PREFIX.length(), source.length() - ISO_DATE_SUFFIX.length());
            source = source.replace("\"", "");
        }

        return source;
    }
}



