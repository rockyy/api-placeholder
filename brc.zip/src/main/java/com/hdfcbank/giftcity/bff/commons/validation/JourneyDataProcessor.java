package com.hdfcbank.giftcity.bff.commons.validation;

import com.hdfcbank.giftcity.bff.customer.model.IdentifyCustomerRequest;
import com.hdfcbank.service.adapters.vo.customer.FetchCasaResponse;
import com.hdfcbank.service.adapters.vo.customer.IdentifyGCCustomerResponse;

public interface JourneyDataProcessor {
    void validate(FetchCasaResponse.Profile profile, String journeyId);

    void validateCustomerEligibility(String journeyId,FetchCasaResponse.Profile profile);

    void validateEtbCustomer(IdentifyGCCustomerResponse gcResponse, String journeyId);

    void validateRequest(IdentifyCustomerRequest request, String journeyId);
}

