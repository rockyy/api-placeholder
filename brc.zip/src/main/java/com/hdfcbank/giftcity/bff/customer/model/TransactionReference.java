package com.hdfcbank.giftcity.bff.customer.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.SuperBuilder;

@Getter
@Setter
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class TransactionReference {
    private String mobileNumber;
    private String dob;
    private String generateOtpTxnRef;
}
