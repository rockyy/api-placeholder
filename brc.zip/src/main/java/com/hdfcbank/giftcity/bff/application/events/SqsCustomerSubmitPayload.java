package com.hdfcbank.giftcity.bff.application.events;

import lombok.*;

import java.util.Map;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SqsCustomerSubmitPayload {

    private String journeyId;
    private Map<String,Object> properties;
}
