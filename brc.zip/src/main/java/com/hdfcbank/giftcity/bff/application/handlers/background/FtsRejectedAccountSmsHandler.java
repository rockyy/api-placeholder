package com.hdfcbank.giftcity.bff.application.handlers.background;

import com.hdfcbank.adapters.clients.feign.communication.CommunicationFeignClient;
import com.hdfcbank.adapters.vo.AlertMessageResponse;
import com.hdfcbank.adapters.vo.SendMessageRequest;
import com.hdfcbank.adapters.vo.TargetSystemType;
import com.hdfcbank.common.models.vo.journey.JourneyData;
import com.hdfcbank.giftcity.bff.commons.enums.CommonJourneyStates;
import com.hdfcbank.giftcity.bff.commons.exception.handler.DownstreamResponseHandler;
import com.hdfcbank.giftcity.bff.commons.handler.Handler;
import com.hdfcbank.giftcity.bff.commons.handler.HandlerContext;
import com.hdfcbank.giftcity.bff.commons.handler.HandlerResult;
import com.hdfcbank.giftcity.bff.commons.utility.TextSanityUtil;
import com.hdfcbank.giftcity.bff.customer.config.CustomerApiProperties;
import com.hdfcbank.giftcity.bff.customer.utility.CustomerUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import static com.hdfcbank.giftcity.bff.commons.constant.CommonConstants.SMS_TEMPLATE;
import static com.hdfcbank.giftcity.bff.commons.enums.CommonJourneyStates.*;

@Slf4j
@Service
@RequiredArgsConstructor
public class FtsRejectedAccountSmsHandler implements Handler<AlertMessageResponse> {

    private final CommunicationFeignClient communicationFeignClient;

    private static final String SUCCESS = "0000";

    @Override
    public boolean preConditions(HandlerContext handlerContext) {
        return true;
    }

    @Override
    public HandlerResult<AlertMessageResponse> handle(HandlerContext handlerContext) {

        log.info("inside FTS account rejection SMS alert handler ");

        JourneyData journeyData = handlerContext.getJourneyData();

        try {

            String smsTemplateId = (String) handlerContext.getProperties().get(SMS_TEMPLATE);
            String journeyId = journeyData.getJourneyId();
            log.info("getting sms template is {}", TextSanityUtil.sanitize(smsTemplateId));

            SendMessageRequest smsRequest =
                    CustomerUtil.sanitizeSendMessageRequest(
                            journeyData,
                            smsTemplateId);

            log.info("before getting call to sendAlertMsg ");

            AlertMessageResponse response = communicationFeignClient.sendAlertMsg(smsRequest,journeyId);

            log.info("before getting call to sendAlertMsg ");

            if (response != null && response.getStatus() != null && SUCCESS.equals(response.getStatus().getCode())) {

                return HandlerResult.of(null, response, true);
            }

            return HandlerResult.of(DownstreamResponseHandler.handleResponse(response, HandlerName.FTS_REJECT_CALLBACK_SMS.name(), false, journeyData.getJourneyName()), response, false);

        } catch (Exception ex) {

            log.error("Error while sending AOF pending SMS", ex);

            return HandlerResult.<AlertMessageResponse>of(DownstreamResponseHandler.handleResponse(null, HandlerName.FTS_REJECT_CALLBACK_SMS.name(), false, journeyData.getJourneyName()), null, false);
        }
    }


    @Override
    public Handler.HandlerType getType() {
        return HandlerType.BACKGROUND_TASKS_POST_SUBMIT_SUCCESS;
    }

    @Override
    public HandlerName getName() {
        return HandlerName.FTS_REJECT_CALLBACK_SMS;
    }

    @Override
    public CommonJourneyStates successState() {
        return FTS_REJECT_CALLBACK_SMS_ALERT_SUCCESS;
    }

    @Override
    public CommonJourneyStates failureState() {
        return FTS_REJECT_CALLBACK_SMS_ALERT_FAILURE;
    }
}
