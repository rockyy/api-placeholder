package com.hdfcbank.giftcity.bff.commons.validation;

import com.hdfcbank.giftcity.bff.commons.enums.CommonJourneyStates;
import com.hdfcbank.giftcity.bff.commons.model.CustomValidationStatus;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;

@Getter
@AllArgsConstructor(staticName = "of")
public class ValidationResult {
    CustomValidationStatus apiResponseStatus;
    private boolean success;
}
