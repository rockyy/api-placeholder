package com.hdfcbank.giftcity.bff.commons.validation;

import com.hdfcbank.giftcity.bff.commons.enums.CommonJourneyStates;

import java.util.Optional;

public interface Validator {
    Optional<ValidationResult> validate(ValidatorContext context);
    ValidatorType type();
    String name();
    CommonJourneyStates successState();
    CommonJourneyStates failureState();
    boolean isMandatory();
}

