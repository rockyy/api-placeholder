package com.hdfcbank.giftcity.bff.callback.model;


import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.*;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class FtsCallbackPageData {

    private  String barCode;
    private  String statusCode;
    private  String statusDesc;
}
