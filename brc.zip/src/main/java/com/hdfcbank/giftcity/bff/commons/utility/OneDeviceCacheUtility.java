package com.hdfcbank.giftcity.bff.commons.utility;

import com.hdfcbank.giftcity.bff.commons.exception.LimitExceededException;
import com.hdfcbank.giftcity.bff.customer.model.CustomerApiStatusCode;
import com.hdfcbank.starter.logging.annotations.Loggable;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Component;

import java.io.Serializable;
import java.time.ZonedDateTime;


@Component
@Slf4j
public class OneDeviceCacheUtility {
    @Loggable
    @Cacheable(cacheNames = {"oneDeviceOneLogin"}, key = "{#mobileNumber,#journeyName}")
    public OneDeviceOneLoginDetail deviceLoggedIn(String mobileNumber, String dob, String journeyName, String accessToken, ZonedDateTime dateTime) {
        log.info("oneDeviceOneLogin cache maintained for journey name: {}", TextSanityUtil.sanitize(journeyName));
        return new OneDeviceOneLoginDetail(dateTime, accessToken);
    }

    @Loggable
    @CacheEvict(cacheNames = {"oneDeviceOneLogin"}, key = "{#mobileNumber,#journeyName}")
    public void cleanDeviceLoggedIn(String mobileNumber, String dob, String journeyName) {
        log.info("oneDeviceOneLogin cache cleared for journey name: {}", TextSanityUtil.sanitize(journeyName));
    }

    public void validateDevice(OneDeviceOneLoginDetail oneDeviceOneLoginDetail, ZonedDateTime currentTime, String authorization) {
        if (!currentTime.equals(oneDeviceOneLoginDetail.getDateTime()) && !oneDeviceOneLoginDetail.accessToken.equals(authorization))
            throw new LimitExceededException(CustomerApiStatusCode.DUPLICATE_SESSION, "Duplicate Session");
    }


    @Getter
    @Setter
    @AllArgsConstructor
    public static class OneDeviceOneLoginDetail implements Serializable {
        private ZonedDateTime dateTime;
        private String accessToken;
    }

}

