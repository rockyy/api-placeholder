package com.hdfcbank.giftcity.bff.commons.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.hdfcbank.common.models.vo.core.ApiResponse;
import com.hdfcbank.common.models.vo.core.ApiResponseStatus;
import com.hdfcbank.common.models.vo.core.ApiResponseStatusCodeLiteral;
import com.hdfcbank.common.models.vo.core.ErrorRef;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.SuperBuilder;

import java.util.List;


@Getter
@Setter
@SuperBuilder
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class InspireApiResponse<T> extends ApiResponse<T> {


    /**
     * 🔑 CRITICAL OVERRIDE
     * Ensures subclass fields (title, type) are preserved
     */
    @Override
    public CustomValidationStatus getStatus() {
        ApiResponseStatus baseStatus = super.getStatus();

        if (baseStatus == null) {
            return null;
        }

        if (baseStatus instanceof CustomValidationStatus) {
            return (CustomValidationStatus) baseStatus;
        }

        return CustomValidationStatus.build(baseStatus);
    }

    public void setStatus(CustomValidationStatus status) {
        super.setStatus(status);
    }

    public static <T> InspireApiResponse<T> customValidationError(ApiResponseStatusCodeLiteral code, String errorRef,
                                                                  String title, List<String> errors) {
        CustomValidationStatus customValidationStatus = CustomValidationStatus.builder()
                .title(title)
                .build();
        customValidationStatus.setCode(code.getCode());
        customValidationStatus.setErrors(errors);
        customValidationStatus.setMessage(code.getMessage());
        customValidationStatus.setErrorRef(errorRef);
        return InspireApiResponse.<T>builder().status(customValidationStatus).build();
    }
}