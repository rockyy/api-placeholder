package com.hdfcbank.giftcity.bff.master.mapper;

import com.hdfcbank.adapters.vo.FetchMasterDataRequest;
import com.hdfcbank.giftcity.bff.master.models.MasterDataFetchRequest;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface MasterDataMapper {
    FetchMasterDataRequest toFetchMasterDataRequest(MasterDataFetchRequest request);
}
