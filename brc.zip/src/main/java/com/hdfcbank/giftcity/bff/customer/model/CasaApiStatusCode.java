package com.hdfcbank.giftcity.bff.customer.model;

import com.hdfcbank.common.models.vo.core.ApiResponseStatusCodeLiteral;
import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum CasaApiStatusCode implements ApiResponseStatusCodeLiteral {
    SUCCESS("0000", "Success"),
    INVALID_REQUEST("8000", "Invalid Request"),
    NO_EXISTING_CUSTOMER("8001", "No Existing Customer Found"),
    NO_ELIGIBLE_CUSTOMER("8002", "No Eligible Customer Found"),
    INTERNAL_SERVER_ERROR("9000", "Internal server error"),
    DOWNSTREAM_ERROR("9002", "Downstream api error"),
    FAILED("9003","FAILED"),
    REKYC_NON_COMPLIANT_CUSTOMER("9005", "As your KYC is not complete"),
    FC_DATA_NOT_AVAILABLE("9006", "Please connect with the nearest branch to buy the policy.");




    private final String code;
    private final String message;

    public static CasaApiStatusCode getCustomerApiStatus(String statusCode) {
        for (CasaApiStatusCode apiStatusCode : values()) {
            if (apiStatusCode.getCode().equals(statusCode)) {
                return apiStatusCode;
            }

        }
        return FAILED;
    }
}
