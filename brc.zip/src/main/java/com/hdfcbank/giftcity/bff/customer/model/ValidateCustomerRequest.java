package com.hdfcbank.giftcity.bff.customer.model;

import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.*;

import java.util.List;

@Getter
@Setter
@ToString
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ValidateCustomerRequest {
    @NotEmpty
    @Pattern(regexp = "[0-9]{6}", message = "invalid otp value")
    private String otp;

    @NotEmpty(message = "txnRef cannot be empty")
    @Size(max = 255)
    private String txnRef;

    @NonNull
    private List<CustomerConsentRequest> consents;
}
