package com.hdfcbank.giftcity.bff.commons.utility;

import com.hdfcbank.giftcity.bff.commons.model.CustomValidationStatus;
import com.hdfcbank.giftcity.bff.commons.properties.CustomValidationProperties;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Locale;
import java.util.Optional;

@Component
@RequiredArgsConstructor
public class ValidationHelper {

    private final CustomValidationProperties customValidationProperties;

    /**
     *     REFACTORED: Cognitive Complexity reduced
     * Extracted validateNonNullValue() and early-return structure.
     * Original logic preserved exactly.
     */
    public CustomValidationProperties.FieldDetail validateData(
            String type,
            String value,
            CustomValidationProperties customValidationProperties,
            String journeyName) {

        //     Extracted first part unchanged.
        Optional<CustomValidationProperties.FieldDetail> fieldDetailOptional =
                customValidationProperties.getJourneys()
                        .get(journeyName)
                        .getFieldsDetail()
                        .stream()
                        .filter(fd -> fd.getType().equals(type))
                        .findFirst();

        if (fieldDetailOptional.isEmpty()) {
            return null; //     Early exit
        }

        CustomValidationProperties.FieldDetail fieldDetail = fieldDetailOptional.get();

        //     Mandatory + empty value check (unchanged)
        if (fieldDetail.isMandatory() && StringUtils.isEmpty(value)) {
            return fieldDetail;
        }

        //     If value is null, no further checks needed
        if (value == null) {
            return null;
        }

        //     Extracted nested validation logic into helper
        return validateNonNullValue(fieldDetail, value);
    }

    /**
     *     NEW METHOD (Refactoring): Extracted from validateData()
     * This reduces nested conditions and Sonar cognitive complexity.
     * Original validation logic preserved fully.
     */
    private CustomValidationProperties.FieldDetail validateNonNullValue(
            CustomValidationProperties.FieldDetail fieldDetail,
            String value) {

        String lowerValue = value.toLowerCase(Locale.ROOT);

        //     allowedValues check
        if (fieldDetail.getAllowedValues() != null &&
                !fieldDetail.getAllowedValues().contains(lowerValue)) {
            return fieldDetail;
        }

        //     notAllowedValues check
        if (fieldDetail.getNotAllowedValues() != null &&
                fieldDetail.getNotAllowedValues().contains(lowerValue)) {
            return fieldDetail;
        }

        //     max length check
        if (value.length() > fieldDetail.getLength()) {
            return fieldDetail;
        }

        //     regex validation
        String regex = fieldDetail.getAllowedRegex();
        if (regex != null && !value.matches(regex)) {
            return fieldDetail;
        }

        return null;
    }

    public CustomValidationStatus getErrors(
            String journeyName,
            List<CustomValidationProperties.FieldDetail> fieldDetails,
            CustomValidationProperties customValidationProperties) {

        if (fieldDetails.isEmpty()) {
            return CustomValidationStatus.builder().build();
        }

        CustomValidationProperties.CustomValidations journeyConfig =
                customValidationProperties.getJourneys().get(journeyName);

        String defaultMessage = journeyConfig.getDefaultMessage();
        String defaultMessageHeading = journeyConfig.getDefaultMessageHeading();

        List<String> errors = fieldDetails.stream()
                .map(fd -> StringUtils.defaultString(fd.getMessage()))
                .toList();

        CustomValidationProperties.FieldDetail field = fieldDetails.get(0);

        CustomValidationStatus customValidationStatus = CustomValidationStatus.builder()
                .title(field.getMessageHeading() == null ? defaultMessageHeading : field.getMessageHeading())
                .type(field.getType())
                .build();

        customValidationStatus.setCode(field.getCode());
        customValidationStatus.setErrors(errors);
        customValidationStatus.setMessage(
                field.getMessage() == null ? defaultMessage : field.getMessage());

        return customValidationStatus;
    }

    public CustomValidationProperties.FieldDetail validateRange(
            String type,
            Integer value,
            String journeyName) {

        Optional<CustomValidationProperties.FieldDetail> fieldDetailOptional =
                customValidationProperties.getJourneys()
                        .get(journeyName)
                        .getFieldsDetail()
                        .stream()
                        .filter(fd -> fd.getType().equals(type))
                        .findFirst();

        if (fieldDetailOptional.isEmpty()) {
            return null;
        }

        CustomValidationProperties.FieldDetail field = fieldDetailOptional.get();

        if (field.isMandatory() && value == null) {
            return field;
        }

        if (value != null) {

            if (field.getMin() > 0 && value < field.getMin()) {
                return field;
            }

            if (field.getMax() > 0 && value > field.getMax()) {
                return field;
            }
        }

        return null;
    }
}