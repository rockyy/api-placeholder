package com.hdfcbank.giftcity.bff.commons.validation;

public enum ValidatorType {
    POST_CUSTOMER_VALIDATION,
    PRE_CUSTOMER_VALIDATION
}
