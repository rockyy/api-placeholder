package com.hdfcbank.giftcity.bff.customer.rmcodes.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Document(collection = "giftcity_rmcodes_master")
public class RmCodesMasterEntity {

    @Id
    private String id;

    @Field("employeecode")
    private String employeeCode;

    @Field("rmportfoliocode")
    private String rmPortfolioCode;

    @Field("employeename")
    private String employeeName;
}