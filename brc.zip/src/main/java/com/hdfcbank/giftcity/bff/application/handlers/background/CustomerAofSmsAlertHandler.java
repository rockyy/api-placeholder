package com.hdfcbank.giftcity.bff.application.handlers.background;

import com.hdfcbank.adapters.clients.feign.communication.CommunicationFeignClient;
import com.hdfcbank.adapters.vo.AlertMessageResponse;
import com.hdfcbank.adapters.vo.SendMessageRequest;
import com.hdfcbank.adapters.vo.TargetSystemType;
import com.hdfcbank.common.models.vo.journey.JourneyData;
import com.hdfcbank.common.models.vo.journey.JourneyState;
import com.hdfcbank.giftcity.bff.commons.enums.CommonJourneyStates;
import com.hdfcbank.giftcity.bff.commons.exception.handler.DownstreamResponseHandler;
import com.hdfcbank.giftcity.bff.commons.handler.Handler;
import com.hdfcbank.giftcity.bff.commons.handler.HandlerContext;
import com.hdfcbank.giftcity.bff.commons.handler.HandlerResult;
import com.hdfcbank.giftcity.bff.commons.model.FcIndiaProfile;
import com.hdfcbank.giftcity.bff.commons.utility.TextSanityUtil;
import com.hdfcbank.giftcity.bff.customer.config.CustomerApiProperties;
import com.hdfcbank.giftcity.bff.customer.utility.CustomerUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;


import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.Map;
import java.util.Optional;

import static com.hdfcbank.giftcity.bff.commons.constant.CommonConstants.SMS_TEMPLATE;
import static com.hdfcbank.giftcity.bff.commons.enums.CommonJourneyStates.*;

@Slf4j
@Service
@RequiredArgsConstructor
public class CustomerAofSmsAlertHandler implements Handler<AlertMessageResponse> {

    private final CommunicationFeignClient communicationFeignClient;
    private final CustomerApiProperties customerApiProperties;
    private static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern("dd-MM-yy");
    private static final String SUCCESS = "0000";
    private static final String SMS = "SMS";
    private static final String APPLICATION_REJECTION_DAYS = "applicationRejectionDays";



    @Override
    public boolean preConditions(HandlerContext handlerContext) {
        return hasJourneyState(handlerContext, FTS_AOF_SUBMIT_SUCCESS.name())
                && !hasJourneyState(handlerContext, FTS_DOCS_RECEIVED_CALLBACK.name());
    }

    @Override
    public HandlerResult<AlertMessageResponse> handle(HandlerContext handlerContext) {

        log.info("inside pending SMS alert handler ");

        JourneyData journeyData = handlerContext.getJourneyData();

        try {

                FcIndiaProfile.Profile fcProfile =
                        CustomerUtil.getPrimaryProfile(journeyData).orElse(null);

                String journeyId = journeyData.getJourneyId();

            String smsTemplateId = (String) handlerContext.getProperties().get(SMS_TEMPLATE);

            Map<String, String> smsServiceDefaults = customerApiProperties.getAofPendingDocumentSmsAlert().getServiceDefaults();

            int rejectionOffsetDays = Integer.parseInt(smsServiceDefaults.get(APPLICATION_REJECTION_DAYS));

            String dateOfRejection = CustomerUtil.getJourneyState(
                            journeyData,
                            String.valueOf(CREATE_APPLICATION_NUMBER_SUCCESS))
                    .map(JourneyState::getCreatedOn)
                    .map(Date::toInstant)
                    .map(instant -> instant.atZone(ZoneId.systemDefault()).toLocalDate())
                    .map(date -> date.plusDays(rejectionOffsetDays))
                    .map(DATE_FORMATTER::format)
                    .orElse(null);

            log.info("getting sms template is {}", TextSanityUtil.sanitize(smsTemplateId));

                SendMessageRequest smsRequest =
                        SendMessageRequest.builder()
                                .messageType(SMS)
                                .channel(SMS)
                                .mobileNumber(journeyData.getIsd().concat(journeyData.getMobileNumber()))
                                .customerName(fcProfile.getName())
                                .targetSystem(TargetSystemType.AXIOM.name())
                                .templateId(smsTemplateId)
                                .emailId(journeyData.getProfile().getEmailId())
                                .dateOfRejection(dateOfRejection)
                                .build();

                log.info("before getting call to sendAlertMsg ");

                AlertMessageResponse response = communicationFeignClient.sendAlertMsg(smsRequest,journeyId);

                log.info("before getting call to sendAlertMsg ");

                if (response != null && response.getStatus() != null && SUCCESS.equals(response.getStatus().getCode())) {

                    return HandlerResult.of(null, response, true);
                }

                return HandlerResult.of(DownstreamResponseHandler.handleResponse(response, HandlerName.AOF_SUBMISSION_SMS_ALERT.name(), false, journeyData.getJourneyName()), response, false);

        } catch (Exception ex) {

            log.error("Error while sending AOF pending SMS", ex);

            return HandlerResult.<AlertMessageResponse>of(DownstreamResponseHandler.handleResponse(null, HandlerName.AOF_SUBMISSION_SMS_ALERT.name(), false, journeyData.getJourneyName()), null, false);
        }
    }


    @Override
    public Handler.HandlerType getType() {
        return HandlerType.BACKGROUND_TASKS_POST_SUBMIT_SUCCESS;
    }

    @Override
    public HandlerName getName() {
        return HandlerName.AOF_SUBMISSION_SMS_ALERT;
    }

    @Override
    public CommonJourneyStates successState() {
        return CUSTOMER_AOF_SUBMISSION_SMS_ALERT_SUCCESS;
    }

    @Override
    public CommonJourneyStates failureState() {
        return CUSTOMER_AOF_SUBMISSION_SMS_ALERT_FAILURE;
    }
}
