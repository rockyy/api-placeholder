package com.hdfcbank.giftcity.bff.customer.config;

import lombok.*;
import lombok.experimental.SuperBuilder;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import java.util.List;

@Getter
@Setter
@Configuration
@ConfigurationProperties("api.masters-fcc-mapping")
public class CreateFccMastersConfig {

    private List<OccupationMapping> occupationMapping;
    private List<OccupationNewMapping> occupationNewMapping;
    private List<IndustryMapping> industryMapping;
    private List<NatureOfBusinessMapping> natureOfBusinessMapping;

    @Getter
    @Setter
    @NoArgsConstructor
    @AllArgsConstructor
    @SuperBuilder
    public static class OccupationMapping {

        private String occupationType;
        private String fccOccupation;
    }

    @Getter
    @Setter
    @NoArgsConstructor
    @AllArgsConstructor
    @SuperBuilder
    public static class OccupationNewMapping {

        private String occupationType;
        private String designation;
        private String fccOccupationNew;
    }

    @Getter
    @Setter
    @NoArgsConstructor
    @AllArgsConstructor
    @SuperBuilder
    public static class IndustryMapping {

        private String industryType;
        private String fccIndustry;
    }

    @Getter
    @Setter
    @NoArgsConstructor
    @AllArgsConstructor
    @SuperBuilder
    public static class NatureOfBusinessMapping {
        private String industryVariation;
        private String natureOfBusiness;
    }

}
