package com.hdfcbank.giftcity.bff.communication;

import com.hdfcbank.adapters.vo.GenerateOtpResponse;
import com.hdfcbank.adapters.vo.VerifyOtpResponse;
import com.hdfcbank.common.models.vo.core.ApiResponseStatus;
import com.hdfcbank.common.models.vo.journey.JourneyData;
import com.hdfcbank.giftcity.bff.commons.config.JourneyContextHolder;
import com.hdfcbank.giftcity.bff.commons.enums.CommonJourneyStates;
import com.hdfcbank.giftcity.bff.commons.model.CustomValidationStatus;
import com.hdfcbank.giftcity.bff.commons.utility.CommonUtil;
import com.hdfcbank.giftcity.bff.consent.service.ConsentService;
import com.hdfcbank.giftcity.bff.customer.model.*;
import com.hdfcbank.giftcity.bff.infrastructure.service.JourneyService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.stream.Collectors;

import static com.hdfcbank.common.models.vo.core.ApiResponseStatusCode.FAILURE;
import static com.hdfcbank.giftcity.bff.commons.enums.CustomCommonApiStatusCodes.SUCCESS;
import static com.hdfcbank.giftcity.bff.customer.model.CustomerApiStatusCode.OTP_EXPIRED;
import static io.lettuce.core.pubsub.PubSubOutput.Type.message;

@Slf4j
@Component
@RequiredArgsConstructor
public class OtpResponseHandler {

    private final JourneyService journeyService;

    private final ConsentService consentService;


    public IdentifyCustomerResponse handleGenerateOtpResponse(
            HandleGenerateOtpResponse request,
            GenerateOtpResponse response,
            String journeyId,
            String email) {

        boolean isRetry = request.isRetry();

        if (SUCCESS.getCode().equals(response.getStatus().getCode())) {

            if (!isRetry) {
                journeyService.updateJourneyState(journeyId, CommonJourneyStates.OTP_GENERATE_SUCCESS.name());
            } else {
                journeyService.updateJourneyState(journeyId, CommonJourneyStates.OTP_RESEND_SUCCESS.name());
            }

            return identifyCustomerResponseBuilder(request, response, journeyId, email);

        } else {
                if (!isRetry) {
                    journeyService.recordJourneyState(journeyId, CommonJourneyStates.OTP_GENERATE_FAILURE);
                } else {
                    journeyService.recordJourneyState(journeyId, CommonJourneyStates.OTP_RESEND_FAILURE);
                }
                return IdentifyCustomerResponse.builder()
                        .status(new ApiResponseStatus(FAILURE))
                        .data(IdentifyCustomerResponse.IdentifyCustomerDetail.builder()
                                .txnRef(null)
                                .journeyId(journeyId)
                                .build())
                        .build();
            }
    }


    public IdentifyCustomerResponse handleGenerateOtpResponse(
            String mobileNumber,
            String dob,
            GenerateOtpResponse response,
            String journeyId,
            boolean isRetry) {

        if (SUCCESS.getCode().equals(response.getStatus().getCode())) {

            if (!isRetry) {
                journeyService.updateJourneyState(journeyId, CommonJourneyStates.OTP_GENERATE_SUCCESS.name());
            } else {
                journeyService.updateJourneyState(journeyId, CommonJourneyStates.OTP_RESEND_SUCCESS.name());
            }
            TransactionReference transactionReference = TransactionReference.builder()
                    .mobileNumber(mobileNumber)
                    .dob(dob)
                    .generateOtpTxnRef(response.getData().getTxnRef())
                    .build();

            String txnRef = transactionReference.getGenerateOtpTxnRef();

            return IdentifyCustomerResponse.builder()
                    .status(new ApiResponseStatus(SUCCESS))
                    .data(IdentifyCustomerResponse.IdentifyCustomerDetail.builder()
                            .txnRef(txnRef)
                            .existingCustomer(true)
                            .journeyId(JourneyContextHolder.getJourneyData().getJourneyId())
                            .correlationId("")
                            .build())
                    .build();
        }
            else {
                if (!isRetry) {
                    journeyService.recordJourneyState(journeyId, CommonJourneyStates.OTP_GENERATE_FAILURE);
                } else {
                    journeyService.recordJourneyState(journeyId, CommonJourneyStates.OTP_GENERATE_FAILURE);
                    log.info("OTP generation failed during retry attempt for journey: {}", journeyId);
                }
                return IdentifyCustomerResponse.builder()
                        .status(new ApiResponseStatus(FAILURE))
                        .data(IdentifyCustomerResponse.IdentifyCustomerDetail.builder()
                                .txnRef(null)
                                .journeyId(journeyId)
                                .correlationId("")
                                .build())
                        .build();
            }
        }

    public ValidateCustomerResponse handleVerifyOtpResponse(ValidateCustomerRequest request, VerifyOtpResponse response, JourneyData journeyData) {

        if (OtpApiStatusCode.SUCCESS.getCode().equals(response.getStatus().getCode())) {

            journeyService.recordJourneyState(journeyData.getJourneyId(), CommonJourneyStates.CUSTOMER_VALIDATED_SUCCESS);

            journeyService.recordJourneyState(journeyData.getJourneyId(), CommonJourneyStates.OTP_VALIDATE_SUCCESS

            );

            List<CustomerConsentRequest> customerConsentRequestList = request.getConsents().stream()
                    .map(data -> CustomerConsentRequest.builder()
                            .key(data.getKey())
                            .acceptance(data.isAcceptance())
                            .build())
                    .collect(Collectors.toList());

            consentService.storeConsentsData(customerConsentRequestList, journeyData);

            return buildResponse(ApiResponseStatus.success(), true, 0);

        }
        if (OtpApiStatusCode.OTP_MISMATCHED.getCode().equals(response.getStatus().getCode())) {
            journeyService.recordJourneyState(journeyData.getJourneyId(), CommonJourneyStates.OTP_VALIDATE_MISMATCH);

            return buildResponse(new ApiResponseStatus(CustomerApiStatusCode.OTP_MISMATCHED), false, 2);
        }

        if (OtpApiStatusCode.OTP_EXPIRED.getCode().equals(response.getStatus().getCode())) {

            CustomValidationStatus customValidationStatus = CustomValidationStatus.builder()
                    .title(OTP_EXPIRED.getMessage())
                    .code(OTP_EXPIRED.getCode())
                    .message(OTP_EXPIRED.getMessage())
                    .build();

            journeyService.updateJourneyDetailDropOff(journeyData, customValidationStatus, CommonJourneyStates.OTP_VALIDATE_EXPIRED);

            return buildResponse(
                    new ApiResponseStatus(OTP_EXPIRED),
                    false,
                    1
            );
        }

        journeyService.recordJourneyState(journeyData.getJourneyId(), CommonJourneyStates.OTP_VALIDATE_FAILURE);

        return buildResponse(
                new ApiResponseStatus(CustomerApiStatusCode.FAILED),
                false);
    }

    private ValidateCustomerResponse buildResponse(ApiResponseStatus status, boolean otpValidated) {
        ValidateCustomerResponse.ValidateCustomerDetail detail = ValidateCustomerResponse.ValidateCustomerDetail.builder()
                .otpValidated(otpValidated).build();
        return ValidateCustomerResponse.builder().status(status).data(detail).build();
    }

    private ValidateCustomerResponse buildResponse(ApiResponseStatus status, boolean otpValidated, int incorrectAttempts) {

        ValidateCustomerResponse.ValidateCustomerDetail detail = ValidateCustomerResponse.ValidateCustomerDetail.builder()
                .otpValidated(otpValidated)
                .incorrectAttempts(incorrectAttempts).build();

        return ValidateCustomerResponse.builder().status(status).data(detail).build();
    }


    public IdentifyCustomerResponse identifyCustomerResponseBuilder(HandleGenerateOtpResponse handleGenerateOtpResponse, GenerateOtpResponse response, String journeyId, String email) {

        TransactionReference transactionReference = TransactionReference.builder()
                .mobileNumber(handleGenerateOtpResponse.getMobileNumber())
                .dob(handleGenerateOtpResponse.getDob())
                .generateOtpTxnRef(response.getData().getTxnRef())
                .build();
        String txnRef = transactionReference.getGenerateOtpTxnRef();
        return IdentifyCustomerResponse.builder()
                .status(new ApiResponseStatus(SUCCESS))
                .data(IdentifyCustomerResponse.IdentifyCustomerDetail.builder()
                        .txnRef(txnRef)
                        .existingCustomer(true)
                        .eligibleAccounts(handleGenerateOtpResponse.getEligibleAccounts())
                        .journeyId(journeyId)
                        .correlationId("")
                        .profile(CustomerProfileResponse.CustomerProfile.builder()
                                .mobileNumber(CommonUtil.maskMobile(handleGenerateOtpResponse.getMobileNumber()))
                                .email(CommonUtil.maskEmail(email, 2, 2)).build())
                        .build())
                .build();
    }
}
