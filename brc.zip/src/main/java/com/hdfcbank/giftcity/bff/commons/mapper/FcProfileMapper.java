package com.hdfcbank.giftcity.bff.commons.mapper;

import com.hdfcbank.giftcity.bff.commons.model.FcGcProfile;
import com.hdfcbank.giftcity.bff.commons.model.FcIndiaProfile;
import com.hdfcbank.giftcity.bff.master.mapper.CountryMapper;
import com.hdfcbank.service.adapters.vo.customer.FetchCasaResponse;
import com.hdfcbank.service.adapters.vo.customer.IdentifyGCCustomerResponse;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import java.util.List;

@Mapper(componentModel = "spring", uses = CountryMapper.class)
public interface FcProfileMapper {


    FcIndiaProfile toFcIndiaProfile(FetchCasaResponse.FetchCasaDetail fetchCasaResponse);

    FcGcProfile toFcGcProfile(IdentifyGCCustomerResponse.GCData identifyGCCustomerResponse);

    @Mapping(target = "country", source = "namPermadrCntry",  qualifiedByName = "masterDataFromCode")
    @Mapping(target = "mailingCountry", source = "mailingCountry",  qualifiedByName = "masterDataFromCode")
    @Mapping(target = "nationality", source = "nationality",  qualifiedByName = "masterDataFromCode")
    FcIndiaProfile.Profile mapProfile(FetchCasaResponse.Profile source);

    List<FcIndiaProfile.Profile> profiles(List<FetchCasaResponse.Profile> source);

    FcIndiaProfile.CustomerAccountDetail mapAccount(FetchCasaResponse.CustomerAccountDetail source);

    List<FcIndiaProfile.CustomerAccountDetail> customerAccountDetails(List<FetchCasaResponse.CustomerAccountDetail> source);

    FcIndiaProfile.CustomerMemoDetail mapMemo(FetchCasaResponse.CustomerMemoDetail source);

    List<FcIndiaProfile.CustomerMemoDetail> customerMemoDetails(List<FetchCasaResponse.CustomerMemoDetail> source);

    FcIndiaProfile.CustomerFATCADetail mapFatca(FetchCasaResponse.CustomerFATCADetail source);

    List<FcIndiaProfile.CustomerFATCADetail> customerFATCADetails(List<FetchCasaResponse.CustomerFATCADetail> source);

    FcIndiaProfile.CustomerAMLDetail mapAml(FetchCasaResponse.CustomerAMLDetail source);

    List<FcIndiaProfile.CustomerAMLDetail> customerAMLDetails(List<FetchCasaResponse.CustomerAMLDetail> source);

}
