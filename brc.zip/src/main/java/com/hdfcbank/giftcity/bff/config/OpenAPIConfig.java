package com.hdfcbank.giftcity.bff.config;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class OpenAPIConfig {

    @Autowired
    private AppProperties appProperties;

    @Bean
    public OpenAPI customOpenAPI() {
        return new OpenAPI()
                .info(new Info()
                        .title(appProperties.getName())
                        .version(appProperties.getVersion())
                        .description(appProperties.getDescription()))
                .servers(appProperties.getServers());
    }
}
