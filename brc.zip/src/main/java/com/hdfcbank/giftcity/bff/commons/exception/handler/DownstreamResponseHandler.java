package com.hdfcbank.giftcity.bff.commons.exception.handler;

import com.hdfcbank.common.models.vo.core.ApiResponse;
import com.hdfcbank.common.models.vo.core.ApiResponseStatus;
import com.hdfcbank.giftcity.bff.commons.config.JourneyConfigProperties;
import com.hdfcbank.giftcity.bff.commons.exception.CustomValidationException;
import com.hdfcbank.giftcity.bff.commons.model.CustomValidationStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Optional;

@Component
public class DownstreamResponseHandler {

    private DownstreamResponseHandler() {
    }

    private static JourneyConfigProperties journeyConfigProperties;
    private static final String UNKNOWN = "UNKNOWN";

    @Autowired
    public static void setErrorMappingProperties(
            JourneyConfigProperties journeyConfigProperties) {

        DownstreamResponseHandler.journeyConfigProperties =
                journeyConfigProperties;
    }

    public static CustomValidationStatus handleResponse(ApiResponse<?> response, String category, Boolean isThrowException, String journeyName) {

        JourneyConfigProperties.JourneyConfig errorConfig =
                journeyConfigProperties.getJourneys().get(journeyName);

        if (errorConfig == null || errorConfig.getErrorMapping() == null) {
            return null;
        }

        String responseCode = Optional.ofNullable(response)
                .map(ApiResponse::getStatus)
                .map(ApiResponseStatus::getCode)
                .orElse(UNKNOWN);

        Optional<JourneyConfigProperties.ErrorMapping> errorMapping =
                errorConfig.getErrorMapping()
                        .stream()
                        .filter(error ->
                                responseCode.equalsIgnoreCase(
                                        error.getDownstreamErrorCode())
                                        && error.getCategory().equalsIgnoreCase(category))
                        .findFirst()
                        .or(() -> errorConfig.getErrorMapping()
                                .stream()
                                .filter(error ->
                                        UNKNOWN.equalsIgnoreCase(error.getCategory()))
                                .findFirst());

        if (errorMapping.isEmpty()) {
            return null;
        }

        JourneyConfigProperties.ErrorMapping error = errorMapping.get();

        CustomValidationStatus customValidationStatus =
                CustomValidationStatus.builder()
                        .code(error.getErrorCode())
                        .message(error.getMessage())
                        .title(error.getMessageHeading())
                        .build();

        customValidationStatus.setErrors(List.of(error.getMessage()));

        if (Boolean.TRUE.equals(isThrowException)) {
            throw new CustomValidationException(customValidationStatus);
        }

        return customValidationStatus;
    }
}
