package com.hdfcbank.giftcity.bff.customer.model;

public class GiftCityIdentifyResponse {
}
