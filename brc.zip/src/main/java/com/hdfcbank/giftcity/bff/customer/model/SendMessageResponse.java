package com.hdfcbank.giftcity.bff.customer.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.hdfcbank.common.models.vo.core.ApiResponse;
import lombok.*;
import lombok.experimental.SuperBuilder;

@Getter
@Setter
@ToString
@NoArgsConstructor
@SuperBuilder
public class SendMessageResponse extends ApiResponse<SendMessageResponse.OtpSendDetail> {


    @Getter
    @Setter
    @SuperBuilder
    @NoArgsConstructor
    @AllArgsConstructor
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class OtpSendDetail {
        private String txnRef;
        private Integer retryOtpAttemptsConsumed;
        private Integer retryOtpAttemptsLeft;
        private Integer verifyOtpAttemptsConsumed;
        private Integer verifyOtpAttemptsLeft;
    }
}
