package com.hdfcbank.giftcity.bff.customer.model;

import com.hdfcbank.common.models.vo.core.ApiResponse;
import lombok.*;
import lombok.experimental.SuperBuilder;


@Getter
@Setter
@ToString
@SuperBuilder
@AllArgsConstructor
public class CustomerProfileResponse extends ApiResponse<CustomerProfileResponse.CustomerProfileDetails> {

    @Getter
    @Setter
    @ToString
    @AllArgsConstructor
    @NoArgsConstructor
    @Builder
    public static class CustomerProfileDetails{

        private CustomerProfile profile;

    }

    @Getter
    @Setter
    @ToString
    @AllArgsConstructor
    @NoArgsConstructor
    @Builder
    public static class CustomerProfile{
        private String email;
        private String mobileNumber;
    }
}
