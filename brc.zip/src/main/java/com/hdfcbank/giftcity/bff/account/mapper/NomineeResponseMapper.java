package com.hdfcbank.giftcity.bff.account.mapper;

import com.hdfcbank.service.adapters.vo.account.NomineeApiResponse;
import com.hdfcbank.common.models.vo.core.ApiResponseStatus;
import com.hdfcbank.giftcity.bff.account.model.NomineeResponse;
import com.hdfcbank.giftcity.bff.commons.enums.CustomCommonApiStatusCodes;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring")
public interface NomineeResponseMapper {

    @Mapping(source = "nomineeRelation", target = "relation")
    @Mapping(source = "datBirth", target = "dateOfBirth")
    @Mapping(source = "nomAdrAdd1", target = "txtNomAdrAdd1")
    @Mapping(source = "nomAdrAdd2", target = "txtNomAdrAdd2")
    @Mapping(source = "nomAdrAdd3", target = "txtNomAdrAdd3")
    @Mapping(source = "guardRelationship", target = "guardNomineeRelation")
    @Mapping(source = "guardDatBirth", target = "guardDatOfBirth")
    NomineeResponse.NomineeDetailsResponse.NomineeDetails toDetails(NomineeApiResponse.NomineeDtlsDTO source);

    default NomineeResponse toResponse(NomineeApiResponse.NomineeDtlsDTO source) {
        if (source == null) return null;

        return NomineeResponse.builder()
                .status(new ApiResponseStatus(CustomCommonApiStatusCodes.SUCCESS))
                .data(
                        NomineeResponse.NomineeDetailsResponse.builder()
                                .nomineeDetails(toDetails(source))
                                .build()
                )
                .build();
    }
}
