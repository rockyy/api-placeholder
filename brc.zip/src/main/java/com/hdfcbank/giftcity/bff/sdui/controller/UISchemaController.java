package com.hdfcbank.giftcity.bff.sdui.controller;



import com.hdfcbank.giftcity.bff.sdui.model.UiSchemaApiResponse;
import com.hdfcbank.giftcity.bff.sdui.service.UISchemaService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import tools.jackson.databind.JsonNode;

@Slf4j
@RestController
@RequestMapping("${api.giftcity.base-path}/sd-ui")
public class UISchemaController {
    @Autowired
    private UISchemaService schemaService;

    @PostMapping("/page/{pageId}")
    public ResponseEntity<UiSchemaApiResponse> getSchemaWithData(@PathVariable String pageId,
                                                                 @RequestBody(required = false) JsonNode requestBody) {
        return schemaService.getPageDetails(pageId, requestBody);
    }
}
