package com.hdfcbank.giftcity.bff.commons.model;

import lombok.*;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class MasterDataValue {
    private String code;
    private String description;
}
