package com.hdfcbank.giftcity.bff.application.service.impl;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hdfcbank.common.models.vo.core.ApiResponseStatus;
import com.hdfcbank.common.models.vo.core.ApiResponseStatusCode;
import com.hdfcbank.common.models.vo.journey.JourneyData;
import com.hdfcbank.common.models.vo.journey.JourneyState;
import com.hdfcbank.giftcity.bff.application.events.SqsCustomerSubmitPayload;
import com.hdfcbank.giftcity.bff.application.service.ApplicationService;
import com.hdfcbank.giftcity.bff.application.service.BackgroundEventPublisherService;
import com.hdfcbank.giftcity.bff.commons.config.JourneyContextHolder;
import com.hdfcbank.giftcity.bff.commons.constant.CommonConstants;
import com.hdfcbank.giftcity.bff.commons.enums.CommonJourneyStates;
import com.hdfcbank.giftcity.bff.commons.enums.CustomCommonApiStatusCodes;
import com.hdfcbank.giftcity.bff.commons.exception.CustomValidationException;
import com.hdfcbank.giftcity.bff.commons.utility.CommonUtil;
import com.hdfcbank.giftcity.bff.commons.utility.TextSanityUtil;
import com.hdfcbank.giftcity.bff.customer.config.CustomerApiProperties;
import com.hdfcbank.giftcity.bff.customer.model.*;

import com.hdfcbank.giftcity.bff.commons.model.JourneyCustomerProjection;
import com.hdfcbank.giftcity.bff.commons.repository.JourneyRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import software.amazon.awssdk.services.sqs.SqsClient;
import software.amazon.awssdk.services.sqs.model.MessageAttributeValue;
import software.amazon.awssdk.services.sqs.model.SendMessageResponse;

import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.temporal.ChronoUnit;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import static com.hdfcbank.common.models.constant.CommonConstants.JOURNEY_ID;
import static com.hdfcbank.giftcity.bff.application.events.BackgroundEvents.AOF_SUBMISSION_EMAIL_ALERT;
import static com.hdfcbank.giftcity.bff.application.events.BackgroundEvents.AOF_SUBMISSION_SMS_ALERT;
import static com.hdfcbank.giftcity.bff.commons.constant.CommonConstants.EMAIL_TEMPLATE;
import static com.hdfcbank.giftcity.bff.commons.constant.CommonConstants.SMS_TEMPLATE;
import static com.hdfcbank.giftcity.bff.commons.enums.CommonJourneyStates.*;

@Slf4j
@Service
@RequiredArgsConstructor
public class ApplicationServiceImpl implements ApplicationService {

    private final SqsClient applicationSubmit;
    private final ObjectMapper objectMapper;
    private final CustomerApiProperties customerApiProperties;
    private final JourneyRepository journeyRepository;
    private final BackgroundEventPublisherService backgroundEventPublisherService;



    @Value("${api.submit.queueUrl}")
    private String submitQueueUrl;

    @Override
    public ApplicationSubmitResponse applicationSubmit(String journeyId) {

        // Publish the message for the application submit
        publishSubmitMessage(journeyId);
        return buildSubmitResponse(journeyId);
    }

    @Override
    public InquireSubmitResponse inquireSubmit(String journeyId) {
        log.info("Verify submit journey states for the journey ID {}", TextSanityUtil.sanitize(journeyId));
        List<String> successJourneyStates = List.of(
                CREATE_APPLICATION_NUMBER_SUCCESS.name());

        JourneyData journeyData = JourneyContextHolder.getJourneyData();
        if (journeyData == null
                || journeyData.getJourneyDetail() == null
                || journeyData.getJourneyDetail().getJourneyStates() == null) {
            throw new CustomValidationException(CustomCommonApiStatusCodes.JOURNEY_DETAILS_NOT_FOUND,
                    List.of(CustomCommonApiStatusCodes.JOURNEY_DETAILS_NOT_FOUND.getMessage()));
        }

        Set<String> journeyStateSet = journeyData.getJourneyDetail()
                .getJourneyStates()
                .stream()
                .map(JourneyState::getStateName)
                .collect(Collectors.toSet());

        boolean allSuccess = journeyStateSet.containsAll(successJourneyStates);

        return buildSubmitEnquiryResponse(allSuccess
                ? InquireSubmitResponse.SubmitStatus.SUCCESS
                : InquireSubmitResponse.SubmitStatus.IN_PROGRESS,
                journeyData.getReferenceNo()
        );
    }

    private InquireSubmitResponse buildSubmitEnquiryResponse(InquireSubmitResponse.SubmitStatus status, String applicationNumber) {
        return InquireSubmitResponse.builder()
                .status(new ApiResponseStatus(ApiResponseStatusCode.SUCCESS))
                .data(InquireSubmitResponse.InquireSubmit.builder()
                        .status(status)
                        .applicationNumber(applicationNumber)
                        .build())
                .build();
    }

    private ApplicationSubmitResponse buildSubmitResponse(String journeyId) {
        return ApplicationSubmitResponse.builder()
                .status(ApiResponseStatus.success())
                .data(ApplicationSubmitResponse.SubmitDetails.builder()
                        .journeyId(journeyId)
                        .build())
                .build();
    }

    private void publishSubmitMessage(String journeyId) {
        log.info("Publishing submit SQS message with journey ID {} and Queue Url {}", TextSanityUtil.sanitize(journeyId), TextSanityUtil.sanitize(submitQueueUrl));
        try {
            SqsCustomerSubmitPayload sqsCustomerValidatePayload = SqsCustomerSubmitPayload.builder()
                    .journeyId(journeyId)
                    .build();
            String message = objectMapper.writeValueAsString(sqsCustomerValidatePayload);
            log.info("Preparing to send message to SQS. Message body: {}", TextSanityUtil.sanitize(message));

            software.amazon.awssdk.services.sqs.model.SendMessageRequest sendMessageRequest = software.amazon.awssdk.services.sqs.model.SendMessageRequest.builder()
                    .queueUrl(submitQueueUrl)
                    .messageBody(message)
                    .messageAttributes(Map.of(
                            JOURNEY_ID,
                            MessageAttributeValue.builder()
                                    .dataType("String")
                                    .stringValue(journeyId)
                                    .build()
                    ))
                    .build();

            SendMessageResponse response = applicationSubmit.sendMessage(sendMessageRequest);
            log.info("Message sent to queue: {}, messageId: {}, MD5: {}",
                    TextSanityUtil.sanitize(submitQueueUrl),
                    TextSanityUtil.sanitize(response.messageId()),
                    TextSanityUtil.sanitize(response.md5OfMessageBody())
            );
        } catch (Exception e) {
            log.error("Error sending customer submit message to SQS queue {}", TextSanityUtil.sanitize(submitQueueUrl), e);
        }
    }

    public void processAofSubmissionAlertReminders() {

        log.info("Processing AOF submission pending reminders");

        Map<String, String> smsServiceDefaults = customerApiProperties.getAofPendingDocumentSmsAlert().getServiceDefaults();

        Map<String, String> emailServiceDefaults = customerApiProperties.getAofPendingDocumentEmailAlert().getServiceDefaults();

        int smsMaxReminderEligibilityDays = Integer.parseInt(CommonUtil.getValue(smsServiceDefaults, CommonConstants.MAX_REMINDER_ELIGIBILITY_DAYS));

        int emailMaxReminderEligibilityDays = Integer.parseInt(CommonUtil.getValue(emailServiceDefaults, CommonConstants.MAX_REMINDER_ELIGIBILITY_DAYS));

        int maxReminderEligibilityDays = Math.max(smsMaxReminderEligibilityDays, emailMaxReminderEligibilityDays);

        Date cutoffDate = Date.from(Instant.now().minus(maxReminderEligibilityDays, ChronoUnit.DAYS));

        log.info("Processing AOF submission before getting data from mongo");

        List<JourneyCustomerProjection> journeys = journeyRepository.findEligibleJourneys(cutoffDate, FTS_SUCCESS_CALLBACK.name(), FTS_DOCS_RECEIVED_CALLBACK.name());

        log.info("Processing AOF submission after getting data from mongo");

        for (JourneyCustomerProjection journey : journeys) {

            JourneyCustomerProjection.JourneyStateProjection submitState =
                    journey.getJourneyDetail()
                            .getJourneyStates()
                            .stream()
                            .filter(state ->
                                    FTS_SUCCESS_CALLBACK.name()
                                            .equals(state.getStateName()))
                            .findFirst()
                            .orElse(null);

            boolean skipJourney = submitState == null;

            LocalDate submitDate = null;
            int days = 0;
            boolean smsReminderDay = false;
            boolean emailReminderDay = false;

            if (!skipJourney) {
                submitDate = submitState.getCreatedOn()
                        .toInstant()
                        .atZone(ZoneId.systemDefault())
                        .toLocalDate();

                log.info("Processing AOF submission getting submitDate {}", submitDate);

                days = (int) ChronoUnit.DAYS.between(submitDate, LocalDate.now());

                log.info("Processing AOF submission getting days {}", days);

                smsReminderDay = CommonUtil.isReminderDay(days, smsServiceDefaults);

                log.info("Processing AOF submission getting smsReminderDay {}", smsReminderDay);

                emailReminderDay = CommonUtil.isReminderDay(days, emailServiceDefaults);

                log.info("Processing AOF submission getting emailReminderDay {}", emailReminderDay);

                if (!smsReminderDay && !emailReminderDay) {
                    skipJourney = true;
                }
            }

            if (skipJourney) {
                continue;
            }

            String customerId =
                    journey.getJourneyDetail()
                            .getSystemData()
                            .getFcIndiaProfile()
                            .getProfiles()
                            .stream()
                            .findFirst()
                            .map(JourneyCustomerProjection.ProfilesProjection::getCustomerId)
                            .orElse(null);

            log.info("Processing AOF submission getting customerId {}", TextSanityUtil.sanitize(customerId));

            if (smsReminderDay) {

                String smsTemplateId =
                        CommonUtil.getSmsTemplateId(days, smsServiceDefaults);

                Map<String, Object> properties = Map.of(
                        SMS_TEMPLATE,
                        smsTemplateId
                );

                backgroundEventPublisherService.sendBackgroundEvent(journey.getId(), customerId, AOF_SUBMISSION_SMS_ALERT, properties);
            }

            if (emailReminderDay) {

                String emailTemplateId = CommonUtil.getEmailTemplateId(days, emailServiceDefaults);

                Map<String, Object> properties = Map.of(
                        EMAIL_TEMPLATE,
                        emailTemplateId
                );

                backgroundEventPublisherService.sendBackgroundEvent(journey.getId(), customerId, AOF_SUBMISSION_EMAIL_ALERT, properties);
            }
        }
    }


}
