package com.hdfcbank.giftcity.bff.customer.model;


import lombok.*;
import lombok.experimental.SuperBuilder;

import java.util.List;

@Getter
@Setter
@ToString
@SuperBuilder
@NoArgsConstructor
public class FactivaSummaryResponse {

    private SummaryResponse summaryResponse;

    @Getter
    @Setter
    @ToString
    @Builder
    @AllArgsConstructor
    @NoArgsConstructor
    public static class SummaryResponse {
        private MatchGroup factiva;
        private MatchGroup negativeList;
        private MatchGroup dotList;
        private MatchGroup mhaList;

        private String matchCombination;
        private String mhaMatch;
        private String neglistMatch;
        private String factivaMatch;
        private String dotMatch;
    }


    @Getter
    @Setter
    @ToString
    @Builder
    @AllArgsConstructor
    @NoArgsConstructor
    public static class MatchGroup {
        private List<MatchParameter> matchParameter;
    }

    @Getter
    @Setter
    @ToString
    @Builder
    @AllArgsConstructor
    @NoArgsConstructor
    public static class MatchParameter {
        private String matchParameterName;
        private String matchParameterValue;
    }

}

