package com.hdfcbank.giftcity.bff.customer.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.hdfcbank.common.models.vo.core.ApiResponse;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.*;
import lombok.experimental.SuperBuilder;

@Getter
@Setter
@ToString
@SuperBuilder
@NoArgsConstructor

public class ValidateCustomerResponse extends ApiResponse<ValidateCustomerResponse.ValidateCustomerDetail> {

    @Getter
    @Setter
    @ToString
    @SuperBuilder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class ValidateCustomerDetail {
        private boolean otpValidated;
        private int incorrectAttempts;
        private Integer retryOtpAttemptsConsumed;
        private Integer retryOtpAttemptsLeft;
        private Integer verifyOtpAttemptsConsumed;
        private Integer verifyOtpAttemptsLeft;
    }
}
