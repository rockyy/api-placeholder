package com.hdfcbank.giftcity.bff.customer.validator;

import com.hdfcbank.common.models.vo.journey.JourneyData;
import com.hdfcbank.giftcity.bff.commons.enums.CommonJourneyStates;
import com.hdfcbank.giftcity.bff.commons.enums.JourneyPageName;
import com.hdfcbank.giftcity.bff.commons.model.FcIndiaProfile;
import com.hdfcbank.giftcity.bff.commons.properties.CustomValidationProperties;
import com.hdfcbank.giftcity.bff.commons.validation.*;
import com.hdfcbank.giftcity.bff.customer.constants.CustomerConstants;
import com.hdfcbank.giftcity.bff.customer.mapper.UcicRequestMapper;
import com.hdfcbank.giftcity.bff.infrastructure.service.JourneyService;
import com.hdfcbank.service.adapters.clients.feign.customer.CustomerServiceFeignClient;
import com.hdfcbank.service.adapters.vo.customer.UcicApiResponse;
import com.hdfcbank.service.adapters.vo.customer.UcicRequest;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import java.util.Optional;
import static com.hdfcbank.giftcity.bff.commons.enums.CommonJourneyStates.UCIC_ELIGIBLE_FAILURE;
import static com.hdfcbank.giftcity.bff.commons.enums.CommonJourneyStates.UCIC_ELIGIBLE_SUCCESS;
import static com.hdfcbank.giftcity.bff.customer.constants.CustomerConstants.*;

@Service
@RequiredArgsConstructor
@Slf4j
public class UcicValidator extends AbstractCommanValidator implements Validator {

    private final CustomerServiceFeignClient customerFCFeignClient;
    private final UcicRequestMapper ucicRequestMapper;
    private final CustomValidationProperties customValidationProperties;


    @Override
    public Optional<ValidationResult> validate(ValidatorContext context) {
        JourneyData journeyData = context.getJourneyData();
        String journeyName = context.getJourneyData().getJourneyName();

        try {
            UcicApiResponse response = callUcicApi(journeyData);
            return handleResponse(journeyName, response, context);
        } catch (Exception e) {
            log.error("Exception in {} for journey {}", name(), journeyData.getReferenceNo(), e);
            return Optional.of(ValidationResult.of(getErrors(journeyName, null, customValidationProperties,CUSTOMER_UCIC), false));
        }
    }

    private UcicApiResponse callUcicApi(JourneyData journeyData) {
        FcIndiaProfile.Profile profile = JourneyService.extractFromJourney(journeyData, JourneyPageName.CUSTOMER_FC_INDIA_DETAIL.getPageName(), FcIndiaProfile.class, fcIndiaProfile -> Optional.ofNullable(fcIndiaProfile.getProfiles()).filter(list -> !list.isEmpty()).map(list -> list.get(0)).orElse(null)).orElse(null);
        UcicRequest request = ucicRequestMapper.toRequest(profile);
        return customerFCFeignClient.customerUcicValidate(request, journeyData.getJourneyId());
    }

    private Optional<ValidationResult> handleResponse(String journeyName, UcicApiResponse ucicApiResponse, ValidatorContext context) {
        String statusCode = ucicApiResponse.getStatus().getCode();
        if (UCIC_SUCCESS_201.equals(statusCode) || UCIC_SUCCESS_200.equals(statusCode) || UCIC_SUCCESS_222.equals(statusCode)) {
            context.getData().put(ValidatorContext.ContextKey.UCIC_DETAILS, ucicApiResponse.getData());
            return Optional.of(ValidationResult.of(null, true));
        }
        log.info("UCIC Failure getting error code {}", statusCode);
        return Optional.of(ValidationResult.of(getErrors(journeyName, ucicApiResponse, customValidationProperties,CUSTOMER_UCIC), false));
    }

    @Override
    public ValidatorType type() {
        return ValidatorType.POST_CUSTOMER_VALIDATION;
    }

    @Override
    public String name() {
        return CustomerConstants.POST_UCIC_VALIDATOR;
    }

    @Override
    public CommonJourneyStates successState() {
        return UCIC_ELIGIBLE_SUCCESS;
    }

    @Override
    public CommonJourneyStates failureState() {
        return UCIC_ELIGIBLE_FAILURE;
    }

    @Override
    public boolean isMandatory() {
        return false;
    }
}
