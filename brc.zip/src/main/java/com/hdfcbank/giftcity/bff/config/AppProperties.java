package com.hdfcbank.giftcity.bff.config;

import io.swagger.v3.oas.models.servers.Server;
import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import java.util.List;


@Getter
@Setter
@Configuration
@ConfigurationProperties("spring.application")
public class AppProperties {
    private String name;
    private String description;
    private String version;
    private List<Server> servers;
    private String channel;
    
}
