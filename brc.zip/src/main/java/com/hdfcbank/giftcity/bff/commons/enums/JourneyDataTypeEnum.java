package com.hdfcbank.giftcity.bff.commons.enums;

import lombok.Generated;

public enum JourneyDataTypeEnum {
    DOMAIN_DATA("domainData"),
    SYSTEM_DATA("systemData");

    private final String element;

    public String getElement() {
        return this.element;
    }

    public String getName() {
        return this.name();
    }

    @Generated
    private JourneyDataTypeEnum(final String element) {
        this.element = element;
    }
}
