package com.hdfcbank.giftcity.bff.application.controller;

import com.hdfcbank.giftcity.bff.application.service.ApplicationService;
import com.hdfcbank.giftcity.bff.commons.annotation.ValidateJourney;
import com.hdfcbank.giftcity.bff.customer.model.ApplicationSubmitResponse;
import com.hdfcbank.giftcity.bff.customer.model.InquireSubmitResponse;
import com.hdfcbank.starter.logging.annotations.JourneyId;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import static com.hdfcbank.giftcity.bff.commons.enums.CommonJourneyStates.*;

@Slf4j
@RestController
@RequestMapping("${api.giftcity.base-path}/application")
@RequiredArgsConstructor
public class ApplicationController {

    private final ApplicationService applicationService;


    @PostMapping("/submit")
    @ValidateJourney(shouldExists = {FC_INDIA_ELIGIBILITY_SUCCESS, FACTIVA_ELIGIBLE_SUCCESS, CUSTOMER_SIGNATURE_FETCH_SUCCESS})
    public ResponseEntity<ApplicationSubmitResponse> applicationSubmitDetails(@JourneyId String journeyId) {

        return ResponseEntity.ok(applicationService.applicationSubmit(journeyId));
    }

    @PostMapping("/inquire-submit")
    @ValidateJourney(shouldExists = {FC_INDIA_ELIGIBILITY_SUCCESS, FACTIVA_ELIGIBLE_SUCCESS, CUSTOMER_SIGNATURE_FETCH_SUCCESS})
    public ResponseEntity<InquireSubmitResponse> inquireSubmitDetails(@JourneyId String journeyId) {

        return ResponseEntity.ok(applicationService.inquireSubmit(journeyId));
    }
}
