package com.hdfcbank.giftcity.bff.account.service;

import com.hdfcbank.giftcity.bff.commons.exception.handler.DownstreamResponseHandler;
import com.hdfcbank.giftcity.bff.commons.handler.Handler;
import com.hdfcbank.giftcity.bff.commons.handler.HandlerResult;
import com.hdfcbank.giftcity.bff.commons.model.CustomValidationStatus;
import com.hdfcbank.giftcity.bff.commons.utility.TextSanityUtil;
import com.hdfcbank.service.adapters.vo.account.*;
import com.hdfcbank.service.adapters.clients.feign.account.AccountServiceFeignClient;
import com.hdfcbank.common.models.vo.journey.JourneyData;
import com.hdfcbank.giftcity.bff.account.mapper.CreateCustomerAccountMapper;
import com.hdfcbank.giftcity.bff.account.mapper.NomineeResponseMapper;
import com.hdfcbank.giftcity.bff.account.model.NomineeResponse;
import com.hdfcbank.giftcity.bff.commons.config.JourneyContextHolder;
import com.hdfcbank.giftcity.bff.commons.constant.CommonConstants;
import com.hdfcbank.giftcity.bff.commons.enums.JourneyPageName;
import com.hdfcbank.giftcity.bff.commons.exception.handler.NomineeException;
import com.hdfcbank.giftcity.bff.commons.model.FcIndiaProfile;
import com.hdfcbank.giftcity.bff.customer.config.CustomerApiProperties;
import com.hdfcbank.giftcity.bff.customer.model.CustomerApiStatusCode;
import com.hdfcbank.giftcity.bff.customer.model.ReviewCustomerResponse;
import com.hdfcbank.giftcity.bff.customer.utility.CustomerUtil;
import com.hdfcbank.giftcity.bff.infrastructure.service.JourneyService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import static com.hdfcbank.giftcity.bff.customer.constants.CustomerConstants.*;

@Service
@Slf4j
@AllArgsConstructor
public class AccountService {

    private AccountServiceFeignClient accountServiceFeignClient;
    private final NomineeResponseMapper nomineeMapper;

    private static final String SUCCESS = "0000";

    //unfreeze debit and credit flags for a account
    public   UpdateFccAccountResponseBFF removeAccountFreeze(String accountNumber, String journeyId) {

        UpdateFccAccountRequest request = new UpdateFccAccountRequest();

        request.setAccountNumber(accountNumber);
        request.setDebitFreeze(CommonConstants.DEBIT_UN_FREEZE);
        request.setCreditFreeze(CommonConstants.CREDIT_UN_FREEZE);  //both freeze flags to unfreeze
        return  updateFccAccount(request, journeyId);

    }
    //sanitize and call feign api
    public UpdateFccAccountResponseBFF updateFccAccount(UpdateFccAccountRequest request, String journeyId) {
        UpdateFccAccountRequest sanitizedRequest =
                CustomerUtil.sanitizeUpdateFccAccountRequest(request);
        return  accountServiceFeignClient.updateFccAccount(sanitizedRequest, journeyId);
    }


    public NomineeResponse getNominee(String journeyId) {

        log.info("inside nominee service call");

        JourneyData journeyData = JourneyContextHolder.getJourneyData();
        //extraction profile from journey
        FcIndiaProfile.Profile profile = JourneyService.extractFromJourney(journeyData, JourneyPageName.CUSTOMER_FC_INDIA_DETAIL.getPageName(), FcIndiaProfile.class, fcIndiaProfile -> Optional.ofNullable(fcIndiaProfile.getProfiles()).filter(list -> !list.isEmpty()).map(list -> list.get(0)).orElse(null)).orElse(null);

        if (profile == null || profile.getCustomerAccountDetails() == null || profile.getCustomerAccountDetails().isEmpty()) {

            DownstreamResponseHandler.handleResponse(null, Handler.HandlerName.FETCH_NOMINEE.name(), true, journeyData.getJourneyName());

        }
        log.info("fc india profile data present in request");
        //if account null aya toh cutomerprofile lega, stream pe paas karega,
        FcIndiaProfile.CustomerAccountDetail customerAccountDetails = profile.getCustomerAccountDetails().stream()
                .max(Comparator.comparing(acc -> new BigDecimal(Optional.ofNullable(acc.getAvailableBalance())
                        .orElse(ZERO)))).orElseThrow(() -> new NomineeException(CustomerApiStatusCode.CUSTDATA_MISSING_INVALID));

        String accountNumber = customerAccountDetails.getAccountNumber();

        NomineeRequest nomineeRequest = NomineeRequest.builder().accountNo(accountNumber).build();

        NomineeApiResponse apiResponse = accountServiceFeignClient.fetchNominees(nomineeRequest, journeyId);

        if (!apiResponse.getStatus().getCode().equalsIgnoreCase(SUCCESS)) {

            log.info("Nominee API failure response");

            DownstreamResponseHandler.handleResponse(apiResponse, Handler.HandlerName.FETCH_NOMINEE.name(), true, journeyData.getJourneyName());
        }

        List<NomineeApiResponse.NomineeDtlsDTO> nomineeList = apiResponse.getData();

        Optional<NomineeApiResponse.NomineeDtlsDTO> optionalNominee = nomineeList.stream()
                .filter(n -> n.getRatSharePct() != null)
                .max(Comparator.comparingDouble(n -> Double.parseDouble(n.getRatSharePct())));


        if (nomineeList.isEmpty()) {
            DownstreamResponseHandler.handleResponse(
                    apiResponse,
                    Handler.HandlerName.FETCH_NOMINEE.name(),
                    true,
                    journeyData.getJourneyName()
            );
        }

        log.info("Nominee API success response");

        NomineeApiResponse.NomineeDtlsDTO maxNominee = optionalNominee.get();

        return nomineeMapper.toResponse(maxNominee);
    }
    //direct paas method
    public FTSApplicationInquireApiResponse ftsApplicationInquire(FTSApplicationInquireRequest ftsApplicationInquireRequest, String journeyId) {

        return accountServiceFeignClient.applicationInquire(ftsApplicationInquireRequest, journeyId);

    }

}
