package com.hdfcbank.giftcity.bff.commons.utility;

import com.hdfcbank.giftcity.bff.commons.constant.CommonConstants;
import lombok.experimental.UtilityClass;
import org.apache.commons.lang3.StringUtils;
import org.mapstruct.Named;

import java.nio.charset.Charset;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.Locale;
import java.util.Map;

import static com.hdfcbank.giftcity.bff.commons.constant.CommonConstants.*;

@UtilityClass
public class CommonUtil {

    public static byte[] generateSHA1(String input) {
        try {
            MessageDigest crypt = MessageDigest.getInstance("SHA-256");
            crypt.reset();
            crypt.update(input.getBytes(Charset.defaultCharset()));
            return crypt.digest();
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException("SHA-256 algorithm not available", e);
        }
    }

    public static String generateRefNumber(String productCode) {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("ddMMyyHHmmssS");
        String format = simpleDateFormat.format(new Date());
        return String.format("%s%s", productCode, format);
    }

    public LocalDate getFormattedDate(String inputDate) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMdd");
        formatter = formatter.withLocale(Locale.ENGLISH);
        return LocalDate.parse(inputDate, formatter);
    }
    public LocalDate getFormattedDate(String inputDate, String pattern) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(pattern);
        formatter = formatter.withLocale(Locale.ENGLISH);
        return LocalDate.parse(inputDate, formatter);
    }
    public String localDateToString(LocalDate localDate, String outputPattern){
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(outputPattern);
        return localDate.format(formatter);
    }
    public LocalDate stringToLocalDate(String inputDate, String pattern){
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(pattern);
        return LocalDate.parse(inputDate, formatter);
    }
    public String changeDateFormat(String inputDate, String inputPattern, String outputPattern) {
        LocalDate formattedDate = getFormattedDate(inputDate, inputPattern);
        return localDateToString(formattedDate, outputPattern);
    }
    public LocalTime stringToLocalTime(String inputTime, String pattern){
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(pattern);
        return LocalTime.parse(inputTime, formatter);
    }

    public String getMaskString(String toMask, int place) {
        String maskChar = "*";
        String maskString = StringUtils.repeat(maskChar, place);
        return StringUtils.overlay(toMask, maskString, 0, place);
    }

    public String getMaskString(String toMask, int start, int place) {

        if (toMask == null || toMask.isEmpty()) {
            return toMask;
        }
        String maskString = StringUtils.repeat("*", place);
        return StringUtils.overlay(toMask, maskString, start, start + place);
    }

    public String maskPan(String pan) {
        if (pan == null || pan.length() <= 4) {
            return pan;
        }
        return getMaskString(pan, 2, pan.length() - 4);
    }

    public String mask(String value, int keep) {
        int place = value.length() - keep;
        return CommonUtil.getMaskString(value, place);
    }

    public String maskAndBatch(String value, int keep, int batchSize) {
        String maskedValue = mask(value, keep);
        String regex = "(?<=\\G.{" + batchSize + "})";
        String[] split = maskedValue.split(regex);
        return String.join(" ", split);
    }
    public static String formatDate(Date date, String format) {
        SimpleDateFormat dateFormat = new SimpleDateFormat(format);
        return dateFormat.format(date);
    }

    public String encode(String message) {
        message = message.replace( '\n' ,  '_' ).replace( '\r' , '_' )
                .replace( '\t' , '_' );
        return message;
    }

    public String formatDob(String dob) {
        if (dob == null || dob.isBlank()) {
            return dob;
        }
        try {
            LocalDate date = LocalDate.parse(dob, DateTimeFormatter.ISO_LOCAL_DATE);
            return date.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
        } catch (Exception e) {
            return dob;
        }
    }

    public String formatPassportDob(String date) {
        if (date == null || date.isBlank()) {
            return date;
        }

        try {
            LocalDate localDate;

            if (date.contains("-")) {
                localDate = LocalDate.parse(date, DateTimeFormatter.ISO_LOCAL_DATE);
            } else {
                localDate = LocalDate.parse(date, DateTimeFormatter.ofPattern("yyyyMMdd"));
            }

            return localDate.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));

        } catch (Exception e) {
            return date;
        }
    }

    public static String maskMobile(String mobile) {
        if (mobile == null || mobile.length() <= 4) {
            return mobile;
        }

        String firstTwo = mobile.substring(0, 2);
        String lastTwo = mobile.substring(mobile.length() - 2);

        String maskedPart = "*".repeat(mobile.length() - 4);

        return firstTwo + maskedPart + lastTwo;
    }

    public static String maskMobile(String mobile, String isd) {

        if (mobile == null || mobile.length() <= 4) {
            return (isd == null ? "" : isd) + mobile;
        }

        String maskedMobile = CommonUtil.getMaskString(mobile, mobile.length() - 4);

        return StringUtils.defaultString(isd) + maskedMobile;
    }

    @Named("maskEmail")
    public static String maskEmail(String email, int visiblePrefix, int visibleSuffix) {

        if (email == null || !email.contains("@")) {
            return email;
        }

        String[] parts = email.split("@", 2);
        String name = parts[0];
        String domain = parts[1];

        if (visiblePrefix < 0 || visibleSuffix < 0) {
            throw new IllegalArgumentException("Visible character counts cannot be negative.");
        }

        if (name.length() <= visiblePrefix) {
            return email;
        }

        int maskedLength = name.length() - visiblePrefix - visibleSuffix;

        if (maskedLength <= 0) {
            return name.substring(0, visiblePrefix)
                    + "*".repeat(Math.max(0, name.length() - visiblePrefix))
                    + "@"
                    + domain;
        }

        return name.substring(0, visiblePrefix)
                + "*".repeat(maskedLength)
                + name.substring(name.length() - visibleSuffix)
                + "@"
                + domain;
    }

    public String getEmailTemplateId(long days, Map<String, String> serviceDefaults) {
        if (days == Long.parseLong(
                getValue(serviceDefaults, CommonConstants.FIRST_REMINDER_DAY))) {
            return FIRST_REM_MAIL_TEMPLATE;
        }

        if (days == Long.parseLong(
                getValue(serviceDefaults, CommonConstants.SECOND_REMINDER_DAY))) {
            return SECOND_REM_MAIL_TEMPLATE;
        }

        if (days == Long.parseLong(
                getValue(serviceDefaults, CommonConstants.THIRD_REMINDER_DAY))) {
            return THIRD_REM_MAIL_TEMPLATE;
        }
        return null;
    }

    public String getSmsTemplateId(long days, Map<String, String> serviceDefaults) {
        if (days == Long.parseLong(
                getValue(serviceDefaults, CommonConstants.FIRST_REMINDER_DAY))) {
            return FIRST_REM_SMS_TEMPLATE;
        }

        if (days == Long.parseLong(
                getValue(serviceDefaults, CommonConstants.SECOND_REMINDER_DAY))) {
            return SECOND_REM_SMS_TEMPLATE;
        }

        if (days == Long.parseLong(
                getValue(serviceDefaults, CommonConstants.THIRD_REMINDER_DAY))) {
            return THIRD_REM_SMS_TEMPLATE;
        }
        return null;
    }

    public String getValue(Map<String, String> serviceDefaults, String key) {
        if (serviceDefaults == null) {
            return null;
        }
        return serviceDefaults.get(key);
    }

    public boolean isReminderDay(int days, Map<String, String> serviceDefaults) {

        int firstReminderDay = Integer.parseInt(CommonUtil.getValue(serviceDefaults, CommonConstants.FIRST_REMINDER_DAY));

        int secondReminderDay = Integer.parseInt(CommonUtil.getValue(serviceDefaults, CommonConstants.SECOND_REMINDER_DAY));

        int thirdReminderDay = Integer.parseInt(CommonUtil.getValue(serviceDefaults, CommonConstants.THIRD_REMINDER_DAY));

        return days == firstReminderDay || days == secondReminderDay || days == thirdReminderDay;
    }

    public static String maskAddress(String fullAddress) {

        if (StringUtils.isBlank(fullAddress)) {
            return fullAddress;
        }

        int visibleLength = Math.min(10, fullAddress.length());

        return fullAddress.substring(0, visibleLength)
                + StringUtils.repeat("*", fullAddress.length() - visibleLength);
    }

    public static String[] maskAddressLines(String address1, String address2) {

        address1 = StringUtils.defaultString(address1);
        address2 = StringUtils.defaultString(address2);

        String combined = address1 + address2;

        if (combined.isEmpty()) {
            return new String[]{"", ""};
        }

        String masked = maskAddress(combined);

        int splitIndex = Math.min(address1.length(), masked.length());

        String maskedAddress1 = masked.substring(0, splitIndex);
        String maskedAddress2 = masked.length() > splitIndex ? masked.substring(splitIndex) : "";

        return new String[]{maskedAddress1, maskedAddress2};
    }
}
