package com.hdfcbank.giftcity.bff;

import com.hdfcbank.security.utils.SSLHelperUtil;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.scheduling.annotation.EnableScheduling;


@EnableCaching
@EnableScheduling
@SpringBootApplication
@EnableFeignClients(basePackages = "com.hdfcbank")
@ComponentScan(basePackages = "com.hdfcbank")
public class GiftcityGatewayBFFApplication {

    public static void main(String[] args) {
        SSLHelperUtil.setupSSLProperties();
        SpringApplication.run(GiftcityGatewayBFFApplication.class, args);
    }
}
