package com.hdfcbank.giftcity.bff.application.handlers.background;

import com.hdfcbank.common.models.vo.journey.JourneyData;
import com.hdfcbank.common.models.vo.journey.JourneyDetail;
import com.hdfcbank.common.models.vo.journey.Profile;
import com.hdfcbank.giftcity.bff.application.mapper.FTSAccountOpeningMapper;
import com.hdfcbank.giftcity.bff.commons.enums.CommonJourneyStates;
import com.hdfcbank.giftcity.bff.commons.exception.handler.DownstreamResponseHandler;
import com.hdfcbank.giftcity.bff.commons.handler.Handler;
import com.hdfcbank.giftcity.bff.commons.handler.HandlerContext;
import com.hdfcbank.giftcity.bff.commons.handler.HandlerResult;
import com.hdfcbank.giftcity.bff.commons.model.FtsDetails;
import com.hdfcbank.giftcity.bff.customer.config.CustomerApiProperties;
import com.hdfcbank.giftcity.bff.customer.constants.CustomerConstants;
import com.hdfcbank.giftcity.bff.infrastructure.service.JourneyService;
import com.hdfcbank.service.adapters.clients.feign.account.AccountServiceFeignClient;
import com.hdfcbank.service.adapters.vo.account.FTSAccountOpeningApiResponse;
import com.hdfcbank.service.adapters.vo.account.FTSAccountOpeningRequest;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Objects;
import java.util.stream.Stream;

import static com.hdfcbank.giftcity.bff.commons.enums.CommonJourneyStates.*;
import static com.hdfcbank.giftcity.bff.commons.enums.JourneyPageName.FTS_DETAILS;

@Slf4j
@Service
@RequiredArgsConstructor
@Order(2)
public class FTSAccountOpeningHandler implements Handler<FTSAccountOpeningApiResponse> {
    private final AccountServiceFeignClient accountServiceFeignClient;

    private final FTSAccountOpeningMapper ftsAccountOpeningMapper;
    private final JourneyService journeyService;
    private final CustomerApiProperties customerApiProperties;


    @Override
    public boolean preConditions(HandlerContext handlerContext) {

        boolean dpcftpSuccess = hasJourneyState(handlerContext, CommonJourneyStates.DPCFTP_UPLOAD_SUCCESS.name());
        boolean ftsSuccessful = hasJourneyState(handlerContext, CommonJourneyStates.FTS_AOF_POSTED_SUCCESS.name());
        log.info("preConditions FTSAccountOpeningHandler triggered: {}", dpcftpSuccess);

        return (dpcftpSuccess && !ftsSuccessful);
    }

    @Override
    public HandlerResult<FTSAccountOpeningApiResponse> handle(HandlerContext handlerContext) {

        JourneyData journeyData = handlerContext.getJourneyData();
        try {

            log.info("Background FTSAccountOpeningHandler triggered {}", getName());

            FTSAccountOpeningRequest request = buildFTSAccountOpeningRequest(journeyData);

            FTSAccountOpeningApiResponse response =   accountServiceFeignClient.accountOpening(
                    journeyData.getJourneyId(),
                    request);

            if (response != null
                    && response.getData() != null
                    && response.getData().getResponseString() != null
                    && "Success".equalsIgnoreCase(
                    response.getData().getResponseString().getStatus())){
                FtsDetails ftsDetails = JourneyService.extractFromJourney(journeyData, FTS_DETAILS.getPageName(), FTS_DETAILS.getPageClassName(), x -> (FtsDetails)x).orElse(new FtsDetails());
                ftsDetails.setFtsAccountOpeningDetails(
                        FtsDetails.FtsAccountOpeningDetails.builder()
                                .status(response.getData().getResponseString().getStatus())
                                .rejectReason(response.getData().getResponseString().getRejectReason())
                                .acknowledgementNo(response.getData().getResponseString().getAcknowledgementNo())
                                .errorCode(response.getData().getResponseString().getErrorCode())
                                .build()
                );
                journeyService.updateJourney(journeyData.getJourneyId(), FTS_DETAILS.getPageName(), ftsDetails, FTS_AOF_POSTED_SUCCESS);

                return HandlerResult.of(null, response, true);
            }
            log.error("FTSAccountOpeningApi failed with code={} errors={}", response.getStatus().getCode(), response.getStatus().getErrors());
            return HandlerResult.of(DownstreamResponseHandler.handleResponse(response, HandlerName.FTS_ACCOUNT_OPENING.name(), false, journeyData.getJourneyName()), response, false);
        } catch (Throwable ex) {
            log.error("Exception while FTSAccountOpeningApi", ex);
            return HandlerResult.<FTSAccountOpeningApiResponse>of(DownstreamResponseHandler.handleResponse(null, HandlerName.FTS_ACCOUNT_OPENING.name(), false, journeyData.getJourneyName()), null, false);
        }
    }

    private FTSAccountOpeningRequest buildFTSAccountOpeningRequest(
            JourneyData journeyData) {

        Profile profile = journeyData.getProfile();

        FtsDetails ftsDetails = JourneyService.extractFromJourney(
                        journeyData,
                        FTS_DETAILS.getPageName(),
                        (Class<FtsDetails>) FTS_DETAILS.getPageClassName())
                .orElseGet(FtsDetails::new);

        List<FTSAccountOpeningRequest.HolderInfo> holderInfoList = Stream.of(
                        Stream.of(
                                buildCustomerSignatureHolderInfo(journeyData, ftsDetails.getCustomerSignatureDocRef(), profile),

                                buildAofWithAnnextureHolderInfo(journeyData, ftsDetails.getAofWithAnnextureDocRef(), profile)
                        )

                )
                .flatMap(s -> s)        // flatten all streams
                .filter(Objects::nonNull)
                .toList();

        return ftsAccountOpeningMapper.toFTSAccountOpeningRequest(
                journeyData,
                profile,
                ftsDetails,
                holderInfoList);
    }

    private FTSAccountOpeningRequest.HolderInfo buildAofWithAnnextureHolderInfo(JourneyData journeyData,
            String aofWithAnnextureDocRef,
            Profile profile) {

        if (aofWithAnnextureDocRef == null) {
            return null;
        }

        return ftsAccountOpeningMapper.toHolderInfo(journeyData,
                profile,
                customerApiProperties.getAofDetails().getAofImagePath(),
                CustomerConstants.AOF_WITH_ANNEXTURE_DOC_REF);
    }

    private FTSAccountOpeningRequest.HolderInfo buildCustomerSignatureHolderInfo(JourneyData journeyData,
            String customerSignatureDocRef,
            Profile profile) {

        if (customerSignatureDocRef == null) {
            return null;
        }

        return ftsAccountOpeningMapper.toHolderInfo(
                journeyData,
                profile,
                customerApiProperties.getAofDetails().getSigImagePath(),
                CustomerConstants.CUSTOMER_SIGNATURE_DOC_REF);
    }

    @Override
    public HandlerType getType() {
        return HandlerType.BACKGROUND_TASKS_POST_SUBMIT_SUCCESS;
    }

    @Override
    public HandlerName getName() {
        return HandlerName.FTS_ACCOUNT_OPENING;
    }

    @Override
    public CommonJourneyStates successState() {
        return FTS_AOF_POSTED_SUCCESS;
    }

    @Override
    public CommonJourneyStates failureState() {
        return FTS_AOF_POSTED_FAILURE;
    }
}
