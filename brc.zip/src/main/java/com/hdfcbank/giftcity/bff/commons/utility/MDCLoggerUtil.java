package com.hdfcbank.giftcity.bff.commons.utility;

import com.hdfcbank.common.models.vo.journey.JourneyData;
import com.hdfcbank.common.models.vo.mdc.MDCValues;

public class MDCLoggerUtil {

    private MDCLoggerUtil() {
    }

    public static void populateMDC(JourneyData journeyData) {
        MDCValues.clear();
        MDCValues.setJourneyId(journeyData.getJourneyId());
        MDCValues.setJourneyName(journeyData.getJourneyName());
    }
}
