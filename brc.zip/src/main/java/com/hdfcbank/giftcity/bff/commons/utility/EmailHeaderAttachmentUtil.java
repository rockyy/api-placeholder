package com.hdfcbank.giftcity.bff.commons.utility;


import com.hdfcbank.giftcity.bff.commons.file.ByteArrayMultipartFile;
import com.hdfcbank.giftcity.bff.commons.file.InlineImage;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Component;
import org.springframework.util.StreamUtils;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.io.InputStream;

@Slf4j
@Component
@RequiredArgsConstructor
public class EmailHeaderAttachmentUtil {

    private static final String FILE_CONSTANT = "file";

    public static class EmailResourcePreparationException extends RuntimeException {
        public EmailResourcePreparationException(String message, Throwable cause) {
            super(message, cause);
        }
    }

    public MultipartFile prepareMultipartResource(String resourcePath, String contentType) {
        log.info("Converting classpath asset to MultipartFile: {}", TextSanityUtil.sanitize(resourcePath));

        try {
            ClassPathResource imgResource = new ClassPathResource(resourcePath);
            byte[] headerBytes;

            try (InputStream inputStream = imgResource.getInputStream()) {
                headerBytes = StreamUtils.copyToByteArray(inputStream);
            }

            return new ByteArrayMultipartFile(
                    FILE_CONSTANT,
                    resourcePath,
                    contentType,
                    headerBytes
            );

        } catch (IOException e) {
            log.error("Failed to read classpath resource asset: {}", resourcePath, e);
            throw new EmailResourcePreparationException("Error preparing inline email resource file stream: " + resourcePath, e);
        }
    }


    public InlineImage prepareInlineImage(String resourcePath, String contentType, String cid) {

        return new InlineImage(cid, prepareMultipartResource(resourcePath, contentType));

    }
}