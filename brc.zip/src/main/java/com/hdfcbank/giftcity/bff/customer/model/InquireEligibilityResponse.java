package com.hdfcbank.giftcity.bff.customer.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonValue;
import com.hdfcbank.common.models.vo.core.ApiResponse;
import lombok.*;
import lombok.experimental.SuperBuilder;

@Getter
@SuperBuilder
public class InquireEligibilityResponse extends ApiResponse <InquireEligibilityResponse.InquireEligibility>{

    @Getter
    @Setter
    @ToString
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class InquireEligibility {
        private JourneyStatus status;
    }

    public enum JourneyStatus {

        SUCCESS,
        IN_PROGRESS,
        FAILED
    }
}
