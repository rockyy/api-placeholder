package com.hdfcbank.giftcity.bff.sdui.model;

import lombok.*;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Header {
    private String key;
    private String value;
}
