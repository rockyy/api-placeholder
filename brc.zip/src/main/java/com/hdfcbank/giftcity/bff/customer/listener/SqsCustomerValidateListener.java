package com.hdfcbank.giftcity.bff.customer.listener;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.hdfcbank.adapters.clients.feign.document.DocumentFeignClient;
import com.hdfcbank.adapters.vo.DocumentUploadedResponse;
import com.hdfcbank.common.models.vo.journey.JourneyData;
import com.hdfcbank.giftcity.bff.commons.enums.CommonJourneyStates;
import com.hdfcbank.giftcity.bff.commons.enums.ImageFormat;
import com.hdfcbank.giftcity.bff.commons.exception.handler.DownstreamResponseHandler;
import com.hdfcbank.giftcity.bff.commons.file.Base64MultipartFile;
import com.hdfcbank.giftcity.bff.commons.model.FcGcProfile;
import com.hdfcbank.giftcity.bff.commons.model.FtsDetails;
import com.hdfcbank.giftcity.bff.commons.utility.ImageConverter;
import com.hdfcbank.giftcity.bff.commons.utility.MDCLoggerUtil;
import com.hdfcbank.giftcity.bff.commons.utility.TextSanityUtil;
import com.hdfcbank.giftcity.bff.commons.validation.ValidationResult;
import com.hdfcbank.giftcity.bff.commons.validation.Validator;
import com.hdfcbank.giftcity.bff.commons.validation.ValidatorContext;
import com.hdfcbank.giftcity.bff.commons.validation.ValidatorsFactory;
import com.hdfcbank.giftcity.bff.customer.events.SqsCustomerValidateMessage;
import com.hdfcbank.giftcity.bff.customer.service.CustomerService;
import com.hdfcbank.giftcity.bff.infrastructure.service.JourneyService;
import io.awspring.cloud.sqs.annotation.SqsListener;
import io.awspring.cloud.sqs.listener.acknowledgement.Acknowledgement;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.messaging.handler.annotation.Headers;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.*;

import static com.hdfcbank.giftcity.bff.commons.constant.CommonConstants.IMAGE_PNG_TYPE_HEADER;
import static com.hdfcbank.giftcity.bff.commons.constant.CommonConstants.IMAGE_TYPE_HEADER;
import static com.hdfcbank.giftcity.bff.commons.enums.JourneyPageName.*;


@Service
@Slf4j
@RequiredArgsConstructor
public class SqsCustomerValidateListener {

    public static final int MAX_RETRY = 3;
    private final ObjectMapper objectMapper;
    private final ValidatorsFactory validatorsFactory;
    private final JourneyService journeyService;

    private final DocumentFeignClient documentFeignClient;

    @SqsListener(value = "${api.customer-validate.queueUrl}", acknowledgementMode = "MANUAL")
    public void sqsCustomerValidateListner(@Payload String requestJSON, @Headers Map<String, Object> headers, Acknowledgement acknowledgement)  {
        String messageId = headers.get("MessageId") != null ? headers.get("MessageId").toString() : "UNKNOWN";
        headers.forEach((k, v) -> log.info("SqsCustomerValidateListener Headers - {} = {}", TextSanityUtil.sanitize(k), v));
        int retryCount = headers.get("Sqs_Msa_ApproximateReceiveCount") != null ? Integer.parseInt(headers.get("Sqs_Msa_ApproximateReceiveCount").toString()) : 1;
        log.info("Received SQS message. MessageId: {}, Payload: {}, Retry Count {}", TextSanityUtil.sanitize(messageId), TextSanityUtil.sanitize(requestJSON), retryCount);
        JourneyData journeyData = null;
        try {
            SqsCustomerValidateMessage sqsCustomerValidateMessage = objectMapper.readValue(requestJSON, SqsCustomerValidateMessage.class);
            journeyData = journeyService.fetchJourney(sqsCustomerValidateMessage.getPayload().getJourneyId());
            MDCLoggerUtil.populateMDC(journeyData);

            // Set comman ValidatorContext for all validators!
            ValidatorContext validatorContext = ValidatorContext.builder()
                    .journeyData(journeyData)
                    .data(new HashMap<>())
                    .build();

            // Get Validators by journey name and validator type
            List<Validator> validators = validatorsFactory.getValidators(journeyData.getJourneyName(),
                    sqsCustomerValidateMessage.getType());

            // Call Validators
            boolean isProcessed = callValidators(validators, validatorContext);

            if (isProcessed) {
                performPostActions(validatorContext);

                acknowledgement.acknowledge();

                log.info("Message successfully acknowledged. MessageId: {}", messageId);
            } else {
                log.warn("Message processing failed. It will be retried. MessageId: {}", messageId);
            }

        } catch (JsonProcessingException e) {
            log.error("Failed to parse JSON. MessageId: {}", messageId, e);
        } catch (Exception e) {
            log.error("Unexpected error while processing message. MessageId: {}", messageId, e);
            if (retryCount > MAX_RETRY) {
                journeyService.updateJourneyDetailDropOff(journeyData, DownstreamResponseHandler
                                .handleResponse(null, null, false,
                                        journeyData.getJourneyName())
                        , CommonJourneyStates.VALIDATORS_FAILURE);
                acknowledgement.acknowledge();
            }
        }
    }

    private void performPostActions(ValidatorContext validatorContext) throws IOException {

        saveUcic(validatorContext);
        saveSignature(validatorContext);
        saveKyc(validatorContext);
    }

    private void saveKyc(ValidatorContext validatorContext) {

        JourneyData updatedJourneyData = journeyService.fetchJourney(validatorContext.getJourneyData().getJourneyId());
        validatorContext.setJourneyData(updatedJourneyData);

        JourneyData journeyData = validatorContext.getJourneyData();

        Object ckycDetails = validatorContext.getData()
                .get(ValidatorContext.ContextKey.CKYC_DETAILS);
        if(Objects.nonNull(ckycDetails)){
            journeyService.updateJourney(journeyData.getJourneyId(), KYC_DETAILS.getPageName(), ckycDetails, CommonJourneyStates.CUSTOMER_CKYC_FETCH_SUCCESS);
        }

    }

    private void saveUcic(ValidatorContext validatorContext) {

        JourneyData updatedJourneyData = journeyService.fetchJourney(validatorContext.getJourneyData().getJourneyId());
        validatorContext.setJourneyData(updatedJourneyData);

        JourneyData journeyData = validatorContext.getJourneyData();
        Object ucicDetails = validatorContext.getData()
                .get(ValidatorContext.ContextKey.UCIC_DETAILS);
        if(Objects.nonNull(ucicDetails)){
            journeyService.updateJourney(journeyData.getJourneyId(), UCIC_DETAILS.getPageName(), ucicDetails, CommonJourneyStates.UCIC_ELIGIBLE_SUCCESS);
        }
    }

    private void saveSignature(ValidatorContext validatorContext) throws IOException {

        JourneyData updatedJourneyData =
                journeyService.fetchJourney(validatorContext.getJourneyData().getJourneyId());
        validatorContext.setJourneyData(updatedJourneyData);

        JourneyData journeyData = validatorContext.getJourneyData();

        Object signatureObj = validatorContext.getData()
                .get(ValidatorContext.ContextKey.CUSTOMER_SIGNATURE);

        if(signatureObj != null){
            String data = signatureObj.toString().replaceAll("\\s", "");

            byte[] fileBytes = Base64.getDecoder().decode(data);

            saveFtsTifSignature(journeyData, fileBytes);
            saveGiftCitySignature(journeyData, fileBytes);
        }
        else{
            log.error("Signature not available in context !");
        }
    }

    private boolean callValidators(List<Validator> validators, ValidatorContext validatorContext) {

        if (CollectionUtils.isEmpty(validators)) {
            return true;
        }

        String journeyId = validatorContext.getJourneyData().getJourneyId();
        for (Validator validator : validators) {
            log.info("Validator name {} and type {}", validator.name(), validator.type());
            Optional<ValidationResult> optionalResult = validator.validate(validatorContext);

            if (optionalResult.isEmpty()) {
                // Skip to next validator when there is no result
            } else {
                ValidationResult result = optionalResult.get();

                if (result.isSuccess()) {
                    journeyService.recordJourneyState(journeyId, validator.successState());
                } else {
                    journeyService.updateJourneyDetailDropOff(validatorContext.getJourneyData(),
                            result.getApiResponseStatus(), validator.failureState());

                    if(validator.isMandatory()) // only break the other executions in case of mandatory validator failure
                        break;
                }
            }
        }
        return true;
    }

    private void saveFtsTifSignature(JourneyData journeyData, byte[] fileBytes) throws IOException {

        // Convert to TIFF if required
        if (!ImageConverter.isImageFormat(fileBytes, ImageFormat.TIF)) {
            log.info("Image is not of type TIF , converting..");
            fileBytes = ImageConverter.convertImage(fileBytes, ImageFormat.TIF, 500, 500);
        }
        else{
            log.info("Image is of type TIF ");
        }
        String docRef = uploadSignature(journeyData, fileBytes, IMAGE_TYPE_HEADER);

        FtsDetails ftsDetails = JourneyService.extractFromJourney(
                        journeyData,
                        FTS_DETAILS.getPageName(),
                        FTS_DETAILS.getPageClassName(),
                        x -> (FtsDetails) x)
                .orElse(new FtsDetails());

        ftsDetails.setCustomerSignatureDocRef(docRef);

        journeyService.updateJourney(
                journeyData.getJourneyId(),
                FTS_DETAILS.getPageName(),
                ftsDetails,
                CommonJourneyStates.CUSTOMER_SIGNATURE_FETCH_SUCCESS);
    }

    private void saveGiftCitySignature(JourneyData journeyData, byte[] fileBytes) throws IOException {

        String docRef = uploadSignature(journeyData, fileBytes, IMAGE_PNG_TYPE_HEADER);

        FcGcProfile fcGcProfile = JourneyService.extractFromJourney(
                        journeyData,
                        CUSTOMER_FC_GIFT_CITY_DETAIL.getPageName(),
                        CUSTOMER_FC_GIFT_CITY_DETAIL.getPageClassName(),
                        x -> (FcGcProfile) x)
                .orElse(new FcGcProfile());

        fcGcProfile.setCustomerSignatureDocRef(docRef);

        journeyService.updateJourney(
                journeyData.getJourneyId(),
                CUSTOMER_FC_GIFT_CITY_DETAIL.getPageName(),
                fcGcProfile,
                CommonJourneyStates.CUSTOMER_SIGNATURE_FETCH_SUCCESS);
    }

    private String uploadSignature(JourneyData journeyData, byte[] fileBytes, String imageTypeHeader) {

        MultipartFile multipartFile =
                new Base64MultipartFile(fileBytes, imageTypeHeader);

        DocumentUploadedResponse documentResponse =
                documentFeignClient
                        .uploadDocumentResponse(
                                journeyData.getJourneyName(),
                                multipartFile,
                                "")
                        .getData();

        log.info("Signature uploaded on S3 docRef {}", documentResponse.getDocRef());

        return documentResponse.getDocRef();
    }
}
