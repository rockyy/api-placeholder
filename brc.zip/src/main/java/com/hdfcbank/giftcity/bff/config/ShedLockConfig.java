package com.hdfcbank.giftcity.bff.config;

import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoDatabase;
import net.javacrumbs.shedlock.core.LockProvider;
import net.javacrumbs.shedlock.provider.mongo.MongoLockProvider;
import net.javacrumbs.shedlock.spring.annotation.EnableSchedulerLock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.mongodb.autoconfigure.MongoProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.mongodb.core.MongoTemplate;

@Configuration
@EnableSchedulerLock(defaultLockAtMostFor = "3h")
public class ShedLockConfig {

    @Autowired
    private MongoProperties mongoProperties;

    @Bean
    public LockProvider lockProvider(MongoTemplate mongoTemplate) {

        MongoDatabase database =  mongoTemplate.getDb();
        return new MongoLockProvider(database);
    }


}
