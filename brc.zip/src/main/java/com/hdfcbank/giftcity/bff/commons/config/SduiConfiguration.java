package com.hdfcbank.giftcity.bff.commons.config;

import com.hdfcbank.giftcity.bff.sdui.model.DataSource;
import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import java.util.Map;

@Getter
@Setter
@Configuration
@ConfigurationProperties(prefix = "app.sdui")
public class SduiConfiguration {

    private Map<String, DataSource> dataSources;
    private String version;
}
