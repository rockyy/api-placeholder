package com.hdfcbank.giftcity.bff.customer.events;

import lombok.*;

import java.util.Map;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SqsCustomerValidatePayload {

    private String journeyId;
    private Map<String,Object> properties;
}
