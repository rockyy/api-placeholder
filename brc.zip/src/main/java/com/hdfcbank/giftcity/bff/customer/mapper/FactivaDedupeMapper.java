package com.hdfcbank.giftcity.bff.customer.mapper;

import com.hdfcbank.common.models.vo.journey.JourneyData;
import com.hdfcbank.common.models.vo.journey.Profile;
import com.hdfcbank.giftcity.bff.commons.model.FcIndiaProfile;
import com.hdfcbank.service.adapters.vo.customer.FactivaDedupeRequest;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring")
public interface FactivaDedupeMapper {

    @Mapping(source = "profile.customerId", target = "requestorUserID")
    @Mapping(source = "profile.fullName", target = "customerName")
    @Mapping(source = "profile.dob", target = "dateOfBirth")
    @Mapping(source = "profile.emailId", target = "emailID")
    @Mapping(source = "journeyData.mobileNumber", target = "mobileNo")
    @Mapping(source = "profile.panNumber", target = "panNo")
    FactivaDedupeRequest toRequest(JourneyData journeyData, Profile profile);

}
