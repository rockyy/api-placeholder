package com.hdfcbank.giftcity.bff.customer.mapper;

import com.hdfcbank.adapters.vo.GenerateDocumentRequest;
import com.hdfcbank.common.models.vo.journey.JourneyData;
import com.hdfcbank.giftcity.bff.commons.model.FcIndiaProfile;
import com.hdfcbank.giftcity.bff.commons.utility.CommonUtil;
import com.hdfcbank.giftcity.bff.customer.config.CustomerApiProperties;
import com.hdfcbank.giftcity.bff.customer.constants.CustomerConstants;
import com.hdfcbank.giftcity.bff.customer.model.AccountStatementDocData;
import com.hdfcbank.giftcity.bff.customer.utility.CustomerUtil;
import com.hdfcbank.service.adapters.vo.account.ViewAccountStatementRequest;
import com.hdfcbank.service.adapters.vo.account.ViewAccountStatementResponse;
import io.micrometer.common.util.StringUtils;
import org.mapstruct.*;
import org.springframework.util.CollectionUtils;


import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static com.hdfcbank.giftcity.bff.customer.constants.CustomerConstants.DD_MM_YYYY_FORMATTER;

@Mapper(
        componentModel = "spring",
        imports = {CustomerConstants.class, CommonUtil.class},
        nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS,
        nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE,
        unmappedTargetPolicy = ReportingPolicy.IGNORE
)
public  interface AccountStatementDocumentMapper {

    @Mapping(target = "accountNumber", source = "accountDetail.accountNumber")
    @Mapping(target = "customerId", source = "accountDetail.customerId")
    @Mapping(target = "dateStmtFrom", expression = "java(buildStatementFromDate(statementDays))")
    @Mapping(target = "dateStmtTo", expression = "java(buildCurrentDate())")
    @Mapping(target = "txnType", source = "txnType")
    ViewAccountStatementRequest toViewAccountStatementRequest(
            JourneyData journeyData,
            FcIndiaProfile.CustomerAccountDetail accountDetail,
            String txnType,
            Integer statementDays
    );

    @Mapping(target = "generateType", constant = CustomerConstants.TIF)
    @Mapping(target = "responseType", constant = CustomerConstants.ATTACHMENT)
    @Mapping(target = "templateId", constant = CustomerConstants.ACCOUNT_STATEMENT_TEMPLATE)
    @Mapping(target = "targetFileName", expression = "java(buildFileName(journeyData, statementIndex, fileIndex))")
    @Mapping(target = "data", expression = "java(toData(journeyData, accountDetail, statementData, statementDays, nominationMappings))")
    GenerateDocumentRequest<AccountStatementDocData> toAccountStatementDocumentRequest(
            JourneyData journeyData,
            FcIndiaProfile.CustomerAccountDetail accountDetail,
            ViewAccountStatementResponse.ViewAccountStatementData statementData,
            Integer statementIndex,
            Integer fileIndex,
            Integer statementDays,
            @Context Map<String, String> nominationMappings
    );

    default String buildFileName(JourneyData journeyData, Integer statementIndex, Integer fileIndex) {
        return CustomerConstants.ACCOUNT_STATEMENT_PREFIX
                + statementIndex
                + "_"
                + fileIndex
                + "_"
                + journeyData.getJourneyId()
                + CustomerConstants.TIF_EXTENSION;
    }

    default AccountStatementDocData toData(
            JourneyData journeyData,
            FcIndiaProfile.CustomerAccountDetail accountDetail,
            ViewAccountStatementResponse.ViewAccountStatementData statementData,
            Integer statementDays,
            Map<String, String> nominationMappings
    ) {
        AccountStatementDocData data = new AccountStatementDocData();

        List<ViewAccountStatementResponse.Transaction> txns =
                Optional.ofNullable(statementData)
                        .map(ViewAccountStatementResponse.ViewAccountStatementData::getTransactions)
                        .orElse(Collections.emptyList());

        data.setTransactionMessage(txns.isEmpty() ? CustomerConstants.ACCOUNT_STATEMENT_NO_TRANSACTIONS_FOUND : null);

        data.setAccountDetails(toAccountDetails(journeyData, accountDetail, statementData, statementDays, nominationMappings));

        data.setTransactions(
                txns.stream()
                        .map(this::toTransaction)
                        .collect(Collectors.toList())
        );

        BigDecimal totalDebits = txns.stream()
                .filter(t -> CustomerConstants.DEBIT.equalsIgnoreCase(t.getCodeDebitCredit()))
                .map(ViewAccountStatementResponse.Transaction::getAmount)
                .filter(Objects::nonNull)
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        BigDecimal totalCredits = txns.stream()
                .filter(t -> CustomerConstants.CREDIT.equalsIgnoreCase(t.getCodeDebitCredit()))
                .map(ViewAccountStatementResponse.Transaction::getAmount)
                .filter(Objects::nonNull)
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        data.setClosingBal(statementData.getClosingBal());
        data.setTotalDebits(totalDebits);
        data.setTotalCredits(totalCredits);
        return data;
    }

    @Mapping(target = "branchName", source = "accountDetail.branchName")
    @Mapping(target = "branchAddress", expression = "java(buildBranchAddress(accountDetail))")
    @Mapping(target = "branchCity", source = "accountDetail.branchCity")
    @Mapping(target = "branchState", source = "accountDetail.branchState")
    @Mapping(target = "branchTelNo", source = "accountDetail.branchTelNo")
    @Mapping(target = "amountODLimit", source = "accountDetail.amountODLimit")
    @Mapping(target = "ifscCode", source = "accountDetail.ifscCode")
    @Mapping(target = "currency", source = "statementData.currency")
    @Mapping(target = "branchCode", source = "accountDetail.branchCode")
    @Mapping(target = "prodTypeDesc", source = "accountDetail.prodTypeDesc")
    @Mapping(target = "accountNumber", source = "accountDetail.accountNumber")
    @Mapping(target = "nomination",  expression = "java(getNomination(journeyData, nominationMappings))")
    @Mapping(target = "customerId", source = "accountDetail.customerId")
    @Mapping(target = "customerAddress", expression = "java(buildCustomerAddress(journeyData))")
    @Mapping(target = "customerCity", expression = "java(getPrimaryProfile(journeyData).map(FcIndiaProfile.Profile::getMailingCity).orElse(null))")
    @Mapping(target = "customerState", expression = "java(getPrimaryProfile(journeyData).map(FcIndiaProfile.Profile::getMailingState).orElse(null))")
    @Mapping(target = "customerPinCode", expression = "java(getPrimaryProfile(journeyData).map(FcIndiaProfile.Profile::getMailingPinCode).orElse(null))")
    @Mapping(target = "customerName", expression = "java(getCustomerName(journeyData))")
    @Mapping(target = "accountStatus", source = "accountDetail.accountStatus")
    @Mapping(target = "accountOpenDate", source = "accountDetail.datAcctOpen")
    @Mapping(target = "dateStmtFrom", expression = "java(buildStatementFromDate(statementDays))")
    @Mapping(target = "dateStmtTo", expression = "java(buildCurrentDate())")
    @Mapping(target = "currentDate", expression = "java(buildCurrentDate())")
    AccountStatementDocData.AccountDetails toAccountDetails(
            JourneyData journeyData,
            FcIndiaProfile.CustomerAccountDetail accountDetail,
            ViewAccountStatementResponse.ViewAccountStatementData statementData,
            Integer statementDays,
            @Context Map<String, String> nominationMappings
    );

    @Mapping(target = "txnDate", source = "transactionDate")
    @Mapping(target = "narration", source = "description")
    @Mapping(target = "chequeRefNo", source = "chequeNumber")
    @Mapping(target = "valueDate", source = "valueDate")
    @Mapping(target = "withdrawalAmount", expression = "java(getWithdrawalAmount(transaction))")
    @Mapping(target = "depositAmount", expression = "java(getDepositAmount(transaction))")
    AccountStatementDocData.TransactionData toTransaction(ViewAccountStatementResponse.Transaction transaction);

    default String getCustomerName(JourneyData journeyData) {
        return CustomerUtil.getPrimaryProfile(journeyData).map(FcIndiaProfile.Profile::getName).orElse(null);
    }

    default BigDecimal getWithdrawalAmount(ViewAccountStatementResponse.Transaction transaction) {
        return CustomerConstants.DEBIT.equalsIgnoreCase(transaction.getCodeDebitCredit()) ? transaction.getAmount() : null;
    }

    default BigDecimal getDepositAmount(ViewAccountStatementResponse.Transaction transaction) {
        return CustomerConstants.CREDIT.equalsIgnoreCase(transaction.getCodeDebitCredit()) ? transaction.getAmount() : null;
    }

    default String buildBranchAddress(FcIndiaProfile.CustomerAccountDetail accountDetail) {

        String address = Stream.of(
                        accountDetail.getBranchAddressLine1(),
                        accountDetail.getBranchAddressLine2(),
                        accountDetail.getBranchAddressLine3()
                )
                .filter(StringUtils::isNotBlank)
                .collect(Collectors.joining(", "));

        return StringUtils.isBlank(address) ? null : address;
    }

    default String buildCustomerAddress(JourneyData journeyData) {

        return getPrimaryProfile(journeyData)
                .map(profile -> Stream.of(
                                profile.getMailingAddress1(),
                                profile.getMailingAddress2(),
                                profile.getMailingAddress3()
                        )
                        .filter(StringUtils::isNotBlank)
                        .collect(Collectors.joining(", ")))
                .filter(StringUtils::isNotBlank)
                .orElse(null);
    }

    default String getNomination(JourneyData journeyData, Map<String, String> nominationMappings) {

        String addrType = getPrimaryProfile(journeyData)
                .map(FcIndiaProfile.Profile::getCustomerFATCADetails)
                .filter(list -> !list.isEmpty())
                .map(list -> list.get(0))
                .map(FcIndiaProfile.CustomerFATCADetail::getAddrTyp)
                .orElse(null);

        return addrType == null ? null : nominationMappings.get(addrType);
    }

    default Optional<FcIndiaProfile.Profile> getPrimaryProfile(JourneyData journeyData) {
        return CustomerUtil.getPrimaryProfile(journeyData);
    }

    default String buildCurrentDate() {return LocalDate.now().format(DD_MM_YYYY_FORMATTER);}

    default String buildStatementFromDate(Integer days) {return LocalDate.now().minusDays(days).format(DD_MM_YYYY_FORMATTER);}
}