package com.hdfcbank.giftcity.bff.config;

import jakarta.annotation.PostConstruct;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.ReactiveMongoOperations;
import org.springframework.data.mongodb.core.index.Index;
import org.springframework.stereotype.Component;

@Component
public class IndexCreator {

    private final MongoOperations mongoOperations;

    public IndexCreator(MongoOperations mongoOperations) {
        this.mongoOperations = mongoOperations;
    }

    @PostConstruct
    public void initIndexes() {
        Index ttlIndex = new Index()
                .on("expireAt", org.springframework.data.domain.Sort.Direction.ASC)
                .named("expire_index")
                .expire(10); // 10 seconds after the `expireAt` field
        mongoOperations.indexOps("cooloff")  // collection name
                .ensureIndex(ttlIndex);

    }
}
