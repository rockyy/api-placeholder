package com.hdfcbank.giftcity.bff.application.handlers.submit;

import com.hdfcbank.adapters.clients.feign.document.DocumentFeignClient;
import com.hdfcbank.adapters.vo.DownloadDocumentRequest;
import com.hdfcbank.common.models.vo.journey.JourneyData;
import com.hdfcbank.giftcity.bff.commons.constant.CommonConstants;
import com.hdfcbank.giftcity.bff.commons.enums.CommonJourneyStates;
import com.hdfcbank.giftcity.bff.commons.enums.ImageFormat;
import com.hdfcbank.giftcity.bff.commons.exception.handler.DownstreamResponseHandler;
import com.hdfcbank.giftcity.bff.commons.handler.Handler;
import com.hdfcbank.giftcity.bff.commons.handler.HandlerContext;
import com.hdfcbank.giftcity.bff.commons.handler.HandlerResult;
import com.hdfcbank.giftcity.bff.commons.model.FcGcProfile;
import com.hdfcbank.giftcity.bff.commons.model.FtsDetails;
import com.hdfcbank.giftcity.bff.commons.utility.CommonUtil;
import com.hdfcbank.giftcity.bff.commons.utility.ImageConverter;
import com.hdfcbank.giftcity.bff.customer.utility.CustomerUtil;
import com.hdfcbank.service.adapters.clients.feign.customer.CustomerServiceFeignClient;
import com.hdfcbank.service.adapters.vo.customer.CreateSignatureResponse;
import com.hdfcbank.service.adapters.vo.customer.SignatureRequest;
import com.hdfcbank.giftcity.bff.infrastructure.service.JourneyService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.jetbrains.annotations.NotNull;
import org.springframework.core.annotation.Order;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.Base64;

import static com.hdfcbank.giftcity.bff.commons.enums.CommonJourneyStates.CREATE_FCC_CUSTOMER_SIGNATURE_FAILURE;
import static com.hdfcbank.giftcity.bff.commons.enums.CommonJourneyStates.CREATE_FCC_CUSTOMER_SIGNATURE_SUCCESS;
import static com.hdfcbank.giftcity.bff.commons.enums.JourneyPageName.CUSTOMER_FC_GIFT_CITY_DETAIL;
import static com.hdfcbank.giftcity.bff.commons.enums.JourneyPageName.FTS_DETAILS;

@Slf4j
@Service
@RequiredArgsConstructor
@Order(4)
public class CreateSignatureHandler implements Handler<CreateSignatureResponse> {

    private final CustomerServiceFeignClient customerFCFeignClient;
    private final DocumentFeignClient documentFeignClient;
    private final JourneyService journeyService;
    private static final String SUCCESS = "0000";

    @Override
    public boolean preConditions(HandlerContext handlerContext) {

        return isSuccess(handlerContext, HandlerName.CREATE_CUSTOMER)
                && isSuccess(handlerContext, HandlerName.CREATE_ACCOUNT);

    }

    @Override
    public HandlerResult<CreateSignatureResponse> handle(HandlerContext handlerContext) {
        JourneyData journeyData = journeyService.fetchJourney(handlerContext.getJourneyData().getJourneyId());

        try {

            FcGcProfile fcGcProfile = JourneyService.extractFromJourney(
                            journeyData,
                            CUSTOMER_FC_GIFT_CITY_DETAIL.getPageName(),
                            CUSTOMER_FC_GIFT_CITY_DETAIL.getPageClassName(),
                            x -> (FcGcProfile) x)
                    .orElse(new FcGcProfile());

            String signatureDocRef = fcGcProfile.getCustomerSignatureDocRef();
            String journeyId = handlerContext.getJourneyData().getJourneyId();
            ResponseEntity<byte[]> signatureBytes = documentFeignClient.downloadResponse(journeyId, journeyData.getJourneyName(), new DownloadDocumentRequest(signatureDocRef));

            byte[] imageBytes = signatureBytes.getBody();

            String base64Signature = Base64.getEncoder().encodeToString(imageBytes);

            SignatureRequest signatureRequest = getSignatureRequest(journeyData, base64Signature);

            log.info("Calling createSignature for customer: {}", journeyData.getProfile().getCustomerId());

            CreateSignatureResponse response = customerFCFeignClient.createSignature(signatureRequest);

            if (response.getStatus().getCode().equals(SUCCESS)) {
                return HandlerResult.of(null,
                         response, true);
            }

            return HandlerResult.of(DownstreamResponseHandler
                            .handleResponse(response, HandlerName.CREATE_SIGNATURE.name(),
                                    false, journeyData.getJourneyName()),
                     response, false);

        } catch (Throwable e) {
            return HandlerResult.<CreateSignatureResponse>of(DownstreamResponseHandler
                            .handleResponse(null,
                                    HandlerName.CREATE_SIGNATURE.name(),
                                    false, journeyData.getJourneyName()), null, false);
        }

    }

    private @NotNull SignatureRequest getSignatureRequest(JourneyData journeyData, String base64Signature) {
        SignatureRequest signatureRequest = new SignatureRequest();
        String customerNumber = CustomerUtil.getFCGiftCityProfile(journeyData)
                .map(FcGcProfile::getCustomerNumber)
                .orElse(null);
        signatureRequest.setCustNumber(customerNumber);
        signatureRequest.setImageType(CommonConstants.SIGNATURE);
        signatureRequest.setSigID(customerNumber);
        signatureRequest.setSigTitle(journeyData.getProfile().getFullName());
        signatureRequest.setImageByte(base64Signature);
        signatureRequest.setSigName(journeyData.getProfile().getFullName());
        signatureRequest.setReplicateToAccount(CommonConstants.DEFAULT_REP_TOACC);
        return signatureRequest;
    }

    @Override
    public HandlerType getType() {
        return HandlerType.CUSTOMER_POST_SUBMIT;
    }

    @Override
    public HandlerName getName() {
        return HandlerName.CREATE_SIGNATURE;
    }

    @Override
    public CommonJourneyStates successState() {
        return CREATE_FCC_CUSTOMER_SIGNATURE_SUCCESS;
    }

    @Override
    public CommonJourneyStates failureState() {
        return CREATE_FCC_CUSTOMER_SIGNATURE_FAILURE;
    }

}
