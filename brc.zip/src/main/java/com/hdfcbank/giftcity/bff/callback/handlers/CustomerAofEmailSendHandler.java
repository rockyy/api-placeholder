package com.hdfcbank.giftcity.bff.callback.handlers;

import com.hdfcbank.adapters.clients.feign.communication.CommunicationFeignClient;
import com.hdfcbank.adapters.clients.feign.document.DocumentFeignClient;
import com.hdfcbank.adapters.vo.*;
import com.hdfcbank.common.models.vo.journey.JourneyData;
import com.hdfcbank.giftcity.bff.commons.enums.CommonJourneyStates;
import com.hdfcbank.giftcity.bff.commons.enums.JourneyPageName;
import com.hdfcbank.giftcity.bff.commons.exception.handler.DownstreamResponseHandler;
import com.hdfcbank.giftcity.bff.commons.file.ByteArrayMultipartFile;
import com.hdfcbank.giftcity.bff.commons.file.InlineImage;
import com.hdfcbank.giftcity.bff.commons.handler.Handler;
import com.hdfcbank.giftcity.bff.commons.handler.HandlerContext;
import com.hdfcbank.giftcity.bff.commons.handler.HandlerResult;
import com.hdfcbank.giftcity.bff.commons.model.FcIndiaProfile;
import com.hdfcbank.giftcity.bff.commons.model.FtsDetails;
import com.hdfcbank.giftcity.bff.commons.utility.CommonUtil;
import com.hdfcbank.giftcity.bff.commons.utility.EmailHeaderAttachmentUtil;
import com.hdfcbank.giftcity.bff.commons.utility.TextSanityUtil;
import com.hdfcbank.giftcity.bff.customer.utility.CustomerUtil;
import com.hdfcbank.giftcity.bff.infrastructure.service.JourneyService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.annotation.Order;
import org.springframework.core.io.ClassPathResource;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.StreamUtils;
import org.springframework.web.multipart.MultipartFile;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static com.hdfcbank.giftcity.bff.commons.constant.CommonConstants.*;
import static com.hdfcbank.giftcity.bff.commons.constant.CommonConstants.BRANCH_LOCATOR_CID;
import static com.hdfcbank.giftcity.bff.commons.constant.CommonConstants.BRANCH_LOCATOR_IMG;
import static com.hdfcbank.giftcity.bff.commons.constant.CommonConstants.CALL_US_CID;
import static com.hdfcbank.giftcity.bff.commons.constant.CommonConstants.CALL_US_IMG;
import static com.hdfcbank.giftcity.bff.commons.constant.CommonConstants.INTERNET_BANKING_CID;
import static com.hdfcbank.giftcity.bff.commons.constant.CommonConstants.INTERNET_BANKING_IMG;
import static com.hdfcbank.giftcity.bff.commons.constant.CommonConstants.MOBILE_APP_CID;
import static com.hdfcbank.giftcity.bff.commons.constant.CommonConstants.MOBILE_APP_IMG;
import static com.hdfcbank.giftcity.bff.commons.constant.CommonConstants.PNG;
import static com.hdfcbank.giftcity.bff.commons.constant.CommonConstants.WHATSAPP_CID;
import static com.hdfcbank.giftcity.bff.commons.constant.CommonConstants.WHATSAPP_IMG;
import static com.hdfcbank.giftcity.bff.commons.enums.CommonJourneyStates.*;
import static com.hdfcbank.giftcity.bff.commons.enums.JourneyPageName.FTS_DETAILS;

@Slf4j
@Service
@RequiredArgsConstructor
@Order(6)
public class CustomerAofEmailSendHandler implements Handler<EmailMessageSuccess> {

    private final CommunicationFeignClient communicationFeignClient;
    private final DocumentFeignClient documentFeignClient;
    private final EmailHeaderAttachmentUtil emailHeaderAttachmentUtil;

    private static final String SUCCESS = "0000";
    private static final String EMAIL = "EMAIL";
    private static final String EMAIL_TEMPLATE = "share-email-gca";
    private static final String DATE_FORMAT = "ddMMyyyy";
    private static final String FILE_FORMAT = "application/pdf";
    private static final String FILE = "file";

    @Override
    public boolean preConditions(HandlerContext handlerContext) {
        return hasJourneyState(handlerContext, FTS_SUCCESS_CALLBACK.name());
    }

    @Override
    public HandlerResult<EmailMessageSuccess> handle(HandlerContext handlerContext) {

        log.info("inside Aof Email Handler ");
        JourneyData journeyData = handlerContext.getJourneyData();

        try {

            FtsDetails ftsDetails = JourneyService.extractFromJourney(journeyData, FTS_DETAILS.getPageName(), (Class<FtsDetails>) FTS_DETAILS.getPageClassName()).orElseGet(FtsDetails::new);

            FcIndiaProfile.Profile fcProfile = CustomerUtil.getPrimaryProfile(journeyData).orElse(null);

            String aofwithoutAnnexture = ftsDetails.getAofWithoutAnnextureDocRef();
            String journeyId = journeyData.getJourneyId();

            ResponseEntity<byte[]> aofwithoutAnnextureBytes = documentFeignClient.downloadResponse(journeyId, journeyData.getJourneyName(), new DownloadDocumentRequest(aofwithoutAnnexture));

            byte[] fileBytes = aofwithoutAnnextureBytes.getBody();

            String customerName = fcProfile != null ? fcProfile.getName() : null;
            String applicationDate = CommonUtil.localDateToString(LocalDate.now(), DATE_FORMAT);

            String fileName = String.format("%s_%s_%s.pdf", customerName, journeyData.getReferenceNo(), applicationDate);

            log.info("filename of aof document without annexture {}", TextSanityUtil.sanitize(fileName));


            MultipartFile multipartFile = new ByteArrayMultipartFile(FILE, fileName, FILE_FORMAT, fileBytes);

            List<UploadAttachmentResponse.UploadAttachmentDetail> attachments = new ArrayList<>();



            UploadAttachmentResponse uploadAttachmentResponse = communicationFeignClient.uploadAttachmentFile(multipartFile,journeyId);

            if (uploadAttachmentResponse == null || uploadAttachmentResponse.getData() == null) {
                throw new IllegalStateException("Failed to upload document attachment");
            }

            attachments.add(
                    UploadAttachmentResponse.UploadAttachmentDetail.builder()
                            .filename(uploadAttachmentResponse.getData().getFilename())
                            .reference(uploadAttachmentResponse.getData().getReference())
                            .build()
            );

            List<InlineImage> inlineImages = List.of(
                    emailHeaderAttachmentUtil.prepareInlineImage(HEADER_IMG, JPEG, HEADER_CID),
                    emailHeaderAttachmentUtil.prepareInlineImage(CALL_US_IMG, PNG, CALL_US_CID),
                    emailHeaderAttachmentUtil.prepareInlineImage(WHATSAPP_IMG, PNG, WHATSAPP_CID),
                    emailHeaderAttachmentUtil.prepareInlineImage(MOBILE_APP_IMG, PNG, MOBILE_APP_CID),
                    emailHeaderAttachmentUtil.prepareInlineImage(INTERNET_BANKING_IMG, PNG, INTERNET_BANKING_CID),
                    emailHeaderAttachmentUtil.prepareInlineImage(BRANCH_LOCATOR_IMG, PNG, BRANCH_LOCATOR_CID));

            for (InlineImage inlineImage : inlineImages) {

                UploadAttachmentResponse uploadResponse =
                        communicationFeignClient.uploadAttachmentFile(
                                inlineImage.getFile(),
                                journeyId);

                if (uploadResponse == null || uploadResponse.getData() == null) {
                    throw new IllegalStateException(
                            "Failed to upload inline image : " + TextSanityUtil.sanitize(inlineImage.getFile().getOriginalFilename()));
                }

                attachments.add(
                        UploadAttachmentResponse.UploadAttachmentDetail.builder()
                                .filename(uploadResponse.getData().getFilename())
                                .reference(uploadResponse.getData().getReference())
                                .imageCidName(inlineImage.getCid())
                                .build()
                );
            }

            EmailDetails emailDetails =
                    EmailDetails.builder()
                            .to(new String[]{journeyData.getProfile().getEmailId()})
                            .cc(new String[]{})
                            .attachments(attachments)
                            .build();

            SendMessageRequest request =
                    SendMessageRequest.builder()
                            .messageType(EMAIL)
                            .channel(EMAIL)
                            .mobileNumber(journeyData.getMobileNumber())
                            .customerName(fcProfile.getName())
                            .emailId(journeyData.getProfile().getEmailId())
                            .templateId(EMAIL_TEMPLATE)
                            .targetSystem(TargetSystemType.SMTP.name())
                            .emailDetails(emailDetails)
                            .fileName(uploadAttachmentResponse.getData().getFilename())
                            .build();


            EmailMessageSuccess response = communicationFeignClient.sendEmail(request,journeyId);


            if (response.getStatus().getCode().equals(SUCCESS)) {
                return HandlerResult.of(null,
                        response, true);
            }

            return HandlerResult.of(DownstreamResponseHandler
                            .handleResponse(response, HandlerName.CUSTOMER_AOF_EMAIL_NOTIFY.name(),
                                    false, journeyData.getJourneyName()),
                    response, false);

        } catch (Throwable e) {
            return HandlerResult.<EmailMessageSuccess>of(DownstreamResponseHandler
                    .handleResponse(null,
                            HandlerName.CUSTOMER_AOF_EMAIL_NOTIFY.name(),
                            false, journeyData.getJourneyName()), null, false);
        }

    }

    @Override
    public HandlerType getType() {
        return HandlerType.BACKGROUND_TASKS_POST_SUBMIT_SUCCESS;
    }

    @Override
    public HandlerName getName() {
        return HandlerName.CUSTOMER_AOF_EMAIL_NOTIFY;
    }

    @Override
    public CommonJourneyStates successState() {
        return CUSTOMER_AOF_NOTIFY_SUCCESS;
    }

    @Override
    public CommonJourneyStates failureState() {
        return CUSTOMER_AOF_NOTIFY_FAILURE;
    }

}

