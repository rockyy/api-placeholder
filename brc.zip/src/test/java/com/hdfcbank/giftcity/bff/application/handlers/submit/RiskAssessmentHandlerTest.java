package com.hdfcbank.giftcity.bff.application.handlers.submit;

import com.hdfcbank.common.models.vo.core.ApiResponseStatus;
import com.hdfcbank.common.models.vo.journey.JourneyData;
import com.hdfcbank.giftcity.bff.commons.enums.CommonJourneyStates;
import com.hdfcbank.giftcity.bff.commons.enums.JourneyPageName;
import com.hdfcbank.giftcity.bff.commons.exception.handler.DownstreamResponseHandler;
import com.hdfcbank.giftcity.bff.commons.handler.Handler;
import com.hdfcbank.giftcity.bff.commons.handler.HandlerContext;
import com.hdfcbank.giftcity.bff.commons.handler.HandlerResult;
import com.hdfcbank.giftcity.bff.commons.model.CustomValidationStatus;
import com.hdfcbank.giftcity.bff.customer.mapper.CustomerRiskAnalysisMapper;
import com.hdfcbank.giftcity.bff.infrastructure.service.JourneyService;

import com.hdfcbank.service.adapters.clients.feign.customer.CustomerServiceFeignClient;
import com.hdfcbank.service.adapters.vo.customer.CustomerRiskAnalysisRequest;
import com.hdfcbank.service.adapters.vo.customer.CustomerRiskAnalysisResponse;

import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;

import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

import ch.qos.logback.classic.Level;
import ch.qos.logback.classic.Logger;
import org.slf4j.LoggerFactory;

@ExtendWith(MockitoExtension.class)
class RiskAssessmentHandlerTest {

    /**           Mute all logs from RiskAssessmentHandler so tests run clean */
    @BeforeAll
    static void muteHandlerLogs() {
        Logger logger =
                (Logger) LoggerFactory.getLogger(RiskAssessmentHandler.class);
        logger.setLevel(Level.OFF);
    }

    @Mock private CustomerServiceFeignClient customerClient;
    @Mock private CustomerRiskAnalysisMapper mapper;
    @Mock private JourneyService journeyService;

    @Spy
    @InjectMocks
    private RiskAssessmentHandler handler;

    private JourneyData journeyData;
    private HandlerContext ctx;

    @BeforeEach
    void setup() {
        journeyData = JourneyData.builder()
                .journeyId("J100")
                .journeyName("GIFT_CITY")
                .build();

        ctx = HandlerContext.builder()
                .journeyData(journeyData)
                .data(new java.util.HashMap<>())
                .properties(new java.util.HashMap<>())
                .build();
    }

              
    // Preconditions (always true)
              
    @Test
    void preConditions_alwaysTrue() {
        assertTrue(handler.preConditions(ctx));
    }

              
    // SUCCESS CASE (status = "0000")
              
    @Test
    void handle_success() {

        CustomerRiskAnalysisRequest req = new CustomerRiskAnalysisRequest();
        when(mapper.toRequest(journeyData)).thenReturn(req);

        // Prepare response
        CustomerRiskAnalysisResponse resp = new CustomerRiskAnalysisResponse();

        ApiResponseStatus status = new ApiResponseStatus();
        status.setCode("0000");
        status.setMessage("OK");
        resp.setStatus(status);

        CustomerRiskAnalysisResponse.RiskAnalysisData data =
                new CustomerRiskAnalysisResponse.RiskAnalysisData();
        resp.setData(data);

        when(customerClient.getCustomerRiskAnalysis(req, "J100"))
                .thenReturn(resp);

        HandlerResult<CustomerRiskAnalysisResponse> result = handler.handle(ctx);

        assertTrue(result.isSuccess());
        assertEquals(resp, result.getResult());

        verify(journeyService).updateJourney(
                eq("J100"),
                eq(JourneyPageName.RISK_ASSESSMENT.getPageName()),
                eq(data),
                eq(CommonJourneyStates.CUSTOMER_RISK_ASSESSMENT_SUCCESS)
        );
    }

              
    // FAILURE CASE (status != "0000")
              
    @Test
    void handle_failure() {

        CustomerRiskAnalysisRequest req = new CustomerRiskAnalysisRequest();
        when(mapper.toRequest(journeyData)).thenReturn(req);

        CustomerRiskAnalysisResponse resp = new CustomerRiskAnalysisResponse();

        ApiResponseStatus status = new ApiResponseStatus();
        status.setCode("9999");
        status.setMessage("FAIL");
        status.setErrors(java.util.List.of("RISK_ERROR"));
        resp.setStatus(status);

        resp.setData(new CustomerRiskAnalysisResponse.RiskAnalysisData());

        when(customerClient.getCustomerRiskAnalysis(req, "J100"))
                .thenReturn(resp);

        CustomValidationStatus custom = CustomValidationStatus.builder()
                .code("ERR")
                .message("DOWN")
                .build();

        try (MockedStatic<DownstreamResponseHandler> mock =
                     mockStatic(DownstreamResponseHandler.class)) {

            mock.when(() -> DownstreamResponseHandler.handleResponse(
                    eq(resp),
                    eq(Handler.HandlerName.RISK_ANALYSIS.name()),
                    eq(false),
                    eq("GIFT_CITY")
            )).thenReturn(custom);

            HandlerResult<CustomerRiskAnalysisResponse> result = handler.handle(ctx);

            assertFalse(result.isSuccess());
            assertEquals("ERR", result.getApiResponseStatus().getCode());
            assertEquals(resp, result.getResult());
        }
    }

              
    // EXCEPTION CASE (RuntimeException)
              
    @Test
    void handle_exception() {

        CustomerRiskAnalysisRequest req = new CustomerRiskAnalysisRequest();
        when(mapper.toRequest(journeyData)).thenReturn(req);

        when(customerClient.getCustomerRiskAnalysis(req, "J100"))
                .thenThrow(new RuntimeException("Boom"));

        CustomValidationStatus custom = CustomValidationStatus.builder()
                .code("EX")
                .message("EXC")
                .build();

        try (MockedStatic<DownstreamResponseHandler> mock =
                     mockStatic(DownstreamResponseHandler.class)) {

            mock.when(() -> DownstreamResponseHandler.handleResponse(
                    eq(null),
                    eq(Handler.HandlerName.RISK_ANALYSIS.name()),
                    eq(false),
                    eq("GIFT_CITY")
            )).thenReturn(custom);

            HandlerResult<CustomerRiskAnalysisResponse> result = handler.handle(ctx);

            assertFalse(result.isSuccess());
            assertEquals("EX", result.getApiResponseStatus().getCode());
            assertNull(result.getResult());
        }
    }

              
    // ENUM COVERAGE
              
    @Test
    void enumCoverage() {
        assertEquals(Handler.HandlerType.CUSTOMER_POST_SUBMIT, handler.getType());
        assertEquals(Handler.HandlerName.RISK_ANALYSIS, handler.getName());
        assertEquals(CommonJourneyStates.CUSTOMER_RISK_ASSESSMENT_SUCCESS, handler.successState());
        assertEquals(CommonJourneyStates.CUSTOMER_RISK_ASSESSMENT_FAILURE, handler.failureState());
    }
}