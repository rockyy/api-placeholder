package com.hdfcbank.giftcity.bff.customer.service.impl;

import com.hdfcbank.giftcity.bff.infrastructure.entity.CoolingPeriodDetailsEntity;
import com.hdfcbank.giftcity.bff.infrastructure.repository.CoolingPeriodDetailsRepository;

import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.Duration;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import ch.qos.logback.classic.Level;
import ch.qos.logback.classic.Logger;
import org.slf4j.LoggerFactory;

@ExtendWith(MockitoExtension.class)
class CoolingPeriodServiceTest {

    // Mute all logs
    @BeforeAll
    static void muteLogs() {
        Logger root = (Logger) LoggerFactory.getLogger(Logger.ROOT_LOGGER_NAME);
        root.setLevel(Level.OFF);
    }

    @Mock
    private CoolingPeriodDetailsRepository coolingPeriodDetailsRepository;

    @InjectMocks
    private CoolingPeriodService coolingPeriodService;

    private Map<String, String> identifiers;

    @BeforeEach
    void setUp() {
        identifiers = new HashMap<>();
        identifiers.put("mobile", "9876543210");
    }

    // =====================================================================
    //             getConsumedAttempts() — entity exists
    // =====================================================================
    @Test
    void getConsumedAttempts_shouldReturnAttempts_whenEntityExists() {

        CoolingPeriodDetailsEntity entity =
                CoolingPeriodDetailsEntity.builder()
                        .id(identifiers)
                        .noOfAttempts(3)
                        .build();

        when(coolingPeriodDetailsRepository.findById(identifiers))
                .thenReturn(Optional.of(entity));

        int result = coolingPeriodService.getConsumedAttempts(identifiers);

        assertEquals(3, result);
        assertEquals(3, entity.getNoOfAttempts());
        assertEquals("9876543210", entity.getId().get("mobile"));

        verify(coolingPeriodDetailsRepository).findById(identifiers);
    }

    // =====================================================================
    //             getConsumedAttempts() — entity DOES NOT exist
    // =====================================================================
    @Test
    void getConsumedAttempts_shouldReturnZero_whenEntityDoesNotExist() {

        when(coolingPeriodDetailsRepository.findById(identifiers))
                .thenReturn(Optional.empty());

        int result = coolingPeriodService.getConsumedAttempts(identifiers);

        assertEquals(0, result);
        assertTrue(result <= 0);

        verify(coolingPeriodDetailsRepository).findById(identifiers);
    }

    // =====================================================================
    //             updateConsumeAttempts() — update existing entity
    // =====================================================================
    @Test
    void updateConsumeAttempts_shouldUpdateExistingEntity() {

        CoolingPeriodDetailsEntity entity =
                CoolingPeriodDetailsEntity.builder()
                        .id(identifiers)
                        .noOfAttempts(2)
                        .build();

        when(coolingPeriodDetailsRepository.findById(identifiers))
                .thenReturn(Optional.of(entity));

        coolingPeriodService.updateConsumeAttempts(
                identifiers,
                3,
                Duration.ofMinutes(10)
        );

        verify(coolingPeriodDetailsRepository).updateAttempts(
                eq(identifiers),
                any(Date.class),
                eq(3),
                any(Date.class)
        );

        verify(coolingPeriodDetailsRepository, never())
                .save(any(CoolingPeriodDetailsEntity.class));

        assertEquals(2, entity.getNoOfAttempts()); // original value unchanged
    }

    // =====================================================================
    //             updateConsumeAttempts() — save new entity
    // =====================================================================
    @Test
    void updateConsumeAttempts_shouldSaveNewEntity_whenEntityDoesNotExist() {

        when(coolingPeriodDetailsRepository.findById(identifiers))
                .thenReturn(Optional.empty());

        coolingPeriodService.updateConsumeAttempts(
                identifiers,
                1,
                Duration.ofMinutes(10)
        );

        ArgumentCaptor<CoolingPeriodDetailsEntity> captor =
                ArgumentCaptor.forClass(CoolingPeriodDetailsEntity.class);

        verify(coolingPeriodDetailsRepository).save(captor.capture());
        CoolingPeriodDetailsEntity saved = captor.getValue();

        assertEquals(identifiers, saved.getId());
        assertEquals(1, saved.getNoOfAttempts());
        assertNotNull(saved.getCreatedDate());
        assertNotNull(saved.getExpireAt());
        assertTrue(saved.getExpireAt().after(saved.getCreatedDate()));
    }

    // =====================================================================
    //             updateConsumeAttempts() — TTL expiration calculation correctness
    // =====================================================================
    @Test
    void updateConsumeAttempts_shouldCalculateExpireAtUsingTtl() {

        when(coolingPeriodDetailsRepository.findById(identifiers))
                .thenReturn(Optional.empty());

        Duration ttl = Duration.ofMinutes(10);

        Date before = new Date();
        coolingPeriodService.updateConsumeAttempts(identifiers, 2, ttl);

        ArgumentCaptor<CoolingPeriodDetailsEntity> captor =
                ArgumentCaptor.forClass(CoolingPeriodDetailsEntity.class);

        verify(coolingPeriodDetailsRepository).save(captor.capture());

        Date expireAt = captor.getValue().getExpireAt();

        assertNotNull(expireAt);
        assertFalse(expireAt.before(before)); // expireAt >= before
        assertTrue(expireAt.before(new Date(System.currentTimeMillis() + Duration.ofMinutes(11).toMillis())));
    }

    // =====================================================================
    //             updateConsumeAttempts() — findById throws → main exception thrown
    // =====================================================================
    @Test
    void updateConsumeAttempts_shouldThrowRuntimeException_whenRepositoryFails() {

        when(coolingPeriodDetailsRepository.findById(identifiers))
                .thenThrow(new RuntimeException("Database error"));

        RuntimeException ex = assertThrows(
                RuntimeException.class,
                () -> coolingPeriodService.updateConsumeAttempts(
                        identifiers,
                        1,
                        Duration.ofMinutes(10)
                )
        );

        assertEquals("Unable to update consume attempts", ex.getMessage());
        assertNotNull(ex.getCause());
    }

    // =====================================================================
    //             updateConsumeAttempts() — save() fails → main exception thrown
    // =====================================================================
    @Test
    void updateConsumeAttempts_shouldThrowRuntimeException_whenSaveFails() {

        when(coolingPeriodDetailsRepository.findById(identifiers))
                .thenReturn(Optional.empty());

        when(coolingPeriodDetailsRepository.save(any(CoolingPeriodDetailsEntity.class)))
                .thenThrow(new RuntimeException("Database error"));

        RuntimeException ex = assertThrows(
                RuntimeException.class,
                () -> coolingPeriodService.updateConsumeAttempts(
                        identifiers,
                        1,
                        Duration.ofMinutes(10)
                )
        );

        assertEquals("Unable to update consume attempts", ex.getMessage());
        assertNotNull(ex.getCause());
    }

    // =====================================================================
    //             getExpireAt() — exists
    // =====================================================================
    @Test
    void getExpireAt_shouldReturnExpireAt_whenEntityExists() {

        Date expire = new Date();

        CoolingPeriodDetailsEntity entity =
                CoolingPeriodDetailsEntity.builder()
                        .id(identifiers)
                        .expireAt(expire)
                        .build();

        when(coolingPeriodDetailsRepository.findById(identifiers))
                .thenReturn(Optional.of(entity));

        assertEquals(expire, coolingPeriodService.getExpireAt(identifiers));
        verify(coolingPeriodDetailsRepository).findById(identifiers);

        assertEquals("9876543210", entity.getId().get("mobile"));
    }

    // =====================================================================
    //             getExpireAt() — does NOT exist
    // =====================================================================
    @Test
    void getExpireAt_shouldReturnCurrentDate_whenEntityDoesNotExist() {

        when(coolingPeriodDetailsRepository.findById(identifiers))
                .thenReturn(Optional.empty());

        Date before = new Date();
        Date result = coolingPeriodService.getExpireAt(identifiers);
        Date after = new Date();

        assertFalse(result.before(before));
        assertFalse(result.after(after));

        verify(coolingPeriodDetailsRepository).findById(identifiers);
    }

    // =====================================================================
    //             deleteEntity() — should delete all IDs
    // =====================================================================
    @Test
    void deleteEntity_shouldDeleteAllIdentifiers() {

        Map<String, String> id1 = Map.of("mobile", "1111111111");
        Map<String, String> id2 = Map.of("mobile", "2222222222");

        coolingPeriodService.deleteEntity(List.of(id1, id2));

        verify(coolingPeriodDetailsRepository).deleteByMapId(id1);
        verify(coolingPeriodDetailsRepository).deleteByMapId(id2);
    }

    // =====================================================================
    //             deleteEntity() — repository failure should NOT throw
    // =====================================================================
    @Test
    void deleteEntity_shouldNotThrow_whenRepositoryFails() {

        Map<String, String> id = Map.of("mobile", "1111111111");

        doThrow(new RuntimeException("Database error"))
                .when(coolingPeriodDetailsRepository)
                .deleteByMapId(id);

        assertDoesNotThrow(() -> coolingPeriodService.deleteEntity(List.of(id)));

        verify(coolingPeriodDetailsRepository).deleteByMapId(id);
    }

    // =====================================================================
    //             deleteEntity() — empty list should do nothing
    // =====================================================================
    @Test
    void deleteEntity_shouldDoNothing_whenIdentifiersListIsEmpty() {

        coolingPeriodService.deleteEntity(Collections.emptyList());

        verify(coolingPeriodDetailsRepository, never())
                .deleteByMapId(anyMap());
    }

    @Test
    void updateConsumeAttempts_shouldPreserveCauseWhenUpdatingExistingEntryFails() {
        CoolingPeriodDetailsEntity entity = CoolingPeriodDetailsEntity.builder().id(identifiers).build();
        when(coolingPeriodDetailsRepository.findById(identifiers)).thenReturn(Optional.of(entity));
        IllegalStateException failure = new IllegalStateException("Update failed");
        when(coolingPeriodDetailsRepository.updateAttempts(eq(identifiers), any(Date.class), eq(4), any(Date.class)))
                .thenThrow(failure);

        IllegalStateException exception = assertThrows(IllegalStateException.class,
                () -> coolingPeriodService.updateConsumeAttempts(identifiers, 4, Duration.ofMinutes(1)));

        assertSame(failure, exception.getCause());
        verify(coolingPeriodDetailsRepository, never()).save(any());
    }

    @ParameterizedTest
    @ValueSource(longs = {0, -1})
    void updateConsumeAttempts_shouldPreserveZeroAndNegativeTtlBehavior(long seconds) {
        when(coolingPeriodDetailsRepository.findById(identifiers)).thenReturn(Optional.empty());
        Duration ttl = Duration.ofSeconds(seconds);
        long earliestExpiry = System.currentTimeMillis() + ttl.toMillis();

        coolingPeriodService.updateConsumeAttempts(identifiers, 1, ttl);

        long latestExpiry = System.currentTimeMillis() + ttl.toMillis();
        ArgumentCaptor<CoolingPeriodDetailsEntity> saved = ArgumentCaptor.forClass(CoolingPeriodDetailsEntity.class);
        verify(coolingPeriodDetailsRepository).save(saved.capture());
        assertTrue(saved.getValue().getExpireAt().getTime() >= earliestExpiry);
        assertTrue(saved.getValue().getExpireAt().getTime() <= latestExpiry);
        assertEquals(1, saved.getValue().getNoOfAttempts());
        assertEquals(identifiers, saved.getValue().getId());
    }
}
