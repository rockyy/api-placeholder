package com.hdfcbank.giftcity.bff.commons.handler;

import com.hdfcbank.giftcity.bff.commons.config.JourneyConfigProperties;
import com.hdfcbank.giftcity.bff.commons.utility.TextSanityUtil;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class HandlersFactoryTest {

    private HandlersFactory handlersFactory;
    private JourneyConfigProperties journeyConfigProperties;
    private List<JourneyHandler> handlers;

    private Handler<?> handlerA;
    private Handler<?> handlerB;
    private Handler<?> handlerC;

    @BeforeEach
    void setup() {
        journeyConfigProperties = new JourneyConfigProperties();

        // Create a JourneyConfig entry
        JourneyConfigProperties.JourneyConfig config = new JourneyConfigProperties.JourneyConfig();
        config.setHandlers(List.of(
                Handler.HandlerName.CREATE_CUSTOMER.name(),
                Handler.HandlerName.CREATE_ACCOUNT.name()
        ));

        journeyConfigProperties.setJourneys(Map.of("JOURNEY_X", config));

        // Mock handlers
        handlerA = mock(Handler.class);
        when(handlerA.getType()).thenReturn(Handler.HandlerType.CUSTOMER_POST_SUBMIT);
        when(handlerA.getName()).thenReturn(Handler.HandlerName.CREATE_CUSTOMER);

        handlerB = mock(Handler.class);
        when(handlerB.getType()).thenReturn(Handler.HandlerType.BACKGROUND_TASKS_POST_SUBMIT_SUCCESS);
        when(handlerB.getName()).thenReturn(Handler.HandlerName.CREATE_ACCOUNT);

        handlerC = mock(Handler.class);
        when(handlerC.getType()).thenReturn(Handler.HandlerType.CUSTOMER_POST_SUBMIT);
        when(handlerC.getName()).thenReturn(Handler.HandlerName.RISK_ANALYSIS); // Not allowed

        handlers = List.of(handlerA, handlerB, handlerC);

        handlersFactory = new HandlersFactory(handlers, journeyConfigProperties);
    }

    // getHandlers(): correct filtering by type + name list
    @Test
    void testGetHandlersFiltering() {
        List<JourneyHandler> result =
                handlersFactory.getHandlers("JOURNEY_X", Handler.HandlerType.CUSTOMER_POST_SUBMIT);

        // Only CREATE_CUSTOMER matches both type + allowed names
        assertEquals(1, result.size());
        assertTrue(result.contains(handlerA));
    }

    // getHandlers(): type matches but name not in config → excluded
    @Test
    void testGetHandlersExcludesUnknownName() {
        List<JourneyHandler> result =
                handlersFactory.getHandlers("JOURNEY_X", Handler.HandlerType.CUSTOMER_POST_SUBMIT);

        assertFalse(result.contains(handlerC)); // RISK_ANALYSIS not in allowed list
    }

    // getHandlers(): second type
    @Test
    void testGetHandlersForSecondType() {
        List<JourneyHandler> result =
                handlersFactory.getHandlers("JOURNEY_X", Handler.HandlerType.BACKGROUND_TASKS_POST_SUBMIT_SUCCESS);

        // Only CREATE_ACCOUNT matches
        assertEquals(1, result.size());
        assertTrue(result.contains(handlerB));
    }

    @Test
    void testGetHandlersPreservesDifferentResultTypes() {
        when(handlerB.getType()).thenReturn(Handler.HandlerType.CUSTOMER_POST_SUBMIT);
        HandlerContext context = HandlerContext.builder().build();
        HandlerResult<String> customerResult = HandlerResult.of(null, "CUSTOMER_123", true);
        HandlerResult<Integer> accountResult = HandlerResult.of(null, 123, false);
        doReturn(customerResult).when(handlerA).handle(context);
        doReturn(accountResult).when(handlerB).handle(context);

        List<JourneyHandler> result =
                handlersFactory.getHandlers("JOURNEY_X", Handler.HandlerType.CUSTOMER_POST_SUBMIT);

        assertEquals(List.of(handlerA, handlerB), result);
        assertSame(customerResult, result.get(0).handle(context));
        assertSame(accountResult, result.get(1).handle(context));
    }

    @Test
    void testSpringInjectsRegisteredHandlers() {
        try (AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext()) {
            context.registerBean(JourneyConfigProperties.class, () -> journeyConfigProperties);
            context.registerBean("handlerA", Handler.class, () -> handlerA);
            context.registerBean("handlerB", Handler.class, () -> handlerB);
            context.register(HandlersFactory.class);
            context.refresh();

            HandlersFactory factory = context.getBean(HandlersFactory.class);
            assertEquals(List.of(handlerA),
                    factory.getHandlers("JOURNEY_X", Handler.HandlerType.CUSTOMER_POST_SUBMIT));
            assertEquals(Optional.of(handlerB), factory.getHandlers("JOURNEY_X",
                    Handler.HandlerType.BACKGROUND_TASKS_POST_SUBMIT_SUCCESS,
                    Handler.HandlerName.CREATE_ACCOUNT.name()));
        }
    }

    // getHandlers(journeyName, type, handlerName)
    @Test
    void testGetSpecificHandler() {

        try (MockedStatic<TextSanityUtil> mocked = Mockito.mockStatic(TextSanityUtil.class)) {

            mocked.when(() -> TextSanityUtil.sanitize("JOURNEY_X"))
                    .thenReturn("JOURNEY_X");

            Optional<JourneyHandler> result =
                    handlersFactory.getHandlers(
                            "JOURNEY_X",
                            Handler.HandlerType.CUSTOMER_POST_SUBMIT,
                            Handler.HandlerName.CREATE_CUSTOMER.name()
                    );

            assertTrue(result.isPresent());
            assertEquals(handlerA, result.get());
        }
    }

    // getHandlers(journeyName, type, handlerName): no match
    @Test
    void testGetSpecificHandlerNoMatch() {

        try (MockedStatic<TextSanityUtil> mocked = Mockito.mockStatic(TextSanityUtil.class)) {

            mocked.when(() -> TextSanityUtil.sanitize("JOURNEY_X"))
                    .thenReturn("JOURNEY_X");

            Optional<JourneyHandler> result =
                    handlersFactory.getHandlers(
                            "JOURNEY_X",
                            Handler.HandlerType.CUSTOMER_POST_SUBMIT,
                            "NOT_REAL"
                    );

            assertTrue(result.isEmpty());
        }
    }
}
