package com.hdfcbank.giftcity.bff.application.handlers.background;

import ch.qos.logback.classic.Level;
import ch.qos.logback.classic.Logger;
import org.slf4j.LoggerFactory;

import com.hdfcbank.adapters.clients.feign.communication.CommunicationFeignClient;
import com.hdfcbank.adapters.vo.*;
import com.hdfcbank.common.models.vo.core.ApiResponseStatus;
import com.hdfcbank.common.models.vo.journey.JourneyData;
import com.hdfcbank.common.models.vo.journey.Profile;
import com.hdfcbank.giftcity.bff.commons.enums.CommonJourneyStates;
import com.hdfcbank.giftcity.bff.commons.exception.handler.DownstreamResponseHandler;
import com.hdfcbank.giftcity.bff.commons.file.InlineImage;
import com.hdfcbank.giftcity.bff.commons.handler.Handler;
import com.hdfcbank.giftcity.bff.commons.handler.HandlerContext;
import com.hdfcbank.giftcity.bff.commons.handler.HandlerResult;
import com.hdfcbank.giftcity.bff.commons.model.CustomValidationStatus;
import com.hdfcbank.giftcity.bff.commons.model.FcIndiaProfile;
import com.hdfcbank.giftcity.bff.commons.utility.EmailHeaderAttachmentUtil;
import com.hdfcbank.giftcity.bff.commons.utility.TextSanityUtil;
import com.hdfcbank.giftcity.bff.customer.utility.CustomerUtil;

import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;

import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;

import org.springframework.web.multipart.MultipartFile;

import java.util.*;

import static com.hdfcbank.giftcity.bff.commons.constant.CommonConstants.EMAIL_TEMPLATE;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class FtsRejectedAccountEmailHandlerTest {

    //             MUTE ALL LOGS FOR THIS TEST CLASS ONLY
    @BeforeAll
    static void muteLogs() {
        Logger root = (Logger) LoggerFactory.getLogger(Logger.ROOT_LOGGER_NAME);
        root.setLevel(Level.OFF);
    }

    @Mock
    private CommunicationFeignClient communicationFeignClient;

    @Mock
    private EmailHeaderAttachmentUtil emailHeaderAttachmentUtil;

    @InjectMocks
    private FtsRejectedAccountEmailHandler handler;

    private JourneyData journeyData;
    private HandlerContext ctx;

    @BeforeEach
    void setup() {

        Profile profile = Profile.builder()
                .emailId("test@mail.com")
                .build();

        journeyData = JourneyData.builder()
                .journeyId("JID123")
                .journeyName("GIFT_CITY")
                .isd("+91")
                .mobileNumber("9999999999")
                .profile(profile)
                .build();

        ctx = HandlerContext.builder()
                .journeyData(journeyData)
                .properties(Map.of(EMAIL_TEMPLATE, "TEMPLATE001"))
                .build();
    }

    @Test
    void preConditions_shouldReturnTrueAlways() {
        assertTrue(handler.preConditions(ctx));
    }

    @Test
    void handle_shouldReturnSuccess_whenEmailStatusIs0000() {

        MultipartFile file = mock(MultipartFile.class);

        when(emailHeaderAttachmentUtil.prepareInlineImage(anyString(), anyString(), anyString()))
                .thenReturn(new InlineImage("CID1", file));

        UploadAttachmentResponse.UploadAttachmentDetail detail =
                UploadAttachmentResponse.UploadAttachmentDetail.builder()
                        .filename("img1.png")
                        .reference("ref1")
                        .imageCidName("CID1")
                        .build();

        UploadAttachmentResponse uploadResp = new UploadAttachmentResponse();
        uploadResp.setData(detail);

        when(communicationFeignClient.uploadAttachmentFile(any(), eq("JID123")))
                .thenReturn(uploadResp);

        ApiResponseStatus status = new ApiResponseStatus();
        status.setCode("0000");
        status.setMessage("SUCCESS");

        EmailMessageSuccess successResponse = EmailMessageSuccess.builder()
                .status(status)
                .data(EmailMessageSuccess.EmailResponse.builder().success(true).build())
                .build();

        when(communicationFeignClient.sendEmail(any(), eq("JID123")))
                .thenReturn(successResponse);

        try (MockedStatic<CustomerUtil> cust = mockStatic(CustomerUtil.class);
             MockedStatic<TextSanityUtil> san = mockStatic(TextSanityUtil.class)) {

            FcIndiaProfile.Profile fc = FcIndiaProfile.Profile.builder()
                    .name("John")
                    .build();

            cust.when(() -> CustomerUtil.getPrimaryProfile(journeyData))
                    .thenReturn(Optional.of(fc));

            san.when(() -> TextSanityUtil.sanitize(anyString()))
                    .thenReturn("CleanTemplate");

            HandlerResult<EmailMessageSuccess> result = handler.handle(ctx);

            assertTrue(result.isSuccess());
            assertEquals("0000", result.getResult().getStatus().getCode());
        }
    }

    @Test
    void handle_shouldFail_whenUploadAttachmentReturnsNull() {

        MultipartFile file = mock(MultipartFile.class);

        when(emailHeaderAttachmentUtil.prepareInlineImage(anyString(), anyString(), anyString()))
                .thenReturn(new InlineImage("CIDX", file));

        when(communicationFeignClient.uploadAttachmentFile(any(), eq("JID123")))
                .thenReturn(null);

        CustomValidationStatus customStatus = new CustomValidationStatus();
        customStatus.setCode("500");
        customStatus.setMessage("UPLOAD_NULL");

        try (MockedStatic<CustomerUtil> cust = mockStatic(CustomerUtil.class);
             MockedStatic<TextSanityUtil> san = mockStatic(TextSanityUtil.class);
             MockedStatic<DownstreamResponseHandler> dsh = mockStatic(DownstreamResponseHandler.class)) {

            FcIndiaProfile.Profile fc = FcIndiaProfile.Profile.builder()
                    .name("AAA")
                    .build();

            cust.when(() -> CustomerUtil.getPrimaryProfile(journeyData))
                    .thenReturn(Optional.of(fc));

            san.when(() -> TextSanityUtil.sanitize(anyString()))
                    .thenReturn("Clean");

            dsh.when(() -> DownstreamResponseHandler.handleResponse(
                            eq(null),
                            eq(Handler.HandlerName.FTS_REJECT_CALLBACK_EMAIL.name()),
                            eq(false),
                            eq("GIFT_CITY")))
                    .thenReturn(customStatus);

            HandlerResult<EmailMessageSuccess> result = handler.handle(ctx);

            assertFalse(result.isSuccess());
            assertEquals("500", result.getApiResponseStatus().getCode());
        }
    }

    @Test
    void handle_shouldFail_whenUploadResponseDataIsNull() {

        MultipartFile file = mock(MultipartFile.class);

        when(emailHeaderAttachmentUtil.prepareInlineImage(anyString(), anyString(), anyString()))
                .thenReturn(new InlineImage("CIDX", file));

        UploadAttachmentResponse upload = new UploadAttachmentResponse();
        upload.setData(null);

        when(communicationFeignClient.uploadAttachmentFile(any(), eq("JID123")))
                .thenReturn(upload);

        CustomValidationStatus customStatus = new CustomValidationStatus();
        customStatus.setCode("400");
        customStatus.setMessage("DATA_NULL");

        try (MockedStatic<CustomerUtil> cust = mockStatic(CustomerUtil.class);
             MockedStatic<TextSanityUtil> san = mockStatic(TextSanityUtil.class);
             MockedStatic<DownstreamResponseHandler> dsh = mockStatic(DownstreamResponseHandler.class)) {

            FcIndiaProfile.Profile fc =
                    FcIndiaProfile.Profile.builder().name("Bob").build();

            cust.when(() -> CustomerUtil.getPrimaryProfile(journeyData))
                    .thenReturn(Optional.of(fc));

            san.when(() -> TextSanityUtil.sanitize(anyString()))
                    .thenReturn("Clean");

            dsh.when(() -> DownstreamResponseHandler.handleResponse(
                    eq(null),
                    eq(Handler.HandlerName.FTS_REJECT_CALLBACK_EMAIL.name()),
                    eq(false),
                    eq("GIFT_CITY")
            )).thenReturn(customStatus);

            HandlerResult<EmailMessageSuccess> result = handler.handle(ctx);

            assertFalse(result.isSuccess());
            assertEquals("400", result.getApiResponseStatus().getCode());
        }
    }

    @Test
    void handle_shouldFail_whenEmailStatusIsNot0000() {

        MultipartFile file = mock(MultipartFile.class);

        when(emailHeaderAttachmentUtil.prepareInlineImage(anyString(), anyString(), anyString()))
                .thenReturn(new InlineImage("CID1", file));

        UploadAttachmentResponse.UploadAttachmentDetail detail =
                UploadAttachmentResponse.UploadAttachmentDetail.builder()
                        .filename("f1.png")
                        .reference("ref1")
                        .imageCidName("CID1")
                        .build();

        UploadAttachmentResponse uploadResp = new UploadAttachmentResponse();
        uploadResp.setData(detail);

        when(communicationFeignClient.uploadAttachmentFile(any(), eq("JID123")))
                .thenReturn(uploadResp);

        ApiResponseStatus st = new ApiResponseStatus();
        st.setCode("9999");
        st.setMessage("FAILED");

        EmailMessageSuccess failResponse = EmailMessageSuccess.builder()
                .status(st)
                .build();

        when(communicationFeignClient.sendEmail(any(), eq("JID123")))
                .thenReturn(failResponse);

        CustomValidationStatus custom = new CustomValidationStatus();
        custom.setCode("ERR");
        custom.setMessage("EMAIL_FAILED");

        try (MockedStatic<CustomerUtil> cust = mockStatic(CustomerUtil.class);
             MockedStatic<TextSanityUtil> san = mockStatic(TextSanityUtil.class);
             MockedStatic<DownstreamResponseHandler> dsh = mockStatic(DownstreamResponseHandler.class)) {

            FcIndiaProfile.Profile fc = FcIndiaProfile.Profile.builder().name("Mike").build();

            cust.when(() -> CustomerUtil.getPrimaryProfile(journeyData))
                    .thenReturn(Optional.of(fc));

            san.when(() -> TextSanityUtil.sanitize(anyString()))
                    .thenReturn("Clean");

            dsh.when(() -> DownstreamResponseHandler.handleResponse(
                    eq(failResponse),
                    eq(Handler.HandlerName.FTS_REJECT_CALLBACK_EMAIL.name()),
                    eq(false),
                    eq("GIFT_CITY")
            )).thenReturn(custom);

            HandlerResult<EmailMessageSuccess> result = handler.handle(ctx);

            assertFalse(result.isSuccess());
            assertEquals("ERR", result.getApiResponseStatus().getCode());
        }
    }

    @Test
    void handle_shouldFail_whenExceptionThrown() {

        MultipartFile file = mock(MultipartFile.class);

        when(emailHeaderAttachmentUtil.prepareInlineImage(anyString(), anyString(), anyString()))
                .thenReturn(new InlineImage("CID1", file));

        when(communicationFeignClient.uploadAttachmentFile(any(), eq("JID123")))
                .thenThrow(new RuntimeException("Boom"));

        CustomValidationStatus custom = new CustomValidationStatus();
        custom.setCode("EX");
        custom.setMessage("EXCEPTION");

        try (MockedStatic<CustomerUtil> cust = mockStatic(CustomerUtil.class);
             MockedStatic<TextSanityUtil> san = mockStatic(TextSanityUtil.class);
             MockedStatic<DownstreamResponseHandler> dsh = mockStatic(DownstreamResponseHandler.class)) {

            FcIndiaProfile.Profile fc =
                    FcIndiaProfile.Profile.builder().name("Zed").build();

            cust.when(() -> CustomerUtil.getPrimaryProfile(journeyData))
                    .thenReturn(Optional.of(fc));

            san.when(() -> TextSanityUtil.sanitize(anyString()))
                    .thenReturn("Clean");

            dsh.when(() -> DownstreamResponseHandler.handleResponse(
                    eq(null),
                    eq(Handler.HandlerName.FTS_REJECT_CALLBACK_EMAIL.name()),
                    eq(false),
                    eq("GIFT_CITY")
            )).thenReturn(custom);

            HandlerResult<EmailMessageSuccess> result = handler.handle(ctx);

            assertFalse(result.isSuccess());
            assertEquals("EX", result.getApiResponseStatus().getCode());
        }
    }

    @Test
    void enumCoverage() {

        assertEquals(
                Handler.HandlerType.BACKGROUND_TASKS_POST_SUBMIT_SUCCESS,
                handler.getType()
        );

        assertEquals(
                Handler.HandlerName.FTS_REJECT_CALLBACK_EMAIL,
                handler.getName()
        );

        assertEquals(
                CommonJourneyStates.FTS_REJECT_CALLBACK_EMAIL_ALERT_SUCCESS,
                handler.successState()
        );

        assertEquals(
                CommonJourneyStates.FTS_REJECT_CALLBACK_EMAIL_ALERT_FAILURE,
                handler.failureState()
        );
    }
}