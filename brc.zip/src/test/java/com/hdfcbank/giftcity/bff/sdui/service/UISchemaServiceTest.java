package com.hdfcbank.giftcity.bff.sdui.service;

import com.hdfcbank.common.models.vo.core.ApiResponse;
import com.hdfcbank.common.models.vo.core.ApiResponseStatusCode;
import com.hdfcbank.exception.DownstreamApiException;

import com.hdfcbank.giftcity.bff.commons.config.SduiConfiguration;
import com.hdfcbank.giftcity.bff.sdui.entity.UISchemaEntity;
import com.hdfcbank.giftcity.bff.sdui.feign.DataSourceFeignClient;
import com.hdfcbank.giftcity.bff.sdui.feign.DynamicFeignFactory;
import com.hdfcbank.giftcity.bff.sdui.model.DataSource;
import com.hdfcbank.giftcity.bff.sdui.model.Header;
import com.hdfcbank.giftcity.bff.sdui.model.UiSchemaApiResponse;
import com.hdfcbank.giftcity.bff.sdui.repository.UISchemaRepository;

import feign.FeignException;
import feign.Request;
import feign.Response;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import org.mockito.Mock;
import org.mockito.ArgumentCaptor;
import org.mockito.junit.jupiter.MockitoExtension;

import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;

import tools.jackson.databind.JsonNode;
import tools.jackson.databind.ObjectMapper;
import tools.jackson.databind.node.ObjectNode;

import java.nio.charset.StandardCharsets;
import java.util.*;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
class UISchemaServiceTest {

    @Mock private UISchemaRepository schemaRepository;
    @Mock private DynamicFeignFactory dynamicFeignFactory;
    @Mock private DataSourceFeignClient feignClient;
    @Mock private SduiConfiguration sduiConfiguration;

    private ObjectMapper objectMapper;
    private UISchemaService uiSchemaService;

    @BeforeEach
    void setup() {
        objectMapper = new ObjectMapper();
        uiSchemaService = new UISchemaService(
                schemaRepository,
                dynamicFeignFactory,
                sduiConfiguration,
                objectMapper
        );

        // Disable logging
        ch.qos.logback.classic.Logger logger =
                (ch.qos.logback.classic.Logger) LoggerFactory.getLogger(UISchemaService.class);
        logger.setLevel(ch.qos.logback.classic.Level.OFF);
    }

                    
    //                 TEST 1 — getUISchemaEntity() → entity found
                    
    @Test
    void getUISchemaEntity_shouldReturnSchema() {
        UISchemaEntity entity = new UISchemaEntity();
        when(schemaRepository.findByPageAndSchemaVersion("pageA", "v1"))
                .thenReturn(Optional.of(entity));

        UISchemaEntity result = uiSchemaService.getUISchemaEntity("pageA", "v1");

        assertNotNull(result);
        assertEquals(entity, result);
        verify(schemaRepository, times(1))
                .findByPageAndSchemaVersion("pageA", "v1");
    }

                    
    //                 TEST 2 — getUISchemaEntity() → entity not found
                    
    @Test
    void getUISchemaEntity_shouldReturnNullWhenNotFound() {
        when(schemaRepository.findByPageAndSchemaVersion("pageA", "v1"))
                .thenReturn(Optional.empty());

        UISchemaEntity result = uiSchemaService.getUISchemaEntity("pageA", "v1");

        assertNull(result);
        verify(schemaRepository, times(1))
                .findByPageAndSchemaVersion("pageA", "v1");
    }

                    
    //                 TEST 3 — missing schema
                    
    @Test
    void getPageDetails_shouldReturnNoDataWhenSchemaMissing() {
        when(sduiConfiguration.getVersion()).thenReturn("v1");
        when(schemaRepository.findByPageAndSchemaVersion("pageA", "v1"))
                .thenReturn(Optional.empty());

        ResponseEntity<UiSchemaApiResponse> response =
                uiSchemaService.getPageDetails("pageA", objectMapper.createObjectNode());

        UiSchemaApiResponse body = response.getBody();

        assertNotNull(body);
        assertNotNull(body.getStatus());
        assertEquals(ApiResponseStatusCode.INVALID_REQUEST.getCode(), body.getStatus().getCode());
        assertEquals("Ui Schema not found", body.getStatus().getErrors().get(0));
        assertEquals(1, body.getStatus().getErrors().size());
        assertNull(body.getData());
    }

                    
    //                 TEST 4 — no data sources
                    
    @Test
    void getPageDetails_shouldReturnNoDataWhenDataSourcesEmpty() {

        UISchemaEntity entity = new UISchemaEntity();
        entity.setDataSources(Collections.emptyList());

        when(sduiConfiguration.getVersion()).thenReturn("v1");
        when(schemaRepository.findByPageAndSchemaVersion("pageA", "v1"))
                .thenReturn(Optional.of(entity));

        ResponseEntity<UiSchemaApiResponse> response =
                uiSchemaService.getPageDetails("pageA", objectMapper.createObjectNode());

        UiSchemaApiResponse body = response.getBody();

        assertNotNull(body);
        assertEquals(ApiResponseStatusCode.INVALID_REQUEST.getCode(), body.getStatus().getCode());
        assertEquals("No data found", body.getStatus().getErrors().get(0));
        assertEquals(1, body.getStatus().getErrors().size());
        assertNull(body.getData());
    }

                    
    //                 TEST 5 — successful response after fetching data sources
                    
    @Test
    void getPageDetails_shouldReturnSuccessResponseWhenDataFetched() {

        UISchemaEntity entity = new UISchemaEntity();
        entity.setSchemaJson(Map.of("layout", "test"));
        entity.setDataSources(List.of("ds1"));

        when(sduiConfiguration.getVersion()).thenReturn("v1");
        when(schemaRepository.findByPageAndSchemaVersion("pageA", "v1"))
                .thenReturn(Optional.of(entity));

        DataSource ds = new DataSource();
        ds.setUrl("http://localhost/ds1");

        when(sduiConfiguration.getDataSources()).thenReturn(Map.of("ds1", ds));

        JsonNode mockNode = objectMapper.createObjectNode().put("key", "value");

        ApiResponse<JsonNode> apiResponse = new ApiResponse<>();
        apiResponse.setData(mockNode);

        when(dynamicFeignFactory.getClient(eq("http://localhost/ds1"), any()))
                .thenReturn(feignClient);
        when(feignClient.callDataSourceAPI(any())).thenReturn(apiResponse);

        ResponseEntity<UiSchemaApiResponse> res =
                uiSchemaService.getPageDetails("pageA", objectMapper.createObjectNode());

        UiSchemaApiResponse body = res.getBody();

        assertNotNull(body);
        assertEquals(ApiResponseStatusCode.SUCCESS.getCode(), body.getStatus().getCode());
        assertNotNull(body.getData());
        assertTrue(body.getData().has("ds1"));
        assertEquals("value", body.getData().get("ds1").get("key").textValue());
    }

                    
    //                 TEST 6 — skip invalid URLs
                    
    @Test
    void fetchDataSources_shouldSkipInvalidUrls() {

        UISchemaEntity entity = new UISchemaEntity();
        entity.setDataSources(List.of("dsX"));

        when(sduiConfiguration.getVersion()).thenReturn("v1");
        when(schemaRepository.findByPageAndSchemaVersion("pageA", "v1"))
                .thenReturn(Optional.of(entity));

        DataSource invalid = new DataSource();
        invalid.setUrl(" ");

        when(sduiConfiguration.getDataSources()).thenReturn(Map.of("dsX", invalid));

        ResponseEntity<UiSchemaApiResponse> response =
                uiSchemaService.getPageDetails("pageA", objectMapper.createObjectNode());

        UiSchemaApiResponse body = response.getBody();

        assertNotNull(body);
        assertEquals(ApiResponseStatusCode.INVALID_REQUEST.getCode(), body.getStatus().getCode());
        assertEquals("No data found", body.getStatus().getErrors().get(0));
        assertNull(body.getData());
    }

                    
    //                 TEST 7 — FeignException → DownstreamApiException
                    
    @Test
    void callDataSource_shouldThrowDownstreamApiException_onFeignError() {

        UISchemaEntity entity = new UISchemaEntity();
        entity.setDataSources(List.of("ds1"));

        when(sduiConfiguration.getVersion()).thenReturn("v1");
        when(schemaRepository.findByPageAndSchemaVersion("pageA", "v1"))
                .thenReturn(Optional.of(entity));

        DataSource ds = new DataSource();
        ds.setUrl("http://bad-url");

        when(sduiConfiguration.getDataSources()).thenReturn(Map.of("ds1", ds));

        Response rawResponse = Response.builder()
                .status(500)
                .reason("Internal")
                .request(Request.create(
                        Request.HttpMethod.POST,
                        "http://bad-url",
                        Collections.emptyMap(),
                        null,
                        StandardCharsets.UTF_8))
                .build();

        FeignException feignEx =
                FeignException.errorStatus("POST http://bad-url", rawResponse);

        when(dynamicFeignFactory.getClient(eq("http://bad-url"), any()))
                .thenThrow(feignEx);

        assertThrows(DownstreamApiException.class,
                () -> uiSchemaService.getPageDetails("pageA", objectMapper.createObjectNode()));

        verify(dynamicFeignFactory, times(1)).getClient(eq("http://bad-url"), any());
    }

                    
    //                 TEST 8 — generic exception → DownstreamApiException
                    
    @Test
    void callDataSource_shouldThrowUnknownError_onGenericException() {

        UISchemaEntity entity = new UISchemaEntity();
        entity.setDataSources(List.of("ds1"));

        when(sduiConfiguration.getVersion()).thenReturn("v1");
        when(schemaRepository.findByPageAndSchemaVersion("pageA", "v1"))
                .thenReturn(Optional.of(entity));

        DataSource ds = new DataSource();
        ds.setUrl("http://url");

        when(sduiConfiguration.getDataSources()).thenReturn(Map.of("ds1", ds));
        when(dynamicFeignFactory.getClient(eq("http://url"), any())).thenReturn(feignClient);
        when(feignClient.callDataSourceAPI(any())).thenThrow(new RuntimeException("Unexpected"));

        ObjectNode root = objectMapper.createObjectNode();
        root.putObject("dataSources").putObject("ds1");

        assertThrows(DownstreamApiException.class,
                () -> uiSchemaService.getPageDetails("pageA", root));
    }

                    
    //                 TEST 9 — validate request parsing and feign call
                    
    @Test
    void buildRequest_shouldParseHeadersAndBodyCorrectly() {

        ObjectNode root = objectMapper.createObjectNode();
        ObjectNode ds1Req = root.putObject("dataSources").putObject("ds1");
        ds1Req.putObject("body").put("id", 77);
        ds1Req.putArray("headers").addObject()
                .put("key", "X-Correlation-ID").put("value", "request-77");

        UISchemaEntity entity = new UISchemaEntity();
        entity.setDataSources(List.of("ds1"));
        entity.setSchemaJson(Map.of("x", "y"));

        DataSource ds = new DataSource();
        ds.setUrl("http://localhost");

        when(sduiConfiguration.getVersion()).thenReturn("v1");
        when(schemaRepository.findByPageAndSchemaVersion("pageA", "v1"))
                .thenReturn(Optional.of(entity));

        when(sduiConfiguration.getDataSources()).thenReturn(Map.of("ds1", ds));

        ApiResponse<JsonNode> apiResponse = new ApiResponse<>();
        apiResponse.setData(objectMapper.createObjectNode().put("status", "OK"));

        when(dynamicFeignFactory.getClient(eq("http://localhost"), any()))
                .thenReturn(feignClient);
        when(feignClient.callDataSourceAPI(any())).thenReturn(apiResponse);

        ResponseEntity<UiSchemaApiResponse> response =
                uiSchemaService.getPageDetails("pageA", root);

        UiSchemaApiResponse body = response.getBody();

        assertNotNull(body);
        assertEquals(ApiResponseStatusCode.SUCCESS.getCode(), body.getStatus().getCode());
        assertNotNull(body.getData());
        assertEquals("OK", body.getData().get("ds1").get("status").textValue());

        @SuppressWarnings("unchecked")
        ArgumentCaptor<List<Header>> headers = ArgumentCaptor.forClass(List.class);
        verify(dynamicFeignFactory).getClient(eq("http://localhost"), headers.capture());
        assertEquals(1, headers.getValue().size());
        assertEquals("X-Correlation-ID", headers.getValue().get(0).getKey());
        assertEquals("request-77", headers.getValue().get(0).getValue());
        verify(feignClient).callDataSourceAPI(eq(ds1Req.get("body")));
    }

    @Test
    void getPageDetails_shouldSkipUnconfiguredDataSource() {
        configureDataSources(List.of("unknown"), Map.of());

        UiSchemaApiResponse response = uiSchemaService.getPageDetails("pageA", null).getBody();

        assertNotNull(response);
        assertEquals(ApiResponseStatusCode.INVALID_REQUEST.getCode(), response.getStatus().getCode());
        verifyNoInteractions(dynamicFeignFactory, feignClient);
    }

    @Test
    void getPageDetails_shouldReturnNoDataWhenDownstreamResponseIsNull() {
        DataSource source = new DataSource();
        source.setUrl("http://localhost");
        configureDataSources(List.of("ds1"), Map.of("ds1", source));
        when(dynamicFeignFactory.getClient(eq(source.getUrl()), isNull())).thenReturn(feignClient);
        when(feignClient.callDataSourceAPI(any())).thenReturn(null);

        UiSchemaApiResponse response = uiSchemaService.getPageDetails("pageA", null).getBody();

        assertNotNull(response);
        assertEquals("No data found", response.getStatus().getErrors().get(0));
        verify(feignClient).callDataSourceAPI(eq(objectMapper.createObjectNode()));
    }

    @Test
    void getPageDetails_shouldAggregateMultipleDataSources() {
        DataSource first = new DataSource();
        first.setUrl("http://first");
        DataSource second = new DataSource();
        second.setUrl("http://second");
        configureDataSources(List.of("ds1", "ds2"), Map.of("ds1", first, "ds2", second));
        DataSourceFeignClient secondClient = mock(DataSourceFeignClient.class);
        when(dynamicFeignFactory.getClient(eq(first.getUrl()), isNull())).thenReturn(feignClient);
        when(dynamicFeignFactory.getClient(eq(second.getUrl()), isNull())).thenReturn(secondClient);
        ApiResponse<JsonNode> firstResponse = new ApiResponse<>();
        firstResponse.setData(objectMapper.createObjectNode().put("name", "first"));
        ApiResponse<JsonNode> secondResponse = new ApiResponse<>();
        secondResponse.setData(objectMapper.createObjectNode().put("name", "second"));
        when(feignClient.callDataSourceAPI(any())).thenReturn(firstResponse);
        when(secondClient.callDataSourceAPI(any())).thenReturn(secondResponse);

        UiSchemaApiResponse response = uiSchemaService.getPageDetails("pageA", null).getBody();

        assertNotNull(response);
        assertEquals(ApiResponseStatusCode.SUCCESS.getCode(), response.getStatus().getCode());
        assertEquals("first", response.getData().get("ds1").get("name").textValue());
        assertEquals("second", response.getData().get("ds2").get("name").textValue());
        assertEquals(2, response.getData().size());
    }

    private void configureDataSources(List<String> requested, Map<String, DataSource> configured) {
        UISchemaEntity entity = new UISchemaEntity();
        entity.setDataSources(requested);
        entity.setSchemaJson(Map.of("page", "test"));
        when(sduiConfiguration.getVersion()).thenReturn("v1");
        when(schemaRepository.findByPageAndSchemaVersion("pageA", "v1"))
                .thenReturn(Optional.of(entity));
        when(sduiConfiguration.getDataSources()).thenReturn(configured);
    }
}
