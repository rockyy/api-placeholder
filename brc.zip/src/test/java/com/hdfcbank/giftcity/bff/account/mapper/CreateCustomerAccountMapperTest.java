package com.hdfcbank.giftcity.bff.account.mapper;

import com.hdfcbank.common.models.vo.journey.JourneyData;
import com.hdfcbank.common.models.vo.journey.JourneyDetail;
import com.hdfcbank.giftcity.bff.commons.constant.CommonConstants;
import com.hdfcbank.giftcity.bff.commons.model.FcIndiaProfile;
import com.hdfcbank.giftcity.bff.customer.constants.CustomerConstants;
import com.hdfcbank.giftcity.bff.customer.model.ReviewCustomerResponse;
import com.hdfcbank.giftcity.bff.customer.utility.CustomerUtil;
import com.hdfcbank.giftcity.bff.infrastructure.service.JourneyService;
import com.hdfcbank.service.adapters.vo.account.CreateCustomerAccountRequest;

import org.junit.jupiter.api.*;
import org.mapstruct.factory.Mappers;
import org.mockito.MockedStatic;

import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

class CreateCustomerAccountMapperTest {

    private CreateCustomerAccountMapper mapper;

    @BeforeEach
    void setUp() {
        mapper = Mappers.getMapper(CreateCustomerAccountMapper.class);
    }

    @Test
    void testGetValue() {
        Map<String,String> defaults = new HashMap<>();
        defaults.put(CommonConstants.BRANCH_CODE, "BR001");

        assertEquals("BR001", mapper.getValue(defaults, CommonConstants.BRANCH_CODE));
        assertNull(mapper.getValue(null, CommonConstants.BRANCH_CODE));
    }

    @Test
    void testBuildStateCity() {
        assertEquals("MH, Mumbai", mapper.buildStateCity("MH", "Mumbai"));
        assertEquals("MH", mapper.buildStateCity("MH", ""));
        assertNull(mapper.buildStateCity("", ""));
    }

    @Test
    void testGetAlternateAccountNumber() {
        FcIndiaProfile.Profile profile = FcIndiaProfile.Profile.builder().build();

        assertNull(mapper.getAlternateAccountNumber(profile));

        FcIndiaProfile.CustomerAccountDetail detail =
                FcIndiaProfile.CustomerAccountDetail.builder()
                        .accountNumber("ACC123")
                        .build();

        profile.setCustomerAccountDetails(List.of(detail));

        assertEquals("ACC123", mapper.getAlternateAccountNumber(profile));
    }

    @Test
    void testMapUdfDetails() {

        JourneyDetail jd = JourneyDetail.builder().domainData(new HashMap<>()).build();
        JourneyData journeyData = JourneyData.builder().journeyDetail(jd).build();

        Map<String,Object> pageInputs = new HashMap<>();
        pageInputs.put(CustomerConstants.LG_CODE_PATH, "LG999");

        try (MockedStatic<JourneyService> js = mockStatic(JourneyService.class)) {

            js.when(() -> JourneyService.getDomainPageUserInputs(any(), eq(CustomerConstants.REVIEW_DETAILS)))
                    .thenReturn(pageInputs);

            Map<String,String> defaults = new HashMap<>();
            defaults.put(CommonConstants.BRANCH_CODE, "BR001");
            defaults.put(CommonConstants.BRANCH_NAME, "MainBranch");

            List<CreateCustomerAccountRequest.UdfDetail> udfDetails =
                    mapper.mapUdfDetails(journeyData, defaults);

            assertNotNull(udfDetails);
            assertEquals(3, udfDetails.size());
        }
    }

    @Test
    void testMapUdfDetails_nullOrEmpty() {

        JourneyData journeyData = JourneyData.builder().journeyDetail(new JourneyDetail()).build();

        try (MockedStatic<JourneyService> js = mockStatic(JourneyService.class)) {

            js.when(() -> JourneyService.getDomainPageUserInputs(any(), anyString()))
                    .thenReturn(null);

            assertNull(mapper.mapUdfDetails(journeyData, new HashMap<>()));

            js.when(() -> JourneyService.getDomainPageUserInputs(any(), anyString()))
                    .thenReturn(Collections.emptyMap());

            assertNull(mapper.mapUdfDetails(journeyData, new HashMap<>()));
        }
    }

    @Test
    void testMapNominee_nonMinor() {

        ReviewCustomerResponse.ReviewCustomerDetails.Nominee nominee =
                ReviewCustomerResponse.ReviewCustomerDetails.Nominee.builder()
                        .name("NomineeName")
                        .relation("Sibling")
                        .dob("2000-01-01")
                        .addressLine1("A1")
                        .addressLine2("A2")
                        .addressLine3("A3")
                        .addressLine4("A4")
                        .pincode("400001")
                        .build();

        JourneyData journeyData = JourneyData.builder().build();

        List<CreateCustomerAccountRequest.Nominee> list =
                mapper.mapNominee(false, nominee, null, journeyData);

        assertNotNull(list);
        assertEquals(1, list.size());

        CreateCustomerAccountRequest.NomineeDetails nd = list.get(0).getNomineeDetails();

        assertEquals("NomineeName", nd.getNomineeName());
        assertEquals("Sibling", nd.getRelationshipType());
        assertEquals("2000-01-01", nd.getDateOfBirth());
        assertEquals("400001", nd.getPinCode());
        assertEquals(CommonConstants.NO, nd.getMinorFlag());
    }

    @Test
    void testMapNominee_minor() {

        ReviewCustomerResponse.ReviewCustomerDetails.Nominee nominee =
                ReviewCustomerResponse.ReviewCustomerDetails.Nominee.builder()
                        .name("ChildNominee")
                        .relation("Son")
                        .dob("2010-05-05")
                        .pincode("400002")
                        .build();

        ReviewCustomerResponse.ReviewCustomerDetails.Nominee guardian =
                ReviewCustomerResponse.ReviewCustomerDetails.Nominee.builder()
                        .name("GuardianName")
                        .relation("Parent")
                        .pincode("400003")
                        .build();

        JourneyData journeyData = JourneyData.builder().build();

        List<CreateCustomerAccountRequest.Nominee> list =
                mapper.mapNominee(true, nominee, guardian, journeyData);

        assertEquals(1, list.size());
        assertNotNull(list.get(0).getGuardianDetails());
        assertEquals("Parent", list.get(0).getGuardianDetails().getGuardianRelationship());
    }

    @Test
    void testNomineeAddressFromProfile_true() {

        JourneyDetail detail = JourneyDetail.builder().build();
        JourneyData journeyData = JourneyData.builder().journeyDetail(detail).build();

        ReviewCustomerResponse.ReviewCustomerDetails.Nominee nominee =
                ReviewCustomerResponse.ReviewCustomerDetails.Nominee.builder()
                        .addressLine1("X1")
                        .addressLine2("X2")
                        .addressLine3("X3")
                        .addressLine4("X4")
                        .build();

        ReviewCustomerResponse.ReviewCustomerDetails.NomineeDetail nd =
                ReviewCustomerResponse.ReviewCustomerDetails.NomineeDetail.builder()
                        .nominee(nominee)
                        .minorNominee(false)
                        .build();

        try (MockedStatic<CustomerUtil> cu = mockStatic(CustomerUtil.class)) {

            cu.when(() -> CustomerUtil.getNomineeDetailFromJourneyData(any()))
                    .thenReturn(nd);

            cu.when(() -> CustomerUtil.getValueByPath(any(), anyString(), anyString()))
                    .thenReturn(null);

            cu.when(() -> CustomerUtil.getValueByPath(
                            any(),
                            eq(CustomerConstants.NOMINEE_DETAILS),
                            eq(CustomerConstants.NOMINEE_ADDRESS_FROM_PROFILE_PATH)))
                    .thenReturn("true");

            assertEquals("X1", mapper.getNomineeAddressLine1(journeyData));
            assertEquals("X2", mapper.getNomineeAddressLine2(journeyData));
            assertEquals("X3", mapper.getNomineeAddressLine3(journeyData));
            assertEquals("X4", mapper.getNomineeAddressLine4(journeyData));
        }
    }

    @Test
    void testNomineeAddressFromProfile_false() {

        JourneyData journeyData = JourneyData.builder().build();

        try (MockedStatic<CustomerUtil> cu = mockStatic(CustomerUtil.class)) {

            cu.when(() -> CustomerUtil.getNomineeDetailFromJourneyData(any()))
                    .thenReturn(null);

            cu.when(() -> CustomerUtil.getValueByPath(any(), anyString(), anyString()))
                    .thenReturn("ADDR_VALUE");

            cu.when(() -> CustomerUtil.getValueByPath(
                            any(),
                            eq(CustomerConstants.NOMINEE_DETAILS),
                            eq(CustomerConstants.NOMINEE_ADDRESS_FROM_PROFILE_PATH)))
                    .thenReturn("false");

            assertEquals("ADDR_VALUE", mapper.getNomineeAddressLine1(journeyData));
        }
    }

    @Test
    void testGuardianAddressNotSame() {

        JourneyData journeyData = JourneyData.builder().build();

        try (MockedStatic<CustomerUtil> cu = mockStatic(CustomerUtil.class)) {

            cu.when(() -> CustomerUtil.getValueByPath(
                            any(),
                            eq(CustomerConstants.NOMINEE_DETAILS),
                            eq(CustomerConstants.GUARDIAN_ADDRESS_SAME_AS_NOMINEE_PATH)))
                    .thenReturn("false");

            cu.when(() -> CustomerUtil.getValueByPath(any(), anyString(), anyString()))
                    .thenReturn("GG1");

            assertEquals("GG1", mapper.getGuardianAddress1(journeyData));
        }
    }

    @Test
    void testToRequest_basic() {

        JourneyData journeyData = JourneyData.builder()
                .journeyDetail(new JourneyDetail())
                .build();

        FcIndiaProfile.Profile profile = FcIndiaProfile.Profile.builder()
                .name("John Doe")
                .mailingAddress1("A1")
                .mailingAddress2("A2")
                .mailingAddress3("A3")
                .build();

        ReviewCustomerResponse.ReviewCustomerDetails.Nominee nominee =
                ReviewCustomerResponse.ReviewCustomerDetails.Nominee.builder()
                        .name("Nominee")
                        .relation("Sibling")
                        .pincode("400001")
                        .dob("2000-01-01")
                        .build();

        ReviewCustomerResponse.ReviewCustomerDetails.NomineeDetail nd =
                ReviewCustomerResponse.ReviewCustomerDetails.NomineeDetail.builder()
                        .minorNominee(false)
                        .nominee(nominee)
                        .build();

        ReviewCustomerResponse.ReviewCustomerDetails.Nominee guardian =
                ReviewCustomerResponse.ReviewCustomerDetails.Nominee.builder().build();

        Map<String,String> defaults = new HashMap<>();
        defaults.put(CommonConstants.BRANCH_CODE, "BR001");
        defaults.put(CommonConstants.ACCOUNT_CLASS, "AC01");
        defaults.put(CommonConstants.LOCATION, "LOC1");
        defaults.put(CommonConstants.COMMUNICATION_MEDIA, "EMAIL");
        defaults.put(CommonConstants.ACCOUNT_TYPE, "TYPE1");
        defaults.put(CommonConstants.NO_CREDIT_STATUS, "N");
        defaults.put(CommonConstants.NO_DEBIT_STATUS, "N");

        try (MockedStatic<CustomerUtil> cu = mockStatic(CustomerUtil.class)) {

            cu.when(() -> CustomerUtil.getValueByPath(any(), anyString(), anyString()))
                    .thenReturn(null);

            cu.when(() -> CustomerUtil.getNomineeDetailFromJourneyData(any()))
                    .thenReturn(nd);

            CreateCustomerAccountRequest req =
                    mapper.toRequest(
                            journeyData,
                            "C123",
                            profile,
                            nd,
                            nominee,
                            guardian,
                            defaults,
                            "USD"
                    );

            assertNotNull(req);
            assertEquals("BR001", req.getBranchCode());
            assertEquals("AC01", req.getAccountClass());
            assertEquals("LOC1", req.getLocation());
            assertEquals("EMAIL", req.getCommunicationMedia());
            assertEquals("TYPE1", req.getAccountType());
        }
    }
}