package com.hdfcbank.giftcity.bff.account.service;

import com.hdfcbank.common.models.vo.core.ApiResponseStatus;
import com.hdfcbank.common.models.vo.journey.JourneyData;
import com.hdfcbank.common.models.vo.journey.JourneyDetail;
import com.hdfcbank.giftcity.bff.account.mapper.NomineeResponseMapper;
import com.hdfcbank.giftcity.bff.account.model.NomineeResponse;
import com.hdfcbank.giftcity.bff.commons.config.JourneyContextHolder;
import com.hdfcbank.giftcity.bff.commons.enums.JourneyPageName;
import com.hdfcbank.giftcity.bff.commons.exception.handler.DownstreamResponseHandler;
import com.hdfcbank.giftcity.bff.commons.model.FcIndiaProfile;
import com.hdfcbank.giftcity.bff.infrastructure.service.JourneyService;
import com.hdfcbank.service.adapters.clients.feign.account.AccountServiceFeignClient;
import com.hdfcbank.service.adapters.vo.account.NomineeApiResponse;
import com.hdfcbank.service.adapters.vo.account.NomineeApiResponse.NomineeDtlsDTO;
import com.hdfcbank.service.adapters.vo.account.NomineeRequest;
import com.hdfcbank.service.adapters.vo.account.FTSApplicationInquireApiResponse;
import com.hdfcbank.service.adapters.vo.account.FTSApplicationInquireRequest;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class AccountServiceGetNomineeTest {

    @Mock
    private AccountServiceFeignClient feignClient;

    @Mock
    private NomineeResponseMapper nomineeMapper;

    @InjectMocks
    private AccountService accountService;

    @AfterEach
    void clearJourneyContext() {
        JourneyContextHolder.clear();
    }

    // 1: Missing profile → Downstream handler throws
    @Test
    void testGetNominee_missingProfile_throws() {

        JourneyData jd = new JourneyData();
        jd.setJourneyName("JOURNEY_X");

        try (MockedStatic<JourneyContextHolder> jchMock = mockStatic(JourneyContextHolder.class);
             MockedStatic<JourneyService> jsMock = mockStatic(JourneyService.class);
             MockedStatic<DownstreamResponseHandler> drhMock = mockStatic(DownstreamResponseHandler.class)) {

            jchMock.when(JourneyContextHolder::getJourneyData).thenReturn(jd);
            jsMock.when(() ->
                            JourneyService.extractFromJourney(any(), any(), any(), any()))
                    .thenReturn(Optional.empty());

            drhMock.when(() ->
                            DownstreamResponseHandler.handleResponse(
                                    any(), anyString(), eq(true), eq("JOURNEY_X")))
                    .thenThrow(new RuntimeException("PROFILE_MISSING"));

            RuntimeException ex = assertThrows(RuntimeException.class,
                    () -> accountService.getNominee("J123"));

            assertEquals("PROFILE_MISSING", ex.getMessage());
            assertEquals("JOURNEY_X", jd.getJourneyName());
        }
    }

    // 2: Empty AccountDetails → must throw
    @Test
    void testGetNominee_emptyAccountList_throws() {

        JourneyData jd = new JourneyData();
        jd.setJourneyName("JOURNEY_X");

        FcIndiaProfile.Profile profile =
                FcIndiaProfile.Profile.builder()
                        .customerAccountDetails(Collections.emptyList())
                        .build();

        try (MockedStatic<JourneyContextHolder> jchMock = mockStatic(JourneyContextHolder.class);
             MockedStatic<JourneyService> jsMock = mockStatic(JourneyService.class);
             MockedStatic<DownstreamResponseHandler> drhMock = mockStatic(DownstreamResponseHandler.class)) {

            jchMock.when(JourneyContextHolder::getJourneyData).thenReturn(jd);
            jsMock.when(() ->
                            JourneyService.extractFromJourney(any(), any(), any(), any()))
                    .thenReturn(Optional.of(profile));

            drhMock.when(() ->
                            DownstreamResponseHandler.handleResponse(any(), anyString(), eq(true), eq("JOURNEY_X")))
                    .thenThrow(new RuntimeException("ACC_LIST_EMPTY"));

            RuntimeException ex = assertThrows(RuntimeException.class,
                    () -> accountService.getNominee("J123"));

            assertEquals("ACC_LIST_EMPTY", ex.getMessage());
            assertTrue(profile.getCustomerAccountDetails().isEmpty());
        }
    }

    // 3: Highest balance selected correctly
    @Test
    void testGetNominee_selectHighestBalance() {

        JourneyData jd = new JourneyData();
        jd.setJourneyName("JOURNEY_X");

        FcIndiaProfile.CustomerAccountDetail acc1 =
                FcIndiaProfile.CustomerAccountDetail.builder()
                        .accountNumber("ACC1")
                        .availableBalance("100")
                        .build();

        FcIndiaProfile.CustomerAccountDetail acc2 =
                FcIndiaProfile.CustomerAccountDetail.builder()
                        .accountNumber("ACC2")
                        .availableBalance("9000")
                        .build();

        FcIndiaProfile.Profile profile =
                FcIndiaProfile.Profile.builder()
                        .customerAccountDetails(List.of(acc1, acc2))
                        .build();

        NomineeDtlsDTO dto = new NomineeDtlsDTO();
        dto.setRatSharePct("50");

        NomineeApiResponse api = new NomineeApiResponse();
        api.setStatus(ApiResponseStatus.success());
        api.setData(List.of(dto));

        NomineeResponse mapped = new NomineeResponse();

        try (MockedStatic<JourneyContextHolder> jch = mockStatic(JourneyContextHolder.class);
             MockedStatic<JourneyService> js = mockStatic(JourneyService.class)) {

            jch.when(JourneyContextHolder::getJourneyData).thenReturn(jd);
            js.when(() ->
                            JourneyService.extractFromJourney(any(), any(), any(), any()))
                    .thenReturn(Optional.of(profile));

            when(feignClient.fetchNominees(any(NomineeRequest.class), eq("J123")))
                    .thenReturn(api);

            when(nomineeMapper.toResponse(dto)).thenReturn(mapped);

            NomineeResponse res = accountService.getNominee("J123");

            assertNotNull(res);
            assertEquals(mapped, res);
            assertEquals("50", dto.getRatSharePct());
            assertEquals(ApiResponseStatus.success().getCode(), api.getStatus().getCode());
            assertEquals(ApiResponseStatus.success().getMessage(), api.getStatus().getMessage());

            ArgumentCaptor<NomineeRequest> captor = ArgumentCaptor.forClass(NomineeRequest.class);
            verify(feignClient, times(1)).fetchNominees(captor.capture(), eq("J123"));

            assertEquals("ACC2", captor.getValue().getAccountNo());
        }
    }

    // 4: API Status FAIL → Downstream throws
    @Test
    void testGetNominee_apiFailure_throws() {

        JourneyData jd = new JourneyData();
        jd.setJourneyName("JOURNEY_X");

        FcIndiaProfile.CustomerAccountDetail acc =
                FcIndiaProfile.CustomerAccountDetail.builder()
                        .accountNumber("ACC1")
                        .availableBalance("100")
                        .build();

        FcIndiaProfile.Profile profile =
                FcIndiaProfile.Profile.builder()
                        .customerAccountDetails(List.of(acc))
                        .build();

        NomineeApiResponse api = new NomineeApiResponse();
        api.setStatus(ApiResponseStatus.businessValidationError(null));
        api.setData(new ArrayList<>());

        try (MockedStatic<JourneyContextHolder> jch = mockStatic(JourneyContextHolder.class);
             MockedStatic<JourneyService> js = mockStatic(JourneyService.class);
             MockedStatic<DownstreamResponseHandler> drh = mockStatic(DownstreamResponseHandler.class)) {

            jch.when(JourneyContextHolder::getJourneyData).thenReturn(jd);
            js.when(() ->
                            JourneyService.extractFromJourney(any(), any(), any(), any()))
                    .thenReturn(Optional.of(profile));

            when(feignClient.fetchNominees(any(), eq("J123"))).thenReturn(api);

            drh.when(() ->
                            DownstreamResponseHandler.handleResponse(any(), anyString(), eq(true), eq("JOURNEY_X")))
                    .thenThrow(new RuntimeException("API_FAIL"));

            RuntimeException ex = assertThrows(RuntimeException.class,
                    () -> accountService.getNominee("J123"));

            assertEquals("API_FAIL", ex.getMessage());
            assertTrue(api.getData().isEmpty());
        }
    }

    // 5: Empty Nominee List → throws
    @Test
    void testGetNominee_emptyNomineeList_throws() {

        JourneyData jd = new JourneyData();
        jd.setJourneyName("JOURNEY_X");

        FcIndiaProfile.CustomerAccountDetail acc =
                FcIndiaProfile.CustomerAccountDetail.builder()
                        .accountNumber("ACC1")
                        .availableBalance("100")
                        .build();

        FcIndiaProfile.Profile profile =
                FcIndiaProfile.Profile.builder()
                        .customerAccountDetails(List.of(acc))
                        .build();

        NomineeApiResponse api = new NomineeApiResponse();
        api.setStatus(ApiResponseStatus.success());
        api.setData(Collections.emptyList());

        try (MockedStatic<JourneyContextHolder> jch = mockStatic(JourneyContextHolder.class);
             MockedStatic<JourneyService> js = mockStatic(JourneyService.class);
             MockedStatic<DownstreamResponseHandler> drh = mockStatic(DownstreamResponseHandler.class)) {

            jch.when(JourneyContextHolder::getJourneyData).thenReturn(jd);
            js.when(() ->
                            JourneyService.extractFromJourney(any(), any(), any(), any()))
                    .thenReturn(Optional.of(profile));

            when(feignClient.fetchNominees(any(), eq("J123"))).thenReturn(api);

            drh.when(() ->
                            DownstreamResponseHandler.handleResponse(any(), anyString(), eq(true), eq("JOURNEY_X")))
                    .thenThrow(new RuntimeException("EMPTY_LIST"));

            RuntimeException ex = assertThrows(RuntimeException.class,
                    () -> accountService.getNominee("J123"));

            assertEquals("EMPTY_LIST", ex.getMessage());
            assertTrue(api.getData().isEmpty());
        }
    }

    // 6: Full Success
    @Test
    void testGetNominee_success() {

        JourneyData jd = new JourneyData();
        jd.setJourneyName("JOURNEY_X");

        FcIndiaProfile.CustomerAccountDetail acc =
                FcIndiaProfile.CustomerAccountDetail.builder()
                        .accountNumber("ACC1")
                        .availableBalance("100")
                        .build();

        FcIndiaProfile.Profile profile =
                FcIndiaProfile.Profile.builder()
                        .customerAccountDetails(List.of(acc))
                        .build();

        NomineeDtlsDTO dto = new NomineeDtlsDTO();
        dto.setRatSharePct("90");

        NomineeApiResponse api = new NomineeApiResponse();
        api.setStatus(ApiResponseStatus.success());
        api.setData(List.of(dto));

        NomineeResponse mapped = new NomineeResponse();

        try (MockedStatic<JourneyContextHolder> jch = mockStatic(JourneyContextHolder.class);
             MockedStatic<JourneyService> js = mockStatic(JourneyService.class)) {

            jch.when(JourneyContextHolder::getJourneyData).thenReturn(jd);
            js.when(() ->
                            JourneyService.extractFromJourney(any(), any(), any(), any()))
                    .thenReturn(Optional.of(profile));

            when(feignClient.fetchNominees(any(), eq("J123"))).thenReturn(api);
            when(nomineeMapper.toResponse(dto)).thenReturn(mapped);

            NomineeResponse res = accountService.getNominee("J123");

            assertNotNull(res);
            assertEquals(mapped, res);
            assertEquals("90", dto.getRatSharePct());
            assertEquals("ACC1", profile.getCustomerAccountDetails().get(0).getAccountNumber());
        }
    }

    // ---------------------------------------------------------------------
    // ftsApplicationInquire() tests
    // ---------------------------------------------------------------------

    @Test
    void testFtsApplicationInquire_success() {

        FTSApplicationInquireRequest req = new FTSApplicationInquireRequest();
        FTSApplicationInquireApiResponse resp = new FTSApplicationInquireApiResponse();

        when(feignClient.applicationInquire(req, "J123")).thenReturn(resp);

        assertEquals(resp, accountService.ftsApplicationInquire(req, "J123"));
        verify(feignClient, times(1)).applicationInquire(req, "J123");
    }

    @Test
    void testFtsApplicationInquire_feignThrows() {

        FTSApplicationInquireRequest req = new FTSApplicationInquireRequest();

        when(feignClient.applicationInquire(req, "J123"))
                .thenThrow(new RuntimeException("BackendDown"));

        RuntimeException ex = assertThrows(RuntimeException.class,
                () -> accountService.ftsApplicationInquire(req, "J123"));

        assertEquals("BackendDown", ex.getMessage());
        verify(feignClient, times(1)).applicationInquire(req, "J123");
    }

    @Test
    void getNominee_shouldExtractJourneyAndSelectHighestBalanceAndNonNullShare() {
        Map<String, Object> profile = Map.of("customerAccountDetails", List.of(
                Map.of("accountNumber", "ZERO-BALANCE"),
                Map.of("accountNumber", "HIGH-BALANCE", "availableBalance", "100.50")));
        JourneyDetail detail = new JourneyDetail();
        detail.setSystemData(Map.of(JourneyPageName.CUSTOMER_FC_INDIA_DETAIL.getPageName(),
                Map.of("profiles", List.of(profile))));
        JourneyData journey = new JourneyData();
        journey.setJourneyName("JOURNEY_X");
        journey.setJourneyDetail(detail);
        JourneyContextHolder.setJourneyData(journey);

        NomineeDtlsDTO missingShare = new NomineeDtlsDTO();
        NomineeDtlsDTO smallerShare = new NomineeDtlsDTO();
        smallerShare.setRatSharePct("20");
        NomineeDtlsDTO largerShare = new NomineeDtlsDTO();
        largerShare.setRatSharePct("80");
        NomineeApiResponse downstream = new NomineeApiResponse();
        downstream.setStatus(ApiResponseStatus.success());
        downstream.setData(List.of(missingShare, smallerShare, largerShare));
        when(feignClient.fetchNominees(any(), eq("J-SELECT"))).thenReturn(downstream);
        NomineeResponse expected = new NomineeResponse();
        when(nomineeMapper.toResponse(largerShare)).thenReturn(expected);

        assertSame(expected, accountService.getNominee("J-SELECT"));

        ArgumentCaptor<NomineeRequest> request = ArgumentCaptor.forClass(NomineeRequest.class);
        verify(feignClient).fetchNominees(request.capture(), eq("J-SELECT"));
        assertEquals("HIGH-BALANCE", request.getValue().getAccountNo());
        verify(nomineeMapper, only()).toResponse(largerShare);
    }
}
