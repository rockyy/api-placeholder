package com.hdfcbank.giftcity.bff;

import com.hdfcbank.security.utils.SSLHelperUtil;
import org.junit.jupiter.api.Test;
import org.mockito.MockedStatic;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.scheduling.annotation.EnableScheduling;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class GiftcityGatewayBFFApplicationTest {

    @Test
    void test_annotations_present() {
        //               Verifies class-level annotations are present (covers class loading)
        assertTrue(GiftcityGatewayBFFApplication.class.isAnnotationPresent(SpringBootApplication.class));
        assertTrue(GiftcityGatewayBFFApplication.class.isAnnotationPresent(EnableCaching.class));
        assertTrue(GiftcityGatewayBFFApplication.class.isAnnotationPresent(EnableScheduling.class));
        assertTrue(GiftcityGatewayBFFApplication.class.isAnnotationPresent(ComponentScan.class));

        EnableFeignClients feign = GiftcityGatewayBFFApplication.class.getAnnotation(EnableFeignClients.class);
        assertNotNull(feign);
        assertArrayEquals(new String[]{"com.hdfcbank"}, feign.basePackages());
    }

    @Test
    void test_main_method_runs_without_starting_spring() {

        try (
                MockedStatic<SSLHelperUtil> sslMock = mockStatic(SSLHelperUtil.class);
                MockedStatic<SpringApplication> springMock = mockStatic(SpringApplication.class)
        ) {
            //               Prevent real SSL setup
            sslMock.when(SSLHelperUtil::setupSSLProperties).thenAnswer(inv -> null);

            //               Prevent the actual Spring context from starting
            springMock.when(() -> SpringApplication.run(GiftcityGatewayBFFApplication.class, new String[]{}))
                    .thenReturn(null);

            //               Execute main (covers entire main method)
            GiftcityGatewayBFFApplication.main(new String[]{});

            //               Both methods must be invoked exactly once
            sslMock.verify(SSLHelperUtil::setupSSLProperties, times(1));

            springMock.verify(
                    () -> SpringApplication.run(GiftcityGatewayBFFApplication.class, new String[]{}),
                    times(1)
            );
        }
    }

    @Test
    void test_class_instantiation() {
        //               Covers class constructor invocation
        GiftcityGatewayBFFApplication app = new GiftcityGatewayBFFApplication();
        assertNotNull(app);
    }
}