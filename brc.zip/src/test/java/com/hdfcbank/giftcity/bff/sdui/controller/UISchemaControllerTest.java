package com.hdfcbank.giftcity.bff.sdui.controller;

import com.hdfcbank.giftcity.bff.sdui.model.UiSchemaApiResponse;
import com.hdfcbank.giftcity.bff.sdui.service.UISchemaService;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.ResponseEntity;
import tools.jackson.databind.JsonNode;
import tools.jackson.databind.ObjectMapper;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.*;

class UISchemaControllerTest {

    @Mock
    private UISchemaService schemaService;

    @InjectMocks
    private UISchemaController controller;

    private final ObjectMapper mapper = new ObjectMapper();

    UISchemaControllerTest() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testGetSchemaWithData_WithBody() throws Exception {

        String pageId = "dashboard";
        JsonNode body = mapper.readTree("{\"key\":\"value\"}");

        UiSchemaApiResponse response = UiSchemaApiResponse.builder().build();

        when(schemaService.getPageDetails(pageId, body))
                .thenReturn(ResponseEntity.ok(response));

        ResponseEntity<UiSchemaApiResponse> result =
                controller.getSchemaWithData(pageId, body);

        assertThat(result.getStatusCode().value()).isEqualTo(200);
        assertThat(result.getBody()).isEqualTo(response);

        verify(schemaService, times(1))
                .getPageDetails(pageId, body);
    }

    @Test
    void testGetSchemaWithData_NoBody() {

        String pageId = "home";

        UiSchemaApiResponse response = UiSchemaApiResponse.builder().build();

        when(schemaService.getPageDetails(pageId, null))
                .thenReturn(ResponseEntity.ok(response));

        ResponseEntity<UiSchemaApiResponse> result =
                controller.getSchemaWithData(pageId, null);

        assertThat(result.getStatusCode().value()).isEqualTo(200);
        assertThat(result.getBody()).isEqualTo(response);

        verify(schemaService, times(1))
                .getPageDetails(pageId, null);
    }
}