package com.hdfcbank.giftcity.bff.application.handlers.background;

import com.hdfcbank.common.models.vo.core.ApiResponseStatus;
import com.hdfcbank.common.models.vo.journey.JourneyData;
import com.hdfcbank.common.models.vo.journey.JourneyDetail;
import com.hdfcbank.common.models.vo.journey.JourneyState;
import com.hdfcbank.giftcity.bff.commons.config.JourneyConfigProperties;
import com.hdfcbank.giftcity.bff.commons.enums.CommonJourneyStates;
import com.hdfcbank.giftcity.bff.commons.exception.handler.DownstreamResponseHandler;
import com.hdfcbank.giftcity.bff.commons.handler.Handler;
import com.hdfcbank.giftcity.bff.commons.handler.HandlerContext;
import com.hdfcbank.giftcity.bff.commons.handler.HandlerResult;
import com.hdfcbank.giftcity.bff.commons.model.FtsDetails;
import com.hdfcbank.giftcity.bff.infrastructure.service.JourneyService;
import com.hdfcbank.model.SFTPTransferRequest;
import com.hdfcbank.model.SFTPTransferResponse;
import com.hdfcbank.service.SftpService;

import org.junit.jupiter.api.*;
import org.mockito.*;

import java.lang.reflect.Field;
import java.time.LocalDate;
import java.util.*;

import static com.hdfcbank.giftcity.bff.commons.enums.CommonJourneyStates.*;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import ch.qos.logback.classic.Logger;
import ch.qos.logback.classic.Level;
import org.slf4j.LoggerFactory;

class DpcftpUploadHandlerTest {

    /**        Clean test output — no logs printed */
    @BeforeAll
    static void muteHandlerLogs() {
        Logger logger = (Logger) LoggerFactory.getLogger(DpcftpUploadHandler.class);
        logger.setLevel(Level.OFF);
    }

    @Mock private SftpService sftpService;
    @Mock private JourneyService journeyService;

    @InjectMocks
    private DpcftpUploadHandler handler;

    private JourneyData journeyData;
    private HandlerContext context;

    @BeforeEach
    void setup() throws Exception {

        MockitoAnnotations.openMocks(this);

        JourneyState js = new JourneyState();
        js.setStateName(AOF_WITHOUT_ANNEXTURE_UPLOAD_SUCCESS.name());

        JourneyDetail detail = new JourneyDetail();
        detail.setJourneyStates(List.of(js));

        journeyData = new JourneyData();
        journeyData.setJourneyId("JX001");
        journeyData.setJourneyName("FTS Journey");
        journeyData.setReferenceNo("REF123");
        journeyData.setJourneyDetail(detail);

        context = HandlerContext.builder()
                .journeyData(journeyData)
                .build();

        // Fix static property NPE
        JourneyConfigProperties cfg = mock(JourneyConfigProperties.class);
        when(cfg.getJourneys()).thenReturn(Map.of());

        Field f = DownstreamResponseHandler.class.getDeclaredField("journeyConfigProperties");
        f.setAccessible(true);
        f.set(null, cfg);
    }

    @Test
    void testPreConditionsTrue() {
        assertTrue(handler.preConditions(context));
    }

    @Test
    void testPreConditionsFalse() {
        JourneyState wrong = new JourneyState();
        wrong.setStateName("OTHER_STATE");

        JourneyDetail d = new JourneyDetail();
        d.setJourneyStates(List.of(wrong));

        journeyData.setJourneyDetail(d);

        HandlerContext ctx = HandlerContext.builder()
                .journeyData(journeyData)
                .build();

        assertFalse(handler.preConditions(ctx));
    }

    @Test
    void testFailureWhenFTSDetailsMissing() {

        try (MockedStatic<JourneyService> mocked = mockStatic(JourneyService.class)) {

            mocked.when(() -> JourneyService.extractFromJourney(any(), anyString(), any()))
                    .thenReturn(Optional.empty());

            HandlerResult<SFTPTransferResponse> result = handler.handle(context);

            assertFalse(result.isSuccess());
            assertNull(result.getResult());
        }
    }

    @Test
    void testFailureWhenRequiredDocumentRefsMissing() {

        FtsDetails fts = new FtsDetails();

        try (MockedStatic<JourneyService> mocked = mockStatic(JourneyService.class)) {

            mocked.when(() -> JourneyService.extractFromJourney(any(), anyString(), any()))
                    .thenReturn(Optional.of(fts));

            HandlerResult<SFTPTransferResponse> result = handler.handle(context);

            assertFalse(result.isSuccess());
            assertNull(result.getResult());
        }
    }

    @Test
    void testSuccessFlow() throws Exception {

        FtsDetails fts = new FtsDetails();
        fts.setCustomerSignatureDocRef("SIG-001");
        fts.setAofWithAnnextureDocRef("AOF-ANNEX-001");
        fts.setAofWithoutAnnextureDocRef("AOF-WO-001");
        fts.setAccountStatement1DocRef(List.of("AS1-001", "AS1-002"));
        fts.setAccountStatement2DocRef(List.of("AS2-001"));

        ApiResponseStatus ok = new ApiResponseStatus();
        ok.setCode("0000");

        SFTPTransferResponse resp = SFTPTransferResponse.builder()
                .status(ok)
                .state(SFTPTransferResponse.State.SUCCESS)
                .uploadedFolderPath("/sftp/folder/REF123")
                .build();

        resp.setData(resp);

        try (MockedStatic<JourneyService> mocked = mockStatic(JourneyService.class)) {

            mocked.when(() -> JourneyService.extractFromJourney(any(), anyString(), any()))
                    .thenReturn(Optional.of(fts));

            when(sftpService.transferDocumentsToSftp(any(), any(), any()))
                    .thenReturn(resp);

            HandlerResult<SFTPTransferResponse> res = handler.handle(context);

            assertTrue(res.isSuccess());
            assertEquals("0000", res.getResult().getStatus().getCode());
            assertEquals("/sftp/folder/REF123", res.getResult().getUploadedFolderPath());

            verify(journeyService).updateJourney(
                    eq("JX001"),
                    eq("FtsDetails"),
                    any(FtsDetails.class),
                    eq(DPCFTP_UPLOAD_SUCCESS)
            );
        }
    }

    @Test
    void testFailureWhenSftpFails() throws Exception {

        FtsDetails fts = new FtsDetails();
        fts.setCustomerSignatureDocRef("SIG");
        fts.setAofWithAnnextureDocRef("AOFWITH");
        fts.setAofWithoutAnnextureDocRef("AOFWO");
        fts.setAccountStatement1DocRef(List.of("AS1"));
        fts.setAccountStatement2DocRef(List.of("AS2"));

        ApiResponseStatus fail = new ApiResponseStatus();
        fail.setCode("9999");

        SFTPTransferResponse failResp = SFTPTransferResponse.builder()
                .status(fail)
                .state(SFTPTransferResponse.State.FAILURE)
                .uploadedFolderPath(null)
                .build();

        try (MockedStatic<JourneyService> mocked = mockStatic(JourneyService.class)) {

            mocked.when(() -> JourneyService.extractFromJourney(any(), anyString(), any()))
                    .thenReturn(Optional.of(fts));

            when(sftpService.transferDocumentsToSftp(any(), any(), any()))
                    .thenReturn(failResp);

            HandlerResult<SFTPTransferResponse> result = handler.handle(context);

            assertFalse(result.isSuccess());
            assertNull(result.getResult());
            verify(journeyService, never()).updateJourney(any(), any(), any(), any());
        }
    }

    @Test
    void testExceptionFlow() throws Exception {

        FtsDetails fts = new FtsDetails();
        fts.setCustomerSignatureDocRef("SIG");
        fts.setAofWithAnnextureDocRef("AOFWITH");
        fts.setAofWithoutAnnextureDocRef("AOFWO");
        fts.setAccountStatement1DocRef(List.of("AS1"));
        fts.setAccountStatement2DocRef(List.of("AS2"));

        try (MockedStatic<JourneyService> mocked = mockStatic(JourneyService.class)) {

            mocked.when(() -> JourneyService.extractFromJourney(any(), anyString(), any()))
                    .thenReturn(Optional.of(fts));

            when(sftpService.transferDocumentsToSftp(any(), any(), any()))
                    .thenThrow(new RuntimeException("EXP"));

            HandlerResult<SFTPTransferResponse> result = handler.handle(context);

            assertFalse(result.isSuccess());
            assertNull(result.getResult());
        }
    }

    @Test
    void testMetadata() {
        assertEquals(Handler.HandlerType.BACKGROUND_TASKS_POST_SUBMIT_SUCCESS, handler.getType());
        assertEquals(Handler.HandlerName.DPCFTP_UPLOAD, handler.getName());
        assertEquals(DPCFTP_UPLOAD_SUCCESS, handler.successState());
        assertEquals(DPCFTP_UPLOAD_FAILURE, handler.failureState());
    }
}