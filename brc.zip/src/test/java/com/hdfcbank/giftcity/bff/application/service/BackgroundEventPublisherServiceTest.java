package com.hdfcbank.giftcity.bff.application.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.hdfcbank.giftcity.bff.application.events.BackgroundEvents;
import com.hdfcbank.giftcity.bff.application.events.SqsBackgroundTaskEvent;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.springframework.test.util.ReflectionTestUtils;
import software.amazon.awssdk.services.sqs.SqsClient;
import software.amazon.awssdk.services.sqs.model.MessageAttributeValue;
import software.amazon.awssdk.services.sqs.model.SendMessageRequest;
import software.amazon.awssdk.services.sqs.model.SendMessageResponse;

import java.util.Map;

import static com.hdfcbank.common.models.constant.CommonConstants.JOURNEY_ID;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.mockito.Mockito.*;

class BackgroundEventPublisherServiceTest {

    private ObjectMapper objectMapper;
    private SqsClient sqsClient;
    private BackgroundEventPublisherService service;

    @BeforeEach
    void setup() {
        objectMapper = mock(ObjectMapper.class);
        sqsClient = mock(SqsClient.class);

        service = new BackgroundEventPublisherService(objectMapper, sqsClient);

        ReflectionTestUtils.setField(
                service,
                "backgroundTasksQueue",
                "https://sqs.fake.amazonaws.com/123/background.fifo"
        );
    }

    @Test
    void testSendBackgroundEvent_success() throws Exception {

        String journeyId = "J123";
        String customerId = "C456";
        BackgroundEvents event = BackgroundEvents.RISK_ANALYSIS;
        Map<String, Object> props = Map.of("key", "value");

        SqsBackgroundTaskEvent payload = SqsBackgroundTaskEvent.builder()
                .journeyId(journeyId)
                .event(event)
                .properties(props)
                .build();

        String serialized = new ObjectMapper().writeValueAsString(payload);

        when(objectMapper.writeValueAsString(any())).thenReturn(serialized);

        SendMessageResponse sqsResponse = SendMessageResponse.builder()
                .messageId("MSG123")
                .md5OfMessageBody("md5hash")
                .build();

        when(sqsClient.sendMessage(any(SendMessageRequest.class)))
                .thenReturn(sqsResponse);

        service.sendBackgroundEvent(journeyId, customerId, event, props);

        ArgumentCaptor<SendMessageRequest> captor =
                ArgumentCaptor.forClass(SendMessageRequest.class);

        verify(sqsClient).sendMessage(captor.capture());
        SendMessageRequest request = captor.getValue();

        assertThat(request.queueUrl())
                .isEqualTo("https://sqs.fake.amazonaws.com/123/background.fifo");

        assertThat(request.messageBody()).isEqualTo(serialized);

        assertThat(request.messageGroupId()).isEqualTo("J123-C456");
        assertThat(request.messageDeduplicationId())
                .isEqualTo("J123-" + event.name());

        MessageAttributeValue mav = request.messageAttributes().get(JOURNEY_ID);
        assertThat(mav.dataType()).isEqualTo("String");
        assertThat(mav.stringValue()).isEqualTo(journeyId);

        ArgumentCaptor<SqsBackgroundTaskEvent> payloadCaptor =
                ArgumentCaptor.forClass(SqsBackgroundTaskEvent.class);
        verify(objectMapper).writeValueAsString(payloadCaptor.capture());
        assertThat(payloadCaptor.getValue().getJourneyId()).isEqualTo(journeyId);
        assertThat(payloadCaptor.getValue().getEvent()).isEqualTo(event);
        assertThat(payloadCaptor.getValue().getProperties()).isEqualTo(props);
    }

    @Test
    void sendBackgroundEvent_shouldNotSendWhenSerializationFails() throws Exception {
        when(objectMapper.writeValueAsString(any()))
                .thenThrow(new JsonProcessingException("Serialization failed") { });

        assertDoesNotThrow(() -> service.sendBackgroundEvent(
                "J777", "C999", BackgroundEvents.AOF_WITHOUT_ANNEXTURE_UPLOAD, Map.of()));

        verifyNoInteractions(sqsClient);
    }

    @Test
    void sendBackgroundEvent_shouldContainSqsFailure() throws Exception {
        when(objectMapper.writeValueAsString(any())).thenReturn("{}");
        when(sqsClient.sendMessage(any(SendMessageRequest.class)))
                .thenThrow(new IllegalStateException("SQS unavailable"));

        assertDoesNotThrow(() -> service.sendBackgroundEvent(
                "J777", "C999", BackgroundEvents.AOF_WITHOUT_ANNEXTURE_UPLOAD, Map.of()));

        verify(sqsClient).sendMessage(any(SendMessageRequest.class));
    }
}
