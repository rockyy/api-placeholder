package com.hdfcbank.giftcity.bff.commons.file;

import org.junit.jupiter.api.Test;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;

import static org.junit.jupiter.api.Assertions.*;

class Base64MultipartFileTest {

    @Test
    void testGetName() {
        MultipartFile file = new Base64MultipartFile("abc".getBytes(), "image/tif;base64");

        assertEquals("file", file.getName());

        // extra assertions
        assertNotNull(file.getName());
        assertFalse(file.getName().isBlank());
    }

    @Test
    void testGetOriginalFilename() {
        MultipartFile file = new Base64MultipartFile("abc".getBytes(), "image/tif;base64");

        assertEquals(Base64MultipartFile.IMAGE, file.getOriginalFilename());

        // extra assertions
        assertNotNull(file.getOriginalFilename());
        assertFalse(file.getOriginalFilename().isBlank());
    }

    @Test
    void testGetContentType() {
        MultipartFile file = new Base64MultipartFile("xyz".getBytes(), "image/png;base64,extra");

        assertEquals("image/png", file.getContentType());

        // extra assertions
        assertTrue(file.getContentType().startsWith("image"));
        assertFalse(file.getContentType().contains("base64"));
    }

    @Test
    void testIsEmptyWhenZeroBytes() throws Exception {
        MultipartFile file = new Base64MultipartFile(new byte[]{}, "image/png;base64");

        assertTrue(file.isEmpty());
        assertEquals(0, file.getBytes().length);
    }

    @Test
    void testNotEmpty() throws Exception {
        MultipartFile file = new Base64MultipartFile("abc".getBytes(), "image/png;base64");

        assertFalse(file.isEmpty());

        // extra assertions
        assertTrue(file.getSize() > 0);
        assertNotNull(file.getBytes());
    }

    @Test
    void testGetSize() {
        byte[] bytes = "hello".getBytes();
        MultipartFile file = new Base64MultipartFile(bytes, "image/png;base64");

        assertEquals(bytes.length, file.getSize());

        // extra assertions
        assertEquals(5, file.getSize());
        assertFalse(file.isEmpty());
    }

    @Test
    void testGetBytes() throws IOException {
        byte[] bytes = "world".getBytes();
        MultipartFile file = new Base64MultipartFile(bytes, "image/png;base64");

        assertArrayEquals(bytes, file.getBytes());

        // extra assertions
        assertEquals("world", new String(file.getBytes()));
        assertEquals(bytes.length, file.getBytes().length);
        assertNotNull(file.getBytes());
    }

    @Test
    void testGetInputStream() throws Exception {
        byte[] bytes = "stream".getBytes();
        MultipartFile file = new Base64MultipartFile(bytes, "image/png;base64");

        try (InputStream is = file.getInputStream()) {
            assertArrayEquals(bytes, is.readAllBytes());
        }

        try (InputStream is2 = file.getInputStream()) {
            assertEquals(bytes.length, is2.available());
        }
    }

    @Test
    void testTransferTo() throws Exception {
        byte[] bytes = "filedata".getBytes();
        MultipartFile file = new Base64MultipartFile(bytes, "image/png;base64");

        File temp = File.createTempFile("test", ".bin");
        temp.deleteOnExit();

        file.transferTo(temp);

        byte[] fileBytes = Files.readAllBytes(temp.toPath());
        assertArrayEquals(bytes, fileBytes);

        // extra assertions
        assertTrue(temp.exists());
        assertEquals(bytes.length, fileBytes.length);
        assertTrue(temp.length() > 0);
    }
}