package com.hdfcbank.giftcity.bff.sdui.repository;

import com.hdfcbank.giftcity.bff.sdui.entity.UISchemaEntity;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDateTime;
import java.util.*;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
class UISchemaRepositoryTest {

    @Mock
    private UISchemaRepository repository;

    @Test
    void testFindByPageAndSchemaVersion_success() {

        UISchemaEntity entity = new UISchemaEntity();
        entity.setId("schema-001");
        entity.setPage("HOME_PAGE");
        entity.setSchemaVersion("v1");
        entity.setActive(true);
        entity.setSchemaJson(Map.of("title", "Home Page"));
        entity.setDataSources(List.of("DS1", "DS2"));
        entity.setCreatedAt(LocalDateTime.now());
        entity.setUpdatedAt(LocalDateTime.now());

        when(repository.findByPageAndSchemaVersion("HOME_PAGE", "v1"))
                .thenReturn(Optional.of(entity));

        Optional<UISchemaEntity> result =
                repository.findByPageAndSchemaVersion("HOME_PAGE", "v1");

        assertTrue(result.isPresent());
        assertEquals("schema-001", result.get().getId());
        assertEquals("HOME_PAGE", result.get().getPage());
        assertEquals("v1", result.get().getSchemaVersion());
        assertTrue(result.get().isActive());
        assertEquals("Home Page", result.get().getSchemaJson().get("title"));
    }

    @Test
    void testFindByPageAndSchemaVersion_notFound() {

        when(repository.findByPageAndSchemaVersion("LOGIN_PAGE", "v9"))
                .thenReturn(Optional.empty());

        Optional<UISchemaEntity> result =
                repository.findByPageAndSchemaVersion("LOGIN_PAGE", "v9");

        assertTrue(result.isEmpty());
    }

    @Test
    void testSaveEntity() {

        UISchemaEntity entity = new UISchemaEntity();
        entity.setId("schema-002");
        entity.setPage("PROFILE_PAGE");
        entity.setSchemaVersion("v2");
        entity.setActive(false);
        entity.setSchemaJson(Map.of("key", "value"));
        entity.setDataSources(List.of("DSA"));
        entity.setCreatedAt(LocalDateTime.now());
        entity.setUpdatedAt(LocalDateTime.now());

        when(repository.save(entity)).thenReturn(entity);

        UISchemaEntity savedEntity = repository.save(entity);

        assertNotNull(savedEntity);
        assertEquals("schema-002", savedEntity.getId());
        assertEquals("PROFILE_PAGE", savedEntity.getPage());
        assertEquals("v2", savedEntity.getSchemaVersion());
        assertFalse(savedEntity.isActive());
        assertEquals("value", savedEntity.getSchemaJson().get("key"));
    }

    @Test
    void testFindById() {

        UISchemaEntity entity = new UISchemaEntity();
        entity.setId("schema-003");
        entity.setPage("DS_PAGE");
        entity.setSchemaVersion("v3");

        when(repository.findById("schema-003"))
                .thenReturn(Optional.of(entity));

        Optional<UISchemaEntity> result = repository.findById("schema-003");

        assertTrue(result.isPresent());
        assertEquals("schema-003", result.get().getId());
        assertEquals("DS_PAGE", result.get().getPage());
        assertEquals("v3", result.get().getSchemaVersion());
    }

    @Test
    void testDeleteById() {

        doNothing().when(repository).deleteById("schema-004");

        repository.deleteById("schema-004");

        verify(repository, times(1)).deleteById("schema-004");
    }
}