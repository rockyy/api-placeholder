package com.hdfcbank.giftcity.bff.commons.validation;

import com.hdfcbank.giftcity.bff.commons.properties.CustomValidationProperties;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.*;

class ValidatorsFactoryTest {

    private CustomValidationProperties properties;
    private ValidatorsFactory factory;
    private Validator v1;
    private Validator v2;
    private Validator v3;

    @BeforeEach
    void setup() {

        properties = mock(CustomValidationProperties.class);

        CustomValidationProperties.CustomValidations j1 = new CustomValidationProperties.CustomValidations();
        j1.setValidators(List.of("VAL1", "VAL2"));

        CustomValidationProperties.CustomValidations emptyJourney = new CustomValidationProperties.CustomValidations();
        emptyJourney.setValidators(List.of());

        Map<String, CustomValidationProperties.CustomValidations> journeysMap = Map.of(
                "J1", j1,
                "EMPTY", emptyJourney
        );

        when(properties.getJourneys()).thenReturn(journeysMap);

        // Validator mocks
        v1 = mock(Validator.class);
        when(v1.name()).thenReturn("VAL1");
        when(v1.type()).thenReturn(ValidatorType.PRE_CUSTOMER_VALIDATION);

        v2 = mock(Validator.class);
        when(v2.name()).thenReturn("VAL2");
        when(v2.type()).thenReturn(ValidatorType.POST_CUSTOMER_VALIDATION);

        v3 = mock(Validator.class);
        when(v3.name()).thenReturn("OTHER");
        when(v3.type()).thenReturn(ValidatorType.PRE_CUSTOMER_VALIDATION);

        factory = new ValidatorsFactory(List.of(v1, v2, v3), properties);
    }

    @Test
    void testGetValidators_MatchingValidatorsByNameAndType() {
        List<Validator> result =
                factory.getValidators("J1", ValidatorType.PRE_CUSTOMER_VALIDATION);

        assertThat(result)
                .isNotNull()
                .hasSize(1)
                .containsExactly(v1);

        assertThat(result.get(0).name()).isEqualTo("VAL1");
        assertThat(result.get(0).type()).isEqualTo(ValidatorType.PRE_CUSTOMER_VALIDATION);
    }

    @Test
    void testGetValidators_MatchingSecondValidatorByType() {
        List<Validator> result =
                factory.getValidators("J1", ValidatorType.POST_CUSTOMER_VALIDATION);

        assertThat(result)
                .isNotNull()
                .hasSize(1)
                .containsExactly(v2);

        assertThat(result.get(0).name()).isEqualTo("VAL2");
        assertThat(result.get(0).type()).isEqualTo(ValidatorType.POST_CUSTOMER_VALIDATION);
    }

    @Test
    void testGetValidators_NoMatchingType() {
        List<Validator> result =
                factory.getValidators("J1", null);

        assertThat(result)
                .isNotNull()
                .isEmpty();
    }

    @Test
    void testGetValidators_JourneyWithEmptyValidatorList() {
        List<Validator> result =
                factory.getValidators("EMPTY", ValidatorType.PRE_CUSTOMER_VALIDATION);

        assertThat(result)
                .isNotNull()
                .isEmpty();
    }

    @Test
    void testGetValidators_NoValidatorNameMatch() {
        List<Validator> result =
                factory.getValidators("J1", ValidatorType.PRE_CUSTOMER_VALIDATION);

        assertThat(result)
                .isNotNull()
                .hasSize(1)
                .doesNotContain(v3)
                .containsExactly(v1);

        assertThat(result.get(0).name()).isEqualTo("VAL1");
    }

    @Test
    void testGetValidators_JourneyNotFound() {

        when(properties.getJourneys()).thenReturn(Map.of());

        ValidatorsFactory newFactory =
                new ValidatorsFactory(List.of(v1, v2, v3), properties);

        try {
            List<Validator> result =
                    newFactory.getValidators("UNKNOWN", ValidatorType.PRE_CUSTOMER_VALIDATION);

            assertThat(result).isEmpty();

        } catch (NullPointerException ignored) {
            // Expected due to missing key in properties map
            assertThat(true).isTrue();
        }
    }

    @Test
    void testGetValidators_NoValidatorsInjected() {
        ValidatorsFactory newFactory =
                new ValidatorsFactory(List.of(), properties);

        List<Validator> result =
                newFactory.getValidators("J1", ValidatorType.PRE_CUSTOMER_VALIDATION);

        assertThat(result)
                .isNotNull()
                .isEmpty();
    }
}