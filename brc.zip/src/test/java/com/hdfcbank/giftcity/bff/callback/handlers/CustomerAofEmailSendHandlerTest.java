package com.hdfcbank.giftcity.bff.callback.handlers;

import com.hdfcbank.adapters.clients.feign.communication.CommunicationFeignClient;
import com.hdfcbank.adapters.clients.feign.document.DocumentFeignClient;
import com.hdfcbank.adapters.vo.*;
import com.hdfcbank.common.models.constant.CommonApiStatusCodes;
import com.hdfcbank.common.models.vo.core.ApiResponseStatus;
import com.hdfcbank.common.models.vo.journey.*;
import com.hdfcbank.giftcity.bff.commons.enums.CommonJourneyStates;
import com.hdfcbank.giftcity.bff.commons.enums.JourneyPageName;
import com.hdfcbank.giftcity.bff.commons.exception.handler.DownstreamResponseHandler;
import com.hdfcbank.giftcity.bff.commons.file.ByteArrayMultipartFile;
import com.hdfcbank.giftcity.bff.commons.file.InlineImage;
import com.hdfcbank.giftcity.bff.commons.handler.Handler;
import com.hdfcbank.giftcity.bff.commons.handler.HandlerContext;
import com.hdfcbank.giftcity.bff.commons.handler.HandlerResult;
import com.hdfcbank.giftcity.bff.commons.model.CustomValidationStatus;
import com.hdfcbank.giftcity.bff.commons.model.FcIndiaProfile;
import com.hdfcbank.giftcity.bff.commons.model.FtsDetails;
import com.hdfcbank.giftcity.bff.commons.utility.EmailHeaderAttachmentUtil;
import com.hdfcbank.giftcity.bff.customer.utility.CustomerUtil;
import com.hdfcbank.giftcity.bff.infrastructure.service.JourneyService;

import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.ResponseEntity;

import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class CustomerAofEmailSendHandlerTest {

    @Mock private CommunicationFeignClient communicationFeignClient;
    @Mock private DocumentFeignClient documentFeignClient;
    @Mock private EmailHeaderAttachmentUtil emailHeaderAttachmentUtil;
    @Mock private JourneyService journeyService;

    @InjectMocks private CustomerAofEmailSendHandler handler;

    private JourneyData journeyData;
    private HandlerContext context;
    private FtsDetails ftsDetails;
    private FcIndiaProfile.Profile fcProfile;

    @BeforeEach
    void setup() {

        journeyData = new JourneyData();
        journeyData.setJourneyId("J100");
        journeyData.setJourneyName("GiftCity");
        journeyData.setReferenceNo("REF001");
        journeyData.setMobileNumber("9999999999");

        Profile profile = Profile.builder()
                .emailId("john.doe@test.com")
                .name("John Doe")
                .build();
        journeyData.setProfile(profile);

        ftsDetails = new FtsDetails();
        ftsDetails.setAofWithoutAnnextureDocRef("AOF123");

        Map<String, Object> pageMap = new HashMap<>();
        pageMap.put("data", ftsDetails);

        Map<String, Map<String, ?>> systemData = new HashMap<>();
        systemData.put(JourneyPageName.FTS_DETAILS.getPageName(), pageMap);

        JourneyDetail detail = new JourneyDetail();
        detail.setSystemData(systemData);
        detail.setJourneyStates(
                List.of(new JourneyState(CommonJourneyStates.FTS_SUCCESS_CALLBACK.name(), new Date(), "")));

        journeyData.setJourneyDetail(detail);

        context = HandlerContext.builder()
                .journeyData(journeyData)
                .data(new HashMap<>())
                .properties(new HashMap<>())
                .build();

        fcProfile = FcIndiaProfile.Profile.builder().name("John Doe").build();
    }

    // PRECONDITIONS

    @Test
    void testPreConditionsTrue() {
        assertTrue(handler.preConditions(context));
    }

    @Test
    void testPreConditionsFalse() {
        journeyData.getJourneyDetail().setJourneyStates(new ArrayList<>());
        assertFalse(handler.preConditions(context));
    }


    // SUCCESS PATH

    @Test
    void testHandleSuccess() {

        try (MockedStatic<JourneyService> js = mockStatic(JourneyService.class);
             MockedStatic<CustomerUtil> cu = mockStatic(CustomerUtil.class)) {

            js.when(() -> JourneyService.extractFromJourney(
                            any(), eq(JourneyPageName.FTS_DETAILS.getPageName()), eq(FtsDetails.class)))
                    .thenReturn(Optional.of(ftsDetails));

            cu.when(() -> CustomerUtil.getPrimaryProfile(any()))
                    .thenReturn(Optional.of(fcProfile));

            byte[] bytes = "DOC".getBytes();
            when(documentFeignClient.downloadResponse(any(), any(), any()))
                    .thenReturn(ResponseEntity.ok(bytes));

            UploadAttachmentResponse.UploadAttachmentDetail docAttach =
                    UploadAttachmentResponse.UploadAttachmentDetail.builder()
                            .filename("AOF.tif")
                            .reference("REF-AOF")
                            .build();

            when(communicationFeignClient.uploadAttachmentFile(any(), any()))
                    .thenReturn(UploadAttachmentResponse.builder().data(docAttach).build());

            InlineImage inline = new InlineImage(
                    "CID",
                    new ByteArrayMultipartFile("file", "img.png", "png", bytes)
            );
            when(emailHeaderAttachmentUtil.prepareInlineImage(any(), any(), any()))
                    .thenReturn(inline);

            EmailMessageSuccess emailSuccess =
                    EmailMessageSuccess.builder()
                            .status(ApiResponseStatus.success())
                            .data(new EmailMessageSuccess.EmailResponse(true))
                            .build();

            when(communicationFeignClient.sendEmail(any(), any()))
                    .thenReturn(emailSuccess);

            HandlerResult<EmailMessageSuccess> result = handler.handle(context);

            assertTrue(result.isSuccess());
            assertEquals(emailSuccess, result.getResult());
            assertNull(result.getApiResponseStatus());
        }
    }

    // FAILURE: Email Status != 0000

    @Test
    void testHandleFailure_EmailFailure() {

        try (MockedStatic<JourneyService> js = mockStatic(JourneyService.class);
             MockedStatic<CustomerUtil> cu = mockStatic(CustomerUtil.class);
             MockedStatic<DownstreamResponseHandler> drh = mockStatic(DownstreamResponseHandler.class)) {

            js.when(() -> JourneyService.extractFromJourney(any(), any(), any()))
                    .thenReturn(Optional.of(ftsDetails));

            cu.when(() -> CustomerUtil.getPrimaryProfile(any()))
                    .thenReturn(Optional.of(fcProfile));

            when(documentFeignClient.downloadResponse(any(), any(), any()))
                    .thenReturn(ResponseEntity.ok("X".getBytes()));

            UploadAttachmentResponse.UploadAttachmentDetail attach =
                    UploadAttachmentResponse.UploadAttachmentDetail.builder()
                            .filename("file")
                            .reference("ref")
                            .build();

            when(communicationFeignClient.uploadAttachmentFile(any(), any()))
                    .thenReturn(UploadAttachmentResponse.builder().data(attach).build());

            InlineImage inline = new InlineImage(
                    "CID",
                    new ByteArrayMultipartFile("file", "img.png", "png", "yy".getBytes())
            );

            when(emailHeaderAttachmentUtil.prepareInlineImage(any(), any(), any()))
                    .thenReturn(inline);

            EmailMessageSuccess failure =
                    EmailMessageSuccess.builder()
                            .status(ApiResponseStatus.businessValidationError(null))
                            .data(new EmailMessageSuccess.EmailResponse(false))
                            .build();

            when(communicationFeignClient.sendEmail(any(), any()))
                    .thenReturn(failure);

            CustomValidationStatus downstream =
                    CustomValidationStatus.builder().code("ERR").message("FAIL").build();

            drh.when(() ->
                            DownstreamResponseHandler.handleResponse(any(), any(), eq(false), any()))
                    .thenReturn(downstream);

            HandlerResult<EmailMessageSuccess> result = handler.handle(context);

            assertFalse(result.isSuccess());
            assertEquals("ERR", result.getApiResponseStatus().getCode());
            assertEquals(failure, result.getResult());
        }
    }

    // FAILURE: First attachment upload returns null

    @Test
    void testHandleFailure_AttachmentNull() {

        try (MockedStatic<JourneyService> js = mockStatic(JourneyService.class);
             MockedStatic<CustomerUtil> cu = mockStatic(CustomerUtil.class);
             MockedStatic<DownstreamResponseHandler> drh = mockStatic(DownstreamResponseHandler.class)) {

            js.when(() -> JourneyService.extractFromJourney(any(), any(), any()))
                    .thenReturn(Optional.of(ftsDetails));

            cu.when(() -> CustomerUtil.getPrimaryProfile(any()))
                    .thenReturn(Optional.of(fcProfile));

            when(documentFeignClient.downloadResponse(any(), any(), any()))
                    .thenReturn(ResponseEntity.ok("DOC".getBytes()));

            when(communicationFeignClient.uploadAttachmentFile(any(), any()))
                    .thenReturn(null);

            CustomValidationStatus downstream =
                    CustomValidationStatus.builder().code("UP-Fail").message("Upload fail").build();

            drh.when(() ->
                            DownstreamResponseHandler.handleResponse(any(), any(), eq(false), any()))
                    .thenReturn(downstream);

            HandlerResult<EmailMessageSuccess> result = handler.handle(context);

            assertFalse(result.isSuccess());
            assertEquals("UP-Fail", result.getApiResponseStatus().getCode());
            assertNull(result.getResult());
        }
    }

    // FAILURE: Inline image upload returns null

    @Test
    void testHandleFailure_InlineUploadNull() {

        try (MockedStatic<JourneyService> js = mockStatic(JourneyService.class);
             MockedStatic<CustomerUtil> cu = mockStatic(CustomerUtil.class);
             MockedStatic<DownstreamResponseHandler> drh = mockStatic(DownstreamResponseHandler.class)) {

            js.when(() -> JourneyService.extractFromJourney(any(), any(), any()))
                    .thenReturn(Optional.of(ftsDetails));

            cu.when(() -> CustomerUtil.getPrimaryProfile(any()))
                    .thenReturn(Optional.of(fcProfile));

            when(documentFeignClient.downloadResponse(any(), any(), any()))
                    .thenReturn(ResponseEntity.ok("DOC".getBytes()));

            UploadAttachmentResponse.UploadAttachmentDetail baseAttach =
                    UploadAttachmentResponse.UploadAttachmentDetail.builder()
                            .filename("file")
                            .reference("ref")
                            .build();

            when(communicationFeignClient.uploadAttachmentFile(any(), any()))
                    .thenReturn(UploadAttachmentResponse.builder().data(baseAttach).build())
                    .thenReturn(null);

            InlineImage inline = new InlineImage(
                    "CID",
                    new ByteArrayMultipartFile("file", "img.png", "png", "xx".getBytes())
            );

            when(emailHeaderAttachmentUtil.prepareInlineImage(any(), any(), any()))
                    .thenReturn(inline);

            CustomValidationStatus downstream =
                    CustomValidationStatus.builder().code("INLINE-Fail").message("fail").build();

            drh.when(() ->
                            DownstreamResponseHandler.handleResponse(any(), any(), eq(false), any()))
                    .thenReturn(downstream);

            HandlerResult<EmailMessageSuccess> result = handler.handle(context);

            assertFalse(result.isSuccess());
            assertEquals("INLINE-Fail", result.getApiResponseStatus().getCode());
            assertNull(result.getResult());
        }
    }

    // FAILURE: Profile returns null

    @Test
    void testHandleFailure_ProfileNull() {

        try (MockedStatic<JourneyService> js = Mockito.mockStatic(JourneyService.class);
             MockedStatic<CustomerUtil> cu = Mockito.mockStatic(CustomerUtil.class);
             MockedStatic<DownstreamResponseHandler> drh = Mockito.mockStatic(DownstreamResponseHandler.class)) {

            // 1. FTS DETAILS extraction returns valid details
            js.when(() -> JourneyService.extractFromJourney(
                    eq(journeyData),
                    eq(JourneyPageName.FTS_DETAILS.getPageName()),
                    eq(FtsDetails.class)
            )).thenReturn(Optional.of(ftsDetails));

            // 2. Profile is missing → fcProfile = null
            cu.when(() -> CustomerUtil.getPrimaryProfile(journeyData))
                    .thenReturn(Optional.empty()); // this triggers NPE inside handler

            // 3. Document download OK
            when(documentFeignClient.downloadResponse(any(), any(), any()))
                    .thenReturn(ResponseEntity.ok("DOC".getBytes()));

            // 4. First attachment upload OK
            UploadAttachmentResponse.UploadAttachmentDetail attach =
                    UploadAttachmentResponse.UploadAttachmentDetail.builder()
                            .filename("file")
                            .reference("ref")
                            .build();

            when(communicationFeignClient.uploadAttachmentFile(any(), any()))
                    .thenReturn(UploadAttachmentResponse.builder().data(attach).build());

            // 5. Inline image prepared OK
            InlineImage inline = new InlineImage(
                    "CID",
                    new ByteArrayMultipartFile("file", "img.png", "png", "xx".getBytes())
            );
            when(emailHeaderAttachmentUtil.prepareInlineImage(any(), any(), any()))
                    .thenReturn(inline);

            CustomValidationStatus downstream =
                    CustomValidationStatus.builder()
                            .code("NULL-PROFILE")
                            .message("null")
                            .build();

            // Handler calls DownstreamResponseHandler.handleResponse(null,...)
            drh.when(() -> DownstreamResponseHandler.handleResponse(
                    eq(null),                                   // because response never created
                    eq("CUSTOMER_AOF_EMAIL_NOTIFY"),
                    eq(false),
                    eq("GiftCity")
            )).thenReturn(downstream);

            HandlerResult<EmailMessageSuccess> result = handler.handle(context);

            // ASSERT exception-path output
            assertFalse(result.isSuccess());
            assertEquals("NULL-PROFILE", result.getApiResponseStatus().getCode());
            assertNull(result.getResult()); // exception path always returns null result
        }
    }

    // EXCEPTION PATH

    @Test
    void testHandleException() {

        try (MockedStatic<JourneyService> js = Mockito.mockStatic(JourneyService.class);
             MockedStatic<CustomerUtil> cu = Mockito.mockStatic(CustomerUtil.class);
             MockedStatic<DownstreamResponseHandler> drh = Mockito.mockStatic(DownstreamResponseHandler.class)) {

            // 1. Prevent NPE before our intended exception
            js.when(() -> JourneyService.extractFromJourney(
                    eq(journeyData),
                    eq(JourneyPageName.FTS_DETAILS.getPageName()),
                    eq(FtsDetails.class)
            )).thenReturn(Optional.of(new FtsDetails())); // safe

            FcIndiaProfile.Profile safeProfile =
                    FcIndiaProfile.Profile.builder().name("Test User").build();
            cu.when(() -> CustomerUtil.getPrimaryProfile(journeyData))
                    .thenReturn(Optional.of(safeProfile));  // avoid NPE

            // 2. NOW our stubbed exception will be reached
            when(documentFeignClient.downloadResponse(any(), any(), any()))
                    .thenThrow(new RuntimeException("BOOM"));

            CustomValidationStatus downstream =
                    CustomValidationStatus.builder()
                            .code("EX")
                            .message("EXCEPTION")
                            .build();

            // 3. EXACT match for exception-path invocation
            drh.when(() -> DownstreamResponseHandler.handleResponse(
                    eq(null),
                    eq("CUSTOMER_AOF_EMAIL_NOTIFY"),
                    eq(false),
                    eq("GiftCity")
            )).thenReturn(downstream);

            // RUN
            HandlerResult<EmailMessageSuccess> result = handler.handle(context);

            // ASSERTS
            assertFalse(result.isSuccess());
            assertEquals("EX", result.getApiResponseStatus().getCode());
            assertNull(result.getResult());
        }
    }


    // GETTERS

    @Test
    void testGetters() {
        assertEquals(
                Handler.HandlerType.BACKGROUND_TASKS_POST_SUBMIT_SUCCESS,
                handler.getType()
        );
        assertEquals(
                Handler.HandlerName.CUSTOMER_AOF_EMAIL_NOTIFY,
                handler.getName()
        );
        assertEquals(
                CommonJourneyStates.CUSTOMER_AOF_NOTIFY_SUCCESS,
                handler.successState()
        );
        assertEquals(
                CommonJourneyStates.CUSTOMER_AOF_NOTIFY_FAILURE,
                handler.failureState()
        );
    }
}