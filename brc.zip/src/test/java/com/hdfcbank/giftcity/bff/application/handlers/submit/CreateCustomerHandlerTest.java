package com.hdfcbank.giftcity.bff.application.handlers.submit;

import com.hdfcbank.giftcity.bff.commons.enums.CommonJourneyStates;
import com.hdfcbank.giftcity.bff.commons.enums.JourneyPageName;
import com.hdfcbank.giftcity.bff.commons.exception.handler.DownstreamResponseHandler;
import com.hdfcbank.giftcity.bff.commons.handler.Handler;
import com.hdfcbank.giftcity.bff.commons.handler.HandlerContext;
import com.hdfcbank.giftcity.bff.commons.handler.HandlerResult;
import com.hdfcbank.giftcity.bff.commons.model.CustomValidationStatus;
import com.hdfcbank.giftcity.bff.commons.model.FcGcProfile;
import com.hdfcbank.giftcity.bff.commons.model.FcIndiaProfile;
import com.hdfcbank.giftcity.bff.customer.config.CustomerApiProperties;
import com.hdfcbank.giftcity.bff.customer.mapper.CreateFCCCustomerMapper;
import com.hdfcbank.giftcity.bff.customer.mapper.CreateFccMasterMapper;
import com.hdfcbank.giftcity.bff.customer.utility.CustomerUtil;
import com.hdfcbank.giftcity.bff.infrastructure.service.JourneyService;

import com.hdfcbank.service.adapters.clients.feign.customer.CustomerServiceFeignClient;
import com.hdfcbank.service.adapters.vo.customer.FccCustomerRequest;
import com.hdfcbank.service.adapters.vo.customer.FccCustomerResponse;

import com.hdfcbank.common.models.vo.core.ApiResponseStatus;
import com.hdfcbank.common.models.vo.journey.JourneyData;
import com.hdfcbank.common.models.vo.journey.Profile;

import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;

import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.*;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

import ch.qos.logback.classic.Level;
import ch.qos.logback.classic.Logger;
import org.slf4j.LoggerFactory;

@ExtendWith(MockitoExtension.class)
class CreateCustomerHandlerTest {

    @Mock private CustomerApiProperties customerApiProperties;
    @Mock private CreateFCCCustomerMapper createFCCCustomerMapper;
    @Mock private CustomerServiceFeignClient customerServiceFeignClient;
    @Mock private JourneyService journeyService;
    @Mock private CreateFccMasterMapper createFccMasterMapper;

    @Spy
    @InjectMocks
    private CreateCustomerHandler handler;

    private HandlerContext ctx;
    private JourneyData journeyData;

    @BeforeEach
    void disableErrorLogs() {
        Logger root = (Logger) LoggerFactory.getLogger(Logger.ROOT_LOGGER_NAME);
        root.setLevel(Level.OFF);
    }

    @BeforeEach
    void setup() {

        journeyData = JourneyData.builder()
                .journeyId("J123")
                .journeyName("GIFT_CITY")
                .profile(Profile.builder()
                        .dob("1990-01-01")
                        .emailId("test@x.com")
                        .build())
                .build();

        ctx = HandlerContext.builder()
                .journeyData(journeyData)
                .data(new HashMap<>())
                .properties(new HashMap<>())
                .build();

        CustomerApiProperties.ApiDetails apiDetails = new CustomerApiProperties.ApiDetails();
        apiDetails.setServiceDefaults(Map.of("CC_CTYPE", "X"));

        lenient().when(customerApiProperties.getCreateFccCustomer()).thenReturn(apiDetails);
    }

    // ----------------------------------------------------------------------
    // PRECONDITIONS
    // ----------------------------------------------------------------------
    @Test
    void preConditions_false() {
        doReturn(false)
                .when(handler).isSuccess(ctx, Handler.HandlerName.RISK_ANALYSIS);

        assertFalse(handler.preConditions(ctx));
    }

    // ----------------------------------------------------------------------
    // SUCCESS CASE
    // ----------------------------------------------------------------------
    @Test
    void handle_success_responseCode0000() {

        FcIndiaProfile.Profile fcProfile = FcIndiaProfile.Profile.builder()
                .customerFirstName("John")
                .customerLastName("Doe")
                .build();

        FcGcProfile gcProfile = FcGcProfile.builder()
                .customerNumber("OLD")
                .build();

        FccCustomerRequest request = new FccCustomerRequest();

        when(createFCCCustomerMapper.toRequest(
                eq(journeyData), any(), any(),
                anyMap(), anyMap(),
                eq(createFccMasterMapper),
                any(),
                any()
        )).thenReturn(request);

        try (
                MockedStatic<CustomerUtil> custMock = mockStatic(CustomerUtil.class);
                MockedStatic<JourneyService> jsvcMock = mockStatic(JourneyService.class)
        ) {

            custMock.when(() -> CustomerUtil.getUcicDetails(journeyData))
                    .thenReturn(Optional.empty());

            custMock.when(() -> CustomerUtil.getRiskAssessment(journeyData))
                    .thenReturn(null);

            jsvcMock.when(() -> JourneyService.extractFromJourney(
                    eq(journeyData),
                    eq(JourneyPageName.CUSTOMER_FC_INDIA_DETAIL.getPageName()),
                    eq(FcIndiaProfile.class),
                    any()
            )).thenReturn(Optional.of(fcProfile));

            jsvcMock.when(() -> JourneyService.getDomainPageUserInputs(eq(journeyData), eq("customerDetails")))
                    .thenReturn(Collections.emptyMap());

            jsvcMock.when(() -> JourneyService.extractFromJourney(
                    eq(journeyData),
                    eq(JourneyPageName.CUSTOMER_FC_GIFT_CITY_DETAIL.getPageName()),
                    eq(FcGcProfile.class),
                    eq(java.util.function.Function.identity())
            )).thenReturn(Optional.of(gcProfile));

            ApiResponseStatus ok = new ApiResponseStatus();
            ok.setCode("0000");
            ok.setMessage("OK");

            FccCustomerResponse.FccCustomerId newId =
                    FccCustomerResponse.FccCustomerId.builder().customerId("NEWID").build();

            FccCustomerResponse resp = FccCustomerResponse.builder()
                    .status(ok)
                    .data(newId)
                    .build();

            when(customerServiceFeignClient.createFCCCustomer(eq(request), eq("J123")))
                    .thenReturn(resp);

            doNothing().when(journeyService).updateJourney(
                    eq("J123"),
                    eq(JourneyPageName.CUSTOMER_FC_GIFT_CITY_DETAIL.getPageName()),
                    any(FcGcProfile.class),
                    eq(CommonJourneyStates.CUSTOMER_FC_GC_DETAIL_CAPTURED)
            );

            HandlerResult<FccCustomerResponse> result = handler.handle(ctx);

            assertTrue(result.isSuccess());
            assertNotNull(result.getResult());
            assertEquals("0000", result.getResult().getStatus().getCode());
            assertEquals("OK", result.getResult().getStatus().getMessage());
            assertEquals("NEWID", result.getResult().getData().getCustomerId());

            //     SUCCESS → apiResponseStatus MUST BE null
            assertNull(result.getApiResponseStatus());

            verify(customerServiceFeignClient, times(1))
                    .createFCCCustomer(eq(request), eq("J123"));

            verify(journeyService, times(1))
                    .updateJourney(
                            eq("J123"),
                            eq(JourneyPageName.CUSTOMER_FC_GIFT_CITY_DETAIL.getPageName()),
                            any(FcGcProfile.class),
                            eq(CommonJourneyStates.CUSTOMER_FC_GC_DETAIL_CAPTURED)
                    );
        }
    }

    // ----------------------------------------------------------------------
    // FAILURE CASE
    // ----------------------------------------------------------------------
    @Test
    void handle_failure_responseCodeNot0000() {

        FccCustomerRequest req = new FccCustomerRequest();

        when(createFCCCustomerMapper.toRequest(
                any(), any(), any(), anyMap(), anyMap(), any(), any(), any()
        )).thenReturn(req);

        ApiResponseStatus failStatus = new ApiResponseStatus();
        failStatus.setCode("9999");
        failStatus.setMessage("FAIL");

        FccCustomerResponse failResp = FccCustomerResponse.builder()
                .status(failStatus)
                .data(null)
                .build();

        when(customerServiceFeignClient.createFCCCustomer(eq(req), eq("J123")))
                .thenReturn(failResp);

        CustomValidationStatus custom = CustomValidationStatus.builder()
                .code("ERR")
                .message("DOWNSTREAM_FAIL")
                .build();

        try (MockedStatic<DownstreamResponseHandler> dshMock = mockStatic(DownstreamResponseHandler.class)) {

            dshMock.when(() -> DownstreamResponseHandler.handleResponse(
                    eq(failResp),
                    eq(Handler.HandlerName.CREATE_CUSTOMER.name()),
                    eq(false),
                    eq("GIFT_CITY")
            )).thenReturn(custom);

            HandlerResult<FccCustomerResponse> result = handler.handle(ctx);

            // FAILURE assertions
            assertFalse(result.isSuccess());
            assertEquals("ERR", result.getApiResponseStatus().getCode());
            assertEquals("DOWNSTREAM_FAIL", result.getApiResponseStatus().getMessage());

            //     Corrected: result is NOT null on failure
            assertNotNull(result.getResult());
            assertEquals("9999", result.getResult().getStatus().getCode());
            assertEquals("FAIL", result.getResult().getStatus().getMessage());
        }
    }

    // ----------------------------------------------------------------------
    // EXCEPTION CASE
    // ----------------------------------------------------------------------
    @Test
    void handle_exceptionThrown() {

        FccCustomerRequest req = new FccCustomerRequest();

        when(createFCCCustomerMapper.toRequest(any(), any(), any(), anyMap(), anyMap(), any(), any(), any()))
                .thenReturn(req);

        when(customerServiceFeignClient.createFCCCustomer(eq(req), eq("J123")))
                .thenThrow(new RuntimeException("Boom"));

        CustomValidationStatus custom = CustomValidationStatus.builder()
                .code("XERR")
                .message("EXCEPTION")
                .build();

        try (MockedStatic<DownstreamResponseHandler> dsh = mockStatic(DownstreamResponseHandler.class)) {

            dsh.when(() -> DownstreamResponseHandler.handleResponse(
                    isNull(),
                    eq(Handler.HandlerName.CREATE_CUSTOMER.name()),
                    eq(false),
                    eq("GIFT_CITY")
            )).thenReturn(custom);

            HandlerResult<FccCustomerResponse> result = handler.handle(ctx);

            assertFalse(result.isSuccess());
            assertEquals("XERR", result.getApiResponseStatus().getCode());
            assertEquals("EXCEPTION", result.getApiResponseStatus().getMessage());
            assertNull(result.getResult());
        }
    }

    // ----------------------------------------------------------------------
    // ENUM COVERAGE
    // ----------------------------------------------------------------------
    @Test
    void enumCoverage() {
        assertEquals(Handler.HandlerType.CUSTOMER_POST_SUBMIT, handler.getType());
        assertEquals(Handler.HandlerName.CREATE_CUSTOMER, handler.getName());
        assertEquals(CommonJourneyStates.CREATE_FCC_CUSTOMER_SUCCESS, handler.successState());
        assertEquals(CommonJourneyStates.CREATE_FCC_CUSTOMER_FAILURE, handler.failureState());
    }
}