package com.hdfcbank.giftcity.bff.account.service;

import com.hdfcbank.adapters.vo.FetchDynamicDataRequest;
import com.hdfcbank.common.models.vo.core.ApiResponseStatus;
import com.hdfcbank.common.models.vo.journey.JourneyData;
import com.hdfcbank.common.models.vo.journey.JourneyDetail;
import com.hdfcbank.common.models.vo.journey.JourneyState;
import com.hdfcbank.giftcity.bff.commons.enums.CommonJourneyStates;
import com.hdfcbank.giftcity.bff.commons.exception.handler.DownstreamResponseHandler;
import com.hdfcbank.giftcity.bff.commons.model.CustomValidationStatus;
import com.hdfcbank.giftcity.bff.commons.model.FtsDetails;
import com.hdfcbank.giftcity.bff.infrastructure.service.JourneyService;
import com.hdfcbank.service.adapters.vo.account.FTSApplicationInquireApiResponse;
import com.hdfcbank.service.adapters.vo.account.FTSApplicationInquireRequest;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.MethodSource;

import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.junit.jupiter.MockitoExtension;

import ch.qos.logback.classic.Level;
import ch.qos.logback.classic.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;
import java.util.stream.Stream;

import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
class FtsApplicationInquireServiceTest {

    @AfterEach
    void clearMdc() {
        com.hdfcbank.common.models.vo.mdc.MDCValues.clear();
    }

    @BeforeAll
    static void muteLogs() {
        Logger root = (Logger) LoggerFactory.getLogger(Logger.ROOT_LOGGER_NAME);
        root.setLevel(Level.OFF);
    }

    @Mock
    private AccountService accountService;

    @Mock
    private JourneyService journeyService;

    @InjectMocks
    private FtsApplicationInquireService service;

    private JourneyData createJourney(String id, String ack) {
        JourneyState js = new JourneyState();
        js.setStateName(CommonJourneyStates.FTS_AOF_POSTED_SUCCESS.name());

        JourneyDetail detail = new JourneyDetail();
        detail.setJourneyStates(List.of(js));

        JourneyData jd = new JourneyData();
        jd.setJourneyId(id);
        jd.setJourneyDetail(detail);
        jd.setJourneyName("GIFT");

        FtsDetails fts = new FtsDetails();
        FtsDetails.FtsAccountOpeningDetails aod = new FtsDetails.FtsAccountOpeningDetails();
        aod.setAcknowledgementNo(ack);
        fts.setFtsAccountOpeningDetails(aod);

        return jd;
    }

    private ApiResponseStatus outerStatus(String code, String msg) {
        ApiResponseStatus s = new ApiResponseStatus();
        s.setCode(code);
        s.setMessage(msg);
        return s;
    }

    private FTSApplicationInquireApiResponse.Status innerStatus(int rc, String rt) {
        return FTSApplicationInquireApiResponse.Status.builder()
                .replyCode(rc)
                .replyText(rt)
                .build();
    }

    // ---------------------------------------------------------------------
    @Test
    void testNoJourneysFound() {

        when(journeyService.fetchDynamicJourneyData(any())).thenReturn(null);

        service.inquireApplicationsAndUpdateJourneyState();

        verify(accountService, never()).ftsApplicationInquire(any(), anyString());
        verify(journeyService, never()).updateJourneyState(any(), any());
    }

    // ---------------------------------------------------------------------
    @Test
    void testMissingAckSkipped() {

        JourneyData jd = createJourney("J1", null);

        when(journeyService.fetchDynamicJourneyData(any())).thenReturn(List.of(jd));

        try (MockedStatic<JourneyService> js = mockStatic(JourneyService.class)) {

            js.when(() ->
                    JourneyService.extractFromJourney(any(), any(), any(), any())
            ).thenReturn(Optional.of(new FtsDetails()));

            service.inquireApplicationsAndUpdateJourneyState();

            verify(accountService, never()).ftsApplicationInquire(any(), anyString());
        }
    }

    // ---------------------------------------------------------------------
    @Test
    void testFailureApiResponse() {

        JourneyData jd = createJourney("J-F", "ACK100");

        when(journeyService.fetchDynamicJourneyData(any())).thenReturn(List.of(jd));

        FTSApplicationInquireApiResponse resp = new FTSApplicationInquireApiResponse();
        resp.setStatus(outerStatus("9999", "FAIL"));
        FTSApplicationInquireApiResponse.ResponseData rd =
                FTSApplicationInquireApiResponse.ResponseData.builder()
                        .status(innerStatus(9999, "FAIL"))
                        .responseString(null)
                        .build();

        resp.setData(rd);

        when(accountService.ftsApplicationInquire(any(), anyString())).thenReturn(resp);

        try (MockedStatic<JourneyService> js = mockStatic(JourneyService.class);
             MockedStatic<DownstreamResponseHandler> dr = mockStatic(DownstreamResponseHandler.class)) {

            FtsDetails fts = new FtsDetails();
            FtsDetails.FtsAccountOpeningDetails aod = new FtsDetails.FtsAccountOpeningDetails();
            aod.setAcknowledgementNo("ACK100");
            fts.setFtsAccountOpeningDetails(aod);

            js.when(() ->
                    JourneyService.extractFromJourney(any(), any(), any(), any())
            ).thenReturn(Optional.of(fts));

            dr.when(() ->
                    DownstreamResponseHandler.handleResponse(any(), anyString(), anyBoolean(), anyString())
            ).thenReturn(CustomValidationStatus.builder().title("FAIL").build());

            service.inquireApplicationsAndUpdateJourneyState();

            verify(journeyService).updateJourneyDetailDropOff(
                    eq(jd),
                    any(CustomValidationStatus.class),
                    eq(CommonJourneyStates.FTS_AOF_INQUIRE_FAILURE)
            );

            assertEquals("FAIL", resp.getStatus().getMessage());
            assertNotNull(resp.getData().getStatus());
            assertEquals(9999, resp.getData().getStatus().getReplyCode());
        }
    }

    // ---------------------------------------------------------------------
    @Test
    void testProcessedSuccessFlow() {

        JourneyData jd = createJourney("J-PROC", "ACK200");

        when(journeyService.fetchDynamicJourneyData(any())).thenReturn(List.of(jd));

        FTSApplicationInquireApiResponse.ResponseString rs =
                FTSApplicationInquireApiResponse.ResponseString.builder()
                        .enquiryStatus(FtsApplicationInquireService.FTS_ENQUIRY_STATUS_PROCESSED)
                        .build();

        FTSApplicationInquireApiResponse resp = new FTSApplicationInquireApiResponse();
        resp.setStatus(outerStatus("0000", "SUCCESS"));

        FTSApplicationInquireApiResponse.ResponseData rd =
                FTSApplicationInquireApiResponse.ResponseData.builder()
                        .status(innerStatus(0, "SUCCESS"))
                        .responseString(rs)
                        .build();

        resp.setData(rd);

        when(accountService.ftsApplicationInquire(any(), anyString())).thenReturn(resp);

        try (MockedStatic<JourneyService> js = mockStatic(JourneyService.class);
             MockedStatic<DownstreamResponseHandler> dr = mockStatic(DownstreamResponseHandler.class)) {

            dr.when(() ->
                    DownstreamResponseHandler.handleResponse(any(), anyString(), anyBoolean(), anyString())
            ).thenReturn(null);

            FtsDetails fts = new FtsDetails();
            FtsDetails.FtsAccountOpeningDetails aod = new FtsDetails.FtsAccountOpeningDetails();
            aod.setAcknowledgementNo("ACK200");
            fts.setFtsAccountOpeningDetails(aod);

            js.when(() ->
                    JourneyService.extractFromJourney(any(), any(), any(), any())
            ).thenReturn(Optional.of(fts));

            service.inquireApplicationsAndUpdateJourneyState();

            verify(journeyService).updateJourneyState(
                    eq("J-PROC"),
                    eq(CommonJourneyStates.FTS_AOF_SUBMIT_SUCCESS.name())
            );

            verify(journeyService).recordJourneyState(
                    eq("J-PROC"),
                    eq(CommonJourneyStates.FTS_AOF_INQUIRE_SUCCESS)
            );

            assertEquals("SUCCESS", resp.getStatus().getMessage());
            assertEquals("Processed", rs.getEnquiryStatus());
        }
    }

    // ---------------------------------------------------------------------
    @Test
    void testEnquiryRejected() {

        JourneyData jd = createJourney("J-REJ", "ACK300");

        when(journeyService.fetchDynamicJourneyData(any())).thenReturn(List.of(jd));

        FTSApplicationInquireApiResponse.ResponseString rs =
                FTSApplicationInquireApiResponse.ResponseString.builder()
                        .enquiryStatus(FtsApplicationInquireService.FTS_ENQUIRY_STATUS_REJECTED)
                        .enquiryRejectReason("Bad Docs")
                        .build();

        FTSApplicationInquireApiResponse resp = new FTSApplicationInquireApiResponse();
        resp.setStatus(outerStatus("0000", "SUCCESS"));

        FTSApplicationInquireApiResponse.ResponseData rd =
                FTSApplicationInquireApiResponse.ResponseData.builder()
                        .status(innerStatus(0, "SUCCESS"))
                        .responseString(rs)
                        .build();

        resp.setData(rd);

        when(accountService.ftsApplicationInquire(any(), anyString())).thenReturn(resp);

        try (MockedStatic<JourneyService> js = mockStatic(JourneyService.class);
             MockedStatic<DownstreamResponseHandler> dr = mockStatic(DownstreamResponseHandler.class)) {

            dr.when(() ->
                    DownstreamResponseHandler.handleResponse(any(), anyString(), anyBoolean(), anyString())
            ).thenReturn(null);

            FtsDetails fts = new FtsDetails();
            FtsDetails.FtsAccountOpeningDetails aod = new FtsDetails.FtsAccountOpeningDetails();
            aod.setAcknowledgementNo("ACK300");
            fts.setFtsAccountOpeningDetails(aod);

            js.when(() ->
                    JourneyService.extractFromJourney(any(), any(), any(), any())
            ).thenReturn(Optional.of(fts));

            service.inquireApplicationsAndUpdateJourneyState();

            verify(journeyService).updateJourneyDetailDropOff(
                    eq(jd),
                    any(CustomValidationStatus.class),
                    eq(CommonJourneyStates.FTS_AOF_SUBMIT_FAILURE)
            );

            verify(journeyService).recordJourneyState(
                    eq("J-REJ"),
                    eq(CommonJourneyStates.FTS_AOF_INQUIRE_SUCCESS)
            );

            assertEquals("Bad Docs", rs.getEnquiryRejectReason());
            assertEquals("Rejected", rs.getEnquiryStatus());
        }
    }

    // ---------------------------------------------------------------------
    @Test
    void testPendingNoUpdate() {

        JourneyData jd = createJourney("J-PEND", "ACK400");

        when(journeyService.fetchDynamicJourneyData(any())).thenReturn(List.of(jd));

        FTSApplicationInquireApiResponse.ResponseString rs =
                FTSApplicationInquireApiResponse.ResponseString.builder()
                        .enquiryStatus(FtsApplicationInquireService.FTS_ENQUIRY_STATUS_PENDING)
                        .build();

        FTSApplicationInquireApiResponse resp = new FTSApplicationInquireApiResponse();
        resp.setStatus(outerStatus("0000", "SUCCESS"));

        FTSApplicationInquireApiResponse.ResponseData rd =
                FTSApplicationInquireApiResponse.ResponseData.builder()
                        .status(innerStatus(0, "SUCCESS"))
                        .responseString(rs)
                        .build();

        resp.setData(rd);

        when(accountService.ftsApplicationInquire(any(), anyString())).thenReturn(resp);

        try (MockedStatic<JourneyService> js = mockStatic(JourneyService.class);
             MockedStatic<DownstreamResponseHandler> dr = mockStatic(DownstreamResponseHandler.class)) {

            dr.when(() ->
                    DownstreamResponseHandler.handleResponse(any(), anyString(), anyBoolean(), anyString())
            ).thenReturn(null);

            FtsDetails fts = new FtsDetails();
            FtsDetails.FtsAccountOpeningDetails aod = new FtsDetails.FtsAccountOpeningDetails();
            aod.setAcknowledgementNo("ACK400");
            fts.setFtsAccountOpeningDetails(aod);

            js.when(() ->
                    JourneyService.extractFromJourney(any(), any(), any(), any())
            ).thenReturn(Optional.of(fts));

            service.inquireApplicationsAndUpdateJourneyState();

            verify(journeyService, never()).updateJourneyState(any(), any());
            verify(journeyService).recordJourneyState(
                    eq("J-PEND"),
                    eq(CommonJourneyStates.FTS_AOF_INQUIRE_SUCCESS)
            );

            assertEquals("Pending", rs.getEnquiryStatus());
        }
    }

    // ---------------------------------------------------------------------
    @Test
    void testExceptionDuringProcessing() {

        JourneyData jd = createJourney("J-ERR", "ACK500");

        when(journeyService.fetchDynamicJourneyData(any())).thenReturn(List.of(jd));

        when(accountService.ftsApplicationInquire(any(), anyString()))
                .thenThrow(new RuntimeException("DOWNSTREAM_ERR"));

        try (MockedStatic<JourneyService> js = mockStatic(JourneyService.class);
             MockedStatic<DownstreamResponseHandler> dr = mockStatic(DownstreamResponseHandler.class)) {

            FtsDetails fts = new FtsDetails();
            FtsDetails.FtsAccountOpeningDetails aod = new FtsDetails.FtsAccountOpeningDetails();
            aod.setAcknowledgementNo("ACK500");
            fts.setFtsAccountOpeningDetails(aod);

            js.when(() ->
                    JourneyService.extractFromJourney(any(), any(), any(), any())
            ).thenReturn(Optional.of(fts));

            dr.when(() ->
                    DownstreamResponseHandler.handleResponse(any(), anyString(), anyBoolean(), anyString())
            ).thenReturn(CustomValidationStatus.builder().title("ERR").build());

            service.inquireApplicationsAndUpdateJourneyState();

            verify(journeyService).updateJourneyDetailDropOff(
                    eq(jd),
                    any(CustomValidationStatus.class),
                    eq(CommonJourneyStates.FTS_AOF_INQUIRE_FAILURE)
            );
        }
    }

    // ---------------------------------------------------------------------
    @Test
    void testOuterCatchBlock() {

        when(journeyService.fetchDynamicJourneyData(any()))
                .thenThrow(new RuntimeException("OUTER_FAIL"));

        service.inquireApplicationsAndUpdateJourneyState();

        verify(accountService, never()).ftsApplicationInquire(any(), anyString());
    }

    // ---------------------------------------------------------------------
    @Test
    void testEmptyJourneyList() {

        when(journeyService.fetchDynamicJourneyData(any()))
                .thenReturn(Collections.emptyList());

        service.inquireApplicationsAndUpdateJourneyState();

        verify(accountService, never()).ftsApplicationInquire(any(), anyString());
        verify(journeyService, never()).updateJourneyState(any(), any());
    }

    // ---------------------------------------------------------------------
    @Test
    void testPopulateMDCAndSanitizeExecuted() {

        JourneyData jd = createJourney("J123", "ACK777");

        when(journeyService.fetchDynamicJourneyData(any())).thenReturn(List.of(jd));

        FTSApplicationInquireApiResponse response = new FTSApplicationInquireApiResponse();
        response.setStatus(outerStatus("0000", "SUCCESS"));

        response.setData(
                FTSApplicationInquireApiResponse.ResponseData.builder()
                        .status(innerStatus(0, "SUCCESS"))
                        .responseString(
                                FTSApplicationInquireApiResponse.ResponseString.builder()
                                        .enquiryStatus("Processed")
                                        .build()
                        )
                        .build()
        );

        when(accountService.ftsApplicationInquire(any(), anyString()))
                .thenReturn(response);

        try (MockedStatic<JourneyService> js = mockStatic(JourneyService.class)) {

            FtsDetails fts = new FtsDetails();
            FtsDetails.FtsAccountOpeningDetails aod = new FtsDetails.FtsAccountOpeningDetails();
            aod.setAcknowledgementNo("ACK777");
            fts.setFtsAccountOpeningDetails(aod);

            js.when(() ->
                    JourneyService.extractFromJourney(any(), any(), any(), any())
            ).thenReturn(Optional.of(fts));

            service.inquireApplicationsAndUpdateJourneyState();

            verify(journeyService).updateJourneyState(
                    eq("J123"),
                    eq(CommonJourneyStates.FTS_AOF_SUBMIT_SUCCESS.name())
            );

            assertEquals("SUCCESS", response.getStatus().getMessage());
            assertEquals("Processed", response.getData().getResponseString().getEnquiryStatus());
        }
    }

    @ParameterizedTest
    @MethodSource("invalidResponses")
    void inquiry_shouldRecordFailureForInvalidResponse(FTSApplicationInquireApiResponse response) {
        JourneyData journey = createJourney("J-INVALID", "ACK-INVALID");
        when(journeyService.fetchDynamicJourneyData(any())).thenReturn(List.of(journey));
        when(accountService.ftsApplicationInquire(any(), eq("J-INVALID"))).thenReturn(response);

        try (MockedStatic<JourneyService> extraction = mockStatic(JourneyService.class);
             MockedStatic<DownstreamResponseHandler> errors = mockStatic(DownstreamResponseHandler.class)) {
            extraction.when(() -> JourneyService.extractFromJourney(any(), any(), any(), any()))
                    .thenReturn(Optional.of(openingDetails("ACK-INVALID")));
            CustomValidationStatus failure = CustomValidationStatus.builder().title("Invalid response").build();
            errors.when(() -> DownstreamResponseHandler.handleResponse(any(), anyString(), anyBoolean(), anyString()))
                    .thenReturn(failure);

            service.inquireApplicationsAndUpdateJourneyState();

            verify(journeyService).updateJourneyDetailDropOff(
                    journey, failure, CommonJourneyStates.FTS_AOF_INQUIRE_FAILURE);
            verify(journeyService, never()).updateJourneyState(anyString(), anyString());
            verify(journeyService, never()).recordJourneyState(
                    anyString(), eq(CommonJourneyStates.FTS_AOF_INQUIRE_SUCCESS));
        }
    }

    private static Stream<FTSApplicationInquireApiResponse> invalidResponses() {
        FTSApplicationInquireApiResponse missingStatus = new FTSApplicationInquireApiResponse();
        FTSApplicationInquireApiResponse failedStatus = new FTSApplicationInquireApiResponse();
        ApiResponseStatus failure = new ApiResponseStatus();
        failure.setCode("9999");
        failedStatus.setStatus(failure);
        FTSApplicationInquireApiResponse missingData = new FTSApplicationInquireApiResponse();
        missingData.setStatus(ApiResponseStatus.success());
        FTSApplicationInquireApiResponse missingResponseString = new FTSApplicationInquireApiResponse();
        missingResponseString.setStatus(ApiResponseStatus.success());
        missingResponseString.setData(FTSApplicationInquireApiResponse.ResponseData.builder().build());
        return Stream.of(null, missingStatus, failedStatus, missingData, missingResponseString);
    }

    @Test
    void inquiry_shouldSkipOpeningDetailsWithNullAcknowledgement() {
        JourneyData journey = createJourney("J-NO-ACK", null);
        when(journeyService.fetchDynamicJourneyData(any())).thenReturn(List.of(journey));

        try (MockedStatic<JourneyService> extraction = mockStatic(JourneyService.class)) {
            extraction.when(() -> JourneyService.extractFromJourney(any(), any(), any(), any()))
                    .thenReturn(Optional.of(openingDetails(null)));

            service.inquireApplicationsAndUpdateJourneyState();

            verifyNoInteractions(accountService);
            verify(journeyService, never()).updateJourneyState(anyString(), anyString());
        }
    }

    @Test
    void inquiry_shouldContinueWithNextJourneyAfterDownstreamFailure() {
        JourneyData first = createJourney("J-FIRST", "ACK");
        JourneyData second = createJourney("J-SECOND", "ACK");
        when(journeyService.fetchDynamicJourneyData(any())).thenReturn(List.of(first, second));
        when(accountService.ftsApplicationInquire(any(), eq("J-FIRST")))
                .thenThrow(new IllegalStateException("Downstream unavailable"));
        FTSApplicationInquireApiResponse processed = new FTSApplicationInquireApiResponse();
        processed.setStatus(ApiResponseStatus.success());
        processed.setData(FTSApplicationInquireApiResponse.ResponseData.builder()
                .responseString(FTSApplicationInquireApiResponse.ResponseString.builder()
                        .enquiryStatus("Processed").build()).build());
        when(accountService.ftsApplicationInquire(any(), eq("J-SECOND"))).thenReturn(processed);

        try (MockedStatic<JourneyService> extraction = mockStatic(JourneyService.class);
             MockedStatic<DownstreamResponseHandler> errors = mockStatic(DownstreamResponseHandler.class)) {
            extraction.when(() -> JourneyService.extractFromJourney(any(), any(), any(), any()))
                    .thenReturn(Optional.of(openingDetails("ACK")));
            CustomValidationStatus failure = CustomValidationStatus.builder().title("Failure").build();
            errors.when(() -> DownstreamResponseHandler.handleResponse(any(), anyString(), anyBoolean(), anyString()))
                    .thenReturn(failure);

            service.inquireApplicationsAndUpdateJourneyState();

            verify(journeyService).updateJourneyDetailDropOff(
                    first, failure, CommonJourneyStates.FTS_AOF_INQUIRE_FAILURE);
            verify(journeyService).updateJourneyState(
                    "J-SECOND", CommonJourneyStates.FTS_AOF_SUBMIT_SUCCESS.name());
            verify(journeyService).recordJourneyState("J-SECOND", CommonJourneyStates.FTS_AOF_INQUIRE_SUCCESS);
        }
    }

    private FtsDetails openingDetails(String acknowledgement) {
        FtsDetails.FtsAccountOpeningDetails details = new FtsDetails.FtsAccountOpeningDetails();
        details.setAcknowledgementNo(acknowledgement);
        FtsDetails fts = new FtsDetails();
        fts.setFtsAccountOpeningDetails(details);
        return fts;
    }
}
