package com.hdfcbank.giftcity.bff.commons.config;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.DeserializationFeature;
import feign.okhttp.OkHttpClient;
import org.junit.jupiter.api.Test;

import javax.net.ssl.*;
import java.security.KeyStore;
import java.security.SecureRandom;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class FeignClientConfigurationTest {

    /**
     * Real TrustManager required because OkHttp rejects mocks
     */
    private X509TrustManager createRealTrustManager() throws Exception {
        TrustManagerFactory tmf = TrustManagerFactory.getInstance(
                TrustManagerFactory.getDefaultAlgorithm()
        );
        tmf.init((KeyStore) null);
        return (X509TrustManager) tmf.getTrustManagers()[0];
    }

    /**
     * Real SSLSocketFactory so OkHttp does not throw NPE
     */
    private SSLSocketFactory createRealSslFactory(X509TrustManager tm) throws Exception {
        SSLContext sslContext = SSLContext.getInstance("TLS");
        sslContext.init(null, new TrustManager[]{tm}, new SecureRandom());
        return sslContext.getSocketFactory();
    }

    @Test
    void testFeignClientBeanCreation() throws Exception {

        // Use real SSL objects (OkHttp requires this)
        X509TrustManager trustManager = createRealTrustManager();
        SSLSocketFactory sslFactory = createRealSslFactory(trustManager);

        // HostnameVerifier can be mocked safely
        HostnameVerifier hostnameVerifier = mock(HostnameVerifier.class);

        FeignClientConfiguration config = new FeignClientConfiguration();

        // ACT — EXACT production code path is executed
        OkHttpClient client = config.feignClient(
                hostnameVerifier,
                sslFactory,
                trustManager
        );

        // ASSERT — ensures bean created correctly (covers all lines)
        assertNotNull(client);
    }

    @Test
    void testFeignObjectMapperBean() {
        FeignClientConfiguration config = new FeignClientConfiguration();

        ObjectMapper mapper = config.feignObjectMapper();

        assertNotNull(mapper);
        assertFalse(mapper.isEnabled(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES));
        assertFalse(mapper.getRegisteredModuleIds().isEmpty());
    }
}