package com.hdfcbank.giftcity.bff.customer.mapper;

import com.hdfcbank.common.models.vo.journey.JourneyData;
import com.hdfcbank.common.models.vo.journey.Profile;
import com.hdfcbank.giftcity.bff.commons.constant.CommonConstants;
import com.hdfcbank.giftcity.bff.commons.model.FcIndiaProfile;
import com.hdfcbank.giftcity.bff.commons.model.MasterDataValue;
import com.hdfcbank.giftcity.bff.commons.utility.CommonUtil;
import com.hdfcbank.giftcity.bff.customer.model.CustomerDetails;
import com.hdfcbank.giftcity.bff.customer.model.RiskAssessmentPageData;
import com.hdfcbank.giftcity.bff.master.mapper.CountryMapper;
import com.hdfcbank.service.adapters.vo.customer.FccCustomerRequest;

import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.MockedStatic;

import java.lang.reflect.Method;
import java.time.LocalDate;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class CreateFCCCustomerMapperImplTest {

    @InjectMocks
    private CreateFCCCustomerMapperImpl mapper;

    @Mock
    private CountryMapper countryMapper;

    @Mock
    private CreateFccMasterMapper createFccMasterMapper;

    private FcIndiaProfile.Profile fcProfile;
    private Profile profile;
    private JourneyData journeyData;
    private Map<String,String> serviceDefaults;
    private Map<String,Object> userInputs;
    private CustomerDetails.EmploymentFinancial employment;
    private CustomerDetails.FatcaDetails fatca;
    private RiskAssessmentPageData riskPage;

    @BeforeEach
    void init() {

        FcIndiaProfile.CustomerFATCADetail fatDetail = new FcIndiaProfile.CustomerFATCADetail();
        fatDetail.setIdDocNum("P123");
        fatDetail.setIdDocExpDat("20250101");
        fatDetail.setNamCustFather("Father");
        fatDetail.setNamCityBirth("Kolkata");
        fatDetail.setCodCntryBirth("IN");
        fatDetail.setTxtEmpadrAdd1("EMP1");
        fatDetail.setTxtEmpadrAdd2("EMP2");
        fatDetail.setTxtEmpadrAdd3("EMP3");
        fatDetail.setTxtEmpadrZip("700001");

        fcProfile = FcIndiaProfile.Profile.builder()
                .mailingAddress1("MA1")
                .mailingAddress2("MA2")
                .mailingAddress3("MA3")
                .mailingCity("Mumbai")
                .mailingState("MH")
                .mailingPinCode("400001")
                .mailingCountry(MasterDataValue.builder().code("IN").description("India").build())
                .txtCustNATNLTY("IND")
                .namCustadrCntry("India")
                .customerFirstName("John")
                .customerLastName("Doe")
                .txtCustSex("M")
                .state("MH")
                .city("Mumbai")
                .country(MasterDataValue.builder().code("IN").description("India").build())
                .motherMaidenName("Jane")
                .refCustItNum("ABCDE1234F")
                .customerFATCADetails(List.of(fatDetail))
                .build();

        profile = Profile.builder()
                .dob("1990-01-01")
                .emailId("john@example.com")
                .build();

        journeyData = JourneyData.builder()
                .mobileNumber("9876543210")
                .isd("+91")
                .build();

        employment = CustomerDetails.EmploymentFinancial.builder()
                .employedSince(LocalDate.of(2020,1,1))
                .qualification(
                        CustomerDetails.Qualification.builder()
                                .key("GRAD")
                                .id("GRAD")
                                .type("GRAD")
                                .build()
                )
                .industryVariation("FINTECH")
                .employerBusinessName("ABC Ltd")
                .employerAddress1("EMP_ADDR1")
                .employerAddress2("EMP_ADDR2")
                .employerAddress3("EMP_ADDR3")
                .employerAddress4("EMP_ADDR4")
                .employerPinCode("400002")
                .purposeOfAccount("SAVINGS")
                .workExperience("5")
                .build();

        fatca = CustomerDetails.FatcaDetails.builder()
                .maritalStatus(CustomerDetails.MaritalStatus.builder()
                        .status("MARRIED")
                        .key("MARRIED")
                        .id("MARRIED")
                        .build())
                .spouseName("Spouse")
                .residenceType(CustomerDetails.ResidentialType.builder()
                        .type("RENTED")
                        .key("RENTED")
                        .id("RENTED")
                        .build())
                .build();

        serviceDefaults = new HashMap<>();
        serviceDefaults.put(CommonConstants.CC_CTYPE, "CTYPE");
        serviceDefaults.put(CommonConstants.CCATEG, "CAT");
        serviceDefaults.put(CommonConstants.CC_MEDIA, "MED");
        serviceDefaults.put(CommonConstants.TRACK_LIMITS, "TL");
        serviceDefaults.put(CommonConstants.TAX_CODE1, "TC1");
        serviceDefaults.put(CommonConstants.RESSTATUS, "RES");
        serviceDefaults.put(CommonConstants.LANGUAGE, "EN");
        serviceDefaults.put(CommonConstants.EMPCODE, "EMP_C");

        // Put Employment in userInputs so mapper.mapEmployment(userInputs) returns non-null
        userInputs = new HashMap<>();
        userInputs.put("employed", employment);
        userInputs.put("employmentFinancial", employment);
        userInputs.put("employment", employment);
        userInputs.put("empFinancial", employment);

        riskPage = RiskAssessmentPageData.builder()
                .cddLevel("LOW")
                .totalWeightedScore(10)
                .build();
    }

    @Test
    void test_toRequest_null() {
        assertNull(mapper.toRequest(null,null,null,null,null,null,null,null));
    }

    @Test
    void test_toRequest_full_success() {

        when(countryMapper.codeFromMasterData(any())).thenReturn("IN");
        when(createFccMasterMapper.resolveNatureOfBusiness("FINTECH")).thenReturn("NOB");

        try (MockedStatic<CommonUtil> st = mockStatic(CommonUtil.class)) {
            st.when(() -> CommonUtil.generateRefNumber(CommonConstants.PI))
                    .thenReturn("PI12345");

            FccCustomerRequest req = mapper.toRequest(
                    journeyData, profile, fcProfile,
                    serviceDefaults, userInputs,
                    createFccMasterMapper, riskPage,
                    "UCIC001"
            );

            assertNotNull(req);
            assertEquals("UCIC001", req.getUcicNo());
            assertEquals("CTYPE", req.getCtype());
            assertEquals("CAT", req.getCcateg());
            assertEquals("MED", req.getMedia());
            assertEquals("PI12345", req.getSName());
        }
    }

    @Test
    void test_mapEmployed_full() {

        when(createFccMasterMapper.resolveNatureOfBusiness("FINTECH"))
                .thenReturn("NOB");

        FccCustomerRequest.Employed e =
                mapper.mapEmployed(employment, fcProfile, createFccMasterMapper, userInputs);

        assertNotNull(e);
        assertEquals(LocalDate.of(2020, 1, 1), e.getSelfEmployedSince());
        assertEquals("NOB", e.getNatureOfBusiness());
    }

    @Test
    void test_mapEmployed_null() {
        assertNull(mapper.mapEmployed(null,null,null,null));
    }

    @Test
    void test_mapPAddress() {
        FccCustomerRequest.PAddress pa = mapper.mapPAddress(fcProfile);
        assertNotNull(pa);
        assertEquals("EMP1", pa.getAdd1());
        assertEquals("EMP2", pa.getAdd2());
        assertEquals("EMP3", pa.getAdd3());
        assertEquals("700001", pa.getPinCode());
    }

    @Test
    void test_mapPAddress_null() {
        assertNull(mapper.mapPAddress(null));
    }

    @Test
    void test_mapNewEmp() {
        FccCustomerRequest.NewEmp ne = mapper.mapNewEmp(serviceDefaults, employment);
        assertEquals("EMP_C", ne.getEmpCode());
        assertEquals("ABC Ltd", ne.getEmpDesc());
    }

    @Test
    void test_mapCustPersonal() {

        FccCustomerRequest.CustPersonal cp =
                mapper.mapCustPersonal(
                        fcProfile,
                        journeyData,
                        profile,
                        userInputs,
                        serviceDefaults,
                        createFccMasterMapper
                );

        assertNotNull(cp);
        assertEquals("John", cp.getFirstName());
        assertEquals("Doe", cp.getLastName());
        assertEquals("9876543210", cp.getMobileNumber());
        assertEquals("ABCDE1234F", cp.getPanNumber());
    }

    @Test
    void test_mapCustPersonal_null() {
        assertNull(mapper.mapCustPersonal(null,null,null,null,null,null));
    }

    @Test
    void test_mapCustDomestic() {

        FccCustomerRequest.CustDomestic cd =
                mapper.mapCustDomestic(profile, fcProfile, employment, fatca);

        assertNotNull(cd);
        assertEquals("GRAD", cd.getEducationStatus());
        assertEquals("MARRIED", cd.getMaritalStatus());
        assertEquals("Spouse", cd.getSpouseName());
        assertEquals("RENTED", cd.getAccomodate());
    }

    @Test
    void test_mapCustDomestic_null() {
        assertNull(mapper.mapCustDomestic(null,null,null,null));
    }

    @Test
    void test_mapCustText() {
        assertNotNull(mapper.mapCustText(employment));
    }

    @Test
    void test_mapCustText_null() {
        assertNull(mapper.mapCustText(null));
    }

    @Test
    void test_mapCustAml() {
        FccCustomerRequest.CustAml aml = mapper.mapCustAml(employment);
        assertEquals("SAVINGS", aml.getPurposeOfAccount());
    }

    @Test
    void test_mapCustAml_null() {
        assertNull(mapper.mapCustAml(null));
    }

    @Test
    void test_mapCustProf() {
        FccCustomerRequest.CustProf cp = mapper.mapCustProf(fcProfile, employment, createFccMasterMapper);
        assertNotNull(cp);
        assertEquals("EMP_ADDR1", cp.getAdd1());
        assertEquals("5", cp.getEmpTenure());
    }

    @Test
    void test_mapCustProf_null() {
        assertNull(mapper.mapCustProf(null,null,null));
    }

    @Test
    void test_fcProfileCountryCode_private_reflection() throws Exception {

        Method m = CreateFCCCustomerMapperImpl.class.getDeclaredMethod(
                "fcProfileCountryCode", FcIndiaProfile.Profile.class);
        m.setAccessible(true);

        String code = (String) m.invoke(mapper, fcProfile);
        assertEquals("IN", code);
    }

    @Test
    void test_fcProfileCountryCode_private_null() throws Exception {
        Method m = CreateFCCCustomerMapperImpl.class.getDeclaredMethod(
                "fcProfileCountryCode", FcIndiaProfile.Profile.class);
        m.setAccessible(true);

        assertNull(m.invoke(mapper, new Object[]{null}));
    }
}