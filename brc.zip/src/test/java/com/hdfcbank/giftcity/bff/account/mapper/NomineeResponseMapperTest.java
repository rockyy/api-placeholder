package com.hdfcbank.giftcity.bff.account.mapper;

import com.hdfcbank.common.models.vo.core.ApiResponseStatus;
import com.hdfcbank.giftcity.bff.account.model.NomineeResponse;
import com.hdfcbank.giftcity.bff.commons.enums.CustomCommonApiStatusCodes;
import com.hdfcbank.service.adapters.vo.account.NomineeApiResponse;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mapstruct.factory.Mappers;

import static org.junit.jupiter.api.Assertions.*;

class NomineeResponseMapperTest {

    private NomineeResponseMapper mapper;

    @BeforeEach
    void setup() {
        mapper = Mappers.getMapper(NomineeResponseMapper.class);
    }

    //  1 — toResponse(null) should return null
    @Test
    void testToResponse_nullInput() {
        assertNull(mapper.toResponse(null));
    }

    //  2 — toResponse should set status = SUCCESS and map fields correctly
    @Test
    void testToResponse_success() {

        NomineeApiResponse.NomineeDtlsDTO dto = new NomineeApiResponse.NomineeDtlsDTO();
        dto.setNomineeId(101L);
        dto.setNomineeName("Alice Nominee");
        dto.setNomineeRelation("Sister");
        dto.setFlgNomnamDisplay("Y");
        dto.setDatBirth("2000-01-01");
        dto.setNomAge(24);

        dto.setNomAdrAdd1("Address Line 1");
        dto.setNomAdrAdd2("Address Line 2");
        dto.setNomAdrAdd3("Address Line 3");
        dto.setNomAdrCity("Mumbai");
        dto.setNomAdrState("MH");
        dto.setNomAdrCntry("IN");
        dto.setNomAdrZip("400001");

        dto.setNomPhoneCountry("+91");
        dto.setNomPhoneArea("022");
        dto.setNomPhone("12345678");
        dto.setNomPhoneMobile("9876543210");
        dto.setNomEmailId("nominee@test.com");
        dto.setAmtShareFixed(50.0);
        dto.setRatSharePct("60");
        dto.setPriority(1);

        dto.setDeceasedDate(null);
        dto.setNominationtype("FULL");
        dto.setNominationTypeDesc("Full Nominee");
        dto.setNamGuardian("Guardian Name");
        dto.setGuardRelationship("Father");
        dto.setGuardAdrAdd1("G-Add1");
        dto.setGuardAdrAdd2("G-Add2");
        dto.setGuardAdrAdd3("G-Add3");
        dto.setGuardAdrCity("Delhi");
        dto.setGuardAdrState("DL");
        dto.setGuardAdrCntry("IN");
        dto.setGuardAdrZip("110001");
        dto.setGuardPhoneCntry("+91");
        dto.setGuardPhoneArea("011");
        dto.setGuardPhone("88888888");
        dto.setGuardPhoneMobile("9999999999");
        dto.setGuardEmailId("guardian@test.com");
        dto.setGuardDatBirth("1970-01-01");
        dto.setFlgIsbankCustomer("N");
        dto.setCodRel(10);
        dto.setGuardCodRel(20);
        dto.setAccountTitle("Ms Alice Nominee");

        //  Invoke
        NomineeResponse response = mapper.toResponse(dto);

        //  Validate top-level object
        assertNotNull(response);
        assertNotNull(response.getStatus());
        assertEquals(CustomCommonApiStatusCodes.SUCCESS.getCode(),
                response.getStatus().getCode());

        assertNotNull(response.getData());
        assertNotNull(response.getData().getNomineeDetails());

        //  Validate mapped fields inside nomineeDetails (from toDetails mapping)
        NomineeResponse.NomineeDetailsResponse.NomineeDetails details =
                response.getData().getNomineeDetails();

        assertEquals("Sister", details.getRelation());
        assertEquals("2000-01-01", details.getDateOfBirth());
        assertEquals("Address Line 1", details.getTxtNomAdrAdd1());
        assertEquals("Address Line 2", details.getTxtNomAdrAdd2());
        assertEquals("Address Line 3", details.getTxtNomAdrAdd3());

        //  Guard fields
        assertEquals("Father", details.getGuardNomineeRelation());
        assertEquals("1970-01-01", details.getGuardDatOfBirth());
    }

    //  3 — toDetails() should map fields properly
    @Test
    void testToDetails_mappingAccuracy() {

        NomineeApiResponse.NomineeDtlsDTO dto = new NomineeApiResponse.NomineeDtlsDTO();
        dto.setNomineeRelation("Brother");
        dto.setDatBirth("1990-12-12");
        dto.setNomAdrAdd1("Line1");
        dto.setNomAdrAdd2("Line2");
        dto.setNomAdrAdd3("Line3");
        dto.setGuardRelationship("Uncle");
        dto.setGuardDatBirth("1965-05-05");

        NomineeResponse.NomineeDetailsResponse.NomineeDetails details =
                mapper.toDetails(dto);

        assertNotNull(details);
        assertEquals("Brother", details.getRelation());
        assertEquals("1990-12-12", details.getDateOfBirth());
        assertEquals("Line1", details.getTxtNomAdrAdd1());
        assertEquals("Line2", details.getTxtNomAdrAdd2());
        assertEquals("Line3", details.getTxtNomAdrAdd3());
        assertEquals("Uncle", details.getGuardNomineeRelation());
        assertEquals("1965-05-05", details.getGuardDatOfBirth());
    }
}