package com.hdfcbank.giftcity.bff.customer.utility;

import ch.qos.logback.classic.Level;
import ch.qos.logback.classic.Logger;
import org.slf4j.LoggerFactory;

import com.hdfcbank.adapters.vo.SendMessageRequest;
import com.hdfcbank.adapters.vo.TargetSystemType;
import com.hdfcbank.common.models.vo.journey.*;
import com.hdfcbank.giftcity.bff.commons.enums.JourneyPageName;
import com.hdfcbank.giftcity.bff.commons.model.FcGcProfile;
import com.hdfcbank.giftcity.bff.commons.model.FcIndiaProfile;
import com.hdfcbank.giftcity.bff.customer.model.ReviewCustomerResponse;
import com.hdfcbank.giftcity.bff.customer.model.RiskAssessmentPageData;
import com.hdfcbank.giftcity.bff.infrastructure.service.JourneyService;
import com.hdfcbank.service.adapters.vo.account.UpdateFccAccountRequest;
import com.hdfcbank.service.adapters.vo.customer.FetchKycResponse;
import com.hdfcbank.service.adapters.vo.customer.UcicApiResponse;

import org.junit.jupiter.api.*;
import org.mockito.MockedStatic;

import java.util.*;

import static com.hdfcbank.giftcity.bff.customer.constants.CustomerConstants.NOMINEE_DETAILS;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class CustomerUtilTest {

    @BeforeAll
    static void muteLogs() {
        Logger root = (Logger) LoggerFactory.getLogger(Logger.ROOT_LOGGER_NAME);
        root.setLevel(Level.OFF);
    }

    private JourneyData journey;

    @BeforeEach
    void setup() {
        JourneyDetail detail = JourneyDetail.builder()
                .systemData(new HashMap<>())
                .journeyStates(new ArrayList<>())
                .domainData(new HashMap<>())
                .build();

        journey = JourneyData.builder()
                .journeyDetail(detail)
                .journeyName("TEST_JOURNEY")
                .journeyId("J001")
                .referenceNo("REF001")
                .isd("91")
                .mobileNumber("9876543210")
                .build();
    }

    // convert()
    @Test
    void testConvertSuccess() {
        Map<String, Object> nomineeMap = new HashMap<>();
        nomineeMap.put("name", "John");
        nomineeMap.put("relation", "Brother");
        nomineeMap.put("addressFromProfile", false);

        Map<String, Object> wrapper = new HashMap<>();
        wrapper.put("nominee", nomineeMap);

        ReviewCustomerResponse.ReviewCustomerDetails.NomineeDetail result =
                CustomerUtil.convert(wrapper, ReviewCustomerResponse.ReviewCustomerDetails.NomineeDetail.class);

        assertNotNull(result);
        assertNotNull(result.getNominee());
        assertEquals("John", result.getNominee().getName());
        assertEquals("Brother", result.getNominee().getRelation());
        assertEquals(false, result.getNominee().getAddressFromProfile());
    }

    @Test
    void testConvertExceptionBranch() {
        Object invalid = new Object();
        Object result = CustomerUtil.convert(invalid, RiskAssessmentPageData.class);
        assertNull(result);
    }

    // sanitizeDob()
    @Test
    void testSanitizeDobValid() {
        assertEquals("2024-01-01", CustomerUtil.sanitizeDob("2024-01-01"));
    }

    @Test
    void testSanitizeDobInvalid() {
        assertThrows(IllegalArgumentException.class,
                () -> CustomerUtil.sanitizeDob("01/01/2020"));
    }

    // sanitizePan()
    @Test
    void testSanitizePanValid() {
        assertEquals("ABCDE1234F", CustomerUtil.sanitizePan("ABCDE1234F"));
    }

    @Test
    void testSanitizePanInvalid() {
        assertEquals("", CustomerUtil.sanitizePan("invalid"));
    }

    // sanitizeOtp()
    @Test
    void testSanitizeOtpValid() {
        assertEquals("123456", CustomerUtil.sanitizeOtp("123456"));
    }

    @Test
    void testSanitizeOtpInvalid() {
        assertEquals("", CustomerUtil.sanitizeOtp("12A456"));
    }

    // sanitizeEmail()
    @Test
    void testSanitizeEmailValid() {
        assertEquals("abc@xyz.com", CustomerUtil.sanitizeEmail("abc@xyz.com"));
    }

    @Test
    void testSanitizeEmailInvalid() {
        assertThrows(IllegalArgumentException.class,
                () -> CustomerUtil.sanitizeEmail("abc###"));
    }

    // sanitizeAccountNumber()
    @Test
    void testSanitizeAccountNumberValid() {
        assertEquals("ACC1234", CustomerUtil.sanitizeAccountNumber("ACC1234"));
    }

    @Test
    void testSanitizeAccountNumberInvalid() {
        assertThrows(IllegalArgumentException.class,
                () -> CustomerUtil.sanitizeAccountNumber("INVALID!!"));
    }

    // sanitizeFreezeFlag()
    @Test
    void testSanitizeFreezeFlagValid() {
        assertEquals("Y", CustomerUtil.sanitizeFreezeFlag("y"));
    }

    @Test
    void testSanitizeFreezeFlagInvalid() {
        assertThrows(IllegalArgumentException.class,
                () -> CustomerUtil.sanitizeFreezeFlag("maybe"));
    }

    // sanitizeUpdateFccAccountRequest()
    @Test
    void testSanitizeUpdateFccAccountRequest() {

        UpdateFccAccountRequest req = UpdateFccAccountRequest.builder()
                .accountNumber("ACC100")
                .creditFreeze("Y")
                .debitFreeze("N")
                .build();

        UpdateFccAccountRequest result = CustomerUtil.sanitizeUpdateFccAccountRequest(req);

        assertEquals("ACC100", result.getAccountNumber());
        assertEquals("N", result.getDebitFreeze());
        assertEquals("Y", result.getCreditFreeze());
        assertNotNull(result);
    }

    // sanitizeSendMessageRequest()
    @Test
    void testSanitizeSendMessageRequestSuccess() {

        SendMessageRequest r = CustomerUtil.sanitizeSendMessageRequest(journey, "TEMPLATE_ID");

        assertEquals("SMS", r.getMessageType());
        assertEquals("SMS", r.getChannel());
        assertEquals(TargetSystemType.AXIOM.name(), r.getTargetSystem());
        assertEquals("TEMPLATE_ID", r.getTemplateId());
        assertEquals("", r.getEmailId());
        assertEquals("919876543210", r.getMobileNumber());
        assertNotNull(r);
    }

    @Test
    void testSanitizeSendMessageRequestNullJourney() {
        assertThrows(IllegalArgumentException.class,
                () -> CustomerUtil.sanitizeSendMessageRequest(null, "TEMPLATE_ID"));
    }

    @Test
    void testSanitizeSendMessageRequestInvalidTemplateIdChars() {
        assertThrows(IllegalArgumentException.class,
                () -> CustomerUtil.sanitizeSendMessageRequest(journey, "TEMPLATE@@@@"));
    }

    // buildAddress()
    @Test
    void testBuildAddressMixed() {
        assertEquals("A, B", CustomerUtil.buildAddress("A", "", "B"));
    }

    @Test
    void testBuildAddressAllBlank() {
        assertNull(CustomerUtil.buildAddress("", " ", null));
    }

    // getNomineeFromProfile()

    @Test
    void testGetNomineeFromProfileCommunication() {

        ReviewCustomerResponse.ReviewCustomerDetails.Nominee n =
                ReviewCustomerResponse.ReviewCustomerDetails.Nominee.builder()
                        .addressFromProfile(true)
                        .addressFromProfileType("COMMUNICATION")
                        .build();

        FcIndiaProfile.Profile p = FcIndiaProfile.Profile.builder()
                .mailingAddress1("Line1").mailingAddress2("Line2").mailingAddress3("Line3")
                .mailingCity("City").mailingState("State").mailingPinCode("560001")
                .mailingCountry(null)
                .build();

        ReviewCustomerResponse.ReviewCustomerDetails.Nominee result =
                CustomerUtil.getNomineeFromProfile(n, p);

        assertEquals("Line1", result.getAddressLine1());
        assertEquals("City", result.getCity());
        assertEquals("560001", result.getPincode());
        assertTrue(result.getAddressFromProfile());
    }

    @Test
    void testGetNomineeFromProfilePermanent() {

        ReviewCustomerResponse.ReviewCustomerDetails.Nominee n =
                ReviewCustomerResponse.ReviewCustomerDetails.Nominee.builder()
                        .addressFromProfile(true)
                        .addressFromProfileType("PERMANENT")
                        .build();

        FcIndiaProfile.Profile p = FcIndiaProfile.Profile.builder()
                .address("A1").address2("A2").address3("A3")
                .city("City").state("State").pinCode("560001")
                .country(null)
                .build();

        ReviewCustomerResponse.ReviewCustomerDetails.Nominee result =
                CustomerUtil.getNomineeFromProfile(n, p);

        assertEquals("A1", result.getAddressLine1());
        assertEquals("City", result.getCity());
        assertEquals("560001", result.getPincode());
        assertTrue(result.getAddressFromProfile());
    }

    // getNomineeDetailFromJourneyData()

    @Test
    void testGetNomineeDetail_JourneyNull() {
        assertNull(CustomerUtil.getNomineeDetailFromJourneyData(null));
    }

    @Test
    void testGetNomineeDetail_UserInputsNull() {
        try (MockedStatic<JourneyService> js = mockStatic(JourneyService.class)) {
            js.when(() -> JourneyService.getDomainPageUserInputs(any(), any()))
                    .thenReturn(null);

            assertNull(CustomerUtil.getNomineeDetailFromJourneyData(journey));
        }
    }

    @Test
    void testGetNomineeDetail_UserInputsEmpty() {
        try (MockedStatic<JourneyService> js = mockStatic(JourneyService.class)) {
            js.when(() -> JourneyService.getDomainPageUserInputs(any(), any()))
                    .thenReturn(Collections.emptyMap());

            assertNull(CustomerUtil.getNomineeDetailFromJourneyData(journey));
        }
    }

    @Test
    void testGetNomineeDetail_NomineeDetailNull() {
        try (MockedStatic<JourneyService> js = mockStatic(JourneyService.class)) {

            Map<String, Object> m = new HashMap<>();
            m.put("nomineeDetail", null);

            js.when(() -> JourneyService.getDomainPageUserInputs(any(), any()))
                    .thenReturn(m);

            assertNull(CustomerUtil.getNomineeDetailFromJourneyData(journey));
        }
    }

    @Test
    void testGetNomineeDetail_Success() {

        Map<String, Object> nomineeMap = new HashMap<>();
        nomineeMap.put("nominee", Map.of("name", "John"));

        Map<String, Object> inputs = new HashMap<>();
        inputs.put("nomineeDetail", nomineeMap);

        try (MockedStatic<JourneyService> js = mockStatic(JourneyService.class)) {

            js.when(() -> JourneyService.getDomainPageUserInputs(any(), any()))
                    .thenReturn(inputs);

            js.when(() -> JourneyService.extractFromJourney(any(), any(), any(), any()))
                    .thenReturn(Optional.of(FcIndiaProfile.Profile.builder().name("X").build()));

            ReviewCustomerResponse.ReviewCustomerDetails.NomineeDetail nd =
                    CustomerUtil.getNomineeDetailFromJourneyData(journey);

            assertNotNull(nd);
            assertNotNull(nd.getNominee());
            assertEquals("John", nd.getNominee().getName());
        }
    }

    // getPrimaryProfile()

    @Test
    void testGetPrimaryProfile() {

        FcIndiaProfile.Profile p =
                FcIndiaProfile.Profile.builder().name("Test").build();

        try (MockedStatic<JourneyService> js = mockStatic(JourneyService.class)) {

            js.when(() -> JourneyService.extractFromJourney(any(), any(), any(), any()))
                    .thenReturn(Optional.of(p));

            Optional<FcIndiaProfile.Profile> result = CustomerUtil.getPrimaryProfile(journey);
            assertTrue(result.isPresent());
            assertEquals("Test", result.get().getName());
        }
    }

    // getFCGiftCityProfile()

    @Test
    void testGetFCGiftCityProfile() {

        FcGcProfile giftCity = new FcGcProfile();

        try (MockedStatic<JourneyService> js = mockStatic(JourneyService.class)) {

            js.when(() -> JourneyService.extractFromJourney(any(), any(), any()))
                    .thenReturn(Optional.of(giftCity));

            Optional<FcGcProfile> result = CustomerUtil.getFCGiftCityProfile(journey);
            assertTrue(result.isPresent());
        }
    }

    // getUcicDetails()

    @Test
    void testGetUcicDetails() {

        UcicApiResponse.UcicSummaryResponse summary =
                UcicApiResponse.UcicSummaryResponse.builder().ucic("UCIC123").build();

        try (MockedStatic<JourneyService> js = mockStatic(JourneyService.class)) {

            js.when(() -> JourneyService.extractFromJourney(any(), any(), any()))
                    .thenReturn(Optional.of(summary));

            Optional<UcicApiResponse.UcicSummaryResponse> r =
                    CustomerUtil.getUcicDetails(journey);

            assertTrue(r.isPresent());
            assertEquals("UCIC123", r.get().getUcic());
        }
    }

    // getCkycDetails()

    @Test
    void testGetCkycDetails() {

        FetchKycResponse.FetchCBRCodesDetails details =
                FetchKycResponse.FetchCBRCodesDetails.builder().ckycId("X").build();

        try (MockedStatic<JourneyService> js = mockStatic(JourneyService.class)) {

            js.when(() -> JourneyService.extractFromJourney(any(), any(), any()))
                    .thenReturn(Optional.of(details));

            Optional<FetchKycResponse.FetchCBRCodesDetails> result =
                    CustomerUtil.getCkycDetails(journey);

            assertTrue(result.isPresent());
            assertEquals("X", result.get().getCkycId());
        }
    }

    // getJourneyState()

    @Test
    void testGetJourneyState() {

        JourneyState st = JourneyState.builder().stateName("STATE1").build();

        journey.getJourneyDetail().setJourneyStates(new ArrayList<>());
        journey.getJourneyDetail().getJourneyStates().add(st);

        Optional<JourneyState> found = CustomerUtil.getJourneyState(journey, "STATE1");

        assertTrue(found.isPresent());
        assertEquals("STATE1", found.get().getStateName());
    }

    // getValueByPath()

    @Test
    void testGetValueByPathSuccess() {

        try (MockedStatic<JourneyService> js = mockStatic(JourneyService.class)) {

            js.when(() -> JourneyService.getDomainPageUserInputs(any(), any()))
                    .thenReturn(Map.of("page", Map.of("field1", "value123")));

            js.when(() -> JourneyService.getByPath(any(), any()))
                    .thenReturn("value123");

            assertEquals("value123",
                    CustomerUtil.getValueByPath(journey, "page", "field1"));
        }
    }

    @Test
    void testGetValueByPathReturnsNull() {

        try (MockedStatic<JourneyService> js = mockStatic(JourneyService.class)) {

            js.when(() -> JourneyService.getDomainPageUserInputs(any(), any()))
                    .thenReturn(Map.of("page", Map.of()));

            js.when(() -> JourneyService.getByPath(any(), any()))
                    .thenReturn(null);

            assertNull(CustomerUtil.getValueByPath(journey, "page", "x"));
        }
    }

    // getRiskAssessment()

    @Test
    void testGetRiskAssessment_SystemDataNull() {

        JourneyDetail d = JourneyDetail.builder()
                .systemData(null)
                .journeyStates(new ArrayList<>())
                .domainData(new HashMap<>())
                .build();

        JourneyData jd = JourneyData.builder().journeyDetail(d).build();

        assertNull(CustomerUtil.getRiskAssessment(jd));
    }

    @Test
    void testGetRiskAssessment_NoRiskObj() {

        Map<String, Map<String, ?>> systemData = new HashMap<>();
        systemData.put(JourneyPageName.RISK_ASSESSMENT.getPageName(),
                Map.of("notRisk", "123"));

        journey.getJourneyDetail().setSystemData(systemData);

        assertNull(CustomerUtil.getRiskAssessment(journey));
    }

    @Test
    void testGetRiskAssessment_Success() {

        Map<String, Object> riskMap = new HashMap<>();
        riskMap.put("risk", Map.of("score", 75));

        Map<String, Map<String, ?>> systemData = new HashMap<>();
        systemData.put(JourneyPageName.RISK_ASSESSMENT.getPageName(), riskMap);

        journey.getJourneyDetail().setSystemData(systemData);

        RiskAssessmentPageData result = CustomerUtil.getRiskAssessment(journey);

        assertNotNull(result);
    }
}