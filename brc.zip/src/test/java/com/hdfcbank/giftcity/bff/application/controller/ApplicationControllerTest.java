package com.hdfcbank.giftcity.bff.application.controller;

import com.hdfcbank.giftcity.bff.application.service.ApplicationService;
import com.hdfcbank.giftcity.bff.customer.model.ApplicationSubmitResponse;
import com.hdfcbank.giftcity.bff.customer.model.InquireSubmitResponse;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import org.springframework.http.ResponseEntity;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ApplicationControllerTest {

    @Mock
    private ApplicationService applicationService;

    @InjectMocks
    private ApplicationController controller;

    private static final String JOURNEY_ID = "JOURNEY123";

    @Test
    void testApplicationSubmitDetails_success() {

        ApplicationSubmitResponse expected =
                ApplicationSubmitResponse.builder()
                        .data(ApplicationSubmitResponse.SubmitDetails.builder()
                                .journeyId(JOURNEY_ID)
                                .build())
                        .build();

        when(applicationService.applicationSubmit(JOURNEY_ID))
                .thenReturn(expected);

        ResponseEntity<ApplicationSubmitResponse> response =
                controller.applicationSubmitDetails(JOURNEY_ID);

        assertNotNull(response);
        assertEquals(200, response.getStatusCode().value());
        assertEquals(expected, response.getBody());

        verify(applicationService, times(1)).applicationSubmit(JOURNEY_ID);
    }

    @Test
    void testInquireSubmitDetails_success() {

        InquireSubmitResponse expected =
                InquireSubmitResponse.builder()
                        .data(InquireSubmitResponse.InquireSubmit.builder()
                                .applicationNumber("APP998")
                                .status(InquireSubmitResponse.SubmitStatus.SUCCESS)
                                .build())
                        .build();

        when(applicationService.inquireSubmit(JOURNEY_ID))
                .thenReturn(expected);

        ResponseEntity<InquireSubmitResponse> response =
                controller.inquireSubmitDetails(JOURNEY_ID);

        assertNotNull(response);
        assertEquals(200, response.getStatusCode().value());
        assertEquals(expected, response.getBody());

        verify(applicationService, times(1)).inquireSubmit(JOURNEY_ID);
    }
}