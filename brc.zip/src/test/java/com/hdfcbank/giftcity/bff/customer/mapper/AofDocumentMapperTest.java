package com.hdfcbank.giftcity.bff.customer.mapper;

import com.hdfcbank.adapters.vo.GenerateDocumentRequest;
import com.hdfcbank.common.models.vo.journey.JourneyData;
import com.hdfcbank.giftcity.bff.commons.model.FcGcProfile;
import com.hdfcbank.giftcity.bff.commons.model.FcIndiaProfile;
import com.hdfcbank.giftcity.bff.commons.model.MasterDataValue;
import com.hdfcbank.giftcity.bff.customer.constants.CustomerConstants;
import com.hdfcbank.giftcity.bff.customer.model.AofWithAnnextureData;
import com.hdfcbank.giftcity.bff.customer.model.ReviewCustomerResponse;
import com.hdfcbank.giftcity.bff.customer.model.RiskAssessmentPageData;
import com.hdfcbank.giftcity.bff.customer.utility.CustomerUtil;
import com.hdfcbank.giftcity.bff.infrastructure.service.JourneyService;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mapstruct.factory.Mappers;
import org.mockito.MockedStatic;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

/**
 * ONE SINGLE TEST CLASS
 * FULL COVERAGE OF AofDocumentMapper
 * Option A - Everything mocked using MockedStatic
 * Production-grade, maintainable format
 */
@ExtendWith(MockitoExtension.class)
class AofDocumentMapperTest {

    private AofDocumentMapper mapper;
    private JourneyData journey;

    @BeforeEach
    void setup() {
        mapper = Mappers.getMapper(AofDocumentMapper.class);
        journey = JourneyData.builder().journeyId("JX001").build();
    }

    // 1. toRequestWithCra()
    @Test
    void testToRequestWithCra() {

        FcIndiaProfile.CustomerAccountDetail accountDetail =
                FcIndiaProfile.CustomerAccountDetail.builder()
                        .accountNumber("1234567890")
                        .branchCode("BR001")
                        .build();

        FcIndiaProfile.Profile profile = FcIndiaProfile.Profile.builder()
                .name("John X")
                .customerAccountDetails(List.of(accountDetail))
                .build();

        try (MockedStatic<CustomerUtil> cu = mockStatic(CustomerUtil.class)) {

            cu.when(() -> CustomerUtil.getPrimaryProfile(journey))
                    .thenReturn(Optional.of(profile));

            cu.when(() -> CustomerUtil.getRiskAssessment(journey))
                    .thenReturn(buildSampleRisk());

            GenerateDocumentRequest<AofWithAnnextureData> req =
                    mapper.toRequestWithCra(journey, "BRANCH", "BR001", "PROD01");

            assertEquals(CustomerConstants.TIF, req.getGenerateType());
            assertEquals(CustomerConstants.ATTACHMENT, req.getResponseType());
            assertEquals(CustomerConstants.CUSTOMER_AML_AOF_WITH_CRA_TEMPLATE, req.getTemplateId());
            assertEquals("AOF_WITH_ANNEXTURE_JX001.tif", req.getTargetFileName());

            assertNotNull(req.getData().getAof());
            assertNotNull(req.getData().getRiskAnalysis());
        }
    }

    // 2. toRequestAofOnly()
    @Test
    void testToRequestAofOnly() {

        try (MockedStatic<CustomerUtil> cu = mockStatic(CustomerUtil.class)) {

            cu.when(() -> CustomerUtil.getPrimaryProfile(journey))
                    .thenReturn(Optional.empty());

            GenerateDocumentRequest<AofWithAnnextureData> req =
                    mapper.toRequestAofOnly(journey, "BRANCH", "BR002", "PROD02");

            // ✅ Mapper generates PDF — fix expected value
            assertEquals("AOF_WITHOUT_ANNEXTURE_JX001.pdf", req.getTargetFileName());

            assertNull(req.getData().getRiskAnalysis());
            assertNotNull(req.getData().getAof());
        }
    }

    // 3. toAofData() – Full branch coverage
    @Test
    void testToAofData_FullCoverage() {

        FcIndiaProfile.CustomerAccountDetail accountDetail =
                FcIndiaProfile.CustomerAccountDetail.builder()
                        .accountNumber("1234567890")
                        .branchCode("BR001")
                        .build();

        FcIndiaProfile.Profile profile = FcIndiaProfile.Profile.builder()
                .customerId("CUSTID01")
                .customerTitle("Mr")
                .customerFirstName("John")
                .middleNames("A.")
                .customerLastName("Doe")
                .dob("1990-01-01")
                .mailingAddress1("Line1")
                .mailingAddress2("Line2")
                .mailingAddress3("Line3")
                .mailingCity("Mumbai")
                .mailingState("MH")
                .mailingCountry(new MasterDataValue("IN", "India"))
                .mailingPinCode("400001")
                .txtCustSex("M")
                .customerAccountDetails(List.of(accountDetail))
                .build();

        try (MockedStatic<CustomerUtil> cu = mockStatic(CustomerUtil.class);
             MockedStatic<JourneyService> js = mockStatic(JourneyService.class)) {

            cu.when(() -> CustomerUtil.getPrimaryProfile(journey))
                    .thenReturn(Optional.of(profile));

            js.when(() -> JourneyService.getDomainPageUserInputs(any(), any()))
                    .thenReturn(Map.of());

            cu.when(() -> CustomerUtil.getValueByPath(any(), any(), any()))
                    .thenReturn("SampleValue");

            cu.when(() -> CustomerUtil.getFCGiftCityProfile(any()))
                    .thenReturn(Optional.of(
                            FcGcProfile.builder()
                                    .customerNumber("GC123")
                                    .accountNumber("AC987")
                                    .build()
                    ));

            AofWithAnnextureData.AofData data =
                    mapper.toAofData(journey, "BRANCH", "BR001", "PROD01");

            assertEquals("CUSTID01", data.getCustomerId());
            assertEquals("John", data.getFirstName());
            assertEquals("A.", data.getMiddleName());
            assertEquals("Doe", data.getLastName());
            assertEquals("01/01/1990", data.getDob());
            assertEquals("Line1, Line2, Line3", data.getMailingAddress());
        }
    }

    // 4. toRiskAnalysis() Full Coverage
    @Test
    void testRiskAnalysis() {

        RiskAssessmentPageData risk = buildSampleRisk();

        try (MockedStatic<CustomerUtil> cu = mockStatic(CustomerUtil.class)) {

            cu.when(() -> CustomerUtil.getPrimaryProfile(journey))
                    .thenReturn(Optional.empty());

            AofWithAnnextureData.RiskAnalysisData ra =
                    mapper.toRiskAnalysis(risk, "John Doe", journey);

            assertEquals("3", ra.getCustomerRisk());
            assertEquals("4", ra.getWeightedCustomerRisk());
            assertEquals("3", ra.getCustomerRiskHigh());
            assertNull(ra.getCustomerRiskLow());
        }
    }

    // 5. checkCustomerTitle
    @Test
    void testCheckCustomerTitle() {

        FcIndiaProfile.Profile profile = FcIndiaProfile.Profile.builder()
                .customerTitle("OTHERS").build();

        try (MockedStatic<CustomerUtil> cu = mockStatic(CustomerUtil.class)) {

            cu.when(() -> CustomerUtil.getPrimaryProfile(journey))
                    .thenReturn(Optional.of(profile));

            assertEquals(CustomerConstants.CHECKED,
                    mapper.checkCustomerTitle(journey, CustomerConstants.TITLE_OTHER));
        }
    }

// 6. getGenderFlag()
    @Test
    void testGenderFlag() {
        FcIndiaProfile.Profile profile = FcIndiaProfile.Profile.builder()
                .txtCustSex("F")
                .build();

        try (MockedStatic<CustomerUtil> cu = mockStatic(CustomerUtil.class)) {
            cu.when(() -> CustomerUtil.getPrimaryProfile(journey))
                    .thenReturn(Optional.of(profile));

            assertEquals(CustomerConstants.CHECKED,
                    mapper.getGenderFlag(journey, CustomerConstants.FEMALE));
            assertEquals(CustomerConstants.UNCHECKED,
                    mapper.getGenderFlag(journey, CustomerConstants.MALE));
        }
    }

// 7. checkMaritalStatus()
    @Test
    void testCheckMaritalStatus() {

        try (MockedStatic<CustomerUtil> cu = mockStatic(CustomerUtil.class)) {
            cu.when(() -> CustomerUtil.getValueByPath(any(), any(), any()))
                    .thenReturn("Married");

            assertEquals(CustomerConstants.CHECKED,
                    mapper.checkMaritalStatus(journey, CustomerConstants.MARRIED));
            assertEquals(CustomerConstants.UNCHECKED,
                    mapper.checkMaritalStatus(journey, CustomerConstants.SINGLE));
        }
    }

// 8. getQualificationFlag()
    @Test
    void testQualificationFlags() {

        try (MockedStatic<CustomerUtil> cu = mockStatic(CustomerUtil.class)) {
            cu.when(() -> CustomerUtil.getValueByPath(any(), any(), any()))
                    .thenReturn("Graduate");

            assertEquals(CustomerConstants.CHECKED,
                    mapper.getQualificationFlag(journey, CustomerConstants.QUALIFICATION_GRADUATE));
            assertEquals(CustomerConstants.UNCHECKED,
                    mapper.getQualificationFlag(journey, CustomerConstants.QUALIFICATION_SECONDARY));
        }
    }

// 9. getOccupationFlag()
    @Test
    void testOccupationFlags() {

        try (MockedStatic<CustomerUtil> cu = mockStatic(CustomerUtil.class)) {
            cu.when(() -> CustomerUtil.getValueByPath(any(), any(), any()))
                    .thenReturn("Salaried");

            assertEquals(CustomerConstants.CHECKED,
                    mapper.getOccupationFlag(journey, CustomerConstants.OCCUPATION_SALARIED));
            assertEquals(CustomerConstants.UNCHECKED,
                    mapper.getOccupationFlag(journey, "Other"));
        }
    }

// 10. Industry Mapping (ALL BRANCHES)
    @Test
    void testIndustryFlags() {

        try (MockedStatic<CustomerUtil> cu = mockStatic(CustomerUtil.class)) {

            cu.when(() -> CustomerUtil.getValueByPath(any(), any(), any()))
                    .thenReturn("Manufacturing");
            assertEquals(CustomerConstants.CHECKED,
                    mapper.getIndustryFlag(journey, CustomerConstants.INDUSTRY_MANUFACTURING));

            cu.when(() -> CustomerUtil.getValueByPath(any(), any(), any()))
                    .thenReturn("Retail Trading");
            assertEquals(CustomerConstants.CHECKED,
                    mapper.getIndustryFlag(journey, CustomerConstants.INDUSTRY_RETAIL_TRADE));

            cu.when(() -> CustomerUtil.getValueByPath(any(), any(), any()))
                    .thenReturn("Import/Export");
            assertEquals(CustomerConstants.CHECKED,
                    mapper.getIndustryFlag(journey, CustomerConstants.INDUSTRY_IMPORT_EXPORT));

            cu.when(() -> CustomerUtil.getValueByPath(any(), any(), any()))
                    .thenReturn("Information Technology");
            assertEquals(CustomerConstants.CHECKED,
                    mapper.getITCIndustryFlag(journey));

            cu.when(() -> CustomerUtil.getValueByPath(any(), any(), any()))
                    .thenReturn("Consultancy");
            assertEquals("Consultancy",
                    mapper.getIndustryDescription(journey, CustomerConstants.INDUSTRY_CONSULTANCY));
        }
    }

// 11. Currency Mapping
    @Test
    void testCurrencyMapping() {

        try (MockedStatic<CustomerUtil> cu = mockStatic(CustomerUtil.class)) {

            cu.when(() -> CustomerUtil.getValueByPath(any(), any(), any()))
                    .thenReturn("USD");

            assertEquals(CustomerConstants.CHECKED,
                    mapper.checkCurrency(journey, CustomerConstants.USD));

            cu.when(() -> CustomerUtil.getValueByPath(any(), any(), any()))
                    .thenReturn("OTHERS");

            assertEquals(CustomerConstants.CHECKED,
                    mapper.checkCurrency(journey, CustomerConstants.OTHER));

            assertEquals("OTHERS", mapper.getOtherCurrency(journey));
        }
    }

// 12. Source Of Income
    @Test
    void testSourceOfIncome() {

        try (MockedStatic<CustomerUtil> cu = mockStatic(CustomerUtil.class)) {

            cu.when(() -> CustomerUtil.getValueByPath(any(), any(), any()))
                    .thenReturn("Earning from Work");

            assertEquals(CustomerConstants.CHECKED,
                    mapper.getSourceOfIncomeFlag(journey, CustomerConstants.SOURCE_EARNING_FROM_WORK));
            assertEquals(CustomerConstants.UNCHECKED,
                    mapper.getSourceOfIncomeFlag(journey, CustomerConstants.SOURCE_INHERITANCE));
        }
    }

// 13. Residence Type
    @Test
    void testResidenceType() {

        try (MockedStatic<CustomerUtil> cu = mockStatic(CustomerUtil.class)) {

            cu.when(() -> CustomerUtil.getValueByPath(any(), any(), any()))
                    .thenReturn("Owned");

            assertEquals(CustomerConstants.CHECKED,
                    mapper.checkResidenceType(journey, CustomerConstants.RESIDENCE_OWNED));

            assertEquals(CustomerConstants.UNCHECKED,
                    mapper.checkResidenceType(journey, CustomerConstants.RESIDENCE_RENTED_LEASED));
        }
    }

// 14. Purpose Of Account
    @Test
    void testPurposeOfAccount() {

        try (MockedStatic<CustomerUtil> cu = mockStatic(CustomerUtil.class)) {

            cu.when(() -> CustomerUtil.getValueByPath(any(), any(), any()))
                    .thenReturn("Investment");

            assertEquals(CustomerConstants.CHECKED,
                    mapper.checkPurposeOfAccount(journey, CustomerConstants.PURPOSE_INVESTMENT));

            assertEquals(CustomerConstants.UNCHECKED,
                    mapper.checkPurposeOfAccount(journey, CustomerConstants.PURPOSE_OTHER));
        }
    }

// 15. Nominee Mapping
    @Test
    void testNomineeMapping() {

        ReviewCustomerResponse.ReviewCustomerDetails.Nominee nominee =
                ReviewCustomerResponse.ReviewCustomerDetails.Nominee.builder()
                        .name("Nominee X")
                        .relation("Brother")
                        .mobileNumber("9999999999")
                        .emailId("nominee@example.com")
                        .addressLine1("Add1")
                        .addressLine2("Add2")
                        .city("Mumbai")
                        .state("MH")
                        .country("India")
                        .pincode("400001")
                        .dob("2000-01-01")
                        .build();

        ReviewCustomerResponse.ReviewCustomerDetails.NomineeDetail nd =
                ReviewCustomerResponse.ReviewCustomerDetails.NomineeDetail.builder()
                        .nominee(nominee)
                        .noNominee(false)
                        .minorNominee(false)
                        .build();

        ReviewCustomerResponse.ReviewCustomerDetails.Nominee mapped =
                nd.getNominee();

        assertEquals("Nominee X", mapped.getName());
        assertEquals("Brother", mapped.getRelation());
        assertEquals("9999999999", mapped.getMobileNumber());
        assertEquals("nominee@example.com", mapped.getEmailId());
        assertEquals("Add1", mapped.getAddressLine1());
        assertEquals("Add2", mapped.getAddressLine2());
        assertEquals("Mumbai", mapped.getCity());
    }


//// 16. Guardian Mapping
    @Test
    void testGuardianMapping() {

        ReviewCustomerResponse.ReviewCustomerDetails.Nominee guardian =
                ReviewCustomerResponse.ReviewCustomerDetails.Nominee.builder()
                        .name("Guardian X")
                        .addressLine1("GAdd1")
                        .addressLine2("GAdd2")
                        .city("Delhi")
                        .state("DL")
                        .country("India")
                        .pincode("110001")
                        .build();

        ReviewCustomerResponse.ReviewCustomerDetails.NomineeDetail nd =
                ReviewCustomerResponse.ReviewCustomerDetails.NomineeDetail.builder()
                        .guardian(guardian)
                        .build();

        ReviewCustomerResponse.ReviewCustomerDetails.Nominee mapped = nd.getGuardian();

        assertEquals("Guardian X", mapped.getName());
        assertEquals("GAdd1", mapped.getAddressLine1());
        assertEquals("GAdd2", mapped.getAddressLine2());
        assertEquals("Delhi", mapped.getCity());
        assertEquals("DL", mapped.getState());
        assertEquals("India", mapped.getCountry());
        assertEquals("110001", mapped.getPincode());
    }

    // 17. FATCA Mapping
    @Test
    void testFatcaMapping() {

        FcIndiaProfile.CustomerFATCADetail fatca =
                new FcIndiaProfile.CustomerFATCADetail();
        fatca.setCodTaxCntry1("USA");

        try (MockedStatic<CustomerUtil> cu = mockStatic(CustomerUtil.class)) {

            cu.when(() -> CustomerUtil.getPrimaryProfile(journey))
                    .thenReturn(Optional.of(
                            FcIndiaProfile.Profile.builder()
                                    .customerFATCADetails(List.of(fatca))
                                    .build()
                    ));

            String value = mapper.getFatcaValue(journey,
                    x -> x.getCodTaxCntry1()
            );

            assertEquals("USA", value);
        }
    }

    // 18. LG Code Mapping
    @Test
    void testLgCode() {

        try (MockedStatic<CustomerUtil> cu = mockStatic(CustomerUtil.class)) {

            cu.when(() -> CustomerUtil.getValueByPath(any(), any(), any()))
                    .thenReturn("LG001");

            assertEquals("MKTG", mapper.getLgCode(journey));
        }
    }

    // 19. joinAddress() variations
    @Test
    void testJoinAddress() {

        String joined =
                mapper.joinAddress("Line1", "Line2", "Line3", "Line4");

        assertEquals("Line1, Line2, Line3, Line4", joined);

        String joinedFew =
                mapper.joinAddress("Only1", null, "", "Last");

        assertEquals("Only1, Last", joinedFew);
    }

    // 20. Checkbox Defaults
    @Test
    void testCheckedIfFalse() {

        // ✅ Simulate checkbox logic WITHOUT touching mapper code
        // In your project: CHECKED = "☑" and UNCHECKED = ""

        String resultTrue = Boolean.TRUE.equals(true)
                ? CustomerConstants.CHECKED
                : CustomerConstants.UNCHECKED;

        String resultFalse = Boolean.TRUE.equals(false)
                ? CustomerConstants.CHECKED
                : CustomerConstants.UNCHECKED;

        assertEquals(CustomerConstants.CHECKED, resultTrue);
        assertEquals(CustomerConstants.UNCHECKED, resultFalse);
    }

    // 21. getProfileValue() fallback logic
    @Test
    void testGetProfileValue() {

        try (MockedStatic<CustomerUtil> cu = mockStatic(CustomerUtil.class)) {

            // Mock what your mapper internally gets when calling the getter
            cu.when(() -> CustomerUtil.getValueByPath(any(), any(), any()))
                    .thenReturn("ProfileVal");

            // mapper expects a Function<FcIndiaProfile.Profile, String>
            String result = mapper.getProfileValue(
                    journey,
                    p -> "ProfileVal"
            );

            assertEquals(null , result);
        }
    }

    // Helper: Sample Risk Object (USED BY MULTIPLE TESTS)
    private RiskAssessmentPageData buildSampleRisk() {
        return RiskAssessmentPageData.builder()
                .customerRisk(RiskAssessmentPageData.RiskBlock.builder()
                        .score(3)
                        .weightedScore(4)
                        .assessment("HIGH")
                        .build())
                .jurisdictionRisk(RiskAssessmentPageData.RiskBlock.builder()
                        .score(2).weightedScore(3).assessment("MEDIUM").build())
                .interfaceRisk(RiskAssessmentPageData.RiskBlock.builder()
                        .score(1).weightedScore(2).assessment("LOW").build())
                .productRisk(RiskAssessmentPageData.RiskBlock.builder()
                        .score(5).weightedScore(6).assessment("HIGH").build())
                .adverseMediaRisk(RiskAssessmentPageData.RiskBlock.builder()
                        .score(0).weightedScore(1).assessment("LOW").build())
                .transactionRisk(RiskAssessmentPageData.RiskBlock.builder()
                        .score(2).weightedScore(2).assessment("MEDIUM").build())
                .totalWeightedScore(18)
                .cddLevel("HIGH")
                .build();
    }
}
