package com.hdfcbank.giftcity.bff.customer.utility;

import com.hdfcbank.common.models.vo.journey.JourneyData;
import com.hdfcbank.common.models.vo.journey.JourneyDetail;
import com.hdfcbank.common.models.vo.mdc.MDCValues;
import com.hdfcbank.giftcity.bff.commons.constant.CommonConstants;
import com.hdfcbank.giftcity.bff.commons.enums.CommonJourneyStates;
import com.hdfcbank.giftcity.bff.commons.exception.CustomValidationException;
import com.hdfcbank.giftcity.bff.commons.model.CustomValidationStatus;
import com.hdfcbank.giftcity.bff.commons.properties.CustomValidationProperties;
import com.hdfcbank.giftcity.bff.commons.utility.ValidationHelper;
import com.hdfcbank.giftcity.bff.customer.model.CustomerApiStatusCode;
import com.hdfcbank.giftcity.bff.customer.model.IdentifyCustomerRequest;
import com.hdfcbank.giftcity.bff.infrastructure.service.JourneyService;
import com.hdfcbank.service.adapters.vo.customer.FetchCasaResponse;
import com.hdfcbank.service.adapters.vo.customer.IdentifyGCCustomerResponse;

import org.junit.jupiter.api.*;
import org.mockito.*;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class JourneyValidationProcessorTest {

    @Mock
    private ValidationFailureHandler validationFailureHandler;

    @Mock
    private CustomValidationProperties customValidationProperties;

    @Mock
    private ValidationHelper validationHelper;

    @Mock
    private JourneyService journeyService;

    @InjectMocks
    private JourneyValidationProcessor processor;

    private CustomValidationProperties.CustomValidations journeyConfig;
    private CustomValidationProperties.FieldDetail fieldDetail;

    @BeforeEach
    void init() {
        MockitoAnnotations.openMocks(this);

        journeyConfig = new CustomValidationProperties.CustomValidations();
        journeyConfig.setDefaultMessage("DefaultMessage");
        journeyConfig.setDefaultMessageHeading("DefaultHeading");

        fieldDetail = new CustomValidationProperties.FieldDetail();
        fieldDetail.setType("mobileNo");
        fieldDetail.setCode("M01");
        fieldDetail.setMandatory(true);
        fieldDetail.setLength(10);
        fieldDetail.setAllowedRegex("\\d+");
        fieldDetail.setMessageHeading("MH");
        fieldDetail.setMessage("Message %s");
        journeyConfig.setFieldsDetail(List.of(fieldDetail));

        when(customValidationProperties.getJourneys()).thenReturn(
                Map.of("GIFT", journeyConfig)
        );

        // Set journey name in MDCValues.getJourneyName() simulation
        MDCValues.setJourneyName("GIFT");

        // Basic working JourneyData mock
        JourneyData jd = JourneyData.builder()
                .journeyDetail(JourneyDetail.builder()
                        .systemData(new HashMap<>())
                        .journeyStates(new ArrayList<>())
                        .domainData(new HashMap<>())
                        .build())
                .journeyName("GIFT")
                .journeyId("J001")
                .build();

        when(journeyService.fetchJourney(anyString())).thenReturn(jd);

        // validationHelper returns failure when needed
        when(validationHelper.getErrors(anyString(), anyList(), any()))
                .thenAnswer(inv -> {
                    CustomValidationStatus status = CustomValidationStatus.builder()
                            .title("t")
                            .code("c")
                            .message("m")
                            .build();

                    status.setErrors(List.of("err"));
                    return status;
                });
    }

    // manageValidationViolation() coverage
    @Test
    void testManageValidationViolation_NoFields_NoException() {
        assertDoesNotThrow(() -> processor.manageValidationViolation(Collections.emptyList(), "J001"));
    }

    @Test
    void testManageValidationViolation_WithFailures_ThrowsException() {
        List<CustomValidationProperties.FieldDetail> list = List.of(fieldDetail);

        doThrow(new CustomValidationException(CustomerApiStatusCode.CUSTOM_VALIDATION_EXCEPTION, List.of("x")))
                .when(validationHelper)
                .getErrors(anyString(), anyList(), any());

        assertThrows(CustomValidationException.class,
                () -> processor.manageValidationViolation(list, "J001"));
    }

    // getErrors() coverage
    @Test
    void testGetErrors_MessagePresent() {
        fieldDetail.setMessage("Hello %s");

        List<String> errors = invokeGetErrors(List.of(fieldDetail));

        assertEquals("MH", errors.get(0)); // heading
        assertTrue(errors.get(1).contains("Hello")); // default structure
    }

    @Test
    void testGetErrors_MessageNull_DefaultMessageApplied() {
        fieldDetail.setMessage(null);

        List<String> errors = invokeGetErrors(List.of(fieldDetail));

        assertEquals("DefaultHeading", errors.get(0));
        assertTrue(errors.get(1).contains("DefaultMessage"));
    }

    private List<String> invokeGetErrors(List<CustomValidationProperties.FieldDetail> fields) {
        return callPrivateErrors(fields);
    }

    private List<String> callPrivateErrors(List<CustomValidationProperties.FieldDetail> details) {
        try {
            var m = JourneyValidationProcessor.class.getDeclaredMethod(
                    "getErrors", List.class, CustomValidationProperties.class);
            m.setAccessible(true);
            return (List<String>) m.invoke(null, details, customValidationProperties);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    // validateRequest() coverage
    @Test
    void testValidateRequest_DOB() {
        IdentifyCustomerRequest r = IdentifyCustomerRequest.builder()
                .mobileNo("123456")
                .identifierName("DOB")
                .identifierValue("1990-01-01")
                .build();

        when(validationHelper.validateData(eq("dob"), any(), any(), any()))
                .thenReturn(null);
        when(validationHelper.validateData(eq("mobileNo"), any(), any(), any()))
                .thenReturn(null);

        assertDoesNotThrow(() -> processor.validateRequest(r, "J001"));
    }

    @Test
    void testValidateRequest_PAN() {
        IdentifyCustomerRequest r = IdentifyCustomerRequest.builder()
                .mobileNo("123456")
                .identifierName("PAN")
                .identifierValue("ABCDE1234F")
                .build();

        when(validationHelper.validateData(eq("pan"), any(), any(), any()))
                .thenReturn(null);
        when(validationHelper.validateData(eq("mobileNo"), any(), any(), any()))
                .thenReturn(null);

        assertDoesNotThrow(() -> processor.validateRequest(r, "J001"));
    }

    @Test
    void testValidateRequest_OtherIdentifier() {
        IdentifyCustomerRequest r = IdentifyCustomerRequest.builder()
                .mobileNo("123456")
                .identifierName("ABC")
                .identifierValue("x")
                .build();

        when(validationHelper.validateData(eq("identifierName"), any(), any(), any()))
                .thenReturn(null);
        when(validationHelper.validateData(eq("mobileNo"), any(), any(), any()))
                .thenReturn(null);

        assertDoesNotThrow(() -> processor.validateRequest(r, "J001"));
    }

    @Test
    void testValidateRequest_WithFailure_Throws() {
        IdentifyCustomerRequest r = IdentifyCustomerRequest.builder()
                .mobileNo("")
                .identifierName("DOB")
                .identifierValue("")
                .build();

        when(validationHelper.validateData(any(), any(), any(), any()))
                .thenReturn(fieldDetail); // indicates failure

        assertThrows(CustomValidationException.class,
                () -> processor.validateRequest(r, "J001"));
    }

    // validate(profile) coverage
    @Test
    void testValidateProfile_NoSpaceInName() {
        FetchCasaResponse.Profile p = FetchCasaResponse.Profile.builder()
                .name("SingleName")
                .gender("M")
                .email("a@b.com")
                .kycStatus("K")
                .panNumber("ABCDE1234F")
                .build();

        when(validationHelper.validateData(any(), any(), any(), any())).thenReturn(null);

        assertDoesNotThrow(() -> processor.validate(p, "J001"));
    }

    @Test
    void testValidateProfile_WithSpaceSplit() {
        FetchCasaResponse.Profile p = FetchCasaResponse.Profile.builder()
                .name("John Doe")
                .gender("M")
                .email("a@b.com")
                .kycStatus("K")
                .panNumber("ABCDE1234F")
                .build();

        when(validationHelper.validateData(any(), any(), any(), any())).thenReturn(null);

        assertDoesNotThrow(() -> processor.validate(p, "J001"));
    }

    @Test
    void testValidateProfile_WithFailure_Throws() {

        // Spy on processor so we can override its internal validateData()
        JourneyValidationProcessor spyProcessor = Mockito.spy(processor);

        FetchCasaResponse.Profile p = FetchCasaResponse.Profile.builder()
                .name("John")
                .gender("M")
                .email("a@b.com")
                .build();

        // Force JourneyValidationProcessor.validateData() to ALWAYS fail
        Mockito.doReturn(fieldDetail)
                .when(spyProcessor)
                .validateData(anyString(), anyString(), any(), anyString());

        // Create CustomValidationStatus with errors (required for throwing)
        CustomValidationStatus status = CustomValidationStatus.builder()
                .title("t")
                .code("c")
                .message("m")
                .build();
        status.setErrors(List.of("err"));

        // When manageValidationViolation calls validationHelper.getErrors
        when(validationHelper.getErrors(anyString(), anyList(), any()))
                .thenReturn(status);

        // manageValidationViolation calls this internally
        doNothing().when(journeyService)
                .updateJourneyDetailDropOff(any(), any(), any());

        // NOW exception is thrown correctly
        assertThrows(CustomValidationException.class,
                () -> spyProcessor.validate(p, "J001"));
    }

    // -------------------------------------------------------------------------
    // validateCustomerEligibility()
    // -------------------------------------------------------------------------
    @Test
    void testValidateCustomerEligibility_NotEligible() {
        FetchCasaResponse.Profile p = FetchCasaResponse.Profile.builder()
                .customerType("Retail")
                .flgBlocked("Y")
                .build();

        doThrow(new CustomValidationException(CustomerApiStatusCode.NO_ELIGIBLE_CUSTOMER, List.of("x")))
                .when(validationFailureHandler)
                .dropOnValidationFailure(any(), any(), any(), any());

        assertThrows(CustomValidationException.class,
                () -> processor.validateCustomerEligibility("J001", p));
    }

    @Test
    void testValidateCustomerEligibility_Eligible_NoException() {
        FetchCasaResponse.Profile p = FetchCasaResponse.Profile.builder()
                .customerType("BUSINESS")
                .flgBlocked("N")
                .build();

        assertDoesNotThrow(() -> processor.validateCustomerEligibility("J001", p));
    }

    // validateEtbCustomer()
    @Test
    void testValidateEtbCustomer_NullResponse() {
        assertDoesNotThrow(() -> processor.validateEtbCustomer(null, "J001"));
    }

    @Test
    void testValidateEtbCustomer_DataNull() {
        IdentifyGCCustomerResponse r = new IdentifyGCCustomerResponse();
        assertDoesNotThrow(() -> processor.validateEtbCustomer(r, "J001"));
    }

    @Test
    void testValidateEtbCustomer_isEtb_Fails() {

        IdentifyGCCustomerResponse.GCData data =
                IdentifyGCCustomerResponse.GCData.builder()
                        .etb(CommonConstants.ETB) // MUST match constant exactly
                        .build();

        IdentifyGCCustomerResponse response = new IdentifyGCCustomerResponse();
        response.setData(data);

// Mock the failure handler so it throws the expected exception
        Mockito.doThrow(
                        new CustomValidationException(
                                CustomerApiStatusCode.NO_ELIGIBLE_GCCUSTOMER,
                                List.of("x")
                        )
                ).when(validationFailureHandler)
                .dropOnValidationFailure(
                        anyString(),
                        eq(CustomerApiStatusCode.NO_ELIGIBLE_GCCUSTOMER),
                        anyString(),
                        any()
                );

// Validate that exception is thrown
        assertThrows(CustomValidationException.class,
                () -> processor.validateEtbCustomer(response, "J001"));
    }

    @Test
    void testValidateEtbCustomer_NotEtb_NoException() {
        IdentifyGCCustomerResponse.GCData data =
                IdentifyGCCustomerResponse.GCData.builder().etb("NOT_ETB").build();

        IdentifyGCCustomerResponse r = new IdentifyGCCustomerResponse();
        r.setData(data);

        assertDoesNotThrow(() -> processor.validateEtbCustomer(r, "J001"));
    }

    // validateData() coverage
    @Test
    void testValidateData_MandatoryFail() {
        fieldDetail.setMandatory(true);
        fieldDetail.setType("mobileNo");

        var result = processor.validateData("mobileNo", "", customValidationProperties, "GIFT");
        assertEquals(fieldDetail, result);
    }

    @Test
    void testValidateData_AllowedValuesMismatch() {
        fieldDetail.setAllowedValues(List.of("abc"));
        var result = processor.validateData("mobileNo", "xyz", customValidationProperties, "GIFT");
        assertEquals(fieldDetail, result);
    }

    @Test
    void testValidateData_NotAllowedValuesHit() {
        fieldDetail.setNotAllowedValues(List.of("bad"));
        var result = processor.validateData("mobileNo", "bad", customValidationProperties, "GIFT");
        assertEquals(fieldDetail, result);
    }

    @Test
    void testValidateData_LengthOverflow() {
        fieldDetail.setLength(3);
        var result = processor.validateData("mobileNo", "12345", customValidationProperties, "GIFT");
        assertEquals(fieldDetail, result);
    }

    @Test
    void testValidateData_RegexMismatch() {
        fieldDetail.setAllowedRegex("\\d+");
        var result = processor.validateData("mobileNo", "abc", customValidationProperties, "GIFT");
        assertEquals(fieldDetail, result);
    }

    @Test
    void testValidateData_FieldMissing_ReturnNull() {
        // No fieldDetail of type "wrongType"
        var result = processor.validateData("wrongType", "123", customValidationProperties, "GIFT");
        assertNull(result);
    }
}
