package com.hdfcbank.giftcity.bff.commons.aspect;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hdfcbank.adapters.clients.feign.journey.JourneyServiceFeignClient;
import com.hdfcbank.common.models.constant.RequestHeaders;
import com.hdfcbank.common.models.vo.journey.JourneyData;
import com.hdfcbank.common.models.vo.journey.JourneyDetail;
import com.hdfcbank.common.models.vo.journey.JourneyState;
import com.hdfcbank.exception.BusinessValidationException;
import com.hdfcbank.giftcity.bff.commons.annotation.ValidateJourney;
import com.hdfcbank.giftcity.bff.commons.config.JourneyContextHolder;
import com.hdfcbank.giftcity.bff.commons.constant.CommonConstants;
import com.hdfcbank.giftcity.bff.commons.enums.CommonJourneyStates;
import com.hdfcbank.giftcity.bff.commons.exception.CustomValidationException;
import com.hdfcbank.giftcity.bff.commons.model.CustomValidationStatus;
import com.hdfcbank.giftcity.bff.commons.properties.CustomValidationProperties;
import com.hdfcbank.giftcity.bff.commons.utility.TextSanityUtil;
import jakarta.servlet.http.HttpServletRequest;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.reflect.MethodSignature;

import org.junit.jupiter.api.*;
import org.mockito.MockedStatic;

import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import java.lang.reflect.Method;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import ch.qos.logback.classic.Logger;
import ch.qos.logback.classic.Level;
import org.slf4j.LoggerFactory;

public class ValidateJourneyAspectTest {

    @BeforeAll
    static void muteValidateJourneyLogs() {
        Logger logger = (Logger) LoggerFactory.getLogger(ValidateJourneyAspect.class);
        logger.setLevel(Level.OFF);
    }

    private JourneyServiceFeignClient feignClient;
    private CustomValidationProperties customProps;
    private ObjectMapper objectMapper;

    private ValidateJourneyAspect aspect;
    private JoinPoint joinPoint;
    private MethodSignature signature;

    private ServletRequestAttributes attributes;
    private HttpServletRequest request;

    private JourneyData journeyData;
    private JourneyDetail journeyDetail;

    private MockedStatic<TextSanityUtil> sanitizeMock;

    @BeforeEach
    void setup() throws Exception {

        feignClient = mock(JourneyServiceFeignClient.class);
        customProps = mock(CustomValidationProperties.class);
        objectMapper = mock(ObjectMapper.class);

        aspect = new ValidateJourneyAspect(feignClient, customProps, objectMapper);

        joinPoint = mock(JoinPoint.class);
        signature = mock(MethodSignature.class);

        when(joinPoint.getSignature()).thenReturn(signature);

        Method method = DummyController.class.getMethod("dummyMethod");
        when(signature.getMethod()).thenReturn(method);

        JourneyState initialState = JourneyState.builder()
                .stateName(CommonJourneyStates.CUSTOMER_PROFILE_SUCCESS.name())
                .createdOn(new Date())
                .build();

        journeyDetail = JourneyDetail.builder()
                .journeyStates(new ArrayList<>(List.of(initialState)))
                .systemData(new HashMap<>())
                .build();

        journeyData = JourneyData.builder()
                .journeyId("J123")
                .journeyName("GIFT")
                .journeyDetail(journeyDetail)
                .build();

        attributes = mock(ServletRequestAttributes.class);
        request = mock(HttpServletRequest.class);

        sanitizeMock = mockStatic(TextSanityUtil.class);
        sanitizeMock.when(() -> TextSanityUtil.sanitize(anyString())).thenReturn("CLEAN");
    }

    @AfterEach
    void tearDown() {
        sanitizeMock.close();
        JourneyContextHolder.clear();
    }

    static class DummyController {

        @ValidateJourney(
                shouldExists = {CommonJourneyStates.CUSTOMER_PROFILE_SUCCESS},
                shouldNotExists = {CommonJourneyStates.DROP_OFF_CUSTOMER_NOT_AVAILABLE},
                hasAny = {
                        CommonJourneyStates.CUSTOMER_PROFILE_SUCCESS,
                        CommonJourneyStates.FETCH_CUSTOMER_DETAILS_SUCCESS
                },
                successStates = {CommonJourneyStates.CUSTOMER_PROFILE_SUCCESS}
        )
        public void dummyMethod() {
            // Intentionally left blank: method is only used as a target for @ValidateJourney in tests
        }
    }

    @Test
    void test_success() {

        when(attributes.getRequest()).thenReturn(request);
        when(request.getHeader(RequestHeaders.JOURNEY_ID)).thenReturn("J123");
        RequestContextHolder.setRequestAttributes(attributes);

        when(feignClient.fetch((String) "J123")).thenReturn(journeyData);
        when(customProps.getJourneys()).thenReturn(Collections.emptyMap());

        assertDoesNotThrow(() -> aspect.validateJourney(joinPoint));

        assertEquals("J123", JourneyContextHolder.getJourneyData().getJourneyId());
        assertFalse(JourneyContextHolder.getJourneyData().getJourneyDetail().getJourneyStates().isEmpty());
        verify(feignClient, times(1)).fetch((String) "J123");

        aspect.clearJourneyContext();
        assertNull(JourneyContextHolder.getJourneyData());
    }

    @Test
    void test_journey_not_found() {

        when(attributes.getRequest()).thenReturn(request);
        when(request.getHeader(RequestHeaders.JOURNEY_ID)).thenReturn("INVALID");
        RequestContextHolder.setRequestAttributes(attributes);

        when(feignClient.fetch((String) "INVALID")).thenReturn(null);

        BusinessValidationException ex = assertThrows(BusinessValidationException.class,
                () -> aspect.validateJourney(joinPoint));

        assertNotNull(ex.getMessage());
        verify(feignClient, times(1)).fetch((String) "INVALID");
    }

    @Test
    void test_dropoff_list_throws_custom_validation() {

        JourneyState dropState = JourneyState.builder()
                .stateName(CommonJourneyStates.DROP_OFF_CUSTOMER_NOT_AVAILABLE.name())
                .createdOn(new Date())
                .build();

        journeyDetail.setJourneyStates(List.of(dropState));

        CustomValidationProperties.CustomValidations validations =
                new CustomValidationProperties.CustomValidations();

        validations.setDropOffStates(List.of(CommonJourneyStates.DROP_OFF_CUSTOMER_NOT_AVAILABLE.name()));

        when(customProps.getJourneys()).thenReturn(Map.of("GIFT", validations));

        Map<String, Map<String, ?>> sys = new HashMap<>();
        sys.put(CommonConstants.JOURNEY_STATUS_DETAIL,
                Map.of(CommonConstants.JOURNEY_DROP_OFF,
                        List.of(Map.of("reason", "BAD"))));
        journeyDetail.setSystemData(sys);

        CustomValidationStatus status = new CustomValidationStatus();
        when(objectMapper.convertValue(any(), eq(CustomValidationStatus.class)))
                .thenReturn(status);

        when(attributes.getRequest()).thenReturn(request);
        when(request.getHeader(RequestHeaders.JOURNEY_ID)).thenReturn("J123");
        RequestContextHolder.setRequestAttributes(attributes);

        when(feignClient.fetch((String) "J123")).thenReturn(journeyData);

        assertThrows(CustomValidationException.class,
                () -> aspect.validateJourney(joinPoint));

        assertEquals(1, journeyDetail.getJourneyStates().size());
        verify(objectMapper, times(1)).convertValue(any(), eq(CustomValidationStatus.class));
    }

    @Test
    void test_dropoff_state_systemData_null_skips() {

        JourneyState successState = JourneyState.builder()
                .stateName(CommonJourneyStates.CUSTOMER_PROFILE_SUCCESS.name())
                .createdOn(new Date())
                .build();

        journeyDetail.setJourneyStates(List.of(successState));
        journeyDetail.setSystemData(null);

        CustomValidationProperties.CustomValidations validations =
                new CustomValidationProperties.CustomValidations();

        validations.setDropOffStates(List.of(CommonJourneyStates.DROP_OFF_CUSTOMER_NOT_AVAILABLE.name()));

        when(customProps.getJourneys()).thenReturn(Map.of("GIFT", validations));

        when(attributes.getRequest()).thenReturn(request);
        when(request.getHeader(RequestHeaders.JOURNEY_ID)).thenReturn("J123");
        RequestContextHolder.setRequestAttributes(attributes);

        when(feignClient.fetch((String) "J123")).thenReturn(journeyData);

        assertDoesNotThrow(() -> aspect.validateJourney(joinPoint));

        assertNull(journeyDetail.getSystemData());
        verify(feignClient, times(1)).fetch((String) "J123");
    }

    @Test
    void test_dropoff_no_entry_throws_business_validation() {

        JourneyState dropState = JourneyState.builder()
                .stateName(CommonJourneyStates.DROP_OFF_CUSTOMER_NOT_AVAILABLE.name())
                .createdOn(new Date())
                .build();

        journeyDetail.setJourneyStates(List.of(dropState));

        Map<String, Map<String, ?>> sys = new HashMap<>();
        sys.put(CommonConstants.JOURNEY_STATUS_DETAIL, new HashMap<>());
        journeyDetail.setSystemData(sys);

        CustomValidationProperties.CustomValidations validations =
                new CustomValidationProperties.CustomValidations();

        validations.setDropOffStates(List.of(CommonJourneyStates.DROP_OFF_CUSTOMER_NOT_AVAILABLE.name()));

        when(customProps.getJourneys()).thenReturn(Map.of("GIFT", validations));

        when(attributes.getRequest()).thenReturn(request);
        when(request.getHeader(RequestHeaders.JOURNEY_ID)).thenReturn("J123");
        RequestContextHolder.setRequestAttributes(attributes);

        when(feignClient.fetch((String) "J123")).thenReturn(journeyData);

        BusinessValidationException ex = assertThrows(BusinessValidationException.class,
                () -> aspect.validateJourney(joinPoint));

        assertNotNull(ex.getMessage());
        assertFalse(journeyDetail.getJourneyStates().isEmpty());
    }

    @Test
    void test_shouldNotExists_violation() {

        JourneyState forbiddenState = JourneyState.builder()
                .stateName(CommonJourneyStates.DROP_OFF_CUSTOMER_NOT_AVAILABLE.name())
                .createdOn(new Date())
                .build();

        journeyDetail.setJourneyStates(new ArrayList<>(List.of(
                JourneyState.builder()
                        .stateName(CommonJourneyStates.CUSTOMER_PROFILE_SUCCESS.name())
                        .createdOn(new Date())
                        .build(),
                forbiddenState
        )));

        when(customProps.getJourneys()).thenReturn(Collections.emptyMap());

        when(attributes.getRequest()).thenReturn(request);
        when(request.getHeader(RequestHeaders.JOURNEY_ID)).thenReturn("J123");
        RequestContextHolder.setRequestAttributes(attributes);

        when(feignClient.fetch((String) "J123")).thenReturn(journeyData);

        BusinessValidationException ex = assertThrows(BusinessValidationException.class,
                () -> aspect.validateJourney(joinPoint));

        assertTrue(journeyDetail.getJourneyStates().contains(forbiddenState));
        assertNotNull(ex.getMessage());
    }

    @Test
    void test_hasAny_violation() {

        JourneyState wrongState = JourneyState.builder()
                .stateName(CommonJourneyStates.FETCH_CUSTOMER_DETAILS_FAILURE.name())
                .createdOn(new Date())
                .build();

        journeyDetail.setJourneyStates(List.of(wrongState));

        when(customProps.getJourneys()).thenReturn(Collections.emptyMap());

        when(attributes.getRequest()).thenReturn(request);
        when(request.getHeader(RequestHeaders.JOURNEY_ID)).thenReturn("J123");
        RequestContextHolder.setRequestAttributes(attributes);

        when(feignClient.fetch((String) "J123")).thenReturn(journeyData);

        BusinessValidationException ex = assertThrows(BusinessValidationException.class,
                () -> aspect.validateJourney(joinPoint));

        assertEquals(1, journeyDetail.getJourneyStates().size());
        assertNotNull(ex.getMessage());
    }

    @Test
    void test_extractJourneyId_nullAttributes() {

        RequestContextHolder.setRequestAttributes(null);

        when(feignClient.fetch((String) null)).thenReturn(null);

        BusinessValidationException ex = assertThrows(BusinessValidationException.class,
                () -> aspect.validateJourney(joinPoint));

        assertNotNull(ex.getMessage());
        verify(feignClient, times(1)).fetch((String) null);
    }

    @Test
    void test_null_journeyId_header() {

        when(attributes.getRequest()).thenReturn(request);
        when(request.getHeader(RequestHeaders.JOURNEY_ID)).thenReturn(null);
        RequestContextHolder.setRequestAttributes(attributes);

        when(feignClient.fetch((String) null)).thenReturn(null);

        BusinessValidationException ex = assertThrows(BusinessValidationException.class,
                () -> aspect.validateJourney(joinPoint));

        assertNotNull(ex.getMessage());
        verify(feignClient, times(1)).fetch((String) null);
    }
}