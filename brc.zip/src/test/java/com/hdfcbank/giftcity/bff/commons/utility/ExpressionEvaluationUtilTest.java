package com.hdfcbank.giftcity.bff.commons.utility;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.springframework.beans.factory.config.AutowireCapableBeanFactory;
import org.springframework.context.ApplicationContext;

import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class ExpressionEvaluationUtilTest {

    private ApplicationContext mockContext;
    private AutowireCapableBeanFactory mockBeanFactory;

    @BeforeEach
    void setup() {
        mockContext = mock(ApplicationContext.class);
        mockBeanFactory = mock(AutowireCapableBeanFactory.class);

        when(mockContext.getAutowireCapableBeanFactory()).thenReturn(mockBeanFactory);

        new AppContextUtil().setApplicationContext(mockContext);
    }

    // evaluate(String)
    @Test
    void testEvaluateWithoutRootObject() {
        String template = "Hello #{'World'}";

        String result = ExpressionEvaluationUtil.evaluate(template);

        assertEquals("Hello World", result);

        // extra assertions
        assertNotNull(result);
        assertFalse(result.isBlank());
        assertTrue(result.contains("World"));
    }

    // evaluate(String, Object)
    @Test
    void testEvaluateWithRootObject() {
        Map<String, Object> root = Map.of("name", "Arijit");

        String template = "Welcome #{#root['name']}";

        String result = ExpressionEvaluationUtil.evaluate(template, root);

        assertEquals("Welcome Arijit", result);

        // extra assertions
        assertNotNull(result);
        assertTrue(result.contains("Arijit"));
        assertEquals(String.class, result.getClass());
    }

    // evaluate(String, Object, Class<T>)
    @Test
    void testEvaluateWithExplicitClass() {
        Map<String, Object> root = Map.of("x", 5, "y", 10);

        String template = "#{#root['x'] + #root['y']}";

        Integer result = ExpressionEvaluationUtil.evaluate(template, root, Integer.class);

        assertEquals(15, result);

        // extra assertions
        assertNotNull(result);
        assertEquals(Integer.class, result.getClass());
    }

    // BeanResolver integration test
    @Test
    void testEvaluateWithBeanResolver() {

        Object serviceBean = new Object(); // mock bean

        try (MockedStatic<AppContextUtil> mockedStaticAppCtx =
                     Mockito.mockStatic(AppContextUtil.class)) {

            mockedStaticAppCtx.when(AppContextUtil::getApplicationContext)
                    .thenReturn(mockContext);

            when(mockBeanFactory.getBean("myService")).thenReturn(serviceBean);

            String template = "#{@myService.toString()}";

            String result = ExpressionEvaluationUtil.evaluate(template);

            assertEquals(serviceBean.toString(), result);

            // extra assertions
            assertNotNull(result);
            assertEquals(serviceBean.toString().length(), result.length());
            assertFalse(result.isBlank());
            verify(mockBeanFactory, times(1)).getBean("myService");
        }
    }
}