package com.hdfcbank.giftcity.bff.customer.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.hdfcbank.adapters.clients.feign.document.DocumentFeignClient;
import com.hdfcbank.adapters.clients.feign.refgen.clients.RefGenServiceFeignClient;
import com.hdfcbank.adapters.vo.GenerateOtpResponse;
import com.hdfcbank.adapters.vo.VerifyOtpResponse;
import com.hdfcbank.common.models.vo.core.ApiResponseStatus;
import com.hdfcbank.common.models.vo.core.ApiResponseStatusCode;
import com.hdfcbank.common.models.vo.journey.JourneyData;
import com.hdfcbank.common.models.vo.journey.JourneyDetail;
import com.hdfcbank.common.models.vo.journey.JourneyState;
import com.hdfcbank.common.models.vo.journey.Profile;
import com.hdfcbank.giftcity.bff.commons.config.JourneyContextHolder;
import com.hdfcbank.giftcity.bff.commons.constant.CommonConstants;
import com.hdfcbank.giftcity.bff.commons.enums.CommonJourneyStates;
import com.hdfcbank.giftcity.bff.commons.exception.CustomValidationException;
import com.hdfcbank.giftcity.bff.commons.exception.OTPValidationException;
import com.hdfcbank.giftcity.bff.commons.exception.handler.DownstreamResponseHandler;
import com.hdfcbank.giftcity.bff.commons.mapper.FcProfileMapper;
import com.hdfcbank.giftcity.bff.commons.model.CustomValidationStatus;
import com.hdfcbank.giftcity.bff.commons.properties.CustomValidationProperties;
import com.hdfcbank.giftcity.bff.commons.validation.JourneyDataProcessor;
import com.hdfcbank.giftcity.bff.communication.OtpResponseHandler;
import com.hdfcbank.giftcity.bff.communication.service.CommunicationService;
import com.hdfcbank.giftcity.bff.customer.config.CustomerApiProperties;
import com.hdfcbank.giftcity.bff.customer.config.ReviewCustomerProperties;
import com.hdfcbank.giftcity.bff.customer.mapper.CustomerMapper;
import com.hdfcbank.giftcity.bff.customer.mapper.ReviewCustomerMapper;
import com.hdfcbank.giftcity.bff.customer.mapper.ViewCustomerMapper;
import com.hdfcbank.giftcity.bff.customer.model.*;
import com.hdfcbank.giftcity.bff.customer.utility.JourneyDataProcessorFactory;
import com.hdfcbank.giftcity.bff.customer.utility.ValidationFailureHandler;
import com.hdfcbank.giftcity.bff.infrastructure.service.JourneyService;
import com.hdfcbank.service.adapters.clients.feign.customer.CustomerServiceFeignClient;
import com.hdfcbank.service.adapters.vo.customer.*;
import com.hdfcbank.service.adapters.vo.customer.CustomerSignatureRequest;
import com.hdfcbank.service.adapters.vo.customer.FetchSignatureResponse;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.NullAndEmptySource;
import org.junit.jupiter.params.provider.ValueSource;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.junit.jupiter.MockitoExtension;
import org.slf4j.LoggerFactory;
import org.springframework.test.util.ReflectionTestUtils;
import software.amazon.awssdk.services.sqs.SqsClient;
import software.amazon.awssdk.services.sqs.model.SendMessageRequest;
import software.amazon.awssdk.services.sqs.model.SendMessageResponse;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.hdfcbank.giftcity.bff.customer.constants.CustomerConstants.ALLOWED;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;


@ExtendWith(MockitoExtension.class)
class CustomerServiceTest {

    @Mock
    private JourneyDataProcessorFactory journeyDataProcessorFactory;

    @Mock
    private CustomerApiProperties customerApiProperties;

    @Mock
    private CustomValidationProperties customValidationProperties;

    @Mock
    private CustomerMapper customerMapper;

    @Mock
    private JourneyService journeyService;

    /*
     * CustomerService contains TWO dependencies of the same type.
     * Therefore CustomerService is created manually in setUp().
     */
    @Mock
    private CustomerServiceFeignClient customerFCFeignClient;

    @Mock
    private CustomerServiceFeignClient customerServiceFeignClient;

    @Mock
    private RefGenServiceFeignClient refGenServiceFeignClient;

    @Mock
    private FcProfileMapper fcProfileMapper;

    @Mock
    private ValidationFailureHandler validationFailureHandler;

    @Mock
    private ViewCustomerMapper viewCustomerMapper;

    @Mock
    private CommunicationService communicationService;

    @Mock
    private OtpResponseHandler otpResponseHandler;

    @Mock
    private SqsClient customerValidate;

    @Mock
    private ObjectMapper objectMapper;

    @Mock
    private ReviewCustomerMapper reviewCustomerMapper;

    @Mock
    private ReviewCustomerProperties reviewCustomerProperties;

    @Mock
    private com.hdfcbank.giftcity.bff.commons.utility.ValidationHelper validationHelper;

    @Mock
    private DocumentFeignClient documentFeignClient;

    private CustomerService customerService;


    @BeforeEach
    void setUp() {

        customerService = new CustomerService(
                journeyDataProcessorFactory,
                customerApiProperties,
                customValidationProperties,
                customerMapper,
                journeyService,
                customerFCFeignClient,
                customerServiceFeignClient,
                fcProfileMapper,
                validationFailureHandler,
                viewCustomerMapper,
                communicationService,
                otpResponseHandler,
                customerValidate,
                objectMapper,
                reviewCustomerMapper,
                reviewCustomerProperties,
                validationHelper
        );

        ReflectionTestUtils.setField(
                customerService,
                "customerValidateQueUrl",
                "https://sqs.test/customer-validation"
        );
    }


    // closeFccCustomer()

    @Test
    void closeFccCustomer_shouldBuildRequestAndReturnResponse() {

        String customerNumber = "CUSTOMER-123";
        String journeyId = "JOURNEY-123";

        CloseCustomerResponse expectedResponse =
                mock(CloseCustomerResponse.class);

        when(customerServiceFeignClient.closeFccCustomer(
                any(CloseCustomerRequest.class),
                eq(journeyId)
        )).thenReturn(expectedResponse);

        CloseCustomerResponse actualResponse =
                customerService.closeFccCustomer(
                        customerNumber,
                        journeyId
                );

        assertSame(expectedResponse, actualResponse);

        ArgumentCaptor<CloseCustomerRequest> captor =
                ArgumentCaptor.forClass(CloseCustomerRequest.class);

        verify(customerServiceFeignClient)
                .closeFccCustomer(
                        captor.capture(),
                        eq(journeyId)
                );

        assertEquals(
                customerNumber,
                captor.getValue().getCustomerNumber()
        );
    }


    // fetchSignature()

    @Test
    void fetchSignature_shouldBuildRequestAndReturnResponse() {

        String customerId = "CUSTOMER-123";
        String journeyId = "JOURNEY-123";

        FetchSignatureResponse expectedResponse =
                mock(FetchSignatureResponse.class);

        when(customerFCFeignClient.fetchSignature(
                any(CustomerSignatureRequest.class),
                eq(journeyId)
        )).thenReturn(expectedResponse);

        FetchSignatureResponse actualResponse =
                customerService.fetchSignature(
                        customerId,
                        journeyId
                );

        assertSame(expectedResponse, actualResponse);

        ArgumentCaptor<CustomerSignatureRequest> captor =
                ArgumentCaptor.forClass(CustomerSignatureRequest.class);

        verify(customerFCFeignClient)
                .fetchSignature(
                        captor.capture(),
                        eq(journeyId)
                );

        assertEquals(
                customerId,
                captor.getValue().getCustomerId()
        );
    }


    // fetchKYC()

    @Test
    void fetchKYC_shouldBuildRequestAndReturnResponse() {

        String customerId = "CUSTOMER-123";

        FetchKycResponse expectedResponse =
                mock(FetchKycResponse.class);

        when(customerFCFeignClient.fetchKyc(
                any(FetchKycRequest.class)
        )).thenReturn(expectedResponse);

        FetchKycResponse actualResponse =
                customerService.fetchKYC(customerId);

        assertSame(expectedResponse, actualResponse);

        ArgumentCaptor<FetchKycRequest> captor =
                ArgumentCaptor.forClass(FetchKycRequest.class);

        verify(customerFCFeignClient)
                .fetchKyc(captor.capture());

        assertEquals(
                customerId,
                captor.getValue().getCustomerId()
        );
    }


    // identifyCustomer(FetchCasaRequest, journeyId)

    @Test
    void identifyCustomer_shouldDelegateToCustomerApi() {

        FetchCasaRequest request =
                new FetchCasaRequest();

        String journeyId = "JOURNEY-123";

        FetchCasaResponse expectedResponse =
                mock(FetchCasaResponse.class);

        when(customerFCFeignClient.identifyCustomer(
                request,
                journeyId
        )).thenReturn(expectedResponse);

        FetchCasaResponse actualResponse =
                customerService.identifyCustomer(
                        request,
                        journeyId
                );

        assertSame(expectedResponse, actualResponse);

        verify(customerFCFeignClient)
                .identifyCustomer(
                        request,
                        journeyId
                );
    }


    // identifyCustomer(request, journeyId, journeyName)

    @Test
    void identifyCustomer_shouldCompleteFullFlowSuccessfully()
            throws Exception {

        String journeyId = "JOURNEY-123";
        String journeyName = "ACCOUNT_OPENING";

        IdentifyCustomerRequest request =
                mock(IdentifyCustomerRequest.class);

        FetchCasaRequest fetchCasaRequest =
                mock(FetchCasaRequest.class);

        FetchCasaResponse fetchCasaResponse =
                mock(FetchCasaResponse.class);

        FetchCasaResponse.FetchCasaDetail fetchCasaDetail =
                mock(FetchCasaResponse.FetchCasaDetail.class);

        FetchCasaResponse.Profile profile =
                mock(FetchCasaResponse.Profile.class);

        FetchCasaResponse.CustomerAccountDetail account =
                mock(FetchCasaResponse.CustomerAccountDetail.class);

        IdentifyGCCustomerResponse gcResponse =
                mock(IdentifyGCCustomerResponse.class);

        JourneyDataProcessor processor =
                mock(JourneyDataProcessor.class);

        GenerateOtpResponse generateOtpResponse =
                mock(GenerateOtpResponse.class);

        IdentifyCustomerResponse expectedResponse =
                mock(IdentifyCustomerResponse.class);

        when(request.getMobileNo())
                .thenReturn("9876543210");

        when(request.getIsd())
                .thenReturn("+91");

        when(request.getIdentifierName())
                .thenReturn("TEST USER");

        when(request.getFullMobileNumber())
                .thenReturn("+919876543210");

        when(customerMapper.toFetchCasaRequest(
                request,
                journeyName
        )).thenReturn(fetchCasaRequest);

        when(journeyDataProcessorFactory.getJourneyDataValidation())
                .thenReturn(processor);

        when(fetchCasaResponse.getStatus())
                .thenReturn(
                        new ApiResponseStatus(
                                ApiResponseStatusCode.SUCCESS
                        )
                );

        when(fetchCasaResponse.getData())
                .thenReturn(fetchCasaDetail);

        when(fetchCasaDetail.getProfiles())
                .thenReturn(List.of(profile));

        when(profile.getCustomerType())
                .thenReturn("INDIVIDUAL");

        when(account.getAccountStatus())
                .thenReturn(
                        CommonConstants.VALID_ACCOUNT_STATUS_CODE
                );

        when(profile.getCustomerAccountDetails())
                .thenReturn(List.of(account));

        when(profile.getDob())
                .thenReturn("1990-01-01");

        when(profile.getEmail())
                .thenReturn("test@example.com");


        /*
         * CustomerApiProperties contains nested maps.
         * Use real maps rather than chained Mockito calls.
         */
        Map journeyCustomerTypes = new HashMap();
        journeyCustomerTypes.put(
                ALLOWED,
                "INDIVIDUAL"
        );

        Map customerTypes = new HashMap();
        customerTypes.put(
                journeyName,
                journeyCustomerTypes
        );

        when(customerApiProperties.getCustomerTypes())
                .thenReturn(customerTypes);

        when(validationHelper.validateRange(
                eq(CommonConstants.AGE),
                anyInt(),
                eq(journeyName)
        )).thenReturn(null);

        when(customerFCFeignClient.identifyCustomer(
                fetchCasaRequest,
                journeyId
        )).thenReturn(fetchCasaResponse);

        /*
         * toGcRequest() return type is project-specific.
         * Returning null is enough because the Feign client is mocked.
         */
        when(customerMapper.toGcRequest(request))
                .thenReturn(null);

        when(customerFCFeignClient.fetchGcCustomer(
                isNull(),
                eq(journeyId)
        )).thenReturn(gcResponse);

        when(communicationService.sendOtp(
                "+919876543210",
                "test@example.com",
                journeyName,
                journeyId
        )).thenReturn(generateOtpResponse);

        when(otpResponseHandler.handleGenerateOtpResponse(
                any(HandleGenerateOtpResponse.class),
                eq(generateOtpResponse),
                eq(journeyId),
                eq("test@example.com")
        )).thenReturn(expectedResponse);

        IdentifyCustomerResponse actualResponse =
                customerService.identifyCustomer(
                        request,
                        journeyId,
                        journeyName
                );

        assertSame(
                expectedResponse,
                actualResponse
        );

        verify(processor)
                .validateRequest(
                        request,
                        journeyId
                );

        verify(journeyService)
                .saveJourney(any(JourneyData.class));

        verify(customerFCFeignClient)
                .identifyCustomer(
                        fetchCasaRequest,
                        journeyId
                );

        verify(fcProfileMapper)
                .toFcIndiaProfile(
                        fetchCasaResponse.getData()
                );

        verify(processor)
                .validateCustomerEligibility(
                        journeyId,
                        profile
                );

        verify(journeyService)
                .updateProfile(
                        journeyId,
                        CommonJourneyStates.CUSTOMER_PROFILE_SUCCESS,
                        profile
                );

        verify(customerFCFeignClient)
                .fetchGcCustomer(
                        isNull(),
                        eq(journeyId)
                );

        verify(processor)
                .validateEtbCustomer(
                        gcResponse,
                        journeyId
                );

        verify(communicationService)
                .sendOtp(
                        "+919876543210",
                        "test@example.com",
                        journeyName,
                        journeyId
                );

        verify(otpResponseHandler)
                .handleGenerateOtpResponse(
                        any(HandleGenerateOtpResponse.class),
                        eq(generateOtpResponse),
                        eq(journeyId),
                        eq("test@example.com")
                );
    }


    @Test
    void identifyCustomer_shouldThrowDownstreamExceptionWhenFcIndiaResponseIsNull()
            throws Exception {

        String journeyId = "JOURNEY-123";
        String journeyName = "ACCOUNT_OPENING";

        IdentifyCustomerRequest request =
                mock(IdentifyCustomerRequest.class);

        FetchCasaRequest fetchCasaRequest =
                mock(FetchCasaRequest.class);

        JourneyDataProcessor processor =
                mock(JourneyDataProcessor.class);

        when(journeyDataProcessorFactory.getJourneyDataValidation())
                .thenReturn(processor);

        when(customerMapper.toFetchCasaRequest(
                request,
                journeyName
        )).thenReturn(fetchCasaRequest);

        when(customerFCFeignClient.identifyCustomer(
                fetchCasaRequest,
                journeyId
        )).thenReturn(null);

        assertThrows(
                Exception.class,
                () -> customerService.identifyCustomer(
                        request,
                        journeyId,
                        journeyName
                )
        );

        verify(processor)
                .validateRequest(
                        request,
                        journeyId
                );

        verify(validationFailureHandler)
                .dropOnValidationFailure(
                        eq(journeyId),
                        eq(CustomerApiStatusCode.DOWNSTREAM_API_ERROR),
                        anyString(),
                        eq(CommonJourneyStates.DROP_OFF_CUSTOMER_EXCLUDED)
                );
    }


    @Test
    void identifyCustomer_shouldThrowCustomValidationExceptionWhenFcIndiaFails()
            throws Exception {

        String journeyId = "JOURNEY-123";
        String journeyName = "ACCOUNT_OPENING";

        IdentifyCustomerRequest request =
                mock(IdentifyCustomerRequest.class);

        FetchCasaRequest fetchCasaRequest =
                mock(FetchCasaRequest.class);

        FetchCasaResponse fetchCasaResponse =
                mock(FetchCasaResponse.class);

        ApiResponseStatus failedStatus =
                mock(ApiResponseStatus.class);

        JourneyData journeyData =
                mock(JourneyData.class);

        JourneyDataProcessor processor =
                mock(JourneyDataProcessor.class);

        CustomValidationStatus customValidationStatus =
                mock(CustomValidationStatus.class);

        when(journeyDataProcessorFactory.getJourneyDataValidation())
                .thenReturn(processor);

        when(customerMapper.toFetchCasaRequest(
                request,
                journeyName
        )).thenReturn(fetchCasaRequest);

        when(customerFCFeignClient.identifyCustomer(
                fetchCasaRequest,
                journeyId
        )).thenReturn(fetchCasaResponse);

        when(fetchCasaResponse.getStatus())
                .thenReturn(failedStatus);

        when(failedStatus.getCode())
                .thenReturn("FAILED");

        when(journeyService.fetchJourney(journeyId))
                .thenReturn(journeyData);

        try (MockedStatic<DownstreamResponseHandler> handler =
                     mockStatic(DownstreamResponseHandler.class)) {

            handler.when(() ->
                    DownstreamResponseHandler.handleResponse(
                            fetchCasaResponse,
                            CommonConstants.IDENTIFY_CUSTOMER,
                            false,
                            journeyName
                    )
            ).thenReturn(customValidationStatus);

            assertThrows(
                    CustomValidationException.class,
                    () -> customerService.identifyCustomer(
                            request,
                            journeyId,
                            journeyName
                    )
            );

            verify(journeyService)
                    .fetchJourney(journeyId);

            verify(journeyService)
                    .updateJourneyDetailDropOff(
                            eq(journeyData),
                            eq(customValidationStatus),
                            eq(CommonJourneyStates.DROP_OFF_CUSTOMER_EXCLUDED)
                    );
        }
    }


    @Test
    void identifyCustomer_shouldHandleSuccessfulFcIndiaResponseWithNullData()
            throws Exception {

        String journeyId = "JOURNEY-123";
        String journeyName = "ACCOUNT_OPENING";

        IdentifyCustomerRequest request =
                mock(IdentifyCustomerRequest.class);

        FetchCasaRequest fetchCasaRequest =
                mock(FetchCasaRequest.class);

        FetchCasaResponse fetchCasaResponse =
                mock(FetchCasaResponse.class);

        ApiResponseStatus successStatus =
                mock(ApiResponseStatus.class);

        JourneyDataProcessor processor =
                mock(JourneyDataProcessor.class);

        when(journeyDataProcessorFactory.getJourneyDataValidation())
                .thenReturn(processor);

        when(customerMapper.toFetchCasaRequest(
                request,
                journeyName
        )).thenReturn(fetchCasaRequest);

        when(customerFCFeignClient.identifyCustomer(
                fetchCasaRequest,
                journeyId
        )).thenReturn(fetchCasaResponse);

        when(fetchCasaResponse.getStatus())
                .thenReturn(successStatus);

        when(successStatus.getCode())
                .thenReturn(CommonConstants.SUCCESS_CODE);

        when(fetchCasaResponse.getData())
                .thenReturn(null);

        try (MockedStatic<DownstreamResponseHandler> handler =
                     mockStatic(DownstreamResponseHandler.class)) {

            handler.when(() ->
                    DownstreamResponseHandler.handleResponse(
                            fetchCasaResponse,
                            CommonConstants.IDENTIFY_CUSTOMER,
                            true,
                            journeyName
                    )
            ).thenReturn(null);

            assertThrows(
                    NullPointerException.class,
                    () -> customerService.identifyCustomer(
                            request,
                            journeyId,
                            journeyName
                    )
            );

            verify(validationFailureHandler)
                    .dropOnValidationFailure(
                            eq(journeyId),
                            eq(CustomerApiStatusCode.DOWNSTREAM_API_ERROR),
                            anyString(),
                            eq(CommonJourneyStates.DROP_OFF_CUSTOMER_EXCLUDED)
                    );
        }
    }


    @Test
    void identifyCustomer_shouldThrowWhenCustomerAgeIsInvalid()
            throws Exception {

        String journeyId = "JOURNEY-123";
        String journeyName = "ACCOUNT_OPENING";

        IdentifyCustomerRequest request =
                mock(IdentifyCustomerRequest.class);

        FetchCasaRequest fetchCasaRequest =
                mock(FetchCasaRequest.class);

        FetchCasaResponse fetchCasaResponse =
                mock(FetchCasaResponse.class);

        FetchCasaResponse.FetchCasaDetail detail =
                mock(FetchCasaResponse.FetchCasaDetail.class);

        FetchCasaResponse.Profile profile =
                mock(FetchCasaResponse.Profile.class);

        JourneyData journeyData =
                mock(JourneyData.class);

        JourneyDataProcessor processor =
                mock(JourneyDataProcessor.class);

        CustomValidationProperties.FieldDetail field =
                mock(CustomValidationProperties.FieldDetail.class);

        CustomValidationStatus validationStatus =
                mock(CustomValidationStatus.class);

        when(journeyDataProcessorFactory.getJourneyDataValidation())
                .thenReturn(processor);

        when(customerMapper.toFetchCasaRequest(
                request,
                journeyName
        )).thenReturn(fetchCasaRequest);

        when(customerFCFeignClient.identifyCustomer(
                fetchCasaRequest,
                journeyId
        )).thenReturn(fetchCasaResponse);

        when(fetchCasaResponse.getStatus())
                .thenReturn(
                        new ApiResponseStatus(
                                ApiResponseStatusCode.SUCCESS
                        )
                );

        when(fetchCasaResponse.getData())
                .thenReturn(detail);

        when(detail.getProfiles())
                .thenReturn(List.of(profile));

        when(profile.getDob())
                .thenReturn("1900-01-01");

        when(validationHelper.validateRange(
                eq(CommonConstants.AGE),
                anyInt(),
                eq(journeyName)
        )).thenReturn(field);

        when(validationHelper.getErrors(
                eq(journeyName),
                anyList(),
                eq(customValidationProperties)
        )).thenReturn(validationStatus);

        when(journeyService.fetchJourney(journeyId))
                .thenReturn(journeyData);

        assertThrows(
                CustomValidationException.class,
                () -> customerService.identifyCustomer(
                        request,
                        journeyId,
                        journeyName
                )
        );

        verify(validationHelper)
                .validateRange(
                        eq(CommonConstants.AGE),
                        anyInt(),
                        eq(journeyName)
                );

        verify(journeyService)
                .fetchJourney(journeyId);

        verify(journeyService)
                .updateJourneyDetailDropOff(
                        eq(journeyData),
                        eq(validationStatus),
                        eq(CommonJourneyStates.DROP_OFF_CUSTOMER_EXCLUDED)
                );
    }


    @Test
    void identifyCustomer_shouldContinueWhenCustomerDobIsMissing()
            throws Exception {

        String journeyId = "JOURNEY-123";
        String journeyName = "ACCOUNT_OPENING";

        IdentifyCustomerRequest request =
                mock(IdentifyCustomerRequest.class);

        FetchCasaRequest fetchCasaRequest =
                mock(FetchCasaRequest.class);

        FetchCasaResponse fetchCasaResponse =
                mock(FetchCasaResponse.class);

        FetchCasaResponse.FetchCasaDetail detail =
                mock(FetchCasaResponse.FetchCasaDetail.class);

        FetchCasaResponse.Profile profile =
                mock(FetchCasaResponse.Profile.class);

        JourneyDataProcessor processor =
                mock(JourneyDataProcessor.class);

        when(journeyDataProcessorFactory.getJourneyDataValidation())
                .thenReturn(processor);

        when(customerMapper.toFetchCasaRequest(
                request,
                journeyName
        )).thenReturn(fetchCasaRequest);

        when(customerFCFeignClient.identifyCustomer(
                fetchCasaRequest,
                journeyId
        )).thenReturn(fetchCasaResponse);

        when(fetchCasaResponse.getStatus())
                .thenReturn(
                        new ApiResponseStatus(
                                ApiResponseStatusCode.SUCCESS
                        )
                );

        when(fetchCasaResponse.getData())
                .thenReturn(detail);

        when(detail.getProfiles())
                .thenReturn(List.of(profile));

        when(profile.getDob())
                .thenReturn(null);

        when(profile.getCustomerType())
                .thenReturn("INDIVIDUAL");

        FetchCasaResponse.CustomerAccountDetail account =
                mock(FetchCasaResponse.CustomerAccountDetail.class);

        when(account.getAccountStatus())
                .thenReturn(
                        CommonConstants.VALID_ACCOUNT_STATUS_CODE
                );

        when(profile.getCustomerAccountDetails())
                .thenReturn(List.of(account));

        when(profile.getEmail())
                .thenReturn("test@example.com");

        when(request.getFullMobileNumber())
                .thenReturn("+919876543210");

        Map journeyCustomerTypes = new HashMap();
        journeyCustomerTypes.put(ALLOWED, "INDIVIDUAL");

        Map customerTypes = new HashMap();
        customerTypes.put(journeyName, journeyCustomerTypes);

        when(customerApiProperties.getCustomerTypes())
                .thenReturn(customerTypes);

        when(customerFCFeignClient.fetchGcCustomer(
                isNull(),
                eq(journeyId)
        )).thenReturn(mock(IdentifyGCCustomerResponse.class));

        when(communicationService.sendOtp(
                anyString(),
                eq("test@example.com"),
                eq(journeyName),
                eq(journeyId)
        )).thenReturn(mock(GenerateOtpResponse.class));

        when(otpResponseHandler.handleGenerateOtpResponse(
                any(HandleGenerateOtpResponse.class),
                any(GenerateOtpResponse.class),
                eq(journeyId),
                eq("test@example.com")
        )).thenReturn(mock(IdentifyCustomerResponse.class));

        // No age validation is performed when DOB is null.

        IdentifyCustomerResponse response =
                customerService.identifyCustomer(
                        request,
                        journeyId,
                        journeyName
                );

        assertNotNull(response);

        verify(validationHelper)
                .validateRange(
                        eq(CommonConstants.AGE),
                        isNull(),
                        eq(journeyName)
                );
    }


    @Test
    void identifyCustomer_shouldHandleNoEligibleProfiles()
            throws Exception {

        String journeyId = "JOURNEY-123";
        String journeyName = "ACCOUNT_OPENING";

        IdentifyCustomerRequest request =
                mock(IdentifyCustomerRequest.class);

        FetchCasaRequest fetchCasaRequest =
                mock(FetchCasaRequest.class);

        FetchCasaResponse fetchCasaResponse =
                mock(FetchCasaResponse.class);

        FetchCasaResponse.FetchCasaDetail detail =
                mock(FetchCasaResponse.FetchCasaDetail.class);

        JourneyDataProcessor processor =
                mock(JourneyDataProcessor.class);

        when(journeyDataProcessorFactory.getJourneyDataValidation())
                .thenReturn(processor);

        when(customerMapper.toFetchCasaRequest(
                request,
                journeyName
        )).thenReturn(fetchCasaRequest);

        when(customerFCFeignClient.identifyCustomer(
                fetchCasaRequest,
                journeyId
        )).thenReturn(fetchCasaResponse);

        when(fetchCasaResponse.getStatus())
                .thenReturn(
                        new ApiResponseStatus(
                                ApiResponseStatusCode.SUCCESS
                        )
                );

        when(fetchCasaResponse.getData())
                .thenReturn(detail);

        // No profiles returned by CASA
        when(detail.getProfiles())
                .thenReturn(Collections.emptyList());

        when(customerApiProperties.getCustomerTypes())
                .thenReturn(
                        createCustomerTypes(
                                journeyName,
                                "INDIVIDUAL"
                        )
                );

        CustomValidationStatus status =
                CustomValidationStatus.builder()
                        .title(CustomerApiStatusCode.NO_ELIGIBLE_CUSTOMER.getMessage())
                        .code(CustomerApiStatusCode.NO_ELIGIBLE_CUSTOMER.getCode())
                        .message("No ELIGIBLE Customer Found")
                        .build();

        doThrow(new CustomValidationException(status))
                .when(validationFailureHandler)
                .dropOnValidationFailure(
                        eq(journeyId),
                        eq(CustomerApiStatusCode.NO_ELIGIBLE_CUSTOMER),
                        eq("No ELIGIBLE Customer Found"),
                        eq(CommonJourneyStates.CUSTOMER_NOT_ELIGIBILE)
                );

        assertThrows(
                CustomValidationException.class,
                () -> customerService.identifyCustomer(
                        request,
                        journeyId,
                        journeyName
                )
        );

        verify(validationFailureHandler)
                .dropOnValidationFailure(
                        eq(journeyId),
                        eq(CustomerApiStatusCode.NO_ELIGIBLE_CUSTOMER),
                        eq("No ELIGIBLE Customer Found"),
                        eq(CommonJourneyStates.CUSTOMER_NOT_ELIGIBILE)
                );
    }


    // filterProfilesByCustomerTypes()

    @Test
    void filterProfilesByCustomerTypes_shouldReturnEligibleProfile() {

        FetchCasaResponse.Profile profile =
                mock(FetchCasaResponse.Profile.class);

        FetchCasaResponse.CustomerAccountDetail account =
                mock(FetchCasaResponse.CustomerAccountDetail.class);

        when(profile.getCustomerType())
                .thenReturn("INDIVIDUAL");

        when(account.getAccountStatus())
                .thenReturn(
                        CommonConstants.VALID_ACCOUNT_STATUS_CODE
                );

        when(profile.getCustomerAccountDetails())
                .thenReturn(List.of(account));

        List<FetchCasaResponse.Profile> result =
                customerService.filterProfilesByCustomerTypes(
                        List.of(profile),
                        "INDIVIDUAL"
                );

        assertEquals(1, result.size());
        assertSame(profile, result.get(0));
    }


    @Test
    void filterProfilesByCustomerTypes_shouldExcludeWrongCustomerType() {

        FetchCasaResponse.Profile profile =
                mock(FetchCasaResponse.Profile.class);

        FetchCasaResponse.CustomerAccountDetail account =
                mock(FetchCasaResponse.CustomerAccountDetail.class);

        when(profile.getCustomerType())
                .thenReturn("CORPORATE");

        when(account.getAccountStatus())
                .thenReturn(
                        CommonConstants.VALID_ACCOUNT_STATUS_CODE
                );

        when(profile.getCustomerAccountDetails())
                .thenReturn(List.of(account));

        List<FetchCasaResponse.Profile> result =
                customerService.filterProfilesByCustomerTypes(
                        List.of(profile),
                        "INDIVIDUAL"
                );

        assertTrue(result.isEmpty());
    }


    @Test
    void filterProfilesByCustomerTypes_shouldExcludeInvalidAccountStatus() {

        FetchCasaResponse.Profile profile =
                mock(FetchCasaResponse.Profile.class);

        FetchCasaResponse.CustomerAccountDetail account =
                mock(FetchCasaResponse.CustomerAccountDetail.class);

        when(profile.getCustomerType())
                .thenReturn("INDIVIDUAL");

        when(account.getAccountStatus())
                .thenReturn("INVALID");

        when(profile.getCustomerAccountDetails())
                .thenReturn(List.of(account));

        List<FetchCasaResponse.Profile> result =
                customerService.filterProfilesByCustomerTypes(
                        List.of(profile),
                        "INDIVIDUAL"
                );

        assertTrue(result.isEmpty());
    }


    @Test
    void filterProfilesByCustomerTypes_shouldExcludeNullAccountList() {

        FetchCasaResponse.Profile profile =
                mock(FetchCasaResponse.Profile.class);

        when(profile.getCustomerType())
                .thenReturn("INDIVIDUAL");

        when(profile.getCustomerAccountDetails())
                .thenReturn(null);

        List<FetchCasaResponse.Profile> result =
                customerService.filterProfilesByCustomerTypes(
                        List.of(profile),
                        "INDIVIDUAL"
                );

        assertTrue(result.isEmpty());
    }


    @Test
    void filterProfilesByCustomerTypes_shouldExcludeEmptyAccountList() {

        FetchCasaResponse.Profile profile =
                mock(FetchCasaResponse.Profile.class);

        when(profile.getCustomerType())
                .thenReturn("INDIVIDUAL");

        when(profile.getCustomerAccountDetails())
                .thenReturn(Collections.emptyList());

        List<FetchCasaResponse.Profile> result =
                customerService.filterProfilesByCustomerTypes(
                        List.of(profile),
                        "INDIVIDUAL"
                );

        assertTrue(result.isEmpty());
    }


    @Test
    void filterProfilesByCustomerTypes_shouldIgnoreCaseAndWhitespace() {

        FetchCasaResponse.Profile profile =
                mock(FetchCasaResponse.Profile.class);

        FetchCasaResponse.CustomerAccountDetail account =
                mock(FetchCasaResponse.CustomerAccountDetail.class);

        when(profile.getCustomerType())
                .thenReturn("  individual  ");

        when(account.getAccountStatus())
                .thenReturn(
                        CommonConstants.VALID_ACCOUNT_STATUS_CODE
                );

        when(profile.getCustomerAccountDetails())
                .thenReturn(List.of(account));

        List<FetchCasaResponse.Profile> result =
                customerService.filterProfilesByCustomerTypes(
                        List.of(profile),
                        " INDIVIDUAL "
                );

        assertEquals(1, result.size());
        assertSame(profile, result.get(0));
    }


    @Test
    void filterProfilesByCustomerTypes_shouldReturnOnlyEligibleProfiles() {

        FetchCasaResponse.Profile eligibleProfile =
                mock(FetchCasaResponse.Profile.class);

        FetchCasaResponse.Profile wrongTypeProfile =
                mock(FetchCasaResponse.Profile.class);

        FetchCasaResponse.Profile invalidAccountProfile =
                mock(FetchCasaResponse.Profile.class);

        FetchCasaResponse.CustomerAccountDetail validAccount =
                mock(FetchCasaResponse.CustomerAccountDetail.class);

        FetchCasaResponse.CustomerAccountDetail invalidAccount =
                mock(FetchCasaResponse.CustomerAccountDetail.class);

        when(validAccount.getAccountStatus())
                .thenReturn(
                        CommonConstants.VALID_ACCOUNT_STATUS_CODE
                );

        when(invalidAccount.getAccountStatus())
                .thenReturn("INVALID");

        when(eligibleProfile.getCustomerType())
                .thenReturn("INDIVIDUAL");

        when(eligibleProfile.getCustomerAccountDetails())
                .thenReturn(List.of(validAccount));

        when(wrongTypeProfile.getCustomerType())
                .thenReturn("CORPORATE");

        when(wrongTypeProfile.getCustomerAccountDetails())
                .thenReturn(List.of(validAccount));

        when(invalidAccountProfile.getCustomerType())
                .thenReturn("INDIVIDUAL");

        when(invalidAccountProfile.getCustomerAccountDetails())
                .thenReturn(List.of(invalidAccount));

        List<FetchCasaResponse.Profile> result =
                customerService.filterProfilesByCustomerTypes(
                        List.of(
                                eligibleProfile,
                                wrongTypeProfile,
                                invalidAccountProfile
                        ),
                        "INDIVIDUAL"
                );

        assertEquals(1, result.size());
        assertSame(eligibleProfile, result.get(0));
    }


    @Test
    void filterProfilesByCustomerTypes_shouldAcceptWhenAtLeastOneAccountIsValid() {

        FetchCasaResponse.Profile profile =
                mock(FetchCasaResponse.Profile.class);

        FetchCasaResponse.CustomerAccountDetail invalidAccount =
                mock(FetchCasaResponse.CustomerAccountDetail.class);

        FetchCasaResponse.CustomerAccountDetail validAccount =
                mock(FetchCasaResponse.CustomerAccountDetail.class);

        when(profile.getCustomerType())
                .thenReturn("INDIVIDUAL");

        when(invalidAccount.getAccountStatus())
                .thenReturn("INVALID");

        when(validAccount.getAccountStatus())
                .thenReturn(
                        CommonConstants.VALID_ACCOUNT_STATUS_CODE
                );

        when(profile.getCustomerAccountDetails())
                .thenReturn(
                        List.of(
                                invalidAccount,
                                validAccount
                        )
                );

        List<FetchCasaResponse.Profile> result =
                customerService.filterProfilesByCustomerTypes(
                        List.of(profile),
                        "INDIVIDUAL"
                );

        assertEquals(1, result.size());
        assertSame(profile, result.get(0));
    }


    // customerInquireEligibility()

    @Test
    void customerInquireEligibility_shouldReturnSuccessWhenAllStatesArePresent() {

        String journeyId = "JOURNEY-123";

        JourneyData journeyData =
                mock(JourneyData.class);

        JourneyDetail journeyDetail =
                mock(JourneyDetail.class);

        JourneyState fcIndiaState =
                mock(JourneyState.class);

        JourneyState factivaState =
                mock(JourneyState.class);

        JourneyState signatureState =
                mock(JourneyState.class);

        when(journeyData.getJourneyDetail())
                .thenReturn(journeyDetail);

        when(journeyDetail.getJourneyStates())
                .thenReturn(
                        List.of(
                                fcIndiaState,
                                factivaState,
                                signatureState
                        )
                );

        when(fcIndiaState.getStateName())
                .thenReturn(
                        CommonJourneyStates.FC_INDIA_ELIGIBILITY_SUCCESS.name()
                );

        when(factivaState.getStateName())
                .thenReturn(
                        CommonJourneyStates.FACTIVA_ELIGIBLE_SUCCESS.name()
                );

        when(signatureState.getStateName())
                .thenReturn(
                        CommonJourneyStates.CUSTOMER_SIGNATURE_FETCH_SUCCESS.name()
                );

        try (MockedStatic<JourneyContextHolder> context =
                     mockStatic(JourneyContextHolder.class)) {

            context.when(JourneyContextHolder::getJourneyData)
                    .thenReturn(journeyData);

            InquireEligibilityResponse response =
                    customerService.customerInquireEligibility(
                            journeyId
                    );

            assertNotNull(response);
            assertNotNull(response.getData());

            assertEquals(
                    InquireEligibilityResponse.JourneyStatus.SUCCESS,
                    response.getData().getStatus()
            );
        }
    }


    @Test
    void customerInquireEligibility_shouldReturnInProgressWhenStateIsMissing() {

        String journeyId = "JOURNEY-123";

        JourneyData journeyData =
                mock(JourneyData.class);

        JourneyDetail journeyDetail =
                mock(JourneyDetail.class);

        JourneyState state =
                mock(JourneyState.class);

        when(journeyData.getJourneyDetail())
                .thenReturn(journeyDetail);

        when(journeyDetail.getJourneyStates())
                .thenReturn(List.of(state));

        when(state.getStateName())
                .thenReturn(
                        CommonJourneyStates.FC_INDIA_ELIGIBILITY_SUCCESS.name()
                );

        try (MockedStatic<JourneyContextHolder> context =
                     mockStatic(JourneyContextHolder.class)) {

            context.when(JourneyContextHolder::getJourneyData)
                    .thenReturn(journeyData);

            InquireEligibilityResponse response =
                    customerService.customerInquireEligibility(
                            journeyId
                    );

            assertNotNull(response);
            assertNotNull(response.getData());

            assertEquals(
                    InquireEligibilityResponse.JourneyStatus.IN_PROGRESS,
                    response.getData().getStatus()
            );
        }
    }


    @Test
    void customerInquireEligibility_shouldThrowWhenJourneyDataIsNull() {

        String journeyId = "JOURNEY-123";

        try (MockedStatic<JourneyContextHolder> context =
                     mockStatic(JourneyContextHolder.class)) {

            context.when(JourneyContextHolder::getJourneyData)
                    .thenReturn(null);

            assertThrows(
                    CustomValidationException.class,
                    () -> customerService.customerInquireEligibility(
                            journeyId
                    )
            );
        }
    }


    @Test
    void customerInquireEligibility_shouldThrowWhenJourneyDetailIsNull() {

        String journeyId = "JOURNEY-123";

        JourneyData journeyData =
                mock(JourneyData.class);

        when(journeyData.getJourneyDetail())
                .thenReturn(null);

        try (MockedStatic<JourneyContextHolder> context =
                     mockStatic(JourneyContextHolder.class)) {

            context.when(JourneyContextHolder::getJourneyData)
                    .thenReturn(journeyData);

            assertThrows(
                    CustomValidationException.class,
                    () -> customerService.customerInquireEligibility(
                            journeyId
                    )
            );
        }
    }


    @Test
    void customerInquireEligibility_shouldThrowWhenJourneyStatesAreNull() {

        String journeyId = "JOURNEY-123";

        JourneyData journeyData =
                mock(JourneyData.class);

        JourneyDetail journeyDetail =
                mock(JourneyDetail.class);

        when(journeyData.getJourneyDetail())
                .thenReturn(journeyDetail);

        when(journeyDetail.getJourneyStates())
                .thenReturn(null);

        try (MockedStatic<JourneyContextHolder> context =
                     mockStatic(JourneyContextHolder.class)) {

            context.when(JourneyContextHolder::getJourneyData)
                    .thenReturn(journeyData);

            assertThrows(
                    CustomValidationException.class,
                    () -> customerService.customerInquireEligibility(
                            journeyId
                    )
            );
        }
    }


    // ============================================================
    // validateCustomer()
    // ============================================================

    @Test
    void validateCustomer_shouldPublishSqsMessageWhenOtpSucceeds()
            throws JsonProcessingException {

        String journeyId = "JOURNEY-123";

        ValidateCustomerRequest request =
                mock(ValidateCustomerRequest.class);

        JourneyData journeyData =
                mock(JourneyData.class);

        VerifyOtpResponse verifyOtpResponse =
                mock(VerifyOtpResponse.class);

        ApiResponseStatus otpStatus =
                mock(ApiResponseStatus.class);

        ValidateCustomerResponse expectedResponse =
                mock(ValidateCustomerResponse.class);

        when(otpStatus.getCode())
                .thenReturn(OtpApiStatusCode.SUCCESS.getCode());

        when(verifyOtpResponse.getStatus())
                .thenReturn(otpStatus);

        when(communicationService.verifyOtp(
                request,
                journeyId
        )).thenReturn(verifyOtpResponse);

        when(otpResponseHandler.handleVerifyOtpResponse(
                request,
                verifyOtpResponse,
                journeyData
        )).thenReturn(expectedResponse);

        when(objectMapper.writeValueAsString(any()))
                .thenReturn(
                        "{\"journeyId\":\"JOURNEY-123\"}"
                );

        when(customerValidate.sendMessage(
                any(SendMessageRequest.class)
        )).thenReturn(
                SendMessageResponse.builder()
                        .messageId("MESSAGE-123")
                        .md5OfMessageBody("MD5")
                        .build()
        );

        try (MockedStatic<JourneyContextHolder> context =
                     mockStatic(JourneyContextHolder.class)) {

            context.when(JourneyContextHolder::getJourneyData)
                    .thenReturn(journeyData);

            ValidateCustomerResponse actualResponse =
                    customerService.validateCustomer(
                            request,
                            journeyId
                    );

            assertSame(
                    expectedResponse,
                    actualResponse
            );

            verify(communicationService)
                    .verifyOtp(
                            request,
                            journeyId
                    );

            verify(otpResponseHandler)
                    .handleVerifyOtpResponse(
                            request,
                            verifyOtpResponse,
                            journeyData
                    );

            verify(customerValidate)
                    .sendMessage(
                            any(SendMessageRequest.class)
                    );
        }
    }


    @Test
    void validateCustomer_shouldNotPublishSqsMessageWhenOtpFails() {

        String journeyId = "JOURNEY-123";

        ValidateCustomerRequest request =
                mock(ValidateCustomerRequest.class);

        JourneyData journeyData =
                mock(JourneyData.class);

        VerifyOtpResponse verifyOtpResponse =
                mock(VerifyOtpResponse.class);

        ApiResponseStatus otpStatus =
                mock(ApiResponseStatus.class);

        ValidateCustomerResponse expectedResponse =
                mock(ValidateCustomerResponse.class);

        when(otpStatus.getCode())
                .thenReturn("FAILED");

        when(verifyOtpResponse.getStatus())
                .thenReturn(otpStatus);

        when(communicationService.verifyOtp(
                request,
                journeyId
        )).thenReturn(verifyOtpResponse);

        when(otpResponseHandler.handleVerifyOtpResponse(
                request,
                verifyOtpResponse,
                journeyData
        )).thenReturn(expectedResponse);

        try (MockedStatic<JourneyContextHolder> context =
                     mockStatic(JourneyContextHolder.class)) {

            context.when(JourneyContextHolder::getJourneyData)
                    .thenReturn(journeyData);

            ValidateCustomerResponse actualResponse =
                    customerService.validateCustomer(
                            request,
                            journeyId
                    );

            assertSame(
                    expectedResponse,
                    actualResponse
            );

            verify(customerValidate, never())
                    .sendMessage(
                            any(SendMessageRequest.class)
                    );

            verify(otpResponseHandler)
                    .handleVerifyOtpResponse(
                            request,
                            verifyOtpResponse,
                            journeyData
                    );
        }
    }


    @Test
    void validateCustomer_shouldContinueWhenSqsPublishingFails() throws Exception {

        //                 Turn OFF logging for CustomerService so "Serialization failed" never appears
        ((ch.qos.logback.classic.Logger) LoggerFactory.getLogger(CustomerService.class))
                .setLevel(ch.qos.logback.classic.Level.OFF);

        String journeyId = "JOURNEY-123";

        ValidateCustomerRequest request = mock(ValidateCustomerRequest.class);
        JourneyData journeyData = mock(JourneyData.class);

        VerifyOtpResponse verifyOtpResponse = mock(VerifyOtpResponse.class);
        ApiResponseStatus otpStatus = mock(ApiResponseStatus.class);

        ValidateCustomerResponse expectedResponse = mock(ValidateCustomerResponse.class);

        when(otpStatus.getCode()).thenReturn(OtpApiStatusCode.SUCCESS.getCode());
        when(verifyOtpResponse.getStatus()).thenReturn(otpStatus);

        when(communicationService.verifyOtp(request, journeyId))
                .thenReturn(verifyOtpResponse);

        when(otpResponseHandler.handleVerifyOtpResponse(request, verifyOtpResponse, journeyData))
                .thenReturn(expectedResponse);

        //                 Simulate serialization failure
        doThrow(new JsonProcessingException("Serialization failed") {})
                .when(objectMapper).writeValueAsString(any());

        //                 VALID queue URL so publishCustomerValidatorMessage() executes
        ReflectionTestUtils.setField(
                customerService,
                "customerValidateQueUrl",
                "https://sqs.test/customer-validation"
        );

        try (MockedStatic<JourneyContextHolder> ctx = mockStatic(JourneyContextHolder.class)) {

            ctx.when(JourneyContextHolder::getJourneyData).thenReturn(journeyData);

            ValidateCustomerResponse actualResponse =
                    customerService.validateCustomer(request, journeyId);

            assertSame(expectedResponse, actualResponse);

            verify(otpResponseHandler)
                    .handleVerifyOtpResponse(request, verifyOtpResponse, journeyData);

            verify(customerValidate, never()).sendMessage(any(SendMessageRequest.class));
        }
    }


    // ============================================================
    // resendOtp()
    // ============================================================

    @Test
    void resendOtp_shouldResendOtpAndReturnResponse() {

        String journeyId = "JOURNEY-123";
        String journeyName = "ACCOUNT_OPENING";
        String isd = "+91";
        String mobileNumber = "9876543210";
        String fullMobileNumber = "+919876543210";

        Profile profile =
                mock(Profile.class);

        JourneyData journeyData =
                mock(JourneyData.class);

        GenerateOtpResponse generateOtpResponse =
                mock(GenerateOtpResponse.class);

        IdentifyCustomerResponse expectedResponse =
                mock(IdentifyCustomerResponse.class);

        when(journeyData.getJourneyName())
                .thenReturn(journeyName);

        when(journeyData.getIsd())
                .thenReturn(isd);

        when(journeyData.getMobileNumber())
                .thenReturn(mobileNumber);

        when(journeyData.getProfile())
                .thenReturn(profile);

        when(profile.getEmailId())
                .thenReturn("test@example.com");

        when(profile.getDob())
                .thenReturn("1990-01-01");

        when(communicationService.resendOtp(
                fullMobileNumber,
                "test@example.com",
                journeyName,
                journeyId
        )).thenReturn(generateOtpResponse);

        when(otpResponseHandler.handleGenerateOtpResponse(
                fullMobileNumber,
                "1990-01-01",
                generateOtpResponse,
                journeyId,
                true
        )).thenReturn(expectedResponse);

        try (MockedStatic<JourneyContextHolder> context =
                     mockStatic(JourneyContextHolder.class)) {

            context.when(JourneyContextHolder::getJourneyData)
                    .thenReturn(journeyData);

            IdentifyCustomerResponse actualResponse =
                    customerService.resendOtp(journeyId);

            assertSame(
                    expectedResponse,
                    actualResponse
            );

            verify(communicationService)
                    .resendOtp(
                            fullMobileNumber,
                            "test@example.com",
                            journeyName,
                            journeyId
                    );

            verify(otpResponseHandler)
                    .handleGenerateOtpResponse(
                            fullMobileNumber,
                            "1990-01-01",
                            generateOtpResponse,
                            journeyId,
                            true
                    );
        }
    }


    @Test
    void resendOtp_shouldWrapExceptionInOtpValidationException() {

        String journeyId = "JOURNEY-123";

        JourneyData journeyData =
                mock(JourneyData.class);

        when(journeyData.getJourneyName())
                .thenReturn("ACCOUNT_OPENING");

        when(journeyData.getIsd())
                .thenReturn("+91");

        when(journeyData.getMobileNumber())
                .thenReturn("9876543210");

        when(journeyData.getProfile())
                .thenThrow(
                        new RuntimeException("Profile error")
                );

        try (MockedStatic<JourneyContextHolder> context =
                     mockStatic(JourneyContextHolder.class)) {

            context.when(JourneyContextHolder::getJourneyData)
                    .thenReturn(journeyData);

            assertThrows(
                    OTPValidationException.class,
                    () -> customerService.resendOtp(journeyId)
            );
        }
    }


    // ============================================================
    // getCustomerDetails()
    // ============================================================

    @Test
    void getCustomerDetails_shouldReturnMappedDetailsWhenJourneyExists() {

        String journeyId = "JOURNEY-123";

        JourneyData journeyData =
                mock(JourneyData.class);

        CustomerDetails.CustomerProfile customerProfile =
                mock(CustomerDetails.CustomerProfile.class);

        when(viewCustomerMapper.journeyDetailsMapper(journeyData))
                .thenReturn(customerProfile);

        when(viewCustomerMapper.journeyFactaDetailsMapper(journeyData))
                .thenReturn(null);

        when(viewCustomerMapper.employmentFinancialDetailsMapper(journeyData))
                .thenReturn(null);

        List<String> financialProducts =
                List.of(
                        "PRODUCT-1",
                        "PRODUCT-2"
                );

        when(reviewCustomerProperties.getFinancialProducts())
                .thenReturn(financialProducts);

        try (MockedStatic<JourneyContextHolder> context =
                     mockStatic(JourneyContextHolder.class)) {

            context.when(JourneyContextHolder::getJourneyData)
                    .thenReturn(journeyData);

            CustomerDetailsResponse response =
                    customerService.getCustomerDetails(
                    );

            assertNotNull(response);
            assertNotNull(response.getData());

            assertSame(
                    customerProfile,
                    response.getData().getCustomerProfile()
            );

            assertNull(
                    response.getData().getFatcaDetails()
            );

            assertNull(
                    response.getData().getEmploymentFinancial()
            );

            assertNotNull(
                    response.getData().getFinancialProducts()
            );

            assertEquals(
                    financialProducts,
                    response.getData()
                            .getFinancialProducts()
                            .getProducts()
            );

            verify(viewCustomerMapper)
                    .journeyDetailsMapper(journeyData);

            verify(viewCustomerMapper)
                    .journeyFactaDetailsMapper(journeyData);

            verify(viewCustomerMapper)
                    .employmentFinancialDetailsMapper(journeyData);

            verify(reviewCustomerProperties)
                    .getFinancialProducts();
        }
    }


    @Test
    void getCustomerDetails_shouldReturnNotFoundWhenJourneyDoesNotExist() {

        String journeyId = "JOURNEY-123";

        try (MockedStatic<JourneyContextHolder> context =
                     mockStatic(JourneyContextHolder.class)) {

            context.when(JourneyContextHolder::getJourneyData)
                    .thenReturn(null);

            CustomerDetailsResponse response =
                    customerService.getCustomerDetails(
                    );

            assertNotNull(response);
            assertNull(response.getData());

            verifyNoInteractions(viewCustomerMapper);
            verifyNoInteractions(reviewCustomerProperties);
        }
    }


    // ============================================================
    // getReviewCustomerDetails()
    // ============================================================

    @Test
    void getReviewCustomerDetails_shouldReturnNotFoundWhenJourneyDoesNotExist() {

        String journeyId = "JOURNEY-123";

        try (MockedStatic<JourneyContextHolder> context =
                     mockStatic(JourneyContextHolder.class)) {

            context.when(JourneyContextHolder::getJourneyData)
                    .thenReturn(null);

            ReviewCustomerResponse response =
                    customerService.getReviewCustomerDetails(
                    );

            assertNotNull(response);
            assertNull(response.getData());

            verifyNoInteractions(reviewCustomerMapper);
            verifyNoInteractions(viewCustomerMapper);
            verifyNoInteractions(reviewCustomerProperties);
        }
    }


    @Test
    void getReviewCustomerDetails_shouldReturnDetailsWhenJourneyExists() {

        String journeyId = "JOURNEY-123";

        JourneyData journeyData =
                mock(JourneyData.class);

        ReviewCustomerResponse.ReviewCustomerDetails details =
                new ReviewCustomerResponse.ReviewCustomerDetails();

        when(reviewCustomerMapper.mapToReviewDetails(
                anyMap(),
                anyMap(),
                eq(journeyData)
        )).thenReturn(details);

        when(viewCustomerMapper.journeyDetailsMapper(journeyData))
                .thenReturn(null);

        when(viewCustomerMapper.journeyFactaDetailsMapper(journeyData))
                .thenReturn(null);

        when(reviewCustomerProperties.getBranchName())
                .thenReturn("Test Branch");

        when(reviewCustomerProperties.getBranchCode())
                .thenReturn("001");

        when(reviewCustomerProperties.getBranchAddress())
                .thenReturn("Test Address");

        try (MockedStatic<JourneyContextHolder> context =
                     mockStatic(JourneyContextHolder.class);

             MockedStatic<JourneyService> journeyServiceStatic =
                     mockStatic(JourneyService.class)) {

            context.when(JourneyContextHolder::getJourneyData)
                    .thenReturn(journeyData);

            journeyServiceStatic
                    .when(() ->
                            JourneyService.getDomainPageUserInputs(
                                    eq(journeyData),
                                    anyString()
                            )
                    )
                    .thenReturn(Collections.emptyMap());

            ReviewCustomerResponse response =
                    customerService.getReviewCustomerDetails(
                    );

            assertNotNull(response);
            assertNotNull(response.getData());

            verify(reviewCustomerMapper)
                    .mapToReviewDetails(
                            anyMap(),
                            anyMap(),
                            eq(journeyData)
                    );

            verify(viewCustomerMapper)
                    .journeyDetailsMapper(journeyData);

            verify(viewCustomerMapper)
                    .journeyFactaDetailsMapper(journeyData);

            verify(reviewCustomerProperties)
                    .getBranchName();

            verify(reviewCustomerProperties)
                    .getBranchCode();

            verify(reviewCustomerProperties)
                    .getBranchAddress();
        }
    }


    @Test
    void getReviewCustomerDetails_shouldCreateDetailsWhenMapperReturnsNull() {

        String journeyId = "JOURNEY-123";

        JourneyData journeyData =
                mock(JourneyData.class);

        when(reviewCustomerMapper.mapToReviewDetails(
                anyMap(),
                anyMap(),
                eq(journeyData)
        )).thenReturn(null);

        when(viewCustomerMapper.journeyDetailsMapper(journeyData))
                .thenReturn(null);

        when(viewCustomerMapper.journeyFactaDetailsMapper(journeyData))
                .thenReturn(null);

        when(reviewCustomerProperties.getBranchName())
                .thenReturn("Test Branch");

        when(reviewCustomerProperties.getBranchCode())
                .thenReturn("001");

        when(reviewCustomerProperties.getBranchAddress())
                .thenReturn("Test Address");

        try (MockedStatic<JourneyContextHolder> context =
                     mockStatic(JourneyContextHolder.class);

             MockedStatic<JourneyService> journeyServiceStatic =
                     mockStatic(JourneyService.class)) {

            context.when(JourneyContextHolder::getJourneyData)
                    .thenReturn(journeyData);

            journeyServiceStatic
                    .when(() ->
                            JourneyService.getDomainPageUserInputs(
                                    eq(journeyData),
                                    anyString()
                            )
                    )
                    .thenReturn(Collections.emptyMap());

            ReviewCustomerResponse response =
                    customerService.getReviewCustomerDetails(
                    );

            assertNotNull(response);
            assertNotNull(response.getData());

            verify(reviewCustomerMapper)
                    .mapToReviewDetails(
                            anyMap(),
                            anyMap(),
                            eq(journeyData)
                    );

            verify(viewCustomerMapper)
                    .journeyDetailsMapper(journeyData);

            verify(viewCustomerMapper)
                    .journeyFactaDetailsMapper(journeyData);
        }
    }


    @Test
    void getReviewCustomerDetails_shouldMergeFatcaDetailsWhenExistingFatcaIsPresent() {

        String journeyId = "JOURNEY-123";

        JourneyData journeyData =
                mock(JourneyData.class);

        ReviewCustomerResponse.ReviewCustomerDetails details =
                mock(
                        ReviewCustomerResponse.ReviewCustomerDetails.class
                );

        /*
         * We don't need to know the concrete nested FATCA DTO type.
         * Mockito creates a mock using the method's return type.
         */
        when(details.getFatcaDetails())
                .thenAnswer(invocation ->
                        mock(
                                invocation.getMethod().getReturnType()
                        )
                );

        when(reviewCustomerMapper.mapToReviewDetails(
                anyMap(),
                anyMap(),
                eq(journeyData)
        )).thenReturn(details);

        when(viewCustomerMapper.journeyDetailsMapper(journeyData))
                .thenReturn(null);

        when(viewCustomerMapper.journeyFactaDetailsMapper(journeyData))
                .thenAnswer(invocation ->
                        mock(
                                invocation.getMethod().getReturnType()
                        )
                );

        when(reviewCustomerProperties.getBranchName())
                .thenReturn("Test Branch");

        when(reviewCustomerProperties.getBranchCode())
                .thenReturn("001");

        when(reviewCustomerProperties.getBranchAddress())
                .thenReturn("Test Address");

        try (MockedStatic<JourneyContextHolder> context =
                     mockStatic(JourneyContextHolder.class);

             MockedStatic<JourneyService> journeyServiceStatic =
                     mockStatic(JourneyService.class)) {

            context.when(JourneyContextHolder::getJourneyData)
                    .thenReturn(journeyData);

            journeyServiceStatic
                    .when(() ->
                            JourneyService.getDomainPageUserInputs(
                                    eq(journeyData),
                                    anyString()
                            )
                    )
                    .thenReturn(Collections.emptyMap());

            ReviewCustomerResponse response =
                    customerService.getReviewCustomerDetails(
                    );

            assertNotNull(response);
            assertNotNull(response.getData());

            verify(reviewCustomerMapper)
                    .mergeFatcaDetails(
                            any(),
                            any()
                    );
        }
    }


    @Test
    void identifyCustomer_shouldStopBeforeOtpWhenFcIndiaStatusIsMissing() {
        IdentifyCustomerRequest request = mock(IdentifyCustomerRequest.class);
        FetchCasaRequest downstreamRequest = mock(FetchCasaRequest.class);
        JourneyDataProcessor processor = mock(JourneyDataProcessor.class);
        when(journeyDataProcessorFactory.getJourneyDataValidation()).thenReturn(processor);
        when(customerMapper.toFetchCasaRequest(request, "ACCOUNT_OPENING")).thenReturn(downstreamRequest);
        when(customerFCFeignClient.identifyCustomer(downstreamRequest, "J-NO-STATUS"))
                .thenReturn(new FetchCasaResponse());

        assertThrows(com.hdfcbank.exception.DownstreamApiException.class,
                () -> customerService.identifyCustomer(request, "J-NO-STATUS", "ACCOUNT_OPENING"));

        verify(validationFailureHandler).dropOnValidationFailure(eq("J-NO-STATUS"),
                eq(CustomerApiStatusCode.DOWNSTREAM_API_ERROR), anyString(),
                eq(CommonJourneyStates.DROP_OFF_CUSTOMER_EXCLUDED));
        verifyNoInteractions(communicationService, otpResponseHandler);
        verify(customerFCFeignClient, never()).fetchGcCustomer(any(), anyString());
    }

    @Test
    void identifyCustomer_shouldStopWhenRequestValidationFails() {
        IdentifyCustomerRequest request = mock(IdentifyCustomerRequest.class);
        JourneyDataProcessor processor = mock(JourneyDataProcessor.class);
        when(journeyDataProcessorFactory.getJourneyDataValidation()).thenReturn(processor);
        IllegalArgumentException failure = new IllegalArgumentException("Invalid request");
        doThrow(failure).when(processor).validateRequest(request, "J-INVALID");

        assertSame(failure, assertThrows(IllegalArgumentException.class,
                () -> customerService.identifyCustomer(request, "J-INVALID", "ACCOUNT_OPENING")));

        verifyNoInteractions(journeyService, customerMapper, customerFCFeignClient,
                communicationService, otpResponseHandler);
    }

    @ParameterizedTest
    @NullAndEmptySource
    @ValueSource(strings = " ")
    void resendOtp_shouldUseMobileNumberWithoutMissingIsd(String isd) {
        JourneyData journey = new JourneyData();
        journey.setJourneyName("ACCOUNT_OPENING");
        journey.setIsd(isd);
        journey.setMobileNumber("9000000000");
        Profile profile = new Profile();
        profile.setEmailId("customer@example.com");
        profile.setDob("1990-01-01");
        journey.setProfile(profile);
        GenerateOtpResponse otp = mock(GenerateOtpResponse.class);
        IdentifyCustomerResponse expected = mock(IdentifyCustomerResponse.class);
        when(communicationService.resendOtp("9000000000", "customer@example.com", "ACCOUNT_OPENING", "J-OTP"))
                .thenReturn(otp);
        when(otpResponseHandler.handleGenerateOtpResponse("9000000000", "1990-01-01", otp, "J-OTP", true))
                .thenReturn(expected);

        try (MockedStatic<JourneyContextHolder> context = mockStatic(JourneyContextHolder.class)) {
            context.when(JourneyContextHolder::getJourneyData).thenReturn(journey);

            assertSame(expected, customerService.resendOtp("J-OTP"));

            verify(communicationService).resendOtp(
                    "9000000000", "customer@example.com", "ACCOUNT_OPENING", "J-OTP");
        }
    }

    @Test
    void filterProfilesByCustomerTypes_shouldExcludeMissingCustomerType() {
        FetchCasaResponse.Profile profile = mock(FetchCasaResponse.Profile.class);
        FetchCasaResponse.CustomerAccountDetail account = mock(FetchCasaResponse.CustomerAccountDetail.class);
        when(profile.getCustomerAccountDetails()).thenReturn(List.of(account));
        when(account.getAccountStatus()).thenReturn(CommonConstants.VALID_ACCOUNT_STATUS_CODE);

        assertTrue(customerService.filterProfilesByCustomerTypes(List.of(profile), "INDIVIDUAL").isEmpty());
    }

    // ============================================================
    // Helper methods
    // ============================================================

    @SuppressWarnings({"rawtypes", "unchecked"})
    private Map createCustomerTypes(
            String journeyName,
            String allowedTypes) {

        Map journeyConfig = new HashMap();

        journeyConfig.put(
                ALLOWED,
                allowedTypes
        );

        Map customerTypes = new HashMap();

        customerTypes.put(
                journeyName,
                journeyConfig
        );

        return customerTypes;
    }
}
