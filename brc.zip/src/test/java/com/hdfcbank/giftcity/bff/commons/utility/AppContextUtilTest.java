package com.hdfcbank.giftcity.bff.commons.utility;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.context.ApplicationContext;

import static org.junit.jupiter.api.Assertions.*;

class AppContextUtilTest {

    @BeforeEach
    void resetStaticContext() {
        // Reset static field using instance method
        new AppContextUtil().setApplicationContext(null);
    }

    @Test
    void testSetApplicationContextStoresContextCorrectly() {
        ApplicationContext mockContext = Mockito.mock(ApplicationContext.class);

        AppContextUtil util = new AppContextUtil();
        util.setApplicationContext(mockContext);

        assertNotNull(AppContextUtil.getApplicationContext());
        assertEquals(mockContext, AppContextUtil.getApplicationContext());
    }

    @Test
    void testGetApplicationContextReturnsNullInitially() {
        assertNull(AppContextUtil.getApplicationContext());
    }

    @Test
    void testSetApplicationContextOverwritesContext() {
        ApplicationContext mockContext1 = Mockito.mock(ApplicationContext.class);
        ApplicationContext mockContext2 = Mockito.mock(ApplicationContext.class);

        AppContextUtil util = new AppContextUtil();
        util.setApplicationContext(mockContext1);

        assertEquals(mockContext1, AppContextUtil.getApplicationContext());

        util.setApplicationContext(mockContext2); // overwrite

        assertEquals(mockContext2, AppContextUtil.getApplicationContext());
    }
}