package com.hdfcbank.giftcity.bff.application.handlers.submit;

import com.hdfcbank.common.models.vo.core.ApiResponseStatus;
import com.hdfcbank.common.models.vo.journey.JourneyData;
import com.hdfcbank.giftcity.bff.account.mapper.CreateCustomerAccountMapper;
import com.hdfcbank.giftcity.bff.commons.enums.CommonJourneyStates;
import com.hdfcbank.giftcity.bff.commons.enums.JourneyPageName;
import com.hdfcbank.giftcity.bff.commons.exception.handler.DownstreamResponseHandler;
import com.hdfcbank.giftcity.bff.commons.handler.Handler;
import com.hdfcbank.giftcity.bff.commons.handler.HandlerContext;
import com.hdfcbank.giftcity.bff.commons.handler.HandlerResult;
import com.hdfcbank.giftcity.bff.commons.model.CustomValidationStatus;
import com.hdfcbank.giftcity.bff.commons.model.FcGcProfile;
import com.hdfcbank.giftcity.bff.commons.model.FcIndiaProfile;
import com.hdfcbank.giftcity.bff.customer.config.CustomerApiProperties;
import com.hdfcbank.giftcity.bff.customer.utility.CustomerUtil;
import com.hdfcbank.giftcity.bff.infrastructure.service.JourneyService;
import com.hdfcbank.service.adapters.clients.feign.account.AccountServiceFeignClient;
import com.hdfcbank.service.adapters.vo.account.CreateCustomerAccountRequest;
import com.hdfcbank.service.adapters.vo.account.CreateCustomerAccountResponse;

import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.*;
import java.util.function.Function;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

import ch.qos.logback.classic.Level;
import ch.qos.logback.classic.Logger;
import org.slf4j.LoggerFactory;

@ExtendWith(MockitoExtension.class)
class CreateCustomerAccountHandlerTest {

    /** Mute ALL logs */
    @BeforeAll
    static void muteLogs() {
        Logger logger = (Logger) LoggerFactory.getLogger(CreateCustomerAccountHandler.class);
        logger.setLevel(Level.OFF);
    }

    @Mock private CustomerApiProperties customerApiProperties;
    @Mock private JourneyService journeyService;
    @Mock private AccountServiceFeignClient accountServiceFeignClient;
    @Mock private CreateCustomerAccountMapper mapper;

    @Spy
    @InjectMocks
    private CreateCustomerAccountHandler handler;

    private HandlerContext ctx;
    private JourneyData journeyData;

    @BeforeEach
    void setup() {
        journeyData = JourneyData.builder()
                .journeyId("J123")
                .journeyName("GIFT_CITY")
                .build();

        ctx = HandlerContext.builder()
                .journeyData(journeyData)
                .data(new HashMap<>())
                .properties(new HashMap<>())
                .build();
    }

    // -------------------------------------------------------------------------
    // PRECONDITIONS
    // -------------------------------------------------------------------------
    @Test
    void preConditions_shouldReturnTrue_whenCreateCustomerSuccess() {
        doReturn(true).when(handler).isSuccess(ctx, Handler.HandlerName.CREATE_CUSTOMER);
        assertTrue(handler.preConditions(ctx));
    }

    @Test
    void preConditions_shouldReturnFalse_whenCreateCustomerFails() {
        doReturn(false).when(handler).isSuccess(ctx, Handler.HandlerName.CREATE_CUSTOMER);
        assertFalse(handler.preConditions(ctx));
    }

    // -------------------------------------------------------------------------
    // SUCCESS FLOW
    // -------------------------------------------------------------------------
    @Test
    void handle_shouldReturnSuccess_whenResponseCodeIs0000() {

        // API Properties
        CustomerApiProperties.ApiDetails apiDetails = new CustomerApiProperties.ApiDetails();
        apiDetails.setServiceDefaults(Map.of("BRANCH_CODE", "999"));
        when(customerApiProperties.getCreateFccCustomerAccount())
                .thenReturn(apiDetails);

        // PrimaryProfile static mocks
        FcIndiaProfile.Profile fcProfile = FcIndiaProfile.Profile.builder()
                .name("John Doe")
                .build();

        FcGcProfile gcProfile = FcGcProfile.builder()
                .customerNumber("CUST123")
                .build();

        try (MockedStatic<CustomerUtil> cust = mockStatic(CustomerUtil.class);
             MockedStatic<JourneyService> jsvc = mockStatic(JourneyService.class)) {

            cust.when(() -> CustomerUtil.getPrimaryProfile(journeyData))
                    .thenReturn(Optional.of(fcProfile));

            cust.when(() -> CustomerUtil.getFCGiftCityProfile(journeyData))
                    .thenReturn(Optional.of(gcProfile));

            cust.when(() -> CustomerUtil.getNomineeDetailFromJourneyData(journeyData))
                    .thenReturn(null);

            cust.when(() -> CustomerUtil.getValueByPath(any(), any(), any()))
                    .thenReturn("USD");

            jsvc.when(() -> JourneyService.extractFromJourney(
                    eq(journeyData),
                    eq(JourneyPageName.CUSTOMER_FC_GIFT_CITY_DETAIL.getPageName()),
                    eq(FcGcProfile.class),
                    any(Function.class)
            )).thenReturn(Optional.of(gcProfile));

            // Mapper → request creation
            CreateCustomerAccountRequest req =
                    CreateCustomerAccountRequest.builder()
                            .customerName("John Doe")
                            .build();

            when(mapper.toRequest(
                    eq(journeyData),
                    eq("CUST123"),
                    eq(fcProfile),
                    eq(null),
                    eq(null),
                    eq(null),
                    anyMap(),
                    eq("USD")
            )).thenReturn(req);

            // Feign Response
            ApiResponseStatus ok = new ApiResponseStatus();
            ok.setCode("0000");
            ok.setMessage("OK");

            CreateCustomerAccountResponse.CreateCustomerAccountData data =
                    CreateCustomerAccountResponse.CreateCustomerAccountData.builder()
                            .accountNumber("ACC001")
                            .build();

            CreateCustomerAccountResponse resp =
                    CreateCustomerAccountResponse.builder()
                            .status(ok)
                            .data(data)
                            .build();

            when(accountServiceFeignClient.createFccCustomerAccount(eq(req), eq("J123")))
                    .thenReturn(resp);

            doNothing().when(journeyService).updateJourney(
                    eq("J123"),
                    eq(JourneyPageName.CUSTOMER_FC_GIFT_CITY_DETAIL.getPageName()),
                    any(FcGcProfile.class),
                    eq(CommonJourneyStates.CUSTOMER_FC_GC_DETAIL_CAPTURED)
            );

            // ACT
            HandlerResult<CreateCustomerAccountResponse> result = handler.handle(ctx);

            // -------------------------------------------------------
            // ✅ ASSERTIONS
            // -------------------------------------------------------
            assertTrue(result.isSuccess(), "Handler must indicate success");

            // Response integrity
            assertNotNull(result.getResult());
            assertEquals("0000", result.getResult().getStatus().getCode());
            assertEquals("OK", result.getResult().getStatus().getMessage());
            assertEquals("ACC001", result.getResult().getData().getAccountNumber());

            // ✅ No CustomValidationStatus in SUCCESS
            assertNull(result.getApiResponseStatus(),
                    "apiResponseStatus must be NULL for success flows");

            // Mapper verification
            verify(mapper, times(1)).toRequest(
                    eq(journeyData),
                    eq("CUST123"),
                    eq(fcProfile),
                    eq(null),
                    eq(null),
                    eq(null),
                    anyMap(),
                    eq("USD")
            );

            // Feign invocation
            verify(accountServiceFeignClient, times(1))
                    .createFccCustomerAccount(eq(req), eq("J123"));

            // Journey update triggered
            verify(journeyService, times(1))
                    .updateJourney(
                            eq("J123"),
                            eq(JourneyPageName.CUSTOMER_FC_GIFT_CITY_DETAIL.getPageName()),
                            any(FcGcProfile.class),
                            eq(CommonJourneyStates.CUSTOMER_FC_GC_DETAIL_CAPTURED)
                    );
        }
    }

    // -------------------------------------------------------------------------
    // FAILURE FLOW
    // -------------------------------------------------------------------------
    @Test
    void handle_shouldReturnFailure_whenResponseCodeIsNot0000() {

        CustomerApiProperties.ApiDetails apiDetails = new CustomerApiProperties.ApiDetails();
        apiDetails.setServiceDefaults(Map.of());
        when(customerApiProperties.getCreateFccCustomerAccount())
                .thenReturn(apiDetails);

        try (MockedStatic<CustomerUtil> cust = mockStatic(CustomerUtil.class);
             MockedStatic<DownstreamResponseHandler> dsh = mockStatic(DownstreamResponseHandler.class)) {

            cust.when(() -> CustomerUtil.getPrimaryProfile(journeyData))
                    .thenReturn(Optional.empty());

            cust.when(() -> CustomerUtil.getFCGiftCityProfile(journeyData))
                    .thenReturn(Optional.empty());

            cust.when(() -> CustomerUtil.getNomineeDetailFromJourneyData(journeyData))
                    .thenReturn(null);

            cust.when(() -> CustomerUtil.getValueByPath(any(), any(), any()))
                    .thenReturn("USD");

            CreateCustomerAccountRequest req = new CreateCustomerAccountRequest();

            when(mapper.toRequest(any(), any(), any(), any(), any(), any(), anyMap(), any()))
                    .thenReturn(req);

            ApiResponseStatus fail = new ApiResponseStatus();
            fail.setCode("9999");
            fail.setMessage("FAILED");

            CreateCustomerAccountResponse resp =
                    CreateCustomerAccountResponse.builder()
                            .status(fail)
                            .build();

            when(accountServiceFeignClient.createFccCustomerAccount(eq(req), eq("J123")))
                    .thenReturn(resp);

            CustomValidationStatus custom = CustomValidationStatus.builder()
                    .code("ERR")
                    .message("DOWNSTREAM_FAIL")
                    .build();

            dsh.when(() -> DownstreamResponseHandler.handleResponse(
                    eq(resp),
                    eq(Handler.HandlerName.CREATE_ACCOUNT.name()),
                    eq(false),
                    eq("GIFT_CITY")
            )).thenReturn(custom);

            HandlerResult<CreateCustomerAccountResponse> result = handler.handle(ctx);

            assertFalse(result.isSuccess());
            assertEquals("ERR", result.getApiResponseStatus().getCode());
            assertEquals("DOWNSTREAM_FAIL", result.getApiResponseStatus().getMessage());
        }
    }

    // -------------------------------------------------------------------------
    // EXCEPTION FLOW
    // -------------------------------------------------------------------------
    @Test
    void handle_shouldReturnFailure_whenExceptionThrown() {

        CustomerApiProperties.ApiDetails apiDetails = new CustomerApiProperties.ApiDetails();
        apiDetails.setServiceDefaults(Map.of());
        when(customerApiProperties.getCreateFccCustomerAccount())
                .thenReturn(apiDetails);

        CreateCustomerAccountRequest req = new CreateCustomerAccountRequest();
        when(mapper.toRequest(any(), any(), any(), any(), any(), any(), anyMap(), any()))
                .thenReturn(req);

        when(accountServiceFeignClient.createFccCustomerAccount(eq(req), eq("J123")))
                .thenThrow(new RuntimeException("Boom"));

        CustomValidationStatus custom = CustomValidationStatus.builder()
                .code("EX")
                .message("EXCEPTION")
                .build();

        try (MockedStatic<DownstreamResponseHandler> dsh = mockStatic(DownstreamResponseHandler.class)) {

            dsh.when(() -> DownstreamResponseHandler.handleResponse(
                    eq(null),
                    eq(Handler.HandlerName.CREATE_ACCOUNT.name()),
                    eq(false),
                    eq("GIFT_CITY")
            )).thenReturn(custom);

            HandlerResult<CreateCustomerAccountResponse> result = handler.handle(ctx);

            assertFalse(result.isSuccess());
            assertEquals("EX", result.getApiResponseStatus().getCode());
            assertEquals("EXCEPTION", result.getApiResponseStatus().getMessage());
        }
    }

    // -------------------------------------------------------------------------
    // ENUM COVERAGE
    // -------------------------------------------------------------------------
    @Test
    void enumCoverage() {
        assertEquals(Handler.HandlerType.CUSTOMER_POST_SUBMIT, handler.getType());
        assertEquals(Handler.HandlerName.CREATE_ACCOUNT, handler.getName());
        assertEquals(CommonJourneyStates.CREATE_FCC_CUSTOMER_ACCOUNT_SUCCESS, handler.successState());
        assertEquals(CommonJourneyStates.CREATE_FCC_CUSTOMER_ACCOUNT_FAILURE, handler.failureState());
    }
}