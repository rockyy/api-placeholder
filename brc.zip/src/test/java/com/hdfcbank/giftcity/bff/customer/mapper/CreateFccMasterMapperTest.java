package com.hdfcbank.giftcity.bff.customer.mapper;

import com.hdfcbank.giftcity.bff.customer.config.CreateFccMastersConfig;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class CreateFccMasterMapperTest {

    private CreateFccMastersConfig config;
    private CreateFccMasterMapper mapper;

    @BeforeEach
    void setup() {
        config = new CreateFccMastersConfig();

        // Populate all mapping lists
        config.setOccupationMapping(List.of(
                CreateFccMastersConfig.OccupationMapping.builder()
                        .occupationType("SALARIED")
                        .fccOccupation("OCC_SAL")
                        .build(),
                CreateFccMastersConfig.OccupationMapping.builder()
                        .occupationType("SELF_EMPLOYED")
                        .fccOccupation("OCC_SELF")
                        .build()
        ));

        config.setOccupationNewMapping(List.of(
                // Exact match case
                CreateFccMastersConfig.OccupationNewMapping.builder()
                        .occupationType("SALARIED")
                        .designation("Manager")
                        .fccOccupationNew("NEW_SAL_MANAGER")
                        .build(),
                // Fallback when designation is blank
                CreateFccMastersConfig.OccupationNewMapping.builder()
                        .occupationType("SALARIED")
                        .designation("")
                        .fccOccupationNew("NEW_SAL_DEFAULT")
                        .build(),
                // Another fallback for coverage
                CreateFccMastersConfig.OccupationNewMapping.builder()
                        .occupationType("SELF_EMPLOYED")
                        .designation("")
                        .fccOccupationNew("NEW_SELF_DEFAULT")
                        .build()
        ));

        config.setIndustryMapping(List.of(
                CreateFccMastersConfig.IndustryMapping.builder()
                        .industryType("BANKING")
                        .fccIndustry("IND_BANK")
                        .build(),
                CreateFccMastersConfig.IndustryMapping.builder()
                        .industryType("IT")
                        .fccIndustry("IND_IT")
                        .build()
        ));

        config.setNatureOfBusinessMapping(List.of(
                CreateFccMastersConfig.NatureOfBusinessMapping.builder()
                        .industryVariation("FINTECH")
                        .natureOfBusiness("NOB_FINTECH")
                        .build(),
                CreateFccMastersConfig.NatureOfBusinessMapping.builder()
                        .industryVariation("AGRI")
                        .natureOfBusiness("NOB_AGRI")
                        .build()
        ));

        mapper = new CreateFccMasterMapper(config);
    }

    // resolveOccupation() Tests

    @Test
    void testResolveOccupation_exactMatch() {
        assertEquals("OCC_SAL", mapper.resolveOccupation("SALARIED"));
    }

    @Test
    void testResolveOccupation_noMatch_returnsDefault() {
        assertEquals("Others", mapper.resolveOccupation("UNKNOWN"));
    }

    @Test
    void testResolveOccupation_blank_returnsDefault() {
        assertEquals("Others", mapper.resolveOccupation(null));
        assertEquals("Others", mapper.resolveOccupation(""));
        assertEquals("Others", mapper.resolveOccupation("   "));
    }

    // resolveOccupationNew() Tests

    @Test
    void testResolveOccupationNew_exactMatch() {
        assertEquals("NEW_SAL_MANAGER",
                mapper.resolveOccupationNew("SALARIED", "Manager"));
    }

    @Test
    void testResolveOccupationNew_fallbackDesignation_blank() {
        assertEquals("NEW_SAL_DEFAULT",
                mapper.resolveOccupationNew("SALARIED", "Officer"));
    }

    @Test
    void testResolveOccupationNew_noMatch_returnsDefault() {
        assertEquals("Others",
                mapper.resolveOccupationNew("UNKNOWN", "Something"));
    }

    @Test
    void testResolveOccupationNew_blankInputs_returnDefault() {
        assertEquals("Others", mapper.resolveOccupationNew(null, "Manager"));
        assertEquals("Others", mapper.resolveOccupationNew("", "Manager"));
        assertEquals("Others", mapper.resolveOccupationNew("   ", "Manager"));
    }

    // resolveIndustry() Tests

    @Test
    void testResolveIndustry_exactMatch() {
        assertEquals("IND_BANK", mapper.resolveIndustry("BANKING"));
    }

    @Test
    void testResolveIndustry_noMatch_returnInput() {
        assertEquals("UNKNOWN", mapper.resolveIndustry("UNKNOWN"));
    }

    @Test
    void testResolveIndustry_blank_returnDefault() {
        assertEquals("Others", mapper.resolveIndustry(null));
        assertEquals("Others", mapper.resolveIndustry(""));
        assertEquals("Others", mapper.resolveIndustry("   "));
    }

    // resolveNatureOfBusiness() Tests

    @Test
    void testResolveNatureOfBusiness_exactMatch() {
        assertEquals("NOB_FINTECH", mapper.resolveNatureOfBusiness("FINTECH"));
    }

    @Test
    void testResolveNatureOfBusiness_noMatch_returnInput() {
        assertEquals("UNKNOWN", mapper.resolveNatureOfBusiness("UNKNOWN"));
    }

    @Test
    void testResolveNatureOfBusiness_blank_returnDefault() {
        assertEquals("Others", mapper.resolveNatureOfBusiness(null));
        assertEquals("Others", mapper.resolveNatureOfBusiness(""));
        assertEquals("Others", mapper.resolveNatureOfBusiness("   "));
    }

    // isBlank() coverage — implicitly covered

    @Test
    void testAllBlankCoverage() {
        // ensures all blank branches have already been covered
        assertEquals("Others", mapper.resolveOccupation(" "));
        assertEquals("Others", mapper.resolveOccupationNew(" ", "Manager"));
        assertEquals("Others", mapper.resolveIndustry(" "));
        assertEquals("Others", mapper.resolveNatureOfBusiness(" "));
    }
}
