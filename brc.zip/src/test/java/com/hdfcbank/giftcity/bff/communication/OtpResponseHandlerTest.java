package com.hdfcbank.giftcity.bff.communication;

import com.hdfcbank.adapters.vo.GenerateOtpResponse;
import com.hdfcbank.adapters.vo.VerifyOtpResponse;
import com.hdfcbank.common.models.vo.core.ApiResponseStatus;
import com.hdfcbank.common.models.vo.journey.JourneyData;
import com.hdfcbank.giftcity.bff.commons.config.JourneyContextHolder;
import com.hdfcbank.giftcity.bff.commons.enums.CommonJourneyStates;
import com.hdfcbank.giftcity.bff.commons.model.CustomValidationStatus;
import com.hdfcbank.giftcity.bff.consent.service.ConsentService;
import com.hdfcbank.giftcity.bff.customer.model.*;
import com.hdfcbank.giftcity.bff.infrastructure.service.JourneyService;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class OtpResponseHandlerTest {

    @Mock JourneyService journeyService;
    @Mock ConsentService consentService;

    @InjectMocks
    OtpResponseHandler handler;

    @BeforeEach
    void setup() {
        JourneyData jd = new JourneyData();
        jd.setJourneyId("JCTX");
        JourneyContextHolder.setJourneyData(jd);
    }

    // generate OTP (email version)
    @Test
    @DisplayName("Generate OTP (email): SUCCESS")
    void testGenerateOtpEmailSuccess() {

        HandleGenerateOtpResponse req = HandleGenerateOtpResponse.builder()
                .mobileNumber("9876543210")
                .dob("1990-01-01")
                .journeyId("J100")
                .eligibleAccounts(2)
                .isRetry(false)
                .build();

        // Correct inner data class based on your errors
        GenerateOtpResponse.GenerateOtpDetail detail = new GenerateOtpResponse.GenerateOtpDetail();
        detail.setTxnRef("TX123");

        GenerateOtpResponse res = new GenerateOtpResponse();
        res.setStatus(ApiResponseStatus.success());
        res.setData(detail);

        IdentifyCustomerResponse out =
                handler.handleGenerateOtpResponse(req, res, "J100", "abc@test.com");

        assertEquals("TX123", out.getData().getTxnRef());
        verify(journeyService).updateJourneyState("J100",
                CommonJourneyStates.OTP_GENERATE_SUCCESS.name());
    }

    // generate OTP (email) FAILURE
    @Test
    @DisplayName("Generate OTP (email): FAILURE")
    void testGenerateOtpEmailFailure() {

        HandleGenerateOtpResponse req = HandleGenerateOtpResponse.builder()
                .mobileNumber("9876543210")
                .dob("1990-01-01")
                .journeyId("J102")
                .eligibleAccounts(0)
                .isRetry(false)
                .build();

        GenerateOtpResponse res = new GenerateOtpResponse();
        res.setStatus(new ApiResponseStatus(CustomerApiStatusCode.FAILED));

        IdentifyCustomerResponse out =
                handler.handleGenerateOtpResponse(req, res, "J102", "abc@test.com");

        assertNull(out.getData().getTxnRef());
        verify(journeyService).recordJourneyState("J102",
                CommonJourneyStates.OTP_GENERATE_FAILURE);
    }

    // verify OTP (SUCCESS)
    @Test
    @DisplayName("Verify OTP: SUCCESS")
    void testVerifyOtpSuccess() {

        // real class uses otp(), NOT otpValue()
        ValidateCustomerRequest req = ValidateCustomerRequest.builder()
                .otp("123456")
                .consents(List.of(
                        CustomerConsentRequest.builder().key("K1").acceptance(true).build()
                ))
                .build();

        VerifyOtpResponse res = new VerifyOtpResponse();
        res.setStatus(new ApiResponseStatus(OtpApiStatusCode.SUCCESS));

        JourneyData jd = new JourneyData();
        jd.setJourneyId("J400");

        ValidateCustomerResponse out =
                handler.handleVerifyOtpResponse(req, res, jd);

        assertTrue(out.getData().isOtpValidated());
        verify(journeyService).recordJourneyState("J400",
                CommonJourneyStates.CUSTOMER_VALIDATED_SUCCESS);
        verify(consentService).storeConsentsData(anyList(), eq(jd));
    }

    // verify OTP (MISMATCH)
    @Test
    @DisplayName("Verify OTP: MISMATCH")
    void testVerifyOtpMismatch() {

        ValidateCustomerRequest req = ValidateCustomerRequest.builder()
                .otp("123456")
                .consents(List.of())
                .build();

        VerifyOtpResponse res = new VerifyOtpResponse();
        res.setStatus(new ApiResponseStatus(OtpApiStatusCode.OTP_MISMATCHED));

        JourneyData jd = new JourneyData();
        jd.setJourneyId("J401");

        ValidateCustomerResponse out =
                handler.handleVerifyOtpResponse(req, res, jd);

        assertFalse(out.getData().isOtpValidated());
        assertEquals(2, out.getData().getIncorrectAttempts());

        verify(journeyService).recordJourneyState("J401",
                CommonJourneyStates.OTP_VALIDATE_MISMATCH);
    }

    // verify OTP (EXPIRED)
    @Test
    @DisplayName("Verify OTP: EXPIRED")
    void testVerifyOtpExpired() {

        ValidateCustomerRequest req = ValidateCustomerRequest.builder()
                .otp("123456")
                .consents(List.of())
                .build();

        VerifyOtpResponse res = new VerifyOtpResponse();
        res.setStatus(new ApiResponseStatus(OtpApiStatusCode.OTP_EXPIRED));

        JourneyData jd = new JourneyData();
        jd.setJourneyId("J402");

        ValidateCustomerResponse out =
                handler.handleVerifyOtpResponse(req, res, jd);

        assertFalse(out.getData().isOtpValidated());
        assertEquals(1, out.getData().getIncorrectAttempts());

        verify(journeyService).updateJourneyDetailDropOff(eq(jd),
                any(CustomValidationStatus.class),
                eq(CommonJourneyStates.OTP_VALIDATE_EXPIRED));
    }

    // verify OTP (FAILURE fallback)
    @Test
    @DisplayName("Verify OTP: FAILURE")
    void testVerifyOtpFailure() {

        ValidateCustomerRequest req = ValidateCustomerRequest.builder()
                .otp("123456")
                .consents(List.of())
                .build();

        VerifyOtpResponse res = new VerifyOtpResponse();
        res.setStatus(new ApiResponseStatus(OtpApiStatusCode.FAILED));

        JourneyData jd = new JourneyData();
        jd.setJourneyId("J403");

        ValidateCustomerResponse out =
                handler.handleVerifyOtpResponse(req, res, jd);

        assertFalse(out.getData().isOtpValidated());
        verify(journeyService).recordJourneyState("J403",
                CommonJourneyStates.OTP_VALIDATE_FAILURE);
    }

// EMAIL VERSION — FAILURE with retry (missing earlier)
    @Test
    @DisplayName("handleGenerateOtpResponse(email): FAILURE on retry")
    void testGenerateOtpEmailFailureRetry() {

        HandleGenerateOtpResponse req = HandleGenerateOtpResponse.builder()
                .mobileNumber("9999999999")
                .dob("1990-01-01")
                .journeyId("J150")
                .eligibleAccounts(0)
                .isRetry(true)
                .build();

        GenerateOtpResponse res = new GenerateOtpResponse();
        res.setStatus(new ApiResponseStatus(CustomerApiStatusCode.FAILED));

        IdentifyCustomerResponse out =
                handler.handleGenerateOtpResponse(req, res, "J150", "test@xyz.com");

        assertNull(out.getData().getTxnRef());
        verify(journeyService)
                .recordJourneyState("J150", CommonJourneyStates.OTP_RESEND_FAILURE);
    }

// MOBILE/DOB VERSION — SUCCESS with retry (missing earlier)
    @Test
    @DisplayName("handleGenerateOtpResponse(mobile/dob): SUCCESS on retry")
    void testGenerateOtpMobileDobSuccessRetry() {

        GenerateOtpResponse.GenerateOtpDetail detail = new GenerateOtpResponse.GenerateOtpDetail();
        detail.setTxnRef("TX555");

        GenerateOtpResponse res = new GenerateOtpResponse();
        res.setStatus(ApiResponseStatus.success());
        res.setData(detail);

        IdentifyCustomerResponse out =
                handler.handleGenerateOtpResponse("9000", "2001-01-01", res, "J250", true);

        assertEquals("TX555", out.getData().getTxnRef());
        verify(journeyService)
                .updateJourneyState("J250", CommonJourneyStates.OTP_RESEND_SUCCESS.name());
    }

// MOBILE/DOB VERSION — FAILURE with retry (missing earlier)
    @Test
    @DisplayName("handleGenerateOtpResponse(mobile/dob): FAILURE on retry")
    void testGenerateOtpMobileDobFailureRetry() {

        GenerateOtpResponse res = new GenerateOtpResponse();
        res.setStatus(new ApiResponseStatus(CustomerApiStatusCode.FAILED));

        IdentifyCustomerResponse out =
                handler.handleGenerateOtpResponse("9000", "2001-01-01", res, "J260", true);

        assertNull(out.getData().getTxnRef());

        // failure branch uses same OTP_GENERATE_FAILURE regardless of retry
        verify(journeyService)
                .recordJourneyState("J260", CommonJourneyStates.OTP_GENERATE_FAILURE);
    }

// EMAIL VERSION — SUCCESS → validate builder method scenario
//    (covers the line building masked profile + eligibleAccounts)
    @Test
    @DisplayName("handleGenerateOtpResponse(email): SUCCESS → validate builder fields")
    void testGenerateOtpEmailSuccessProfileBuilder() {

        HandleGenerateOtpResponse req = HandleGenerateOtpResponse.builder()
                .mobileNumber("9876543210")
                .dob("1990-01-01")
                .journeyId("J350")
                .eligibleAccounts(7)
                .isRetry(false)
                .build();

        GenerateOtpResponse.GenerateOtpDetail detail = new GenerateOtpResponse.GenerateOtpDetail();
        detail.setTxnRef("TX777");

        GenerateOtpResponse res = new GenerateOtpResponse();
        res.setStatus(ApiResponseStatus.success());
        res.setData(detail);

        IdentifyCustomerResponse out =
                handler.handleGenerateOtpResponse(req, res, "J350", "hello@test.com");

        assertEquals("TX777", out.getData().getTxnRef());
        assertEquals(7, out.getData().getEligibleAccounts());
        assertNotNull(out.getData().getProfile());

        verify(journeyService)
                .updateJourneyState("J350", CommonJourneyStates.OTP_GENERATE_SUCCESS.name());
    }
}