package com.hdfcbank.giftcity.bff.customer.listener;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.hdfcbank.adapters.clients.feign.document.DocumentFeignClient;
import com.hdfcbank.adapters.vo.DocumentUploadedResponse;
import com.hdfcbank.common.models.vo.core.ApiResponse;
import com.hdfcbank.common.models.vo.journey.JourneyData;
import com.hdfcbank.giftcity.bff.commons.enums.CommonJourneyStates;
import com.hdfcbank.giftcity.bff.commons.enums.ImageFormat;
import com.hdfcbank.giftcity.bff.commons.exception.handler.DownstreamResponseHandler;
import com.hdfcbank.giftcity.bff.commons.model.CustomValidationStatus;
import com.hdfcbank.giftcity.bff.commons.utility.ImageConverter;
import com.hdfcbank.giftcity.bff.commons.validation.*;
import com.hdfcbank.giftcity.bff.customer.events.SqsCustomerValidateMessage;
import com.hdfcbank.giftcity.bff.customer.events.SqsCustomerValidatePayload;
import com.hdfcbank.giftcity.bff.customer.service.CustomerService;
import com.hdfcbank.giftcity.bff.infrastructure.service.JourneyService;

import io.awspring.cloud.sqs.listener.acknowledgement.Acknowledgement;
import org.junit.jupiter.api.*;
import org.mockito.*;

import ch.qos.logback.classic.Level;
import ch.qos.logback.classic.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;

import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

class SqsCustomerValidateListenerTest {

    //      GLOBAL LOG MUTE FOR THIS CLASS (NO LOGS PRINTED)
    @BeforeAll
    static void muteLogs() {
        Logger root = (Logger) LoggerFactory.getLogger(Logger.ROOT_LOGGER_NAME);
        root.setLevel(Level.OFF);
    }

    @InjectMocks
    private SqsCustomerValidateListener listener;

    @Mock private ObjectMapper objectMapper;
    @Mock private ValidatorsFactory validatorsFactory;
    @Mock private JourneyService journeyService;
    @Mock private CustomerService customerService;
    @Mock private DocumentFeignClient documentFeignClient;
    @Mock private Acknowledgement acknowledgement;

    @Mock DownstreamResponseHandler downstreamResponseHandler;

    private JourneyData journeyData;
    private SqsCustomerValidateMessage message;

    @BeforeEach
    void setup() {
        MockitoAnnotations.openMocks(this);

        journeyData = JourneyData.builder()
                .journeyId("J123")
                .journeyName("GIFT")
                .build();

        message = SqsCustomerValidateMessage.builder()
                .payload(SqsCustomerValidatePayload.builder()
                        .journeyId("J123").build())
                .type(ValidatorType.POST_CUSTOMER_VALIDATION)
                .build();
    }

    private Map<String,Object> headerMap(int retry) {
        return Map.of(
                "MessageId", "MID123",
                "Sqs_Msa_ApproximateReceiveCount", retry
        );
    }

    @Test
    void test_successfulValidatorFlow_acknowledged() throws Exception {

        when(objectMapper.readValue(anyString(), eq(SqsCustomerValidateMessage.class)))
                .thenReturn(message);

        when(journeyService.fetchJourney("J123")).thenReturn(journeyData);

        Validator validator = mock(Validator.class);

        when(validatorsFactory.getValidators(eq("GIFT"), eq(ValidatorType.POST_CUSTOMER_VALIDATION)))
                .thenReturn(List.of(validator));

        when(validator.validate(any()))
                .thenReturn(Optional.of(ValidationResult.of(null, true)));

        when(validator.successState())
                .thenReturn(CommonJourneyStates.CUSTOMER_SIGNATURE_FETCH_SUCCESS);

        listener.sqsCustomerValidateListner(
                "{\"payload\":{\"journeyId\":\"J123\"}}",
                headerMap(1),
                acknowledgement
        );

        verify(acknowledgement).acknowledge();
        verify(journeyService).recordJourneyState("J123",
                CommonJourneyStates.CUSTOMER_SIGNATURE_FETCH_SUCCESS);
    }

    @Test
    void test_validatorFailure_nonMandatory() throws Exception {

        when(objectMapper.readValue(anyString(), eq(SqsCustomerValidateMessage.class)))
                .thenReturn(message);

        when(journeyService.fetchJourney("J123"))
                .thenReturn(journeyData);

        Validator validator = mock(Validator.class);

        when(validatorsFactory.getValidators(anyString(), any()))
                .thenReturn(List.of(validator));

        when(validator.validate(any()))
                .thenReturn(Optional.of(ValidationResult.of(new CustomValidationStatus(), false)));

        when(validator.failureState())
                .thenReturn(CommonJourneyStates.VALIDATORS_FAILURE);

        when(validator.isMandatory()).thenReturn(false);

        listener.sqsCustomerValidateListner(
                "{\"payload\":{\"journeyId\":\"J123\"}}",
                headerMap(1),
                acknowledgement
        );

        verify(journeyService).updateJourneyDetailDropOff(
                eq(journeyData),
                any(CustomValidationStatus.class),
                eq(CommonJourneyStates.VALIDATORS_FAILURE)
        );
    }

    @Test
    void test_validatorFailure_mandatory_breakFlow() throws Exception {

        when(objectMapper.readValue(anyString(), eq(SqsCustomerValidateMessage.class)))
                .thenReturn(message);
        when(journeyService.fetchJourney("J123")).thenReturn(journeyData);

        Validator validator = mock(Validator.class);

        when(validatorsFactory.getValidators(anyString(), any()))
                .thenReturn(List.of(validator));

        when(validator.validate(any()))
                .thenReturn(Optional.of(ValidationResult.of(new CustomValidationStatus(), false)));

        when(validator.failureState())
                .thenReturn(CommonJourneyStates.VALIDATORS_FAILURE);

        when(validator.isMandatory()).thenReturn(true);

        listener.sqsCustomerValidateListner(
                "{\"payload\":{\"journeyId\":\"J123\"}}",
                headerMap(1),
                acknowledgement
        );

        verify(journeyService).updateJourneyDetailDropOff(
                eq(journeyData), any(), eq(CommonJourneyStates.VALIDATORS_FAILURE));
        verify(validator, times(1)).validate(any());
    }

    @Test
    void test_retryExceeded_acknowledged_dropOff() throws Exception {

        when(objectMapper.readValue(anyString(), eq(SqsCustomerValidateMessage.class)))
                .thenReturn(message);

        when(journeyService.fetchJourney("J123")).thenReturn(journeyData);

        when(validatorsFactory.getValidators(anyString(), any()))
                .thenThrow(new RuntimeException("Simulated failure"));

        try (MockedStatic<DownstreamResponseHandler> mockStatic = mockStatic(DownstreamResponseHandler.class)) {

            CustomValidationStatus dummyStatus = new CustomValidationStatus();
            mockStatic.when(() ->
                            DownstreamResponseHandler.handleResponse(any(), any(), anyBoolean(), any()))
                    .thenReturn(dummyStatus);

            listener.sqsCustomerValidateListner(
                    "{\"payload\":{\"journeyId\":\"J123\"}}",
                    headerMap(5),
                    acknowledgement
            );
        }

        verify(acknowledgement).acknowledge();
        verify(journeyService).updateJourneyDetailDropOff(eq(journeyData), any(),
                eq(CommonJourneyStates.VALIDATORS_FAILURE));
    }

    @Test
    void test_signatureProcessing_uploadBothImages() throws Exception {

        when(objectMapper.readValue(anyString(), eq(SqsCustomerValidateMessage.class)))
                .thenReturn(message);

        when(journeyService.fetchJourney("J123")).thenReturn(journeyData);

        Validator validator = mock(Validator.class);

        when(validatorsFactory.getValidators(anyString(), any())).thenReturn(List.of(validator));

        byte[] sigBytes = "dummySig".getBytes();

        when(validator.validate(any())).thenAnswer(inv -> {
            ValidatorContext ctx = inv.getArgument(0);
            ctx.getData().put(ValidatorContext.ContextKey.CUSTOMER_SIGNATURE,
                    Base64.getEncoder().encodeToString(sigBytes));
            return Optional.of(ValidationResult.of(null, true));
        });

        when(validator.successState()).thenReturn(CommonJourneyStates.CUSTOMER_SIGNATURE_FETCH_SUCCESS);

        try (MockedStatic<ImageConverter> staticMock = mockStatic(ImageConverter.class)) {

            staticMock.when(() -> ImageConverter.isImageFormat(any(), eq(ImageFormat.TIF)))
                    .thenReturn(false);

            staticMock.when(() ->
                            ImageConverter.convertImage(any(), eq(ImageFormat.TIF), anyInt(), anyInt()))
                    .thenReturn("tiffConverted".getBytes());

            staticMock.when(() ->
                            ImageConverter.isImageFormat(any(), eq(ImageFormat.PNG)))
                    .thenReturn(true);

            DocumentUploadedResponse tifUpload = new DocumentUploadedResponse();
            tifUpload.setDocRef("TIF_REF");

            DocumentUploadedResponse pngUpload = new DocumentUploadedResponse();
            pngUpload.setDocRef("PNG_REF");

            ApiResponse<DocumentUploadedResponse> tifResponse = new ApiResponse<>();
            tifResponse.setData(tifUpload);

            ApiResponse<DocumentUploadedResponse> pngResponse = new ApiResponse<>();
            pngResponse.setData(pngUpload);

            when(documentFeignClient.uploadDocumentResponse(anyString(), any(), eq("")))
                    .thenReturn(tifResponse)
                    .thenReturn(pngResponse);

            listener.sqsCustomerValidateListner(
                    "{\"payload\":{\"journeyId\":\"J123\"}}",
                    headerMap(1),
                    acknowledgement
            );
        }

        verify(documentFeignClient, times(2))
                .uploadDocumentResponse(eq("GIFT"), any(), eq(""));

        verify(journeyService, times(2))
                .updateJourney(eq("J123"), anyString(), any(),
                        eq(CommonJourneyStates.CUSTOMER_SIGNATURE_FETCH_SUCCESS));

        verify(acknowledgement).acknowledge();
    }

    @Test
    void test_saveUcic_saveKyc_flow() throws Exception {

        when(objectMapper.readValue(anyString(), eq(SqsCustomerValidateMessage.class)))
                .thenReturn(message);

        when(journeyService.fetchJourney("J123"))
                .thenReturn(journeyData);

        Validator validator = mock(Validator.class);

        when(validatorsFactory.getValidators(eq("GIFT"), eq(ValidatorType.POST_CUSTOMER_VALIDATION)))
                .thenReturn(List.of(validator));

        when(validator.successState())
                .thenReturn(CommonJourneyStates.UCIC_ELIGIBLE_SUCCESS);

        when(validator.validate(any())).thenAnswer(inv -> {
            ValidatorContext ctx = inv.getArgument(0);
            ctx.getData().put(ValidatorContext.ContextKey.UCIC_DETAILS, "UCIC_DATA");
            ctx.getData().put(ValidatorContext.ContextKey.CKYC_DETAILS, "CKYC_DATA");
            return Optional.of(ValidationResult.of(null, true));
        });

        listener.sqsCustomerValidateListner(
                "{\"payload\":{\"journeyId\":\"J123\"}}",
                headerMap(1),
                acknowledgement
        );

        verify(journeyService).updateJourney(eq("J123"), eq("UCICDetails"),
                eq("UCIC_DATA"), eq(CommonJourneyStates.UCIC_ELIGIBLE_SUCCESS));

        verify(journeyService).updateJourney(eq("J123"), eq("CKYCDetails"),
                eq("CKYC_DATA"), eq(CommonJourneyStates.CUSTOMER_CKYC_FETCH_SUCCESS));

        verify(acknowledgement).acknowledge();
    }

    @Test
    void test_jsonParsingFailure() throws Exception {

        when(objectMapper.readValue(anyString(), eq(SqsCustomerValidateMessage.class)))
                .thenThrow(new JsonProcessingException("Invalid JSON") {});

        listener.sqsCustomerValidateListner(
                "INVALID_JSON",
                headerMap(1),
                acknowledgement
        );

        verify(acknowledgement, never()).acknowledge();
    }

    @Test
    void test_missingHeaders() throws Exception {

        Map<String,Object> headers = new HashMap<>();

        when(objectMapper.readValue(anyString(), eq(SqsCustomerValidateMessage.class)))
                .thenReturn(message);

        when(journeyService.fetchJourney("J123"))
                .thenReturn(journeyData);

        when(validatorsFactory.getValidators(anyString(), any()))
                .thenReturn(Collections.emptyList());

        listener.sqsCustomerValidateListner(
                "{\"payload\":{\"journeyId\":\"J123\"}}",
                headers,
                acknowledgement
        );

        verify(acknowledgement).acknowledge();
    }

    @Test
    void test_emptyValidatorsList() throws Exception {

        when(objectMapper.readValue(anyString(), eq(SqsCustomerValidateMessage.class)))
                .thenReturn(message);

        when(journeyService.fetchJourney("J123")).thenReturn(journeyData);

        when(validatorsFactory.getValidators(anyString(), any()))
                .thenReturn(Collections.emptyList());

        listener.sqsCustomerValidateListner(
                "{\"payload\":{\"journeyId\":\"J123\"}}",
                headerMap(1),
                acknowledgement
        );

        verify(acknowledgement).acknowledge();
    }

    @Test
    void test_validatorReturnsEmptyOptional() throws Exception {

        Validator validator = mock(Validator.class);

        when(objectMapper.readValue(anyString(), eq(SqsCustomerValidateMessage.class)))
                .thenReturn(message);

        when(journeyService.fetchJourney("J123")).thenReturn(journeyData);

        when(validatorsFactory.getValidators(anyString(), any()))
                .thenReturn(List.of(validator));

        when(validator.validate(any()))
                .thenReturn(Optional.empty());

        when(validator.name()).thenReturn(null);
        when(validator.type()).thenReturn(null);

        listener.sqsCustomerValidateListner(
                "{\"payload\":{\"journeyId\":\"J123\"}}",
                headerMap(1),
                acknowledgement
        );

        verify(acknowledgement).acknowledge();
    }

    @Test
    void test_signatureNotAvailable() throws Exception {

        Validator validator = mock(Validator.class);

        when(objectMapper.readValue(anyString(), eq(SqsCustomerValidateMessage.class)))
                .thenReturn(message);

        when(journeyService.fetchJourney("J123")).thenReturn(journeyData);

        when(validatorsFactory.getValidators(anyString(), any()))
                .thenReturn(List.of(validator));

        when(validator.validate(any()))
                .thenReturn(Optional.of(ValidationResult.of(null, true)));

        when(validator.successState())
                .thenReturn(CommonJourneyStates.CUSTOMER_SIGNATURE_FETCH_SUCCESS);

        listener.sqsCustomerValidateListner(
                "{\"payload\":{\"journeyId\":\"J123\"}}",
                headerMap(1),
                acknowledgement
        );

        verify(acknowledgement).acknowledge();
    }

    @Test
    void test_multipleValidatorsMandatoryStops() throws Exception {

        Validator v1 = mock(Validator.class);
        Validator v2 = mock(Validator.class);

        when(objectMapper.readValue(anyString(), eq(SqsCustomerValidateMessage.class)))
                .thenReturn(message);

        when(journeyService.fetchJourney("J123")).thenReturn(journeyData);

        when(validatorsFactory.getValidators(anyString(), any()))
                .thenReturn(List.of(v1, v2));

        when(v1.validate(any()))
                .thenReturn(Optional.of(ValidationResult.of(new CustomValidationStatus(), false)));

        when(v1.failureState()).thenReturn(CommonJourneyStates.VALIDATORS_FAILURE);
        when(v1.isMandatory()).thenReturn(true);

        listener.sqsCustomerValidateListner(
                "{\"payload\":{\"journeyId\":\"J123\"}}",
                headerMap(1),
                acknowledgement
        );

        verify(journeyService).updateJourneyDetailDropOff(eq(journeyData), any(),
                eq(CommonJourneyStates.VALIDATORS_FAILURE));

        verify(v2, never()).validate(any());
    }
}