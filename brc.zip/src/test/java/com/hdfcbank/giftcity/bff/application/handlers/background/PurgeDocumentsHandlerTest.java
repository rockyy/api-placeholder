package com.hdfcbank.giftcity.bff.application.handlers.background;

import com.hdfcbank.adapters.clients.feign.document.DocumentFeignClient;
import com.hdfcbank.adapters.vo.DeleteDocumentRequest;
import com.hdfcbank.adapters.vo.DeleteDocumentResponse;
import com.hdfcbank.common.models.vo.core.ApiResponse;
import com.hdfcbank.common.models.vo.core.ApiResponseStatus;
import com.hdfcbank.common.models.vo.journey.JourneyData;
import com.hdfcbank.common.models.vo.journey.JourneyDetail;
import com.hdfcbank.common.models.vo.journey.JourneyState;
import com.hdfcbank.giftcity.bff.commons.enums.CommonJourneyStates;
import com.hdfcbank.giftcity.bff.commons.enums.JourneyPageName;
import com.hdfcbank.giftcity.bff.commons.handler.Handler;
import com.hdfcbank.giftcity.bff.commons.handler.HandlerContext;
import com.hdfcbank.giftcity.bff.commons.handler.HandlerResult;
import com.hdfcbank.giftcity.bff.commons.model.FtsDetails;
import com.hdfcbank.giftcity.bff.infrastructure.service.JourneyService;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class PurgeDocumentsHandlerTest {

    @Mock
    private DocumentFeignClient feign;

    @InjectMocks
    private PurgeDocumentsHandler handler;

    private JourneyData journeyData;
    private HandlerContext ctx;

    private static final String PAGE = JourneyPageName.FTS_DETAILS.getPageName();

    @BeforeEach
    void setup() {
        JourneyDetail detail = new JourneyDetail();

        detail.setSystemData(new HashMap<>());
        detail.setJourneyStates(
                List.of(JourneyState.builder().stateName("READY").build())
        );

        journeyData = new JourneyData();
        journeyData.setJourneyId("J001");
        journeyData.setJourneyName("GiftJourney");
        journeyData.setJourneyDetail(detail);

        ctx = HandlerContext.builder()
                .journeyData(journeyData)
                .data(new HashMap<>())
                .properties(new HashMap<>())
                .build();
    }

    @Test
    void testPreConditions() {
        assertTrue(handler.preConditions(ctx));
    }

    @Test
    void testHandle_OuterException() {
        try (MockedStatic<JourneyService> mock = mockStatic(JourneyService.class)) {

            // Critical: Force handler to skip entire deletion logic
            mock.when(() -> JourneyService.extractFromJourney(any(), eq(PAGE), eq(FtsDetails.class)))
                    .thenReturn(Optional.empty());

            HandlerResult<DeleteDocumentResponse> result = handler.handle(ctx);

            // Expected output for outer-exception case
            assertFalse(result.isSuccess());
            assertNull(result.getResult());
        }
    }

    @Test
    void testGetName() {
        assertEquals(Handler.HandlerName.PURGE_DOCUMENTS, handler.getName());
    }

    @Test
    void testGetType() {
        assertEquals(Handler.HandlerType.BACKGROUND_TASKS_POST_SUBMIT_SUCCESS, handler.getType());
    }

    @Test
    void testSuccessState() {
        assertEquals(CommonJourneyStates.PURGE_DOCUMENTS_SUCCESS, handler.successState());
    }

    @Test
    void testFailureState() {
        assertEquals(CommonJourneyStates.PURGE_DOCUMENTS_FAILURE, handler.failureState());
    }
}