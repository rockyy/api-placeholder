package com.hdfcbank.giftcity.bff.application.handlers.background;

import com.hdfcbank.adapters.clients.feign.communication.CommunicationFeignClient;
import com.hdfcbank.adapters.vo.AlertMessageResponse;
import com.hdfcbank.adapters.vo.SendMessageRequest;
import com.hdfcbank.common.models.vo.core.ApiResponseStatus;
import com.hdfcbank.common.models.vo.journey.JourneyData;
import com.hdfcbank.common.models.vo.journey.JourneyDetail;
import com.hdfcbank.common.models.vo.journey.Profile;
import com.hdfcbank.giftcity.bff.commons.enums.CommonJourneyStates;
import com.hdfcbank.giftcity.bff.commons.exception.handler.DownstreamResponseHandler;
import com.hdfcbank.giftcity.bff.commons.handler.Handler;
import com.hdfcbank.giftcity.bff.commons.handler.HandlerContext;
import com.hdfcbank.giftcity.bff.commons.handler.HandlerResult;
import com.hdfcbank.giftcity.bff.commons.model.CustomValidationStatus;
import com.hdfcbank.giftcity.bff.customer.config.CustomerApiProperties;
import com.hdfcbank.giftcity.bff.customer.utility.CustomerUtil;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.*;

import static com.hdfcbank.giftcity.bff.commons.constant.CommonConstants.SMS_TEMPLATE;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class FtsRejectedAccountSmsHandlerTest {

    @Mock
    private CommunicationFeignClient communicationFeignClient;

    @Mock
    private CustomerApiProperties customerApiProperties;

    @InjectMocks
    private FtsRejectedAccountSmsHandler handler;

    private JourneyData journeyData;
    private HandlerContext ctx;

    @BeforeEach
    void setup() {

        JourneyDetail detail = JourneyDetail.builder().build();
        detail.setJourneyStates(new ArrayList<>());
        detail.setSystemData(new HashMap<>());

        Profile profile = Profile.builder()
                .emailId("cust@test.com")
                .build();

        journeyData = JourneyData.builder()
                .journeyId("J123")
                .journeyDetail(detail)
                .profile(profile)
                .isd("+91")
                .mobileNumber("9876543210")
                .journeyName("GIFT_CITY")
                .build();

        Map<String,Object> props = new HashMap<>();
        props.put(SMS_TEMPLATE, "SMS_TEMP_1");

        ctx = HandlerContext.builder()
                .journeyData(journeyData)
                .properties(props)
                .build();
    }

    // ---------------------------------------------------------------------------
    // preConditions() always true
    // ---------------------------------------------------------------------------
    @Test
    void preConditions_shouldAlwaysReturnTrue() {
        assertTrue(handler.preConditions(ctx));
    }

    // ---------------------------------------------------------------------------
    // SUCCESS PATH
    // ---------------------------------------------------------------------------
    @Test
    void handle_shouldReturnSuccess_whenResponseCodeIs0000() {

        SendMessageRequest sanitizedReq = SendMessageRequest.builder()
                .messageType("SMS")
                .channel("SMS")
                .mobileNumber("+919876543210")
                .templateId("SMS_TEMP_1")
                .customerName("John Doe")
                .emailId("cust@test.com")
                .targetSystem("AXIOM")
                .build();

        try (MockedStatic<CustomerUtil> custMock = Mockito.mockStatic(CustomerUtil.class)) {

            custMock.when(() -> CustomerUtil.sanitizeSendMessageRequest(any(), anyString()))
                    .thenReturn(sanitizedReq);

            AlertMessageResponse.ResponseMsg data =
                    AlertMessageResponse.ResponseMsg.builder().success(true).build();

            AlertMessageResponse resp = AlertMessageResponse.builder()
                    .status(ApiResponseStatus.success())
                    .data(data)
                    .build();

            when(communicationFeignClient.sendAlertMsg(eq(sanitizedReq), eq("J123")))
                    .thenReturn(resp);

            HandlerResult<AlertMessageResponse> result = handler.handle(ctx);

            assertTrue(result.isSuccess());
            assertNotNull(result.getResult());
        }
    }

    // ---------------------------------------------------------------------------
    // FAILURE PATH — response null
    // ---------------------------------------------------------------------------
    @Test
    void handle_shouldFail_whenResponseIsNull() {

        try (MockedStatic<CustomerUtil> custMock = Mockito.mockStatic(CustomerUtil.class)) {

            custMock.when(() -> CustomerUtil.sanitizeSendMessageRequest(any(), anyString()))
                    .thenReturn(SendMessageRequest.builder().build());

            when(communicationFeignClient.sendAlertMsg(any(), eq("J123")))
                    .thenReturn(null);

            try (MockedStatic<DownstreamResponseHandler> dsMock =
                         Mockito.mockStatic(DownstreamResponseHandler.class)) {

                dsMock.when(
                        () -> DownstreamResponseHandler.handleResponse(
                                eq(null), anyString(), anyBoolean(), anyString()
                        )
                ).thenReturn(CustomValidationStatus.builder()
                        .code("ERR_NULL")
                        .message("Null response")
                        .build());

                HandlerResult<AlertMessageResponse> result = handler.handle(ctx);

                assertFalse(result.isSuccess());
                assertNull(result.getResult());
            }
        }
    }

    // ---------------------------------------------------------------------------
    // FAILURE PATH — status null
    // ---------------------------------------------------------------------------
    @Test
    void handle_shouldFail_whenStatusIsNull() {

        try (MockedStatic<CustomerUtil> custMock = Mockito.mockStatic(CustomerUtil.class)) {

            custMock.when(() -> CustomerUtil.sanitizeSendMessageRequest(any(), anyString()))
                    .thenReturn(SendMessageRequest.builder().build());

            AlertMessageResponse resp = AlertMessageResponse.builder()
                    .status(null)
                    .data(null)
                    .build();

            when(communicationFeignClient.sendAlertMsg(any(), eq("J123")))
                    .thenReturn(resp);

            try (MockedStatic<DownstreamResponseHandler> dsMock =
                         Mockito.mockStatic(DownstreamResponseHandler.class)) {

                dsMock.when(
                        () -> DownstreamResponseHandler.handleResponse(
                                any(), anyString(), anyBoolean(), anyString()
                        )
                ).thenReturn(CustomValidationStatus.builder()
                        .code("ERR_STATUS_NULL")
                        .message("Missing status")
                        .build());

                HandlerResult<AlertMessageResponse> result = handler.handle(ctx);

                assertFalse(result.isSuccess());
            }
        }
    }

    // ---------------------------------------------------------------------------
    // FAILURE PATH — non-success code
    // ---------------------------------------------------------------------------
    @Test
    void handle_shouldFail_whenStatusCodeNot0000() {

        try (MockedStatic<CustomerUtil> custMock = Mockito.mockStatic(CustomerUtil.class)) {

            custMock.when(() -> CustomerUtil.sanitizeSendMessageRequest(any(), anyString()))
                    .thenReturn(SendMessageRequest.builder().build());

            AlertMessageResponse resp = AlertMessageResponse.builder()
                    .status(ApiResponseStatus.downstreamApiError(null))
                    .data(null)
                    .build();

            when(communicationFeignClient.sendAlertMsg(any(), eq("J123")))
                    .thenReturn(resp);

            try (MockedStatic<DownstreamResponseHandler> dsMock =
                         Mockito.mockStatic(DownstreamResponseHandler.class)) {

                dsMock.when(
                        () -> DownstreamResponseHandler.handleResponse(
                                any(), anyString(), anyBoolean(), anyString()
                        )
                ).thenReturn(CustomValidationStatus.builder()
                        .code("DOWNSTREAM_FAIL")
                        .message("Error from downstream")
                        .build());

                HandlerResult<AlertMessageResponse> result = handler.handle(ctx);

                assertFalse(result.isSuccess());
            }
        }
    }

    // ---------------------------------------------------------------------------
    // EXCEPTION PATH
    // ---------------------------------------------------------------------------
    @Test
    void handle_shouldCatchException_whenExceptionThrown() {

        try (MockedStatic<CustomerUtil> custMock = Mockito.mockStatic(CustomerUtil.class)) {

            custMock.when(() -> CustomerUtil.sanitizeSendMessageRequest(any(), anyString()))
                    .thenThrow(new RuntimeException("Boom"));

            try (MockedStatic<DownstreamResponseHandler> dsMock =
                         Mockito.mockStatic(DownstreamResponseHandler.class)) {

                dsMock.when(
                        () -> DownstreamResponseHandler.handleResponse(
                                eq(null), anyString(), anyBoolean(), anyString()
                        )
                ).thenReturn(CustomValidationStatus.builder()
                        .code("ERR_EXCEPTION")
                        .message("Exception handled")
                        .build());

                HandlerResult<AlertMessageResponse> result = handler.handle(ctx);

                assertFalse(result.isSuccess());
                assertNull(result.getResult());
            }
        }
    }

    // ---------------------------------------------------------------------------
    // ENUM COVERAGE
    // ---------------------------------------------------------------------------
    @Test
    void enumCoverage() {
        assertEquals(CommonJourneyStates.FTS_REJECT_CALLBACK_SMS_ALERT_SUCCESS, handler.successState());
        assertEquals(CommonJourneyStates.FTS_REJECT_CALLBACK_SMS_ALERT_FAILURE, handler.failureState());
        assertEquals(Handler.HandlerType.BACKGROUND_TASKS_POST_SUBMIT_SUCCESS, handler.getType());
        assertEquals(Handler.HandlerName.FTS_REJECT_CALLBACK_SMS, handler.getName());
    }
}