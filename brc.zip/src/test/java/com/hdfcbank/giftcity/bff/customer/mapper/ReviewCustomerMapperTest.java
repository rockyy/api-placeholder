package com.hdfcbank.giftcity.bff.customer.mapper;

import com.hdfcbank.common.models.vo.journey.JourneyData;
import com.hdfcbank.giftcity.bff.commons.enums.JourneyPageName;
import com.hdfcbank.giftcity.bff.commons.model.FcIndiaProfile;
import com.hdfcbank.giftcity.bff.commons.utility.CommonUtil;
import com.hdfcbank.giftcity.bff.customer.model.CustomerDetails;
import com.hdfcbank.giftcity.bff.customer.model.ReviewCustomerResponse;
import com.hdfcbank.giftcity.bff.customer.utility.CustomerUtil;
import com.hdfcbank.giftcity.bff.infrastructure.service.JourneyService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mapstruct.factory.Mappers;
import org.mockito.MockedStatic;
import org.mockito.Mockito;

import java.util.*;

import static org.junit.jupiter.api.Assertions.*;

class ReviewCustomerMapperTest {

    private ReviewCustomerMapper mapper;

    @BeforeEach
    void setup() {
        mapper = Mappers.getMapper(ReviewCustomerMapper.class);
    }

    private JourneyData jd() {
        JourneyData jd = new JourneyData();
        jd.setJourneyDetail(new com.hdfcbank.common.models.vo.journey.JourneyDetail());
        return jd;
    }

    // TEST mapEmployment

    @Test
    void test_mapEmployment_success() {
        Map<String, Object> input = new HashMap<>();
        Map<String, Object> empMap = Map.of("occupation", "ENGINEER");
        input.put("employment", empMap);

        CustomerDetails.EmploymentFinancial ef =
                CustomerDetails.EmploymentFinancial.builder()
                        .occupation("ENGINEER")
                        .build();

        try (MockedStatic<CustomerUtil> util = Mockito.mockStatic(CustomerUtil.class)) {
            util.when(() -> CustomerUtil.convert(empMap, CustomerDetails.EmploymentFinancial.class))
                    .thenReturn(ef);

            CustomerDetails.EmploymentFinancial out = mapper.mapEmployment(input);

            assertNotNull(out);
            assertEquals("ENGINEER", out.getOccupation());
        }
    }

    @Test
    void test_mapEmployment_nullInput() {
        assertNull(mapper.mapEmployment(null));
    }

    @Test
    void test_mapEmployment_emptyInput() {
        assertNull(mapper.mapEmployment(Collections.emptyMap()));
    }


    // TEST mapFinancialProducts

    @Test
    void test_mapFinancialProducts_success() {
        Map<String, Object> input = new HashMap<>();
        Map<String, Object> fpMap = Map.of("products", List.of("A", "B"));
        input.put("financialProducts", fpMap);

        CustomerDetails.FinancialProducts fp =
                CustomerDetails.FinancialProducts.builder()
                        .products(List.of("A", "B"))
                        .build();

        try (MockedStatic<CustomerUtil> util = Mockito.mockStatic(CustomerUtil.class)) {
            util.when(() -> CustomerUtil.convert(fpMap, CustomerDetails.FinancialProducts.class))
                    .thenReturn(fp);

            CustomerDetails.FinancialProducts out = mapper.mapFinancialProducts(input);

            assertNotNull(out);
            assertEquals(List.of("A", "B"), out.getProducts());
        }
    }

    @Test
    void test_mapFinancialProducts_emptyInput() {
        assertNull(mapper.mapFinancialProducts(Collections.emptyMap()));
    }


    // TEST mapFatca

    @Test
    void test_mapFatca_success() {
        Map<String, Object> input = new HashMap<>();
        Map<String, Object> fatcaMap = Map.of("nationality", "IN");
        input.put("fatca", fatcaMap);

        CustomerDetails.FatcaDetails fd =
                CustomerDetails.FatcaDetails.builder()
                        .nationality("IN")
                        .build();

        try (MockedStatic<CustomerUtil> util = Mockito.mockStatic(CustomerUtil.class)) {

            util.when(() -> CustomerUtil.convert(fatcaMap, CustomerDetails.FatcaDetails.class))
                    .thenReturn(fd);

            CustomerDetails.FatcaDetails out = mapper.mapFatca(input);

            assertNotNull(out);
            assertEquals("IN", out.getNationality());
        }
    }

    @Test
    void test_mapFatca_emptyInput() {
        assertNull(mapper.mapFatca(Collections.emptyMap()));
    }


    // TEST maskTaxResidency (@Named)

    @Test
    void test_maskTaxResidency_success() {
        CustomerDetails.TaxResidency tr =
                CustomerDetails.TaxResidency.builder()
                        .countryOfTaxResidency("IN")
                        .taxIdType("TIN")
                        .taxIdNumber("ABCDEFGH1234")
                        .build();

        try (MockedStatic<CommonUtil> util = Mockito.mockStatic(CommonUtil.class)) {
            util.when(() -> CommonUtil.mask("ABCDEFGH1234", 4))
                    .thenReturn("********1234");

            CustomerDetails.TaxResidency out = mapper.maskTaxResidency(tr);

            assertNotNull(out);
            assertEquals("IN", out.getCountryOfTaxResidency());
            assertEquals("TIN", out.getTaxIdType());
            assertEquals("********1234", out.getTaxIdNumber());
        }
    }

    @Test
    void test_maskTaxResidency_null() {
        assertNull(mapper.maskTaxResidency(null));
    }


    // TEST mergeFatcaDetails — all mappings covered

    @Test
    void test_mergeFatcaDetails_success() {

        CustomerDetails.MaritalStatus marital =
                CustomerDetails.MaritalStatus.builder()
                        .status("Married")
                        .build();

        CustomerDetails.ResidentialType res =
                CustomerDetails.ResidentialType.builder()
                        .type("Owned")
                        .build();

        CustomerDetails.FatcaDetails existing =
                CustomerDetails.FatcaDetails.builder()
                        .maritalStatus(marital)
                        .spouseName("SpouseA")
                        .residenceType(res)
                        .build();

        CustomerDetails.TaxResidency tr =
                CustomerDetails.TaxResidency.builder()
                        .taxIdNumber("AAAA1111BBBB")
                        .countryOfTaxResidency("IN")
                        .taxIdType("TIN")
                        .build();

        CustomerDetails.FatcaDetails incoming =
                CustomerDetails.FatcaDetails.builder()
                        .nationality("INDIAN")
                        .fatherName("Father")
                        .motherName("Mother")
                        .addressForTaxPurpose("ADDR")
                        .placeOfBirth("CITY")
                        .countryOfBirth("IN")
                        .taxResidency(tr)
                        .build();

        try (MockedStatic<CommonUtil> util = Mockito.mockStatic(CommonUtil.class)) {

            util.when(() -> CommonUtil.mask("AAAA1111BBBB", 4))
                    .thenReturn("********BBBB");

            CustomerDetails.FatcaDetails out =
                    mapper.mergeFatcaDetails(existing, incoming);

            assertEquals("INDIAN", out.getNationality());
            assertEquals("Father", out.getFatherName());
            assertEquals("Mother", out.getMotherName());
            assertEquals("CITY", out.getPlaceOfBirth());
            assertEquals("IN", out.getCountryOfBirth());
            assertEquals("********BBBB", out.getTaxResidency().getTaxIdNumber());

            assertEquals("Married", out.getMaritalStatus().getStatus());
            assertEquals("SpouseA", out.getSpouseName());
            assertEquals("Owned", out.getResidenceType().getType());
        }
    }


    // TEST isEmpty

    @Test
    void test_isEmpty() {
        assertTrue(mapper.isEmpty(null));
        assertTrue(mapper.isEmpty(Collections.emptyMap()));
        assertFalse(mapper.isEmpty(Map.of("A", 1)));
    }


    // TEST mapNomineeFromPage — FULL BRANCH COVERAGE

    @Test
    void test_mapNomineeFromPage_fullGuardianMerge() {

        JourneyData jd = jd();

        Map<String, Object> nomineeInputs = new HashMap<>();
        Map<String, Object> nomineeDetailMap = new HashMap<>();

        Map<String, Object> nomineeMap = new HashMap<>();
        nomineeMap.put("addressLine1", "N1");
        nomineeMap.put("addressLine2", "N2");
        nomineeMap.put("addressLine3", "N3");
        nomineeMap.put("addressLine4", "N4");
        nomineeMap.put("city", "City");
        nomineeMap.put("state", "State");
        nomineeMap.put("country", "Country");
        nomineeMap.put("pincode", "110011");
        nomineeMap.put("maskedPermanentAddress", "MASKED");

        Map<String, Object> guardianMap = new HashMap<>();
        guardianMap.put("addressSameAsNominee", true);

        nomineeDetailMap.put("nominee", nomineeMap);
        nomineeDetailMap.put("guardian", guardianMap);

        nomineeInputs.put("nomineeDetail", nomineeDetailMap);

        ReviewCustomerResponse.ReviewCustomerDetails.Nominee nominee =
                ReviewCustomerResponse.ReviewCustomerDetails.Nominee.builder()
                        .addressLine1("N1")
                        .addressLine2("N2")
                        .addressLine3("N3")
                        .addressLine4("N4")
                        .city("City")
                        .state("State")
                        .country("Country")
                        .pincode("110011")
                        .maskedPermanentAddress("MASKED")
                        .build();

        ReviewCustomerResponse.ReviewCustomerDetails.Nominee guardian =
                ReviewCustomerResponse.ReviewCustomerDetails.Nominee.builder()
                        .addressSameAsNominee(true)
                        .build();

        ReviewCustomerResponse.ReviewCustomerDetails.NomineeDetail converted =
                new ReviewCustomerResponse.ReviewCustomerDetails.NomineeDetail();
        converted.setNominee(nominee);
        converted.setGuardian(guardian);

        FcIndiaProfile.Profile profile = new FcIndiaProfile.Profile();

        try (MockedStatic<CustomerUtil> util = Mockito.mockStatic(CustomerUtil.class);
             MockedStatic<JourneyService> js = Mockito.mockStatic(JourneyService.class)) {

            // convert() mock
            util.when(() -> CustomerUtil.convert(
                    nomineeDetailMap,
                    ReviewCustomerResponse.ReviewCustomerDetails.NomineeDetail.class
            )).thenReturn(converted);

            // extractFromJourney mock
            js.when(() -> JourneyService.extractFromJourney(
                    Mockito.eq(jd),
                    Mockito.eq(JourneyPageName.CUSTOMER_FC_INDIA_DETAIL.getPageName()),
                    Mockito.eq(FcIndiaProfile.class),
                    Mockito.any()
            )).thenReturn(Optional.of(profile));

            // nomineeFromProfile mock
            util.when(() -> CustomerUtil.getNomineeFromProfile(nominee, profile))
                    .thenReturn(nominee);

            ReviewCustomerResponse.ReviewCustomerDetails.NomineeDetail out =
                    mapper.mapNomineeFromPage(nomineeInputs, jd);

            assertNotNull(out);
            assertEquals("N1", out.getGuardian().getAddressLine1());
            assertEquals("MASKED", out.getGuardian().getMaskedPermanentAddress());
        }
    }

    @Test
    void test_mapNomineeFromPage_emptyMap() {
        assertNull(mapper.mapNomineeFromPage(Collections.emptyMap(), jd()));
    }

    @Test
    void test_mapNomineeFromPage_nullNomineeDetailKey() {
        Map<String, Object> input = Map.of("wrongKey", 123);
        assertNull(mapper.mapNomineeFromPage(input, jd()));
    }

    @Test
    void test_mapNomineeFromPage_convertReturnsNull() {
        Map<String, Object> input = new HashMap<>();
        input.put("nomineeDetail", new Object());

        try (MockedStatic<CustomerUtil> util = Mockito.mockStatic(CustomerUtil.class)) {
            util.when(() -> CustomerUtil.convert(
                            Mockito.any(),
                            Mockito.eq(ReviewCustomerResponse.ReviewCustomerDetails.NomineeDetail.class)))
                    .thenReturn(null);

            assertNull(mapper.mapNomineeFromPage(input, jd()));
        }
    }

    @Test
    void test_mapNomineeFromPage_profileNull() {
        JourneyData jd = jd();

        Map<String, Object> nomineeInputs = new HashMap<>();
        Map<String, Object> nomineeDetailMap = Map.of("nominee", new HashMap<>());
        nomineeInputs.put("nomineeDetail", nomineeDetailMap);

        ReviewCustomerResponse.ReviewCustomerDetails.NomineeDetail converted =
                new ReviewCustomerResponse.ReviewCustomerDetails.NomineeDetail();
        converted.setNominee(new ReviewCustomerResponse.ReviewCustomerDetails.Nominee());
        converted.setGuardian(null);

        try (MockedStatic<CustomerUtil> util = Mockito.mockStatic(CustomerUtil.class);
             MockedStatic<JourneyService> js = Mockito.mockStatic(JourneyService.class)) {

            util.when(() -> CustomerUtil.convert(
                            nomineeDetailMap,
                            ReviewCustomerResponse.ReviewCustomerDetails.NomineeDetail.class))
                    .thenReturn(converted);

            js.when(() -> JourneyService.extractFromJourney(
                    Mockito.any(),
                    Mockito.anyString(),
                    Mockito.eq(FcIndiaProfile.class),
                    Mockito.any()
            )).thenReturn(Optional.empty());

            ReviewCustomerResponse.ReviewCustomerDetails.NomineeDetail out =
                    mapper.mapNomineeFromPage(nomineeInputs, jd);

            assertSame(converted, out);
        }
    }
}