package com.hdfcbank.giftcity.bff.commons.handler;

import com.hdfcbank.common.models.vo.journey.JourneyData;
import com.hdfcbank.common.models.vo.journey.JourneyDetail;
import com.hdfcbank.common.models.vo.journey.JourneyState;
import com.hdfcbank.giftcity.bff.commons.enums.CommonJourneyStates;
import org.junit.jupiter.api.Test;

import java.util.*;

import static org.junit.jupiter.api.Assertions.*;

class HandlerTest {

    // Concrete anonymous handler to test default methods
    private final Handler<String> handler = new Handler<>() {
        @Override
        public boolean preConditions(HandlerContext handlerContext) { return true; }

        @Override
        public HandlerResult<String> handle(HandlerContext handlerContext) {
            return HandlerResult.of(null, "OK", true);
        }

        @Override
        public HandlerType getType() { return HandlerType.CUSTOMER_POST_SUBMIT; }

        @Override
        public HandlerName getName() { return HandlerName.CREATE_CUSTOMER; }

        @Override
        public CommonJourneyStates successState() {
            return CommonJourneyStates.values()[0]; // any valid enum constant
        }

        @Override
        public CommonJourneyStates failureState() {
            return CommonJourneyStates.values()[0];
        }
    };

    // hasJourneyState: journeyData = null → false
    @Test
    void testHasJourneyStateWhenJourneyDataIsNull() {
        HandlerContext context = HandlerContext.builder()
                .journeyData(null)
                .data(new HashMap<>())
                .properties(new HashMap<>())
                .build();

        assertFalse(handler.hasJourneyState(context, "STATE1"));
    }

    // hasJourneyState: journeyDetail = null → false
    @Test
    void testHasJourneyStateWhenJourneyDetailIsNull() {
        JourneyData jd = new JourneyData();
        jd.setJourneyDetail(null);

        HandlerContext context = HandlerContext.builder()
                .journeyData(jd)
                .data(new HashMap<>())
                .properties(new HashMap<>())
                .build();

        assertFalse(handler.hasJourneyState(context, "STATE1"));
    }

    // hasJourneyState: list empty → false
    @Test
    void testHasJourneyStateEmptyList() {
        JourneyDetail detail = new JourneyDetail();
        detail.setJourneyStates(Collections.emptyList());

        JourneyData jd = new JourneyData();
        jd.setJourneyDetail(detail);

        HandlerContext context = HandlerContext.builder()
                .journeyData(jd)
                .data(new HashMap<>())
                .properties(new HashMap<>())
                .build();

        assertFalse(handler.hasJourneyState(context, "STATE1"));
    }

    // hasJourneyState: match found → true
    @Test
    void testHasJourneyStateReturnsTrue() {
        JourneyState state = new JourneyState();
        state.setStateName("STATE1");

        JourneyDetail detail = new JourneyDetail();
        detail.setJourneyStates(List.of(state));

        JourneyData jd = new JourneyData();
        jd.setJourneyDetail(detail);

        HandlerContext context = HandlerContext.builder()
                .journeyData(jd)
                .data(new HashMap<>())
                .properties(new HashMap<>())
                .build();

        assertTrue(handler.hasJourneyState(context, "STATE1"));
    }

    // hasJourneyState: no match → false
    @Test
    void testHasJourneyStateReturnsFalse() {
        JourneyState state = new JourneyState();
        state.setStateName("ABC");

        JourneyDetail detail = new JourneyDetail();
        detail.setJourneyStates(List.of(state));

        JourneyData jd = new JourneyData();
        jd.setJourneyDetail(detail);

        HandlerContext context = HandlerContext.builder()
                .journeyData(jd)
                .data(new HashMap<>())
                .properties(new HashMap<>())
                .build();

        assertFalse(handler.hasJourneyState(context, "STATE1"));
    }

    // isSuccess: no entry → false
    @Test
    void testIsSuccessNoEntry() {
        HandlerContext context = HandlerContext.builder()
                .journeyData(null)
                .data(new HashMap<>())
                .properties(new HashMap<>())
                .build();

        assertFalse(handler.isSuccess(context, Handler.HandlerName.CREATE_ACCOUNT));
    }

    // isSuccess: non‑HandlerResult object → false
    @Test
    void testIsSuccessNonHandlerResult() {
        Map<Handler.HandlerName, Object> map = new HashMap<>();
        map.put(Handler.HandlerName.CREATE_ACCOUNT, "NOT_RESULT");

        HandlerContext context = HandlerContext.builder()
                .journeyData(null)
                .data(map)
                .properties(new HashMap<>())
                .build();

        assertFalse(handler.isSuccess(context, Handler.HandlerName.CREATE_ACCOUNT));
    }

    // isSuccess: HandlerResult.success = true → true
    @Test
    void testIsSuccessTrue() {
        HandlerResult<String> result = HandlerResult.of(null, "OK", true);

        Map<Handler.HandlerName, Object> map = new HashMap<>();
        map.put(Handler.HandlerName.CREATE_ACCOUNT, result);

        HandlerContext context = HandlerContext.builder()
                .journeyData(null)
                .data(map)
                .properties(new HashMap<>())
                .build();

        assertTrue(handler.isSuccess(context, Handler.HandlerName.CREATE_ACCOUNT));
    }

    // getResult: no entry → null
    @Test
    void testGetResultNoEntry() {
        HandlerContext context = HandlerContext.builder()
                .journeyData(null)
                .data(new HashMap<>())
                .properties(new HashMap<>())
                .build();

        assertNull(handler.getResult(context, Handler.HandlerName.CREATE_CUSTOMER, String.class));
    }

    // getResult: non‑HandlerResult object → null
    @Test
    void testGetResultNonHandlerResult() {
        Map<Handler.HandlerName, Object> map = new HashMap<>();
        map.put(Handler.HandlerName.CREATE_CUSTOMER, 123);

        HandlerContext context = HandlerContext.builder()
                .journeyData(null)
                .data(map)
                .properties(new HashMap<>())
                .build();

        assertNull(handler.getResult(context, Handler.HandlerName.CREATE_CUSTOMER, String.class));
    }

    // getResult: wrong type → null
    @Test
    void testGetResultWrongType() {
        HandlerResult<Integer> result = HandlerResult.of(null, 123, true);

        Map<Handler.HandlerName, Object> map = new HashMap<>();
        map.put(Handler.HandlerName.CREATE_CUSTOMER, result);

        HandlerContext context = HandlerContext.builder()
                .journeyData(null)
                .data(map)
                .properties(new HashMap<>())
                .build();

        assertNull(handler.getResult(context, Handler.HandlerName.CREATE_CUSTOMER, String.class));
    }

    // getResult: correct type → returns value
    @Test
    void testGetResultCorrectType() {
        HandlerResult<String> result = HandlerResult.of(null, "RESULT123", true);

        Map<Handler.HandlerName, Object> map = new HashMap<>();
        map.put(Handler.HandlerName.CREATE_CUSTOMER, result);

        HandlerContext context = HandlerContext.builder()
                .journeyData(null)
                .data(map)
                .properties(new HashMap<>())
                .build();

        String res = handler.getResult(context, Handler.HandlerName.CREATE_CUSTOMER, String.class);
        assertEquals("RESULT123", res);
    }
}
