package com.hdfcbank.giftcity.bff.commons.exception.handler;

import com.hdfcbank.common.models.vo.core.ApiResponse;
import com.hdfcbank.common.models.vo.core.ErrorRef;
import com.hdfcbank.exception.CoolOffLimitExceededException;
import com.hdfcbank.giftcity.bff.commons.enums.CustomCommonApiStatusCodes;
import com.hdfcbank.giftcity.bff.commons.exception.*;
import com.hdfcbank.giftcity.bff.commons.model.InspireApiResponse;
import com.hdfcbank.service.adapters.commons.exception.CustomValidationAdapterException;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.http.ResponseEntity;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class CustomerExceptionHandlerTest {

    private CustomerExceptionHandler handler;

    @BeforeEach
    void init() {
        handler = Mockito.spy(new CustomerExceptionHandler());

        //        COMPLETELY MUTE ALL LOGGING (NO error logs printed)
        doNothing().when(handler).logException(anyString(), any());
        doNothing().when(handler).logException(any());
        doNothing().when(handler).logThrowable(anyString(), any());
        doNothing().when(handler).logThrowable(any());
    }

           
    //        LOGGING TESTS
           

    @Test
    void test_logException_withSource() {
        Exception ex = new Exception("test");
        handler.logException("SRC", ex); // muted
    }

    @Test
    void test_logThrowable_withSource() {
        Throwable ex = new Throwable("boom");
        handler.logThrowable("SRC", ex); // muted
    }

    @Test
    void test_logException_simple() {
        Exception ex = new Exception("simple");
        handler.logException(ex); // muted
    }

    @Test
    void test_logThrowable_simple() {
        Throwable ex = new Throwable("simple");
        handler.logThrowable(ex); // muted
    }

           
    //        LimitExceededException handler
           

    @Test
    void test_handleRetryLimitExceeded() {

        LimitExceededException ex =
                new LimitExceededException("limit exceeded",
                        CustomCommonApiStatusCodes.CUSTOM_VALIDATION_EXCEPTION);

        ResponseEntity<ApiResponse<?>> entity = handler.handleRetryLimitExceeded(ex);

        assertEquals(200, entity.getStatusCode().value());
        assertEquals(
                CustomCommonApiStatusCodes.CUSTOM_VALIDATION_EXCEPTION.getCode(),
                entity.getBody().getStatus().getCode()
        );
    }

           
    //        CustomValidationException handler
           

    @Test
    void test_handleCustomValidationException() {

        CustomValidationException ex = new CustomValidationException(
                CustomCommonApiStatusCodes.CUSTOM_VALIDATION_EXCEPTION,
                List.of("ERR1", "ERR2")
        );

        ResponseEntity<ApiResponse<?>> entity = handler.handleCustomValidationException(ex);
        InspireApiResponse<?> response = (InspireApiResponse<?>) entity.getBody();

        assertEquals(200, entity.getStatusCode().value());

        //        MUST use dynamic ErrorRef value
        assertEquals(ErrorRef.inputValidation().asString(),
                response.getStatus().getErrorRef());

        assertEquals(List.of("ERR1", "ERR2"), response.getStatus().getErrors());
    }

           
    //        CustomValidationAdapterException handler
           

    @Test
    void test_handleCustomValidationAdapterException() {

        //        Mock dependency required by constructor
        com.hdfcbank.service.adapters.customer.model.CustomerApiStatusCode mockCode =
                Mockito.mock(com.hdfcbank.service.adapters.customer.model.CustomerApiStatusCode.class);

        when(mockCode.getCode()).thenReturn("9999");
        when(mockCode.getMessage()).thenReturn("adapter-error");

        CustomValidationAdapterException ex =
                new CustomValidationAdapterException(mockCode, List.of("A1", "B2"));

        ResponseEntity<ApiResponse<?>> entity = handler.handleCustomValidationException(ex);
        InspireApiResponse<?> response = (InspireApiResponse<?>) entity.getBody();

        assertEquals(200, entity.getStatusCode().value());
        assertEquals(ErrorRef.inputValidation().asString(), response.getStatus().getErrorRef());
        assertEquals(List.of("A1", "B2"), response.getStatus().getErrors());
    }

           
    //        OTPValidationException handler
           

    @Test
    void test_handleOtpValidationException() {

        OTPValidationException ex =
                new OTPValidationException(CustomCommonApiStatusCodes.DATA_NOT_FOUND);

        ResponseEntity<ApiResponse<?>> entity = handler.handleSoaTokenException(ex);

        assertEquals(200, entity.getStatusCode().value());
        assertEquals(CustomCommonApiStatusCodes.DATA_NOT_FOUND.getCode(),
                entity.getBody().getStatus().getCode());
    }

           
    //        SOATokenException handler
           

    @Test
    void test_handleSoaTokenException() {

        SOATokenException ex =
                new SOATokenException(CustomCommonApiStatusCodes.SUCCESS);

        ResponseEntity<ApiResponse<?>> entity = handler.handleSoaTokenException(ex);

        assertEquals(200, entity.getStatusCode().value());
        assertEquals(CustomCommonApiStatusCodes.SUCCESS.getCode(),
                entity.getBody().getStatus().getCode());
    }

           
    //        CoolOffLimitExceededException handler
           

    @Test
    void test_handleCoolOffLimitExceededException() {

        ErrorRef ref = ErrorRef.cooloff();

        CoolOffLimitExceededException ex =
                new CoolOffLimitExceededException(ref, "ERR1", "ERR2");

        ResponseEntity<ApiResponse<?>> entity = handler.handle(ex);

        //        Use correct type — DO NOT CAST to InspireApiResponse
        ApiResponse<?> response = entity.getBody();

        assertEquals(200, entity.getStatusCode().value());
        assertEquals(
                CustomCommonApiStatusCodes.COOL_OFF_LIMIT_EXCEEDED_ERROR.getCode(),
                response.getStatus().getCode()
        );

        assertEquals(ref.asString(), response.getStatus().getErrorRef());
        assertEquals(List.of("ERR1", "ERR2"), response.getStatus().getErrors());
    }

           
    //        NomineeException handler
           

    @Test
    void test_handleNomineeException() {

        NomineeException ex =
                new NomineeException(CustomCommonApiStatusCodes.DATA_NOT_FOUND);

        ResponseEntity<ApiResponse<?>> entity = handler.handleNomineeException(ex);

        assertEquals(200, entity.getStatusCode().value());
        assertEquals(
                CustomCommonApiStatusCodes.DATA_NOT_FOUND.getCode(),
                entity.getBody().getStatus().getCode()
        );
    }
}