package com.hdfcbank.giftcity.bff.config;

import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.index.Index;
import org.springframework.data.mongodb.core.index.IndexDefinition;
import org.springframework.data.mongodb.core.index.IndexOperations;

import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@SuppressWarnings({"deprecation", "removal"})
class IndexCreatorTest {

    @Test
    void initIndexes_shouldCreateCorrectTTLIndex() {

        MongoOperations mongoOps = mock(MongoOperations.class);
        IndexOperations indexOps = mock(IndexOperations.class);

        when(mongoOps.indexOps("cooloff")).thenReturn(indexOps);

        IndexCreator creator = new IndexCreator(mongoOps);
        creator.initIndexes(); // production still calls ensureIndex()

        ArgumentCaptor<IndexDefinition> captor =
                ArgumentCaptor.forClass(IndexDefinition.class);

        verify(indexOps, times(1)).ensureIndex(captor.capture());

        Index index = (Index) captor.getValue();

        Map<String, Object> keys = index.getIndexKeys();
        assertEquals(1, keys.get("expireAt"));

        Map<String, Object> opts = index.getIndexOptions();
        assertEquals("expire_index", opts.get("name"));
        assertEquals(10L, opts.get("expireAfterSeconds"));
    }
}