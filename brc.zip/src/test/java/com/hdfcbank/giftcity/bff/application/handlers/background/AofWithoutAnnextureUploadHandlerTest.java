package com.hdfcbank.giftcity.bff.application.handlers.background;

import com.hdfcbank.adapters.clients.feign.document.DocumentFeignClient;
import com.hdfcbank.adapters.vo.DocumentUploadedResponse;
import com.hdfcbank.adapters.vo.GenerateDocumentRequest;
import com.hdfcbank.common.models.vo.core.ApiResponse;
import com.hdfcbank.common.models.vo.core.ApiResponseStatus;
import com.hdfcbank.common.models.vo.journey.JourneyData;
import com.hdfcbank.common.models.vo.journey.JourneyDetail;
import com.hdfcbank.common.models.vo.journey.JourneyState;
import com.hdfcbank.giftcity.bff.commons.config.JourneyConfigProperties;
import com.hdfcbank.giftcity.bff.commons.enums.CommonJourneyStates;
import com.hdfcbank.giftcity.bff.commons.exception.handler.DownstreamResponseHandler;
import com.hdfcbank.giftcity.bff.commons.handler.Handler;
import com.hdfcbank.giftcity.bff.commons.handler.HandlerContext;
import com.hdfcbank.giftcity.bff.commons.handler.HandlerResult;
import com.hdfcbank.giftcity.bff.commons.model.FtsDetails;
import com.hdfcbank.giftcity.bff.customer.config.CustomerApiProperties;
import com.hdfcbank.giftcity.bff.customer.mapper.AofDocumentMapper;
import com.hdfcbank.giftcity.bff.customer.model.AofWithAnnextureData;
import com.hdfcbank.giftcity.bff.infrastructure.service.JourneyService;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import ch.qos.logback.classic.Level;
import ch.qos.logback.classic.Logger;
import org.slf4j.LoggerFactory;

import java.lang.reflect.Field;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class AofWithoutAnnextureUploadHandlerTest {

    @Mock private DocumentFeignClient documentFeignClient;
    @Mock private AofDocumentMapper mapper;
    @Mock private JourneyService journeyService;
    @Mock private CustomerApiProperties customerApiProperties;
    @Mock private CustomerApiProperties.AOFDetails aofDetails;

    @InjectMocks private AofWithoutAnnextureUploadHandler handler;

    private HandlerContext context;
    private JourneyData journeyData;

    @BeforeEach
    void init() throws Exception {
        MockitoAnnotations.openMocks(this);

        // Mute ALL logs from the handler (this removes exceptions from console)
        Logger logger = (Logger) LoggerFactory.getLogger(AofWithoutAnnextureUploadHandler.class);
        logger.setLevel(Level.OFF);

        // Journey baseline
        journeyData = new JourneyData();
        journeyData.setJourneyId("JX001");
        journeyData.setJourneyName("FTS Journey");

        JourneyState state = new JourneyState();
        state.setStateName(CommonJourneyStates.CUSTOMER_ACCOUNT_STATEMENTS_FETCH_SUCCESS.name());

        JourneyDetail detail = new JourneyDetail();
        detail.setJourneyStates(List.of(state));

        journeyData.setJourneyDetail(detail);
        context = HandlerContext.builder().journeyData(journeyData).build();

        when(customerApiProperties.getAofDetails()).thenReturn(aofDetails);
        when(aofDetails.getBranchName()).thenReturn("BR001");
        when(aofDetails.getBranchCode()).thenReturn("BC001");
        when(aofDetails.getProductCode()).thenReturn("PC999");

        JourneyConfigProperties mockJourneyConfig = mock(JourneyConfigProperties.class);
        when(mockJourneyConfig.getJourneys()).thenReturn(Map.of());

        Field field = DownstreamResponseHandler.class.getDeclaredField("journeyConfigProperties");
        field.setAccessible(true);
        field.set(null, mockJourneyConfig);
    }

    @Test
    @DisplayName("handle(): success flow")
    void testSuccessFlow() {

        GenerateDocumentRequest<AofWithAnnextureData> req = new GenerateDocumentRequest<>();
        when(mapper.toRequestAofOnly(any(), any(), any(), any())).thenReturn(req);

        DocumentUploadedResponse data = new DocumentUploadedResponse();
        data.setDocRef("DOC-ONLY-123");

        ApiResponseStatus status = new ApiResponseStatus();
        status.setCode("0000");

        ApiResponse<DocumentUploadedResponse> apiResponse =
                new ApiResponse<>(status, data);

        when(documentFeignClient.fetchGenerateAndUploadResponse(
                eq("JX001"), eq("FTS Journey"), eq(req)
        )).thenReturn(apiResponse);

        try (MockedStatic<JourneyService> mockedStatic = mockStatic(JourneyService.class)) {

            mockedStatic.when(() ->
                    JourneyService.extractFromJourney(any(), anyString(), any(), any())
            ).thenReturn(Optional.of(new FtsDetails()));

            HandlerResult<DocumentUploadedResponse> result = handler.handle(context);

            assertTrue(result.isSuccess());
            assertEquals("DOC-ONLY-123", result.getResult().getDocRef());

            verify(journeyService).updateJourney(
                    eq("JX001"),
                    eq("FtsDetails"),
                    any(FtsDetails.class),
                    eq(CommonJourneyStates.AOF_WITHOUT_ANNEXTURE_UPLOAD_SUCCESS)
            );
        }
    }

    @Test
    @DisplayName("handle(): failure flow")
    void testFailureFlow() {

        GenerateDocumentRequest<AofWithAnnextureData> req = new GenerateDocumentRequest<>();
        when(mapper.toRequestAofOnly(any(), any(), any(), any())).thenReturn(req);

        ApiResponseStatus status = new ApiResponseStatus();
        status.setCode("9999");

        ApiResponse<DocumentUploadedResponse> apiResponse =
                new ApiResponse<>(status, new DocumentUploadedResponse());

        when(documentFeignClient.fetchGenerateAndUploadResponse(
                eq("JX001"), eq("FTS Journey"), eq(req)
        )).thenReturn(apiResponse);

        HandlerResult<DocumentUploadedResponse> result = handler.handle(context);

        assertFalse(result.isSuccess());
        assertNotNull(result.getResult());
        assertNull(result.getResult().getDocRef());

        verify(journeyService, never())
                .updateJourney(any(), any(), any(), any());
    }

    @Test
    @DisplayName("preConditions(): missing state → false")
    void testPreConditionsFalse() {

        JourneyData jd = new JourneyData();
        jd.setJourneyDetail(new JourneyDetail());
        jd.getJourneyDetail().setJourneyStates(List.of());

        HandlerContext ctx = HandlerContext.builder().journeyData(jd).build();

        assertFalse(handler.preConditions(ctx));
    }

    @Test
    @DisplayName("handle(): AOF details null → failure")
    void testHandleWhenAofDetailsNull() {

        when(customerApiProperties.getAofDetails()).thenReturn(null);

        GenerateDocumentRequest<AofWithAnnextureData> req = new GenerateDocumentRequest<>();
        when(mapper.toRequestAofOnly(any(), any(), any(), any())).thenReturn(req);

        HandlerResult<DocumentUploadedResponse> result = handler.handle(context);

        assertFalse(result.isSuccess());
        assertNull(result.getResult());
    }

    @Test
    @DisplayName("handle(): status null → failure")
    void testFailureWhenStatusNull() {

        GenerateDocumentRequest<AofWithAnnextureData> req = new GenerateDocumentRequest<>();
        when(mapper.toRequestAofOnly(any(), any(), any(), any())).thenReturn(req);

        ApiResponse<DocumentUploadedResponse> resp =
                new ApiResponse<>(null, new DocumentUploadedResponse());

        when(documentFeignClient.fetchGenerateAndUploadResponse(
                eq("JX001"), eq("FTS Journey"), eq(req)
        )).thenReturn(resp);

        HandlerResult<DocumentUploadedResponse> result = handler.handle(context);

        assertFalse(result.isSuccess());
        assertNull(result.getResult());

        verify(journeyService, never())
                .updateJourney(any(), any(), any(), any());
    }

    @Test
    @DisplayName("handle(): Feign exception → clean failure")
    void testHandleExceptionFlow() {

        GenerateDocumentRequest<AofWithAnnextureData> req = new GenerateDocumentRequest<>();
        when(mapper.toRequestAofOnly(any(), any(), any(), any())).thenReturn(req);

        when(documentFeignClient.fetchGenerateAndUploadResponse(
                anyString(), anyString(), any()
        )).thenThrow(new RuntimeException("Feign error"));

        HandlerResult<DocumentUploadedResponse> result = handler.handle(context);

        assertFalse(result.isSuccess());
        assertNull(result.getResult());

        verify(journeyService, never())
                .updateJourney(any(), any(), any(), any());
    }

    @Test
    @DisplayName("Metadata getters")
    void testMetadataMethods() {

        assertEquals(Handler.HandlerType.BACKGROUND_TASKS_POST_SUBMIT_SUCCESS, handler.getType());
        assertEquals(Handler.HandlerName.AOF_WITHOUT_ANNEXTURE_UPLOAD, handler.getName());
        assertEquals(CommonJourneyStates.AOF_WITHOUT_ANNEXTURE_UPLOAD_SUCCESS, handler.successState());
        assertEquals(CommonJourneyStates.AOF_WITHOUT_ANNEXTURE_UPLOAD_FAILURE, handler.failureState());
    }
}