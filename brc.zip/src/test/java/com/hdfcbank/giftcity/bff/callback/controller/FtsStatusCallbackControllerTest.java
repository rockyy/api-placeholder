package com.hdfcbank.giftcity.bff.callback.controller;

import com.hdfcbank.giftcity.bff.callback.model.FtsStatusCallbackRequest;
import com.hdfcbank.giftcity.bff.callback.model.FtsStatusCallbackResponse;
import com.hdfcbank.giftcity.bff.callback.service.FtsStatusCallbackService;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import org.springframework.http.ResponseEntity;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

class FtsStatusCallbackControllerTest {

    @Mock
    private FtsStatusCallbackService service;

    @InjectMocks
    private FtsStatusCallbackController controller;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    // ----------------------------------------------------------
    // SUCCESS CASE
    // ----------------------------------------------------------
    @Test
    void testProcessFtsStatusCallback_returnsOkResponse() {

        FtsStatusCallbackRequest request = new FtsStatusCallbackRequest();
        FtsStatusCallbackResponse expectedResponse = new FtsStatusCallbackResponse();

        when(service.processFtsStatusCallback(request)).thenReturn(expectedResponse);

        ResponseEntity<FtsStatusCallbackResponse> response =
                controller.processFtsStatusCallback(request);

        assertNotNull(response, "ResponseEntity must not be null");
        assertEquals(200, response.getStatusCode().value(), "Status code must be 200 OK");
        assertSame(expectedResponse, response.getBody(),
                "Controller must return the same response object returned by the service");

        // ✔ Correct assertion: ResponseEntity.ok() returns empty headers
        assertTrue(response.getHeaders().isEmpty(),
                "Headers should be empty for ResponseEntity.ok()");

        // ✔ Correct assertion: Spring sets Content-Length = -1 by default
        assertEquals(-1, response.getHeaders().getContentLength(),
                "Content-Length should be -1 unless explicitly set");

        verify(service, times(1)).processFtsStatusCallback(request);
        verifyNoMoreInteractions(service);
    }

    // ----------------------------------------------------------
    // FAILURE — Service throws exception
    // ----------------------------------------------------------
    @Test
    void testProcessFtsStatusCallback_whenServiceThrowsException() {

        // Arrange
        FtsStatusCallbackRequest request = new FtsStatusCallbackRequest();
        RuntimeException exception = new RuntimeException("Service failure");

        when(service.processFtsStatusCallback(request))
                .thenThrow(exception);

        // Act & Assert — enhanced
        RuntimeException thrown = assertThrows(
                RuntimeException.class,
                () -> controller.processFtsStatusCallback(request),
                "Controller must propagate the same exception thrown by the service"
        );

        assertEquals("Service failure", thrown.getMessage(),
                "Exception message must match the service exception");

        assertTrue(thrown instanceof RuntimeException,
                "Thrown exception must be RuntimeException");

        // Verify service interaction
        verify(service, times(1)).processFtsStatusCallback(request);
        verifyNoMoreInteractions(service);
    }
}