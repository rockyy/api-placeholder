package com.hdfcbank.giftcity.bff.commons.exception;

import com.hdfcbank.common.models.vo.core.ApiResponseStatusCodeLiteral;
import com.hdfcbank.giftcity.bff.customer.model.CustomerApiStatusCode;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class LimitExceededExceptionTest {

    @Test
    void test_constructor_customerApiStatusCode_and_attemptMessage() {
        CustomerApiStatusCode code = mock(CustomerApiStatusCode.class);
        LimitExceededException ex = new LimitExceededException(code, "ATTEMPT");

        assertEquals(code, ex.getCustomerApiStatusCode());
        assertEquals("ATTEMPT", ex.getAttemptExceededMessage());
        assertNull(ex.getMessage());  // RuntimeException message is null
    }

    @Test
    void test_constructor_message_and_literalStatusCode() {
        ApiResponseStatusCodeLiteral literal = mock(ApiResponseStatusCodeLiteral.class);
        when(literal.getMessage()).thenReturn("LITERAL-MSG");

        LimitExceededException ex = new LimitExceededException("LIMIT", literal);

        assertEquals(literal, ex.getCustomerApiStatusCode());
        assertEquals("LITERAL-MSG", ex.getAttemptExceededMessage());
        assertEquals("LIMIT", ex.getMessage());
    }

    @Test
    void test_constructor_message_customerCode_attemptMessage() {
        CustomerApiStatusCode code = mock(CustomerApiStatusCode.class);

        LimitExceededException ex =
                new LimitExceededException("LIMIT", code, "ATTEMPT");

        assertEquals(code, ex.getCustomerApiStatusCode());
        assertEquals("ATTEMPT", ex.getAttemptExceededMessage());
        assertEquals("LIMIT", ex.getMessage());
    }

    @Test
    void test_constructor_message_cause_customerCode_attemptMessage() {
        CustomerApiStatusCode code = mock(CustomerApiStatusCode.class);
        Throwable cause = new RuntimeException("ROOT");

        LimitExceededException ex =
                new LimitExceededException("LIMIT", cause, code, "ATTEMPT");

        assertEquals(code, ex.getCustomerApiStatusCode());
        assertEquals("ATTEMPT", ex.getAttemptExceededMessage());
        assertEquals("LIMIT", ex.getMessage());
        assertEquals(cause, ex.getCause());
    }

    @Test
    void test_constructor_cause_customerCode_attemptMessage() {
        CustomerApiStatusCode code = mock(CustomerApiStatusCode.class);
        Throwable cause = new RuntimeException("ROOT");

        LimitExceededException ex =
                new LimitExceededException(cause, code, "ATTEMPT");

        assertEquals(code, ex.getCustomerApiStatusCode());
        assertEquals("ATTEMPT", ex.getAttemptExceededMessage());

        // Cause must match
        assertEquals(cause, ex.getCause());

        // Message is NOT null — inherited from Throwable(cause)
        assertEquals("java.lang.RuntimeException: ROOT", ex.getMessage());
    }

    @Test
    void test_full_constructor_enableSuppression_writableStackTrace() {

        CustomerApiStatusCode code = mock(CustomerApiStatusCode.class);
        Throwable cause = new RuntimeException("ROOT");

        LimitExceededException ex =
                new LimitExceededException(
                        "LIMIT",
                        cause,
                        true,         // enableSuppression
                        false,        // writableStackTrace
                        code,
                        "ATTEMPT"
                );

        assertEquals(code, ex.getCustomerApiStatusCode());
        assertEquals("ATTEMPT", ex.getAttemptExceededMessage());
        assertEquals("LIMIT", ex.getMessage());
        assertEquals(cause, ex.getCause());
    }
}
