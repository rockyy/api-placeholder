package com.hdfcbank.giftcity.bff.commons.utility;

import com.hdfcbank.giftcity.bff.commons.exception.LimitExceededException;
import com.hdfcbank.giftcity.bff.customer.model.CustomerApiStatusCode;
import org.junit.jupiter.api.Test;
import org.mockito.MockedStatic;
import org.mockito.Mockito;

import java.time.ZonedDateTime;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class OneDeviceCacheUtilityTest {

    private final OneDeviceCacheUtility utility = new OneDeviceCacheUtility();

    // Test deviceLoggedIn() @Cacheable
    @Test
    void testDeviceLoggedInReturnsCorrectDetail() {

        ZonedDateTime now = ZonedDateTime.now();
        String accessToken = "abc-token";

        try (MockedStatic<TextSanityUtil> mocked = Mockito.mockStatic(TextSanityUtil.class)) {

            mocked.when(() -> TextSanityUtil.sanitize("LOGIN"))
                    .thenReturn("LOGIN");

            OneDeviceCacheUtility.OneDeviceOneLoginDetail detail =
                    utility.deviceLoggedIn("9999999999", "1995-01-01", "LOGIN", accessToken, now);

            assertNotNull(detail);
            assertEquals(now, detail.getDateTime(), "Stored dateTime must match input");
            assertEquals(accessToken, detail.getAccessToken(), "AccessToken must match input");

            // Additional assertions
            assertNotNull(detail.getAccessToken());
            assertFalse(detail.getAccessToken().isBlank());
            mocked.verify(() -> TextSanityUtil.sanitize("LOGIN"));
        }
    }

    // Test cleanDeviceLoggedIn() @CacheEvict
    @Test
    void testCleanDeviceLoggedInDoesNotThrow() {
        try (MockedStatic<TextSanityUtil> mocked = Mockito.mockStatic(TextSanityUtil.class)) {

            mocked.when(() -> TextSanityUtil.sanitize("FASTAG"))
                    .thenReturn("FASTAG");

            assertDoesNotThrow(() ->
                    utility.cleanDeviceLoggedIn("9999999999", "2000-01-01", "FASTAG"));

            // Verify sanitize is invoked
            mocked.verify(() -> TextSanityUtil.sanitize("FASTAG"));
        }
    }

    // Test validateDevice() — throws LimitExceededException
    @Test
    void testValidateDeviceThrowsExceptionOnDuplicateSession() {

        ZonedDateTime storedTime = ZonedDateTime.now().minusMinutes(10);
        ZonedDateTime currentTime = ZonedDateTime.now();

        OneDeviceCacheUtility.OneDeviceOneLoginDetail detail =
                new OneDeviceCacheUtility.OneDeviceOneLoginDetail(storedTime, "old-token");

        LimitExceededException ex = assertThrows(
                LimitExceededException.class,
                () -> utility.validateDevice(detail, currentTime, "new-token")
        );

        assertNotNull(ex.getCustomerApiStatusCode());
        assertEquals(CustomerApiStatusCode.DUPLICATE_SESSION, ex.getCustomerApiStatusCode());
        assertEquals("Duplicate Session", ex.getAttemptExceededMessage());

        // Additional assertions
        assertNotEquals("old-token", "new-token");
        assertNotEquals(storedTime, currentTime);
    }

    // Test validateDevice() — allowed: matching token
    @Test
    void testValidateDeviceAllowedWhenTokenMatches() {

        ZonedDateTime storedTime = ZonedDateTime.now().minusMinutes(5);
        ZonedDateTime currentTime = ZonedDateTime.now();

        OneDeviceCacheUtility.OneDeviceOneLoginDetail detail =
                new OneDeviceCacheUtility.OneDeviceOneLoginDetail(storedTime, "token-123");

        assertDoesNotThrow(() ->
                utility.validateDevice(detail, currentTime, "token-123"));

        // Additional assertions confirming valid conditions
        assertEquals("token-123", detail.getAccessToken());
        assertTrue(currentTime.isAfter(storedTime));
    }

    // Test validateDevice() — allowed: matching dateTime
    @Test
    void testValidateDeviceAllowedWhenDateTimeMatches() {

        ZonedDateTime now = ZonedDateTime.now();

        OneDeviceCacheUtility.OneDeviceOneLoginDetail detail =
                new OneDeviceCacheUtility.OneDeviceOneLoginDetail(now, "token-xyz");

        assertDoesNotThrow(() ->
                utility.validateDevice(detail, now, "different-token"));

        // Extra assertions
        assertEquals(now, detail.getDateTime());
        assertNotNull(detail.getAccessToken());
        assertFalse(detail.getAccessToken().isBlank());
    }
}