package com.hdfcbank.giftcity.bff.commons.file;

import org.junit.jupiter.api.Test;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;

import static org.junit.jupiter.api.Assertions.*;

class ByteArrayMultipartFileTest {

    @Test
    void testGetName() {
        MultipartFile file = new ByteArrayMultipartFile(
                "testName",
                "file.txt",
                "text/plain",
                "data".getBytes()
        );

        assertEquals("testName", file.getName());

        // extra assertions
        assertNotNull(file.getName());
        assertFalse(file.getName().isBlank());
    }

    @Test
    void testGetOriginalFilename() {
        MultipartFile file = new ByteArrayMultipartFile(
                "testName",
                "file.txt",
                "text/plain",
                "data".getBytes()
        );

        assertEquals("file.txt", file.getOriginalFilename());

        // extra assertions
        assertNotNull(file.getOriginalFilename());
        assertTrue(file.getOriginalFilename().contains("."));
        assertEquals("file.txt", file.getOriginalFilename());
    }

    @Test
    void testGetContentType() {
        MultipartFile file = new ByteArrayMultipartFile(
                "name",
                "abc.json",
                "application/json",
                "123".getBytes()
        );

        assertEquals("application/json", file.getContentType());

        // extra assertions
        assertNotNull(file.getContentType());
        assertTrue(file.getContentType().startsWith("application"));
    }

    @Test
    void testIsEmptyTrue() throws Exception {
        MultipartFile file = new ByteArrayMultipartFile(
                "name",
                "empty.bin",
                "application/octet-stream",
                new byte[]{}     // empty bytes
        );

        assertTrue(file.isEmpty());

        // extra assertions
        assertEquals(0, file.getSize());
        assertEquals(0, file.getBytes().length);
    }

    @Test
    void testIsEmptyFalse() {
        MultipartFile file = new ByteArrayMultipartFile(
                "name",
                "notEmpty.bin",
                "application/octet-stream",
                "abc".getBytes()
        );

        assertFalse(file.isEmpty());

        // extra assertions
        assertTrue(file.getSize() > 0);
        assertEquals(3, file.getSize());
    }

    @Test
    void testGetSize() {
        byte[] data = "hello".getBytes();

        MultipartFile file = new ByteArrayMultipartFile(
                "name",
                "size.bin",
                "application/octet-stream",
                data
        );

        assertEquals(data.length, file.getSize());

        // extra assertions
        assertEquals(5, file.getSize());
        assertFalse(file.isEmpty());
    }

    @Test
    void testGetBytes() throws IOException {
        byte[] data = "bytes-test".getBytes();

        MultipartFile file = new ByteArrayMultipartFile(
                "name",
                "bytes.bin",
                "application/octet-stream",
                data
        );

        assertArrayEquals(data, file.getBytes());

        // extra assertions
        assertEquals("bytes-test", new String(file.getBytes()));
        assertNotNull(file.getBytes());
        assertEquals(data.length, file.getBytes().length);
    }

    @Test
    void testGetInputStream() throws IOException {
        byte[] data = "stream-test".getBytes();

        MultipartFile file = new ByteArrayMultipartFile(
                "name",
                "stream.bin",
                "application/octet-stream",
                data
        );

        try (InputStream is = file.getInputStream()) {
            byte[] read = is.readAllBytes();
            assertArrayEquals(data, read);
        }

        // extra assertions
        try (InputStream is2 = file.getInputStream()) {
            assertEquals(data.length, is2.available());
        }
    }

    @Test
    void testTransferToCreatesAndWritesFile() throws IOException {
        byte[] data = "transfer-test".getBytes();

        MultipartFile file = new ByteArrayMultipartFile(
                "name",
                "transfer.bin",
                "application/octet-stream",
                data
        );

        File temp = File.createTempFile("test-transfer", ".bin");
        temp.delete(); // ensure not exists → triggers createFile() branch
        temp.deleteOnExit();

        file.transferTo(temp);

        byte[] written = Files.readAllBytes(temp.toPath());
        assertArrayEquals(data, written);

        // extra assertions
        assertTrue(temp.exists());
        assertTrue(temp.length() > 0);
        assertEquals(data.length, written.length);
    }

    @Test
    void testTransferToOverwritesExistingFile() throws IOException {
        byte[] data = "overwrite-test".getBytes();

        MultipartFile file = new ByteArrayMultipartFile(
                "name",
                "overwrite.bin",
                "application/octet-stream",
                data
        );

        File temp = File.createTempFile("test-overwrite", ".bin");
        temp.deleteOnExit();

        // Write initial content
        Files.write(temp.toPath(), "old".getBytes());

        // Should truncate + overwrite
        file.transferTo(temp);

        byte[] written = Files.readAllBytes(temp.toPath());
        assertArrayEquals(data, written);

        // extra assertions
        assertTrue(temp.exists());
        assertEquals(data.length, written.length);
        assertNotEquals("old", new String(written));
    }
}