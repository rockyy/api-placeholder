package com.hdfcbank.giftcity.bff.scheduler;

import com.hdfcbank.giftcity.bff.account.service.FtsApplicationInquireService;
import com.hdfcbank.giftcity.bff.application.service.impl.ApplicationServiceImpl;
import com.hdfcbank.giftcity.bff.customer.rmcodes.service.RmCodesMasterService;
import com.hdfcbank.job.scheduler.common.model.ExecutionStatus;
import com.hdfcbank.job.scheduler.common.model.JobSchedule;

import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
class ScheduleExecutionServiceTest {

    @Mock
    private RmCodesMasterService rmCodesMasterService;

    @Mock
    private ApplicationServiceImpl applicationService;

    @Mock
    private FtsApplicationInquireService applicationInquireService;

    private ScheduleExecutionService scheduleExecutionService;

    @BeforeEach
    void setup() {
        scheduleExecutionService = new ScheduleExecutionService(
                rmCodesMasterService,
                applicationService,
                applicationInquireService
        );

        assertNotNull(scheduleExecutionService, "ScheduleExecutionService should be initialized");
    }

    private JobSchedule buildJob(String jobName) {
        JobSchedule schedule = new JobSchedule();
        schedule.setJobName(jobName);

        assertEquals(jobName, schedule.getJobName(), "JobName must match setter");

        return schedule;
    }

    // ==================================================================================
    // TEST 1 — LG_LC_MASTERSYNC should trigger rmCodesMasterService.saveOrUpdateRmCodes()
    // ==================================================================================
    @Test
    void execute_shouldRunLG_LC_MASTERSYNC() {
        JobSchedule schedule = buildJob(ScheduleExecutionService.JobName.LG_LC_MASTERSYNC.name());

        ExecutionStatus result = scheduleExecutionService.execute(schedule);

        verify(rmCodesMasterService, times(1)).saveOrUpdateRmCodes();
        verifyNoInteractions(applicationService);
        verifyNoInteractions(applicationInquireService);

        assertNotNull(result);
        assertEquals(ExecutionStatus.COMPLETED, result);
    }

    // ==================================================================================
    // TEST 2 — AOF_SUBMISSION_PENDING should call applicationService.processAofSubmissionAlertReminders()
    // ==================================================================================
    @Test
    void execute_shouldRunAofSubmissionPending() {
        JobSchedule schedule = buildJob(ScheduleExecutionService.JobName.AOF_SUBMISSION_PENDING.name());

        ExecutionStatus result = scheduleExecutionService.execute(schedule);

        verify(applicationService, times(1)).processAofSubmissionAlertReminders();
        verifyNoInteractions(rmCodesMasterService);
        verifyNoInteractions(applicationInquireService);

        assertNotNull(result);
        assertEquals(ExecutionStatus.COMPLETED, result);
    }

    // ==================================================================================
    // TEST 3 — FTS_APPLICATION_INQUIRE should call applicationInquireService.inquireApplicationsAndUpdateJourneyState()
    // ==================================================================================
    @Test
    void execute_shouldRunFtsApplicationInquire() {
        JobSchedule schedule = buildJob(ScheduleExecutionService.JobName.FTS_APPLICATION_INQUIRE.name());

        ExecutionStatus result = scheduleExecutionService.execute(schedule);

        verify(applicationInquireService, times(1)).inquireApplicationsAndUpdateJourneyState();
        verifyNoInteractions(rmCodesMasterService);
        verifyNoInteractions(applicationService);

        assertNotNull(result);
        assertEquals(ExecutionStatus.COMPLETED, result);
    }

    // ==================================================================================
    // TEST 4 — UNKNOWN jobName must NOT call any service but return COMPLETED
    // ==================================================================================
    @Test
    void execute_shouldHandleUnknownJob() {
        JobSchedule schedule = buildJob("SOME_UNKNOWN_JOB");

        ExecutionStatus result = scheduleExecutionService.execute(schedule);

        verifyNoInteractions(rmCodesMasterService);
        verifyNoInteractions(applicationService);
        verifyNoInteractions(applicationInquireService);

        assertNotNull(result);
        assertEquals(ExecutionStatus.COMPLETED, result);
    }

    // ==================================================================================
    // TEST 5 — Null jobName should throw NPE and call no services
    // ==================================================================================
    @Test
    void execute_shouldHandleNullJobName() {
        JobSchedule schedule = buildJob(null);

        assertThrows(NullPointerException.class,
                () -> scheduleExecutionService.execute(schedule),
                "Null jobName must throw NullPointerException"
        );

        verifyNoInteractions(rmCodesMasterService);
        verifyNoInteractions(applicationService);
        verifyNoInteractions(applicationInquireService);
    }

    // ==================================================================================
    // EXTRA TEST — Blank jobName (not null), should behave as unknown
    // ==================================================================================
    @Test
    void execute_shouldHandleBlankJobName() {
        JobSchedule schedule = buildJob("   ");

        ExecutionStatus result = scheduleExecutionService.execute(schedule);

        verifyNoInteractions(rmCodesMasterService);
        verifyNoInteractions(applicationService);
        verifyNoInteractions(applicationInquireService);

        assertNotNull(result);
        assertEquals(ExecutionStatus.COMPLETED, result);
        assertEquals("   ", schedule.getJobName());
    }

    // ==================================================================================
    // EXTRA TEST — Lowercase job name shouldn't match any enum
    // ==================================================================================
    @Test
    void execute_shouldHandleCaseMismatchJobName() {
        JobSchedule schedule = buildJob("lg_lc_mastersync"); // wrong case

        ExecutionStatus result = scheduleExecutionService.execute(schedule);

        verifyNoInteractions(rmCodesMasterService);
        verifyNoInteractions(applicationService);
        verifyNoInteractions(applicationInquireService);

        assertNotNull(result);
        assertEquals(ExecutionStatus.COMPLETED, result);
    }

    // ==================================================================================
    // EXTRA TEST — Verify each enum jobName maps to valid execution
    // ==================================================================================
    @Test
    void execute_shouldSupportAllEnumJobNames() {
        for (ScheduleExecutionService.JobName job : ScheduleExecutionService.JobName.values()) {

            JobSchedule schedule = buildJob(job.name());
            ExecutionStatus result = scheduleExecutionService.execute(schedule);

            assertNotNull(result);

            switch (job) {
                case LG_LC_MASTERSYNC:
                    verify(rmCodesMasterService, times(1)).saveOrUpdateRmCodes();
                    break;

                case AOF_SUBMISSION_PENDING:
                    verify(applicationService, times(1)).processAofSubmissionAlertReminders();
                    break;

                case FTS_APPLICATION_INQUIRE:
                    verify(applicationInquireService, times(1)).inquireApplicationsAndUpdateJourneyState();
                    break;
            }

            // Reset mocks after each iteration
            clearInvocations(rmCodesMasterService);
            clearInvocations(applicationService);
            clearInvocations(applicationInquireService);
        }
    }

    @Test
    void execute_shouldPropagateDelegatedFailure() {
        IllegalStateException failure = new IllegalStateException("Master sync failed");
        doThrow(failure).when(rmCodesMasterService).saveOrUpdateRmCodes();

        assertSame(failure, assertThrows(IllegalStateException.class,
                () -> scheduleExecutionService.execute(
                        buildJob(ScheduleExecutionService.JobName.LG_LC_MASTERSYNC.name()))));

        verify(rmCodesMasterService).saveOrUpdateRmCodes();
        verifyNoInteractions(applicationService, applicationInquireService);
    }
}
