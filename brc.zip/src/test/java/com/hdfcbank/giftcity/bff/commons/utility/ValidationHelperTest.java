package com.hdfcbank.giftcity.bff.commons.utility;

import com.hdfcbank.giftcity.bff.commons.model.CustomValidationStatus;
import com.hdfcbank.giftcity.bff.commons.properties.CustomValidationProperties;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.*;

import static org.junit.jupiter.api.Assertions.*;

class ValidationHelperTest {

    private ValidationHelper validationHelper;
    private CustomValidationProperties properties;

    @BeforeEach
    void setup() {
        properties = new CustomValidationProperties();

        CustomValidationProperties.FieldDetail field1 = new CustomValidationProperties.FieldDetail();
        field1.setType("testType");
        field1.setMandatory(true);
        field1.setLength(5);
        field1.setAllowedRegex("[A-Z]+");
        field1.setAllowedValues(Arrays.asList("yes", "no"));
        field1.setNotAllowedValues(Collections.singletonList("bad"));
        field1.setMessageHeading("Field1 Heading");
        field1.setMessage("Field1 Message");
        field1.setCode("C001");
        field1.setMin(10);
        field1.setMax(20);

        CustomValidationProperties.CustomValidations cv = new CustomValidationProperties.CustomValidations();
        cv.setDefaultMessage("Default Message");
        cv.setDefaultMessageHeading("Default Heading");
        cv.setFieldsDetail(Collections.singletonList(field1));

        Map<String, CustomValidationProperties.CustomValidations> journeys = new HashMap<>();
        journeys.put("journeyA", cv);
        properties.setJourneys(journeys);

        validationHelper = new ValidationHelper(properties);
    }

    // validateData(): mandatory is true and value is empty → return fieldDetail
    @Test
    void testMandatoryFieldEmpty() {
        CustomValidationProperties.FieldDetail fd =
                validationHelper.validateData("testType", "", properties, "journeyA");

        assertNotNull(fd);
        assertEquals("testType", fd.getType());
    }

    // validateData(): allowedValues check fails → return fieldDetail
    @Test
    void testAllowedValuesFails() {
        CustomValidationProperties.FieldDetail fd =
                validationHelper.validateData("testType", "maybe", properties, "journeyA");

        assertNotNull(fd);
        assertEquals("testType", fd.getType());
    }

    // validateData(): notAllowedValues check → return fieldDetail
    @Test
    void testNotAllowedValuesFails() {
        CustomValidationProperties.FieldDetail fd =
                validationHelper.validateData("testType", "bad", properties, "journeyA");

        assertNotNull(fd);
        assertEquals("testType", fd.getType());
    }

    // validateData(): length check fails → return fieldDetail
    @Test
    void testLengthFails() {
        CustomValidationProperties.FieldDetail fd =
                validationHelper.validateData("testType", "TOO_LONG", properties, "journeyA");

        assertNotNull(fd);
        assertEquals("testType", fd.getType());
    }

    // validateData(): regex check fails → return fieldDetail
    @Test
    void testRegexFails() {
        CustomValidationProperties.FieldDetail fd =
                validationHelper.validateData("testType", "abc", properties, "journeyA"); // regex = [A-Z]+

        assertNotNull(fd);
    }

    // validateData(): passes (no validation errors)
    @Test
    void testValidateDataPasses() {
        CustomValidationProperties.FieldDetail fd =
                validationHelper.validateData("testType", "YES", properties, "journeyA");

        assertNull(fd); // no validation errors
    }

    // getErrors(): field messageHeading + message override defaults
    @Test
    void testGetErrorsFieldOverrides() {
        CustomValidationProperties.FieldDetail fd =
                properties.getJourneys().get("journeyA").getFieldsDetail().get(0);

        CustomValidationStatus status =
                validationHelper.getErrors("journeyA", Collections.singletonList(fd), properties);

        assertEquals("Field1 Heading", status.getTitle());
        assertEquals("Field1 Message", status.getMessage());
        assertEquals("C001", status.getCode());
        assertEquals("testType", status.getType());
        assertEquals(Collections.singletonList("Field1 Message"), status.getErrors());
    }

    // getErrors(): fallback to default when messageHeading or message is null
    @Test
    void testGetErrorsUsesDefaultMessages() {
        CustomValidationProperties.FieldDetail fd =
                properties.getJourneys().get("journeyA").getFieldsDetail().get(0);

        fd.setMessageHeading(null);
        fd.setMessage(null);

        CustomValidationStatus status =
                validationHelper.getErrors("journeyA", Collections.singletonList(fd), properties);

        assertEquals("Default Heading", status.getTitle());
        assertEquals("Default Message", status.getMessage());
    }

    // getErrors(): empty input → return empty CustomValidationStatus
    @Test
    void testGetErrorsEmptyList() {
        CustomValidationStatus status =
                validationHelper.getErrors("journeyA", Collections.emptyList(), properties);

        assertNotNull(status);
        assertNull(status.getMessage()); // builder() created object with no fields
    }

    // validateRange(): mandatory field and null value → return fieldDetail
    @Test
    void testValidateRangeMandatoryNull() {
        CustomValidationProperties.FieldDetail field =
                properties.getJourneys().get("journeyA").getFieldsDetail().get(0);

        field.setMandatory(true);

        CustomValidationProperties.FieldDetail result =
                validationHelper.validateRange("testType", null, "journeyA");

        assertNotNull(result);
    }

    // validateRange(): min validation fails
    @Test
    void testValidateRangeMinFails() {
        CustomValidationProperties.FieldDetail result =
                validationHelper.validateRange("testType", 5, "journeyA"); // min = 10

        assertNotNull(result);
    }

    // validateRange(): max validation fails
    @Test
    void testValidateRangeMaxFails() {
        CustomValidationProperties.FieldDetail result =
                validationHelper.validateRange("testType", 25, "journeyA"); // max = 20

        assertNotNull(result);
    }

    // validateRange(): valid value → return null
    @Test
    void testValidateRangePasses() {
        CustomValidationProperties.FieldDetail result =
                validationHelper.validateRange("testType", 15, "journeyA");

        assertNull(result);
    }

    // validateRange(): no field found for type → return null
    @Test
    void testValidateRangeTypeNotFound() {
        CustomValidationProperties.FieldDetail result =
                validationHelper.validateRange("unknownType", 10, "journeyA");

        assertNull(result);
    }
}