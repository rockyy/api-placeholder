package com.hdfcbank.giftcity.bff.consent.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.hdfcbank.common.models.vo.journey.JourneyData;
import com.hdfcbank.common.models.vo.journey.Profile;
import com.hdfcbank.giftcity.bff.consent.config.ConsentsApiProperties;
import com.hdfcbank.giftcity.bff.customer.model.CustomerConsentRequest;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import software.amazon.awssdk.services.sqs.SqsClient;
import software.amazon.awssdk.services.sqs.model.SendMessageRequest;
import software.amazon.awssdk.services.sqs.model.SendMessageResponse;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class ConsentServiceTest {

    @Mock
    private ConsentsApiProperties consentsApiProperties;

    @Mock
    private SqsClient sqsClient;

    @InjectMocks
    private ConsentService consentService;

         
    // SUCCESSFUL SUBMISSION TEST
         
    @Test
    void storeConsentsData_shouldSendConsentMessageToSqs() throws Exception {

        Profile profile = Profile.builder()
                .panNumber("ABCDE1234F")
                .firstName("Arijit")
                .lastName("Bhattacharjee")
                .dob("10-05-2000")
                .build();

        JourneyData journeyData = JourneyData.builder()
                .mobileNumber("8753785686")
                .isd("+91")
                .journeyId("JOURNEY-123")
                .journeyName("TEST_JOURNEY")
                .profile(profile)
                .build();

        CustomerConsentRequest consent = CustomerConsentRequest.builder()
                .key("TERMS_AND_CONDITIONS")
                .acceptance(true)
                .build();

        List<CustomerConsentRequest> consents = List.of(consent);

        when(consentsApiProperties.getQueueUrl()).thenReturn("https://test-queue");

        SendMessageResponse sqsResponse = SendMessageResponse.builder()
                .messageId("test-message-id")
                .md5OfMessageBody("test-md5")
                .build();

        when(sqsClient.sendMessage(any(SendMessageRequest.class)))
                .thenReturn(sqsResponse);

        consentService.storeConsentsData(consents, journeyData);

        ArgumentCaptor<SendMessageRequest> captor = ArgumentCaptor.forClass(SendMessageRequest.class);
        verify(sqsClient, times(1)).sendMessage(captor.capture());

        SendMessageRequest request = captor.getValue();

        assertEquals("https://test-queue", request.queueUrl());

        ObjectMapper mapper = new ObjectMapper();
        JsonNode root = mapper.readTree(request.messageBody());

        assertEquals("TEST_JOURNEY", root.get("journeyName").asText());
        assertEquals("JOURNEY-123", root.get("journeyId").asText());

        JsonNode details = root.get("customerDetails");
        assertEquals("ABCDE1234F", details.get("pan").asText());
        assertEquals("Arijit", details.get("firstName").asText());
        assertEquals("Bhattacharjee", details.get("lastName").asText());
        assertEquals("10-05-2000", details.get("dateOfBirth").asText());
        assertEquals("+918753785686", details.get("identifier").asText());
        assertEquals("MOBILE_NUMBER", details.get("identifierType").asText());

        JsonNode consentsNode = details.get("consents");
        assertEquals(1, consentsNode.size());
        assertEquals("TERMS_AND_CONDITIONS", consentsNode.get(0).get("key").asText());
        assertTrue(consentsNode.get(0).get("acceptance").asBoolean());
        assertFalse(details.get("consentsCapturedDate").asText().isBlank());
    }

         
    // MULTIPLE CONSENTS TEST
         
    @Test
    void storeConsentData_shouldSendMultipleConsentsToSqs() throws Exception {

        Profile profile = Profile.builder()
                .panNumber("ABCDE1234F")
                .firstName("Arijit")
                .lastName("Bhattacharjee")
                .dob("10-05-2000")
                .build();

        JourneyData journeyData = JourneyData.builder()
                .mobileNumber("8753785686")
                .isd("+91")
                .journeyId("JOURNEY-123")
                .journeyName("TEST_JOURNEY")
                .profile(profile)
                .build();

        CustomerConsentRequest c1 = CustomerConsentRequest.builder().key("TERMS").acceptance(true).build();
        CustomerConsentRequest c2 = CustomerConsentRequest.builder().key("PRIVACY").acceptance(false).build();
        CustomerConsentRequest c3 = CustomerConsentRequest.builder().key("MARKETING").acceptance(true).build();

        List<CustomerConsentRequest> consents = List.of(c1, c2, c3);

        when(consentsApiProperties.getQueueUrl()).thenReturn("https://test-queue");

        SendMessageResponse sqsResponse = SendMessageResponse.builder()
                .messageId("test-message-id")
                .md5OfMessageBody("test-md5")
                .build();

        when(sqsClient.sendMessage(any(SendMessageRequest.class)))
                .thenReturn(sqsResponse);

        consentService.storeConsentsData(consents, journeyData);

        ArgumentCaptor<SendMessageRequest> captor = ArgumentCaptor.forClass(SendMessageRequest.class);
        verify(sqsClient, times(1)).sendMessage(captor.capture());

        JsonNode root = new ObjectMapper().readTree(captor.getValue().messageBody());

        JsonNode consentsNode = root.get("customerDetails").get("consents");
        assertEquals(3, consentsNode.size());
        assertEquals("TERMS", consentsNode.get(0).get("key").asText());
        assertEquals("PRIVACY", consentsNode.get(1).get("key").asText());
        assertEquals("MARKETING", consentsNode.get(2).get("key").asText());
    }

         
    // SQS EXCEPTION TEST
         
    @Test
    void storeConsentData_shouldHandleSqsExceptionGracefully() {

        Profile profile = Profile.builder()
                .panNumber("ABCDE1234F")
                .firstName("Arijit")
                .lastName("Bhattacharjee")
                .dob("10-05-2000")
                .build();

        JourneyData journeyData = JourneyData.builder()
                .mobileNumber("8753785686")
                .isd("+91")
                .journeyId("JOURNEY-123")
                .journeyName("TEST_JOURNEY")
                .profile(profile)
                .build();

        CustomerConsentRequest consent = CustomerConsentRequest.builder()
                .key("TERMS_AND_CONDITIONS")
                .acceptance(true)
                .build();

        List<CustomerConsentRequest> consents = List.of(consent);

        when(consentsApiProperties.getQueueUrl())
                .thenReturn("https://test-queue");

        when(sqsClient.sendMessage(any(SendMessageRequest.class)))
                .thenThrow(new IllegalStateException("SQS unavailable"));

        assertDoesNotThrow(() ->
                consentService.storeConsentsData(consents, journeyData)
        );

        verify(sqsClient, times(1)).sendMessage(any(SendMessageRequest.class));
    }

    @Test
    void storeConsentsData_shouldPublishEmptyConsentList() throws Exception {
        JourneyData journeyData = JourneyData.builder()
                .journeyId("JOURNEY-EMPTY")
                .journeyName("TEST_JOURNEY")
                .isd("+91")
                .mobileNumber("9000000000")
                .profile(Profile.builder().firstName("Customer").build())
                .build();
        when(consentsApiProperties.getQueueUrl()).thenReturn("https://test-queue");
        when(sqsClient.sendMessage(any(SendMessageRequest.class)))
                .thenReturn(SendMessageResponse.builder().messageId("empty-consents").build());

        consentService.storeConsentsData(List.of(), journeyData);

        ArgumentCaptor<SendMessageRequest> captor = ArgumentCaptor.forClass(SendMessageRequest.class);
        verify(sqsClient).sendMessage(captor.capture());
        JsonNode details = new ObjectMapper().readTree(captor.getValue().messageBody())
                .get("customerDetails");
        assertTrue(details.get("consents").isArray());
        assertEquals(0, details.get("consents").size());
    }
}
