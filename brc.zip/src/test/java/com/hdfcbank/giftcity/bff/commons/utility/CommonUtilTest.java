package com.hdfcbank.giftcity.bff.commons.utility;

import com.hdfcbank.giftcity.bff.commons.constant.CommonConstants;
import org.junit.jupiter.api.Test;

import java.nio.charset.Charset;
import java.security.MessageDigest;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;

class CommonUtilTest {

    // generateSHA1()
    @Test
    void testGenerateSHA1() throws Exception {
        byte[] result = CommonUtil.generateSHA1("test");

        MessageDigest sha = MessageDigest.getInstance("SHA-256");
        sha.update("test".getBytes(Charset.defaultCharset()));

        assertArrayEquals(sha.digest(), result);

        // extra assertions
        assertNotNull(result);
        assertEquals(32, result.length);   // SHA‑256 → 32 bytes
    }

    // generateRefNumber()
    @Test
    void testGenerateRefNumber() {
        String ref = CommonUtil.generateRefNumber("PC");

        assertTrue(ref.startsWith("PC"));
        assertTrue(ref.length() > 10);

        // extra assertions
        assertNotNull(ref);
        assertFalse(ref.isBlank());
        assertTrue(ref.matches("PC.*"));
    }

    // getFormattedDate()
    @Test
    void testGetFormattedDateDefault() {
        LocalDate d = CommonUtil.getFormattedDate("20240115");
        assertEquals(LocalDate.of(2024, 1, 15), d);

        // extra assertions
        assertNotNull(d);
    }

    @Test
    void testGetFormattedDatePattern() {
        LocalDate d = CommonUtil.getFormattedDate("15-01-2024", "dd-MM-yyyy");
        assertEquals(LocalDate.of(2024, 1, 15), d);

        assertNotNull(d);
    }

    // localDateToString()
    @Test
    void testLocalDateToString() {
        String s = CommonUtil.localDateToString(LocalDate.of(2024, 1, 15), "dd/MM/yyyy");
        assertEquals("15/01/2024", s);

        // extra assertions
        assertNotNull(s);
        assertTrue(s.matches("\\d{2}/\\d{2}/\\d{4}"));
    }

    // stringToLocalDate()
    @Test
    void testStringToLocalDate() {
        LocalDate date = CommonUtil.stringToLocalDate("2024-01-15", "yyyy-MM-dd");
        assertEquals(LocalDate.of(2024, 1, 15), date);

        assertNotNull(date);
    }

    // changeDateFormat()
    @Test
    void testChangeDateFormat() {
        String s = CommonUtil.changeDateFormat("20240115", "yyyyMMdd", "dd/MM/yyyy");
        assertEquals("15/01/2024", s);

        assertNotNull(s);
    }

    // stringToLocalTime()
    @Test
    void testStringToLocalTime() {
        LocalTime t = CommonUtil.stringToLocalTime("134500", "HHmmss");
        assertEquals(LocalTime.of(13, 45, 0), t);

        assertNotNull(t);
        assertEquals(13, t.getHour());
        assertEquals(45, t.getMinute());
    }

    // getMaskString()
    @Test
    void testGetMaskStringSimple() {
        assertEquals("***def", CommonUtil.getMaskString("abcdef", 3));

        // extra assertions
        assertEquals(6, CommonUtil.getMaskString("abcdef", 3).length());
    }

    @Test
    void testGetMaskStringWithStartAndPlace() {
        assertEquals("ab**ef", CommonUtil.getMaskString("abcdef", 2, 2));

        // extra assertions
        assertEquals("abcdef".length(), CommonUtil.getMaskString("abcdef", 2, 2).length());
    }

    @Test
    void testGetMaskStringWithNull() {
        assertNull(CommonUtil.getMaskString(null, 2, 3));
    }

    @Test
    void testGetMaskStringWithEmpty() {
        assertEquals("", CommonUtil.getMaskString("", 2, 3));
    }

    @Test
    void testMaskPanShort() {
        assertEquals("1234", CommonUtil.maskPan("1234"));

        // extra assertions
        assertEquals(4, CommonUtil.maskPan("1234").length());
    }

    // maskAndBatch()
    @Test
    void testMaskAndBatch() {
        String masked = CommonUtil.maskAndBatch("ABCDEFGH", 2, 2);

        String expected =
                "******GH".substring(0, 2) + " " +
                        "******GH".substring(2, 4) + " " +
                        "******GH".substring(4, 6) + " " +
                        "******GH".substring(6);

        assertEquals(expected, masked);

        // extra assertions
        assertNotNull(masked);
        assertTrue(masked.contains(" "));
    }

    // formatDate()
    @Test
    void testFormatDate() {
        Date d = new Date(0);
        String formatted = CommonUtil.formatDate(d, "dd/MM/yyyy");

        assertEquals("01/01/1970", formatted);

        assertTrue(formatted.matches("\\d{2}/\\d{2}/\\d{4}"));
    }

    // encode()
    @Test
    void testEncode() {
        String encoded = CommonUtil.encode("a\nb\rc\t");
        assertEquals("a_b_c_", encoded);

        // extra assertions
        assertFalse(encoded.contains("\n"));
        assertFalse(encoded.contains("\r"));
        assertFalse(encoded.contains("\t"));
    }

    // formatDob()
    @Test
    void testFormatDobValid() {
        assertEquals("15/01/2024", CommonUtil.formatDob("2024-01-15"));
    }

    @Test
    void testFormatDobInvalid() {
        assertEquals("abc", CommonUtil.formatDob("abc"));
    }

    // formatPassportDob()
    @Test
    void testFormatPassportDobISO() {
        assertEquals("15/01/2024", CommonUtil.formatPassportDob("2024-01-15"));
    }

    @Test
    void testFormatPassportDobYYYYMMDD() {
        assertEquals("15/01/2024", CommonUtil.formatPassportDob("20240115"));
    }

    @Test
    void testFormatPassportDobInvalid() {
        assertEquals("xxx", CommonUtil.formatPassportDob("xxx"));
    }

    // maskMobile()
    @Test
    void testMaskMobile() {
        assertEquals("12******56", CommonUtil.maskMobile("1234567856"));

        // extra assertions
        assertEquals(10, CommonUtil.maskMobile("1234567856").length());
    }

    @Test
    void testMaskMobileShort() {
        assertEquals("1234", CommonUtil.maskMobile("1234"));
    }

    @Test
    void testMaskMobileWithIsdShort() {
        assertEquals("+91123", CommonUtil.maskMobile("123", "+91"));
    }

    // maskEmail()
    @Test
    void testMaskEmailNoAt() {
        assertEquals("abc", CommonUtil.maskEmail("abc", 2, 2));
    }

    @Test
    void testMaskEmailNegative() {
        assertThrows(IllegalArgumentException.class,
                () -> CommonUtil.maskEmail("a@test.com", -1, 2));
    }

    @Test
    void testMaskEmail() {
        assertEquals("ar**it@test.com",
                CommonUtil.maskEmail("arijit@test.com", 2, 2));
    }

    // getValue()
    @Test
    void testGetValue() {
        Map<String, String> map = Map.of("x", "y");
        assertEquals("y", CommonUtil.getValue(map, "x"));

        // extra assertions
        assertNull(CommonUtil.getValue(map, "missing"));
    }

    @Test
    void testGetValueNullMap() {
        assertNull(CommonUtil.getValue(null, "x"));
    }

    // getEmailTemplateId()
    @Test
    void testGetEmailTemplateId() {
        Map<String, String> map = new HashMap<>();
        map.put(CommonConstants.FIRST_REMINDER_DAY, "1");
        map.put(CommonConstants.SECOND_REMINDER_DAY, "2");
        map.put(CommonConstants.THIRD_REMINDER_DAY, "3");

        assertEquals(CommonConstants.FIRST_REM_MAIL_TEMPLATE,
                CommonUtil.getEmailTemplateId(1, map));
        assertEquals(CommonConstants.SECOND_REM_MAIL_TEMPLATE,
                CommonUtil.getEmailTemplateId(2, map));
        assertEquals(CommonConstants.THIRD_REM_MAIL_TEMPLATE,
                CommonUtil.getEmailTemplateId(3, map));

        assertNull(CommonUtil.getEmailTemplateId(99, map));

        // extra assertions
        assertNotNull(map);
    }

    // getSmsTemplateId()
    @Test
    void testGetSmsTemplateId() {
        Map<String, String> map = new HashMap<>();
        map.put(CommonConstants.FIRST_REMINDER_DAY, "1");
        map.put(CommonConstants.SECOND_REMINDER_DAY, "2");
        map.put(CommonConstants.THIRD_REMINDER_DAY, "3");

        assertEquals(CommonConstants.FIRST_REM_SMS_TEMPLATE,
                CommonUtil.getSmsTemplateId(1, map));
        assertEquals(CommonConstants.SECOND_REM_SMS_TEMPLATE,
                CommonUtil.getSmsTemplateId(2, map));
        assertEquals(CommonConstants.THIRD_REM_SMS_TEMPLATE,
                CommonUtil.getSmsTemplateId(3, map));

        assertNull(CommonUtil.getSmsTemplateId(99, map));
    }

    // isReminderDay()
    @Test
    void testIsReminderDay() {
        Map<String, String> map = new HashMap<>();
        map.put(CommonConstants.FIRST_REMINDER_DAY, "1");
        map.put(CommonConstants.SECOND_REMINDER_DAY, "2");
        map.put(CommonConstants.THIRD_REMINDER_DAY, "3");

        assertTrue(CommonUtil.isReminderDay(1, map));
        assertTrue(CommonUtil.isReminderDay(2, map));
        assertTrue(CommonUtil.isReminderDay(3, map));
        assertFalse(CommonUtil.isReminderDay(5, map));
    }

    // maskAddress()
    @Test
    void testMaskAddress() {
        assertEquals("1234567890*****", CommonUtil.maskAddress("1234567890ABCDE"));

        // extra assertions
        assertTrue(CommonUtil.maskAddress("1234567890ABCDE").startsWith("1234567890"));
    }

    @Test
    void testMaskAddressShort() {
        assertEquals("abc", CommonUtil.maskAddress("abc"));
    }

    @Test
    void testMaskAddressBlank() {
        assertEquals("", CommonUtil.maskAddress(""));
    }

    @Test
    void testMaskAddressLinesEmpty() {
        String[] result = CommonUtil.maskAddressLines("", "");
        assertEquals("", result[0]);
        assertEquals("", result[1]);

        // extra assertions
        assertEquals(2, result.length);
    }

    @Test
    void testMaskAddressLinesOneEmpty() {
        String[] result = CommonUtil.maskAddressLines("ABC", "");

        String expectedMasked = CommonUtil.maskAddress("ABC");

        assertEquals(expectedMasked.substring(0, 3), result[0]);
        assertEquals(expectedMasked.length() > 3 ? expectedMasked.substring(3) : "", result[1]);

        assertEquals(2, result.length);
    }

    @Test
    void testMaskMobileWithIsd() {
        assertEquals("+91**3456", CommonUtil.maskMobile("123456", "+91"));
    }

    // mask()
    @Test
    void testMask() {
        assertEquals("******3456", CommonUtil.mask("1234563456", 4));
    }

    @Test
    void testMaskPanNormal() {
        assertEquals("12******56", CommonUtil.maskPan("1234563456"));
    }

    @Test
    void testMaskAddressLines() {
        String[] result = CommonUtil.maskAddressLines("12345", "67890");
        assertEquals("12345", result[0]);
        assertEquals("67890", result[1]);

        assertEquals(2, result.length);
    }
}