package com.hdfcbank.giftcity.bff.communication;

import com.hdfcbank.adapters.vo.GenerateOtpRequest;
import com.hdfcbank.adapters.vo.VerifyOtpRequest;
import com.hdfcbank.giftcity.bff.commons.utility.TextSanityUtil;
import com.hdfcbank.giftcity.bff.communication.mapper.CommunicationMapper;
import com.hdfcbank.giftcity.bff.customer.config.CustomerApiProperties;
import com.hdfcbank.giftcity.bff.customer.model.ValidateCustomerRequest;
import com.hdfcbank.giftcity.bff.customer.utility.CustomerUtil;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.MockedStatic;

import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class CommunicationMapperTest {

    private CustomerApiProperties customerApiProperties;
    private CustomerApiProperties.ApiDetails apiDetails;

    private CommunicationMapper mapper;

    @BeforeEach
    void setUp() {
        customerApiProperties = mock(CustomerApiProperties.class);
        apiDetails = mock(CustomerApiProperties.ApiDetails.class);

        when(customerApiProperties.getGenerateAndDispatchOtp()).thenReturn(apiDetails);

        mapper = new CommunicationMapper(customerApiProperties);
    }

      
    //   TEST 1 — toGenerateOtpRequest()
      
    @Test
    void testToGenerateOtpRequest() {

        Map<String, String> defaults = Map.of(
                "messageType", "SMS",
                "channel", "MOBILE"
        );

        when(apiDetails.getServiceDefaults()).thenReturn(defaults);

        try (MockedStatic<TextSanityUtil> textMock = mockStatic(TextSanityUtil.class);
             MockedStatic<CustomerUtil> customerMock = mockStatic(CustomerUtil.class)) {

            // sanitizers
            textMock.when(() -> TextSanityUtil.sanitize("9999999999")).thenReturn("9999999999");
            customerMock.when(() -> CustomerUtil.sanitizeEmail("test@mail.com")).thenReturn("test@mail.com");

            textMock.when(() -> TextSanityUtil.sanitize("SMS")).thenReturn("SMS");
            textMock.when(() -> TextSanityUtil.sanitize("template123")).thenReturn("template123");
            textMock.when(() -> TextSanityUtil.sanitize("MOBILE")).thenReturn("MOBILE");

            GenerateOtpRequest req = mapper.toGenerateOtpRequest(
                    "9999999999",
                    "test@mail.com",
                    "template123"
            );

            assertEquals("9999999999", req.getMobileNumber());
            assertEquals("test@mail.com", req.getEmailId());
            assertEquals("SMS", req.getMessageType());
            assertEquals("template123", req.getTemplateId());
            assertEquals("MOBILE", req.getChannel());
        }
    }

      
    //   TEST 2 — toVerifyOtpRequest()
      
    @Test
    void testToVerifyOtpRequest() {

        ValidateCustomerRequest validateRequest = ValidateCustomerRequest.builder()
                .otp("123456")
                .txnRef("TXN001")
                .consents(List.of())
                .build();

        Map<String, String> defaults = Map.of(
                "messageType", "EMAIL",
                "channel", "WEB"
        );

        try (MockedStatic<TextSanityUtil> textMock = mockStatic(TextSanityUtil.class);
             MockedStatic<CustomerUtil> customerMock = mockStatic(CustomerUtil.class)) {

            customerMock.when(() -> CustomerUtil.sanitizeOtp("123456")).thenReturn("123456");

            textMock.when(() -> TextSanityUtil.sanitize("EMAIL")).thenReturn("EMAIL");
            textMock.when(() -> TextSanityUtil.sanitize("WEB")).thenReturn("WEB");
            textMock.when(() -> TextSanityUtil.sanitize("TXN001")).thenReturn("TXN001");

            VerifyOtpRequest req = mapper.toVerifyOtpRequest(validateRequest, defaults);

            assertEquals("123456", req.getOtpValue());
            assertEquals("EMAIL", req.getMessageType());
            assertEquals("WEB", req.getChannel());
            assertEquals("TXN001", req.getTxnRef());
        }
    }
}
