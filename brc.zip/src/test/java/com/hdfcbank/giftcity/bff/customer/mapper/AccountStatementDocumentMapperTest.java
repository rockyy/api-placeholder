package com.hdfcbank.giftcity.bff.customer.mapper;

import com.hdfcbank.adapters.vo.GenerateDocumentRequest;
import com.hdfcbank.common.models.vo.journey.JourneyData;
import com.hdfcbank.giftcity.bff.commons.model.FcIndiaProfile;
import com.hdfcbank.giftcity.bff.customer.constants.CustomerConstants;
import com.hdfcbank.giftcity.bff.customer.model.AccountStatementDocData;
import com.hdfcbank.giftcity.bff.customer.utility.CustomerUtil;
import com.hdfcbank.service.adapters.vo.account.ViewAccountStatementRequest;
import com.hdfcbank.service.adapters.vo.account.ViewAccountStatementResponse;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import org.mapstruct.factory.Mappers;
import org.mockito.MockedStatic;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class AccountStatementDocumentMapperTest {

    private AccountStatementDocumentMapper mapper;

    private JourneyData journeyData;
    private FcIndiaProfile.CustomerAccountDetail acc;
    private ViewAccountStatementResponse.ViewAccountStatementData stmt;

    @BeforeEach
    void setup() {
        mapper = Mappers.getMapper(AccountStatementDocumentMapper.class);

        journeyData = JourneyData.builder()
                .journeyId("J123")
                .profile(null)
                .build();

        acc = FcIndiaProfile.CustomerAccountDetail.builder()
                .accountNumber("AC001")
                .customerId("CUST01")
                .branchName("Branch X")
                .branchAddressLine1("Addr1")
                .branchAddressLine2("Addr2")
                .branchAddressLine3("Addr3")
                .branchTelNo("9999")
                .branchCity("CityX")
                .branchState("StateX")
                .ifscCode("IFSC001")
                .branchCode("BR001")
                .prodTypeDesc("Savings")
                .amountODLimit(100)
                .datAcctOpen("01-01-2020")
                .accountStatus("ACTIVE")
                .build();

        stmt = ViewAccountStatementResponse.ViewAccountStatementData.builder()
                .currency("INR")
                .closingBal(new BigDecimal("1000"))
                .transactions(
                        Arrays.asList(
                                ViewAccountStatementResponse.Transaction.builder()
                                        .amount(new BigDecimal("50"))
                                        .codeDebitCredit(CustomerConstants.DEBIT)
                                        .transactionDate("10/09/2024")
                                        .description("ATM Withdrawal")
                                        .chequeNumber("CH001")
                                        .valueDate("11/09/2024")
                                        .build(),
                                ViewAccountStatementResponse.Transaction.builder()
                                        .amount(new BigDecimal("150"))
                                        .codeDebitCredit(CustomerConstants.CREDIT)
                                        .transactionDate("12/09/2024")
                                        .description("Salary Credit")
                                        .chequeNumber("CH002")
                                        .valueDate("13/09/2024")
                                        .build()
                        )
                )
                .build();
    }

    // Test: toViewAccountStatementRequest()
    @Test
    void testToViewAccountStatementRequest() {
        int statementDays = 30;

        ViewAccountStatementRequest req =
                mapper.toViewAccountStatementRequest(journeyData, acc, "ALL", statementDays);

        assertNotNull(req);
        assertEquals("AC001", req.getAccountNumber());
        assertEquals("CUST01", req.getCustomerId());
        assertEquals("ALL", req.getTxnType());
        assertNotNull(req.getDateStmtFrom());
        assertNotNull(req.getDateStmtTo());
    }

    // Test: toAccountStatementDocumentRequest()
    @Test
    void testToAccountStatementDocumentRequest() {

        try (MockedStatic<CustomerUtil> mocked = mockStatic(CustomerUtil.class)) {

            mocked.when(() -> CustomerUtil.getPrimaryProfile(journeyData))
                    .thenReturn(Optional.empty());

            Map<String, String> nominationMap = new HashMap<>();
            nominationMap.put("ADDR_TYPE", "NominationName");

            GenerateDocumentRequest<AccountStatementDocData> req =
                    mapper.toAccountStatementDocumentRequest(
                            journeyData,
                            acc,
                            stmt,
                            1,
                            2,
                            30,
                            nominationMap
                    );

            assertNotNull(req);
            assertEquals(CustomerConstants.TIF, req.getGenerateType());
            assertEquals(CustomerConstants.ATTACHMENT, req.getResponseType());
            assertEquals(CustomerConstants.ACCOUNT_STATEMENT_TEMPLATE, req.getTemplateId());
            assertTrue(req.getTargetFileName().contains("J123"));
            assertTrue(req.getTargetFileName().startsWith(CustomerConstants.ACCOUNT_STATEMENT_PREFIX));
        }
    }

    // Test: buildFileName()
    @Test
    void testBuildFileName() {
        String result = mapper.buildFileName(journeyData, 3, 4);
        assertEquals("ACCOUNT_STATEMENT_3_4_J123.tif", result);
    }

    // Test: toTransaction()
    @Test
    void testToTransaction() {
        ViewAccountStatementResponse.Transaction t =
                ViewAccountStatementResponse.Transaction.builder()
                        .amount(new BigDecimal("75"))
                        .codeDebitCredit(CustomerConstants.DEBIT)
                        .transactionDate("20/09/2024")
                        .description("Test Debit")
                        .chequeNumber("CH123")
                        .valueDate("21/09/2024")
                        .build();

        AccountStatementDocData.TransactionData result = mapper.toTransaction(t);

        assertNotNull(result);
        assertEquals("20/09/2024", result.getTxnDate());
        assertEquals("Test Debit", result.getNarration());
        assertEquals("CH123", result.getChequeRefNo());
        assertEquals("21/09/2024", result.getValueDate());
        assertEquals(new BigDecimal("75"), result.getWithdrawalAmount());
        assertNull(result.getDepositAmount());
    }

    // Test: buildBranchAddress()
    @Test
    void testBuildBranchAddress() {
        String address = mapper.buildBranchAddress(acc);
        assertEquals("Addr1, Addr2, Addr3", address);
    }

    // Test: buildStatementFromDate()
    @Test
    void testBuildStatementFromDate() {
        String date = mapper.buildStatementFromDate(10);
        LocalDate expected = LocalDate.now().minusDays(10);
        assertEquals(expected.format(CustomerConstants.DD_MM_YYYY_FORMATTER), date);
    }

    // Test: buildCurrentDate()
    @Test
    void testBuildCurrentDate() {
        String date = mapper.buildCurrentDate();
        LocalDate expected = LocalDate.now();
        assertEquals(expected.format(CustomerConstants.DD_MM_YYYY_FORMATTER), date);
    }

    // Test: toAccountDetails()
    @Test
    void testToAccountDetails() {

        FcIndiaProfile.Profile primary = FcIndiaProfile.Profile.builder()
                .mailingCity("CityX")
                .mailingState("StateX")
                .mailingPinCode("123456")
                .build();

        try (MockedStatic<CustomerUtil> mocked = mockStatic(CustomerUtil.class)) {

            mocked.when(() -> CustomerUtil.getPrimaryProfile(journeyData))
                    .thenReturn(Optional.of(primary));

            Map<String, String> nominationMap = new HashMap<>();
            nominationMap.put("ADDR_TYPE", "NomineeMappedValue");

            AccountStatementDocData.AccountDetails details =
                    mapper.toAccountDetails(journeyData, acc, stmt, 30, nominationMap);

            assertNotNull(details);
            assertEquals("Branch X", details.getBranchName());
            assertEquals("Addr1, Addr2, Addr3", details.getBranchAddress());
            assertEquals("CityX", details.getCustomerCity());
            assertEquals("StateX", details.getCustomerState());
            assertEquals("ACTIVE", details.getAccountStatus());
            assertEquals("01-01-2020", details.getAccountOpenDate());
            assertNotNull(details.getDateStmtFrom());
            assertNotNull(details.getDateStmtTo());
        }
    }

// Test: getCustomerName()
    @Test
    void testGetCustomerName() {

        FcIndiaProfile.Profile profile = FcIndiaProfile.Profile.builder()
                .name("Customer X")
                .build();

        try (MockedStatic<CustomerUtil> mocked = mockStatic(CustomerUtil.class)) {
            mocked.when(() -> CustomerUtil.getPrimaryProfile(journeyData))
                    .thenReturn(Optional.of(profile));

            String name = mapper.getCustomerName(journeyData);
            assertEquals("Customer X", name);
        }
    }

// Test: getWithdrawalAmount() & getDepositAmount()
    @Test
    void testWithdrawalAndDepositAmounts() {

        ViewAccountStatementResponse.Transaction debitTxn =
                ViewAccountStatementResponse.Transaction.builder()
                        .codeDebitCredit(CustomerConstants.DEBIT)
                        .amount(new BigDecimal("500"))
                        .build();

        ViewAccountStatementResponse.Transaction creditTxn =
                ViewAccountStatementResponse.Transaction.builder()
                        .codeDebitCredit(CustomerConstants.CREDIT)
                        .amount(new BigDecimal("750"))
                        .build();

        assertEquals(new BigDecimal("500"), mapper.getWithdrawalAmount(debitTxn));
        assertNull(mapper.getWithdrawalAmount(creditTxn));

        assertEquals(new BigDecimal("750"), mapper.getDepositAmount(creditTxn));
        assertNull(mapper.getDepositAmount(debitTxn));
    }

// Test: buildCustomerAddress()
    @Test
    void testBuildCustomerAddress() {

        FcIndiaProfile.Profile profile = FcIndiaProfile.Profile.builder()
                .mailingAddress1("Line1")
                .mailingAddress2("Line2")
                .mailingAddress3("Line3")
                .build();

        try (MockedStatic<CustomerUtil> mocked = mockStatic(CustomerUtil.class)) {
            mocked.when(() -> CustomerUtil.getPrimaryProfile(journeyData))
                    .thenReturn(Optional.of(profile));

            String result = mapper.buildCustomerAddress(journeyData);
            assertEquals("Line1, Line2, Line3", result);
        }
    }

// Test: getNomination()
    @Test
    void testGetNomination() {

        FcIndiaProfile.CustomerFATCADetail fatca = new FcIndiaProfile.CustomerFATCADetail();
        fatca.setAddrTyp("ADDR_TYPE");

        FcIndiaProfile.Profile profile = FcIndiaProfile.Profile.builder()
                .customerFATCADetails(List.of(fatca))
                .build();

        Map<String, String> nominationMap = new HashMap<>();
        nominationMap.put("ADDR_TYPE", "NomineeValue");

        try (MockedStatic<CustomerUtil> mocked = mockStatic(CustomerUtil.class)) {
            mocked.when(() -> CustomerUtil.getPrimaryProfile(journeyData))
                    .thenReturn(Optional.of(profile));

            String result = mapper.getNomination(journeyData, nominationMap);
            assertEquals("NomineeValue", result);
        }
    }

// Test: getPrimaryProfile()
    @Test
    void testGetPrimaryProfile() {

        FcIndiaProfile.Profile profile = FcIndiaProfile.Profile.builder()
                .name("Primary Profile")
                .build();

        try (MockedStatic<CustomerUtil> mocked = mockStatic(CustomerUtil.class)) {
            mocked.when(() -> CustomerUtil.getPrimaryProfile(journeyData))
                    .thenReturn(Optional.of(profile));

            Optional<FcIndiaProfile.Profile> result = mapper.getPrimaryProfile(journeyData);

            assertTrue(result.isPresent());
            assertEquals("Primary Profile", result.get().getName());
        }
    }
    }