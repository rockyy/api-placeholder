package com.hdfcbank.giftcity.bff.commons.config;

import com.hdfcbank.giftcity.bff.consent.config.AwsProperties;
import com.hdfcbank.giftcity.bff.consent.config.ConsentsApiProperties;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.sqs.SqsClient;

import java.lang.reflect.Field;
import java.net.URI;

import static org.junit.jupiter.api.Assertions.*;

class SqsConfigTest {

    private SqsConfig sqsConfig;

    private AwsProperties awsProperties;
    private ConsentsApiProperties consentsApiProperties;

    private String customerValidateQueueUrl;
    private String submitQueueUrl;
    private String backgroundTasksQueueFifo;

    @BeforeEach
    void setUp() throws Exception {

        awsProperties = new AwsProperties();
        awsProperties.setRegion("ap-south-1");

        consentsApiProperties = new ConsentsApiProperties();
        consentsApiProperties.setQueueUrl("https://sqs.local/consents");

        customerValidateQueueUrl = "https://sqs.local/customer-validate";
        submitQueueUrl = "https://sqs.local/application-submit";
        backgroundTasksQueueFifo = "https://sqs.local/background.fifo";

        sqsConfig = new SqsConfig();

        injectPrivate("awsProperties", awsProperties);
        injectPrivate("consentsApiProperties", consentsApiProperties);
        injectPrivate("customerValidateQueUrl", customerValidateQueueUrl);
        injectPrivate("submitQueueUrl", submitQueueUrl);
        injectPrivate("backgroundTasksQueueFifo", backgroundTasksQueueFifo);
    }

    private void injectPrivate(String fieldName, Object value) throws Exception {
        Field field = SqsConfig.class.getDeclaredField(fieldName);
        field.setAccessible(true);
        field.set(sqsConfig, value);
    }

    @Test
    void testCustomerValidateBean() {
        SqsClient client = sqsConfig.customerValidate();
        assertNotNull(client);

        assertEquals(Region.of("ap-south-1"), client.serviceClientConfiguration().region());
        assertEquals(URI.create(customerValidateQueueUrl), client.serviceClientConfiguration().endpointOverride().get());
    }

    @Test
    void testApplicationSubmitBean() {
        SqsClient client = sqsConfig.applicationSubmit();
        assertNotNull(client);

        assertEquals(Region.of("ap-south-1"), client.serviceClientConfiguration().region());
        assertEquals(URI.create(submitQueueUrl), client.serviceClientConfiguration().endpointOverride().get());
    }

    @Test
    void testBackgroundTasksSqsClient() {
        SqsClient client = sqsConfig.backgroundTasksSqsClient();
        assertNotNull(client);

        assertEquals(Region.of("ap-south-1"), client.serviceClientConfiguration().region());
        assertEquals(URI.create(backgroundTasksQueueFifo), client.serviceClientConfiguration().endpointOverride().get());
    }

    @Test
    void testConsentsSqsClient() {
        SqsClient client = sqsConfig.sqsClient();
        assertNotNull(client);

        assertEquals(Region.of("ap-south-1"), client.serviceClientConfiguration().region());
        assertEquals(URI.create(consentsApiProperties.getQueueUrl()), client.serviceClientConfiguration().endpointOverride().get());
    }
}
