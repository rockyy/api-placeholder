package com.hdfcbank.giftcity.bff.application.handlers.background;

import com.hdfcbank.common.models.vo.core.ApiResponseStatus;
import com.hdfcbank.common.models.vo.journey.JourneyData;
import com.hdfcbank.common.models.vo.journey.JourneyDetail;
import com.hdfcbank.common.models.vo.journey.JourneyState;
import com.hdfcbank.common.models.vo.journey.Profile;
import com.hdfcbank.giftcity.bff.application.mapper.FTSAccountOpeningMapper;
import com.hdfcbank.giftcity.bff.commons.enums.CommonJourneyStates;
import com.hdfcbank.giftcity.bff.commons.exception.handler.DownstreamResponseHandler;
import com.hdfcbank.giftcity.bff.commons.handler.Handler;
import com.hdfcbank.giftcity.bff.commons.handler.HandlerContext;
import com.hdfcbank.giftcity.bff.commons.handler.HandlerResult;
import com.hdfcbank.giftcity.bff.commons.model.FtsDetails;
import com.hdfcbank.giftcity.bff.customer.config.CustomerApiProperties;
import com.hdfcbank.giftcity.bff.infrastructure.service.JourneyService;
import com.hdfcbank.service.adapters.clients.feign.account.AccountServiceFeignClient;
import com.hdfcbank.service.adapters.vo.account.FTSAccountOpeningApiResponse;
import com.hdfcbank.service.adapters.vo.account.FTSAccountOpeningRequest;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.*;

import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

// -------- LOG SUPPRESSION ----------
import ch.qos.logback.classic.Logger;
import ch.qos.logback.classic.Level;
import org.slf4j.LoggerFactory;

@ExtendWith(MockitoExtension.class)
class FTSAccountOpeningHandlerTest {

    @Mock private AccountServiceFeignClient feignClient;
    @Mock private FTSAccountOpeningMapper mapper;
    @Mock private JourneyService journeyService;
    @Mock private CustomerApiProperties customerApiProperties;
    @Mock private CustomerApiProperties.AOFDetails aofDetails;

    @InjectMocks
    private FTSAccountOpeningHandler handler;

    private JourneyData journeyData;
    private HandlerContext handlerContext;
    private FtsDetails ftsDetails;

    // ---------------- SUPPRESS ALL HANDLER LOGS ----------------
    @BeforeEach
    void suppressLogs() {
        Logger logger = (Logger) LoggerFactory.getLogger(FTSAccountOpeningHandler.class);
        logger.setLevel(Level.OFF);   // disable ALL logging for this class
    }

    @BeforeEach
    void setup() {
        journeyData = new JourneyData();
        journeyData.setJourneyId("J123");
        journeyData.setJourneyName("GiftFTS");
        journeyData.setProfile(new Profile());

        JourneyDetail detail = new JourneyDetail();
        detail.setJourneyStates(List.of(
                JourneyState.builder().stateName("DPCFTP_UPLOAD_SUCCESS").build()
        ));
        detail.setSystemData(new HashMap<>());
        journeyData.setJourneyDetail(detail);

        handlerContext = HandlerContext.builder()
                .journeyData(journeyData)
                .data(new HashMap<>())
                .properties(new HashMap<>())
                .build();

        ftsDetails = new FtsDetails();
        ftsDetails.setCustomerSignatureDocRef("SIG123");
        ftsDetails.setAofWithAnnextureDocRef("AOF123");
        ftsDetails.setAccountStatement1DocRef(List.of("DOC1"));
        ftsDetails.setAccountStatement2DocRef(List.of("DOC2"));
        ftsDetails.setAccountStatement1UploadedFiles(List.of("UP1"));
        ftsDetails.setAccountStatement2UploadedFiles(List.of("UP2"));

        lenient().when(customerApiProperties.getAofDetails()).thenReturn(aofDetails);
        lenient().when(aofDetails.getSigImagePath()).thenReturn("/sig");
        lenient().when(aofDetails.getAofImagePath()).thenReturn("/aof");
    }

    // ---------------- PRECONDITIONS ------------------
    @Test
    void testPreConditionsTrue() {
        assertTrue(handler.preConditions(handlerContext));
    }

    @Test
    void testPreConditionsFalse() {
        journeyData.getJourneyDetail().setJourneyStates(List.of(
                JourneyState.builder().stateName("DPCFTP_UPLOAD_SUCCESS").build(),
                JourneyState.builder().stateName("FTS_AOF_POSTED_SUCCESS").build()
        ));
        assertFalse(handler.preConditions(handlerContext));
    }

    // ---------------- SUCCESS FLOW ------------------
    @Test
    void testHandleSuccess() {

        try (MockedStatic<JourneyService> msJourney = mockStatic(JourneyService.class);
             MockedStatic<DownstreamResponseHandler> msDS = mockStatic(DownstreamResponseHandler.class)) {

            msJourney.when(() -> JourneyService.extractFromJourney(any(), any(), any()))
                    .thenReturn(Optional.ofNullable(ftsDetails));

            msDS.when(() -> DownstreamResponseHandler.handleResponse(
                    any(), anyString(), anyBoolean(), anyString()
            )).thenReturn(null);

            FTSAccountOpeningApiResponse apiResp = new FTSAccountOpeningApiResponse();

            FTSAccountOpeningApiResponse.ResponseString rs =
                    FTSAccountOpeningApiResponse.ResponseString.builder()
                            .status("Success")
                            .acknowledgementNo("ACK123")
                            .build();

            FTSAccountOpeningApiResponse.ResponseData data =
                    FTSAccountOpeningApiResponse.ResponseData.builder()
                            .responseString(rs)
                            .build();

            apiResp.setData(data);

            when(mapper.toFTSAccountOpeningRequest(any(), any(), any(), any()))
                    .thenReturn(new FTSAccountOpeningRequest());

            when(feignClient.accountOpening(anyString(), any()))
                    .thenReturn(apiResp);

            HandlerResult<FTSAccountOpeningApiResponse> result =
                    handler.handle(handlerContext);

            assertTrue(result.isSuccess());
            assertEquals(apiResp, result.getResult());

            verify(journeyService).updateJourney(
                    eq("J123"),
                    eq("FtsDetails"),
                    any(FtsDetails.class),
                    eq(CommonJourneyStates.FTS_AOF_POSTED_SUCCESS)
            );
        }
    }

    // ---------------- FAILURE FLOW ------------------
    @Test
    void testHandleFailure() {

        try (MockedStatic<JourneyService> msJourney = mockStatic(JourneyService.class);
             MockedStatic<DownstreamResponseHandler> msDS = mockStatic(DownstreamResponseHandler.class)) {

            msJourney.when(() -> JourneyService.extractFromJourney(any(), any(), any()))
                    .thenReturn(Optional.ofNullable(ftsDetails));

            msDS.when(() -> DownstreamResponseHandler.handleResponse(
                    any(), anyString(), anyBoolean(), anyString()
            )).thenReturn(null);

            FTSAccountOpeningApiResponse apiResp = new FTSAccountOpeningApiResponse();

            ApiResponseStatus apiStatus = new ApiResponseStatus();
            apiStatus.setCode("ERR500");
            apiResp.setStatus(apiStatus);

            FTSAccountOpeningApiResponse.Status nestedStatus =
                    FTSAccountOpeningApiResponse.Status.builder()
                            .errorCode("ERR500")
                            .build();

            FTSAccountOpeningApiResponse.ResponseData nestedData =
                    FTSAccountOpeningApiResponse.ResponseData.builder()
                            .status(nestedStatus)
                            .build();

            apiResp.setData(nestedData);

            when(feignClient.accountOpening(anyString(), any()))
                    .thenReturn(apiResp);

            HandlerResult<FTSAccountOpeningApiResponse> result =
                    handler.handle(handlerContext);

            assertFalse(result.isSuccess());
            assertEquals(apiResp, result.getResult());
        }
    }

    // ---------------- EXCEPTION FLOW ------------------
    @Test
    void testHandleException() {

        try (MockedStatic<JourneyService> msJourney = mockStatic(JourneyService.class);
             MockedStatic<DownstreamResponseHandler> msDS = mockStatic(DownstreamResponseHandler.class)) {

            msJourney.when(() -> JourneyService.extractFromJourney(any(), any(), any()))
                    .thenReturn(Optional.ofNullable(ftsDetails));

            msDS.when(() -> DownstreamResponseHandler.handleResponse(
                    any(), anyString(), anyBoolean(), anyString()
            )).thenReturn(null);

            when(feignClient.accountOpening(anyString(), any()))
                    .thenThrow(new RuntimeException("API ERROR"));

            HandlerResult<FTSAccountOpeningApiResponse> result =
                    handler.handle(handlerContext);

            assertFalse(result.isSuccess());
            assertNull(result.getResult());
        }
    }

    // ---------------- CONSTANT METHODS ------------------
    @Test
    void testGetType() {
        assertEquals(Handler.HandlerType.BACKGROUND_TASKS_POST_SUBMIT_SUCCESS, handler.getType());
    }

    @Test
    void testGetName() {
        assertEquals(Handler.HandlerName.FTS_ACCOUNT_OPENING, handler.getName());
    }

    @Test
    void testSuccessState() {
        assertEquals(CommonJourneyStates.FTS_AOF_POSTED_SUCCESS, handler.successState());
    }

    @Test
    void testFailureState() {
        assertEquals(CommonJourneyStates.FTS_AOF_POSTED_FAILURE, handler.failureState());
    }
}