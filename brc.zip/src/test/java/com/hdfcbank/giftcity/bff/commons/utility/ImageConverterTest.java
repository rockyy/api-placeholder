package com.hdfcbank.giftcity.bff.commons.utility;

import com.hdfcbank.giftcity.bff.commons.enums.ImageFormat;
import org.junit.jupiter.api.Test;
import org.mockito.MockedStatic;
import org.mockito.Mockito;

import javax.imageio.ImageIO;
import javax.imageio.ImageReader;
import javax.imageio.stream.ImageInputStream;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Iterator;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class ImageConverterTest {

    private BufferedImage dummyImage(int w, int h) {
        return new BufferedImage(w, h, BufferedImage.TYPE_INT_RGB);
    }

    // convertImage() — ImageIO.read() returns null → unsupported format
    @Test
    void testConvertImageUnsupportedImage() {

        byte[] invalidBytes = "INVALID".getBytes();

        try (MockedStatic<ImageIO> mocked = Mockito.mockStatic(ImageIO.class)) {

            mocked.when(() -> ImageIO.read(any(ByteArrayInputStream.class)))
                    .thenReturn(null);

            IOException ex = assertThrows(IOException.class,
                    () -> ImageConverter.convertImage(invalidBytes, ImageFormat.JPG, 300, 300));

            assertTrue(ex.getMessage() != null && !ex.getMessage().isBlank(),
                    "Exception message should not be empty");

            mocked.verify(() -> ImageIO.read(any(ByteArrayInputStream.class)));
        }
    }

    // convertImage() — writer not found → IOException
    @Test
    void testConvertImageNoWriterFound() throws Exception {
        byte[] imgBytes = "IMG".getBytes();
        BufferedImage image = dummyImage(200, 200);

        try (MockedStatic<ImageIO> mocked = Mockito.mockStatic(ImageIO.class)) {

            mocked.when(() -> ImageIO.read(any(ByteArrayInputStream.class)))
                    .thenReturn(image);

            mocked.when(() -> ImageIO.write(
                    any(BufferedImage.class),
                    eq("GIF"),
                    any(ByteArrayOutputStream.class)
            )).thenReturn(false);

            IOException ex = assertThrows(IOException.class,
                    () -> ImageConverter.convertImage(imgBytes, ImageFormat.GIF, 200, 200));

            assertNotNull(ex.getMessage());
            assertFalse(ex.getMessage().isBlank());

            // Verify mocked behaviour
            mocked.verify(() -> ImageIO.read(any(ByteArrayInputStream.class)));
            mocked.verify(() -> ImageIO.write(any(BufferedImage.class), eq("GIF"), any(ByteArrayOutputStream.class)));
        }
    }

    // resizeImage() — scale >= 1.0 → ORIGINAL RETURNED
    @Test
    void testResizeImageNoResize() throws Exception {
        byte[] imgBytes = "IMAGE".getBytes();
        BufferedImage image = dummyImage(100, 100);

        try (MockedStatic<ImageIO> mocked = Mockito.mockStatic(ImageIO.class)) {

            mocked.when(() -> ImageIO.read(any(ByteArrayInputStream.class)))
                    .thenReturn(image);

            // FIX: Ensure some bytes are written into the output stream
            mocked.when(() -> ImageIO.write(
                    any(BufferedImage.class),
                    anyString(),
                    any(ByteArrayOutputStream.class)
            )).thenAnswer(invocation -> {
                ByteArrayOutputStream out = invocation.getArgument(2);
                out.write("DUMMY_BYTES".getBytes());   // write non-empty bytes
                return true;
            });

            byte[] result = ImageConverter.convertImage(imgBytes, ImageFormat.PNG, 200, 200);

            assertNotNull(result, "Result must not be null");
            assertTrue(result.length > 0, "Result byte array should not be empty");

            mocked.verify(() -> ImageIO.read(any(ByteArrayInputStream.class)));
            mocked.verify(() -> ImageIO.write(any(BufferedImage.class), anyString(), any(ByteArrayOutputStream.class)));
        }
    }

    // resizeImage() — scale < 1.0 → resized image generated
    @Test
    void testResizeImageDownscale() throws Exception {
        byte[] imgBytes = "DATA".getBytes();
        BufferedImage large = dummyImage(1000, 500);

        try (MockedStatic<ImageIO> mocked = Mockito.mockStatic(ImageIO.class)) {

            mocked.when(() -> ImageIO.read(any(ByteArrayInputStream.class)))
                    .thenReturn(large);

            // FIX: ensure some bytes are written into the output stream
            mocked.when(() -> ImageIO.write(
                    any(BufferedImage.class),
                    anyString(),
                    any(ByteArrayOutputStream.class)
            )).thenAnswer(invocation -> {
                ByteArrayOutputStream out = invocation.getArgument(2);
                out.write("RESIZED_IMAGE_BYTES".getBytes());
                return true;
            });

            byte[] out = ImageConverter.convertImage(imgBytes, ImageFormat.PNG, 200, 200);

            assertNotNull(out, "Output should not be null");
            assertTrue(out.length > 0, "Output byte array must not be empty");

            mocked.verify(() -> ImageIO.read(any(ByteArrayInputStream.class)));
            mocked.verify(() -> ImageIO.write(any(BufferedImage.class), anyString(), any(ByteArrayOutputStream.class)));
        }
    }

    // isImageFormat() — SUCCESS CASE
    @Test
    void testIsImageFormatSuccess() throws Exception {
        byte[] bytes = "FAKE".getBytes();

        ImageReader reader = mock(ImageReader.class);
        ImageInputStream inputStream = mock(ImageInputStream.class);
        Iterator<ImageReader> iterator = mock(Iterator.class);

        try (MockedStatic<ImageIO> mocked = Mockito.mockStatic(ImageIO.class)) {

            mocked.when(() -> ImageIO.createImageInputStream(any(ByteArrayInputStream.class)))
                    .thenReturn(inputStream);

            mocked.when(() -> ImageIO.getImageReaders(inputStream))
                    .thenReturn(iterator);

            when(iterator.hasNext()).thenReturn(true);
            when(iterator.next()).thenReturn(reader);
            when(reader.getFormatName()).thenReturn("PNG");

            boolean result = ImageConverter.isImageFormat(bytes, ImageFormat.PNG);

            assertTrue(result, "Image format should match");
            verify(iterator).hasNext();
            verify(iterator).next();
            verify(reader).getFormatName();

            mocked.verify(() -> ImageIO.getImageReaders(inputStream));
        }
    }

    // isImageFormat() — NO READERS → unsupported format
    @Test
    void testIsImageFormatNoReaders() throws Exception {
        byte[] bytes = "FAKE".getBytes();

        ImageInputStream inputStream = mock(ImageInputStream.class);
        Iterator<ImageReader> iterator = mock(Iterator.class);

        try (MockedStatic<ImageIO> mocked = Mockito.mockStatic(ImageIO.class)) {

            mocked.when(() -> ImageIO.createImageInputStream(any(ByteArrayInputStream.class)))
                    .thenReturn(inputStream);

            mocked.when(() -> ImageIO.getImageReaders(inputStream))
                    .thenReturn(iterator);

            when(iterator.hasNext()).thenReturn(false);

            IOException ex = assertThrows(IOException.class,
                    () -> ImageConverter.isImageFormat(bytes, ImageFormat.TIF));

            assertNotNull(ex.getMessage());
            assertFalse(ex.getMessage().isBlank());

            verify(iterator).hasNext();
            mocked.verify(() -> ImageIO.getImageReaders(inputStream));
        }
    }

    // isImageFormat() — reader returns null format → IOException
    @Test
    void testIsImageFormatNullFormatName() throws Exception {
        byte[] bytes = "FAKE".getBytes();

        ImageReader reader = mock(ImageReader.class);
        ImageInputStream inputStream = mock(ImageInputStream.class);
        Iterator<ImageReader> iterator = mock(Iterator.class);

        try (MockedStatic<ImageIO> mocked = Mockito.mockStatic(ImageIO.class)) {

            mocked.when(() -> ImageIO.createImageInputStream(any(ByteArrayInputStream.class)))
                    .thenReturn(inputStream);

            mocked.when(() -> ImageIO.getImageReaders(inputStream))
                    .thenReturn(iterator);

            when(iterator.hasNext()).thenReturn(true);
            when(iterator.next()).thenReturn(reader);

            when(reader.getFormatName()).thenReturn(null);

            IOException ex = assertThrows(IOException.class,
                    () -> ImageConverter.isImageFormat(bytes, ImageFormat.JPG));

            assertNotNull(ex.getMessage());
            assertFalse(ex.getMessage().isBlank());

            verify(iterator).hasNext();
            verify(iterator).next();
            verify(reader).getFormatName();

            mocked.verify(() -> ImageIO.getImageReaders(inputStream));
        }
    }
}