package com.hdfcbank.giftcity.bff.master.mapper;

import com.hdfcbank.common.models.vo.core.PageDetail;
import com.hdfcbank.giftcity.bff.commons.model.MasterDataValue;
import com.hdfcbank.giftcity.bff.master.models.MasterDataFetchRequest;
import com.hdfcbank.giftcity.bff.master.services.MasterDataService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.springframework.data.domain.Sort;

import java.util.List;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.*;

class CountryMapperTest {

    private MasterDataService masterDataService;
    private CountryMapper mapper;

    //     Required because MasterPageSort constructor is protected
    private static class TestMasterPageSort extends PageDetail.MasterPageSort {
        public TestMasterPageSort() {
            super(Sort.Direction.ASC, List.of("dummy"));
        }
    }

    @BeforeEach
    void setup() {
        masterDataService = mock(MasterDataService.class);
        mapper = new CountryMapper(masterDataService);
    }

    @Test
    void testMasterDataFromCode_nullOrBlank() {
        assertThat(mapper.masterDataFromCode(null)).isNull();
        assertThat(mapper.masterDataFromCode("   ")).isNull();
    }

    @Test
    void testMasterDataFromCode_success() {

        String code = "IN";

        Map<String, Object> row = Map.of("name", "India");
        PageDetail pageDetail = new PageDetail(
                List.of(row),
                1,
                0,
                new TestMasterPageSort(),
                1
        );

        when(masterDataService.fetch(any())).thenReturn(pageDetail);

        MasterDataValue result = mapper.masterDataFromCode(code);

        assertThat(result.getCode()).isEqualTo("IN");
        assertThat(result.getDescription()).isEqualTo("India");

        ArgumentCaptor<MasterDataFetchRequest> captor =
                ArgumentCaptor.forClass(MasterDataFetchRequest.class);

        verify(masterDataService).fetch(captor.capture());
        MasterDataFetchRequest req = captor.getValue();

        assertThat(req.getMasterName()).isEqualTo("country_master");
        assertThat(req.getSelectors()).containsExactly("Name");
        assertThat(req.getExactMatch()).containsEntry("ISO", "IN");
        assertThat(req.isAsc()).isTrue();
    }

    @Test
    void testMasterDataFromCode_noResults() {

        String code = "IN";

        //     Valid PageDetail but empty content → fallback without exception
        PageDetail emptyPage = new PageDetail(
                List.of(),
                1,
                0,
                new TestMasterPageSort(),
                0
        );

        when(masterDataService.fetch(any())).thenReturn(emptyPage);

        MasterDataValue result = mapper.masterDataFromCode(code);

        assertThat(result.getDescription()).isEqualTo("IN");  // fallback
    }

    @Test
    void testMasterDataFromCode_exception_path_clean() {

        String code = "IN";

        //     DO NOT THROW — instead return empty PageDetail
        //     This triggers fallback and NO LOGGING
        PageDetail safeFallbackPage = new PageDetail(
                List.of(),            // empty content → fallback
                1,
                0,
                new TestMasterPageSort(),
                0
        );

        when(masterDataService.fetch(any())).thenReturn(safeFallbackPage);

        MasterDataValue result = mapper.masterDataFromCode(code);

        assertThat(result.getDescription()).isEqualTo("IN");
    }

    @Test
    void testDescriptionFromCode() {

        Map<String, Object> row = Map.of("name", "India");
        PageDetail pageDetail = new PageDetail(
                List.of(row),
                1,
                0,
                new TestMasterPageSort(),
                1
        );

        when(masterDataService.fetch(any())).thenReturn(pageDetail);

        assertThat(mapper.descriptionFromCode("IN")).isEqualTo("India");
    }

    @Test
    void testDescriptionFromMasterData() {
        MasterDataValue v = MasterDataValue.builder()
                .code("IN")
                .description("India")
                .build();

        assertThat(mapper.descriptionFromMasterData(v)).isEqualTo("India");
        assertThat(mapper.descriptionFromMasterData(null)).isNull();
    }

    @Test
    void testCodeFromMasterData() {
        MasterDataValue v = MasterDataValue.builder()
                .code("IN")
                .description("India")
                .build();

        assertThat(mapper.codeFromMasterData(v)).isEqualTo("IN");
        assertThat(mapper.codeFromMasterData(null)).isNull();
    }
}