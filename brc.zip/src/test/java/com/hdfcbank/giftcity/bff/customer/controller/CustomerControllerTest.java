package com.hdfcbank.giftcity.bff.customer.controller;

import com.hdfcbank.giftcity.bff.customer.model.*;
import com.hdfcbank.giftcity.bff.customer.service.CustomerService;
import com.hdfcbank.giftcity.bff.customer.rmcodes.service.RmCodesMasterService;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;

class CustomerControllerTest {

    private CustomerController controller;
    private CustomerService customerService;
    private RmCodesMasterService rmCodesMasterService;

    @BeforeEach
    void setup() {
        customerService = Mockito.mock(CustomerService.class);
        rmCodesMasterService = Mockito.mock(RmCodesMasterService.class);

        controller = new CustomerController();
        ReflectionTestUtils.setField(controller, "customerService", customerService);
        ReflectionTestUtils.setField(controller, "rmCodesMasterService", rmCodesMasterService);
    }

    // ===========================================================
    //           /identify
    // ===========================================================
    @Test
    void testIdentifyCustomer() {

        IdentifyCustomerRequest req = IdentifyCustomerRequest.builder()
                .identifierName("MOBILE")
                .identifierValue("9999999999")
                .mobileNo("9999999999")
                .isd("91")
                .sso(false)
                .build();

        IdentifyCustomerResponse resp = IdentifyCustomerResponse.builder()
                .data(IdentifyCustomerResponse.IdentifyCustomerDetail.builder()
                        .journeyId("J123")
                        .txnRef("TREF")
                        .existingCustomer(false)
                        .build())
                .build();

        Mockito.when(customerService.identifyCustomer(any(), eq("J123"), eq("GIFT")))
                .thenReturn(resp);

        ResponseEntity<IdentifyCustomerResponse> response =
                controller.identifyCustomer(req, "Bearer token", "GIFT", "J123");

        assertThat(response).isNotNull();
        assertThat(response.getStatusCode().is2xxSuccessful()).isTrue();

        IdentifyCustomerResponse body = response.getBody();
        assertThat(body).isNotNull();
        assertThat(body.getData()).isNotNull();
        assertThat(body.getData().getJourneyId()).isEqualTo("J123");
        assertThat(body.getData().getTxnRef()).isEqualTo("TREF");
        assertThat(body.getData().isExistingCustomer()).isFalse();

        // Request-level assertion
        assertThat(req.getIdentifierName()).isEqualTo("MOBILE");
        assertThat(req.getIdentifierValue()).isEqualTo("9999999999");
    }

    // ===========================================================
    //           /inquire-eligibility
    // ===========================================================
    @Test
    void testInquireEligibility() {

        InquireEligibilityResponse resp = InquireEligibilityResponse.builder()
                .data(InquireEligibilityResponse.InquireEligibility.builder()
                        .status(InquireEligibilityResponse.JourneyStatus.SUCCESS)
                        .build())
                .build();

        Mockito.when(customerService.customerInquireEligibility("J123"))
                .thenReturn(resp);

        ResponseEntity<InquireEligibilityResponse> response =
                controller.inquireCustomer("J123");

        assertThat(response).isNotNull();
        assertThat(response.getStatusCode().is2xxSuccessful()).isTrue();

        InquireEligibilityResponse body = response.getBody();
        assertThat(body).isNotNull();
        assertThat(body.getData()).isNotNull();
        assertThat(body.getData().getStatus()).isEqualTo(InquireEligibilityResponse.JourneyStatus.SUCCESS);
    }

    // ===========================================================
    //           /validate
    // ===========================================================
    @Test
    void testValidateCustomer() {

        CustomerConsentRequest consentMock = Mockito.mock(CustomerConsentRequest.class);

        ValidateCustomerRequest req = ValidateCustomerRequest.builder()
                .otp("123456")
                .txnRef("XREF")
                .consents(List.of(consentMock))
                .build();

        ValidateCustomerResponse resp = ValidateCustomerResponse.builder()
                .data(ValidateCustomerResponse.ValidateCustomerDetail.builder()
                        .otpValidated(true)
                        .retryOtpAttemptsLeft(3)
                        .build())
                .build();

        Mockito.when(customerService.validateCustomer(any(), eq("J123")))
                .thenReturn(resp);

        ResponseEntity<ValidateCustomerResponse> response =
                controller.validateCustomer("J123", "GIFT", req);

        assertThat(response).isNotNull();
        assertThat(response.getStatusCode().is2xxSuccessful()).isTrue();

        ValidateCustomerResponse body = response.getBody();
        assertThat(body).isNotNull();
        assertThat(body.getData()).isNotNull();

        assertThat(body.getData().isOtpValidated()).isTrue();
        assertThat(body.getData().getRetryOtpAttemptsLeft()).isEqualTo(3);

        // Request assertion
        assertThat(req.getOtp()).isEqualTo("123456");
        assertThat(req.getTxnRef()).isEqualTo("XREF");
        assertThat(req.getConsents()).isNotEmpty();
    }

    // ===========================================================
    //           /resendOtp
    // ===========================================================
    @Test
    void testResendOtp() {

        IdentifyCustomerResponse resp = IdentifyCustomerResponse.builder()
                .data(IdentifyCustomerResponse.IdentifyCustomerDetail.builder()
                        .journeyId("J123")
                        .build())
                .build();

        Mockito.when(customerService.resendOtp("J123"))
                .thenReturn(resp);

        ResponseEntity<IdentifyCustomerResponse> response =
                controller.resendOtp("J123", "GIFT");

        assertThat(response).isNotNull();
        assertThat(response.getStatusCode().is2xxSuccessful()).isTrue();

        IdentifyCustomerResponse body = response.getBody();
        assertThat(body).isNotNull();
        assertThat(body.getData().getJourneyId()).isEqualTo("J123");
    }

    // ===========================================================
    //           /view
    // ===========================================================
    @Test
    void testGetCustomerDetails() {

        CustomerDetailsResponse resp = CustomerDetailsResponse.builder()
                .data(CustomerDetails.builder().build())
                .build();

        Mockito.when(customerService.getCustomerDetails())
                .thenReturn(resp);

        ResponseEntity<CustomerDetailsResponse> response =
                controller.getCustomerDetails("J123");

        assertThat(response).isNotNull();
        assertThat(response.getStatusCode().is2xxSuccessful()).isTrue();
        assertThat(response.getBody()).isNotNull();
        assertThat(response.getBody().getData()).isNotNull();
    }

    // ===========================================================
    //           /review
    // ===========================================================
    @Test
    void testReviewCustomerDetails() {

        ReviewCustomerResponse resp = ReviewCustomerResponse.builder()
                .data(ReviewCustomerResponse.ReviewCustomerDetails.builder().build())
                .build();

        Mockito.when(customerService.getReviewCustomerDetails())
                .thenReturn(resp);

        ResponseEntity<ReviewCustomerResponse> response =
                controller.getReviewCustomerDetails("J123");

        assertThat(response).isNotNull();
        assertThat(response.getStatusCode().is2xxSuccessful()).isTrue();
        assertThat(response.getBody()).isNotNull();
        assertThat(response.getBody().getData()).isNotNull();
    }
}