package com.hdfcbank.giftcity.bff.application.handlers.background;

import java.lang.reflect.Method;

public class TestUtils {

    @SuppressWarnings("unchecked")
    public static <T> T invokePrivate(Object target,
                                      String methodName,
                                      Class<?>[] paramTypes,
                                      Object[] paramValues) {
        try {
            Method m = target.getClass().getDeclaredMethod(methodName, paramTypes);
            m.setAccessible(true);
            return (T) m.invoke(target, paramValues);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public static <T> T invokePrivate(Object target,
                                      String methodName,
                                      Class<?> p1,
                                      Object v1) {
        return invokePrivate(target,
                methodName,
                new Class<?>[]{p1},
                new Object[]{v1});
    }

    public static <T> T invokePrivate(Object target,
                                      String methodName,
                                      Class<?> p1, Class<?> p2, Class<?> p3,
                                      Object v1, Object v2, Object v3) {
        return invokePrivate(target,
                methodName,
                new Class<?>[]{p1, p2, p3},
                new Object[]{v1, v2, v3});
    }

    public static <T> T invokePrivate(Object target,
                                      String methodName,
                                      Class<?> p1, Class<?> p2, Class<?> p3, Class<?> p4, Class<?> p5,
                                      Object v1, Object v2, Object v3, Object v4, Object v5) {
        return invokePrivate(target,
                methodName,
                new Class<?>[]{p1, p2, p3, p4, p5},
                new Object[]{v1, v2, v3, v4, v5});
    }
}