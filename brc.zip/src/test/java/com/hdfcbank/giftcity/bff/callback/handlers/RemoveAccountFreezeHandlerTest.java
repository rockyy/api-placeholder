package com.hdfcbank.giftcity.bff.callback.handlers;

import com.hdfcbank.common.models.vo.journey.JourneyData;
import com.hdfcbank.common.models.vo.journey.JourneyDetail;
import com.hdfcbank.common.models.vo.journey.JourneyState;
import com.hdfcbank.giftcity.bff.account.service.AccountService;
import com.hdfcbank.giftcity.bff.commons.enums.CommonJourneyStates;
import com.hdfcbank.giftcity.bff.commons.enums.JourneyPageName;
import com.hdfcbank.giftcity.bff.commons.exception.handler.DownstreamResponseHandler;
import com.hdfcbank.giftcity.bff.commons.handler.Handler;
import com.hdfcbank.giftcity.bff.commons.handler.HandlerContext;
import com.hdfcbank.giftcity.bff.commons.handler.HandlerResult;
import com.hdfcbank.giftcity.bff.commons.model.CustomValidationStatus;
import com.hdfcbank.giftcity.bff.commons.model.FcGcProfile;
import com.hdfcbank.giftcity.bff.infrastructure.service.JourneyService;
import com.hdfcbank.service.adapters.vo.account.TransactionStatus;
import com.hdfcbank.service.adapters.vo.account.UpdateFccAccountResponseBFF;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.MockedStatic;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class RemoveAccountFreezeHandlerTest {

    private AccountService accountService;
    private RemoveAccountFreezeHandler handler;
    private HandlerContext handlerContext;
    private JourneyData journeyData;

    @BeforeEach
    void setup() {
        accountService = mock(AccountService.class);
        handler = new RemoveAccountFreezeHandler(accountService);

        handlerContext = new HandlerContext(null, Map.of(), Map.of());
        journeyData = new JourneyData();
        journeyData.setJourneyId("J123");
        journeyData.setJourneyName("GIFT_CITY_JOURNEY");

        JourneyDetail detail = new JourneyDetail();
        detail.setJourneyStates(List.of(new JourneyState(
                CommonJourneyStates.FTS_SUCCESS_CALLBACK.name(),
                null,
                null
        )));

        detail.setSystemData(Map.of(
                JourneyPageName.CUSTOMER_FC_GIFT_CITY_DETAIL.getPageName(),
                Map.of("accountNumber", "ACC001")
        ));

        journeyData.setJourneyDetail(detail);
        handlerContext.setJourneyData(journeyData);
    }

    @Test
    void testPreConditionsTrue() {
        assertTrue(handler.preConditions(handlerContext));
    }

    @Test
    void testPreConditionsFalse() {
        journeyData.getJourneyDetail().setJourneyStates(List.of());
        assertFalse(handler.preConditions(handlerContext));
    }

    @Test
    void testHandleAccountNumberMissing() {

        journeyData.getJourneyDetail().setSystemData(Map.of());

        try (MockedStatic<JourneyService> journeyMock = mockStatic(JourneyService.class);
             MockedStatic<DownstreamResponseHandler> downstreamMock = mockStatic(DownstreamResponseHandler.class)) {

            journeyMock.when(() -> JourneyService.extractFromJourney(
                    any(), eq(JourneyPageName.CUSTOMER_FC_GIFT_CITY_DETAIL.getPageName()),
                    eq(FcGcProfile.class), any()
            )).thenReturn(Optional.empty());

            CustomValidationStatus expectedError = new CustomValidationStatus();

            downstreamMock.when(() -> DownstreamResponseHandler.handleResponse(
                    null,
                    Handler.HandlerName.FCC_ACCOUNT_UNFREEZE.name(),
                    false,
                    journeyData.getJourneyName()
            )).thenReturn(expectedError);

            HandlerResult<UpdateFccAccountResponseBFF> result = handler.handle(handlerContext);

            assertFalse(result.isSuccess());
            assertNull(result.getResult());
            assertEquals(expectedError, result.getApiResponseStatus());
        }
    }

    @Test
    void testHandleSuccess() {

        UpdateFccAccountResponseBFF.UpdateFccAccountData data =
                UpdateFccAccountResponseBFF.UpdateFccAccountData.builder()
                        .transactionStatus(TransactionStatus.builder().status("SUCCESS").build())
                        .build();

        UpdateFccAccountResponseBFF response = new UpdateFccAccountResponseBFF();
        response.setData(data);

        try (MockedStatic<JourneyService> journeyMock = mockStatic(JourneyService.class)) {

            journeyMock.when(() -> JourneyService.extractFromJourney(
                    any(), anyString(), eq(FcGcProfile.class), any()
            )).thenReturn(Optional.of("ACC001"));

            when(accountService.removeAccountFreeze("ACC001", "J123"))
                    .thenReturn(response);

            HandlerResult<UpdateFccAccountResponseBFF> result = handler.handle(handlerContext);

            assertTrue(result.isSuccess());
            assertEquals(response, result.getResult());
            assertNull(result.getApiResponseStatus());
        }
    }

    @Test
    void testHandleFailure() {

        UpdateFccAccountResponseBFF.UpdateFccAccountData data =
                UpdateFccAccountResponseBFF.UpdateFccAccountData.builder()
                        .transactionStatus(TransactionStatus.builder().status("FAILED").build())
                        .build();

        UpdateFccAccountResponseBFF response = new UpdateFccAccountResponseBFF();
        response.setData(data);

        CustomValidationStatus expectedError = new CustomValidationStatus();

        try (MockedStatic<JourneyService> journeyMock = mockStatic(JourneyService.class);
             MockedStatic<DownstreamResponseHandler> downstreamMock = mockStatic(DownstreamResponseHandler.class)) {

            journeyMock.when(() -> JourneyService.extractFromJourney(any(), anyString(), eq(FcGcProfile.class), any()))
                    .thenReturn(Optional.of("ACC001"));

            when(accountService.removeAccountFreeze("ACC001", "J123")).thenReturn(response);

            downstreamMock.when(() ->
                    DownstreamResponseHandler.handleResponse(
                            response,
                            Handler.HandlerName.FCC_ACCOUNT_UNFREEZE.name(),
                            false,
                            journeyData.getJourneyName())
            ).thenReturn(expectedError);

            HandlerResult<UpdateFccAccountResponseBFF> result = handler.handle(handlerContext);

            assertFalse(result.isSuccess());
            assertEquals(response, result.getResult());
            assertEquals(expectedError, result.getApiResponseStatus());
        }
    }

    @Test
    void testHandleException() {

        CustomValidationStatus expectedError = new CustomValidationStatus();

        try (MockedStatic<JourneyService> journeyMock = mockStatic(JourneyService.class);
             MockedStatic<DownstreamResponseHandler> downstreamMock = mockStatic(DownstreamResponseHandler.class)) {

            journeyMock.when(() -> JourneyService.extractFromJourney(any(), anyString(), any(), any()))
                    .thenThrow(new RuntimeException("Boom"));

            downstreamMock.when(() ->
                            DownstreamResponseHandler.handleResponse(
                                    null,
                                    Handler.HandlerName.FCC_ACCOUNT_UNFREEZE.name(),
                                    false,
                                    journeyData.getJourneyName()))
                    .thenReturn(expectedError);

            HandlerResult<UpdateFccAccountResponseBFF> result = handler.handle(handlerContext);

            assertFalse(result.isSuccess());
            assertNull(result.getResult());
            assertEquals(expectedError, result.getApiResponseStatus());
        }
    }

    @Test
    void testMetadata() {
        assertEquals(Handler.HandlerType.BACKGROUND_TASKS_POST_SUBMIT_SUCCESS, handler.getType());
        assertEquals(Handler.HandlerName.FCC_ACCOUNT_UNFREEZE, handler.getName());
        assertEquals(CommonJourneyStates.FCC_ACCOUNT_UNFREEZE_SUCCESS, handler.successState());
        assertEquals(CommonJourneyStates.FCC_ACCOUNT_UNFREEZE_FAILURE, handler.failureState());
    }
}