package com.hdfcbank.giftcity.bff;

import org.junit.jupiter.api.Test;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.*;
import java.nio.charset.StandardCharsets;
import java.security.KeyFactory;
import java.security.PublicKey;
import java.security.SecureRandom;
import java.security.spec.MGF1ParameterSpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;
import java.util.HexFormat;

class RequestEncrypterApplicationTests {

    @Test
    void contextLoads() {
        // Method intentionally left empty: verifies that the Spring context loads successfully
    }

    private static String publicKeyFromServer = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA1hVn2LZ0ORCTqXFe5rvnQF+0T6RnrSZS8wrB8vf2P/aBRL9NBaXbH4Z+axas5Rebjdts6sgq1t+yw+LiQU+KCFiZnNZ9lZd3NVKfjSgv2b3yGDZXgfDhrDHBM52fsPXyTpaa1BOeijOQNalF1kxOWXxbRVP9E9blTbdMopNk9kySH8muP/cqhar4H3JmUFpcQDxBgTswfwYDojNR7f9yNw4vuhTKSadHieaUSAAaRn+5e6by5cIfpjbPXgwiuYJI7SYSvqKpPvrKXzQxZhW76o4ut57N+SoFWXErZPtp52d7bzyXqMKfGnkkGT7PSeImUFWhgL8FRC5Rg0pqOGlzbwIDAQAB";
    private static String keyString = "98345678901234567890123456789012";

    @Test
    public void encrypt() throws Exception {

        String requestJson = """
                {
                      "mobileNo": "8097124103",
                     "isd" : "961",
                      "identifierName":"DOB",
                      "identifierValue": "2000-01-01"
                
                  }
                """;

// Generate AES key
        KeyGenerator keyGen = KeyGenerator.getInstance("AES");
        keyGen.init(256);


        SecretKey aesKey =
                new SecretKeySpec(
                        keyString.getBytes(StandardCharsets.UTF_8),
                        "AES"
                );

// Generate IV
        byte[] iv = new byte[12];
        new SecureRandom().nextBytes(iv);

// Encrypt body using AES-GCM
        Cipher aesCipher = Cipher.getInstance("AES/GCM/NoPadding");
        aesCipher.init(
                Cipher.ENCRYPT_MODE,
                aesKey,
                new GCMParameterSpec(128, iv)
        );

        byte[] encryptedBody =
                aesCipher.doFinal(requestJson.getBytes(StandardCharsets.UTF_8));

// Encrypt AES key using RSA-OAEP SHA-256
        byte[] publicKeyBytes =
                Base64.getDecoder().decode(publicKeyFromServer);

        PublicKey publicKey =
                KeyFactory.getInstance("RSA")
                        .generatePublic(new X509EncodedKeySpec(publicKeyBytes));
//RSA/ECB/OAEPWithSHA-256AndMGF1Padding
        Cipher rsaCipher =
                Cipher.getInstance("RSA/ECB/OAEPWithSHA-256AndMGF1Padding");
        OAEPParameterSpec oaepParams =
                new OAEPParameterSpec(
                        "SHA-256",
                        "MGF1",
                        MGF1ParameterSpec.SHA256,
                        PSource.PSpecified.DEFAULT
                );

        rsaCipher.init(Cipher.ENCRYPT_MODE, publicKey, oaepParams);

        byte[] encryptedKey =
                rsaCipher.doFinal(aesKey.getEncoded());

// Build request
        String content =
                Base64.getEncoder().encodeToString(encryptedKey)
                        + "."
                        + Base64.getEncoder().encodeToString(iv)
                        + "."
                        + Base64.getEncoder().encodeToString(encryptedBody);

        System.out.println(
                "{\"content\":\"" + content + "\"}"
        );
    }


    @Test
    public void decryptResponse() throws Exception {
        String responseContent = "xvawcF9/+Ah3KyTp.p1FNM4WH9+CtU9V7ffFehEerufr/bBYi4Sez/khrXjaMBo4pFLdM99aL399WZ3si7c8aDzV5Gl57QDTPxsQa3Z+LOw5XZnEpmQ81Q7MxYx+UmpvqUVLfprX5f4Hkh0Pu0s2CdC5SYmpspuQHfdVbCiJajpK1tOjANP4XFaJqpgfixvgrTenZUXuXZTR9k2PFMIKWJDHrH8fYLfLr9+q23rrROYphDnLCDLehTcLAenmAA4f0b/2cpFjDCS7Q1pjzplnxKGocAf3ke8JHrd5DBd7ZLLyym1fPwwpReRts2hLSWxCCVW9R";

        SecretKey aesKey =
                new SecretKeySpec(
                        keyString.getBytes(StandardCharsets.UTF_8),
                        "AES"
                );
        String[] parts = responseContent.split("\\.");

        if (parts.length != 2) {
            throw new IllegalArgumentException(
                    "Invalid response format");
        }

        byte[] iv =
                Base64.getDecoder().decode(parts[0]);

        byte[] encryptedBody =
                Base64.getDecoder().decode(parts[1]);

        Cipher cipher =
                Cipher.getInstance("AES/GCM/NoPadding");

        cipher.init(
                Cipher.DECRYPT_MODE,
                aesKey,
                new GCMParameterSpec(128, iv)
        );

        byte[] plainBytes =
                cipher.doFinal(encryptedBody);

        System.out.println(new String(
                plainBytes,
                StandardCharsets.UTF_8
        ));
    }

}
