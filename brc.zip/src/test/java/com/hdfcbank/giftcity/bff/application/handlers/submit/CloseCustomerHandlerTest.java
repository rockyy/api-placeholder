package com.hdfcbank.giftcity.bff.application.handlers.submit;

import com.hdfcbank.common.models.vo.core.ApiResponseStatus;
import com.hdfcbank.common.models.vo.journey.JourneyData;
import com.hdfcbank.giftcity.bff.commons.enums.CommonJourneyStates;
import com.hdfcbank.giftcity.bff.commons.exception.handler.DownstreamResponseHandler;
import com.hdfcbank.giftcity.bff.commons.handler.Handler;
import com.hdfcbank.giftcity.bff.commons.handler.HandlerContext;
import com.hdfcbank.giftcity.bff.commons.handler.HandlerResult;
import com.hdfcbank.giftcity.bff.commons.model.CustomValidationStatus;
import com.hdfcbank.service.adapters.clients.feign.customer.CustomerServiceFeignClient;
import com.hdfcbank.service.adapters.vo.customer.CloseCustomerRequest;
import com.hdfcbank.service.adapters.vo.customer.CloseCustomerResponse;
import com.hdfcbank.service.adapters.vo.customer.FccCustomerResponse;

import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;

import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.*;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
class CloseCustomerHandlerTest {

    @Mock
    private CustomerServiceFeignClient customerServiceFeignClient;

    @Spy
    @InjectMocks
    private CloseCustomerHandler handler;

    private HandlerContext ctx;
    private JourneyData journeyData;

    @BeforeEach
    void setup() {

        journeyData = JourneyData.builder()
                .journeyId("JID123")
                .journeyName("GIFT_CITY")
                .build();

        ctx = HandlerContext.builder()
                .journeyData(journeyData)
                .properties(new HashMap<>())
                .data(new HashMap<>())
                .build();
    }

    // -------------------------------------------------------------------------
    // preConditions()
    // -------------------------------------------------------------------------
    @Test
    void preConditions_shouldReturnTrue_whenCreateCustomerSuccess_andCreateAccountFailure() {

        doReturn(true).when(handler).isSuccess(ctx, Handler.HandlerName.CREATE_CUSTOMER);
        doReturn(false).when(handler).isSuccess(ctx, Handler.HandlerName.CREATE_ACCOUNT);

        assertTrue(handler.preConditions(ctx));
    }

    @Test
    void preConditions_shouldReturnFalse_whenCreateCustomerFails() {

        doReturn(false).when(handler).isSuccess(ctx, Handler.HandlerName.CREATE_CUSTOMER);
        assertFalse(handler.preConditions(ctx));
    }

    @Test
    void preConditions_shouldReturnFalse_whenCreateAccountSuccess() {

        doReturn(true).when(handler).isSuccess(ctx, Handler.HandlerName.CREATE_CUSTOMER);
        doReturn(true).when(handler).isSuccess(ctx, Handler.HandlerName.CREATE_ACCOUNT);

        assertFalse(handler.preConditions(ctx));
    }

    // -------------------------------------------------------------------------
    // SUCCESS CASE — closeCustomerResponse.status.code == 0000
    // -------------------------------------------------------------------------
    @Test
    void handle_shouldReturnSuccess_whenResponseCodeIs0000() {

        // Mock previous CREATE_CUSTOMER handler output
        FccCustomerResponse.FccCustomerId id =
                FccCustomerResponse.FccCustomerId.builder()
                        .customerId("CUST123")
                        .build();

        FccCustomerResponse fccResponse =
                FccCustomerResponse.builder()
                        .data(id)
                        .status(new ApiResponseStatus())
                        .build();

        doReturn(fccResponse).when(handler)
                .getResult(ctx, Handler.HandlerName.CREATE_CUSTOMER, FccCustomerResponse.class);

        // Prepare successful close response
        ApiResponseStatus status = new ApiResponseStatus();
        status.setCode("0000");
        status.setMessage("OK");

        CloseCustomerResponse closeResp =
                CloseCustomerResponse.builder()
                        .status(status)
                        .build();

        when(customerServiceFeignClient.closeFccCustomer(any(CloseCustomerRequest.class), eq("JID123")))
                .thenReturn(closeResp);

        HandlerResult<CloseCustomerResponse> result = handler.handle(ctx);

        assertTrue(result.isSuccess());

        assertNotNull(result.getResult());
        assertEquals("0000", result.getResult().getStatus().getCode());
        assertEquals("OK", result.getResult().getStatus().getMessage());

        assertNull(result.getApiResponseStatus());

        // Ensure feign client was called exactly once
        verify(customerServiceFeignClient, times(1))
                .closeFccCustomer(any(), eq("JID123"));
    }

    // -------------------------------------------------------------------------
    // FAILURE CASE — Response code != 0000
    // -------------------------------------------------------------------------
    @Test
    void handle_shouldReturnFailure_whenResponseCodeIsNot0000() {

        // Mock previous CREATE_CUSTOMER handler output
        FccCustomerResponse.FccCustomerId id =
                FccCustomerResponse.FccCustomerId.builder()
                        .customerId("CUST123")
                        .build();

        FccCustomerResponse fccResponse =
                FccCustomerResponse.builder()
                        .data(id)
                        .status(new ApiResponseStatus())
                        .build();

        doReturn(fccResponse).when(handler)
                .getResult(ctx, Handler.HandlerName.CREATE_CUSTOMER, FccCustomerResponse.class);

        ApiResponseStatus st = new ApiResponseStatus();
        st.setCode("9999");
        st.setMessage("FAIL");

        CloseCustomerResponse closeResp =
                CloseCustomerResponse.builder()
                        .status(st)
                        .build();

        when(customerServiceFeignClient.closeFccCustomer(any(), eq("JID123")))
                .thenReturn(closeResp);

        CustomValidationStatus custom =
                CustomValidationStatus.builder()
                        .code("ERR")
                        .message("DOWNSTREAM_FAILED")
                        .build();

        try (MockedStatic<DownstreamResponseHandler> dsh = mockStatic(DownstreamResponseHandler.class)) {

            dsh.when(() -> DownstreamResponseHandler.handleResponse(
                    eq(closeResp),
                    eq(Handler.HandlerName.CLOSE_CUSTOMER.name()),
                    eq(false),
                    eq("GIFT_CITY")
            )).thenReturn(custom);

            HandlerResult<CloseCustomerResponse> result = handler.handle(ctx);

            assertFalse(result.isSuccess());

            assertNotNull(result.getResult());
            assertEquals("9999", result.getResult().getStatus().getCode());
            assertEquals("FAIL", result.getResult().getStatus().getMessage());

            assertEquals("ERR", result.getApiResponseStatus().getCode());
            assertEquals("DOWNSTREAM_FAILED", result.getApiResponseStatus().getMessage());

            verify(customerServiceFeignClient, times(1))
                    .closeFccCustomer(any(), eq("JID123"));
        }
    }

    // -------------------------------------------------------------------------
    // EXCEPTION CASE — Feign client throws
    // -------------------------------------------------------------------------
    @Test
    void handle_shouldReturnFailure_whenExceptionThrown() {

        // Previous result
        FccCustomerResponse.FccCustomerId id =
                FccCustomerResponse.FccCustomerId.builder()
                        .customerId("CUST123")
                        .build();

        FccCustomerResponse fccResponse =
                FccCustomerResponse.builder()
                        .data(id)
                        .status(new ApiResponseStatus())
                        .build();

        doReturn(fccResponse).when(handler)
                .getResult(ctx, Handler.HandlerName.CREATE_CUSTOMER, FccCustomerResponse.class);

        // Simulate Feign exception
        when(customerServiceFeignClient.closeFccCustomer(any(), eq("JID123")))
                .thenThrow(new RuntimeException("Boom"));

        // Expected internal mapping to custom validation error
        CustomValidationStatus custom =
                CustomValidationStatus.builder()
                        .code("EX")
                        .message("EXCEPTION")
                        .build();

        try (MockedStatic<DownstreamResponseHandler> dsh =
                     mockStatic(DownstreamResponseHandler.class)) {

            // For exception, handler sends `null` to DownstreamResponseHandler
            dsh.when(() -> DownstreamResponseHandler.handleResponse(
                    eq(null),
                    eq(Handler.HandlerName.CLOSE_CUSTOMER.name()),
                    eq(false),
                    eq("GIFT_CITY")
            )).thenReturn(custom);

            HandlerResult<CloseCustomerResponse> result = handler.handle(ctx);

            assertFalse(result.isSuccess());
            assertNull(result.getResult());
            assertEquals("EX", result.getApiResponseStatus().getCode());
            assertEquals("EXCEPTION", result.getApiResponseStatus().getMessage());

            verify(customerServiceFeignClient, times(1))
                    .closeFccCustomer(any(), eq("JID123"));
        }
    }

    // -------------------------------------------------------------------------
    // ENUM COVERAGE
    // -------------------------------------------------------------------------
    @Test
    void enumCoverage() {

        assertEquals(Handler.HandlerType.CUSTOMER_POST_SUBMIT, handler.getType());
        assertEquals(Handler.HandlerName.CLOSE_CUSTOMER, handler.getName());

        assertEquals(CommonJourneyStates.CLOSE_FCC_CUSTOMER_SUCCESS, handler.successState());
        assertEquals(CommonJourneyStates.CLOSE_FCC_CUSTOMER_FAILURE, handler.failureState());
    }
}