package com.hdfcbank.giftcity.bff.commons.exception;

import com.hdfcbank.giftcity.bff.commons.enums.CustomCommonApiStatusCodes;
import com.hdfcbank.giftcity.bff.commons.model.CustomValidationStatus;
import com.hdfcbank.giftcity.bff.customer.model.CustomerApiStatusCode;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;

class CustomValidationExceptionTest {

    @Test
    void customerCodeConstructorPreservesStatusErrorsAndMissingPresentationFields() {
        List<String> errors = List.of("Invalid customer");

        CustomValidationException exception = new CustomValidationException(CustomerApiStatusCode.UNKNOWN, errors);

        assertSame(CustomerApiStatusCode.UNKNOWN, exception.getApiResponseStatusCodeLiteral());
        assertSame(errors, exception.getErrors());
        assertNull(exception.getTitle());
        assertNull(exception.getScreen());
    }

    @Test
    void commonCodeConstructorPreservesStatusErrorsAndMissingPresentationFields() {
        List<String> errors = List.of("Invalid request");

        CustomValidationException exception = new CustomValidationException(
                CustomCommonApiStatusCodes.CUSTOM_VALIDATION_EXCEPTION, errors);

        assertSame(CustomCommonApiStatusCodes.CUSTOM_VALIDATION_EXCEPTION, exception.getApiResponseStatusCodeLiteral());
        assertSame(errors, exception.getErrors());
        assertNull(exception.getTitle());
        assertNull(exception.getScreen());
    }

    @Test
    void statusConstructorPreservesTitleAndErrorReferences() {
        CustomValidationStatus status = new CustomValidationStatus();
        status.setTitle("Customer validation");
        status.setErrors(List.of("Missing details"));

        CustomValidationException exception = new CustomValidationException(status);

        assertSame(status, exception.getApiResponseStatusCodeLiteral());
        assertSame(status.getErrors(), exception.getErrors());
        assertEquals("Customer validation", exception.getTitle());
        assertNull(exception.getScreen());
    }
}
