package com.hdfcbank.giftcity.bff.application.handlers.background;

import com.hdfcbank.adapters.clients.feign.communication.CommunicationFeignClient;
import com.hdfcbank.adapters.vo.*;
import com.hdfcbank.common.models.vo.core.ApiResponseStatus;
import com.hdfcbank.common.models.vo.journey.JourneyData;
import com.hdfcbank.common.models.vo.journey.JourneyDetail;
import com.hdfcbank.common.models.vo.journey.JourneyState;
import com.hdfcbank.common.models.vo.journey.Profile;
import com.hdfcbank.giftcity.bff.commons.exception.handler.DownstreamResponseHandler;
import com.hdfcbank.giftcity.bff.commons.file.InlineImage;
import com.hdfcbank.giftcity.bff.commons.handler.Handler;
import com.hdfcbank.giftcity.bff.commons.handler.HandlerContext;
import com.hdfcbank.giftcity.bff.commons.handler.HandlerResult;
import com.hdfcbank.giftcity.bff.commons.model.FcIndiaProfile;
import com.hdfcbank.giftcity.bff.customer.utility.CustomerUtil;
import com.hdfcbank.giftcity.bff.commons.utility.EmailHeaderAttachmentUtil;

import org.junit.jupiter.api.*;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.springframework.web.multipart.MultipartFile;

import ch.qos.logback.classic.Logger;
import ch.qos.logback.classic.Level;
import org.slf4j.LoggerFactory;

import java.util.*;

import static com.hdfcbank.giftcity.bff.commons.constant.CommonConstants.EMAIL_TEMPLATE;
import static com.hdfcbank.giftcity.bff.commons.enums.CommonJourneyStates.*;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.*;

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
class CustomerAofEmailAlertHandlerTest {

    private CommunicationFeignClient commClient;
    private EmailHeaderAttachmentUtil emailUtil;
    private CustomerAofEmailAlertHandler handler;

    @BeforeAll
    void muteLogs() {
        Logger root = (Logger) LoggerFactory.getLogger(Logger.ROOT_LOGGER_NAME);
        root.setLevel(Level.OFF);
    }

    @BeforeEach
    void init() {
        commClient = mock(CommunicationFeignClient.class);
        emailUtil = mock(EmailHeaderAttachmentUtil.class);
        handler = new CustomerAofEmailAlertHandler(commClient, emailUtil);
    }

    private HandlerContext createContext(String... states) {

        List<JourneyState> list = new ArrayList<>();
        for (String st : states) {
            list.add(JourneyState.builder()
                    .stateName(st)
                    .createdOn(new Date())
                    .build());
        }

        JourneyDetail detail = new JourneyDetail();
        detail.setJourneyStates(list);

        Profile profile = Profile.builder()
                .emailId("test@example.com")
                .build();

        JourneyData jd = new JourneyData();
        jd.setJourneyId("JID1");
        jd.setJourneyName("GIFT_CITY");
        jd.setJourneyDetail(detail);
        jd.setProfile(profile);

        HandlerContext ctx = HandlerContext.builder()
                .journeyData(jd)
                .properties(new HashMap<>())
                .data(new HashMap<>())
                .build();

        ctx.getProperties().put(EMAIL_TEMPLATE, "TEMP123");

        return ctx;
    }

      
    // Pre-conditions
      

    @Test
    void testPreConditions_true() {
        HandlerContext ctx = createContext(FTS_SUCCESS_CALLBACK.name());
        boolean result = handler.preConditions(ctx);

        assertThat(result).isTrue();
        assertThat(ctx.getJourneyData().getJourneyDetail().getJourneyStates()).hasSize(1);
    }

    @Test
    void testPreConditions_false_missingRequiredState() {
        HandlerContext ctx = createContext("OTHER_STATE");
        assertThat(handler.preConditions(ctx)).isFalse();
    }

    @Test
    void testPreConditions_false_alreadyCompleted() {
        HandlerContext ctx = createContext(
                FTS_SUCCESS_CALLBACK.name(),
                FTS_DOCS_RECEIVED_CALLBACK.name()
        );
        assertThat(handler.preConditions(ctx)).isFalse();
    }

      
    // SUCCESS FLOW
      

    @Test
    void testHandle_successFlow() {

        HandlerContext ctx = createContext(FTS_SUCCESS_CALLBACK.name());
        JourneyData jd = ctx.getJourneyData();
        jd.setIsd("91");
        jd.setMobileNumber("9999999999");

        FcIndiaProfile.Profile fcProfile = FcIndiaProfile.Profile.builder()
                .name("JOHN")
                .email("test@example.com")
                .build();

        try (MockedStatic<CustomerUtil> mockCU = Mockito.mockStatic(CustomerUtil.class)) {

            mockCU.when(() -> CustomerUtil.getPrimaryProfile(jd))
                    .thenReturn(Optional.of(fcProfile));

            MultipartFile multipart = mock(MultipartFile.class);
            InlineImage inline = new InlineImage("CID1", multipart);

            when(emailUtil.prepareInlineImage(any(), any(), any()))
                    .thenReturn(inline);

            UploadAttachmentResponse.UploadAttachmentDetail det =
                    UploadAttachmentResponse.UploadAttachmentDetail.builder()
                            .filename("f1").reference("r1").imageCidName("CID1")
                            .build();

            UploadAttachmentResponse uploadResp =
                    UploadAttachmentResponse.builder()
                            .status(ApiResponseStatus.success())
                            .data(det)
                            .build();

            when(commClient.uploadAttachmentFile(any(), any()))
                    .thenReturn(uploadResp);

            EmailMessageSuccess.EmailResponse msg =
                    EmailMessageSuccess.EmailResponse.builder()
                            .success(true)
                            .build();

            EmailMessageSuccess emailSuccess =
                    EmailMessageSuccess.builder()
                            .status(ApiResponseStatus.success())
                            .data(msg)
                            .build();

            when(commClient.sendEmail(any(), any())).thenReturn(emailSuccess);

            HandlerResult<EmailMessageSuccess> result = handler.handle(ctx);

            assertThat(result.isSuccess()).isTrue();
            assertThat(result.getResult().getData().isSuccess()).isTrue();
            assertThat(det.getFilename()).isEqualTo("f1");
            assertThat(det.getImageCidName()).isEqualTo("CID1");

            assertThat(emailSuccess.getStatus().getMessage()).isEqualTo("success");
        }
    }

      
    // uploadAttachmentFile → null response
      

    @Test
    void testHandle_inlineImageUploadNullResponse() {

        HandlerContext ctx = createContext(FTS_SUCCESS_CALLBACK.name());
        JourneyData jd = ctx.getJourneyData();
        jd.setIsd("91");
        jd.setMobileNumber("9999999999");

        MultipartFile mf = mock(MultipartFile.class);
        InlineImage img = new InlineImage("CID", mf);

        when(emailUtil.prepareInlineImage(any(), any(), any()))
                .thenReturn(img);

        when(commClient.uploadAttachmentFile(any(), any()))
                .thenReturn(null);

        try (MockedStatic<DownstreamResponseHandler> ds =
                     Mockito.mockStatic(DownstreamResponseHandler.class)) {

            ds.when(() ->
                            DownstreamResponseHandler.handleResponse(any(), any(), eq(false), any()))
                    .thenReturn(null);

            HandlerResult<EmailMessageSuccess> r = handler.handle(ctx);

            assertThat(r.isSuccess()).isFalse();
            assertThat(r.getResult()).isNull();
        }
    }

      
    // uploadAttachmentFile → data null
      

    @Test
    void testHandle_inlineImageUploadDataNull() {

        HandlerContext ctx = createContext(FTS_SUCCESS_CALLBACK.name());
        JourneyData jd = ctx.getJourneyData();
        jd.setIsd("91");
        jd.setMobileNumber("9999999999");

        MultipartFile mf = mock(MultipartFile.class);
        InlineImage img = new InlineImage("CID", mf);

        when(emailUtil.prepareInlineImage(any(), any(), any()))
                .thenReturn(img);

        UploadAttachmentResponse resp =
                UploadAttachmentResponse.builder()
                        .status(ApiResponseStatus.success())
                        .data(null)
                        .build();

        when(commClient.uploadAttachmentFile(any(), any()))
                .thenReturn(resp);

        try (MockedStatic<DownstreamResponseHandler> ds =
                     Mockito.mockStatic(DownstreamResponseHandler.class)) {

            ds.when(() ->
                            DownstreamResponseHandler.handleResponse(any(), any(), eq(false), any()))
                    .thenReturn(null);

            HandlerResult<EmailMessageSuccess> r = handler.handle(ctx);

            assertThat(r.isSuccess()).isFalse();

            assertThat(resp.getStatus().getCode()).isEqualTo("0000");
            assertThat(resp.getStatus().getMessage()).isEqualTo("success"); // optional
        }
    }

      
    // sendEmail FAILURE
      

    @Test
    void testHandle_sendEmailFailure() {

        HandlerContext ctx = createContext(FTS_SUCCESS_CALLBACK.name());
        JourneyData jd = ctx.getJourneyData();
        jd.setIsd("91");
        jd.setMobileNumber("9999999999");

        MultipartFile mf = mock(MultipartFile.class);
        InlineImage img = new InlineImage("CID", mf);

        when(emailUtil.prepareInlineImage(any(), any(), any()))
                .thenReturn(img);

        UploadAttachmentResponse.UploadAttachmentDetail det =
                UploadAttachmentResponse.UploadAttachmentDetail.builder()
                        .filename("f").reference("r").imageCidName("CID")
                        .build();

        UploadAttachmentResponse uploadResp =
                UploadAttachmentResponse.builder()
                        .status(ApiResponseStatus.success())
                        .data(det)
                        .build();

        when(commClient.uploadAttachmentFile(any(), any())).thenReturn(uploadResp);

        EmailMessageSuccess failureResp =
                EmailMessageSuccess.builder()
                        .status(ApiResponseStatus.downstreamApiError(null, "ERR"))
                        .data(EmailMessageSuccess.EmailResponse.builder().success(false).build())
                        .build();

        when(commClient.sendEmail(any(), any())).thenReturn(failureResp);

        try (MockedStatic<DownstreamResponseHandler> ds =
                     Mockito.mockStatic(DownstreamResponseHandler.class)) {

            ds.when(() ->
                            DownstreamResponseHandler.handleResponse(any(), any(), eq(false), any()))
                    .thenReturn(null);

            HandlerResult<EmailMessageSuccess> r = handler.handle(ctx);

            assertThat(r.isSuccess()).isFalse();

            assertThat(failureResp.getStatus().getMessage()).isEqualTo("downstream.api.error");
        }
    }

      
    // EXCEPTION FLOW
      

    @Test
    void testHandle_exception() {

        HandlerContext ctx = createContext(FTS_SUCCESS_CALLBACK.name());
        JourneyData jd = ctx.getJourneyData();
        jd.setIsd("91");
        jd.setMobileNumber("9999999999");

        try (MockedStatic<CustomerUtil> cu = Mockito.mockStatic(CustomerUtil.class);
             MockedStatic<DownstreamResponseHandler> ds = Mockito.mockStatic(DownstreamResponseHandler.class)) {

            cu.when(() -> CustomerUtil.getPrimaryProfile(any()))
                    .thenThrow(new RuntimeException("ERR"));

            ds.when(() ->
                            DownstreamResponseHandler.handleResponse(any(), any(), anyBoolean(), any()))
                    .thenReturn(null);

            HandlerResult<EmailMessageSuccess> r = handler.handle(ctx);

            assertThat(r.isSuccess()).isFalse();
        }
    }

      
    // Metadata tests
      

    @Test
    void testMetadata() {

        assertThat(handler.getType())
                .isEqualTo(Handler.HandlerType.BACKGROUND_TASKS_POST_SUBMIT_SUCCESS);

        assertThat(handler.getName())
                .isEqualTo(Handler.HandlerName.AOF_SUBMISSION_EMAIL_ALERT);

        assertThat(handler.successState())
                .isEqualTo(CUSTOMER_AOF_SUBMISSION_EMAIL_ALERT_SUCCESS);

        assertThat(handler.failureState())
                .isEqualTo(CUSTOMER_AOF_SUBMISSION_EMAIL_ALERT_FAILURE);
    }
}