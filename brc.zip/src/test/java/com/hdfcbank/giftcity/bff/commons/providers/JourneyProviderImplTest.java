package com.hdfcbank.giftcity.bff.commons.providers;

import com.hdfcbank.adapters.clients.feign.journey.JourneyServiceFeignClient;
import com.hdfcbank.common.models.vo.journey.JourneyData;
import com.hdfcbank.starter.logging.models.JourneyAliases;
import com.hdfcbank.starter.logging.properties.JourneyAliasProperties;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;

import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class JourneyProviderImplTest {

    @Mock
    private JourneyServiceFeignClient feignClient;

    @Mock
    private JourneyAliasProperties aliasProperties;

    @InjectMocks
    private JourneyProviderImpl journeyProvider;

    @BeforeEach
    void setup() {
        MockitoAnnotations.openMocks(this);
        journeyProvider = spy(new JourneyProviderImpl(feignClient, aliasProperties));
    }

    // fetch(): should call feign client and return JourneyData
    @Test
    void testFetch() {
        String journeyId = "J100";

        JourneyData expected = new JourneyData();
        when(feignClient.fetch(journeyId)).thenReturn(expected);

        JourneyData actual = journeyProvider.fetch(journeyId);

        verify(feignClient, times(1)).fetch(journeyId);
        assertEquals(expected, actual);
    }

    // findBy(): uses default JourneyProvider implementation using reflection
    @Test
    void testFindBy() throws Exception {
        String journeyId = "J200";

        JourneyData jd = new JourneyData();
        jd.setJourneyIdAlias("ID-ALIAS");
        jd.setJourneyNameAlias("NAME-ALIAS");

        // default JourneyProvider.findBy() calls fetch(), so mock fetch()
        doReturn(jd).when(journeyProvider).fetch(journeyId);

        JourneyAliases aliases = journeyProvider.findBy(journeyId);

        assertNotNull(aliases);
        assertEquals("ID-ALIAS", aliases.getJourneyIdAlias());
        assertEquals("NAME-ALIAS", aliases.getJourneyNameAlias());
    }

    // findBy(): returns null when fetch() returns null
    @Test
    void testFindByReturnsNullWhenFetchReturnsNull() {
        doReturn(null).when(journeyProvider).fetch("J300");

        JourneyAliases result = journeyProvider.findBy("J300");

        assertNull(result);
    }

    // update(): should simply return the same JourneyAliases (default implementation)
    @Test
    void testUpdate() {
        JourneyAliases ja = new JourneyAliases("ID", "NAME");

        JourneyAliases result = journeyProvider.update("J500", ja);

        assertEquals(ja, result);
    }

    // generateJourneyAlias(): tests ID alias generation + mapping lookup
    @Test
    void testGenerateJourneyAlias() {
        String journeyId = "J600";
        String journeyName = "LOAN";

        Map<String, String> mapping = new HashMap<>();
        mapping.put("LOAN", "LN-ALIAS");

        when(aliasProperties.getJourneyAliasMapping()).thenReturn(mapping);

        JourneyAliases aliases = journeyProvider.generateJourneyAlias(journeyId, journeyName);

        assertNotNull(aliases);
        assertEquals("LN-ALIAS", aliases.getJourneyNameAlias());
        assertTrue(aliases.getJourneyIdAlias().contains("-")); // generated alias always contains "-"
    }

    // getJourneyNameAlias(): fallback to UNKWN when mapping missing
    @Test
    void testJourneyNameAliasFallback() {
        when(aliasProperties.getJourneyAliasMapping()).thenReturn(null);

        String alias = journeyProvider.getJourneyNameAlias("UNKNOWN");

        assertEquals("UNKWN", alias);
    }

    // getJourneyIdAlias(): test epoch-based formatting
    @Test
    void testJourneyIdAliasFormat() {
        String alias = journeyProvider.getJourneyIdAlias();

        assertTrue(alias.contains("-"));
        assertTrue(alias.length() > 6);
    }
}