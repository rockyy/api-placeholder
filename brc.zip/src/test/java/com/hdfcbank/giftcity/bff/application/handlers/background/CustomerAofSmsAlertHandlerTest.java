package com.hdfcbank.giftcity.bff.application.handlers.background;

import ch.qos.logback.classic.Level;
import ch.qos.logback.classic.Logger;
import org.slf4j.LoggerFactory;

import com.hdfcbank.adapters.clients.feign.communication.CommunicationFeignClient;
import com.hdfcbank.adapters.vo.AlertMessageResponse;
import com.hdfcbank.adapters.vo.SendMessageRequest;
import com.hdfcbank.common.models.vo.core.ApiResponseStatus;
import com.hdfcbank.common.models.vo.journey.JourneyData;
import com.hdfcbank.common.models.vo.journey.JourneyDetail;
import com.hdfcbank.common.models.vo.journey.JourneyState;
import com.hdfcbank.common.models.vo.journey.Profile;
import com.hdfcbank.giftcity.bff.commons.enums.CommonJourneyStates;
import com.hdfcbank.giftcity.bff.commons.exception.handler.DownstreamResponseHandler;
import com.hdfcbank.giftcity.bff.commons.handler.HandlerContext;
import com.hdfcbank.giftcity.bff.commons.handler.HandlerResult;
import com.hdfcbank.giftcity.bff.commons.handler.Handler.HandlerName;
import com.hdfcbank.giftcity.bff.commons.model.CustomValidationStatus;
import com.hdfcbank.giftcity.bff.commons.model.FcIndiaProfile;
import com.hdfcbank.giftcity.bff.customer.config.CustomerApiProperties;
import com.hdfcbank.giftcity.bff.customer.utility.CustomerUtil;

import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;

import org.mockito.*;
import org.mockito.MockedStatic;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.*;

import static com.hdfcbank.giftcity.bff.commons.constant.CommonConstants.SMS_TEMPLATE;
import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
class CustomerAofSmsAlertHandlerTest {

    @BeforeAll
    static void muteLogs() {
        Logger root = (Logger) LoggerFactory.getLogger(Logger.ROOT_LOGGER_NAME);
        root.setLevel(Level.OFF);
    }

    @Mock
    private CommunicationFeignClient communicationFeignClient;

    @Mock
    private CustomerApiProperties customerApiProperties;

    @InjectMocks
    private CustomerAofSmsAlertHandler handler;

    private JourneyData journeyData;
    private HandlerContext ctx;

    @BeforeEach
    void setup() {

        lenient().when(customerApiProperties.getAofPendingDocumentSmsAlert())
                .thenReturn(createSmsProps());

        JourneyState submitState = JourneyState.builder()
                .stateName(CommonJourneyStates.FTS_AOF_SUBMIT_SUCCESS.name())
                .createdOn(new Date())
                .build();

        JourneyDetail detail = JourneyDetail.builder()
                .journeyStates(new ArrayList<>(List.of(submitState)))
                .build();

        journeyData = JourneyData.builder()
                .journeyId("JID123")
                .journeyName("GIFT_CITY")
                .isd("+91")
                .mobileNumber("9999999999")
                .profile(Profile.builder().emailId("user@mail.com").build())
                .journeyDetail(detail)
                .build();

        ctx = HandlerContext.builder()
                .journeyData(journeyData)
                .properties(Map.of(SMS_TEMPLATE, "TEMP123"))
                .build();
    }

    private CustomerApiProperties.ApiDetails createSmsProps() {
        CustomerApiProperties.ApiDetails d = new CustomerApiProperties.ApiDetails();
        d.setServiceDefaults(Map.of("applicationRejectionDays", "2"));
        return d;
    }

    // -------------------------------------------------------------------------
    @Test
    void preConditions_shouldReturnTrue() {
        assertTrue(handler.preConditions(ctx));
        assertEquals("JID123", ctx.getJourneyData().getJourneyId());
        assertEquals(1, ctx.getJourneyData().getJourneyDetail().getJourneyStates().size());
    }

    @Test
    void preConditions_shouldReturnFalse_whenCallbackStatePresent() {

        JourneyDetail jd = journeyData.getJourneyDetail();
        jd.setJourneyStates(new ArrayList<>(jd.getJourneyStates()));

        jd.getJourneyStates().add(
                JourneyState.builder()
                        .stateName(CommonJourneyStates.FTS_DOCS_RECEIVED_CALLBACK.name())
                        .createdOn(new Date())
                        .build()
        );

        assertFalse(handler.preConditions(ctx));
    }

    // -------------------------------------------------------------------------
    @Test
    void handle_shouldReturnSuccess_whenStatusIs0000() {

        JourneyDetail jd = journeyData.getJourneyDetail();
        jd.setJourneyStates(new ArrayList<>(jd.getJourneyStates()));

        FcIndiaProfile.Profile fc = FcIndiaProfile.Profile.builder()
                .name("Test User")
                .build();

        JourneyState creation = JourneyState.builder()
                .stateName(CommonJourneyStates.CREATE_APPLICATION_NUMBER_SUCCESS.name())
                .createdOn(new Date())
                .build();

        jd.getJourneyStates().add(creation);

        AlertMessageResponse response = successResponse();

        try (MockedStatic<CustomerUtil> util = mockStatic(CustomerUtil.class)) {

            util.when(() -> CustomerUtil.getPrimaryProfile(journeyData))
                    .thenReturn(Optional.of(fc));

            util.when(() -> CustomerUtil.getJourneyState(
                            journeyData,
                            CommonJourneyStates.CREATE_APPLICATION_NUMBER_SUCCESS.name()))
                    .thenReturn(Optional.of(creation));

            when(communicationFeignClient.sendAlertMsg(any(), eq("JID123")))
                    .thenReturn(response);

            HandlerResult<AlertMessageResponse> result = handler.handle(ctx);

            assertTrue(result.isSuccess());
            assertEquals("0000", result.getResult().getStatus().getCode());
            assertTrue(result.getResult().getData().isSuccess());
            assertEquals("SUCCESS", result.getResult().getStatus().getMessage());
        }
    }

    private AlertMessageResponse successResponse() {
        AlertMessageResponse r = new AlertMessageResponse();
        ApiResponseStatus st = new ApiResponseStatus();
        st.setCode("0000");
        st.setMessage("SUCCESS");
        r.setStatus(st);
        r.setData(AlertMessageResponse.ResponseMsg.builder().success(true).build());
        return r;
    }

    // -------------------------------------------------------------------------
    @Test
    void handle_shouldReturnFailure_whenDownstreamStatusNot0000() {

        JourneyDetail jd = journeyData.getJourneyDetail();
        jd.setJourneyStates(new ArrayList<>(jd.getJourneyStates()));

        FcIndiaProfile.Profile fc = FcIndiaProfile.Profile.builder()
                .name("User")
                .build();

        JourneyState creation = JourneyState.builder()
                .stateName(CommonJourneyStates.CREATE_APPLICATION_NUMBER_SUCCESS.name())
                .createdOn(new Date())
                .build();

        jd.getJourneyStates().add(creation);

        AlertMessageResponse response = failureResponse("9999");

        CustomValidationStatus custom = CustomValidationStatus.builder()
                .code("ERR")
                .message("Downstream failed")
                .build();

        try (MockedStatic<CustomerUtil> util = mockStatic(CustomerUtil.class);
             MockedStatic<DownstreamResponseHandler> handlerMock = mockStatic(DownstreamResponseHandler.class)) {

            util.when(() -> CustomerUtil.getPrimaryProfile(journeyData))
                    .thenReturn(Optional.of(fc));

            util.when(() -> CustomerUtil.getJourneyState(
                            journeyData,
                            CommonJourneyStates.CREATE_APPLICATION_NUMBER_SUCCESS.name()))
                    .thenReturn(Optional.of(creation));

            when(communicationFeignClient.sendAlertMsg(any(), eq("JID123")))
                    .thenReturn(response);

            handlerMock.when(() -> DownstreamResponseHandler.handleResponse(
                            eq(response),
                            eq(HandlerName.AOF_SUBMISSION_SMS_ALERT.name()),
                            eq(false),
                            eq("GIFT_CITY")))
                    .thenReturn(custom);

            HandlerResult<AlertMessageResponse> result = handler.handle(ctx);

            assertFalse(result.isSuccess());
            assertEquals("ERR", result.getApiResponseStatus().getCode());
            assertEquals("FAILED", response.getStatus().getMessage());
        }
    }

    private AlertMessageResponse failureResponse(String code) {
        AlertMessageResponse r = new AlertMessageResponse();
        ApiResponseStatus st = new ApiResponseStatus();
        st.setCode(code);
        st.setMessage("FAILED");
        r.setStatus(st);
        return r;
    }

    // -------------------------------------------------------------------------
    @Test
    void handle_shouldReturnFailure_whenResponseNull() {

        FcIndiaProfile.Profile fc =
                FcIndiaProfile.Profile.builder().name("Dummy").build();

        CustomValidationStatus custom = CustomValidationStatus.builder()
                .code("NULL")
                .message("Null response")
                .build();

        try (MockedStatic<CustomerUtil> util = mockStatic(CustomerUtil.class);
             MockedStatic<DownstreamResponseHandler> handlerMock =
                     mockStatic(DownstreamResponseHandler.class)) {

            util.when(() -> CustomerUtil.getPrimaryProfile(any()))
                    .thenReturn(Optional.of(fc));

            handlerMock.when(() -> DownstreamResponseHandler.handleResponse(
                    eq(null),
                    eq(HandlerName.AOF_SUBMISSION_SMS_ALERT.name()),
                    eq(false),
                    eq("GIFT_CITY"))).thenReturn(custom);

            when(communicationFeignClient.sendAlertMsg(any(), eq("JID123")))
                    .thenReturn(null);

            HandlerResult<AlertMessageResponse> result = handler.handle(ctx);

            assertFalse(result.isSuccess());
            assertEquals("NULL", result.getApiResponseStatus().getCode());
        }
    }

    // -------------------------------------------------------------------------
    @Test
    void handle_shouldReturnFailure_whenExceptionThrown() {

        CustomValidationStatus custom = CustomValidationStatus.builder()
                .code("EX")
                .message("Exception occurred")
                .build();

        try (MockedStatic<CustomerUtil> util = mockStatic(CustomerUtil.class);
             MockedStatic<DownstreamResponseHandler> handlerMock =
                     mockStatic(DownstreamResponseHandler.class)) {

            util.when(() -> CustomerUtil.getPrimaryProfile(any()))
                    .thenThrow(new RuntimeException("boom"));

            handlerMock.when(() -> DownstreamResponseHandler.handleResponse(
                    eq(null),
                    eq(HandlerName.AOF_SUBMISSION_SMS_ALERT.name()),
                    eq(false),
                    eq("GIFT_CITY"))).thenReturn(custom);

            HandlerResult<AlertMessageResponse> result = handler.handle(ctx);

            assertFalse(result.isSuccess());
            assertEquals("EX", result.getApiResponseStatus().getCode());
        }
    }

    // -------------------------------------------------------------------------
    @Test
    void enumCoverage() {

        assertEquals(CommonJourneyStates.CUSTOMER_AOF_SUBMISSION_SMS_ALERT_SUCCESS,
                handler.successState());

        assertEquals(CommonJourneyStates.CUSTOMER_AOF_SUBMISSION_SMS_ALERT_FAILURE,
                handler.failureState());

        assertEquals(
                com.hdfcbank.giftcity.bff.commons.handler.Handler.HandlerType.BACKGROUND_TASKS_POST_SUBMIT_SUCCESS,
                handler.getType());

        assertEquals(HandlerName.AOF_SUBMISSION_SMS_ALERT, handler.getName());
    }
}