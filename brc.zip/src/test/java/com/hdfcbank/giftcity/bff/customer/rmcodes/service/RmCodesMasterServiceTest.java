package com.hdfcbank.giftcity.bff.customer.rmcodes.service;

import com.hdfcbank.giftcity.bff.customer.rmcodes.entity.RmCodesMasterEntity;
import com.hdfcbank.giftcity.bff.customer.rmcodes.repository.RmCodesMasterRepository;
import com.hdfcbank.service.adapters.clients.feign.customer.CustomerServiceFeignClient;
import com.hdfcbank.service.adapters.vo.customer.RmDetailsResponse;

import org.junit.jupiter.api.*;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.*;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.argThat;

import ch.qos.logback.classic.Level;
import ch.qos.logback.classic.Logger;
import org.slf4j.LoggerFactory;

class RmCodesMasterServiceTest {

    // MUTE ALL LOGGING
    @BeforeAll
    static void muteLogs() {
        Logger root = (Logger) LoggerFactory.getLogger(Logger.ROOT_LOGGER_NAME);
        root.setLevel(Level.OFF);
    }

    private RmCodesMasterRepository repository;
    private CustomerServiceFeignClient feignClient;
    private RmCodesMasterService service;

    @BeforeEach
    void setup() {
        repository = mock(RmCodesMasterRepository.class);
        feignClient = mock(CustomerServiceFeignClient.class);
        service = new RmCodesMasterService(repository, feignClient);
    }

    // Helper to create wrapped downstream response
    private RmDetailsResponse createResponse(List<RmDetailsResponse.RmDetails> rmList) {

        RmDetailsResponse.ResponseString respString = new RmDetailsResponse.ResponseString();
        respString.setRmDetails(rmList);

        RmDetailsResponse resp = new RmDetailsResponse();
        resp.setResponseString(respString);

        // Required by downstream adapter logic
        resp.setData(resp);

        return resp;
    }

    // ================================================================
    //            NULL Response → nothing saved
    // ================================================================
    @Test
    void test_fetchNull() {

        when(feignClient.fetchRmDetails()).thenReturn(null);

        service.saveOrUpdateRmCodes();

        verify(repository, never()).deleteAll();
        verify(repository, never()).saveAll(anyList());

        // Added assertions
        assertThat(feignClient.fetchRmDetails()).isNull();
    }

    // ================================================================
    //            Empty downstream list → nothing saved
    // ================================================================
    @Test
    void test_emptyDownstreamList() {

        RmDetailsResponse resp = createResponse(List.of());
        when(feignClient.fetchRmDetails()).thenReturn(resp);

        service.saveOrUpdateRmCodes();

        verify(repository, never()).deleteAll();
        verify(repository, never()).saveAll(anyList());

        // Assertions
        assertThat(resp.getResponseString().getRmDetails()).isEmpty();
        assertThat(resp.getData()).isEqualTo(resp);
    }

    // ================================================================
    //            Single record → deleteAll + saveAll called
    // ================================================================
    @Test
    void test_singleRecord() {

        RmDetailsResponse.RmDetails d1 =
                new RmDetailsResponse.RmDetails("PORT1", "EMP001", "John", null, null, null);

        RmDetailsResponse resp = createResponse(List.of(d1));
        when(feignClient.fetchRmDetails()).thenReturn(resp);

        service.saveOrUpdateRmCodes();

        verify(repository).deleteAll();
        verify(repository).saveAll(anyList());

        // Additional assertions
        assertThat(resp.getResponseString().getRmDetails()).hasSize(1);
        assertThat(resp.getResponseString().getRmDetails().get(0).getEmployeeCode()).isEqualTo("EMP001");
    }

    // ================================================================
    //            Duplicate employee codes → latest record must win
    // ================================================================
    @Test
    void test_duplicateEmployeeCodes_keepLatest() {

        RmDetailsResponse.RmDetails oldRec =
                new RmDetailsResponse.RmDetails("PORT1", "EMP001", "OldName", null, null, null);

        RmDetailsResponse.RmDetails newRec =
                new RmDetailsResponse.RmDetails("PORT999", "EMP001", "LatestName", null, null, null);

        RmDetailsResponse resp = createResponse(List.of(oldRec, newRec));
        when(feignClient.fetchRmDetails()).thenReturn(resp);

        service.saveOrUpdateRmCodes();

        verify(repository).deleteAll();

        verify(repository).saveAll(argThat(iter -> {
            List<RmCodesMasterEntity> list = (List<RmCodesMasterEntity>) iter;

            // Assertions added
            assertThat(list).hasSize(1);
            assertThat(list.get(0).getEmployeeCode()).isEqualTo("EMP001");
            assertThat(list.get(0).getRmPortfolioCode()).isEqualTo("PORT999");
            assertThat(list.get(0).getEmployeeName()).isEqualTo("LatestName");

            return true;
        }));

        assertThat(resp.getResponseString().getRmDetails()).hasSize(2);
    }

    // ================================================================
    //            Exception during deleteAll → saveAll must NOT be called
    // ================================================================
    @Test
    void test_exceptionDuringDeleteAll() {

        RmDetailsResponse.RmDetails d1 =
                new RmDetailsResponse.RmDetails("PORT8", "EMP888", "AnyName", null, null, null);

        RmDetailsResponse resp = createResponse(List.of(d1));
        when(feignClient.fetchRmDetails()).thenReturn(resp);

        doThrow(new RuntimeException("DB ERROR")).when(repository).deleteAll();

        service.saveOrUpdateRmCodes();

        verify(repository, times(1)).deleteAll();
        verify(repository, never()).saveAll(anyList());

        // Extra assertions
        assertThat(resp.getResponseString().getRmDetails()).hasSize(1);
        assertThat(resp.getResponseString().getRmDetails().get(0).getEmployeeCode()).isEqualTo("EMP888");
    }

    @Test
    void saveOrUpdateRmCodes_shouldContainSaveFailureAfterDeletingExistingRecords() {
        RmDetailsResponse.RmDetails detail =
                new RmDetailsResponse.RmDetails("PORT1", "EMP001", "Customer RM", null, null, null);
        when(feignClient.fetchRmDetails()).thenReturn(createResponse(List.of(detail)));
        when(repository.saveAll(anyList())).thenThrow(new IllegalStateException("Save failed"));

        assertDoesNotThrow(service::saveOrUpdateRmCodes);

        org.mockito.InOrder order = inOrder(repository);
        order.verify(repository).deleteAll();
        order.verify(repository).saveAll(anyList());
    }

    @Test
    void saveOrUpdateRmCodes_shouldPropagateFetchFailureWithoutDeletingRecords() {
        IllegalStateException failure = new IllegalStateException("Fetch failed");
        when(feignClient.fetchRmDetails()).thenThrow(failure);

        assertSame(failure, assertThrows(IllegalStateException.class, service::saveOrUpdateRmCodes));

        verifyNoInteractions(repository);
    }
}
