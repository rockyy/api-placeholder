package com.hdfcbank.giftcity.bff.commons.model;

import com.hdfcbank.common.models.vo.core.ApiResponseStatus;
import com.hdfcbank.common.models.vo.core.ErrorRef;
import com.hdfcbank.giftcity.bff.customer.model.CustomerApiStatusCode;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class InspireApiResponseTest {

    @Test
    void getStatus_shouldPreserveMissingStatus() {
        InspireApiResponse<String> response = InspireApiResponse.<String>builder().status(null).build();

        assertNull(response.getStatus());
    }

    @Test
    void getStatus_shouldPreserveCustomStatusAndErrorDetails() {
        InspireApiResponse<String> response = InspireApiResponse.customValidationError(
                CustomerApiStatusCode.UNKNOWN, "validation-ref", "Validation failed", List.of("Invalid input"));

        CustomValidationStatus status = response.getStatus();

        assertEquals(CustomerApiStatusCode.UNKNOWN.getCode(), status.getCode());
        assertEquals(CustomerApiStatusCode.UNKNOWN.getMessage(), status.getMessage());
        assertEquals("Validation failed", status.getTitle());
        assertEquals("validation-ref", status.getErrorRef());
        assertEquals(List.of("Invalid input"), status.getErrors());
        assertSame(status, response.getStatus());
    }

    @Test
    void getStatus_shouldPreserveBaseStatusFieldsDuringConversion() {
        ApiResponseStatus base = new ApiResponseStatus(CustomerApiStatusCode.UNKNOWN);
        base.setErrorRef(ErrorRef.inputValidation().asString());
        base.setErrors(List.of("Invalid input"));
        InspireApiResponse<String> response = InspireApiResponse.<String>builder()
                .status(base).data("payload").build();

        CustomValidationStatus status = response.getStatus();

        assertEquals(base.getCode(), status.getCode());
        assertEquals(base.getMessage(), status.getMessage());
        assertEquals(base.getErrors(), status.getErrors());
        assertNull(status.getTitle());
        assertNull(status.getType());
        assertEquals("payload", response.getData());
    }
}
