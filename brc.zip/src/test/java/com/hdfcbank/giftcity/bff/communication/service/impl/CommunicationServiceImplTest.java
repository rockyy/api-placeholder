package com.hdfcbank.giftcity.bff.communication.service.impl;

import com.hdfcbank.adapters.vo.GenerateOtpRequest;
import com.hdfcbank.adapters.vo.GenerateOtpResponse;
import com.hdfcbank.adapters.vo.VerifyOtpRequest;
import com.hdfcbank.adapters.vo.VerifyOtpResponse;
import com.hdfcbank.giftcity.bff.commons.exception.OTPValidationException;
import com.hdfcbank.giftcity.bff.communication.CommunicationServiceAdapter;
import com.hdfcbank.giftcity.bff.communication.mapper.CommunicationMapper;
import com.hdfcbank.giftcity.bff.customer.config.CustomerApiProperties;
import com.hdfcbank.giftcity.bff.customer.model.OtpApiStatusCode;
import com.hdfcbank.giftcity.bff.customer.model.ValidateCustomerRequest;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.junit.jupiter.api.extension.ExtendWith;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class CommunicationServiceImplTest {

    @Mock
    private CommunicationServiceAdapter communicationServiceAdapter;

    @Mock
    private CommunicationMapper communicationMapper;

    @Mock
    private CustomerApiProperties customerApiProperties;

    @InjectMocks
    private CommunicationServiceImpl communicationService;

    // ============================
    //         TEST: sendOtp()
    // ============================
    @Test
    @DisplayName("sendOtp: should create request using mapper and call adapter")
    void testSendOtp() {

        String mobile = "9999999999";
        String email = "abc@test.com";
        String journeyName = "AOF";
        String journeyId = "J123";

        Map<String, Map<String, String>> templateMap = new HashMap<>();
        Map<String, String> inner = new HashMap<>();
        inner.put("send", "TEMPLATE_OTP_SEND");
        templateMap.put("AOF", inner);

        when(customerApiProperties.getTemplateId()).thenReturn(templateMap);

        GenerateOtpRequest mappedRequest = GenerateOtpRequest.builder()
                .mobileNumber(mobile)
                .emailId(email)
                .templateId("TEMPLATE_OTP_SEND")
                .build();

        when(communicationMapper.toGenerateOtpRequest(mobile, email, "TEMPLATE_OTP_SEND"))
                .thenReturn(mappedRequest);

        GenerateOtpResponse expectedResponse = new GenerateOtpResponse();
        when(communicationServiceAdapter.sendCommunication(mappedRequest, journeyId, false))
                .thenReturn(expectedResponse);

        GenerateOtpResponse response =
                communicationService.sendOtp(mobile, email, journeyName, journeyId);

        //         Assertions
        assertNotNull(response);
        assertEquals(expectedResponse, response);
        assertEquals("9999999999", mappedRequest.getMobileNumber());
        assertEquals("abc@test.com", mappedRequest.getEmailId());
        assertEquals("TEMPLATE_OTP_SEND", mappedRequest.getTemplateId());

        verify(communicationMapper).toGenerateOtpRequest(mobile, email, "TEMPLATE_OTP_SEND");
        verify(communicationServiceAdapter).sendCommunication(mappedRequest, journeyId, false);

        verifyNoMoreInteractions(communicationMapper, communicationServiceAdapter);
    }

    // ============================
    //         TEST: resendOtp()
    // ============================
    @Test
    @DisplayName("resendOtp: should create request using mapper and call adapter with resend flag")
    void testResendOtp() {

        String mobile = "9999999999";
        String email = "abc@test.com";
        String journeyName = "AOF";
        String journeyId = "J123";

        Map<String, Map<String, String>> templateMap = new HashMap<>();
        Map<String, String> inner = new HashMap<>();
        inner.put("resend", "TEMPLATE_OTP_RESEND");
        templateMap.put("AOF", inner);

        when(customerApiProperties.getTemplateId()).thenReturn(templateMap);

        GenerateOtpRequest mappedRequest = GenerateOtpRequest.builder()
                .mobileNumber(mobile)
                .emailId(email)
                .templateId("TEMPLATE_OTP_RESEND")
                .build();

        when(communicationMapper.toGenerateOtpRequest(mobile, email, "TEMPLATE_OTP_RESEND"))
                .thenReturn(mappedRequest);

        GenerateOtpResponse expectedResponse = new GenerateOtpResponse();
        when(communicationServiceAdapter.sendCommunication(mappedRequest, journeyId, true))
                .thenReturn(expectedResponse);

        GenerateOtpResponse response =
                communicationService.resendOtp(mobile, email, journeyName, journeyId);

        //         Assertions
        assertNotNull(response);
        assertEquals(expectedResponse, response);
        assertEquals("TEMPLATE_OTP_RESEND", mappedRequest.getTemplateId());

        verify(communicationMapper).toGenerateOtpRequest(mobile, email, "TEMPLATE_OTP_RESEND");
        verify(communicationServiceAdapter).sendCommunication(mappedRequest, journeyId, true);

        verifyNoMoreInteractions(communicationMapper, communicationServiceAdapter);
    }

    // ============================
    //         TEST: verifyOtp()
    // ============================
    @Test
    @DisplayName("verifyOtp: should map request and use adapter to verify OTP")
    void testVerifyOtp() {

        ValidateCustomerRequest validateRequest = ValidateCustomerRequest.builder()
                .otp("123456")
                .txnRef("TXN111")
                .consents(Collections.emptyList())
                .build();

        String journeyId = "J999";

        Map<String, String> serviceDefaultMap = new HashMap<>();
        serviceDefaultMap.put("messageType", "SMS");
        serviceDefaultMap.put("channel", "MOBILE");

        CustomerApiProperties.ApiDetails apiDetails = new CustomerApiProperties.ApiDetails();
        apiDetails.setServiceDefaults(serviceDefaultMap);

        when(customerApiProperties.getGenerateAndDispatchOtp()).thenReturn(apiDetails);

        VerifyOtpRequest verifyOtpRequest = VerifyOtpRequest.builder()
                .otpValue("123456")
                .channel("MOBILE")
                .messageType("SMS")
                .txnRef("TXN111")
                .build();

        when(communicationMapper.toVerifyOtpRequest(validateRequest, serviceDefaultMap))
                .thenReturn(verifyOtpRequest);

        VerifyOtpResponse expectedResponse = new VerifyOtpResponse();
        when(communicationServiceAdapter.verifyOtp(verifyOtpRequest, journeyId))
                .thenReturn(expectedResponse);

        VerifyOtpResponse response =
                communicationService.verifyOtp(validateRequest, journeyId);

        //         Assertions
        assertNotNull(response);
        assertEquals(expectedResponse, response);
        assertEquals("123456", verifyOtpRequest.getOtpValue());
        assertEquals("TXN111", verifyOtpRequest.getTxnRef());
        assertEquals("SMS", verifyOtpRequest.getMessageType());
        assertEquals("MOBILE", verifyOtpRequest.getChannel());

        verify(communicationMapper).toVerifyOtpRequest(validateRequest, serviceDefaultMap);
        verify(communicationServiceAdapter).verifyOtp(verifyOtpRequest, journeyId);

        verifyNoMoreInteractions(communicationMapper, communicationServiceAdapter);
    }

    // ============================
    //         NEGATIVE TEST: Adapter throws exception
    // ============================
    @Test
    @DisplayName("sendOtp: should propagate exception from adapter")
    void testSendOtpThrowsException() {

        String mobile = "99999999";
        String email = "abc@test.com";
        String journeyName = "AOF";
        String journeyId = "J777";

        Map<String, Map<String, String>> templateMap = new HashMap<>();
        Map<String, String> inner = new HashMap<>();
        inner.put("send", "TEMP_123");
        templateMap.put("AOF", inner);

        when(customerApiProperties.getTemplateId()).thenReturn(templateMap);

        GenerateOtpRequest mappedRequest = GenerateOtpRequest.builder()
                .mobileNumber(mobile)
                .emailId(email)
                .templateId("TEMP_123")
                .build();

        when(communicationMapper.toGenerateOtpRequest(mobile, email, "TEMP_123"))
                .thenReturn(mappedRequest);

        when(communicationServiceAdapter.sendCommunication(mappedRequest, journeyId, false))
                .thenThrow(new OTPValidationException(OtpApiStatusCode.COMMUNICATION_SERVICE_ERROR));

        OTPValidationException ex = assertThrows(
                OTPValidationException.class,
                () -> communicationService.sendOtp(mobile, email, journeyName, journeyId)
        );

        //         Correct: your class only has getMessage()
        assertNotNull(ex);
        assertEquals("Communication service returned error", ex.getMessage());

        verify(communicationMapper).toGenerateOtpRequest(mobile, email, "TEMP_123");
        verify(communicationServiceAdapter).sendCommunication(mappedRequest, journeyId, false);

        verifyNoMoreInteractions(communicationMapper, communicationServiceAdapter);
    }
}