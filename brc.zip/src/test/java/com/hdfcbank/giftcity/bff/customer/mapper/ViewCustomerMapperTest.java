package com.hdfcbank.giftcity.bff.customer.mapper;

import com.hdfcbank.common.models.vo.journey.Address;
import com.hdfcbank.common.models.vo.journey.JourneyData;
import com.hdfcbank.giftcity.bff.commons.enums.JourneyPageName;
import com.hdfcbank.giftcity.bff.commons.model.FcIndiaProfile;
import com.hdfcbank.giftcity.bff.commons.model.MasterDataValue;
import com.hdfcbank.giftcity.bff.commons.utility.CommonUtil;
import com.hdfcbank.giftcity.bff.customer.config.ReviewCustomerProperties;
import com.hdfcbank.giftcity.bff.customer.model.CustomerDetails;
import com.hdfcbank.giftcity.bff.infrastructure.service.JourneyService;
import com.hdfcbank.giftcity.bff.master.mapper.CountryMapper;
import org.junit.jupiter.api.*;
import org.mapstruct.factory.Mappers;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.MockitoAnnotations;

import java.lang.reflect.Field;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.function.Function;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class ViewCustomerMapperTest {

    private ViewCustomerMapper mapper;

    @Mock
    private CountryMapper countryMapper;

    @BeforeEach
    void setup() {
        MockitoAnnotations.openMocks(this);

        mapper = Mappers.getMapper(ViewCustomerMapper.class);

        // Inject mock CountryMapper dynamically
        injectMockCountryMapper(mapper, countryMapper);

        // Set expectation for nationality mapping
        when(countryMapper.descriptionFromCode("IN")).thenReturn("India");
        when(countryMapper.descriptionFromCode("US")).thenReturn("United States");
    }

    private void injectMockCountryMapper(ViewCustomerMapper mapper, CountryMapper mock) {
        // Iterate over all fields of the generated implementation
        for (Field field : mapper.getClass().getDeclaredFields()) {
            if (CountryMapper.class.isAssignableFrom(field.getType())) {
                field.setAccessible(true);
                try {
                    field.set(mapper, mock);
                } catch (IllegalAccessException e) {
                    throw new RuntimeException("Failed to inject CountryMapper", e);
                }
                return;
            }
        }
        throw new IllegalStateException("CountryMapper field not found in generated mapper!");
    }

    // ---------- getFcProfile ----------
    @Test
    void test_getFcProfile_success() {
        JourneyData jd = new JourneyData();

        FcIndiaProfile.Profile profile = new FcIndiaProfile.Profile();
        FcIndiaProfile fc = new FcIndiaProfile();
        fc.setProfiles(List.of(profile));

        try (MockedStatic<JourneyService> mocked = mockStatic(JourneyService.class)) {

            mocked.when(() ->
                    JourneyService.extractFromJourney(
                            eq(jd),
                            eq(JourneyPageName.CUSTOMER_FC_INDIA_DETAIL.getPageName()),
                            eq(FcIndiaProfile.class),
                            any(Function.class)
                    )
            ).thenAnswer(invocation -> Optional.of(profile));

            FcIndiaProfile.Profile result = mapper.getFcProfile(jd);

            assertNotNull(result);
            assertSame(profile, result);
        }
    }

    @Test
    void test_getFcProfile_nullProfile() {
        JourneyData jd = new JourneyData();

        try (MockedStatic<JourneyService> mocked = mockStatic(JourneyService.class)) {
            mocked.when(() ->
                    JourneyService.extractFromJourney(
                            any(),
                            any(),
                            eq(FcIndiaProfile.class),
                            any())
            ).thenReturn(Optional.empty());

            assertNull(mapper.getFcProfile(jd));
        }
    }

    // ---------- buildTaxResidency ----------
    @Test
    void test_buildTaxResidency_masksTaxId() {
        CustomerDetails.TaxResidency tr =
                mapper.buildTaxResidency("IND", "ABCDEFGH123", "TIN");

        assertEquals("IND", tr.getCountryOfTaxResidency());
        assertEquals("TIN", tr.getTaxIdType());
        assertNotNull(tr.getTaxIdNumber());
        assertTrue(tr.getTaxIdNumber().contains("*"));
    }

    @Test
    void test_buildTaxResidency_nullTaxId() {
        CustomerDetails.TaxResidency tr =
                mapper.buildTaxResidency("IND", null, "TIN");

        assertNull(tr.getTaxIdNumber());
    }

    // ---------- buildAddress ----------
    @Test
    void test_buildAddress_filtersNulls() {
        String result = mapper.buildAddress("A", "", null, "B", "  ", "C");
        assertEquals("A, B, C", result);
    }

    // ---------- toSingleLineMailingAddress ----------
    @Test
    void test_toSingleLineMailingAddress() {
        FcIndiaProfile.Profile p = new FcIndiaProfile.Profile();
        p.setMailingAddress1("L1");
        p.setMailingAddress2("L2");
        p.setMailingAddress3("L3");
        p.setMailingCity("Mumbai");
        p.setMailingState("MH");
        p.setMailingCountry(MasterDataValue.builder().description("India").build());
        p.setMailingPinCode("400001");

        String address = mapper.toSingleLineMailingAddress(p);

        assertTrue(address.contains("L1"));
        assertTrue(address.contains("Mumbai"));
        assertTrue(address.contains("India"));
        assertTrue(address.contains("400001"));
    }

    // ---------- toSingleLinePermanentAddress ----------
    @Test
    void test_toSingleLinePermanentAddress_masksAddress() {
        FcIndiaProfile.Profile p = new FcIndiaProfile.Profile();
        p.setAddress("A1");
        p.setAddress1("A2");
        p.setAddress2("A3");
        p.setAddress3("A4");
        p.setCity("Delhi");
        p.setState("DL");
        p.setCountry(MasterDataValue.builder().description("India").build());
        p.setPinCode("110001");

        String result = mapper.toSingleLinePermanentAddress(p);

        assertTrue(result.contains("Delhi"));
        assertTrue(result.contains("India"));
    }

    // ---------- toCustomerAddress ----------
    @Test
    void test_toCustomerAddress() {
        Address addr = new Address();
        addr.setZipCode("445566");
        addr.setAddress1("Test");
        addr.setCity("City");
        addr.setState("ST");

        CustomerDetails.CustomerAddress ca = mapper.toCustomerAddress(addr);

        assertEquals("445566", ca.getPinCode());
        assertEquals("Test", ca.getAddress1());
        assertEquals("City", ca.getCity());
    }

    // ---------- mapCustomerProfile (end-to-end) ----------
    @Test
    void test_mapCustomerProfile_fullMapping() {

        JourneyData jd = new JourneyData();
        jd.setMobileNumber("9876543210");
        jd.setIsd("+91");

        FcIndiaProfile.Profile p = new FcIndiaProfile.Profile();
        p.setDob("1990-12-12");
        p.setEmail("john.doe@example.com");
        p.setGender("M");
        p.setPanNumber("ABCDE1234F");

        p.setCustomerTitle("MR");
        p.setMailingAddress1("M1");
        p.setMailingAddress2("M2");
        p.setMailingAddress3("M3");
        p.setMailingCity("Mumbai");
        p.setMailingState("MH");
        p.setMailingCountry(MasterDataValue.builder().description("India").build());
        p.setMailingPinCode("400001");

        p.setAddress("A1");
        p.setAddress1("A2");
        p.setAddress2("A3");
        p.setAddress3("A4");
        p.setCity("Delhi");
        p.setState("DL");
        p.setCountry(MasterDataValue.builder().description("India").build());
        p.setPinCode("110001");

        CustomerDetails.CustomerProfile cp =
                mapper.mapCustomerProfile(jd, p);

        assertNotNull(cp);
        assertEquals("M", cp.getGender());
        assertTrue(cp.getEmail().contains("*"));
        assertTrue(cp.getPanNumber().contains("*"));
        assertTrue(cp.getMobileNumber().contains("*"));
        assertTrue(cp.getPermanentAddress().contains("Delhi"));
    }

    // ---------- mapEmploymentFinancial ----------
    @Test
    void test_mapEmploymentFinancial() {
        JourneyData jd = new JourneyData();

        FcIndiaProfile.Profile p = new FcIndiaProfile.Profile();
        p.setEmployerName("HDFC");
        p.setCustomerProfession("ENGINEER");

        // ✅ One-line fix: pass a NEW ReviewCustomerProperties instead of shared field
        ReviewCustomerProperties localProps = new ReviewCustomerProperties();
        localProps.setPurposeOfAccount("INVESTMENT");

        CustomerDetails.EmploymentFinancial ef =
                mapper.mapEmploymentFinancial(jd, p, localProps);

        assertEquals("HDFC", ef.getEmployerBusinessName());
        assertEquals("ENGINEER", ef.getOccupation());
        assertEquals("INVESTMENT", ef.getPurposeOfAccount());
    }

    // ---------- mapFatcaDetails ----------
    @Test
    void test_mapFatcaDetails() {
        FcIndiaProfile.Profile p = new FcIndiaProfile.Profile();
        p.setMotherMaidenName("Smith");
        p.setAddressTypeConsidered("OWN");
        p.setMaritalStatus("MARRIED");
        p.setTxtCustNATNLTY("IN");

        FcIndiaProfile.CustomerFATCADetail fat = new FcIndiaProfile.CustomerFATCADetail();
        fat.setNamCityBirth("Mumbai");
        fat.setCodCntryBirth("IN");
        fat.setNamCustFather("Father");
        fat.setNamSpouseCust("Spouse");
        fat.setAddrTaxReporting1("ADDR-1");
        fat.setCodTaxCntry1("US");
        fat.setTinNo1("TIN1234");
        fat.setTypTinNo1("TIN");

        CustomerDetails.FatcaDetails fd = mapper.mapFatcaDetails(p, fat);

        assertEquals("Mumbai", fd.getPlaceOfBirth());
        assertEquals("IN", fd.getCountryOfBirth());
        assertEquals("Father", fd.getFatherName());
        assertEquals("Smith", fd.getMotherName());
        assertEquals("Spouse", fd.getSpouseName());
        assertNotNull(fd.getTaxResidency());
        assertTrue(fd.getTaxResidency().getTaxIdNumber().contains("*"));
    }

    // ---------- journeyDetailsMapper ----------
    @Test
    void test_journeyDetailsMapper_nullProfile() {
        JourneyData jd = new JourneyData();

        try (MockedStatic<JourneyService> mocked = mockStatic(JourneyService.class)) {
            mocked.when(() -> JourneyService.extractFromJourney(any(), any(), eq(FcIndiaProfile.class), any()))
                    .thenReturn(Optional.empty());

            assertNull(mapper.journeyDetailsMapper(jd));
        }
    }

    // ---------- employmentFinancialDetailsMapper ----------
    @Test
    void test_employmentFinancialDetailsMapper_nullProfile() {
        JourneyData jd = new JourneyData();

        try (MockedStatic<JourneyService> mocked = mockStatic(JourneyService.class)) {
            mocked.when(() -> JourneyService.extractFromJourney(any(), any(), eq(FcIndiaProfile.class), any()))
                    .thenReturn(Optional.empty());

            assertNull(mapper.employmentFinancialDetailsMapper(jd));
        }
    }

    // ---------- journeyFactaDetailsMapper ----------
    @Test
    void test_journeyFactaDetailsMapper_emptyFatca() {

        JourneyData jd = new JourneyData();

        FcIndiaProfile.Profile profile = new FcIndiaProfile.Profile();
        profile.setCustomerFATCADetails(Collections.emptyList());

        FcIndiaProfile fc = new FcIndiaProfile();
        fc.setProfiles(List.of(profile));

        try (MockedStatic<JourneyService> mocked = mockStatic(JourneyService.class)) {

            mocked.when(() ->
                            JourneyService.extractFromJourney(
                                    eq(jd),
                                    eq(JourneyPageName.CUSTOMER_FC_INDIA_DETAIL.getPageName()),
                                    eq(FcIndiaProfile.class),
                                    any(java.util.function.Function.class)
                            )
                    )
                    .thenAnswer(invocation -> Optional.of(profile));

            assertNull(mapper.journeyFactaDetailsMapper(jd));
        }
    }
}