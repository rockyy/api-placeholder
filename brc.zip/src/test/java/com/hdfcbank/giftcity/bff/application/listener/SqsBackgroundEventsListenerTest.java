package com.hdfcbank.giftcity.bff.application.listener;

import ch.qos.logback.classic.Level;
import ch.qos.logback.classic.Logger;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.hdfcbank.common.models.vo.journey.JourneyData;
import com.hdfcbank.common.models.vo.journey.JourneyDetail;
import com.hdfcbank.common.models.vo.journey.Profile;
import com.hdfcbank.giftcity.bff.application.events.BackgroundEvents;
import com.hdfcbank.giftcity.bff.application.events.SqsBackgroundTaskEvent;
import com.hdfcbank.giftcity.bff.commons.config.JourneyConfigProperties;
import com.hdfcbank.giftcity.bff.commons.enums.CommonJourneyStates;
import com.hdfcbank.giftcity.bff.commons.handler.Handler;
import com.hdfcbank.giftcity.bff.commons.handler.HandlerResult;
import com.hdfcbank.giftcity.bff.commons.handler.HandlersFactory;
import com.hdfcbank.giftcity.bff.commons.model.CustomValidationStatus;
import com.hdfcbank.giftcity.bff.commons.exception.handler.DownstreamResponseHandler;
import com.hdfcbank.giftcity.bff.infrastructure.service.JourneyService;
import io.awspring.cloud.sqs.listener.acknowledgement.Acknowledgement;

import org.junit.jupiter.api.*;
import org.mockito.*;

import org.slf4j.LoggerFactory;

import java.lang.reflect.Field;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class SqsBackgroundEventsListenerTest {

    @InjectMocks
    private SqsBackgroundEventsListener listener;

    @Mock private ObjectMapper objectMapper;
    @Mock private HandlersFactory handlersFactory;
    @Mock private JourneyService journeyService;
    @Mock private Acknowledgement acknowledgement;

    private JourneyData journeyData;
    private Profile profile;
    private JourneyDetail detail;
    private SqsBackgroundTaskEvent event;

    @BeforeEach
    void setup() throws Exception {

        MockitoAnnotations.openMocks(this);

        // Suppress all logs
        Logger root = (Logger) LoggerFactory.getLogger(Logger.ROOT_LOGGER_NAME);
        root.setLevel(Level.OFF);

        // Patch static DownstreamResponseHandler config
        JourneyConfigProperties mockCfg = mock(JourneyConfigProperties.class);
        JourneyConfigProperties.JourneyConfig cfg = mock(JourneyConfigProperties.JourneyConfig.class);

        JourneyConfigProperties.ErrorMapping em = new JourneyConfigProperties.ErrorMapping();
        em.setCategory("UNKNOWN");
        em.setDownstreamErrorCode("UNKNOWN");
        em.setErrorCode("ERR500");
        em.setMessageHeading("Background failure");
        em.setMessage("Handler failed");

        when(mockCfg.getJourneys()).thenReturn(Map.of("GIFT_CITY", cfg));
        when(cfg.getErrorMapping()).thenReturn(List.of(em));

        Field f = DownstreamResponseHandler.class.getDeclaredField("journeyConfigProperties");
        f.setAccessible(true);
        f.set(null, mockCfg);

        // Prepare journeyData
        profile = Profile.builder().customerId("CUST1").build();
        detail = new JourneyDetail();
        detail.setSystemData(new HashMap<>());
        detail.setDomainData(new HashMap<>());

        journeyData = JourneyData.builder()
                .journeyId("J999")
                .journeyName("GIFT_CITY")
                .profile(profile)
                .journeyDetail(detail)
                .build();

        // Base SQS event
        event = SqsBackgroundTaskEvent.builder()
                .journeyId("J999")
                .event(BackgroundEvents.DPCFTP_UPLOAD)
                .properties(new HashMap<>())
                .build();
    }

    // ------------------------------------------------------------
    // SUCCESS PATH
    // ------------------------------------------------------------
    @Test
    void testHandlerSuccess() throws Exception {

        Map<String,Object> headers = Map.of(
                "MessageId", "M1",
                "Sqs_Msa_ApproximateReceiveCount", "1"
        );

        when(objectMapper.readValue(anyString(), eq(SqsBackgroundTaskEvent.class)))
                .thenReturn(event);

        when(journeyService.fetchJourney("J999"))
                .thenReturn(journeyData);

        Handler handler = mock(Handler.class);
        when(handler.getName()).thenReturn(Handler.HandlerName.DPCFTP_UPLOAD);
        when(handler.getType()).thenReturn(Handler.HandlerType.BACKGROUND_TASKS_POST_SUBMIT_SUCCESS);
        when(handler.preConditions(any())).thenReturn(true);

        when(handler.handle(any()))
                .thenReturn(HandlerResult.of(null, null, true));

        when(handler.successState())
                .thenReturn(CommonJourneyStates.CUSTOMER_VALIDATED_SUCCESS);

        when(handlersFactory.getHandlers(anyString(), any(), anyString()))
                .thenReturn(Optional.of(handler));

        assertDoesNotThrow(() ->
                listener.sqsBackgroundEventsListener("{}", headers, acknowledgement)
        );

        verify(journeyService).recordJourneyState("J999",
                CommonJourneyStates.CUSTOMER_VALIDATED_SUCCESS);

        verify(acknowledgement).acknowledge();

        // Extra assertions
        verify(handler).preConditions(any());
        verify(handler).handle(any());
        verify(objectMapper).readValue(anyString(), eq(SqsBackgroundTaskEvent.class));
    }

    // ------------------------------------------------------------
    // FAILURE PATH
    // ------------------------------------------------------------
    @Test
    void testHandlerFailure() throws Exception {

        Map<String,Object> headers = Map.of(
                "MessageId", "M2",
                "Sqs_Msa_ApproximateReceiveCount", "1"
        );

        when(objectMapper.readValue(anyString(), eq(SqsBackgroundTaskEvent.class)))
                .thenReturn(event);

        when(journeyService.fetchJourney("J999"))
                .thenReturn(journeyData);

        CustomValidationStatus failureStatus =
                CustomValidationStatus.builder().code("C1").message("FAILED").build();

        Handler handler = mock(Handler.class);
        when(handler.getName()).thenReturn(Handler.HandlerName.DPCFTP_UPLOAD);
        when(handler.getType()).thenReturn(Handler.HandlerType.BACKGROUND_TASKS_POST_SUBMIT_SUCCESS);
        when(handler.preConditions(any())).thenReturn(true);

        when(handler.handle(any()))
                .thenReturn(HandlerResult.of(failureStatus, null, false));

        when(handler.failureState())
                .thenReturn(CommonJourneyStates.BACKGROUND_TASKS_HANDLER_FAILURE);

        when(handlersFactory.getHandlers(anyString(), any(), anyString()))
                .thenReturn(Optional.of(handler));

        assertDoesNotThrow(() ->
                listener.sqsBackgroundEventsListener("{}", headers, acknowledgement)
        );

        verify(journeyService).updateJourneyDetailDropOff(
                eq(journeyData),
                eq(failureStatus),
                eq(CommonJourneyStates.BACKGROUND_TASKS_HANDLER_FAILURE)
        );

        verify(acknowledgement, never()).acknowledge();

        // Additional checks
        verify(handler).preConditions(any());
        verify(handler).handle(any());
        verify(handler).failureState();
    }

    // ------------------------------------------------------------
    // PRECONDITIONS FALSE
    // ------------------------------------------------------------
    @Test
    void testHandlerPreconditionsFalse() throws Exception {

        Map<String,Object> headers = Map.of("MessageId","M3");

        when(objectMapper.readValue(anyString(), eq(SqsBackgroundTaskEvent.class)))
                .thenReturn(event);

        when(journeyService.fetchJourney("J999"))
                .thenReturn(journeyData);

        Handler handler = mock(Handler.class);
        when(handler.getName()).thenReturn(Handler.HandlerName.DPCFTP_UPLOAD);
        when(handler.getType()).thenReturn(Handler.HandlerType.BACKGROUND_TASKS_POST_SUBMIT_SUCCESS);
        when(handler.preConditions(any())).thenReturn(false);

        when(handlersFactory.getHandlers(anyString(), any(), anyString()))
                .thenReturn(Optional.of(handler));

        assertDoesNotThrow(() ->
                listener.sqsBackgroundEventsListener("{}", headers, acknowledgement)
        );

        verify(journeyService, never())
                .recordJourneyState(anyString(), any());

        verify(acknowledgement, never()).acknowledge();

        // Additional checks
        verify(handler).preConditions(any());
        verify(handler, never()).handle(any());
    }

    // ------------------------------------------------------------
    // NO HANDLER FOUND
    // ------------------------------------------------------------
    @Test
    void testNoHandlerFound() throws Exception {

        Map<String,Object> headers = Map.of("MessageId","M4");

        when(objectMapper.readValue(anyString(), eq(SqsBackgroundTaskEvent.class)))
                .thenReturn(event);

        when(journeyService.fetchJourney("J999"))
                .thenReturn(journeyData);

        when(handlersFactory.getHandlers(anyString(), any(), anyString()))
                .thenReturn(Optional.empty());

        assertDoesNotThrow(() ->
                listener.sqsBackgroundEventsListener("{}", headers, acknowledgement)
        );

        verify(acknowledgement).acknowledge();
        verify(journeyService, never()).recordJourneyState(anyString(), any());

        // Additional checks
        verify(handlersFactory).getHandlers(anyString(), any(), anyString());
        verify(objectMapper).readValue(anyString(), eq(SqsBackgroundTaskEvent.class));
    }

    // ------------------------------------------------------------
    // EXCEPTION INSIDE HANDLER → drop-off
    // ------------------------------------------------------------
    @Test
    void testExceptionInsideHandlerTriggersDropOff() throws Exception {

        Map<String,Object> headers = Map.of("MessageId","M5");

        when(objectMapper.readValue(anyString(), eq(SqsBackgroundTaskEvent.class)))
                .thenReturn(event);

        when(journeyService.fetchJourney("J999"))
                .thenReturn(journeyData);

        Handler handler = mock(Handler.class);

        when(handler.getName()).thenReturn(Handler.HandlerName.DPCFTP_UPLOAD);
        when(handler.getType()).thenReturn(Handler.HandlerType.BACKGROUND_TASKS_POST_SUBMIT_SUCCESS);
        when(handler.preConditions(any())).thenReturn(true);

        when(handler.handle(any()))
                .thenThrow(new RuntimeException("FAIL-IN-HANDLER"));

        when(handlersFactory.getHandlers(anyString(), any(), anyString()))
                .thenReturn(Optional.of(handler));

        assertDoesNotThrow(() ->
                listener.sqsBackgroundEventsListener("{}", headers, acknowledgement)
        );

        verify(journeyService).updateJourneyDetailDropOff(
                eq(journeyData),
                any(CustomValidationStatus.class),
                eq(CommonJourneyStates.BACKGROUND_TASKS_HANDLER_FAILURE)
        );

        verify(acknowledgement, never()).acknowledge();

        // Extra checks
        verify(handler).preConditions(any());
        verify(handler).handle(any());
        verify(handlersFactory).getHandlers(anyString(), any(), anyString());
    }
}