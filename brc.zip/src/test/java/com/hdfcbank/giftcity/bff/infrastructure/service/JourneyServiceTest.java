package com.hdfcbank.giftcity.bff.infrastructure.service;

import com.hdfcbank.adapters.clients.feign.journey.JourneyServiceFeignClient;
import com.hdfcbank.adapters.vo.FetchDynamicDataRequest;
import com.hdfcbank.adapters.vo.JourneyUpdateResponse;
import com.hdfcbank.adapters.vo.UpdateSystemDataJourneyRequest;
import com.hdfcbank.common.models.vo.core.ApiResponse;
import com.hdfcbank.common.models.vo.journey.*;
import com.hdfcbank.giftcity.bff.commons.constant.CommonConstants;
import com.hdfcbank.giftcity.bff.commons.enums.CommonJourneyStates;
import com.hdfcbank.service.adapters.vo.customer.FetchCasaResponse;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class JourneyServiceTest {

    @Mock JourneyServiceFeignClient journeyServiceFeignClient;
    @InjectMocks JourneyService journeyService;

    // ------------------------------------------------------------------
    // getByPath()
    // ------------------------------------------------------------------

    @Test
    void getByPath_shouldReturnNestedValue_whenPathExists() {
        Map<String, Object> address = Map.of("city", "Kolkata");
        Map<String, Object> profile = Map.of("address", address);
        Map<String, Object> journey = Map.of("profile", profile);

        Object result = JourneyService.getByPath(journey, "profile.address.city");

        assertNotNull(result);
        assertEquals("Kolkata", result);
        assertTrue(result instanceof String);
    }

    @Test
    void getByPath_shouldReturnNull_whenRootIsNull() {
        Object result = JourneyService.getByPath(null, "profile.name");

        assertNull(result);
    }

    @Test
    void getByPath_shouldReturnNull_whenPathIsNull() {
        Map<String, Object> journey = Map.of("name", "Arijit");

        Object result = JourneyService.getByPath(journey, null);

        assertNull(result);
    }

    @Test
    void getByPath_shouldReturnNull_whenPathDoesNotExist() {
        Map<String, Object> journey = Map.of("name", "Arijit");

        Object result = JourneyService.getByPath(journey, "profile.name");

        assertNull(result);
    }

    @Test
    void getByPath_shouldReturnValue_whenPathPointsToPrimitiveValue() {
        Map<String, Object> journey = Map.of("mobile", "9876543210");

        Object result = JourneyService.getByPath(journey, "mobile");

        assertNotNull(result);
        assertEquals("9876543210", result);
    }

    @Test
    void getByPath_shouldReturnFirstMatchingValue_whenPathTraversesList() {
        Map<String, Object> first = Map.of("name", "First");
        Map<String, Object> second = Map.of("name", "Second");
        Map<String, Object> journey = Map.of("customers", List.of(first, second));

        Object result = JourneyService.getByPath(journey, "customers.name");

        assertNotNull(result);
        assertEquals("First", result);
    }

    // ------------------------------------------------------------------
    // convertToMap()
    // ------------------------------------------------------------------

    @Test
    void convertToMap_shouldReturnEmptyMap_whenInputIsNull() {
        Map<String, Object> result = JourneyService.convertToMap(null);

        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    @Test
    void convertToMap_shouldReturnEmptyMap_whenInputIsNotMap() {
        Map<String, Object> result = JourneyService.convertToMap("not-a-map");

        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    @Test
    void convertToMap_shouldConvertNestedMap() {
        Map<String, Object> nestedMap = Map.of("city", "Kolkata");
        Map<String, Object> input = Map.of("profile", nestedMap);

        Map<String, Object> result = JourneyService.convertToMap(input);

        assertNotNull(result);
        assertTrue(result.containsKey("profile"));
        assertEquals("Kolkata", ((Map<?, ?>) result.get("profile")).get("city"));
    }

    @Test
    void convertToMap_shouldPreserveSimpleValues() {
        Map<String, Object> input = new HashMap<>();
        input.put("name", "Arijit");
        input.put("age", 25);
        input.put("active", true);

        Map<String, Object> result = JourneyService.convertToMap(input);

        assertEquals("Arijit", result.get("name"));
        assertEquals(25, result.get("age"));
        assertEquals(true, result.get("active"));
    }

    @Test
    void convertToMap_shouldCopyListValue() {
        List<String> originalList = new ArrayList<>(List.of("A", "B"));
        Map<String, Object> input = Map.of("items", originalList);

        Map<String, Object> result = JourneyService.convertToMap(input);

        assertTrue(result.get("items") instanceof List);
        assertEquals(List.of("A", "B"), result.get("items"));
        assertNotSame(originalList, result.get("items"));
    }

    // ------------------------------------------------------------------
    // saveJourney()
    // ------------------------------------------------------------------

    @Test
    void saveJourney_shouldDelegateToFeignClient() {
        JourneyData journeyData = JourneyData.builder().journeyId("journey-123").build();
        ApiResponse<?> expectedResponse = mock(ApiResponse.class);

        doReturn(expectedResponse).when(journeyServiceFeignClient).saveJourney(journeyData);

        ApiResponse<?> result = journeyService.saveJourney(journeyData);

        assertSame(expectedResponse, result);
        verify(journeyServiceFeignClient).saveJourney(journeyData);
        verifyNoMoreInteractions(journeyServiceFeignClient);
    }

    // ------------------------------------------------------------------
    // fetchJourney()
    // ------------------------------------------------------------------

    @Test
    void fetchJourney_shouldReturnJourneyData_fromFeignClient() {
        String journeyId = "journey-123";
        JourneyData expectedJourney = JourneyData.builder().journeyId(journeyId).build();

        when(journeyServiceFeignClient.fetch(journeyId)).thenReturn(expectedJourney);

        JourneyData result = journeyService.fetchJourney(journeyId);

        assertSame(expectedJourney, result);
        verify(journeyServiceFeignClient).fetch(journeyId);
    }

    // ------------------------------------------------------------------
    // updateJourney()
    // ------------------------------------------------------------------

    @Test
    void updateJourney_shouldDelegateRequestToFeignClient() {
        UpdateSystemDataJourneyRequest request = UpdateSystemDataJourneyRequest.builder().journeyId("journey-123").build();
        ApiResponse<JourneyUpdateResponse> expectedResponse = ApiResponse.success(null);

        when(journeyServiceFeignClient.updateResponse(request)).thenReturn(expectedResponse);

        ApiResponse<JourneyUpdateResponse> result = journeyService.updateJourney(request);

        assertSame(expectedResponse, result);
        verify(journeyServiceFeignClient).updateResponse(request);
    }

    // ------------------------------------------------------------------
    // updateJourneyState()
    // ------------------------------------------------------------------

    @Test
    void updateJourneyState_shouldDelegateToFeignClient() {
        journeyService.updateJourneyState("journey-123", "SUCCESS");

        verify(journeyServiceFeignClient).updateJourneyState("journey-123", "SUCCESS");
    }

    // ------------------------------------------------------------------
    // toUpdateSystemDataRequest()
    // ------------------------------------------------------------------

    @Test
    void toUpdateSystemDataRequest_shouldCreateCorrectRequest() {
        String journeyId = "journey-123";
        String pageName = "customerDetails";
        Map<String, Object> data = Map.of("name", "Arijit");

        UpdateSystemDataJourneyRequest result =
                journeyService.toUpdateSystemDataRequest(journeyId, pageName, data, CommonJourneyStates.CUSTOMER_PROFILE_SUCCESS);

        assertEquals(journeyId, result.getJourneyId());
        assertNotNull(result.getData());
        assertEquals(data, result.getData().get(pageName));
        assertEquals(JourneyDetailsDataType.SYSTEM_DATA, result.getDataType());
        assertNotNull(result.getJourneyState());
        assertEquals(CommonJourneyStates.CUSTOMER_PROFILE_SUCCESS.name(), result.getJourneyState().getStateName());
        assertNotNull(result.getJourneyState().getCreatedOn());
    }

    @Test
    void toUpdateSystemDataRequest_shouldSupportNullData() {
        UpdateSystemDataJourneyRequest result =
                journeyService.toUpdateSystemDataRequest("journey-123", "customerDetails", null,
                        CommonJourneyStates.CUSTOMER_PROFILE_SUCCESS);

        assertEquals("journey-123", result.getJourneyId());
        assertTrue(result.getData().containsKey("customerDetails"));
        assertNull(result.getData().get("customerDetails"));
    }

    // ------------------------------------------------------------------
    // updateJourney(String, page, data, state)
    // ------------------------------------------------------------------

    @Test
    void updateJourney_shouldBuildRequestAndDelegate() {
        String journeyId = "journey-123";
        String pageName = "personalDetails";
        Map<String, Object> data = Map.of("name", "Arijit", "city", "Kolkata");

        ApiResponse<JourneyUpdateResponse> response = ApiResponse.success(null);

        when(journeyServiceFeignClient.updateResponse(any(UpdateSystemDataJourneyRequest.class))).thenReturn(response);

        journeyService.updateJourney(journeyId, pageName, data, CommonJourneyStates.CUSTOMER_PROFILE_SUCCESS);

        ArgumentCaptor<UpdateSystemDataJourneyRequest> captor =
                ArgumentCaptor.forClass(UpdateSystemDataJourneyRequest.class);

        verify(journeyServiceFeignClient).updateResponse(captor.capture());
        UpdateSystemDataJourneyRequest request = captor.getValue();

        assertEquals(journeyId, request.getJourneyId());
        assertEquals(data, request.getData().get(pageName));
        assertEquals(JourneyDetailsDataType.SYSTEM_DATA, request.getDataType());
        assertEquals(CommonJourneyStates.CUSTOMER_PROFILE_SUCCESS.name(), request.getJourneyState().getStateName());
    }

    // ------------------------------------------------------------------
    // updateProfile()
    // ------------------------------------------------------------------

    @Test
    void updateProfile_shouldCreateRequestAndDelegate() {
        FetchCasaResponse.Profile profile = mock(FetchCasaResponse.Profile.class);

        when(profile.getName()).thenReturn("Arijit");
        when(profile.getDob()).thenReturn("01-01-2000");
        when(profile.getGender()).thenReturn("M");
        when(profile.getCustomerTitle()).thenReturn("MR");
        when(profile.getAddress()).thenReturn("Address 1");
        when(profile.getAddress2()).thenReturn("Address 2");
        when(profile.getCity()).thenReturn("Kolkata");
        when(profile.getState()).thenReturn("West Bengal");
        when(profile.getPinCode()).thenReturn("700001");
        when(profile.getMailingAddress1()).thenReturn("Mailing Address 1");
        when(profile.getMailingAddress2()).thenReturn("Mailing Address 2");
        when(profile.getMailingCity()).thenReturn("Kolkata");
        when(profile.getMailingState()).thenReturn("West Bengal");
        when(profile.getMailingPinCode()).thenReturn("700002");
        when(profile.getEmail()).thenReturn("test@example.com");
        when(profile.getPanNumber()).thenReturn("ABCDE1234F");
        when(profile.getIdentifierName()).thenReturn("PAN");
        when(profile.getCustomerType()).thenReturn("INDIVIDUAL");
        when(profile.getEthnicCode()).thenReturn("01");
        when(profile.getCustomerId()).thenReturn("customer-123");

        when(journeyServiceFeignClient.updateResponse(any(UpdateSystemDataJourneyRequest.class)))
                .thenReturn(ApiResponse.success(null));

        journeyService.updateProfile("journey-123", CommonJourneyStates.CUSTOMER_PROFILE_SUCCESS, profile);

        ArgumentCaptor<UpdateSystemDataJourneyRequest> captor =
                ArgumentCaptor.forClass(UpdateSystemDataJourneyRequest.class);

        verify(journeyServiceFeignClient).updateResponse(captor.capture());
        UpdateSystemDataJourneyRequest request = captor.getValue();

        assertEquals("journey-123", request.getJourneyId());
        assertNotNull(request.getJourneyState());
        assertEquals(CommonJourneyStates.CUSTOMER_PROFILE_SUCCESS.name(), request.getJourneyState().getStateName());
        assertNotNull(request.getProfile());
        assertEquals("Arijit", request.getProfile().getFirstName());
        assertEquals("Arijit", request.getProfile().getFullName());
        assertEquals("test@example.com", request.getProfile().getEmailId());
        assertEquals("ABCDE1234F", request.getProfile().getPanNumber());
        assertEquals("customer-123", request.getProfile().getCustomerId());
        assertNotNull(request.getProfile().getAddresses());
        assertEquals(2, request.getProfile().getAddresses().size());
    }

    // ------------------------------------------------------------------
    // updateJourneyDetailDropOff() — overload 1
    // ------------------------------------------------------------------

    @Test
    void updateJourneyDetailDropOff_shouldAddStatusAndUpdateJourney() {
        JourneyDetail journeyDetail = new JourneyDetail();
        journeyDetail.setSystemData(new HashMap<>());

        JourneyData journeyData = JourneyData.builder().journeyId("journey-123").journeyDetail(journeyDetail).build();

        String apiResponseStatus = "CUSTOMER_NOT_ELIGIBLE";

        journeyService.updateJourneyDetailDropOff(journeyData, apiResponseStatus);

        ArgumentCaptor<UpdateSystemDataJourneyRequest> captor = ArgumentCaptor.forClass(UpdateSystemDataJourneyRequest.class);

        verify(journeyServiceFeignClient).update(captor.capture());
        UpdateSystemDataJourneyRequest request = captor.getValue();

        assertEquals("journey-123", request.getJourneyId());
        assertEquals(JourneyDetailsDataType.SYSTEM_DATA, request.getDataType());

        Map<String, ?> statusDetail =
                (Map<String, ?>) request.getData().get(CommonConstants.JOURNEY_STATUS_DETAIL);

        assertEquals(CommonConstants.JOURNEY_DROP_OFF, statusDetail.get(CommonConstants.JOURNEY_STATUS));
        assertEquals(apiResponseStatus, statusDetail.get(CommonConstants.JOURNEY_DROP_OFF));
    }

    // ------------------------------------------------------------------
    // extractFromJourney()
    // ------------------------------------------------------------------

    @Test
    void extractFromJourney_shouldReturnValue_whenDataExists() {
        Map<String, Object> customerDetails = Map.of("name", "Arijit", "age", 25);
        Map<String, Map<String, ?>> systemData = new HashMap<>();
        systemData.put("customerDetails", customerDetails);

        JourneyDetail journeyDetail = new JourneyDetail();
        journeyDetail.setSystemData(systemData);

        JourneyData journeyData = JourneyData.builder().journeyDetail(journeyDetail).build();

        Optional<Map> result = JourneyService.extractFromJourney(journeyData, "customerDetails", Map.class);

        assertTrue(result.isPresent());
        assertEquals("Arijit", result.get().get("name"));
        assertEquals(25, result.get().get("age"));
    }

    @Test
    void extractFromJourney_shouldReturnEmpty_whenJourneyDataIsNull() {
        Optional<Map> result = JourneyService.extractFromJourney(null, "customerDetails", Map.class);

        assertTrue(result.isEmpty());
    }

    @Test
    void extractFromJourney_shouldReturnEmpty_whenJourneyDetailIsNull() {
        JourneyData journeyData = JourneyData.builder().journeyDetail(null).build();

        Optional<Map> result = JourneyService.extractFromJourney(journeyData, "customerDetails", Map.class);

        assertTrue(result.isEmpty());
    }

    @Test
    void extractFromJourney_shouldReturnEmpty_whenPageDoesNotExist() {
        JourneyDetail detail = new JourneyDetail();
        detail.setSystemData(new HashMap<>());

        JourneyData journeyData = JourneyData.builder().journeyDetail(detail).build();

        Optional<Map> result = JourneyService.extractFromJourney(journeyData, "customerDetails", Map.class);

        assertTrue(result.isEmpty());
    }

    @Test
    void extractFromJourney_shouldApplyExtractorFunction() {
        Map<String, Object> customerDetails = Map.of("name", "Arijit");

        JourneyDetail detail = new JourneyDetail();
        detail.setSystemData(Map.of("customerDetails", customerDetails));

        JourneyData journeyData = JourneyData.builder().journeyDetail(detail).build();

        Optional<String> result = JourneyService.extractFromJourney(
                journeyData, "customerDetails", Map.class, map -> (String) map.get("name"));

        assertTrue(result.isPresent());
        assertEquals("Arijit", result.get());
    }

    @Test
    void extractFromJourney_shouldReturnEmpty_whenExtractorInputDoesNotExist() {
        JourneyData journeyData = JourneyData.builder().journeyDetail(null).build();

        Optional<String> result = JourneyService.extractFromJourney(
                journeyData, "customerDetails", Map.class, map -> (String) map.get("name"));

        assertTrue(result.isEmpty());
    }

    // ------------------------------------------------------------------
    // getDataFromJourneyService()
    // ------------------------------------------------------------------

    @Test
    void getDataFromJourneyService_shouldReturnNestedValue() {
        Map<String, Object> sys = Map.of("address", Map.of("city", "Kolkata"));

        Object result = journeyService.getDataFromJourneyService(sys, "address.city");

        assertEquals("Kolkata", result);
    }

    @Test
    void getDataFromJourneyService_shouldReturnEmptyString_whenSystemDataIsNull() {
        assertEquals("", journeyService.getDataFromJourneyService(null, "address.city"));
    }

    @Test
    void getDataFromJourneyService_shouldReturnEmptyString_whenKeyPathIsNull() {
        assertEquals("", journeyService.getDataFromJourneyService(Map.of("name","Arijit"), null));
    }

    @Test
    void getDataFromJourneyService_shouldReturnEmptyString_whenKeyPathIsEmpty() {
        assertEquals("", journeyService.getDataFromJourneyService(Map.of("name","Arijit"), ""));
    }

    @Test
    void getDataFromJourneyService_shouldReturnEmptyString_whenKeyDoesNotExist() {
        assertEquals("", journeyService.getDataFromJourneyService(Map.of("name","Arijit"), "profile.name"));
    }

    @Test
    void getDataFromJourneyService_shouldReturnEmptyString_whenIntermediateValueIsNotMap() {
        assertEquals("", journeyService.getDataFromJourneyService(Map.of("profile","invalid"), "profile.name"));
    }

    @Test
    void getDataFromJourneyService_shouldReturnEmptyString_whenNestedValueIsNull() {
        Map<String,Object> sys = new HashMap<>();
        sys.put("profile", null);

        assertEquals("", journeyService.getDataFromJourneyService(sys, "profile.name"));
    }

    // ------------------------------------------------------------------
    // recordJourneyState()
    // ------------------------------------------------------------------

    @Test
    void recordJourneyState_shouldUpdateJourneyState() {
        journeyService.recordJourneyState("journey-123", CommonJourneyStates.CUSTOMER_PROFILE_SUCCESS);

        verify(journeyServiceFeignClient).updateJourneyState("journey-123",
                CommonJourneyStates.CUSTOMER_PROFILE_SUCCESS.name());
    }

    // ------------------------------------------------------------------
    // updateJourneyDetailDropOff() — overload 2
    // ------------------------------------------------------------------

    @Test
    void updateJourneyDetailDropOff_shouldCreateDropOffList_whenNoExistingDropOff() {
        JourneyDetail detail = new JourneyDetail();
        detail.setSystemData(new HashMap<>());

        JourneyData journeyData = JourneyData.builder()
                .journeyId("journey-123")
                .journeyDetail(detail)
                .build();

        journeyService.updateJourneyDetailDropOff(journeyData, "FAILED",
                CommonJourneyStates.BUSINESS_VALIDATION_FAILED);

        ArgumentCaptor<UpdateSystemDataJourneyRequest> captor =
                ArgumentCaptor.forClass(UpdateSystemDataJourneyRequest.class);

        verify(journeyServiceFeignClient).update(captor.capture());

        UpdateSystemDataJourneyRequest request = captor.getValue();

        Map<String, ?> statusDetail =
                (Map<String, ?>) request.getData().get(CommonConstants.JOURNEY_STATUS_DETAIL);

        assertEquals(List.of("FAILED"), statusDetail.get(CommonConstants.JOURNEY_DROP_OFF));
        assertEquals(JourneyDetailsDataType.SYSTEM_DATA, request.getDataType());
        assertEquals(CommonJourneyStates.BUSINESS_VALIDATION_FAILED.name(),
                request.getJourneyState().getStateName());
    }

    @Test
    void updateJourneyDetailDropOff_shouldAppendToExistingList() {

        // inner map must be mutable
        Map<String, Object> status = new HashMap<>();
        status.put(CommonConstants.JOURNEY_DROP_OFF, new ArrayList<>(List.of("FIRST")));

        // outer map must also be MUTABLE
        Map<String, Map<String, ?>> systemData = new HashMap<>();
        systemData.put(CommonConstants.JOURNEY_STATUS_DETAIL, status);

        JourneyDetail detail = new JourneyDetail();
        detail.setSystemData(systemData);

        JourneyData journeyData = JourneyData.builder()
                .journeyId("journey-123")
                .journeyDetail(detail)
                .build();

        journeyService.updateJourneyDetailDropOff(
                journeyData,
                "SECOND",
                CommonJourneyStates.BUSINESS_VALIDATION_FAILED
        );

        ArgumentCaptor<UpdateSystemDataJourneyRequest> captor =
                ArgumentCaptor.forClass(UpdateSystemDataJourneyRequest.class);

        verify(journeyServiceFeignClient).update(captor.capture());
        UpdateSystemDataJourneyRequest request = captor.getValue();

        Map<String, ?> updatedDetail =
                (Map<String, ?>) request.getData().get(CommonConstants.JOURNEY_STATUS_DETAIL);

        assertEquals(
                List.of("FIRST", "SECOND"),
                updatedDetail.get(CommonConstants.JOURNEY_DROP_OFF)
        );
    }

    @Test
    void updateJourneyDetailDropOff_shouldAvoidDuplicateDropOffStatus() {

        // inner status map MUST be mutable
        Map<String, Object> status = new HashMap<>();
        status.put(CommonConstants.JOURNEY_DROP_OFF, new ArrayList<>(List.of("FAILED")));

        // outer systemData map MUST ALSO be mutable
        Map<String, Map<String, ?>> systemData = new HashMap<>();
        systemData.put(CommonConstants.JOURNEY_STATUS_DETAIL, status);

        JourneyDetail detail = new JourneyDetail();
        detail.setSystemData(systemData);

        JourneyData journeyData = JourneyData.builder()
                .journeyId("journey-123")
                .journeyDetail(detail)
                .build();

        journeyService.updateJourneyDetailDropOff(
                journeyData,
                "FAILED",
                CommonJourneyStates.BUSINESS_VALIDATION_FAILED
        );

        ArgumentCaptor<UpdateSystemDataJourneyRequest> captor =
                ArgumentCaptor.forClass(UpdateSystemDataJourneyRequest.class);

        verify(journeyServiceFeignClient).update(captor.capture());
        UpdateSystemDataJourneyRequest request = captor.getValue();

        Map<String, ?> updatedDetail =
                (Map<String, ?>) request.getData().get(CommonConstants.JOURNEY_STATUS_DETAIL);

        assertEquals(
                List.of("FAILED"),
                updatedDetail.get(CommonConstants.JOURNEY_DROP_OFF)
        );
    }

    @Test
    void updateJourneyDetailDropOff_shouldConvertExistingSingleValueToList() {
        Map<String, Object> status = new HashMap<>();
        status.put(CommonConstants.JOURNEY_DROP_OFF, "FIRST");

        Map<String, Map<String, ?>> systemData = new HashMap<>();
        systemData.put(CommonConstants.JOURNEY_STATUS_DETAIL, status);

        JourneyDetail detail = new JourneyDetail();
        detail.setSystemData(systemData);

        JourneyData journeyData = JourneyData.builder()
                .journeyId("journey-123")
                .journeyDetail(detail)
                .build();

        journeyService.updateJourneyDetailDropOff(
                journeyData,
                "SECOND",
                CommonJourneyStates.BUSINESS_VALIDATION_FAILED
        );

        ArgumentCaptor<UpdateSystemDataJourneyRequest> captor =
                ArgumentCaptor.forClass(UpdateSystemDataJourneyRequest.class);

        verify(journeyServiceFeignClient).update(captor.capture());
        UpdateSystemDataJourneyRequest request = captor.getValue();

        Map<String, ?> updatedDetail =
                (Map<String, ?>) request.getData().get(CommonConstants.JOURNEY_STATUS_DETAIL);

        assertEquals(
                List.of("FIRST", "SECOND"),
                updatedDetail.get(CommonConstants.JOURNEY_DROP_OFF)
        );
    }

    @Test
    void updateJourneyDetailDropOff_shouldHandleNullSystemData() {
        JourneyDetail detail = new JourneyDetail();
        detail.setSystemData(null);

        JourneyData journeyData = JourneyData.builder()
                .journeyId("journey-123")
                .journeyDetail(detail)
                .build();

        journeyService.updateJourneyDetailDropOff(journeyData,
                "FAILED", CommonJourneyStates.BUSINESS_VALIDATION_FAILED);

        verify(journeyServiceFeignClient).update(any(UpdateSystemDataJourneyRequest.class));
    }

    // ------------------------------------------------------------------
    // fetchJourneyByReferenceNo()
    // ------------------------------------------------------------------

    @Test
    void fetchJourneyByReferenceNo_shouldReturnFirstJourney_whenJourneyExists() {
        JourneyData first = JourneyData.builder().journeyId("journey-1").build();
        JourneyData second = JourneyData.builder().journeyId("journey-2").build();
        ApiResponse<List<JourneyData>> response = ApiResponse.success(List.of(first, second));

        when(journeyServiceFeignClient.fetchDynamicDataResponse(any(FetchDynamicDataRequest.class)))
                .thenReturn(response);

        doNothing().when(journeyServiceFeignClient).handleErrors(response.getStatus());

        Optional<JourneyData> result = journeyService.fetchJourneyByReferenceNo("REF-123");

        assertTrue(result.isPresent());
        assertSame(first, result.get());

        verify(journeyServiceFeignClient).fetchDynamicDataResponse(any(FetchDynamicDataRequest.class));
        verify(journeyServiceFeignClient).handleErrors(response.getStatus());
    }

    @Test
    void fetchJourneyByReferenceNo_shouldReturnEmpty_whenNoJourneyExists() {
        ApiResponse<List<JourneyData>> response = ApiResponse.success(Collections.emptyList());

        when(journeyServiceFeignClient.fetchDynamicDataResponse(any(FetchDynamicDataRequest.class)))
                .thenReturn(response);

        doNothing().when(journeyServiceFeignClient).handleErrors(any());

        Optional<JourneyData> result = journeyService.fetchJourneyByReferenceNo("REF-123");

        assertTrue(result.isEmpty());
    }

    @Test
    void fetchJourneyByReferenceNo_shouldReturnEmpty_whenResponseDataIsNull() {
        ApiResponse<List<JourneyData>> response = ApiResponse.success(null);

        when(journeyServiceFeignClient.fetchDynamicDataResponse(any(FetchDynamicDataRequest.class)))
                .thenReturn(response);

        doNothing().when(journeyServiceFeignClient).handleErrors(any());

        Optional<JourneyData> result = journeyService.fetchJourneyByReferenceNo("REF-123");

        assertTrue(result.isEmpty());
    }

    // ------------------------------------------------------------------
    // fetchDynamicJourneyData()
    // ------------------------------------------------------------------

    @Test
    void fetchDynamicJourneyData_shouldReturnResponseData() {
        FetchDynamicDataRequest request = FetchDynamicDataRequest.builder()
                .operationType("AND")
                .filters(Map.of("referenceNo", "REF-123"))
                .build();

        JourneyData journeyData = JourneyData.builder().journeyId("journey-123").build();
        ApiResponse<List<JourneyData>> response = ApiResponse.success(List.of(journeyData));

        when(journeyServiceFeignClient.fetchDynamicDataResponse(request)).thenReturn(response);
        doNothing().when(journeyServiceFeignClient).handleErrors(response.getStatus());

        List<JourneyData> result = journeyService.fetchDynamicJourneyData(request);

        assertEquals(List.of(journeyData), result);
        verify(journeyServiceFeignClient).fetchDynamicDataResponse(request);
        verify(journeyServiceFeignClient).handleErrors(response.getStatus());
    }

    // ------------------------------------------------------------------
    // getDomainPageUserInputs()
    // ------------------------------------------------------------------

    @Test
    void getDomainPageUserInputs_shouldReturnUserInputs_whenPageExists() {
        Map<String, Object> userInputs = Map.of("name", "Arijit", "city", "Kolkata");

        JourneyPage page = mock(JourneyPage.class);
        when(page.getUserInputs()).thenReturn(userInputs);

        JourneyDetail detail = new JourneyDetail();
        detail.setDomainData(Map.of("customerDetails", page));

        JourneyData journeyData = JourneyData.builder().journeyDetail(detail).build();

        Map<String, Object> result = JourneyService.getDomainPageUserInputs(journeyData, "customerDetails");

        assertEquals(userInputs, result);
    }

    @Test
    void getDomainPageUserInputs_shouldReturnEmptyMap_whenJourneyDataIsNull() {
        Map<String, Object> result = JourneyService.getDomainPageUserInputs(null, "customerDetails");

        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    @Test
    void getDomainPageUserInputs_shouldReturnEmptyMap_whenJourneyDetailIsNull() {
        JourneyData jd = JourneyData.builder().journeyDetail(null).build();

        Map<String, Object> result = JourneyService.getDomainPageUserInputs(jd, "customerDetails");

        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    @Test
    void getDomainPageUserInputs_shouldReturnEmptyMap_whenPageDoesNotExist() {
        JourneyDetail detail = new JourneyDetail();
        detail.setDomainData(new HashMap<>());

        JourneyData journeyData = JourneyData.builder().journeyDetail(detail).build();

        Map<String, Object> result = JourneyService.getDomainPageUserInputs(journeyData, "customerDetails");

        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    // ------------------------------------------------------------------
    // Interaction Safety Validation
    // ------------------------------------------------------------------

    @Test
    void saveJourney_shouldNotCallAnyOtherFeignMethod() {
        JourneyData jd = JourneyData.builder().journeyId("journey-123").build();
        ApiResponse<?> response = mock(ApiResponse.class);

        doReturn(response).when(journeyServiceFeignClient).saveJourney(jd);

        journeyService.saveJourney(jd);

        verify(journeyServiceFeignClient).saveJourney(jd);
        verifyNoMoreInteractions(journeyServiceFeignClient);
    }

    @Test
    void fetchDynamicJourneyData_shouldPropagateDownstreamValidationFailure() {
        FetchDynamicDataRequest request = FetchDynamicDataRequest.builder()
                .operationType("AND").filters(Map.of("referenceNo", "REF-FAIL")).build();
        ApiResponse<List<JourneyData>> response = ApiResponse.success(List.of());
        when(journeyServiceFeignClient.fetchDynamicDataResponse(request)).thenReturn(response);
        IllegalStateException failure = new IllegalStateException("Invalid downstream status");
        doThrow(failure).when(journeyServiceFeignClient).handleErrors(response.getStatus());

        assertSame(failure, assertThrows(IllegalStateException.class,
                () -> journeyService.fetchDynamicJourneyData(request)));
    }

    @Test
    void fetchJourneyByReferenceNo_shouldSendExactReferenceFilter() {
        when(journeyServiceFeignClient.fetchDynamicDataResponse(any()))
                .thenReturn(ApiResponse.success(List.of()));

        assertTrue(journeyService.fetchJourneyByReferenceNo("REF-FILTER").isEmpty());

        ArgumentCaptor<FetchDynamicDataRequest> request = ArgumentCaptor.forClass(FetchDynamicDataRequest.class);
        verify(journeyServiceFeignClient).fetchDynamicDataResponse(request.capture());
        assertEquals("AND", request.getValue().getOperationType());
        assertEquals(Map.of("referenceNo", "REF-FILTER"), request.getValue().getFilters());
    }
}
