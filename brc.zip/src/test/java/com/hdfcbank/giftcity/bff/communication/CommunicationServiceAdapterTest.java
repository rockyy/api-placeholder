package com.hdfcbank.giftcity.bff.communication;

import com.hdfcbank.adapters.clients.feign.communication.CommunicationFeignClient;
import com.hdfcbank.adapters.vo.GenerateOtpRequest;
import com.hdfcbank.adapters.vo.GenerateOtpResponse;
import com.hdfcbank.adapters.vo.VerifyOtpRequest;
import com.hdfcbank.adapters.vo.VerifyOtpResponse;

import com.hdfcbank.giftcity.bff.commons.enums.CommonJourneyStates;
import com.hdfcbank.giftcity.bff.commons.exception.OTPValidationException;
import com.hdfcbank.giftcity.bff.infrastructure.service.JourneyService;

import feign.FeignException;
import feign.Request;
import feign.RequestTemplate;

import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.util.Collections;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import ch.qos.logback.classic.Logger;
import ch.qos.logback.classic.Level;
import org.slf4j.LoggerFactory;

@ExtendWith(MockitoExtension.class)
class CommunicationServiceAdapterTest {

    /** mute logs */
    @BeforeAll
    static void muteLogs() {
        Logger logger = (Logger) LoggerFactory.getLogger(CommunicationServiceAdapter.class);
        logger.setLevel(Level.OFF);
    }

    @Mock
    private JourneyService journeyService;

    @Mock
    private CommunicationFeignClient feignClient;

    @InjectMocks
    private CommunicationServiceAdapter adapter;


    // Helper: Convert Optional<ByteBuffer> → String safely
    private String asString(Optional<ByteBuffer> opt) {
        if (opt == null || opt.isEmpty()) return "";
        ByteBuffer bb = opt.get();
        byte[] arr = new byte[bb.remaining()];
        bb.get(arr);
        return new String(arr, StandardCharsets.UTF_8);
    }

    // =====================================================================
    //          SEND COMMUNICATION: SUCCESS CASE
    // =====================================================================
    @ParameterizedTest
    @ValueSource(booleans = {false, true})
    @DisplayName("sendCommunication: success")
    void testSendSuccess(boolean isResend) {

        GenerateOtpRequest req = GenerateOtpRequest.builder()
                .templateId("TEMP")
                .build();

        String journeyId = "J1";
        GenerateOtpResponse expected = new GenerateOtpResponse();

        when(feignClient.sendOtp(req, journeyId)).thenReturn(expected);

        GenerateOtpResponse actual = adapter.sendCommunication(req, journeyId, isResend);

        assertNotNull(actual);
        assertEquals(expected, actual);

        verify(journeyService).recordJourneyState(journeyId, isResend
                ? CommonJourneyStates.RESEND_OTP_SEND_INITIATED : CommonJourneyStates.OTP_SEND_INITIATED);
        verify(feignClient).sendOtp(req, journeyId);

        verifyNoMoreInteractions(journeyService, feignClient);
    }


    // =====================================================================
    //          SEND COMMUNICATION: NULL RESPONSE → OTP_FAILED
    // =====================================================================
    @Test
    @DisplayName("sendCommunication: null → OTP_FAILED")
    void testSendNullResponse() {

        GenerateOtpRequest req = GenerateOtpRequest.builder().build();
        String journeyId = "J2";

        when(feignClient.sendOtp(req, journeyId)).thenReturn(null);

        OTPValidationException ex = assertThrows(
                OTPValidationException.class,
                () -> adapter.sendCommunication(req, journeyId, false)
        );

        assertEquals("OTP_FAILED", ex.getMessage());

        verify(journeyService, times(1))
                .recordJourneyState(journeyId, CommonJourneyStates.OTP_SEND_INITIATED);

        verify(journeyService, times(2))
                .recordJourneyState(journeyId, CommonJourneyStates.OTP_GENERATE_FAILURE);

        verify(feignClient).sendOtp(req, journeyId);

        verifyNoMoreInteractions(journeyService, feignClient);
    }


    // =====================================================================
    //          SEND COMMUNICATION: FeignException → COMMUNICATION_SERVICE_ERROR
    // =====================================================================
    @Test
    @DisplayName("sendCommunication: FeignException → COMMUNICATION_SERVICE_ERROR")
    void testSendFeignException() {

        GenerateOtpRequest req = GenerateOtpRequest.builder().build();
        String journeyId = "J3";

        FeignException exFeign =
                new FeignException.BadRequest(
                        "bad",
                        Request.create(
                                Request.HttpMethod.POST,
                                "/sendOtp",
                                Collections.emptyMap(),
                                null,
                                new RequestTemplate()
                        ),
                        "err".getBytes(StandardCharsets.UTF_8),
                        Collections.emptyMap()
                );

        when(feignClient.sendOtp(req, journeyId)).thenThrow(exFeign);

        OTPValidationException ex = assertThrows(
                OTPValidationException.class,
                () -> adapter.sendCommunication(req, journeyId, true)
        );

        assertEquals("Communication service returned error", ex.getMessage());

        // Extract Feign error body safely using helper
        String body = asString(exFeign.responseBody());
        assertTrue(body.contains("err"));

        verify(journeyService).recordJourneyState(journeyId, CommonJourneyStates.RESEND_OTP_SEND_INITIATED);
        verify(journeyService).recordJourneyState(journeyId, CommonJourneyStates.OTP_RESEND_FAILURE);

        verify(feignClient).sendOtp(req, journeyId);

        verifyNoMoreInteractions(journeyService, feignClient);
    }


    // =====================================================================
    //          SEND COMMUNICATION: Unexpected Exception → OTP_FAILED
    // =====================================================================
    @Test
    @DisplayName("sendCommunication: unexpected Exception → OTP_FAILED")
    void testSendGenericException() {

        GenerateOtpRequest req = GenerateOtpRequest.builder().build();
        String journeyId = "J4";

        when(feignClient.sendOtp(req, journeyId)).thenThrow(new RuntimeException("X"));

        OTPValidationException ex = assertThrows(
                OTPValidationException.class,
                () -> adapter.sendCommunication(req, journeyId, false)
        );

        assertEquals("OTP_FAILED", ex.getMessage());

        verify(journeyService).recordJourneyState(journeyId, CommonJourneyStates.OTP_SEND_INITIATED);
        verify(journeyService).recordJourneyState(journeyId, CommonJourneyStates.OTP_GENERATE_FAILURE);

        verify(feignClient).sendOtp(req, journeyId);

        verifyNoMoreInteractions(journeyService, feignClient);
    }


    // =====================================================================
    //          VERIFY OTP: SUCCESS CASE
    // =====================================================================
    @Test
    @DisplayName("verifyOtp: success")
    void testVerifyOtpSuccess() {

        VerifyOtpRequest req = VerifyOtpRequest.builder()
                .otpValue("123456")
                .build();

        String journeyId = "JV1";
        VerifyOtpResponse expected = new VerifyOtpResponse();

        when(feignClient.verifyOtp(req, journeyId)).thenReturn(expected);

        VerifyOtpResponse actual = adapter.verifyOtp(req, journeyId);

        assertNotNull(actual);
        assertEquals(expected, actual);

        verify(journeyService).recordJourneyState(journeyId, CommonJourneyStates.VALIDATE_OTP_INITIATED);
        verify(feignClient).verifyOtp(req, journeyId);

        verifyNoMoreInteractions(journeyService, feignClient);
    }


    // =====================================================================
    //          VERIFY OTP: NULL RESPONSE → VERIFY_OTP_FAILED
    // =====================================================================
    @Test
    @DisplayName("verifyOtp: null → VERIFY_OTP_FAILED")
    void testVerifyOtpNull() {

        VerifyOtpRequest req = VerifyOtpRequest.builder().build();
        String journeyId = "JV2";

        when(feignClient.verifyOtp(req, journeyId)).thenReturn(null);

        OTPValidationException ex = assertThrows(
                OTPValidationException.class,
                () -> adapter.verifyOtp(req, journeyId)
        );

        assertEquals("Verify OTP Failed", ex.getMessage());

        verify(journeyService, times(1))
                .recordJourneyState(journeyId, CommonJourneyStates.VALIDATE_OTP_INITIATED);

        verify(journeyService, times(2))
                .recordJourneyState(journeyId, CommonJourneyStates.OTP_VALIDATE_FAILURE);

        verify(feignClient).verifyOtp(req, journeyId);

        verifyNoMoreInteractions(journeyService, feignClient);
    }


    // =====================================================================
    //          VERIFY OTP: FeignException → VERIFY_OTP_FAILED
    // =====================================================================
    @Test
    @DisplayName("verifyOtp: FeignException → VERIFY_OTP_FAILED")
    void testVerifyOtpFeignException() {

        VerifyOtpRequest req = VerifyOtpRequest.builder().build();
        String journeyId = "JV3";

        FeignException exFeign =
                new FeignException.BadRequest(
                        "bad",
                        Request.create(
                                Request.HttpMethod.POST,
                                "/verifyOtp",
                                Collections.emptyMap(),
                                null,
                                new RequestTemplate()
                        ),
                        "err".getBytes(StandardCharsets.UTF_8),
                        Collections.emptyMap()
                );

        when(feignClient.verifyOtp(req, journeyId)).thenThrow(exFeign);

        OTPValidationException ex = assertThrows(
                OTPValidationException.class,
                () -> adapter.verifyOtp(req, journeyId)
        );

        assertEquals("Verify OTP Failed", ex.getMessage());

        String body = asString(exFeign.responseBody());
        assertTrue(body.contains("err"));

        verify(journeyService).recordJourneyState(journeyId, CommonJourneyStates.VALIDATE_OTP_INITIATED);
        verify(journeyService).recordJourneyState(journeyId, CommonJourneyStates.OTP_VALIDATE_FAILURE);

        verify(feignClient).verifyOtp(req, journeyId);

        verifyNoMoreInteractions(journeyService, feignClient);
    }


    // =====================================================================
    //          VERIFY OTP: Unexpected Exception → VERIFY_OTP_FAILED
    // =====================================================================
    @Test
    @DisplayName("verifyOtp: unexpected Exception → VERIFY_OTP_FAILED")
    void testVerifyOtpGenericException() {

        VerifyOtpRequest req = VerifyOtpRequest.builder().build();
        String journeyId = "JV4";

        when(feignClient.verifyOtp(req, journeyId)).thenThrow(new RuntimeException("X"));

        OTPValidationException ex = assertThrows(
                OTPValidationException.class,
                () -> adapter.verifyOtp(req, journeyId)
        );

        assertEquals("Verify OTP Failed", ex.getMessage());

        verify(journeyService).recordJourneyState(journeyId, CommonJourneyStates.VALIDATE_OTP_INITIATED);
        verify(journeyService).recordJourneyState(journeyId, CommonJourneyStates.OTP_VALIDATE_FAILURE);

        verify(feignClient).verifyOtp(req, journeyId);

        verifyNoMoreInteractions(journeyService, feignClient);
    }
}
