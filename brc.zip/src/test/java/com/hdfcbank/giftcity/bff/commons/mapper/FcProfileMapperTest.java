package com.hdfcbank.giftcity.bff.commons.mapper;

import com.hdfcbank.giftcity.bff.commons.model.*;
import com.hdfcbank.service.adapters.vo.customer.FetchCasaResponse;
import com.hdfcbank.service.adapters.vo.customer.IdentifyGCCustomerResponse;
import com.hdfcbank.giftcity.bff.master.mapper.CountryMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mapstruct.factory.Mappers;

import java.lang.reflect.Field;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class FcProfileMapperTest {

    private FcProfileMapper mapper;
    private CountryMapper countryMapperMock;

    @BeforeEach
    void setup() throws Exception {
        mapper = Mappers.getMapper(FcProfileMapper.class);

        countryMapperMock = mock(CountryMapper.class);

        Field field = mapper.getClass().getDeclaredField("countryMapper");
        field.setAccessible(true);
        field.set(mapper, countryMapperMock);
    }

    // Test: toFcIndiaProfile(FetchCasaDetail)
    @Test
    void testToFcIndiaProfileMapping() {
        FetchCasaResponse.FetchCasaDetail src = new FetchCasaResponse.FetchCasaDetail();
        src.setExistingCustomer("YES");

        FetchCasaResponse.Profile p = FetchCasaResponse.Profile.builder()
                .name("John")
                .dob("1990-01-01")
                .mobileNumber("9999999999")
                .panNumber("ABCDE1234F")
                .build();

        src.setProfiles(List.of(p));

        FcIndiaProfile result = mapper.toFcIndiaProfile(src);

        assertNotNull(result);
        assertEquals("YES", result.getExistingCustomer());
        assertEquals(1, result.getProfiles().size());
        assertEquals("John", result.getProfiles().get(0).getName());
        assertEquals("9999999999", result.getProfiles().get(0).getMobileNumber());
    }

    // Test: toFcGcProfile(GCData)
    @Test
    void testToFcGcProfileMapping() {
        IdentifyGCCustomerResponse.GCData src = IdentifyGCCustomerResponse.GCData.builder()
                .customerId("CUST123")
                .accountStatus("ACTIVE")
                .linkedAccounts(List.of("A1", "A2"))
                .transactionStatus(
                        IdentifyGCCustomerResponse.TransactionStatus.builder()
                                .status("SUCCESS")
                                .errCode(null)
                                .errMsg(null)
                                .extRefNum("REF001")
                                .build()
                )
                .build();

        FcGcProfile result = mapper.toFcGcProfile(src);

        assertNotNull(result);
        assertEquals("CUST123", result.getCustomerId());
    }

    // Test: mapProfile(Profile) with CountryMapper usage
    @Test
    void testMapProfileWithCountryMapping() {

        FetchCasaResponse.Profile src = FetchCasaResponse.Profile.builder()
                .name("Alice")
                .namPermadrCntry("IN")
                .mailingCountry("US")
                .nationality("FR")
                .build();

        // Mock CountryMapper behavior
        when(countryMapperMock.masterDataFromCode("IN"))
                .thenReturn(MasterDataValue.builder().code("IN").description("India").build());
        when(countryMapperMock.masterDataFromCode("US"))
                .thenReturn(MasterDataValue.builder().code("US").description("United States").build());
        when(countryMapperMock.masterDataFromCode("FR"))
                .thenReturn(MasterDataValue.builder().code("FR").description("France").build());

        FcIndiaProfile.Profile result = mapper.mapProfile(src);

        assertNotNull(result);
        assertEquals("Alice", result.getName());
        assertEquals("India", result.getCountry().getDescription());
        assertEquals("United States", result.getMailingCountry().getDescription());
        assertEquals("France", result.getNationality().getDescription());
    }

    // Test: profiles(List<Profile>)
    @Test
    void testProfilesListMapping() {
        FetchCasaResponse.Profile p1 = FetchCasaResponse.Profile.builder().name("N1").build();
        FetchCasaResponse.Profile p2 = FetchCasaResponse.Profile.builder().name("N2").build();

        when(countryMapperMock.masterDataFromCode(anyString()))
                .thenReturn(null);

        List<FcIndiaProfile.Profile> result = mapper.profiles(List.of(p1, p2));

        assertEquals(2, result.size());
        assertEquals("N1", result.get(0).getName());
        assertEquals("N2", result.get(1).getName());
    }

    // Test: mapAccount(CustomerAccountDetail)
    @Test
    void testMapAccount() {
        FetchCasaResponse.CustomerAccountDetail src = FetchCasaResponse.CustomerAccountDetail.builder()
                .accountNumber("AC001")
                .productTypeDescription("SAVINGS")
                .build();

        FcIndiaProfile.CustomerAccountDetail result = mapper.mapAccount(src);

        assertNotNull(result);
        assertEquals("AC001", result.getAccountNumber());
        assertEquals("SAVINGS", result.getProductTypeDescription());
    }

    // Test: customerAccountDetails(List)
    @Test
    void testCustomerAccountDetailsListMapping() {
        FetchCasaResponse.CustomerAccountDetail c1 = FetchCasaResponse.CustomerAccountDetail.builder()
                .accountNumber("AC1")
                .build();

        FetchCasaResponse.CustomerAccountDetail c2 = FetchCasaResponse.CustomerAccountDetail.builder()
                .accountNumber("AC2")
                .build();

        List<FcIndiaProfile.CustomerAccountDetail> result =
                mapper.customerAccountDetails(List.of(c1, c2));

        assertEquals(2, result.size());
        assertEquals("AC1", result.get(0).getAccountNumber());
        assertEquals("AC2", result.get(1).getAccountNumber());
    }

    // Test: mapMemo(CustomerMemoDetail)
    @Test
    void testMapMemo() {
        FetchCasaResponse.CustomerMemoDetail src = new FetchCasaResponse.CustomerMemoDetail();
        src.setFlgSeverity("HIGH");

        FcIndiaProfile.CustomerMemoDetail result = mapper.mapMemo(src);

        assertNotNull(result);
        assertEquals("HIGH", result.getFlgSeverity());
    }

    // Test: customerMemoDetails(List)
    @Test
    void testCustomerMemoDetailsListMapping() {
        FetchCasaResponse.CustomerMemoDetail m1 = new FetchCasaResponse.CustomerMemoDetail();
        m1.setFlgSeverity("H1");

        FetchCasaResponse.CustomerMemoDetail m2 = new FetchCasaResponse.CustomerMemoDetail();
        m2.setFlgSeverity("H2");

        List<FcIndiaProfile.CustomerMemoDetail> result =
                mapper.customerMemoDetails(List.of(m1, m2));

        assertEquals(2, result.size());
        assertEquals("H1", result.get(0).getFlgSeverity());
        assertEquals("H2", result.get(1).getFlgSeverity());
    }

    // Test: mapFatca(CustomerFATCADetail)
    @Test
    void testMapFatca() {
        FetchCasaResponse.CustomerFATCADetail src = new FetchCasaResponse.CustomerFATCADetail();
        src.setCodTaxCntry1("IN");

        FcIndiaProfile.CustomerFATCADetail result = mapper.mapFatca(src);

        assertNotNull(result);
        assertEquals("IN", result.getCodTaxCntry1());
    }

// Test: customerFATCADetails(List)
    @Test
    void testCustomerFatcaDetailsListMapping() {
        FetchCasaResponse.CustomerFATCADetail f1 = new FetchCasaResponse.CustomerFATCADetail();
        f1.setCodTaxCntry1("A");

        FetchCasaResponse.CustomerFATCADetail f2 = new FetchCasaResponse.CustomerFATCADetail();
        f2.setCodTaxCntry1("B");

        List<FcIndiaProfile.CustomerFATCADetail> result =
                mapper.customerFATCADetails(List.of(f1, f2));

        assertNotNull(result);
        assertEquals(2, result.size());
        assertEquals("A", result.get(0).getCodTaxCntry1());
        assertEquals("B", result.get(1).getCodTaxCntry1());
    }

// Test: mapAml(CustomerAMLDetail)
    @Test
    void testMapAml() {
        FetchCasaResponse.CustomerAMLDetail src = new FetchCasaResponse.CustomerAMLDetail();
        src.setRiskProfile("HIGH_RISK");
        src.setGrossIncome("100000");

        FcIndiaProfile.CustomerAMLDetail result = mapper.mapAml(src);

        assertNotNull(result);
        assertEquals("HIGH_RISK", result.getRiskProfile());
        assertEquals("100000", result.getGrossIncome());
    }

// Test: customerAMLDetails(List)
    @Test
    void testCustomerAmlDetailsListMapping() {
        FetchCasaResponse.CustomerAMLDetail a1 = new FetchCasaResponse.CustomerAMLDetail();
        a1.setRiskProfile("LOW");

        FetchCasaResponse.CustomerAMLDetail a2 = new FetchCasaResponse.CustomerAMLDetail();
        a2.setRiskProfile("MEDIUM");

        List<FcIndiaProfile.CustomerAMLDetail> result =
                mapper.customerAMLDetails(List.of(a1, a2));

        assertNotNull(result);
        assertEquals(2, result.size());
        assertEquals("LOW", result.get(0).getRiskProfile());
        assertEquals("MEDIUM", result.get(1).getRiskProfile());
    }
}