package com.hdfcbank.giftcity.bff.customer.mapper;

import com.hdfcbank.common.models.vo.journey.JourneyData;
import com.hdfcbank.giftcity.bff.commons.constant.CommonConstants;
import com.hdfcbank.giftcity.bff.commons.model.FcIndiaProfile;
import com.hdfcbank.giftcity.bff.customer.constants.CustomerConstants;
import com.hdfcbank.giftcity.bff.customer.model.CustomerDetails;
import com.hdfcbank.service.adapters.vo.customer.FccCustomerRequest;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.NullAndEmptySource;
import org.junit.jupiter.params.provider.ValueSource;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.Mockito.CALLS_REAL_METHODS;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.mock;

class CreateFCCCustomerMapperUdfTest {

    private final CreateFCCCustomerMapper mapper = mock(CreateFCCCustomerMapper.class, CALLS_REAL_METHODS);

    @ParameterizedTest
    @CsvSource({"Y,YES", "y,YES", "N,NO", "n,NO", "custom,custom", "YES,YES", "NO,NO"})
    void tradeTransactionMappingPreservesCaseInsensitiveFlagsAndOtherValues(String input, String expected) {
        Map<String, String> defaults = Map.of(CommonConstants.TRADE_TRANSACTION_CUSTOMER, input);

        assertEquals(expected, fieldValue(mapUdf(defaults, null), CommonConstants.CC_TRADE_TRANSACTION_CUSTOMER));
    }

    @ParameterizedTest
    @NullAndEmptySource
    void tradeTransactionMappingPreservesNullAndEmptyValues(String input) {
        Map<String, String> defaults = new HashMap<>();
        defaults.put(CommonConstants.TRADE_TRANSACTION_CUSTOMER, input);

        assertEquals(input, fieldValue(mapUdf(defaults, null), CommonConstants.CC_TRADE_TRANSACTION_CUSTOMER));
    }

    @Test
    void tradeTransactionMappingPreservesMissingConfiguration() {
        assertNull(fieldValue(mapUdf(Map.of(), null), CommonConstants.CC_TRADE_TRANSACTION_CUSTOMER));
    }

    @ParameterizedTest
    @CsvSource({"Yes,PEP", "YES,PEP", "yes,PEP", "No,Non-PEP", "other,Non-PEP"})
    void pepMappingPreservesCaseInsensitiveYesAndNonPepFallback(String input, String expected) {
        CustomerDetails.EmploymentFinancial employment = new CustomerDetails.EmploymentFinancial();
        employment.setPep(input);

        assertEquals(expected, fieldValue(mapUdf(Map.of(), employment), CommonConstants.CC_PEP_NONPEP));
    }

    @ParameterizedTest
    @NullAndEmptySource
    @ValueSource(strings = " ")
    void pepMappingPreservesNonPepForMissingOrBlankAnswer(String input) {
        CustomerDetails.EmploymentFinancial employment = new CustomerDetails.EmploymentFinancial();
        employment.setPep(input);

        assertEquals(CommonConstants.CC_NON_PEP, fieldValue(mapUdf(Map.of(), employment), CommonConstants.CC_PEP_NONPEP));
    }

    @Test
    void pepMappingPreservesNullWhenEmploymentIsAbsent() {
        assertNull(fieldValue(mapUdf(Map.of(), null), CommonConstants.CC_PEP_NONPEP));
    }

    private List<FccCustomerRequest.UdfDetails> mapUdf(Map<String, String> defaults,
                                                    CustomerDetails.EmploymentFinancial employment) {
        Map<String, Object> inputs = Map.of(CustomerConstants.EMPLOYMENT, "employment-fixture");
        doReturn(employment).when(mapper).mapEmployment(inputs);
        JourneyData journey = new JourneyData();
        journey.setReferenceNo("REF-123");

        return mapper.mapUdf(new FcIndiaProfile.Profile(), inputs, defaults, null, journey);
    }

    private String fieldValue(List<FccCustomerRequest.UdfDetails> fields, String name) {
        return fields.stream()
                .filter(field -> name.equals(field.getFieldName()))
                .findFirst()
                .orElseThrow()
                .getFieldValue();
    }
}
