package com.hdfcbank.giftcity.bff.application.listener;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.hdfcbank.common.models.vo.journey.JourneyData;
import com.hdfcbank.common.models.vo.journey.JourneyDetail;
import com.hdfcbank.common.models.vo.journey.Profile;
import com.hdfcbank.giftcity.bff.application.events.SqsCustomerSubmitPayload;
import com.hdfcbank.giftcity.bff.application.service.BackgroundEventPublisherService;
import com.hdfcbank.giftcity.bff.commons.enums.CommonJourneyStates;
import com.hdfcbank.giftcity.bff.commons.exception.handler.DownstreamResponseHandler;
import com.hdfcbank.giftcity.bff.commons.config.JourneyConfigProperties;
import com.hdfcbank.giftcity.bff.commons.handler.Handler;
import com.hdfcbank.giftcity.bff.commons.handler.HandlerContext;
import com.hdfcbank.giftcity.bff.commons.handler.HandlerResult;
import com.hdfcbank.giftcity.bff.commons.handler.HandlersFactory;
import com.hdfcbank.giftcity.bff.commons.model.CustomValidationStatus;
import com.hdfcbank.giftcity.bff.infrastructure.service.JourneyService;
import io.awspring.cloud.sqs.listener.acknowledgement.Acknowledgement;

import org.junit.jupiter.api.*;
import org.mockito.*;

import java.lang.reflect.Field;
import java.util.*;

import static com.hdfcbank.giftcity.bff.application.events.BackgroundEvents.*;
import static org.mockito.Mockito.*;

import ch.qos.logback.classic.Level;
import ch.qos.logback.classic.Logger;
import org.slf4j.LoggerFactory;

class SqsApplicationSubmitListenerTest {

    //      Mute listener logs – clean console output
    @BeforeAll
    static void muteListenerLogs() {
        Logger logger = (Logger) LoggerFactory.getLogger(SqsApplicationSubmitListener.class);
        logger.setLevel(Level.OFF);
    }

    @InjectMocks
    private SqsApplicationSubmitListener listener;

    @Mock
    private ObjectMapper objectMapper;

    @Mock
    private JourneyService journeyService;

    @Mock
    private HandlersFactory handlersFactory;

    @Mock
    private BackgroundEventPublisherService backgroundEventPublisherService;

    @Mock
    private Acknowledgement acknowledgement;

    private JourneyData journeyData;
    private Profile profile;
    private JourneyDetail journeyDetail;
    private SqsCustomerSubmitPayload payload;

    @BeforeEach
    void setup() throws Exception {
        MockitoAnnotations.openMocks(this);

        // Inject private background queue into listener
        Field q = SqsApplicationSubmitListener.class.getDeclaredField("backgroundTasksQueue");
        q.setAccessible(true);
        q.set(listener, "FIFO_Q_URL");

        // Mock DownstreamResponseHandler configuration
        JourneyConfigProperties mockCfg = mock(JourneyConfigProperties.class);
        JourneyConfigProperties.JourneyConfig jc = mock(JourneyConfigProperties.JourneyConfig.class);

        JourneyConfigProperties.ErrorMapping em = new JourneyConfigProperties.ErrorMapping();
        em.setDownstreamErrorCode("UNKNOWN");
        em.setCategory("UNKNOWN");
        em.setErrorCode("E100");
        em.setMessageHeading("Failure");
        em.setMessage("Retry > 3 failure");

        when(mockCfg.getJourneys()).thenReturn(Map.of("GIFT_CITY", jc));
        when(jc.getErrorMapping()).thenReturn(List.of(em));

        Field sf = DownstreamResponseHandler.class.getDeclaredField("journeyConfigProperties");
        sf.setAccessible(true);
        sf.set(null, mockCfg);

        // Build journeyData
        profile = Profile.builder().customerId("CUST123").build();
        journeyDetail = new JourneyDetail();
        journeyDetail.setSystemData(new HashMap<>());

        journeyData = JourneyData.builder()
                .journeyId("J123")
                .journeyName("GIFT_CITY")
                .profile(profile)
                .journeyDetail(journeyDetail)
                .build();

        payload = SqsCustomerSubmitPayload.builder()
                .journeyId("J123")
                .properties(new HashMap<>())
                .build();
    }


         
    //      SUCCESS FLOW — ALL HANDLERS PASS

    @Test
    void testSuccessFlow_AllHandlersPass() throws Exception {

        Map<String, Object> headers = Map.of(
                "MessageId", "M1",
                "Sqs_Msa_ApproximateReceiveCount", "1"
        );

        when(objectMapper.readValue(anyString(), eq(SqsCustomerSubmitPayload.class)))
                .thenReturn(payload);

        when(journeyService.fetchJourney("J123")).thenReturn(journeyData);

        Handler handler = mock(Handler.class);
        when(handler.getName()).thenReturn(Handler.HandlerName.CREATE_CUSTOMER);
        when(handler.getType()).thenReturn(Handler.HandlerType.CUSTOMER_POST_SUBMIT);
        when(handler.preConditions(any())).thenReturn(true);
        when(handler.handle(any())).thenReturn(HandlerResult.of(null, null, true));
        when(handler.successState()).thenReturn(CommonJourneyStates.CUSTOMER_VALIDATED_SUCCESS);

        when(handlersFactory.getHandlers("GIFT_CITY",
                Handler.HandlerType.CUSTOMER_POST_SUBMIT))
                .thenReturn(List.of(handler));

        listener.sqsCustomerValidateListener("{}", headers, acknowledgement);

        //       Only these 4 events should be verified
        verify(backgroundEventPublisherService)
                .sendBackgroundEvent("J123", "CUST123", AOF_WITH_ANNEXTURE_UPLOAD, new HashMap<>());

        verify(backgroundEventPublisherService)
                .sendBackgroundEvent("J123", "CUST123", AOF_WITHOUT_ANNEXTURE_UPLOAD, new HashMap<>());

        verify(backgroundEventPublisherService)
                .sendBackgroundEvent("J123", "CUST123", DPCFTP_UPLOAD, new HashMap<>());

        verify(backgroundEventPublisherService)
                .sendBackgroundEvent("J123", "CUST123", FTS_ACCOUNT_OPENING, new HashMap<>());

        verify(acknowledgement).acknowledge();
    }


         
    //      FAILURE FLOW — HANDLER FAILS
         
    @Test
    void testHandlerFailure() throws Exception {

        Map<String, Object> headers = Map.of(
                "MessageId", "MID-2",
                "Sqs_Msa_ApproximateReceiveCount", "1"
        );

        when(objectMapper.readValue(anyString(), eq(SqsCustomerSubmitPayload.class)))
                .thenReturn(payload);

        when(journeyService.fetchJourney("J123")).thenReturn(journeyData);

        Handler handler = mock(Handler.class);
        when(handler.getName()).thenReturn(Handler.HandlerName.DPCFTP_UPLOAD);
        when(handler.getType()).thenReturn(Handler.HandlerType.CUSTOMER_POST_SUBMIT);
        when(handler.preConditions(any())).thenReturn(true);

        CustomValidationStatus status = CustomValidationStatus.builder().code("ERR").build();
        HandlerResult<Object> failResult = HandlerResult.of(status, null, false);

        when(handler.handle(any())).thenReturn(failResult);
        when(handler.failureState()).thenReturn(CommonJourneyStates.SUBMIT_HANDLERS_FAILURE);

        when(handlersFactory.getHandlers(anyString(), any()))
                .thenReturn(List.of(handler));

        listener.sqsCustomerValidateListener("{}", headers, acknowledgement);

        verify(journeyService).updateJourneyDetailDropOff(
                eq(journeyData),
                eq(status),
                eq(CommonJourneyStates.SUBMIT_HANDLERS_FAILURE)
        );

        verify(backgroundEventPublisherService, never())
                .sendBackgroundEvent(any(), any(), any(), any());

        verify(acknowledgement).acknowledge();
    }


         
    //      NO HANDLERS → STILL TRIGGER BACKGROUND EVENTS

    @Test
    void testNoHandlers_StillTriggersBackgroundEvents() throws Exception {

        Map<String, Object> headers = Map.of("Sqs_Msa_ApproximateReceiveCount", "1");

        when(objectMapper.readValue(anyString(), eq(SqsCustomerSubmitPayload.class)))
                .thenReturn(payload);

        when(journeyService.fetchJourney("J123")).thenReturn(journeyData);

        when(handlersFactory.getHandlers(anyString(), any()))
                .thenReturn(Collections.emptyList());

        listener.sqsCustomerValidateListener("{}", headers, acknowledgement);

        verify(backgroundEventPublisherService, times(4))
                .sendBackgroundEvent(anyString(), anyString(), any(), any());

        verify(acknowledgement).acknowledge();
    }


         
    //      JSON PARSE EXCEPTION
         
    @Test
    void testJsonProcessingException() throws Exception {

        Map<String, Object> headers = Map.of("MessageId", "MID_FAIL");

        when(objectMapper.readValue(anyString(), eq(SqsCustomerSubmitPayload.class)))
                .thenThrow(JsonProcessingException.class);

        listener.sqsCustomerValidateListener("BAD_JSON", headers, acknowledgement);

        verify(acknowledgement, never()).acknowledge();
    }


         
    //      GENERAL EXCEPTION — RETRY < 3 → DO NOT ACK
         
    @Test
    void testGeneralException_RetryLessThan3() throws Exception {

        Map<String, Object> headers = Map.of("Sqs_Msa_ApproximateReceiveCount", "2");

        when(objectMapper.readValue(anyString(), eq(SqsCustomerSubmitPayload.class)))
                .thenReturn(payload);

        when(journeyService.fetchJourney("J123"))
                .thenThrow(new RuntimeException("DB failure"));

        listener.sqsCustomerValidateListener("{}", headers, acknowledgement);

        verify(acknowledgement, never()).acknowledge();
    }


         
    //      GENERAL EXCEPTION — RETRY > 3 (Final Fix)
         
    @Test
    void testGeneralException_RetryGreaterThan3() throws Exception {

        Map<String, Object> headers = Map.of("Sqs_Msa_ApproximateReceiveCount", "4");

        when(objectMapper.readValue(anyString(), eq(SqsCustomerSubmitPayload.class)))
                .thenReturn(payload);

        // First successful fetch, second throws inside callHandlers()
        when(journeyService.fetchJourney("J123"))
                .thenReturn(journeyData)
                .thenThrow(new RuntimeException("UnknownError"));

        // A handler to ensure callHandlers() runs and triggers second fetch
        Handler handler = mock(Handler.class);
        when(handler.getName()).thenReturn(Handler.HandlerName.CREATE_CUSTOMER);
        when(handler.getType()).thenReturn(Handler.HandlerType.CUSTOMER_POST_SUBMIT);
        when(handler.preConditions(any())).thenReturn(true);
        when(handler.handle(any())).thenReturn(HandlerResult.of(null, null, true));
        when(handler.successState()).thenReturn(CommonJourneyStates.CUSTOMER_VALIDATED_SUCCESS);

        when(handlersFactory.getHandlers(anyString(), any()))
                .thenReturn(List.of(handler));

        ArgumentCaptor<Object> apiStatusCaptor = ArgumentCaptor.forClass(Object.class);

        listener.sqsCustomerValidateListener("{}", headers, acknowledgement);

        verify(journeyService).updateJourneyDetailDropOff(
                eq(journeyData),
                apiStatusCaptor.capture(),
                eq(CommonJourneyStates.SUBMIT_HANDLERS_FAILURE)
        );

        Assertions.assertNotNull(apiStatusCaptor.getValue());
        verify(acknowledgement).acknowledge();
    }
}