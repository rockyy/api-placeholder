package com.hdfcbank.giftcity.bff.customer.mapper;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hdfcbank.giftcity.bff.customer.config.CustomerApiProperties;
import com.hdfcbank.giftcity.bff.commons.utility.TextSanityUtil;
import com.hdfcbank.giftcity.bff.customer.utility.CustomerUtil;
import com.hdfcbank.giftcity.bff.customer.model.IdentifyCustomerRequest;
import com.hdfcbank.giftcity.bff.customer.model.IdentifierType;
import com.hdfcbank.giftcity.bff.customer.constants.CustomerConstants;
import com.hdfcbank.service.adapters.vo.customer.FetchCasaRequest;
import com.hdfcbank.service.adapters.vo.customer.IdentifyGCCustomerRequest;
import com.hdfcbank.giftcity.bff.commons.utility.CommonUtil;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.lang.reflect.Field;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class CustomerMapperTest {

    private CustomerMapper mapper;
    private CustomerApiProperties apiProps;
    private ObjectMapper objectMapper;

    @BeforeEach
    void setup() throws Exception {
        apiProps = mock(CustomerApiProperties.class);
        objectMapper = new ObjectMapper();

        mapper = new CustomerMapper();

        // Inject mocks into private fields (no need to change production code)
        Field apiPropsField = CustomerMapper.class.getDeclaredField("customerApiProperties");
        apiPropsField.setAccessible(true);
        apiPropsField.set(mapper, apiProps);

        Field objectMapperField = CustomerMapper.class.getDeclaredField("objectMapper");
        objectMapperField.setAccessible(true);
        objectMapperField.set(mapper, objectMapper);
    }

    // toFetchCasaRequest Tests

    @Test
    void test_toFetchCasaRequest_withPAN() {
        IdentifyCustomerRequest req = IdentifyCustomerRequest.builder()
                .identifierName(IdentifierType.PAN.name())
                .identifierValue("ABCDE1234F")
                .isd("+91")
                .mobileNo("9876543210")
                .build();

        FetchCasaRequest result = mapper.toFetchCasaRequest(req, "Journey1");

        assertEquals("+91", result.getIsd());
        assertEquals(TextSanityUtil.sanitize("9876543210"), result.getMobileNumber());
        assertEquals("", result.getDob());
        assertEquals(CustomerUtil.sanitizePan("ABCDE1234F"), result.getPan());
        assertEquals("Journey1", result.getJourneyName());
    }

    @Test
    void test_toFetchCasaRequest_withDOB() {
        IdentifyCustomerRequest req = IdentifyCustomerRequest.builder()
                .identifierName(IdentifierType.DOB.name())
                .identifierValue("1990-01-01")
                .isd("+91")
                .mobileNo("9000000000")
                .build();

        FetchCasaRequest result = mapper.toFetchCasaRequest(req, "JX");

        assertEquals(CustomerUtil.sanitizeDob("1990-01-01"), result.getDob());
        assertEquals("", result.getPan());
    }

    @Test
    void test_toFetchCasaRequest_unknownIdentifier() {
        IdentifyCustomerRequest req = IdentifyCustomerRequest.builder()
                .identifierName(IdentifierType.CUSTOMER_ID.name())
                .identifierValue("XYZ123")
                .isd("+91")
                .mobileNo("7000000000")
                .build();

        FetchCasaRequest result = mapper.toFetchCasaRequest(req, "AAA");

        assertEquals("", result.getDob());
        assertEquals("", result.getPan());
    }

    // toGcRequest Tests

    @Test
    void test_toGcRequest_withDOB() {
        IdentifyCustomerRequest req = IdentifyCustomerRequest.builder()
                .identifierName(IdentifierType.DOB.name())
                .identifierValue("2001-02-02")
                .isd("91")
                .mobileNo("7777777777")
                .build();

        IdentifyGCCustomerRequest result = mapper.toGcRequest(req);

        List<IdentifyGCCustomerRequest.CustomerParam> params = result.getCustParams();

        assertEquals(2, params.size());
        assertEquals(CustomerConstants.MOBILE_NO, params.get(0).getParamName());
        assertEquals(req.getFullMobileNumber(), params.get(0).getParamValue());

        assertEquals(CustomerConstants.DOB, params.get(1).getParamName());
        assertEquals(CommonUtil.formatDob("2001-02-02"), params.get(1).getParamValue());
    }

    @Test
    void test_toGcRequest_withPAN() {
        IdentifyCustomerRequest req = IdentifyCustomerRequest.builder()
                .identifierName(IdentifierType.PAN.name())
                .identifierValue("ABCDE1111Z")
                .isd("91")
                .mobileNo("8888888888")
                .build();

        IdentifyGCCustomerRequest result = mapper.toGcRequest(req);

        assertEquals(2, result.getCustParams().size());
        assertEquals(CustomerConstants.PAN, result.getCustParams().get(1).getParamName());
        assertEquals(TextSanityUtil.sanitize("ABCDE1111Z"),
                result.getCustParams().get(1).getParamValue());
    }

    @Test
    void test_toGcRequest_unknownIdentifier_onlyMobile() {
        IdentifyCustomerRequest req = IdentifyCustomerRequest.builder()
                .identifierName(IdentifierType.CUSTOMER_ID.name())
                .identifierValue("ID001")
                .isd("91")
                .mobileNo("7777777777")
                .build();

        IdentifyGCCustomerRequest result = mapper.toGcRequest(req);

        assertEquals(1, result.getCustParams().size());
        assertEquals(CustomerConstants.MOBILE_NO,
                result.getCustParams().get(0).getParamName());
        assertEquals(req.getFullMobileNumber(),
                result.getCustParams().get(0).getParamValue());
    }
}