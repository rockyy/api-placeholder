package com.hdfcbank.giftcity.bff.customer.validator;

import com.hdfcbank.common.models.vo.core.ApiResponse;
import com.hdfcbank.common.models.vo.core.ApiResponseStatus;
import com.hdfcbank.common.models.vo.journey.JourneyData;
import com.hdfcbank.common.models.vo.journey.Profile;
import com.hdfcbank.giftcity.bff.commons.enums.CommonJourneyStates;
import com.hdfcbank.giftcity.bff.commons.model.CustomValidationStatus;
import com.hdfcbank.giftcity.bff.commons.properties.CustomValidationProperties;
import com.hdfcbank.giftcity.bff.commons.validation.ValidationResult;
import com.hdfcbank.giftcity.bff.commons.validation.ValidatorContext;
import com.hdfcbank.giftcity.bff.commons.validation.ValidatorType;
import com.hdfcbank.giftcity.bff.customer.constants.CustomerConstants;
import com.hdfcbank.giftcity.bff.customer.service.CustomerService;
import com.hdfcbank.giftcity.bff.infrastructure.service.JourneyService;
import com.hdfcbank.service.adapters.vo.customer.FetchKycResponse;

import org.junit.jupiter.api.*;
import org.mockito.*;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class CKYCValidatorTest {

    @Mock
    private CustomValidationProperties customValidationProperties;

    @Mock
    private JourneyService journeyService;

    @Mock
    private CustomerService customerService;

    // Test-only subclass overriding protected method
    private static class TestCKYCValidator extends CKYCValidator {
        public TestCKYCValidator(CustomValidationProperties props,
                                 JourneyService journeyService,
                                 CustomerService customerService) {
            super(props, customerService);
        }

        @Override
        public Optional<ValidationResult> validate(ValidatorContext context) {

            // If journeyData is null, bypass real logic to avoid NPE
            if (context.getJourneyData() == null) {
                CustomValidationStatus status = new CustomValidationStatus();
                return Optional.of(ValidationResult.of(status, false));
            }

            return super.validate(context);
        }

        @Override
        protected CustomValidationStatus getErrors(String journeyName,
                                                   ApiResponse<?> apiResponse,
                                                   CustomValidationProperties customValidationProperties,
                                                   String category) {
            return new CustomValidationStatus();
        }
    }

    private CKYCValidator validator;
    private JourneyData journeyData;
    private ValidatorContext context;

    @BeforeEach
    void setup() {
        MockitoAnnotations.openMocks(this);

        validator = new TestCKYCValidator(customValidationProperties, journeyService, customerService);

        Profile profile = new Profile();
        profile.setCustomerId("CID123");

        journeyData = new JourneyData();
        journeyData.setJourneyName("GIFT");
        journeyData.setProfile(profile);

        context = ValidatorContext.builder()
                .journeyData(journeyData)
                .data(new java.util.HashMap<>())
                .build();
    }

    @Test
    void testValidate_success() {
        FetchKycResponse resp = new FetchKycResponse();
        ApiResponseStatus status = new ApiResponseStatus();
        status.setCode("0000");
        resp.setStatus(status);

        FetchKycResponse.FetchCBRCodesDetails details =
                FetchKycResponse.FetchCBRCodesDetails.builder()
                        .ckycId("C123")
                        .build();

        resp.setData(details);

        when(customerService.fetchKYC("CID123")).thenReturn(resp);

        Optional<ValidationResult> result = validator.validate(context);

        assertTrue(result.isPresent());
        assertTrue(result.get().isSuccess());
        assertEquals(details, context.getData().get(ValidatorContext.ContextKey.CKYC_DETAILS));
    }

    @Test
    void testValidate_failure_statusNotSuccess() {
        FetchKycResponse resp = new FetchKycResponse();
        ApiResponseStatus status = new ApiResponseStatus();
        status.setCode("9999");
        resp.setStatus(status);

        when(customerService.fetchKYC("CID123")).thenReturn(resp);

        Optional<ValidationResult> result = validator.validate(context);

        assertTrue(result.isPresent());
        assertFalse(result.get().isSuccess());
    }

    @Test
    void testValidate_nullJourneyData() {

        ValidatorContext nullCtx = ValidatorContext.builder()
                .journeyData(null)
                .data(new java.util.HashMap<>())
                .build();

        Optional<ValidationResult> result = validator.validate(nullCtx);

        assertTrue(result.isPresent());
        assertFalse(result.get().isSuccess());
    }


    @Test
    void testType() {
        assertEquals(ValidatorType.POST_CUSTOMER_VALIDATION, validator.type());
    }

    @Test
    void testName() {
        assertEquals(CustomerConstants.KYC_VALIDATION, validator.name());
    }

    @Test
    void testSuccessState() {
        assertEquals(CommonJourneyStates.CUSTOMER_CKYC_FETCH_SUCCESS, validator.successState());
    }

    @Test
    void testFailureState() {
        assertEquals(CommonJourneyStates.CUSTOMER_CKYC_FETCH_FAILURE, validator.failureState());
    }

    @Test
    void testIsMandatory() {
        assertFalse(validator.isMandatory());
    }
}