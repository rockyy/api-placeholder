package com.hdfcbank.giftcity.bff.commons.config;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

import static org.junit.jupiter.api.Assertions.*;

import ch.qos.logback.classic.Level;
import ch.qos.logback.classic.Logger;
import org.slf4j.LoggerFactory;

class StringToDateConverterTest {

    private final StringToDateConverter converter = new StringToDateConverter();

    @BeforeAll
    static void muteConverterLogs() {
        Logger logger = (Logger) LoggerFactory.getLogger(StringToDateConverter.class);
        logger.setLevel(Level.OFF);
    }

    private SimpleDateFormat localFmt(String pattern) {
        SimpleDateFormat sdf = new SimpleDateFormat(pattern);
        sdf.setTimeZone(TimeZone.getDefault());
        return sdf;
    }

    @Test
    void testConvertIsoMillisTz() {
        String input = "2024-01-02T12:45:30.123Z";

        Date date = converter.convert(input);
        assertNotNull(date, "Converter returned null date for ISO millis format");

        // Check correct UTC → IST conversion
        String expected = "2024-01-02T18:15:30.123+05";
        String actual = localFmt("yyyy-MM-dd'T'HH:mm:ss.SSSX").format(date);

        assertEquals(expected, actual);

        // Extra assertions
        assertTrue(date.getTime() > 0);
        assertEquals(123, Integer.parseInt(localFmt("SSS").format(date)));
    }

    @Test
    void testConvertIsoTz() {
        String input = "2024-01-02T12:45:30Z";

        Date date = converter.convert(input);
        assertNotNull(date);

        String expected = "2024-01-02T18:15:30+05";
        String actual = localFmt("yyyy-MM-dd'T'HH:mm:ssX").format(date);

        assertEquals(expected, actual);

        // Extra assertions
        assertTrue(actual.endsWith("+05"));
        assertEquals("2024-01-02", localFmt("yyyy-MM-dd").format(date));
    }

    @Test
    void testConvertSpaceSeparatedFormat() {
        String input = "2024-01-02 12:45:30";

        Date date = converter.convert(input);
        assertNotNull(date);

        assertEquals(input, localFmt("yyyy-MM-dd HH:mm:ss").format(date));

        // Extra assertions
        assertEquals("12", localFmt("HH").format(date));
        assertEquals("45", localFmt("mm").format(date));
    }

    @Test
    void testConvertDateOnlyFormat() {
        String input = "2024-01-02";

        Date date = converter.convert(input);
        assertNotNull(date);

        assertEquals(input, localFmt("yyyy-MM-dd").format(date));

        // Extra assertions
        assertEquals("00", localFmt("HH").format(date));
        assertEquals("00", localFmt("mm").format(date));
        assertEquals("00", localFmt("ss").format(date));
    }

    @Test
    void testNormalizeIsoDateWrapper() {
        String input = "ISODate(\"2024-01-02T05:30:00Z\")";

        Date date = converter.convert(input);
        assertNotNull(date);

        String expected = "2024-01-02T11:00:00+05";
        String actual = localFmt("yyyy-MM-dd'T'HH:mm:ssX").format(date);

        assertEquals(expected, actual);

        // Extra assertions
        assertEquals("11", localFmt("HH").format(date));
        assertEquals("00", localFmt("mm").format(date));
    }

    @Test
    void testConvertThrowsForNull() {
        IllegalArgumentException ex =
                assertThrows(IllegalArgumentException.class, () -> converter.convert(null));

        assertNotNull(ex.getMessage());
        assertFalse(ex.getMessage().isBlank());
    }

    @Test
    void testConvertThrowsForEmpty() {
        IllegalArgumentException ex =
                assertThrows(IllegalArgumentException.class, () -> converter.convert("   "));

        assertNotNull(ex.getMessage());
        assertTrue(ex.getMessage().contains("empty"));
    }

    @Test
    void testConvertThrowsForUnparseableDate() {
        IllegalArgumentException ex =
                assertThrows(IllegalArgumentException.class, () -> converter.convert("not-a-date-at-all"));

        assertNotNull(ex.getMessage());
        assertTrue(ex.getMessage().toLowerCase().contains("parse"));
    }
}