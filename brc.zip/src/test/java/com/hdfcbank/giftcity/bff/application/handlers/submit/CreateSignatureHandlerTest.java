package com.hdfcbank.giftcity.bff.application.handlers.submit;

import com.hdfcbank.adapters.clients.feign.document.DocumentFeignClient;
import com.hdfcbank.adapters.vo.DownloadDocumentRequest;
import com.hdfcbank.common.models.vo.core.ApiResponseStatus;
import com.hdfcbank.common.models.vo.journey.JourneyData;
import com.hdfcbank.common.models.vo.journey.JourneyDetail;
import com.hdfcbank.common.models.vo.journey.Profile;
import com.hdfcbank.giftcity.bff.commons.enums.CommonJourneyStates;
import com.hdfcbank.giftcity.bff.commons.exception.handler.DownstreamResponseHandler;
import com.hdfcbank.giftcity.bff.commons.handler.Handler;
import com.hdfcbank.giftcity.bff.commons.handler.HandlerContext;
import com.hdfcbank.giftcity.bff.commons.handler.HandlerResult;
import com.hdfcbank.giftcity.bff.commons.model.CustomValidationStatus;
import com.hdfcbank.giftcity.bff.commons.model.FcGcProfile;
import com.hdfcbank.giftcity.bff.infrastructure.service.JourneyService;
import com.hdfcbank.service.adapters.clients.feign.customer.CustomerServiceFeignClient;
import com.hdfcbank.service.adapters.vo.customer.CreateSignatureResponse;
import com.hdfcbank.service.adapters.vo.customer.CreateSignatureResponse.CreateSignatureDetails;
import com.hdfcbank.service.adapters.vo.customer.SignatureRequest;

import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;

import org.springframework.http.ResponseEntity;

import java.util.*;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
class CreateSignatureHandlerTest {

    @Mock private CustomerServiceFeignClient customerServiceFeignClient;
    @Mock private DocumentFeignClient documentFeignClient;
    @Mock private JourneyService journeyService;

    @Spy
    @InjectMocks
    private CreateSignatureHandler handler;

    private JourneyData journeyData;
    private HandlerContext ctx;

    @BeforeEach
    void setup() {

        Profile profile = Profile.builder()
                .fullName("John Doe")
                .customerId("C123")
                .build();

        JourneyDetail detail = new JourneyDetail();
        detail.setSystemData(new HashMap<>());

        journeyData = JourneyData.builder()
                .journeyId("J100")
                .journeyName("GIFT_CITY")
                .profile(profile)
                .journeyDetail(detail)
                .build();

        ctx = HandlerContext.builder()
                .journeyData(journeyData)
                .data(new HashMap<>())
                .properties(new HashMap<>())
                .build();
    }

    // ---------------------------------------------------------------
    // PRECONDITIONS
    // ---------------------------------------------------------------

    @Test
    void preConditions_true() {
        doReturn(true).when(handler).isSuccess(ctx, Handler.HandlerName.CREATE_CUSTOMER);
        doReturn(true).when(handler).isSuccess(ctx, Handler.HandlerName.CREATE_ACCOUNT);

        assertTrue(handler.preConditions(ctx));
    }

    @Test
    void preConditions_false_customerFails() {
        doReturn(false).when(handler).isSuccess(ctx, Handler.HandlerName.CREATE_CUSTOMER);
        lenient().doReturn(true).when(handler).isSuccess(ctx, Handler.HandlerName.CREATE_ACCOUNT);

        assertFalse(handler.preConditions(ctx));
    }

    @Test
    void preConditions_false_accountFails() {
        doReturn(true).when(handler).isSuccess(ctx, Handler.HandlerName.CREATE_CUSTOMER);
        doReturn(false).when(handler).isSuccess(ctx, Handler.HandlerName.CREATE_ACCOUNT);

        assertFalse(handler.preConditions(ctx));
    }

    // ---------------------------------------------------------------
    // SUCCESS CASE — status.code = 0000
    // ---------------------------------------------------------------

    @Test
    void handle_success_signatureCreate() {

        when(journeyService.fetchJourney("J100")).thenReturn(journeyData);

        FcGcProfile fcGc = new FcGcProfile();
        fcGc.setCustomerSignatureDocRef("SIG123");

        try (MockedStatic<JourneyService> jsvc = mockStatic(JourneyService.class)) {

            jsvc.when(() -> JourneyService.extractFromJourney(
                    eq(journeyData),
                    eq("CUSTOMER_FC_GIFT_CITY_DETAIL"),
                    eq(FcGcProfile.class),
                    any()
            )).thenReturn(Optional.of(fcGc));

            // Document download mock
            when(documentFeignClient.downloadResponse(
                    eq("J100"),
                    eq("GIFT_CITY"),
                    any(DownloadDocumentRequest.class)
            )).thenReturn(ResponseEntity.ok("IMG".getBytes()));

            // FEIGN success
            ApiResponseStatus okStatus = new ApiResponseStatus();
            okStatus.setCode("0000");
            okStatus.setMessage("OK");

            CreateSignatureDetails details =
                    CreateSignatureDetails.builder()
                            .transactionStatus(null)
                            .responseString(null)
                            .build();

            CreateSignatureResponse resp =
                    CreateSignatureResponse.builder()
                            .status(okStatus)
                            .data(details)
                            .build();

            when(customerServiceFeignClient.createSignature(any(SignatureRequest.class)))
                    .thenReturn(resp);

            HandlerResult<CreateSignatureResponse> result = handler.handle(ctx);

            // ---------- Assertions ----------
            assertTrue(result.isSuccess());
            assertNotNull(result.getResult());
            assertEquals("0000", result.getResult().getStatus().getCode());
            assertEquals("OK", result.getResult().getStatus().getMessage());

            assertNull(result.getApiResponseStatus(), "apiResponseStatus must be NULL in success flow");

            verify(customerServiceFeignClient, times(1))
                    .createSignature(any(SignatureRequest.class));

            verify(documentFeignClient, times(1))
                    .downloadResponse(eq("J100"), eq("GIFT_CITY"), any(DownloadDocumentRequest.class));
        }
    }

    // ---------------------------------------------------------------
    // FAILURE CASE — status.code != 0000
    // ---------------------------------------------------------------

    @Test
    void handle_failure_signatureCreate() {

        when(journeyService.fetchJourney("J100")).thenReturn(journeyData);

        FcGcProfile fcGc = new FcGcProfile();
        fcGc.setCustomerSignatureDocRef("SIG123");

        try (
                MockedStatic<JourneyService> jsvc = mockStatic(JourneyService.class);
                MockedStatic<DownstreamResponseHandler> dsh = mockStatic(DownstreamResponseHandler.class)
        ) {

            jsvc.when(() -> JourneyService.extractFromJourney(
                    eq(journeyData),
                    eq("CUSTOMER_FC_GIFT_CITY_DETAIL"),
                    eq(FcGcProfile.class),
                    any()
            )).thenReturn(Optional.of(fcGc));

            when(documentFeignClient.downloadResponse(
                    eq("J100"),
                    eq("GIFT_CITY"),
                    any(DownloadDocumentRequest.class)
            )).thenReturn(ResponseEntity.ok("IMG".getBytes()));

            ApiResponseStatus failStatus = new ApiResponseStatus();
            failStatus.setCode("9999");
            failStatus.setMessage("FAIL");

            CreateSignatureResponse failResp =
                    CreateSignatureResponse.builder()
                            .status(failStatus)
                            .data(null)
                            .build();

            when(customerServiceFeignClient.createSignature(any(SignatureRequest.class)))
                    .thenReturn(failResp);

            CustomValidationStatus customErr =
                    CustomValidationStatus.builder()
                            .code("ERR")
                            .message("DOWN")
                            .build();

            dsh.when(() -> DownstreamResponseHandler.handleResponse(
                    eq(failResp),
                    eq("CREATE_SIGNATURE"),
                    eq(false),
                    eq("GIFT_CITY")
            )).thenReturn(customErr);

            HandlerResult<CreateSignatureResponse> result = handler.handle(ctx);

            // ---------- Assertions ----------
            assertFalse(result.isSuccess());
            assertEquals("ERR", result.getApiResponseStatus().getCode());
            assertEquals("DOWN", result.getApiResponseStatus().getMessage());

            // FAILURE → result.getResult() IS PRESERVED
            assertNotNull(result.getResult());
            assertEquals("9999", result.getResult().getStatus().getCode());
        }
    }

    // ---------------------------------------------------------------
    // EXCEPTION CASE — handleResponse(null)
    // ---------------------------------------------------------------

    @Test
    void handle_exceptionThrown() {

        when(journeyService.fetchJourney("J100")).thenReturn(journeyData);

        try (
                MockedStatic<JourneyService> jsvc = mockStatic(JourneyService.class);
                MockedStatic<DownstreamResponseHandler> dsh = mockStatic(DownstreamResponseHandler.class)
        ) {

            jsvc.when(() -> JourneyService.extractFromJourney(
                    any(), any(), any(), any()
            )).thenThrow(new RuntimeException("Boom"));

            CustomValidationStatus customErr =
                    CustomValidationStatus.builder()
                            .code("EX")
                            .message("EXC")
                            .build();

            dsh.when(() -> DownstreamResponseHandler.handleResponse(
                    eq(null),
                    eq("CREATE_SIGNATURE"),
                    eq(false),
                    eq("GIFT_CITY")
            )).thenReturn(customErr);

            HandlerResult<CreateSignatureResponse> result = handler.handle(ctx);

            // ---------- Assertions ----------
            assertFalse(result.isSuccess());
            assertEquals("EX", result.getApiResponseStatus().getCode());
            assertEquals("EXC", result.getApiResponseStatus().getMessage());
            assertNull(result.getResult(), "result must be null in exception flow");
        }
    }

    // ---------------------------------------------------------------
    // ENUM COVERAGE
    // ---------------------------------------------------------------

    @Test
    void enumCoverage() {
        assertEquals(Handler.HandlerType.CUSTOMER_POST_SUBMIT, handler.getType());
        assertEquals(Handler.HandlerName.CREATE_SIGNATURE, handler.getName());
        assertEquals(CommonJourneyStates.CREATE_FCC_CUSTOMER_SIGNATURE_SUCCESS, handler.successState());
        assertEquals(CommonJourneyStates.CREATE_FCC_CUSTOMER_SIGNATURE_FAILURE, handler.failureState());
    }
}