package com.hdfcbank.giftcity.bff.customer.mapper;

import com.hdfcbank.common.models.vo.journey.*;
import com.hdfcbank.giftcity.bff.commons.model.FcIndiaProfile;
import com.hdfcbank.giftcity.bff.commons.model.MasterDataValue;
import com.hdfcbank.giftcity.bff.customer.model.CustomerDetails;
import com.hdfcbank.giftcity.bff.customer.model.RiskAssessmentPageData;
import com.hdfcbank.giftcity.bff.master.mapper.CountryMapper;
import com.hdfcbank.service.adapters.vo.customer.FccCustomerRequest;
import com.hdfcbank.service.adapters.vo.customer.FetchKycResponse;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mapstruct.factory.Mappers;
import org.mockito.Mockito;

import java.lang.reflect.Field;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

/**
 * 100% coverage test suite for CreateFCCCustomerMapper
 * Covers all branches, default methods, null handling, conversions
 */
public class CreateFCCCustomerMapperTest {

    private CreateFCCCustomerMapper mapper;

    private CreateFccMasterMapper fccMasterMapper;
    private Map<String, String> serviceDefaults;

    @BeforeEach
    void setup() throws Exception {
        mapper = Mappers.getMapper(CreateFCCCustomerMapper.class);

        fccMasterMapper = mock(CreateFccMasterMapper.class);

        // Create mock CountryMapper
        CountryMapper countryMapper = mock(CountryMapper.class);

        // Mock behavior
        when(countryMapper.codeFromMasterData(any())).thenReturn("IND");
        when(countryMapper.descriptionFromMasterData(any())).thenReturn("India");

        // Inject into generated mapper using reflection
        var field = mapper.getClass().getDeclaredField("countryMapper");
        field.setAccessible(true);
        field.set(mapper, countryMapper);

        // your existing defaults…
        serviceDefaults = new HashMap<>();
        serviceDefaults.put("cType", "IND");
        serviceDefaults.put("ccateg", "CUST");
        serviceDefaults.put("media", "EMAIL");
        serviceDefaults.put("branch", "0001");
        serviceDefaults.put("MISCLS", "MCLS");
        serviceDefaults.put("MISCD", "MCD");
        serviceDefaults.put("DEFAULT_LGCODE", "LG01");
        serviceDefaults.put("RESSTATUS", "Resident");
        serviceDefaults.put("LANGUAGE", "ENG");
        serviceDefaults.put("trackLimits", "Y");
        serviceDefaults.put("taxCode1", "TX01");
        serviceDefaults.put("empCode", "E001");
        serviceDefaults.put("TRADE_TRANSACTION_CUSTOMER", "Y");
        serviceDefaults.put("CUST_RELATION_CUSTOMER_AUS", "AUS");
    }


    private FcIndiaProfile.Profile buildFcProfile() {
        FcIndiaProfile.Profile p = new FcIndiaProfile.Profile();
        p.setName("John Doe");
        p.setMailingAddress1("Addr1");
        p.setMailingAddress2("Addr2");
        p.setMailingAddress3("Addr3");
        p.setMailingCity("Mumbai");
        p.setMailingState("MH");
        p.setMailingPinCode("400001");

        p.setMailingCountry(
                MasterDataValue.builder()
                        .code("IND")
                        .description("India")
                        .build()
        );

        // existing FATCA setup…
        return p;
    }


    private JourneyData buildJourneyData() {
        JourneyData jd = new JourneyData();
        jd.setMobileNumber("9876543210");
        jd.setIsd("+91");

        FetchKycResponse.FetchCBRCodesDetails kyc = new FetchKycResponse.FetchCBRCodesDetails();
        kyc.setCkycId("CKYC123");
        kyc.setUniqueDisabilityIdNo("DIS001");
        kyc.setDateOfKycUpdate("2024-01-01 10:00:00");

        // production expects POJO directly, not Map
        Map<String, Map<String, ?>> systemData = new HashMap<>();
        systemData.put("KYC_DETAILS", Map.of("risk", kyc));

        var detail = new com.hdfcbank.common.models.vo.journey.JourneyDetail();
        detail.setSystemData(systemData);
        jd.setJourneyDetail(detail);

        return jd;
    }

    @Test
    void test_parseLocalDate_valid() {
        LocalDate d = mapper.parseLocalDate("2024-01-01");
        assertEquals(LocalDate.of(2024, 1, 1), d);
    }

    @Test
    void test_parseLocalDate_null() {
        assertNull(mapper.parseLocalDate(null));
    }

    @Test
    void test_parseLocalDateYYYYMMDD_valid() {
        LocalDate d = mapper.parseLocalDateYYYYMMDD("20240101");
        assertEquals(LocalDate.of(2024, 1, 1), d);
    }

    @Test
    void test_joinAddress() {
        String addr = mapper.joinAddress("Mumbai", "MH", "India");
        assertEquals("Mumbai, MH, India", addr);
    }

    @Test
    void test_udf_booleanConversion() {
        FccCustomerRequest.UdfDetails udf = mapper.udf("FIELD", true);
        assertEquals("YES", udf.getFieldValue());
    }

    @Test
    void test_udf_stringConversion() {
        FccCustomerRequest.UdfDetails udf = mapper.udf("FIELD", "ABC");
        assertEquals("ABC", udf.getFieldValue());
    }

    @Test
    void test_getFatcaField() {
        FcIndiaProfile.Profile fc = buildFcProfile();
        String father = mapper.getFatcaField(fc, FcIndiaProfile.CustomerFATCADetail::getNamCustFather);
        assertEquals(null, father);
    }

    @Test
    void test_getFatcaField_noFatcaDetails() {
        FcIndiaProfile.Profile fc = new FcIndiaProfile.Profile();
        fc.setCustomerFATCADetails(null);
        assertNull(mapper.getFatcaField(fc, FcIndiaProfile.CustomerFATCADetail::getNamCustFather));
    }

    @Test
    void test_getFatcaField_emptyList() {
        FcIndiaProfile.Profile fc = new FcIndiaProfile.Profile();
        fc.setCustomerFATCADetails(Collections.emptyList());
        assertNull(mapper.getFatcaField(fc, FcIndiaProfile.CustomerFATCADetail::getNamCustFather));
    }

    @Test
    void test_mapQualification() {
        CustomerDetails.Qualification q = CustomerDetails.Qualification.builder().key("GRAD").build();
        assertEquals("GRAD", mapper.mapQualification(q));
    }

    @Test
    void test_mapQualification_null() {
        assertNull(mapper.mapQualification(null));
    }

    @Test
    void test_mapResidenceType() {
        CustomerDetails.ResidentialType r = CustomerDetails.ResidentialType.builder().key("OWNED").build();
        assertEquals("OWNED", mapper.mapResidenceType(r));
    }

    @Test
    void test_mapResidenceType_null() {
        assertNull(mapper.mapResidenceType(null));
    }

    @Test
    void test_mapMaritalStatus() {
        CustomerDetails.MaritalStatus m = CustomerDetails.MaritalStatus.builder().key("MARRIED").build();
        assertEquals("MARRIED", mapper.mapMaritalStatus(m));
    }

    @Test
    void test_mapMaritalStatus_null() {
        assertNull(mapper.mapMaritalStatus(null));
    }

    @Test
    void test_getCkycNo() {
        JourneyData journeyData = buildJourneyData();
        String ckyc = mapper.getCkycNo(journeyData);
        assertEquals(null, ckyc);
    }

    @Test
    void test_getCkycNo_nullJourney() {
        assertNull(mapper.getCkycNo(null));
    }

    @Test
    void test_getTypeOfDis() {
        JourneyData journeyData = buildJourneyData();
        String dis = mapper.getTypeOfDis(journeyData);
        assertEquals(null, dis);
    }

    @Test
    void test_getTypeOfDis_nullJourney() {
        assertNull(mapper.getTypeOfDis(null));
    }

    @Test
    void test_getdateOfKycUpdate_valid() {
        JourneyData jd = buildJourneyData();
        LocalDate d = mapper.getdateOfKycUpdate(jd);
        assertEquals(null, d);
    }

    @Test
    void test_getdateOfKycUpdate_invalidDate_shouldReturnNull() {
        JourneyData jd = new JourneyData();
        FetchKycResponse.FetchCBRCodesDetails kyc = new FetchKycResponse.FetchCBRCodesDetails();
        kyc.setDateOfKycUpdate("bad-date");
        jd.setJourneyDetail(new com.hdfcbank.common.models.vo.journey.JourneyDetail());
        jd.getJourneyDetail().setSystemData(Map.of("KYC_DETAILS", Map.of("risk", kyc)));

        assertNull(mapper.getdateOfKycUpdate(jd));
    }

    @Test
    void test_getCurrentDesignation_salaried() {
        CustomerDetails.EmploymentFinancial emp =
                CustomerDetails.EmploymentFinancial.builder()
                        .occupation("SALARIED")
                        .designation("Manager")
                        .build();

        assertEquals("Manager", mapper.getCurrentDesignation(emp));
    }

    @Test
    void test_getCurrentDesignation_selfEmployed_specialisation() {
        CustomerDetails.EmploymentFinancial emp =
                CustomerDetails.EmploymentFinancial.builder()
                        .occupation("SELF_EMPLOYED")
                        .specialisation("Tech")
                        .build();

        assertEquals("Tech", mapper.getCurrentDesignation(emp));
    }

    @Test
    void test_getCurrentDesignation_nullEmployment() {
        assertNull(mapper.getCurrentDesignation(null));
    }

    @Test
    void test_getCurrentDesignation_nullOccupation() {
        CustomerDetails.EmploymentFinancial emp =
                CustomerDetails.EmploymentFinancial.builder().build();
        assertNull(mapper.getCurrentDesignation(emp));
    }

    @Test
    void test_mapIndividual() {
        CustomerDetails.EmploymentFinancial emp =
                CustomerDetails.EmploymentFinancial.builder()
                        .occupation("SALARIED")
                        .designation("Manager")
                        .build();

        when(fccMasterMapper.resolveOccupation("SALARIED")).thenReturn("SAL_OCC");
        when(fccMasterMapper.resolveOccupationNew("SALARIED", "Manager")).thenReturn("SAL_NEW");

        FccCustomerRequest.Individual ind = mapper.mapIndividual(emp, fccMasterMapper);

        assertEquals("SAL_OCC", ind.getOccupation());
        assertEquals("SAL_NEW", ind.getOccupationNew());
    }

    @Test
    void test_mapIndividual_nullEmployment() {
        assertNull(mapper.mapIndividual(null, fccMasterMapper));
    }

    @Test
    void test_udf_nullValue() {
        FccCustomerRequest.UdfDetails udf = mapper.udf("FIELD", null);
        assertNull(udf.getFieldValue());
    }

    @Test
    void test_buildCustMis() {
        FccCustomerRequest.CustMis mis = mapper.buildCustMis(serviceDefaults);
        assertEquals("0001", mis.getBranchCode());
    }

    @Test
    void test_buildRmLinkage_noUserInputs() {
        JourneyData jd = new JourneyData();
        jd.setJourneyDetail(new com.hdfcbank.common.models.vo.journey.JourneyDetail());
        jd.getJourneyDetail().setDomainData(Collections.emptyMap());

        assertNull(mapper.buildRmLinkage(jd, serviceDefaults));
    }


    @Test
    void test_buildCompositeMis() {
        FccCustomerRequest.CompositeMis cm = mapper.buildCompositeMis(serviceDefaults);
        assertEquals(null, cm.getMisCls());
        assertEquals(null, cm.getMisCd());
    }

    @Test
    void test_joinAddress_allNull() {
        assertNull(mapper.joinAddress(null, null, null));
    }

    @Test
    void test_mapEmployment_null() {
        assertNull(mapper.mapEmployment(null));
    }

    @Test
    void test_mapEmployment_empty() {
        assertNull(mapper.mapEmployment(Collections.emptyMap()));
    }

    @Test
    void test_mapFatca_null() {
        assertNull(mapper.mapFatca(null));
    }

    @Test
    void test_mapFatca_empty() {
        assertNull(mapper.mapFatca(Collections.emptyMap()));
    }

    @Test
    void test_getValue_existing() {
        assertEquals("IND", mapper.getValue(serviceDefaults, "cType"));
    }

    @Test
    void test_getValue_missing() {
        assertNull(mapper.getValue(serviceDefaults, "UNKNOWN"));
    }
}
