package com.hdfcbank.giftcity.bff.application.handlers.background;

import com.hdfcbank.adapters.clients.feign.document.DocumentFeignClient;
import com.hdfcbank.adapters.vo.DocumentUploadedResponse;
import com.hdfcbank.adapters.vo.GenerateDocumentRequest;
import com.hdfcbank.common.models.vo.core.ApiResponse;
import com.hdfcbank.common.models.vo.core.ApiResponseStatus;
import com.hdfcbank.common.models.vo.journey.JourneyData;
import com.hdfcbank.common.models.vo.journey.JourneyDetail;
import com.hdfcbank.common.models.vo.journey.JourneyState;
import com.hdfcbank.giftcity.bff.commons.config.JourneyConfigProperties;
import com.hdfcbank.giftcity.bff.commons.enums.CommonJourneyStates;
import com.hdfcbank.giftcity.bff.commons.exception.handler.DownstreamResponseHandler;
import com.hdfcbank.giftcity.bff.commons.handler.Handler;
import com.hdfcbank.giftcity.bff.commons.handler.HandlerContext;
import com.hdfcbank.giftcity.bff.commons.handler.HandlerResult;
import com.hdfcbank.giftcity.bff.commons.model.FtsDetails;
import com.hdfcbank.giftcity.bff.customer.config.CustomerApiProperties;
import com.hdfcbank.giftcity.bff.customer.mapper.AofDocumentMapper;
import com.hdfcbank.giftcity.bff.customer.model.AofWithAnnextureData;
import com.hdfcbank.giftcity.bff.infrastructure.service.JourneyService;

import org.junit.jupiter.api.*;
import org.mockito.*;

import java.lang.reflect.Field;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import static com.hdfcbank.giftcity.bff.commons.enums.CommonJourneyStates.*;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import ch.qos.logback.classic.Logger;
import ch.qos.logback.classic.Level;
import org.slf4j.LoggerFactory;

class AofWithAnnextureUploadHandlerTest {

    /**         Mute ALL logs from handler so tests run silently */
    @BeforeAll
    static void muteLogs() {
        Logger logger =
                (Logger) LoggerFactory.getLogger(AofWithAnnextureUploadHandler.class);
        logger.setLevel(Level.OFF);
    }

    @Mock private DocumentFeignClient documentFeignClient;
    @Mock private AofDocumentMapper mapper;
    @Mock private JourneyService journeyService;
    @Mock private CustomerApiProperties customerApiProperties;
    @Mock private CustomerApiProperties.AOFDetails aofDetails;

    @InjectMocks
    private AofWithAnnextureUploadHandler handler;

    private HandlerContext context;
    private JourneyData journeyData;

    @BeforeEach
    void init() throws Exception {
        MockitoAnnotations.openMocks(this);

        journeyData = new JourneyData();
        journeyData.setJourneyId("JX001");
        journeyData.setJourneyName("FTS Journey");

        JourneyState js = new JourneyState();
        js.setStateName(CUSTOMER_ACCOUNT_STATEMENTS_FETCH_SUCCESS.name());

        JourneyDetail detail = new JourneyDetail();
        detail.setJourneyStates(List.of(js));
        journeyData.setJourneyDetail(detail);

        context = HandlerContext.builder().journeyData(journeyData).build();

        when(customerApiProperties.getAofDetails()).thenReturn(aofDetails);
        when(aofDetails.getBranchName()).thenReturn("BR001");
        when(aofDetails.getBranchCode()).thenReturn("BC001");
        when(aofDetails.getProductCode()).thenReturn("PC999");

        //         Fix static DownstreamResponseHandler to avoid NPE
        JourneyConfigProperties mockConfig = mock(JourneyConfigProperties.class);
        when(mockConfig.getJourneys()).thenReturn(Map.of());
        Field f = DownstreamResponseHandler.class.getDeclaredField("journeyConfigProperties");
        f.setAccessible(true);
        f.set(null, mockConfig);
    }

    @Test
    void testPreConditionsFalse() {
        JourneyData jd = new JourneyData();
        JourneyDetail dd = new JourneyDetail();
        dd.setJourneyStates(List.of());
        jd.setJourneyDetail(dd);

        HandlerContext ctx = HandlerContext.builder().journeyData(jd).build();
        assertFalse(handler.preConditions(ctx));
    }

            
    @Test
    void testSuccessFlow() {

        GenerateDocumentRequest<AofWithAnnextureData> req = new GenerateDocumentRequest<>();
        when(mapper.toRequestWithCra(any(), any(), any(), any())).thenReturn(req);

        DocumentUploadedResponse doc = new DocumentUploadedResponse();
        doc.setDocRef("DOC-123");

        ApiResponseStatus status = new ApiResponseStatus();
        status.setCode("0000");

        ApiResponse<DocumentUploadedResponse> resp =
                new ApiResponse<>(status, doc);

        when(documentFeignClient.fetchGenerateAndUploadResponse(
                eq("JX001"), eq("FTS Journey"), eq(req)
        )).thenReturn(resp);

        try (MockedStatic<JourneyService> mocked = mockStatic(JourneyService.class)) {

            mocked.when(() ->
                    JourneyService.extractFromJourney(any(), anyString(), any(), any())
            ).thenReturn(Optional.of(new FtsDetails()));

            HandlerResult<DocumentUploadedResponse> result = handler.handle(context);

            assertTrue(result.isSuccess());
            assertEquals("DOC-123", result.getResult().getDocRef());

            verify(journeyService).updateJourney(
                    eq("JX001"),
                    eq("FtsDetails"),
                    any(FtsDetails.class),
                    eq(AOF_WITH_ANNEXTURE_UPLOAD_SUCCESS)
            );
        }
    }

            
    @Test
    void testFailureFlow() {

        GenerateDocumentRequest<AofWithAnnextureData> req = new GenerateDocumentRequest<>();
        when(mapper.toRequestWithCra(any(), any(), any(), any())).thenReturn(req);

        ApiResponseStatus status = new ApiResponseStatus();
        status.setCode("9999");

        ApiResponse<DocumentUploadedResponse> resp =
                new ApiResponse<>(status, new DocumentUploadedResponse());

        when(documentFeignClient.fetchGenerateAndUploadResponse(
                eq("JX001"), eq("FTS Journey"), eq(req)
        )).thenReturn(resp);

        HandlerResult<DocumentUploadedResponse> result = handler.handle(context);

        assertFalse(result.isSuccess());
        assertNotNull(result.getResult());
        assertNull(result.getResult().getDocRef());

        verify(journeyService, never()).updateJourney(any(), any(), any(), any());
    }

            
    @Test
    void testFailureWhenStatusNull() {

        GenerateDocumentRequest<AofWithAnnextureData> req = new GenerateDocumentRequest<>();
        when(mapper.toRequestWithCra(any(), any(), any(), any())).thenReturn(req);

        ApiResponse<DocumentUploadedResponse> resp =
                new ApiResponse<>(null, new DocumentUploadedResponse());

        when(documentFeignClient.fetchGenerateAndUploadResponse(
                eq("JX001"), eq("FTS Journey"), eq(req)
        )).thenReturn(resp);

        HandlerResult<DocumentUploadedResponse> result = handler.handle(context);

        assertFalse(result.isSuccess());
        assertNull(result.getResult());
        verify(journeyService, never()).updateJourney(any(), any(), any(), any());
    }

            
    @Test
    void testExceptionFlow() {

        GenerateDocumentRequest<AofWithAnnextureData> req = new GenerateDocumentRequest<>();
        when(mapper.toRequestWithCra(any(), any(), any(), any())).thenReturn(req);

        when(documentFeignClient.fetchGenerateAndUploadResponse(anyString(), anyString(), any()))
                .thenThrow(new RuntimeException("Feign error"));

        HandlerResult<DocumentUploadedResponse> result = handler.handle(context);

        assertFalse(result.isSuccess());
        assertNull(result.getResult());
        verify(journeyService, never()).updateJourney(any(), any(), any(), any());
    }

            
    @Test
    void testHandleWhenAofDetailsNull() {

        when(customerApiProperties.getAofDetails()).thenReturn(null);

        GenerateDocumentRequest<AofWithAnnextureData> req = new GenerateDocumentRequest<>();
        when(mapper.toRequestWithCra(any(), any(), any(), any())).thenReturn(req);

        HandlerResult<DocumentUploadedResponse> result = handler.handle(context);

        assertFalse(result.isSuccess());
        assertNull(result.getResult());
        verify(journeyService, never()).updateJourney(any(), any(), any(), any());
    }

            
    @Test
    void testMetadataMethods() {
        assertEquals(
                Handler.HandlerType.BACKGROUND_TASKS_POST_SUBMIT_SUCCESS,
                handler.getType()
        );
        assertEquals(
                Handler.HandlerName.AOF_WITH_ANNEXTURE_UPLOAD,
                handler.getName()
        );
        assertEquals(
                AOF_WITH_ANNEXTURE_UPLOAD_SUCCESS,
                handler.successState()
        );
        assertEquals(
                AOF_WITH_ANNEXTURE_UPLOAD_FAILURE,
                handler.failureState()
        );
    }
}