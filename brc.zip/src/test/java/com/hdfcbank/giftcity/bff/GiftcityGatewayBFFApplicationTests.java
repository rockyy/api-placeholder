package com.hdfcbank.giftcity.bff;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.core.io.ClassPathResource;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HexFormat;
import java.util.List;
//@ExtendWith(MockitoExtension.class)
class GiftcityGatewayBFFApplicationTests {

	@Test
	void contextLoads() {
        // Method intentionally left empty: verifies that the Spring context loads successfully
	}
    private static String key = "98345678901234567890123456789012";
    private static final byte[] IV = new byte[16]; // all zeros

    public static String encrypt(String plainText) throws Exception {

        Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");

        SecretKeySpec keySpec =
                new SecretKeySpec(key.getBytes(StandardCharsets.UTF_8), "AES");

        cipher.init(
                Cipher.ENCRYPT_MODE,
                keySpec,
                new IvParameterSpec(IV)
        );

        byte[] encrypted =
                cipher.doFinal(plainText.getBytes(StandardCharsets.UTF_8));

        return HexFormat.of()
                .formatHex(encrypted)
                .toUpperCase();
    }

    public static String decrypt(String encryptedHex) throws Exception {

        Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");

        SecretKeySpec keySpec =
                new SecretKeySpec(key.getBytes(StandardCharsets.UTF_8), "AES");

        cipher.init(
                Cipher.DECRYPT_MODE,
                keySpec,
                new IvParameterSpec(IV)
        );

        byte[] decrypted =
                cipher.doFinal(
                        HexFormat.of().parseHex(encryptedHex)
                );

        return new String(decrypted, StandardCharsets.UTF_8);
    }

    @Test
    public void testEncrypt() throws Exception {

        String encrypted = encrypt("kvgogo");
        System.out.println("Encrypted:");
        System.out.println(encrypted);
    }


    @Test
    public void testDecrypt() throws Exception {

        String encrypted = "A6D8BBFEC51AB4965A8D0A3B1BBBF165";



        String decrypted = decrypt(encrypted);
        System.out.println("\nDecrypted:");
        System.out.println(decrypted);
    }

    @Test
    public void sanitizePathTraversal() {
        String value = "/user/abc/downloads";
        if (value == null) {
            System.out.println(value);
        }
        System.out.println(Paths.get(value).toAbsolutePath().normalize());
    }

    @Test
    public void accountSortingTest() throws IOException {
        ObjectMapper mapper = new ObjectMapper();

        // Input JSON file should contain an array of account objects
        JsonNode root = mapper.readTree(
                new ClassPathResource("accounts.json").getInputStream());

        List<JsonNode> accounts = new ArrayList<>();
        root.forEach(accounts::add);

        // Sort by availableBalance in descending order
        accounts.sort(
                Comparator.comparing(
                                (JsonNode node) -> node.path("availableBalance").asDouble())
                        .reversed());

        ArrayNode output = mapper.createArrayNode();

        for (JsonNode account : accounts) {

            ObjectNode obj = mapper.createObjectNode();

            obj.set(
                    "availableBalance",
                    mapper.getNodeFactory().numberNode(
                            account.path("availableBalance").decimalValue()
                    )
            );

            obj.put("productType",
                    account.path("productType").asText());

            output.add(obj);
        }

        System.out.println(
                mapper.writerWithDefaultPrettyPrinter()
                        .writeValueAsString(output));

    }

}
