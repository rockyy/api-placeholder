package com.hdfcbank.giftcity.bff.customer.validator;

import com.hdfcbank.common.models.vo.core.ApiResponseStatus;
import com.hdfcbank.common.models.vo.journey.JourneyData;
import com.hdfcbank.giftcity.bff.commons.enums.CommonJourneyStates;
import com.hdfcbank.giftcity.bff.commons.enums.JourneyPageName;
import com.hdfcbank.giftcity.bff.commons.model.FcIndiaProfile;
import com.hdfcbank.giftcity.bff.commons.model.CustomValidationStatus;
import com.hdfcbank.giftcity.bff.commons.properties.CustomValidationProperties;
import com.hdfcbank.giftcity.bff.commons.validation.ValidationResult;
import com.hdfcbank.giftcity.bff.commons.validation.ValidatorContext;
import com.hdfcbank.giftcity.bff.commons.validation.ValidatorType;
import com.hdfcbank.giftcity.bff.customer.constants.CustomerConstants;
import com.hdfcbank.giftcity.bff.customer.mapper.UcicRequestMapper;
import com.hdfcbank.giftcity.bff.infrastructure.service.JourneyService;

import com.hdfcbank.service.adapters.clients.feign.customer.CustomerServiceFeignClient;
import com.hdfcbank.service.adapters.vo.customer.UcicApiResponse;
import com.hdfcbank.service.adapters.vo.customer.UcicApiResponse.UcicSummaryResponse;
import com.hdfcbank.service.adapters.vo.customer.UcicRequest;

import com.hdfcbank.giftcity.bff.commons.exception.handler.DownstreamResponseHandler;

import org.junit.jupiter.api.*;
import org.mockito.MockedStatic;

import java.util.HashMap;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import static com.hdfcbank.giftcity.bff.customer.constants.CustomerConstants.*;

import ch.qos.logback.classic.Level;
import ch.qos.logback.classic.Logger;
import org.slf4j.LoggerFactory;

class UcicValidatorTest {

    //        MUTE ALL ERROR/INFO LOGS FOR CLEAN CONSOLE
    @BeforeAll
    static void muteLogs() {
        Logger root = (Logger) LoggerFactory.getLogger(Logger.ROOT_LOGGER_NAME);
        root.setLevel(Level.OFF);
    }

    private CustomerServiceFeignClient feign;
    private UcicRequestMapper mapper;
    private CustomValidationProperties props;

    private UcicValidator validator;

    @BeforeEach
    void setup() {
        feign = mock(CustomerServiceFeignClient.class);
        mapper = mock(UcicRequestMapper.class);
        props = mock(CustomValidationProperties.class);

        validator = new UcicValidator(feign, mapper, props);
    }

    private JourneyData journey() {
        return JourneyData.builder()
                .journeyId("J123")
                .journeyName("UCIC_FLOW")
                .referenceNo("REF001")
                .build();
    }

    private FcIndiaProfile.Profile sampleProfile() {
        return FcIndiaProfile.Profile.builder()
                .name("TestUser")
                .panNumber("ABCDE1234F")
                .build();
    }

    private UcicApiResponse buildResponse(String code, String ucicId) {
        ApiResponseStatus status = new ApiResponseStatus();
        status.setCode(code);

        UcicSummaryResponse data = UcicSummaryResponse.builder()
                .ucic(ucicId)
                .customerCategory("NORM")
                .customerType("IND")
                .build();

        UcicApiResponse api = new UcicApiResponse();
        api.setStatus(status);
        api.setData(data);
        return api;
    }

    private CustomValidationStatus err(String code) {
        return CustomValidationStatus.builder()
                .code(code)
                .message(code)
                .title(code)
                .build();
    }

    @Test
    void testUcicSuccess() {

        JourneyData jd = journey();
        UcicRequest req = UcicRequest.builder().customerName("TestUser").build();
        UcicApiResponse resp = buildResponse(UCIC_SUCCESS_200, "UCIC123");

        when(mapper.toRequest(any())).thenReturn(req);

        try (MockedStatic<JourneyService> js = mockStatic(JourneyService.class)) {

            js.when(() -> JourneyService.extractFromJourney(
                    eq(jd),
                    eq(JourneyPageName.CUSTOMER_FC_INDIA_DETAIL.getPageName()),
                    eq(FcIndiaProfile.class),
                    any()
            )).thenReturn(Optional.of(sampleProfile()));

            when(feign.customerUcicValidate(eq(req), eq("J123")))
                    .thenReturn(resp);

            ValidatorContext ctx = ValidatorContext.builder()
                    .journeyData(jd)
                    .data(new HashMap<>())
                    .build();

            Optional<ValidationResult> result = validator.validate(ctx);

            assertTrue(result.isPresent());
            assertTrue(result.get().isSuccess());
            assertEquals("UCIC123",
                    ((UcicSummaryResponse) ctx.getData()
                            .get(ValidatorContext.ContextKey.UCIC_DETAILS))
                            .getUcic());
        }
    }

    @Test
    void testUcicFailure() {

        JourneyData jd = journey();
        UcicRequest req = UcicRequest.builder().build();
        UcicApiResponse resp = buildResponse("999", null);

        when(mapper.toRequest(any())).thenReturn(req);

        try (MockedStatic<JourneyService> js = mockStatic(JourneyService.class);
             MockedStatic<DownstreamResponseHandler> dh = mockStatic(DownstreamResponseHandler.class)) {

            js.when(() -> JourneyService.extractFromJourney(any(), any(), any(), any()))
                    .thenReturn(Optional.of(sampleProfile()));

            when(feign.customerUcicValidate(eq(req), eq("J123")))
                    .thenReturn(resp);

            dh.when(() -> DownstreamResponseHandler.handleResponse(
                    any(),
                    anyString(),
                    any(),
                    anyString()
            )).thenReturn(err("UCIC_ERROR"));

            ValidatorContext ctx = ValidatorContext.builder().journeyData(jd).build();
            ValidationResult vr = validator.validate(ctx).get();

            assertFalse(vr.isSuccess());
            assertEquals("UCIC_ERROR", vr.getApiResponseStatus().getCode());
        }
    }

    @Test
    void testUcicException() {

        JourneyData jd = journey();
        UcicRequest req = UcicRequest.builder().build();

        when(mapper.toRequest(any())).thenReturn(req);

        try (MockedStatic<JourneyService> js = mockStatic(JourneyService.class);
             MockedStatic<DownstreamResponseHandler> dh = mockStatic(DownstreamResponseHandler.class)) {

            js.when(() -> JourneyService.extractFromJourney(any(), any(), any(), any()))
                    .thenReturn(Optional.of(sampleProfile()));

            when(feign.customerUcicValidate(eq(req), eq("J123")))
                    .thenThrow(new RuntimeException("FAIL"));

            dh.when(() -> DownstreamResponseHandler.handleResponse(
                    any(),
                    anyString(),
                    any(),
                    anyString()
            )).thenReturn(err("ERR_500"));

            ValidatorContext ctx = ValidatorContext.builder().journeyData(jd).build();
            ValidationResult vr = validator.validate(ctx).get();

            assertFalse(vr.isSuccess());
            assertEquals("ERR_500", vr.getApiResponseStatus().getCode());
        }
    }

    @Test
    void testMetaMethods() {
        assertEquals(ValidatorType.POST_CUSTOMER_VALIDATION, validator.type());
        assertEquals(CustomerConstants.POST_UCIC_VALIDATOR, validator.name());
        assertEquals(CommonJourneyStates.UCIC_ELIGIBLE_SUCCESS, validator.successState());
        assertEquals(CommonJourneyStates.UCIC_ELIGIBLE_FAILURE, validator.failureState());
        assertFalse(validator.isMandatory());
    }
}