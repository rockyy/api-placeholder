package com.hdfcbank.giftcity.bff.customer.mapper;

import com.hdfcbank.common.models.vo.journey.JourneyData;
import com.hdfcbank.giftcity.bff.commons.model.FcIndiaProfile;
import com.hdfcbank.giftcity.bff.commons.model.MasterDataValue;
import com.hdfcbank.giftcity.bff.customer.constants.CustomerConstants;
import com.hdfcbank.giftcity.bff.customer.mapper.CustomerRiskAnalysisMapper;
import com.hdfcbank.giftcity.bff.customer.utility.CustomerUtil;
import com.hdfcbank.service.adapters.vo.customer.CustomerRiskAnalysisRequest;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mapstruct.factory.Mappers;
import org.mockito.MockedStatic;
import org.mockito.Mockito;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;

class CustomerRiskAnalysisMapperTest {

    private CustomerRiskAnalysisMapper mapper;

    @BeforeEach
    void setup() {
        mapper = Mappers.getMapper(CustomerRiskAnalysisMapper.class);
    }

    private JourneyData buildJourneyData() {
        JourneyData jd = new JourneyData();
        jd.setJourneyDetail(new com.hdfcbank.common.models.vo.journey.JourneyDetail());
        return jd;
    }

    // Test: Full mapping (all values returned by CustomerUtil)
    @Test
    void test_toCustomerDetails_fullMapping() {

        JourneyData jd = buildJourneyData();

        FcIndiaProfile.Profile profile = new FcIndiaProfile.Profile();
        profile.setKycType("KYC123");

        MasterDataValue mailingCountry = MasterDataValue.builder()
                .code("IN")
                .description("India")
                .build();

        profile.setMailingCountry(mailingCountry);

        try (MockedStatic<CustomerUtil> util = Mockito.mockStatic(CustomerUtil.class)) {

            util.when(() -> CustomerUtil.getValueByPath(
                            jd, CustomerConstants.CUSTOMER_DETAILS, CustomerConstants.EMPLOYMENT_OCCUPATION_PATH))
                    .thenReturn("SALARIED");

            util.when(() -> CustomerUtil.getValueByPath(
                            jd, CustomerConstants.CUSTOMER_DETAILS, CustomerConstants.EMPLOYMENT_INDUSTRY_PATH))
                    .thenReturn("BANKING");

            util.when(() -> CustomerUtil.getValueByPath(
                            jd, CustomerConstants.CUSTOMER_DETAILS, CustomerConstants.EMPLOYMENT_SOURCE_OF_INCOME_PATH))
                    .thenReturn("WORK");

            util.when(() -> CustomerUtil.getValueByPath(
                            jd, CustomerConstants.CUSTOMER_DETAILS, CustomerConstants.EMPLOYMENT_MONTHLY_AMOUNT_PATH))
                    .thenReturn("5000");

            util.when(() -> CustomerUtil.getValueByPath(
                            jd, CustomerConstants.CUSTOMER_DETAILS, CustomerConstants.EMPLOYMENT_PEP_PATH))
                    .thenReturn("NO");

            util.when(() -> CustomerUtil.getPrimaryProfile(jd))
                    .thenReturn(Optional.of(profile));

            util.when(() -> CustomerUtil.convertToDouble("5000"))
                    .thenReturn(5000.0);

            CustomerRiskAnalysisRequest.CustomerDetails cust =
                    mapper.toCustomerDetails(jd);

            assertNotNull(cust);
            assertEquals("SALARIED", cust.getOccupation());
            assertEquals("BANKING", cust.getIndustry());
            assertEquals("WORK", cust.getSourceOfIncome());
            assertEquals("KYC123", cust.getKycType());
            assertEquals("IN", cust.getMailingCountry());
            assertEquals(5000.0, cust.getAnnualTransactionAmountUsd());
            assertEquals("NO", cust.getPep());
        }
    }

    // Test: All null values returned → everything in CustomerDetails is null
    @Test
    void test_toCustomerDetails_allNulls() {

        JourneyData jd = buildJourneyData();

        try (MockedStatic<CustomerUtil> util = Mockito.mockStatic(CustomerUtil.class)) {

            util.when(() -> CustomerUtil.getValueByPath(Mockito.any(), Mockito.anyString(), Mockito.anyString()))
                    .thenReturn(null);

            util.when(() -> CustomerUtil.getPrimaryProfile(jd))
                    .thenReturn(Optional.empty());

            util.when(() -> CustomerUtil.convertToDouble(null))
                    .thenReturn(null);

            CustomerRiskAnalysisRequest.CustomerDetails cust =
                    mapper.toCustomerDetails(jd);

            assertNotNull(cust);
            assertNull(cust.getOccupation());
            assertNull(cust.getIndustry());
            assertNull(cust.getSourceOfIncome());
            assertNull(cust.getKycType());
            assertNull(cust.getMailingCountry());
            assertNull(cust.getAnnualTransactionAmountUsd());
            assertNull(cust.getPep());
        }
    }

    // Test: toRequest() wrapper method (calls toCustomerDetails internally)
    @Test
    void test_toRequest_success() {

        JourneyData jd = buildJourneyData();

        try (MockedStatic<CustomerUtil> util = Mockito.mockStatic(CustomerUtil.class)) {

            util.when(() -> CustomerUtil.getValueByPath(Mockito.any(), Mockito.anyString(), Mockito.anyString()))
                    .thenReturn("X");

            util.when(() -> CustomerUtil.getPrimaryProfile(jd))
                    .thenReturn(Optional.empty());

            util.when(() -> CustomerUtil.convertToDouble("X"))
                    .thenReturn(10.0);

            CustomerRiskAnalysisRequest req = mapper.toRequest(jd);

            assertNotNull(req);
            assertNotNull(req.getCustomerDetails());

            CustomerRiskAnalysisRequest.CustomerDetails cust = req.getCustomerDetails();

            assertEquals("X", cust.getOccupation());
            assertEquals("X", cust.getIndustry());
            assertEquals("X", cust.getSourceOfIncome());
            assertEquals(10.0, cust.getAnnualTransactionAmountUsd());
        }
    }
}
