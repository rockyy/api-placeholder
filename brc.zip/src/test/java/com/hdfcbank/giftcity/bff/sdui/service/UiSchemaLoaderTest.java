package com.hdfcbank.giftcity.bff.sdui.service;

import tools.jackson.databind.ObjectMapper;
import tools.jackson.databind.JsonNode;

import com.mongodb.client.MongoCollection;
import com.mongodb.client.result.DeleteResult;

import org.bson.Document;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import org.mockito.MockedConstruction;
import org.mockito.ArgumentCaptor;
import org.springframework.boot.ApplicationArguments;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.data.mongodb.core.MongoTemplate;

import java.io.ByteArrayInputStream;

import net.javacrumbs.shedlock.core.LockProvider;
import net.javacrumbs.shedlock.core.SimpleLock;

import java.util.Optional;

import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

class UiSchemaLoaderTest {

    private MongoTemplate mongoTemplate;
    private ObjectMapper objectMapper;
    private LockProvider lockProvider;

    private UiSchemaLoader loader;

    @BeforeEach
    void setup() throws Exception {

        mongoTemplate = mock(MongoTemplate.class);
        objectMapper = new ObjectMapper();
        lockProvider = mock(LockProvider.class);

        // Mock lock so run() proceeds
        SimpleLock simpleLock = mock(SimpleLock.class);
        when(lockProvider.lock(any())).thenReturn(Optional.of(simpleLock));

        loader = new UiSchemaLoader(mongoTemplate, objectMapper, lockProvider);
    }

    private Resource mockResource(String json, String filename) throws Exception {
        Resource resource = mock(Resource.class);
        when(resource.getInputStream()).thenReturn(new ByteArrayInputStream(json.getBytes()));
        when(resource.getFilename()).thenReturn(filename);
        return resource;
    }

    // ============================================================================================
    // TEST 1 — Collection exists → delete docs → insert all JSON files
    // ============================================================================================
    @Test
    @DisplayName("run() → collection exists → delete docs → insert JSON files")
    void testRun_collectionExists() throws Exception {

        when(mongoTemplate.collectionExists("ui_schemas"))
                .thenReturn(true);

        DeleteResult deleteResult = mock(DeleteResult.class);
        when(deleteResult.getDeletedCount()).thenReturn(5L);
        when(mongoTemplate.remove(any(), eq("ui_schemas")))
                .thenReturn(deleteResult);

        Resource r1 = mockResource("{\"a\":1}", "file1.json");
        Resource r2 = mockResource("{\"b\":2}", "file2.json");

        MongoCollection<Document> coll = mock(MongoCollection.class);
        when(mongoTemplate.getCollection("ui_schemas")).thenReturn(coll);

        try (MockedConstruction<PathMatchingResourcePatternResolver> ignore =
                     mockConstruction(
                             PathMatchingResourcePatternResolver.class,
                             (mockResolver, ctx) ->
                                     when(mockResolver.getResources("classpath:sd-ui/*.json"))
                                             .thenReturn(new Resource[]{r1, r2})
                     )) {

            loader.run(mock(ApplicationArguments.class));

            //                Assert collection existence check
            verify(mongoTemplate).collectionExists("ui_schemas");

            //                Assert delete operation invoked
            verify(mongoTemplate).remove(any(), eq("ui_schemas"));

            //                New assertion: validate deleted count
            assert deleteResult.getDeletedCount() == 5L;

            //                Insert should be called for both JSON files
            ArgumentCaptor<Document> inserted = ArgumentCaptor.forClass(Document.class);
            verify(coll, times(2)).insertOne(inserted.capture());
            assertEquals(java.util.List.of(Document.parse("{\"a\":1}"), Document.parse("{\"b\":2}")),
                    inserted.getAllValues());

            //                NEW added assertions
            // ensure filenames match mock setup
            assert r1.getFilename().equals("file1.json");
            assert r2.getFilename().equals("file2.json");

            // JSON parsing validity check
            JsonNode n1 = objectMapper.readTree("{\"a\":1}");
            JsonNode n2 = objectMapper.readTree("{\"b\":2}");
            assert n1.get("a").asInt() == 1;
            assert n2.get("b").asInt() == 2;
        }
    }

    // ============================================================================================
    // TEST 2 — Collection does NOT exist → skip deletion → insert JSON files
    // ============================================================================================
    @Test
    @DisplayName("run() → collection does NOT exist → skip deletion → insert JSON files")
    void testRun_collectionNotExists() throws Exception {

        when(mongoTemplate.collectionExists("ui_schemas"))
                .thenReturn(false);

        Resource r1 = mockResource("{\"x\":10}", "data.json");

        MongoCollection<Document> coll = mock(MongoCollection.class);
        when(mongoTemplate.getCollection("ui_schemas"))
                .thenReturn(coll);

        try (MockedConstruction<PathMatchingResourcePatternResolver> ignore =
                     mockConstruction(
                             PathMatchingResourcePatternResolver.class,
                             (mockResolver, ctx) ->
                                     when(mockResolver.getResources("classpath:sd-ui/*.json"))
                                             .thenReturn(new Resource[]{r1})
                     )) {

            loader.run(mock(ApplicationArguments.class));

            //                Assert existence check
            verify(mongoTemplate).collectionExists("ui_schemas");

            //                Assert NO deletion called
            verify(mongoTemplate, never()).remove(any(), anyString());

            //                Assert insertion executed once
            verify(coll, times(1)).insertOne(any(Document.class));

            //                NEW added assertions
            assert r1.getFilename().equals("data.json");

            // JSON validation
            JsonNode parsed = objectMapper.readTree("{\"x\":10}");
            assert parsed.get("x").asInt() == 10;

            // Ensure mock resource stream is readable
            assert r1.getInputStream() != null;
        }
    }

    @Test
    void run_shouldSkipLoadingWhenStartupLockIsUnavailable() {
        when(lockProvider.lock(any())).thenReturn(Optional.empty());

        assertDoesNotThrow(() -> loader.run(mock(ApplicationArguments.class)));

        verifyNoInteractions(mongoTemplate);
    }

    @Test
    void run_shouldWrapDatabaseFailureWithOriginalCause() {
        IllegalStateException failure = new IllegalStateException("Mongo unavailable");
        when(mongoTemplate.collectionExists("ui_schemas")).thenThrow(failure);

        IllegalStateException exception = assertThrows(IllegalStateException.class,
                () -> loader.run(mock(ApplicationArguments.class)));

        assertEquals("Failed to perform UI schema loading task", exception.getMessage());
        assertSame(failure, exception.getCause());
        verify(mongoTemplate, never()).getCollection(anyString());
    }

    @Test
    void run_shouldNotInsertMalformedSchema() throws Exception {
        when(mongoTemplate.collectionExists("ui_schemas")).thenReturn(false);
        Resource invalid = mockResource("{invalid", "invalid.json");

        try (MockedConstruction<PathMatchingResourcePatternResolver> resolvers = mockConstruction(
                PathMatchingResourcePatternResolver.class,
                (resolver, context) -> when(resolver.getResources("classpath:sd-ui/*.json"))
                        .thenReturn(new Resource[]{invalid}))) {
            IllegalStateException exception = assertThrows(IllegalStateException.class,
                    () -> loader.run(mock(ApplicationArguments.class)));

            assertNotNull(exception.getCause());
            verify(mongoTemplate, never()).getCollection(anyString());
        }
    }
}
