package com.hdfcbank.giftcity.bff.account.controller;

import com.hdfcbank.giftcity.bff.account.model.NomineeResponse;
import com.hdfcbank.giftcity.bff.account.service.AccountService;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.ResponseEntity;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class AccountControllerTest {

    @Mock
    private AccountService accountService;

    @InjectMocks
    private AccountController accountController;

    public AccountControllerTest() {
        MockitoAnnotations.openMocks(this);  // Safe — no try-with-resources needed
    }

    //   TEST 1: SUCCESS CASE — Without using any getters/setters
    @Test
    void testGetNominee_success() {

        // Arrange
        NomineeResponse dummyResponse = new NomineeResponse();
        String journeyId = "JOURNEY-123";

        when(accountService.getNominee(journeyId)).thenReturn(dummyResponse);

        // Act
        ResponseEntity<NomineeResponse> response =
                accountController.getNominee(journeyId);

        // Assert
        assertEquals(200, response.getStatusCode().value(),
                "Controller must return 200 OK");

        assertNotNull(response.getBody(),
                "Controller must not return null for valid service response");

        assertSame(dummyResponse, response.getBody(),
                "Controller must return exactly the same object returned by service");

        verify(accountService, times(1)).getNominee(journeyId);
    }

    //   TEST 2: EXCEPTION CASE — No getters used
    @Test
    void testGetNominee_serviceThrowsException() {

        String journeyId = "JOURNEY-ERROR";
        RuntimeException exception =
                new RuntimeException("Service failed while fetching nominee");

        when(accountService.getNominee(journeyId)).thenThrow(exception);

        RuntimeException thrown = assertThrows(
                RuntimeException.class,
                () -> accountController.getNominee(journeyId),
                "Controller must propagate service exception"
        );

        assertEquals("Service failed while fetching nominee",
                thrown.getMessage(),
                "Error message must match");

        verify(accountService, times(1)).getNominee(journeyId);
    }

    //   TEST 3: NULL RETURN CASE — Safe null assertion
    @Test
    void testGetNominee_serviceReturnsNull() {

        String journeyId = "JOURNEY-NULL";

        when(accountService.getNominee(journeyId)).thenReturn(null);

        ResponseEntity<NomineeResponse> response =
                accountController.getNominee(journeyId);

        assertEquals(200, response.getStatusCode().value(),
                "Controller must return 200 OK even if service returns null");

        assertNull(response.getBody(),
                "Controller must return null body when service returns null");

        verify(accountService, times(1)).getNominee(journeyId);
    }
}