package com.hdfcbank.giftcity.bff.config;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.servers.Server;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class OpenAPIConfigTest {

    private AppProperties appProperties;
    private OpenAPIConfig openAPIConfig;

    @BeforeEach
    void setup() {

        // Mock AppProperties
        appProperties = mock(AppProperties.class);

        when(appProperties.getName()).thenReturn("GiftCity BFF");
        when(appProperties.getVersion()).thenReturn("v2.5.1");
        when(appProperties.getDescription()).thenReturn("GiftCity API Description");
        when(appProperties.getServers())
                .thenReturn(List.of(new Server().url("https://giftcity.hdfcbank.com")));

        // SUT
        openAPIConfig = new OpenAPIConfig();

        // Inject private field via reflection
        ReflectionTestUtils.setField(openAPIConfig, "appProperties", appProperties);
    }

    @Test
    void customOpenAPI_shouldReturnOpenAPIWithCorrectInfoAndServers() {

        OpenAPI openAPI = openAPIConfig.customOpenAPI();
        assertNotNull(openAPI);

        Info info = openAPI.getInfo();
        assertNotNull(info);
        assertEquals("GiftCity BFF", info.getTitle());
        assertEquals("v2.5.1", info.getVersion());
        assertEquals("GiftCity API Description", info.getDescription());

        List<Server> servers = openAPI.getServers();
        assertNotNull(servers);
        assertEquals(1, servers.size());
        assertEquals("https://giftcity.hdfcbank.com", servers.get(0).getUrl());
    }
}