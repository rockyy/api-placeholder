package com.hdfcbank.giftcity.bff.customer.validator;

import com.hdfcbank.giftcity.bff.customer.model.IdentifyCustomerRequest;
import com.hdfcbank.giftcity.bff.customer.model.IdentifierType;
import jakarta.validation.ConstraintValidatorContext;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;

import static com.hdfcbank.giftcity.bff.commons.constant.CommonConstants.*;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class IdentifierValidatorTest {

    private IdentifierValidator validator;
    private ConstraintValidatorContext context;
    private ConstraintValidatorContext.ConstraintViolationBuilder builder;
    private ConstraintValidatorContext.ConstraintViolationBuilder.NodeBuilderCustomizableContext nodeContext;

    @BeforeEach
    void setup() {
        validator = new IdentifierValidator();
        validator.initialize(null);

        context = mock(ConstraintValidatorContext.class);
        builder = mock(ConstraintValidatorContext.ConstraintViolationBuilder.class);
        nodeContext = mock(ConstraintValidatorContext.ConstraintViolationBuilder.NodeBuilderCustomizableContext.class);

        when(context.buildConstraintViolationWithTemplate(anyString())).thenReturn(builder);
        when(builder.addPropertyNode(anyString())).thenReturn(nodeContext);
    }

    private IdentifyCustomerRequest request(String name, String value) {
        IdentifyCustomerRequest req = new IdentifyCustomerRequest();
        req.setIdentifierName(name);
        req.setIdentifierValue(value);
        req.setMobileNo("9876543210");
        req.setIsd("91");
        return req;
    }

    //               DOB VALID
    @Test
    void testDobValid() {
        String validDob = LocalDate.now().format(DATE_TIME_FORMATTER);

        IdentifyCustomerRequest req = request(IdentifierType.DOB.name(), validDob);

        assertNotNull(req);
        assertEquals(IdentifierType.DOB.name(), req.getIdentifierName());
        assertEquals(validDob, req.getIdentifierValue());
        assertEquals("9876543210", req.getMobileNo());
        assertEquals("91", req.getIsd());

        assertTrue(validator.isValid(req, context));

        verify(context, never()).disableDefaultConstraintViolation();
        verify(context, never()).buildConstraintViolationWithTemplate(anyString());
    }

    //               DOB INVALID FORMAT
    @Test
    void testDobInvalid() {
        IdentifyCustomerRequest req = request(IdentifierType.DOB.name(), "2024-99-99");

        assertFalse(validator.isValid(req, context));

        verify(context).disableDefaultConstraintViolation();
        verify(context).buildConstraintViolationWithTemplate(DOB_NOT_VALID);
        verify(builder).addPropertyNode(IDENTIFIER_VALUE);

        assertEquals("2024-99-99", req.getIdentifierValue());
        assertEquals(IdentifierType.DOB.name(), req.getIdentifierName());
        assertNotNull(req.getMobileNo());
    }

    //               DOB NULL
    @Test
    void testDobNull() {
        IdentifyCustomerRequest req = request(IdentifierType.DOB.name(), null);

        assertNull(req.getIdentifierValue());
        assertEquals(IdentifierType.DOB.name(), req.getIdentifierName());

        assertFalse(validator.isValid(req, context));

        verify(context).disableDefaultConstraintViolation();
        verify(context).buildConstraintViolationWithTemplate(DOB_NOT_VALID);
        verify(builder).addPropertyNode(IDENTIFIER_VALUE);
    }

    //               PAN VALID
    @Test
    void testPanValid() {
        IdentifyCustomerRequest req = request(IdentifierType.PAN.name(), "ABCDE1234F");

        assertEquals("ABCDE1234F", req.getIdentifierValue());
        assertEquals(IdentifierType.PAN.name(), req.getIdentifierName());

        assertTrue(validator.isValid(req, context));

        verify(context, never()).disableDefaultConstraintViolation();
        verify(context, never()).buildConstraintViolationWithTemplate(anyString());
    }

    //               PAN INVALID
    @Test
    void testPanInvalid() {
        IdentifyCustomerRequest req = request(IdentifierType.PAN.name(), "INVALIDPAN");

        assertEquals("INVALIDPAN", req.getIdentifierValue());
        assertEquals(IdentifierType.PAN.name(), req.getIdentifierName());

        assertFalse(validator.isValid(req, context));

        verify(context).disableDefaultConstraintViolation();
        verify(context).buildConstraintViolationWithTemplate(PAN_NOT_VALID);
        verify(builder).addPropertyNode(IDENTIFIER_VALUE);
    }

    //               OTHER IDENTIFIER TYPE → ALWAYS TRUE
    @Test
    void testOtherIdentifierTypeReturnsTrue() {

        IdentifyCustomerRequest req = request(IdentifierType.CUSTOMER_ID.name(), "123456789");

        assertEquals("123456789", req.getIdentifierValue());
        assertEquals(IdentifierType.CUSTOMER_ID.name(), req.getIdentifierName());
        assertNotNull(req.getMobileNo());

        assertTrue(validator.isValid(req, context));

        verify(context, never()).disableDefaultConstraintViolation();
        verify(context, never()).buildConstraintViolationWithTemplate(anyString());
    }
}