package com.hdfcbank.giftcity.bff.master.services;

import com.hdfcbank.adapters.clients.feign.master.MasterDataFeignClient;
import com.hdfcbank.adapters.vo.FetchMasterDataRequest;
import com.hdfcbank.common.models.vo.core.PageDetail;
import com.hdfcbank.giftcity.bff.master.mapper.MasterDataMapper;
import com.hdfcbank.giftcity.bff.master.models.MasterDataFetchRequest;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

// Unit tests for MasterDataService.
//
// These tests verify that MasterDataService:
//    Maps the incoming request using MasterDataMapper
//    Passes the mapped request to MasterDataFeignClient
//    Returns the PageDetail received from MasterDataFeignClient
//    Propagates exceptions from its dependencies
//
//    No Spring context, database, cache infrastructure, or actual Feign
//    service is required for these unit tests.

@ExtendWith(MockitoExtension.class)
class MasterDataServiceTest {

    @Mock
    private MasterDataFeignClient masterDataFeignClient;

    @Mock
    private MasterDataMapper masterDataMapper;

    @InjectMocks
    private MasterDataService masterDataService;


    // fetch()

    // It checks that the input request is passed to the mapper, the mapped request is passed to the feignClient, the result from feign is returned by the service, no unexpected interactions happened
    @Test
    void fetch_shouldMapRequestCallFeignClientAndReturnResponse() {

        // Arrange
        MasterDataFetchRequest request =
                MasterDataFetchRequest.builder()
                        .masterName("COUNTRY")
                        .pageNo(0)
                        .pageSize(10)
                        .selectors(List.of("code", "name"))
                        .exactMatch(
                                Map.of("status", "ACTIVE")
                        )
                        .sortBy(List.of("name"))
                        .asc(true)
                        .build();

        FetchMasterDataRequest mappedRequest =
                new FetchMasterDataRequest();

        mappedRequest.setMasterName("COUNTRY");
        mappedRequest.setPageNo(0);
        mappedRequest.setPageSize(10);
        mappedRequest.setSelectors(
                List.of("code", "name")
        );
        mappedRequest.setExactMatch(
                Map.of("status", "ACTIVE")
        );
        mappedRequest.setSortBy(
                List.of("name")
        );
        mappedRequest.setAsc(true);

        PageDetail expectedPageDetail =
                mock(PageDetail.class);

        when(
                masterDataMapper.toFetchMasterDataRequest(request)
        ).thenReturn(mappedRequest);

        doReturn(expectedPageDetail)
                .when(masterDataFeignClient)
                .fetchData(mappedRequest);

        // Act
        PageDetail result =
                masterDataService.fetch(request);

        // Assert
        assertSame(
                expectedPageDetail,
                result
        );

        verify(masterDataMapper)
                .toFetchMasterDataRequest(request);

        verify(masterDataFeignClient)
                .fetchData(mappedRequest);

        verifyNoMoreInteractions(
                masterDataMapper,
                masterDataFeignClient
        );
    }


    // This test focuses specifically on the request transformation and handoff
    @Test
    void fetch_shouldPassMappedRequestToFeignClient() {

        // Arrange
        MasterDataFetchRequest request =
                MasterDataFetchRequest.builder()
                        .masterName("COUNTRY")
                        .pageNo(1)
                        .pageSize(20)
                        .build();

        FetchMasterDataRequest mappedRequest =
                new FetchMasterDataRequest();

        mappedRequest.setMasterName("COUNTRY");
        mappedRequest.setPageNo(1);
        mappedRequest.setPageSize(20);

        PageDetail expectedPageDetail =
                mock(PageDetail.class);

        when(
                masterDataMapper.toFetchMasterDataRequest(request)
        ).thenReturn(mappedRequest);

        doReturn(expectedPageDetail)
                .when(masterDataFeignClient)
                .fetchData(any(FetchMasterDataRequest.class));

        // Act
        PageDetail result =
                masterDataService.fetch(request);

        // Assert
        assertSame(
                expectedPageDetail,
                result
        );

        ArgumentCaptor<FetchMasterDataRequest> captor =
                ArgumentCaptor.forClass(
                        FetchMasterDataRequest.class
                );

        verify(masterDataFeignClient)
                .fetchData(captor.capture());

        FetchMasterDataRequest actualRequest =
                captor.getValue();

        assertSame(
                mappedRequest,
                actualRequest
        );

        assertEquals(
                "COUNTRY",
                actualRequest.getMasterName()
        );

        assertEquals(
                1,
                actualRequest.getPageNo()
        );

        assertEquals(
                20,
                actualRequest.getPageSize()
        );

        verify(masterDataMapper)
                .toFetchMasterDataRequest(request);
    }


    // This test returns value behavior
    @Test
    void fetch_shouldReturnSamePageDetailInstanceFromFeignClient() {

        // Arrange
        MasterDataFetchRequest request =
                MasterDataFetchRequest.builder()
                        .masterName("COUNTRY")
                        .pageNo(0)
                        .pageSize(10)
                        .build();

        FetchMasterDataRequest mappedRequest =
                new FetchMasterDataRequest();

        PageDetail expectedPageDetail =
                mock(PageDetail.class);

        when(
                masterDataMapper.toFetchMasterDataRequest(request)
        ).thenReturn(mappedRequest);

        doReturn(expectedPageDetail)
                .when(masterDataFeignClient)
                .fetchData(mappedRequest);

        // Act
        PageDetail result =
                masterDataService.fetch(request);

        // Assert
        assertNotNull(result);

        assertSame(
                expectedPageDetail,
                result
        );

        verify(masterDataMapper)
                .toFetchMasterDataRequest(request);

        verify(masterDataFeignClient)
                .fetchData(mappedRequest);
    }


    // This tests what happens when the mapper fails
    @Test
    void fetch_shouldPropagateMapperException() {

        // Arrange
        MasterDataFetchRequest request =
                MasterDataFetchRequest.builder()
                        .masterName("COUNTRY")
                        .pageNo(0)
                        .pageSize(10)
                        .build();

        RuntimeException expectedException =
                new RuntimeException(
                        "Unable to map master data request"
                );

        when(
                masterDataMapper.toFetchMasterDataRequest(request)
        ).thenThrow(expectedException);

        // Act
        RuntimeException actualException =
                assertThrows(
                        RuntimeException.class,
                        () -> masterDataService.fetch(request)
                );

        // Assert
        assertSame(
                expectedException,
                actualException
        );

        verify(masterDataMapper)
                .toFetchMasterDataRequest(request);

        verify(
                masterDataFeignClient,
                never()
        ).fetchData(any(FetchMasterDataRequest.class));
    }


    // This is similar to test #4, but this time the downstream service fails
    @Test
    void fetch_shouldPropagateFeignClientException() {

        // Arrange
        MasterDataFetchRequest request =
                MasterDataFetchRequest.builder()
                        .masterName("COUNTRY")
                        .pageNo(0)
                        .pageSize(10)
                        .build();

        FetchMasterDataRequest mappedRequest =
                new FetchMasterDataRequest();

        RuntimeException expectedException =
                new RuntimeException(
                        "Master data service unavailable"
                );

        when(
                masterDataMapper.toFetchMasterDataRequest(request)
        ).thenReturn(mappedRequest);

        doThrow(expectedException)
                .when(masterDataFeignClient)
                .fetchData(mappedRequest);

        // Act
        RuntimeException actualException =
                assertThrows(
                        RuntimeException.class,
                        () -> masterDataService.fetch(request)
                );

        // Assert
        assertSame(
                expectedException,
                actualException
        );

        verify(masterDataMapper)
                .toFetchMasterDataRequest(request);

        verify(masterDataFeignClient)
                .fetchData(mappedRequest);
    }


    //
    @Test
    void fetch_shouldSupportRequestWithAllFilterFields() {

        // Arrange
        MasterDataFetchRequest request =
                MasterDataFetchRequest.builder()
                        .masterName("BRANCH")
                        .pageNo(2)
                        .pageSize(50)
                        .selectors(
                                List.of(
                                        "code",
                                        "name",
                                        "city"
                                )
                        )
                        .exactMatch(
                                Map.of(
                                        "status",
                                        "ACTIVE"
                                )
                        )
                        .anyMatch(
                                Map.of(
                                        "name",
                                        "BANK"
                                )
                        )
                        .startsWith(
                                Map.of(
                                        "code",
                                        "IN"
                                )
                        )
                        .endsWith(
                                Map.of(
                                        "city",
                                        "PUR"
                                )
                        )
                        .sortBy(
                                List.of(
                                        "name",
                                        "city"
                                )
                        )
                        .asc(false)
                        .filterOperations(
                                Map.of(
                                        "status",
                                        "EQ"
                                )
                        )
                        .build();

        FetchMasterDataRequest mappedRequest =
                new FetchMasterDataRequest();

        mappedRequest.setMasterName("BRANCH");
        mappedRequest.setPageNo(2);
        mappedRequest.setPageSize(50);
        mappedRequest.setSelectors(
                List.of(
                        "code",
                        "name",
                        "city"
                )
        );
        mappedRequest.setExactMatch(
                Map.of(
                        "status",
                        "ACTIVE"
                )
        );
        mappedRequest.setAnyMatch(
                Map.of(
                        "name",
                        "BANK"
                )
        );
        mappedRequest.setStartsWith(
                Map.of(
                        "code",
                        "IN"
                )
        );
        mappedRequest.setEndsWith(
                Map.of(
                        "city",
                        "PUR"
                )
        );
        mappedRequest.setSortBy(
                List.of(
                        "name",
                        "city"
                )
        );
        mappedRequest.setAsc(false);
        mappedRequest.setFilterOperations(
                Map.of(
                        "status",
                        "EQ"
                )
        );

        PageDetail expectedPageDetail =
                mock(PageDetail.class);

        when(
                masterDataMapper.toFetchMasterDataRequest(request)
        ).thenReturn(mappedRequest);

        doReturn(expectedPageDetail)
                .when(masterDataFeignClient)
                .fetchData(mappedRequest);

        // Act
        PageDetail result =
                masterDataService.fetch(request);

        // Assert
        assertSame(
                expectedPageDetail,
                result
        );

        ArgumentCaptor<FetchMasterDataRequest> captor =
                ArgumentCaptor.forClass(
                        FetchMasterDataRequest.class
                );

        verify(masterDataFeignClient)
                .fetchData(captor.capture());

        FetchMasterDataRequest actualRequest =
                captor.getValue();

        assertEquals(
                "BRANCH",
                actualRequest.getMasterName()
        );

        assertEquals(
                2,
                actualRequest.getPageNo()
        );

        assertEquals(
                50,
                actualRequest.getPageSize()
        );

        assertEquals(
                List.of(
                        "code",
                        "name",
                        "city"
                ),
                actualRequest.getSelectors()
        );

        assertEquals(
                Map.of(
                        "status",
                        "ACTIVE"
                ),
                actualRequest.getExactMatch()
        );

        assertEquals(
                Map.of(
                        "name",
                        "BANK"
                ),
                actualRequest.getAnyMatch()
        );

        assertEquals(
                Map.of(
                        "code",
                        "IN"
                ),
                actualRequest.getStartsWith()
        );

        assertEquals(
                Map.of(
                        "city",
                        "PUR"
                ),
                actualRequest.getEndsWith()
        );

        assertEquals(
                List.of(
                        "name",
                        "city"
                ),
                actualRequest.getSortBy()
        );

        assertFalse(
                actualRequest.isAsc()
        );

        assertEquals(
                Map.of(
                        "status",
                        "EQ"
                ),
                actualRequest.getFilterOperations()
        );

        verify(masterDataMapper)
                .toFetchMasterDataRequest(request);
    }


    @Test
    void fetch_shouldReturnNull_whenFeignClientReturnsNull() {

        // Arrange
        MasterDataFetchRequest request =
                MasterDataFetchRequest.builder()
                        .masterName("COUNTRY")
                        .pageNo(0)
                        .pageSize(10)
                        .build();

        FetchMasterDataRequest mappedRequest =
                new FetchMasterDataRequest();

        when(
                masterDataMapper.toFetchMasterDataRequest(request)
        ).thenReturn(mappedRequest);

        doReturn(null)
                .when(masterDataFeignClient)
                .fetchData(mappedRequest);

        // Act
        PageDetail result =
                masterDataService.fetch(request);

        // Assert
        assertNull(result);

        verify(masterDataMapper)
                .toFetchMasterDataRequest(request);

        verify(masterDataFeignClient)
                .fetchData(mappedRequest);
    }


    @Test
    void fetch_shouldWorkWithMinimalRequest() {

        // Arrange
        MasterDataFetchRequest request =
                MasterDataFetchRequest.builder()
                        .masterName("COUNTRY")
                        .build();

        FetchMasterDataRequest mappedRequest =
                new FetchMasterDataRequest();

        mappedRequest.setMasterName("COUNTRY");

        PageDetail expectedPageDetail =
                mock(PageDetail.class);

        when(
                masterDataMapper.toFetchMasterDataRequest(request)
        ).thenReturn(mappedRequest);

        doReturn(expectedPageDetail)
                .when(masterDataFeignClient)
                .fetchData(mappedRequest);

        // Act
        PageDetail result =
                masterDataService.fetch(request);

        // Assert
        assertSame(
                expectedPageDetail,
                result
        );

        verify(masterDataMapper)
                .toFetchMasterDataRequest(request);

        verify(masterDataFeignClient)
                .fetchData(mappedRequest);
    }
}