package com.hdfcbank.giftcity.bff.customer.validator;

import com.hdfcbank.common.models.vo.journey.JourneyData;
import com.hdfcbank.giftcity.bff.commons.constant.CommonConstants;
import com.hdfcbank.giftcity.bff.commons.enums.CommonJourneyStates;
import com.hdfcbank.giftcity.bff.commons.enums.JourneyPageName;
import com.hdfcbank.giftcity.bff.commons.model.CustomValidationStatus;
import com.hdfcbank.giftcity.bff.commons.model.FcIndiaProfile;
import com.hdfcbank.giftcity.bff.commons.properties.CustomValidationProperties;
import com.hdfcbank.giftcity.bff.commons.utility.ValidationHelper;
import com.hdfcbank.giftcity.bff.commons.validation.ValidationResult;
import com.hdfcbank.giftcity.bff.commons.validation.ValidatorContext;
import com.hdfcbank.giftcity.bff.commons.validation.ValidatorType;
import com.hdfcbank.giftcity.bff.infrastructure.service.JourneyService;

import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;

import java.lang.reflect.Method;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class CustomerEligibilityValidatorTest {

    @Mock
    private ValidationHelper validationHelper;

    private CustomValidationProperties props;
    private CustomerEligibilityValidator validator;
    private MockedStatic<JourneyService> staticMock;

    @BeforeEach
    void setUp() throws Exception {
        props = new CustomValidationProperties();
        validator = new CustomerEligibilityValidator(props);

        var fld = validator.getClass().getSuperclass().getDeclaredField("validationHelper");
        fld.setAccessible(true);
        fld.set(validator, validationHelper);

        props.setJourneys(new HashMap<>());
    }

    @AfterEach
    void tearDown() {
        if (staticMock != null) staticMock.close();
    }

    private CustomValidationProperties.FieldDetail mandatoryFD(String type) {
        CustomValidationProperties.FieldDetail fd = new CustomValidationProperties.FieldDetail();
        fd.setType(type);
        fd.setMandatory(true);
        return fd;
    }

    private CustomValidationProperties.FieldDetail nonMandatoryFD(String type) {
        CustomValidationProperties.FieldDetail fd = new CustomValidationProperties.FieldDetail();
        fd.setType(type);
        fd.setMandatory(false);
        return fd;
    }

    private void addField(String journeyName, CustomValidationProperties.FieldDetail fd) {
        CustomValidationProperties.CustomValidations cv = new CustomValidationProperties.CustomValidations();
        cv.setFieldsDetail(List.of(fd));
        props.getJourneys().put(journeyName, cv);
    }

    private FcIndiaProfile.Profile profile() {
        FcIndiaProfile.Profile p = new FcIndiaProfile.Profile();

        p.setPanStatus("OK");
        p.setRefCustItNum("REF123");
        p.setRefCustEmail("x@y.com");
        p.setKycStatus("KYC");
        p.setMemoSevrity("H");

        var nationality = new com.hdfcbank.giftcity.bff.commons.model.MasterDataValue();
        nationality.setCode("IN");
        p.setNationality(nationality);

        p.setName("John Doe");
        p.setDob("19900101");
        p.setPanNumber("ABCDE1234F");

        var country = new com.hdfcbank.giftcity.bff.commons.model.MasterDataValue();
        country.setDescription("India");
        p.setCountry(country);

        p.setAddress("Addr");
        p.setCity("Mumbai");
        p.setState("MH");

        var mailingCountry = new com.hdfcbank.giftcity.bff.commons.model.MasterDataValue();
        mailingCountry.setDescription("India");
        p.setMailingCountry(mailingCountry);

        p.setMailingAddress1("MAddr");
        p.setMailingCity("MCity");
        p.setMailingState("MState");
        p.setMailingPinCode("400001");

        FcIndiaProfile.CustomerFATCADetail fatca = new FcIndiaProfile.CustomerFATCADetail();
        fatca.setIdDocTyp("PASSPORT");
        fatca.setIdDocExpDat(LocalDate.now().plusDays(60)
                .format(DateTimeFormatter.ofPattern("yyyyMMdd")));
        fatca.setDatExpiryVisa(LocalDate.now().plusDays(60)
                .format(DateTimeFormatter.ofPattern(CommonConstants.CASA_DATE_FORMAT)));
        fatca.setCodTaxCntry1("IN");
        fatca.setTinNo1("TIN");
        fatca.setTypTinNo1("TYPE");
        fatca.setNamCityBirth("CITY");
        fatca.setCodCntryBirth("IN");
        fatca.setAddrTaxReporting1("ADDR");

        p.setCustomerFATCADetails(List.of(fatca));

        FcIndiaProfile.CustomerAccountDetail acc = new FcIndiaProfile.CustomerAccountDetail();
        acc.setProductType("NRE");
        acc.setAccountStatus("ACTIVE");

        p.setCustomerAccountDetails(List.of(acc));
        p.setNamCustadrCntry("IN");
        p.setNamPermadrCntry("IN");

        return p;
    }

    // -------------------------------------------------------------------
    // validate()
    // -------------------------------------------------------------------

    @Test
    void testNullJourney() {
        ValidatorContext ctx = ValidatorContext.builder().journeyData(null).build();
        assertTrue(validator.validate(ctx).isEmpty());
    }

    @Test
    void testValidate_ProfileNullExtract() {
        JourneyData jd = JourneyData.builder().journeyName("J1").build();

        staticMock = mockStatic(JourneyService.class);
        staticMock.when(() ->
                JourneyService.extractFromJourney(eq(jd), any(), eq(FcIndiaProfile.class), any())
        ).thenReturn(Optional.empty());

        ValidatorContext ctx = ValidatorContext.builder().journeyData(jd).build();

        assertThrows(NullPointerException.class, () -> validator.validate(ctx));
    }

    @Test
    void testValidate_AllFieldsValid_Success() {
        JourneyData jd = JourneyData.builder().journeyName("J1").build();
        FcIndiaProfile.Profile p = profile();

        staticMock = mockStatic(JourneyService.class);
        staticMock.when(() ->
                JourneyService.extractFromJourney(eq(jd),
                        eq(JourneyPageName.CUSTOMER_FC_INDIA_DETAIL.getPageName()),
                        eq(FcIndiaProfile.class),
                        any())
        ).thenReturn(Optional.of(p));

        when(validationHelper.validateData(anyString(), any(), any(), any()))
                .thenReturn(null);

        addField("J1", nonMandatoryFD(CommonConstants.FOREIGN_ADDRESS));

        ValidatorContext ctx = ValidatorContext.builder().journeyData(jd).build();
        ValidationResult result = validator.validate(ctx).get();

        assertTrue(result.isSuccess());
        assertNull(result.getApiResponseStatus());
    }

    @Test
    void testValidate_Fatca_MissingFieldTriggersFailure() {
        JourneyData jd = JourneyData.builder().journeyName("J1").build();
        FcIndiaProfile.Profile p = profile();

        p.getCustomerFATCADetails().get(0).setTinNo1(null);

        staticMock = mockStatic(JourneyService.class);
        staticMock.when(() ->
                JourneyService.extractFromJourney(eq(jd),
                        eq(JourneyPageName.CUSTOMER_FC_INDIA_DETAIL.getPageName()),
                        eq(FcIndiaProfile.class),
                        any())
        ).thenReturn(Optional.of(p));

        CustomValidationProperties.FieldDetail fd = mandatoryFD(CommonConstants.TAX_ID_NUMBER);
        addField("J1", fd);

        when(validationHelper.validateData(anyString(), any(), any(), any()))
                .thenReturn(fd);

        CustomValidationStatus errorStatus = CustomValidationStatus.builder()
                .code("ERR")
                .message("Missing")
                .build();

        when(validationHelper.getErrors(anyString(), anyList(), any()))
                .thenReturn(errorStatus);

        ValidatorContext ctx = ValidatorContext.builder().journeyData(jd).build();
        ValidationResult result = validator.validate(ctx).get();

        assertFalse(result.isSuccess());
        assertEquals("Missing", result.getApiResponseStatus().getMessage());
        assertEquals("ERR", result.getApiResponseStatus().getCode());
    }

    // -------------------------------------------------------------------
    // validateForeignAddress()
    // -------------------------------------------------------------------

    @Test
    void testForeignAddress_FieldDetailNull() {
        FcIndiaProfile.Profile p = profile();
        assertNull(validator.validateForeignAddress("J1", p, props));
    }

    @Test
    void testForeignAddress_NotMandatory() {
        FcIndiaProfile.Profile p = profile();

        addField("J1", nonMandatoryFD(CommonConstants.FOREIGN_ADDRESS));
        assertNull(validator.validateForeignAddress("J1", p, props));
    }

    @Test
    void testForeignAddress_Mandatory_MailingForeign() {
        FcIndiaProfile.Profile p = profile();
        p.setNamCustadrCntry("US");

        addField("J1", mandatoryFD(CommonConstants.FOREIGN_ADDRESS));
        assertNull(validator.validateForeignAddress("J1", p, props));
    }

    @Test
    void testForeignAddress_Mandatory_PermanentForeign() {
        FcIndiaProfile.Profile p = profile();
        p.setNamPermadrCntry("UK");

        addField("J1", mandatoryFD(CommonConstants.FOREIGN_ADDRESS));
        assertNull(validator.validateForeignAddress("J1", p, props));
    }

    // -------------------------------------------------------------------
    // validatePassportExpiry()
    // -------------------------------------------------------------------

    @Test
    void testPassportExpiry_FieldDetailNull() {
        FcIndiaProfile.Profile p = profile();
        assertNull(validator.validatePassportExpiry("J1", p, props));
    }

    @Test
    void testPassportExpiry_NotMandatoryMissing() {
        FcIndiaProfile.Profile p = profile();
        p.getCustomerFATCADetails().get(0).setIdDocExpDat(null);

        addField("J1", nonMandatoryFD(CommonConstants.PASSPORT_EXPIRY));
        assertNull(validator.validatePassportExpiry("J1", p, props));
    }

    @Test
    void testPassportExpiry_ValidButNotAfterThreshold() {
        FcIndiaProfile.Profile p = profile();

        p.getCustomerFATCADetails().get(0).setIdDocExpDat(
                LocalDate.now().plusDays(20)
                        .format(DateTimeFormatter.ofPattern("yyyyMMdd"))
        );

        addField("J1", mandatoryFD(CommonConstants.PASSPORT_EXPIRY));
        assertNotNull(validator.validatePassportExpiry("J1", p, props));
    }

    @Test
    void testPassportExpiry_ValidAfterThreshold() {
        FcIndiaProfile.Profile p = profile();

        p.getCustomerFATCADetails().get(0).setIdDocExpDat(
                LocalDate.now().plusDays(90)
                        .format(DateTimeFormatter.ofPattern("yyyyMMdd"))
        );

        addField("J1", mandatoryFD(CommonConstants.PASSPORT_EXPIRY));
        assertNull(validator.validatePassportExpiry("J1", p, props));
    }

    // -------------------------------------------------------------------
    // validateVisaExpiry()
    // -------------------------------------------------------------------

    @Test
    void testVisaExpiry_FieldDetailNull() {
        FcIndiaProfile.Profile p = profile();
        assertNull(validator.validateVisaExpiry("J1", p, props));
    }

    @Test
    void testVisaExpiry_ValidButNotAfterThreshold() {
        FcIndiaProfile.Profile p = profile();

        p.getCustomerFATCADetails().get(0).setDatExpiryVisa(
                LocalDate.now().plusDays(10)
                        .format(DateTimeFormatter.ofPattern(CommonConstants.CASA_DATE_FORMAT))
        );

        addField("J1", mandatoryFD(CommonConstants.VISA_EXPIRY));
        assertNotNull(validator.validateVisaExpiry("J1", p, props));
    }

    @Test
    void testVisaExpiry_ValidAfterThreshold() {
        FcIndiaProfile.Profile p = profile();

        p.getCustomerFATCADetails().get(0).setDatExpiryVisa(
                LocalDate.now().plusDays(100)
                        .format(DateTimeFormatter.ofPattern(CommonConstants.CASA_DATE_FORMAT))
        );

        addField("J1", mandatoryFD(CommonConstants.VISA_EXPIRY));
        assertNull(validator.validateVisaExpiry("J1", p, props));
    }

    @Test
    void testVisaExpiry_InvalidDateFormatException() {
        FcIndiaProfile.Profile p = profile();

        p.getCustomerFATCADetails().get(0).setIdDocExpDat(
                LocalDate.now().plusDays(120).format(DateTimeFormatter.ofPattern("yyyyMMdd"))
        );

        p.getCustomerFATCADetails().get(0).setDatExpiryVisa("BAD_DATE");

        addField("J1", mandatoryFD(CommonConstants.VISA_EXPIRY));

        CustomValidationProperties.FieldDetail result = validator.validateVisaExpiry("J1", p, props);

        assertNotNull(result);
        assertEquals("Invalid date format", result.getMessage());
    }

    // -------------------------------------------------------------------
    // Reflection-based tests
    // -------------------------------------------------------------------

    private String invokePrivate(String methodName, FcIndiaProfile.Profile p) {
        try {
            Method m = CustomerEligibilityValidator.class
                    .getDeclaredMethod(methodName, FcIndiaProfile.Profile.class);
            m.setAccessible(true);
            return (String) m.invoke(validator, p);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Test
    void testCommunicationAddress_NullCountry() {
        FcIndiaProfile.Profile p = profile();
        p.setMailingCountry(null);

        String addr = invokePrivate("communicationAddress", p);
        assertNotNull(addr);
        assertTrue(addr.contains("MAddr"));
    }

    @Test
    void testPermanentAddress_NullCountry() {
        FcIndiaProfile.Profile p = profile();
        p.setCountry(null);

        String addr = invokePrivate("permanentAddress", p);
        assertNotNull(addr);
        assertTrue(addr.contains("Addr"));
    }

    // -------------------------------------------------------------------
    // Meta methods
    // -------------------------------------------------------------------

    @Test
    void testMetaMethods() {
        assertEquals("postCustomerValidator", validator.name());
        assertEquals(CommonJourneyStates.FC_INDIA_ELIGIBILITY_SUCCESS, validator.successState());
        assertEquals(CommonJourneyStates.FC_INDIA_ELIGIBILITY_FAILURE, validator.failureState());
        assertTrue(validator.isMandatory());
        assertEquals(ValidatorType.POST_CUSTOMER_VALIDATION, validator.type());
    }
}