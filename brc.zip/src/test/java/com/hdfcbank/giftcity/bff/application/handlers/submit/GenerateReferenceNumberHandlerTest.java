package com.hdfcbank.giftcity.bff.application.handlers.submit;

import com.hdfcbank.adapters.clients.feign.refgen.clients.RefGenServiceFeignClient;
import com.hdfcbank.adapters.clients.feign.refgen.request.RefGenRequest;
import com.hdfcbank.adapters.clients.feign.refgen.response.RefGenResponse;
import com.hdfcbank.common.models.vo.core.ApiResponse;
import com.hdfcbank.common.models.vo.core.ApiResponseStatus;
import com.hdfcbank.common.models.vo.journey.JourneyData;
import com.hdfcbank.giftcity.bff.commons.enums.CommonJourneyStates;
import com.hdfcbank.giftcity.bff.commons.exception.handler.DownstreamResponseHandler;
import com.hdfcbank.giftcity.bff.commons.handler.Handler;
import com.hdfcbank.giftcity.bff.commons.handler.HandlerContext;
import com.hdfcbank.giftcity.bff.commons.handler.HandlerResult;
import com.hdfcbank.giftcity.bff.commons.model.CustomValidationStatus;
import com.hdfcbank.giftcity.bff.infrastructure.service.JourneyService;

import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
class GenerateReferenceNumberHandlerTest {

    @Mock private RefGenServiceFeignClient refGenClient;
    @Mock private JourneyService journeyService;

    @Spy
    @InjectMocks
    private GenerateReferenceNumberHandler handler;

    private JourneyData journeyData;
    private HandlerContext ctx;

    @BeforeEach
    void setup() {
        journeyData = JourneyData.builder()
                .journeyId("J123")
                .journeyName("GIFT_CITY")
                .build();

        ctx = HandlerContext.builder()
                .journeyData(journeyData)
                .data(new java.util.HashMap<>())
                .properties(new java.util.HashMap<>())
                .build();
    }

    // ---------------------------------------------------------------------
    //      PRECONDITIONS — only checks RISK_ANALYSIS
    // ---------------------------------------------------------------------

    @Test
    void preConditions_true() {
        doReturn(true).when(handler).isSuccess(ctx, Handler.HandlerName.RISK_ANALYSIS);
        assertTrue(handler.preConditions(ctx));
    }

    @Test
    void preConditions_false() {
        doReturn(false).when(handler).isSuccess(ctx, Handler.HandlerName.RISK_ANALYSIS);
        assertFalse(handler.preConditions(ctx));
    }

    // ---------------------------------------------------------------------
    //      SUCCESS — refNumber returned
    // ---------------------------------------------------------------------

    @Test
    void handle_success_referenceNumberReturned() {

        RefGenResponse data = new RefGenResponse();
        data.setRefNumber("REF123");

        ApiResponse<RefGenResponse> success = new ApiResponse<>();
        ApiResponseStatus st = new ApiResponseStatus();
        st.setCode("0000");
        st.setMessage("OK");
        success.setStatus(st);
        success.setData(data);

        when(refGenClient.generateReferenceNumber(any(RefGenRequest.class),
                eq("J123"), eq("GIFT_CITY")))
                .thenReturn(success);

        HandlerResult<String> result = handler.handle(ctx);

        assertTrue(result.isSuccess());
        assertEquals("REF123", result.getResult());
        verify(journeyService).saveJourney(journeyData);
        assertEquals("REF123", journeyData.getReferenceNo());
    }

    // ---------------------------------------------------------------------
    //      FAILURE — refNumber null OR code not success
    // ---------------------------------------------------------------------

    @Test
    void handle_failure_refNull() {

        RefGenResponse data = new RefGenResponse();
        data.setRefNumber(null);

        ApiResponse<RefGenResponse> fail = new ApiResponse<>();
        ApiResponseStatus st = new ApiResponseStatus();
        st.setCode("9999");
        st.setMessage("FAIL");
        fail.setStatus(st);
        fail.setData(data);

        when(refGenClient.generateReferenceNumber(any(RefGenRequest.class),
                eq("J123"), eq("GIFT_CITY")))
                .thenReturn(fail);

        CustomValidationStatus status = CustomValidationStatus.builder()
                .code("ERR")
                .message("DOWNSTREAM")
                .build();

        try (MockedStatic<DownstreamResponseHandler> dsh =
                     mockStatic(DownstreamResponseHandler.class)) {

            dsh.when(() -> DownstreamResponseHandler.handleResponse(
                    eq(fail),
                    eq(Handler.HandlerName.CREATE_REFERENCE_NUMBER.name()),
                    eq(false),
                    eq("GIFT_CITY")
            )).thenReturn(status);

            HandlerResult<String> result = handler.handle(ctx);

            assertFalse(result.isSuccess());
            assertEquals("ERR", result.getApiResponseStatus().getCode());
        }
    }

    // ---------------------------------------------------------------------
    //      EXCEPTION — Feign throws
    // ---------------------------------------------------------------------

    @Test
    void handle_exception() {

        when(refGenClient.generateReferenceNumber(any(RefGenRequest.class),
                eq("J123"), eq("GIFT_CITY")))
                .thenThrow(new RuntimeException("Boom"));

        CustomValidationStatus status = CustomValidationStatus.builder()
                .code("EX")
                .message("EXC")
                .build();

        try (MockedStatic<DownstreamResponseHandler> dsh =
                     mockStatic(DownstreamResponseHandler.class)) {

            dsh.when(() -> DownstreamResponseHandler.handleResponse(
                    eq(null),
                    eq(Handler.HandlerName.CREATE_REFERENCE_NUMBER.name()),
                    eq(false),
                    eq("GIFT_CITY")
            )).thenReturn(status);

            HandlerResult<String> result = handler.handle(ctx);

            assertFalse(result.isSuccess());
            assertEquals("EX", result.getApiResponseStatus().getCode());
        }
    }

    // ---------------------------------------------------------------------
    //      ENUM COVERAGE
    // ---------------------------------------------------------------------

    @Test
    void enumCoverage() {
        assertEquals(Handler.HandlerType.CUSTOMER_POST_SUBMIT, handler.getType());
        assertEquals(Handler.HandlerName.CREATE_REFERENCE_NUMBER, handler.getName());
        assertEquals(CommonJourneyStates.CREATE_APPLICATION_NUMBER_SUCCESS, handler.successState());
        assertEquals(CommonJourneyStates.CREATE_APPLICATION_NUMBER_FAILURE, handler.failureState());
    }
}