package com.hdfcbank.giftcity.bff.commons.utility;

import org.junit.jupiter.api.Test;

import java.nio.charset.StandardCharsets;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;

class HashUtilTest {

    @Test
    void testHashProducesDeterministicUUID() {
        String input = "test-value";

        String expected = UUID.nameUUIDFromBytes(
                input.getBytes(StandardCharsets.UTF_8)
        ).toString();

        String actual = HashUtil.hash(input);

        assertEquals(expected, actual);

        // extra assertions
        assertNotNull(actual);
        assertFalse(actual.isBlank());
        assertEquals(36, actual.length());          // UUID length
        assertDoesNotThrow(() -> UUID.fromString(actual)); // valid UUID format
    }

    @Test
    void testHashDifferentInputsProduceDifferentHashes() {
        String hash1 = HashUtil.hash("A");
        String hash2 = HashUtil.hash("B");

        assertNotEquals(hash1, hash2);

        // extra assertions
        assertNotNull(hash1);
        assertNotNull(hash2);
        assertDoesNotThrow(() -> UUID.fromString(hash1));
        assertDoesNotThrow(() -> UUID.fromString(hash2));
    }

    @Test
    void testHashNotNull() {
        String hash = HashUtil.hash("anything");

        assertNotNull(hash);
        assertFalse(hash.isBlank());

        // extra assertions
        assertEquals(36, hash.length());
        assertDoesNotThrow(() -> UUID.fromString(hash));
    }

    @Test
    void testHashConsistencyForSameInput() {
        String input = "consistent";

        String h1 = HashUtil.hash(input);
        String h2 = HashUtil.hash(input);

        assertEquals(h1, h2); // deterministic

        // extra assertions
        assertDoesNotThrow(() -> UUID.fromString(h1));
        assertDoesNotThrow(() -> UUID.fromString(h2));
        assertEquals(h1.length(), h2.length());
    }

    @Test
    void testHashHandlesEmptyString() {
        String hash = HashUtil.hash("");

        assertNotNull(hash);

        String expected = UUID.nameUUIDFromBytes(new byte[0]).toString();
        assertEquals(expected, hash);

        // extra assertions
        assertDoesNotThrow(() -> UUID.fromString(hash));
        assertEquals(36, hash.length());
    }
}