package com.hdfcbank.giftcity.bff.master.mapper;

import com.hdfcbank.adapters.vo.FetchMasterDataRequest;
import com.hdfcbank.giftcity.bff.master.models.MasterDataFetchRequest;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;

class MasterDataMapperImplTest {

    private final MasterDataMapperImpl mapper = new MasterDataMapperImpl();

    @Test
    void testToFetchMasterDataRequest_nullInput() {
        FetchMasterDataRequest result = mapper.toFetchMasterDataRequest(null);
        assertThat(result).isNull();
    }

    @Test
    void testToFetchMasterDataRequest_fullMapping() {

        MasterDataFetchRequest request = MasterDataFetchRequest.builder()
                .masterName("country_master")
                .pageNo(2)
                .pageSize(50)
                .selectors(List.of("Name", "ISO"))
                .exactMatch(Map.of("ISO", "IN"))
                .anyMatch(Map.of("desc", "Ind"))
                .startsWith(Map.of("code", "I"))
                .endsWith(Map.of("suffix", "A"))
                .sortBy(List.of("Name"))
                .asc(true)
                .filterOperations(Map.of("status", "ACTIVE"))
                .build();

        FetchMasterDataRequest result = mapper.toFetchMasterDataRequest(request);

        assertThat(result).isNotNull();
        assertThat(result.getMasterName()).isEqualTo("country_master");
        assertThat(result.getPageNo()).isEqualTo(2);
        assertThat(result.getPageSize()).isEqualTo(50);

        assertThat(result.getSelectors()).containsExactly("Name", "ISO");
        assertThat(result.getExactMatch()).containsEntry("ISO", "IN");
        assertThat(result.getAnyMatch()).containsEntry("desc", "Ind");
        assertThat(result.getStartsWith()).containsEntry("code", "I");
        assertThat(result.getEndsWith()).containsEntry("suffix", "A");
        assertThat(result.getSortBy()).containsExactly("Name");
        assertThat(result.isAsc()).isTrue();
        assertThat(result.getFilterOperations()).containsEntry("status", "ACTIVE");
    }

    @Test
    void testToFetchMasterDataRequest_deepCopyBehavior() {

        //           Use MUTABLE collections (crucial!)
        List<String> selectors = new ArrayList<>();
        selectors.add("Field");

        Map<String, String> exactMatch = new HashMap<>();
        exactMatch.put("k1", "v1");

        MasterDataFetchRequest request = MasterDataFetchRequest.builder()
                .masterName("test_master")
                .pageNo(1)
                .pageSize(10)
                .selectors(selectors)
                .exactMatch(exactMatch)
                .build();

        FetchMasterDataRequest result = mapper.toFetchMasterDataRequest(request);

        //           Modify original MUTABLE lists/maps — no UnsupportedOperationException
        selectors.add("Extra");
        exactMatch.put("k1", "modified");

        //           Ensure the mapper deep‑copied the collections
        assertThat(result.getSelectors()).containsExactly("Field");
        assertThat(result.getExactMatch()).containsEntry("k1", "v1");
    }

    @Test
    void testToFetchMasterDataRequest_emptyCollections() {
        MasterDataFetchRequest request = MasterDataFetchRequest.builder()
                .masterName("empty_test")
                .pageNo(0)
                .pageSize(0)
                .selectors(new ArrayList<>())
                .exactMatch(new HashMap<>())
                .anyMatch(new HashMap<>())
                .startsWith(new HashMap<>())
                .endsWith(new HashMap<>())
                .sortBy(new ArrayList<>())
                .filterOperations(new HashMap<>())
                .asc(false)
                .build();

        FetchMasterDataRequest result = mapper.toFetchMasterDataRequest(request);

        assertThat(result.getSelectors()).isEmpty();
        assertThat(result.getExactMatch()).isEmpty();
        assertThat(result.getAnyMatch()).isEmpty();
        assertThat(result.getStartsWith()).isEmpty();
        assertThat(result.getEndsWith()).isEmpty();
        assertThat(result.getSortBy()).isEmpty();
        assertThat(result.getFilterOperations()).isEmpty();
        assertThat(result.isAsc()).isFalse();
    }
}