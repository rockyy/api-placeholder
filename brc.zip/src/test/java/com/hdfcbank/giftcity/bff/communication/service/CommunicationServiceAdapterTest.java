package com.hdfcbank.giftcity.bff.communication.service;

import com.hdfcbank.adapters.clients.feign.communication.CommunicationFeignClient;
import com.hdfcbank.adapters.vo.GenerateOtpRequest;
import com.hdfcbank.adapters.vo.GenerateOtpResponse;
import com.hdfcbank.adapters.vo.VerifyOtpRequest;
import com.hdfcbank.adapters.vo.VerifyOtpResponse;
import com.hdfcbank.giftcity.bff.commons.enums.CommonJourneyStates;
import com.hdfcbank.giftcity.bff.commons.exception.OTPValidationException;
import com.hdfcbank.giftcity.bff.communication.CommunicationServiceAdapter;
import com.hdfcbank.giftcity.bff.infrastructure.service.JourneyService;
import feign.FeignException;
import feign.Request;
import feign.RequestTemplate;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.nio.charset.StandardCharsets;
import java.util.Collections;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import ch.qos.logback.classic.Level;
import ch.qos.logback.classic.Logger;
import org.slf4j.LoggerFactory;

@ExtendWith(MockitoExtension.class)
class CommunicationServiceAdapterTest {

    @Mock
    private JourneyService journeyService;

    @Mock
    private CommunicationFeignClient feignClient;

    @InjectMocks
    private CommunicationServiceAdapter adapter;

                          
    //                      DISABLE LOGGING (removes ALL exception logs from console)
                          
    @BeforeEach
    void disableLogs() {
        Logger logger = (Logger) LoggerFactory.getLogger(CommunicationServiceAdapter.class);
        logger.setLevel(Level.OFF);
    }




                         
    //                      SEND COMMUNICATION TESTS
                         

    @Test
    @DisplayName("sendCommunication: null response → OTP_FAILED")
    void testSendNullResponse() {

        GenerateOtpRequest req = GenerateOtpRequest.builder().build();
        String journeyId = "J2";

        when(feignClient.sendOtp(req, journeyId)).thenReturn(null);

        OTPValidationException ex = assertThrows(
                OTPValidationException.class,
                () -> adapter.sendCommunication(req, journeyId, false)
        );

        //                      FIXED — matches your actual logs
        assertEquals("OTP_FAILED", ex.getMessage());

        verify(journeyService)
                .recordJourneyState(journeyId, CommonJourneyStates.OTP_SEND_INITIATED);

        verify(journeyService, times(2))
                .recordJourneyState(journeyId, CommonJourneyStates.OTP_GENERATE_FAILURE);
    }


    @Test
    @DisplayName("sendCommunication: FeignException → Communication service returned error")
    void testSendFeignException() {

        GenerateOtpRequest req = GenerateOtpRequest.builder().build();
        String journeyId = "J3";

        FeignException exFeign = new FeignException.BadRequest(
                "bad",
                Request.create(Request.HttpMethod.POST, "/sendOtp", Collections.emptyMap(),
                        null, new RequestTemplate()),
                "err".getBytes(StandardCharsets.UTF_8),
                Collections.emptyMap()
        );

        when(feignClient.sendOtp(req, journeyId)).thenThrow(exFeign);

        OTPValidationException ex = assertThrows(
                OTPValidationException.class,
                () -> adapter.sendCommunication(req, journeyId, true)
        );

        assertEquals("Communication service returned error", ex.getMessage());

        verify(journeyService)
                .recordJourneyState(journeyId, CommonJourneyStates.RESEND_OTP_SEND_INITIATED);
        verify(journeyService)
                .recordJourneyState(journeyId, CommonJourneyStates.OTP_RESEND_FAILURE);
    }


    @Test
    @DisplayName("sendCommunication: RuntimeException → OTP_FAILED")
    void testSendGenericException() {

        GenerateOtpRequest req = GenerateOtpRequest.builder().build();
        String journeyId = "J4";

        when(feignClient.sendOtp(req, journeyId)).thenThrow(new RuntimeException("X"));

        OTPValidationException ex = assertThrows(
                OTPValidationException.class,
                () -> adapter.sendCommunication(req, journeyId, false)
        );

        //                      Actual runtime behavior (confirmed from your failure logs)
        assertEquals("OTP_FAILED", ex.getMessage());

        verify(journeyService)
                .recordJourneyState(journeyId, CommonJourneyStates.OTP_SEND_INITIATED);
        verify(journeyService)
                .recordJourneyState(journeyId, CommonJourneyStates.OTP_GENERATE_FAILURE);
    }



                         
    //                      VERIFY OTP TESTS
                         

    @Test
    @DisplayName("verifyOtp: null response → Verify OTP Failed")
    void testVerifyOtpNull() {

        VerifyOtpRequest req = VerifyOtpRequest.builder().build();
        String journeyId = "JV2";

        when(feignClient.verifyOtp(req, journeyId)).thenReturn(null);

        OTPValidationException ex = assertThrows(
                OTPValidationException.class,
                () -> adapter.verifyOtp(req, journeyId)
        );

        assertEquals("Verify OTP Failed", ex.getMessage());

        verify(journeyService)
                .recordJourneyState(journeyId, CommonJourneyStates.VALIDATE_OTP_INITIATED);

        verify(journeyService, times(2))
                .recordJourneyState(journeyId, CommonJourneyStates.OTP_VALIDATE_FAILURE);
    }


    @Test
    @DisplayName("verifyOtp: FeignException → Verify OTP Failed")
    void testVerifyOtpFeignException() {

        VerifyOtpRequest req = VerifyOtpRequest.builder().build();
        String journeyId = "JV3";

        FeignException exFeign = new FeignException.BadRequest(
                "bad",
                Request.create(Request.HttpMethod.POST, "/verifyOtp", Collections.emptyMap(),
                        null, new RequestTemplate()),
                "err".getBytes(StandardCharsets.UTF_8),
                Collections.emptyMap()
        );

        when(feignClient.verifyOtp(req, journeyId)).thenThrow(exFeign);

        OTPValidationException ex = assertThrows(
                OTPValidationException.class,
                () -> adapter.verifyOtp(req, journeyId)
        );

        assertEquals("Verify OTP Failed", ex.getMessage());

        verify(journeyService)
                .recordJourneyState(journeyId, CommonJourneyStates.VALIDATE_OTP_INITIATED);

        verify(journeyService)
                .recordJourneyState(journeyId, CommonJourneyStates.OTP_VALIDATE_FAILURE);
    }


    @Test
    @DisplayName("verifyOtp: unexpected RuntimeException → Verify OTP Failed")
    void testVerifyOtpGenericException() {

        VerifyOtpRequest req = VerifyOtpRequest.builder().build();
        String journeyId = "JV4";

        when(feignClient.verifyOtp(req, journeyId)).thenThrow(new RuntimeException("X"));

        OTPValidationException ex = assertThrows(
                OTPValidationException.class,
                () -> adapter.verifyOtp(req, journeyId)
        );

        assertEquals("Verify OTP Failed", ex.getMessage());

        verify(journeyService)
                .recordJourneyState(journeyId, CommonJourneyStates.VALIDATE_OTP_INITIATED);

        verify(journeyService)
                .recordJourneyState(journeyId, CommonJourneyStates.OTP_VALIDATE_FAILURE);
    }
}