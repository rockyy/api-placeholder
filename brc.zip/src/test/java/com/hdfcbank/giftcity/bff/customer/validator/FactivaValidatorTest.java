package com.hdfcbank.giftcity.bff.customer.validator;

import com.hdfcbank.common.models.vo.core.ApiResponse;
import com.hdfcbank.common.models.vo.core.ApiResponseStatus;
import com.hdfcbank.common.models.vo.journey.JourneyData;
import com.hdfcbank.giftcity.bff.commons.enums.CommonJourneyStates;
import com.hdfcbank.giftcity.bff.commons.exception.handler.DownstreamResponseHandler;
import com.hdfcbank.giftcity.bff.commons.model.CustomValidationStatus;
import com.hdfcbank.giftcity.bff.commons.properties.CustomValidationProperties;
import com.hdfcbank.giftcity.bff.commons.validation.AbstractCommanValidator;
import com.hdfcbank.giftcity.bff.commons.validation.ValidationResult;
import com.hdfcbank.giftcity.bff.commons.validation.ValidatorContext;
import com.hdfcbank.giftcity.bff.commons.validation.ValidatorType;
import com.hdfcbank.giftcity.bff.customer.constants.CustomerConstants;
import com.hdfcbank.giftcity.bff.customer.mapper.FactivaDedupeMapper;

import com.hdfcbank.service.adapters.clients.feign.customer.CustomerServiceFeignClient;
import com.hdfcbank.service.adapters.vo.customer.FactivaCheckApiResponse;
import com.hdfcbank.service.adapters.vo.customer.FactivaDedupeRequest;
import com.hdfcbank.service.adapters.vo.customer.FactivaSummaryResponse;

import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import ch.qos.logback.classic.Level;
import ch.qos.logback.classic.Logger;
import org.slf4j.LoggerFactory;

@ExtendWith(MockitoExtension.class)
class FactivaValidatorTest {

    //       MUTE ALL LOGGING (no errors printed)
    @BeforeAll
    static void muteLogs() {
        Logger root = (Logger) LoggerFactory.getLogger(Logger.ROOT_LOGGER_NAME);
        root.setLevel(Level.OFF);
    }

    @Mock CustomerServiceFeignClient feignClient;
    @Mock FactivaDedupeMapper mapper;
    @Mock CustomValidationProperties props;
    @Mock com.hdfcbank.giftcity.bff.commons.utility.ValidationHelper validationHelper;

    private FactivaValidator validator;

    @BeforeEach
    void setup() throws Exception {
        validator = new FactivaValidator(feignClient, mapper, props);

        var field = AbstractCommanValidator.class.getDeclaredField("validationHelper");
        field.setAccessible(true);
        field.set(validator, validationHelper);
    }

    private JourneyData journey() {
        return JourneyData.builder()
                .journeyId("J123")
                .journeyName("JOURNEY")
                .referenceNo("REF-001")
                .profile(null)
                .build();
    }

    private FactivaCheckApiResponse buildResp(String code) {
        ApiResponseStatus st = new ApiResponseStatus();
        st.setCode(code);

        FactivaCheckApiResponse resp = new FactivaCheckApiResponse();
        resp.setStatus(st);
        resp.setData(new FactivaSummaryResponse());
        return resp;
    }

    private CustomValidationStatus errorStatus() {
        return CustomValidationStatus.builder()
                .code("ERR")
                .message("ERROR_MESSAGE")
                .title("ERROR_MESSAGE")
                .build();
    }

    // SUCCESS
    @Test
    void testValidate_Success() {
        JourneyData jd = journey();
        FactivaDedupeRequest req = FactivaDedupeRequest.builder().requestorUserID("U1").build();

        when(mapper.toRequest(any(), any())).thenReturn(req);
        FactivaCheckApiResponse resp = buildResp(CustomerConstants.DEDUPE_SUCCESS);
        when(feignClient.customerFactivaDedupe(any(), any())).thenReturn(resp);

        ValidatorContext ctx = ValidatorContext.builder().journeyData(jd).build();
        Optional<ValidationResult> vr = validator.validate(ctx);

        assertTrue(vr.isPresent());
        assertTrue(vr.get().isSuccess());
    }

    @Test
    void testValidate_DedupeFailure() {
        JourneyData jd = journey();
        FactivaDedupeRequest req = FactivaDedupeRequest.builder().requestorUserID("U1").build();

        when(mapper.toRequest(any(), any())).thenReturn(req);
        FactivaCheckApiResponse resp = buildResp(CustomerConstants.DEDUPE_FAILURE);
        when(feignClient.customerFactivaDedupe(any(), any())).thenReturn(resp);

        try (MockedStatic<DownstreamResponseHandler> mocked = mockStatic(DownstreamResponseHandler.class)) {

            mocked.when(() -> DownstreamResponseHandler.handleResponse(
                            any(ApiResponse.class), anyString(), any(Boolean.class), anyString()))
                    .thenReturn(errorStatus());

            ValidatorContext ctx = ValidatorContext.builder().journeyData(jd).build();
            ValidationResult vr = validator.validate(ctx).get();

            assertFalse(vr.isSuccess());
            assertEquals("ERROR_MESSAGE", vr.getApiResponseStatus().getMessage());
        }
    }

    @Test
    void testValidate_NullStatus() {
        JourneyData jd = journey();
        FactivaCheckApiResponse resp = new FactivaCheckApiResponse();

        FactivaDedupeRequest req = FactivaDedupeRequest.builder().build();

        when(mapper.toRequest(any(), any())).thenReturn(req);
        when(feignClient.customerFactivaDedupe(any(), any())).thenReturn(resp);

        try (MockedStatic<DownstreamResponseHandler> mocked = mockStatic(DownstreamResponseHandler.class)) {

            mocked.when(() -> DownstreamResponseHandler.handleResponse(any(ApiResponse.class),
                    anyString(),
                    any(Boolean.class),
                    anyString())).thenReturn(errorStatus());

            ValidatorContext ctx = ValidatorContext.builder().journeyData(jd).build();
            ValidationResult vr = validator.validate(ctx).get();

            assertFalse(vr.isSuccess());
        }
    }

    @Test
    void testValidate_NullResponse() {
        JourneyData jd = journey();
        FactivaDedupeRequest req = FactivaDedupeRequest.builder().build();

        when(mapper.toRequest(any(), any())).thenReturn(req);
        when(feignClient.customerFactivaDedupe(any(), any())).thenReturn(null);

        try (MockedStatic<DownstreamResponseHandler> mocked = mockStatic(DownstreamResponseHandler.class)) {

            mocked.when(() -> DownstreamResponseHandler.handleResponse(
                    any(), anyString(), any(), anyString())).thenReturn(errorStatus());

            ValidatorContext ctx = ValidatorContext.builder().journeyData(jd).build();
            ValidationResult vr = validator.validate(ctx).get();

            assertFalse(vr.isSuccess());
            assertEquals("ERROR_MESSAGE", vr.getApiResponseStatus().getMessage());
        }
    }

    @Test
    void testValidate_ExceptionThrown() {
        JourneyData jd = journey();
        FactivaDedupeRequest req = FactivaDedupeRequest.builder().build();

        when(mapper.toRequest(any(), any())).thenReturn(req);
        when(feignClient.customerFactivaDedupe(any(), any())).thenThrow(new RuntimeException("FAIL"));

        try (MockedStatic<DownstreamResponseHandler> mocked = mockStatic(DownstreamResponseHandler.class)) {

            mocked.when(() -> DownstreamResponseHandler.handleResponse(
                    any(), anyString(), any(), anyString())).thenReturn(errorStatus());

            ValidatorContext ctx = ValidatorContext.builder().journeyData(jd).build();
            ValidationResult vr = validator.validate(ctx).get();

            assertFalse(vr.isSuccess());
        }
    }

    @Test
    void testValidate_UnexpectedStatus() {

        JourneyData jd = journey();
        FactivaDedupeRequest req = FactivaDedupeRequest.builder().build();

        when(mapper.toRequest(any(), any())).thenReturn(req);

        FactivaCheckApiResponse resp = buildResp("XYZ999");
        when(feignClient.customerFactivaDedupe(any(), any())).thenReturn(resp);

        try (MockedStatic<DownstreamResponseHandler> mocked = mockStatic(DownstreamResponseHandler.class)) {

            mocked.when(() -> DownstreamResponseHandler.handleResponse(
                            any(ApiResponse.class), anyString(), any(Boolean.class), anyString()))
                    .thenReturn(errorStatus());

            ValidatorContext ctx = ValidatorContext.builder().journeyData(jd).build();
            ValidationResult vr = validator.validate(ctx).get();

            assertFalse(vr.isSuccess());
        }
    }

    @Test
    void testMetaMethods() {
        assertEquals(ValidatorType.POST_CUSTOMER_VALIDATION, validator.type());
        assertEquals(CustomerConstants.POST_FACTIVA_VALIDATOR, validator.name());
        assertEquals(CommonJourneyStates.FACTIVA_ELIGIBLE_SUCCESS, validator.successState());
        assertEquals(CommonJourneyStates.FACTIVA_ELIGIBLE_FAILURE, validator.failureState());
        assertTrue(validator.isMandatory());
    }
}