package com.hdfcbank.giftcity.bff.application.service.impl;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hdfcbank.common.models.vo.core.ApiResponseStatus;
import com.hdfcbank.common.models.vo.journey.JourneyData;
import com.hdfcbank.common.models.vo.journey.JourneyState;
import com.hdfcbank.giftcity.bff.application.events.SqsCustomerSubmitPayload;
import com.hdfcbank.giftcity.bff.application.service.BackgroundEventPublisherService;
import com.hdfcbank.giftcity.bff.commons.config.JourneyContextHolder;
import com.hdfcbank.giftcity.bff.commons.constant.CommonConstants;
import com.hdfcbank.giftcity.bff.commons.enums.CommonJourneyStates;
import com.hdfcbank.giftcity.bff.commons.exception.CustomValidationException;
import com.hdfcbank.giftcity.bff.commons.model.JourneyCustomerProjection;
import com.hdfcbank.giftcity.bff.commons.repository.JourneyRepository;
import com.hdfcbank.giftcity.bff.customer.config.CustomerApiProperties;
import com.hdfcbank.giftcity.bff.customer.model.ApplicationSubmitResponse;
import com.hdfcbank.giftcity.bff.customer.model.InquireSubmitResponse;

import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.mockito.*;

import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import software.amazon.awssdk.services.sqs.SqsClient;
import software.amazon.awssdk.services.sqs.model.*;

import java.time.LocalDate;
import java.time.ZoneId;
import java.util.*;

import static com.hdfcbank.giftcity.bff.application.events.BackgroundEvents.AOF_SUBMISSION_EMAIL_ALERT;
import static com.hdfcbank.giftcity.bff.application.events.BackgroundEvents.AOF_SUBMISSION_SMS_ALERT;
import static com.hdfcbank.common.models.constant.CommonConstants.JOURNEY_ID;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import ch.qos.logback.classic.Logger;
import ch.qos.logback.classic.Level;
import org.slf4j.LoggerFactory;

@ExtendWith(MockitoExtension.class)
class ApplicationServiceImplTest {

    @BeforeAll
    static void muteLogs() {
        Logger logger = (Logger) LoggerFactory.getLogger(ApplicationServiceImpl.class);
        logger.setLevel(Level.OFF);
    }

    @Mock private SqsClient applicationSubmit;
    @Mock private ObjectMapper objectMapper;
    @Mock private JourneyRepository journeyRepository;
    @Mock private BackgroundEventPublisherService backgroundEventPublisherService;
    @Mock private CustomerApiProperties customerApiProperties;

    @InjectMocks
    private ApplicationServiceImpl service;

    private static final String SUBMIT_QUEUE_URL = "https://sqs.aws.com/app-submit.fifo";

    @BeforeEach
    void setup() {
        ReflectionTestUtils.setField(service, "submitQueueUrl", SUBMIT_QUEUE_URL);
        JourneyContextHolder.clear();
    }

    @AfterEach
    void clearJourneyContext() {
        JourneyContextHolder.clear();
    }

    // ========================================================================
    // SUCCESS – applicationSubmit()
    // ========================================================================
    @Test
    @DisplayName("applicationSubmit(): Should publish submit message and return success response")
    void testApplicationSubmit() throws Exception {

        when(objectMapper.writeValueAsString(any(SqsCustomerSubmitPayload.class)))
                .thenReturn("{\"journeyId\":\"J100\"}");

        when(applicationSubmit.sendMessage(any(SendMessageRequest.class)))
                .thenReturn(
                        SendMessageResponse.builder()
                                .messageId("MSG-1")
                                .md5OfMessageBody("MD5-OK")
                                .build()
                );

        ApplicationSubmitResponse resp = service.applicationSubmit("J100");

        assertNotNull(resp);
        assertEquals(ApiResponseStatus.success().getCode(), resp.getStatus().getCode());
        assertEquals("J100", resp.getData().getJourneyId());
    }

    // ========================================================================
    // SUCCESS – publishSubmitMessage()
    // ========================================================================
    @Test
    @DisplayName("publishSubmitMessage(): Should send correct SQS request")
    void testPublishSubmitMessage() throws Exception {

        when(objectMapper.writeValueAsString(any(SqsCustomerSubmitPayload.class)))
                .thenReturn("{\"journeyId\":\"J600\"}");

        when(applicationSubmit.sendMessage(any(SendMessageRequest.class)))
                .thenReturn(
                        SendMessageResponse.builder()
                                .messageId("MID123")
                                .md5OfMessageBody("MD5123")
                                .build()
                );

        service.applicationSubmit("J600");

        ArgumentCaptor<SendMessageRequest> captor =
                ArgumentCaptor.forClass(SendMessageRequest.class);

        verify(applicationSubmit).sendMessage(captor.capture());
        SendMessageRequest req = captor.getValue();

        assertEquals(SUBMIT_QUEUE_URL, req.queueUrl());
        assertEquals("{\"journeyId\":\"J600\"}", req.messageBody());
        assertEquals("String", req.messageAttributes().get(JOURNEY_ID).dataType());
        assertEquals("J600", req.messageAttributes().get(JOURNEY_ID).stringValue());
    }

    // ========================================================================
    // FAILURE – JSON serialization error
    // ========================================================================
    @Test
    @DisplayName("publishSubmitMessage(): Should NOT call SQS if JSON serialization fails")
    void testPublishSubmitMessageException() throws Exception {

        when(objectMapper.writeValueAsString(any()))
                .thenThrow(new RuntimeException("JSON ERROR"));

        assertDoesNotThrow(() -> service.applicationSubmit("J300"));
        verify(applicationSubmit, never()).sendMessage(any(SendMessageRequest.class));
    }

    // ========================================================================
    // inquireSubmit() – Missing journey data
    // ========================================================================
    @Test
    @DisplayName("inquireSubmit(): Should throw when journey data missing")
    void testInquireSubmitMissingJourneyData() {
        JourneyContextHolder.clear();
        assertThrows(CustomValidationException.class,
                () -> service.inquireSubmit("J400"));
    }

    // ========================================================================
    // inquireSubmit() – IN_PROGRESS
    // ========================================================================
    @Test
    @DisplayName("inquireSubmit(): Should return IN_PROGRESS when success state missing")
    void testInquireSubmitInProgress() {

        JourneyState js = new JourneyState();
        js.setStateName("OTHER_STATE");

        JourneyData jd = new JourneyData();
        jd.setJourneyDetail(new com.hdfcbank.common.models.vo.journey.JourneyDetail());
        jd.getJourneyDetail().setJourneyStates(List.of(js));
        jd.setReferenceNo("APP123");

        JourneyContextHolder.setJourneyData(jd);

        InquireSubmitResponse resp = service.inquireSubmit("J500");

        assertEquals(InquireSubmitResponse.SubmitStatus.IN_PROGRESS,
                resp.getData().getStatus());
        assertEquals("APP123", resp.getData().getApplicationNumber());
    }

    // ========================================================================
    // inquireSubmit() – SUCCESS
    // ========================================================================
    @Test
    @DisplayName("inquireSubmit(): Should return SUCCESS when success state present")
    void testInquireSubmitSuccess() {

        JourneyState js = new JourneyState();
        js.setStateName(CommonJourneyStates.CREATE_APPLICATION_NUMBER_SUCCESS.name());

        JourneyData jd = new JourneyData();
        jd.setJourneyDetail(new com.hdfcbank.common.models.vo.journey.JourneyDetail());
        jd.getJourneyDetail().setJourneyStates(List.of(js));
        jd.setReferenceNo("APP999");

        JourneyContextHolder.setJourneyData(jd);

        InquireSubmitResponse resp = service.inquireSubmit("J600");

        assertEquals(InquireSubmitResponse.SubmitStatus.SUCCESS,
                resp.getData().getStatus());
        assertEquals("APP999", resp.getData().getApplicationNumber());
    }

    // ========================================================================
    // processAofSubmissionAlertReminders() – SMS & EMAIL
    // ========================================================================
    @Test
    @DisplayName("processAofSubmissionAlertReminders(): Should trigger SMS and EMAIL alerts")
    void testProcessAofSubmissionAlertReminders() {

        // ---- Reminder config mocks ----
        Map<String, String> smsDefaults = Map.of(
                CommonConstants.FIRST_REMINDER_DAY, "1",
                CommonConstants.SECOND_REMINDER_DAY, "3",
                CommonConstants.THIRD_REMINDER_DAY, "5",
                CommonConstants.MAX_REMINDER_ELIGIBILITY_DAYS, "10"
        );

        Map<String, String> emailDefaults = Map.of(
                CommonConstants.FIRST_REMINDER_DAY, "1",
                CommonConstants.SECOND_REMINDER_DAY, "3",
                CommonConstants.THIRD_REMINDER_DAY, "5",
                CommonConstants.MAX_REMINDER_ELIGIBILITY_DAYS, "10"
        );

        CustomerApiProperties.ApiDetails smsDetails = new CustomerApiProperties.ApiDetails();
        smsDetails.setServiceDefaults(smsDefaults);

        CustomerApiProperties.ApiDetails emailDetails = new CustomerApiProperties.ApiDetails();
        emailDetails.setServiceDefaults(emailDefaults);

        when(customerApiProperties.getAofPendingDocumentSmsAlert()).thenReturn(smsDetails);
        when(customerApiProperties.getAofPendingDocumentEmailAlert()).thenReturn(emailDetails);

        // ---- Journey projection ----
        JourneyCustomerProjection.JourneyStateProjection submitState =
                new JourneyCustomerProjection.JourneyStateProjection();

        submitState.setStateName(CommonJourneyStates.FTS_SUCCESS_CALLBACK.name());
        submitState.setCreatedOn(
                Date.from(LocalDate.now().minusDays(1)
                        .atStartOfDay(ZoneId.systemDefault()).toInstant())
        );

        JourneyCustomerProjection.ProfilesProjection profile =
                new JourneyCustomerProjection.ProfilesProjection();
        profile.setCustomerId("CUST-101");

        JourneyCustomerProjection.FcIndiaProfileProjection fc =
                new JourneyCustomerProjection.FcIndiaProfileProjection();
        fc.setProfiles(List.of(profile));

        JourneyCustomerProjection.SystemDataProjection sys =
                new JourneyCustomerProjection.SystemDataProjection();
        sys.setFcIndiaProfile(fc);

        JourneyCustomerProjection.JourneyDetailProjection detail =
                new JourneyCustomerProjection.JourneyDetailProjection();
        detail.setSystemData(sys);
        detail.setJourneyStates(List.of(submitState));

        JourneyCustomerProjection journey = new JourneyCustomerProjection();
        journey.setId("JX001");
        journey.setJourneyDetail(detail);

        when(journeyRepository.findEligibleJourneys(
                any(Date.class),
                eq(CommonJourneyStates.FTS_SUCCESS_CALLBACK.name()),
                eq(CommonJourneyStates.FTS_DOCS_RECEIVED_CALLBACK.name())
        )).thenReturn(List.of(journey));

        // ---- Execute ----
        service.processAofSubmissionAlertReminders();

        // ---- Verify SMS ----
        verify(backgroundEventPublisherService, times(1))
                .sendBackgroundEvent(
                        eq("JX001"),
                        eq("CUST-101"),
                        eq(AOF_SUBMISSION_SMS_ALERT),
                        anyMap()
                );

        // ---- Verify EMAIL ----
        verify(backgroundEventPublisherService, times(1))
                .sendBackgroundEvent(
                        eq("JX001"),
                        eq("CUST-101"),
                        eq(AOF_SUBMISSION_EMAIL_ALERT),
                        anyMap()
                );
    }

    @Test
    void applicationSubmit_shouldKeepExistingSuccessResponseWhenSqsFails() throws Exception {
        when(objectMapper.writeValueAsString(any())).thenReturn("{}");
        when(applicationSubmit.sendMessage(any(SendMessageRequest.class)))
                .thenThrow(new IllegalStateException("SQS unavailable"));

        ApplicationSubmitResponse response = assertDoesNotThrow(() -> service.applicationSubmit("J-FAIL"));

        assertEquals(ApiResponseStatus.success().getCode(), response.getStatus().getCode());
        assertEquals("J-FAIL", response.getData().getJourneyId());
        verify(applicationSubmit).sendMessage(any(SendMessageRequest.class));
    }

    @Test
    void inquireSubmit_shouldRejectMissingJourneyDetail() {
        JourneyContextHolder.setJourneyData(new JourneyData());

        assertThrows(CustomValidationException.class, () -> service.inquireSubmit("J-MISSING"));
    }

    @Test
    void inquireSubmit_shouldRejectMissingJourneyStates() {
        JourneyData journey = new JourneyData();
        journey.setJourneyDetail(new com.hdfcbank.common.models.vo.journey.JourneyDetail());
        JourneyContextHolder.setJourneyData(journey);

        assertThrows(CustomValidationException.class, () -> service.inquireSubmit("J-MISSING"));
    }

    @ParameterizedTest
    @CsvSource({
            "1, SMS, gca-sms-alert-1-send",
            "3, SMS, gca-sms-alert-2-send",
            "5, SMS, gca-sms-alert-3-send",
            "2, EMAIL, gca-mail-alert-1-send",
            "4, EMAIL, gca-mail-alert-2-send",
            "6, EMAIL, gca-mail-alert-3-send",
            "7, NONE, unused"
    })
    void reminders_shouldUseEachChannelsScheduleAndTemplate(int days, String channel, String template) {
        configureReminders();
        LocalDate today = LocalDate.of(2026, 6, 15);
        JourneyCustomerProjection journey = reminderJourney(today.minusDays(days), true);
        when(journeyRepository.findEligibleJourneys(any(Date.class), anyString(), anyString()))
                .thenReturn(List.of(journey));

        try (MockedStatic<LocalDate> dates = mockStatic(LocalDate.class, CALLS_REAL_METHODS)) {
            dates.when(LocalDate::now).thenReturn(today);
            service.processAofSubmissionAlertReminders();
        }

        if ("SMS".equals(channel)) {
            verify(backgroundEventPublisherService).sendBackgroundEvent("J-REMINDER", "C-REMINDER",
                    AOF_SUBMISSION_SMS_ALERT, Map.of(CommonConstants.SMS_TEMPLATE, template));
        } else if ("EMAIL".equals(channel)) {
            verify(backgroundEventPublisherService).sendBackgroundEvent("J-REMINDER", "C-REMINDER",
                    AOF_SUBMISSION_EMAIL_ALERT, Map.of(CommonConstants.EMAIL_TEMPLATE, template));
        }
        verifyNoMoreInteractions(backgroundEventPublisherService);
    }

    @Test
    void reminders_shouldSkipJourneyWithoutSuccessfulFtsCallback() {
        configureReminders();
        when(journeyRepository.findEligibleJourneys(any(Date.class), anyString(), anyString()))
                .thenReturn(List.of(reminderJourney(LocalDate.of(2026, 6, 14), false)));

        service.processAofSubmissionAlertReminders();

        verifyNoInteractions(backgroundEventPublisherService);
    }

    @Test
    void reminders_shouldUseLargerEligibilityWindowAndHandleEmptyResults() {
        configureReminders();
        when(journeyRepository.findEligibleJourneys(any(Date.class), anyString(), anyString()))
                .thenReturn(List.of());
        long earliestCutoff = System.currentTimeMillis() - java.time.Duration.ofDays(10).toMillis();

        service.processAofSubmissionAlertReminders();

        long latestCutoff = System.currentTimeMillis() - java.time.Duration.ofDays(10).toMillis();
        ArgumentCaptor<Date> cutoff = ArgumentCaptor.forClass(Date.class);
        verify(journeyRepository).findEligibleJourneys(cutoff.capture(),
                eq(CommonJourneyStates.FTS_SUCCESS_CALLBACK.name()),
                eq(CommonJourneyStates.FTS_DOCS_RECEIVED_CALLBACK.name()));
        assertTrue(cutoff.getValue().getTime() >= earliestCutoff);
        assertTrue(cutoff.getValue().getTime() <= latestCutoff);
        verifyNoInteractions(backgroundEventPublisherService);
    }

    private void configureReminders() {
        CustomerApiProperties.ApiDetails sms = new CustomerApiProperties.ApiDetails();
        sms.setServiceDefaults(Map.of(CommonConstants.FIRST_REMINDER_DAY, "1",
                CommonConstants.SECOND_REMINDER_DAY, "3", CommonConstants.THIRD_REMINDER_DAY, "5",
                CommonConstants.MAX_REMINDER_ELIGIBILITY_DAYS, "7"));
        CustomerApiProperties.ApiDetails email = new CustomerApiProperties.ApiDetails();
        email.setServiceDefaults(Map.of(CommonConstants.FIRST_REMINDER_DAY, "2",
                CommonConstants.SECOND_REMINDER_DAY, "4", CommonConstants.THIRD_REMINDER_DAY, "6",
                CommonConstants.MAX_REMINDER_ELIGIBILITY_DAYS, "10"));
        when(customerApiProperties.getAofPendingDocumentSmsAlert()).thenReturn(sms);
        when(customerApiProperties.getAofPendingDocumentEmailAlert()).thenReturn(email);
    }

    private JourneyCustomerProjection reminderJourney(LocalDate submittedOn, boolean hasCallback) {
        JourneyCustomerProjection.JourneyStateProjection state =
                new JourneyCustomerProjection.JourneyStateProjection();
        state.setStateName(CommonJourneyStates.FTS_SUCCESS_CALLBACK.name());
        state.setCreatedOn(Date.from(submittedOn.atStartOfDay(ZoneId.systemDefault()).toInstant()));
        JourneyCustomerProjection.ProfilesProjection profile = new JourneyCustomerProjection.ProfilesProjection();
        profile.setCustomerId("C-REMINDER");
        JourneyCustomerProjection.FcIndiaProfileProjection fc = new JourneyCustomerProjection.FcIndiaProfileProjection();
        fc.setProfiles(List.of(profile));
        JourneyCustomerProjection.SystemDataProjection data = new JourneyCustomerProjection.SystemDataProjection();
        data.setFcIndiaProfile(fc);
        JourneyCustomerProjection.JourneyDetailProjection detail = new JourneyCustomerProjection.JourneyDetailProjection();
        detail.setSystemData(data);
        detail.setJourneyStates(hasCallback ? List.of(state) : List.of());
        JourneyCustomerProjection journey = new JourneyCustomerProjection();
        journey.setId("J-REMINDER");
        journey.setJourneyDetail(detail);
        return journey;
    }
}
