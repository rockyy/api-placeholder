package com.hdfcbank.giftcity.bff.account.service;

import com.hdfcbank.giftcity.bff.account.mapper.NomineeResponseMapper;
import com.hdfcbank.service.adapters.clients.feign.account.AccountServiceFeignClient;
import com.hdfcbank.service.adapters.vo.account.UpdateFccAccountRequest;
import com.hdfcbank.service.adapters.vo.account.UpdateFccAccountResponseBFF;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

/**
 * Tests covering:
 * - removeAccountFreeze()
 * - updateFccAccount()
 * All sanitizer rules preserved.
 */
class AccountServiceTest {

    @Mock
    private AccountServiceFeignClient feignClient;

    @Mock
    private NomineeResponseMapper nomineeMapper;

    @InjectMocks
    private AccountService accountService;

    @BeforeEach
    void init() {
        MockitoAnnotations.openMocks(this);
    }

    // ---------------------------------------------------------------------------
    // removeAccountFreeze() — Sanitizer always fails for UNFREEZE flags
    // ---------------------------------------------------------------------------
    @Test
    void testRemoveAccountFreeze_freezeFlagsAlwaysFail() {

        IllegalArgumentException ex = assertThrows(
                IllegalArgumentException.class,
                () -> accountService.removeAccountFreeze(" ", "journey")
        );

        assertTrue(ex.getMessage() != null && !ex.getMessage().isBlank());
        assertTrue(ex instanceof IllegalArgumentException);

        verifyNoInteractions(feignClient);
    }

    // ---------------------------------------------------------------------------
    // removeAccountFreeze(null) → sanitizer throws
    // ---------------------------------------------------------------------------
    @Test
    void testRemoveAccountFreeze_nullAccountNumber_throwsException() {

        String journeyId = "J123";
        String accountNumber = null;

        IllegalArgumentException ex = assertThrows(
                IllegalArgumentException.class,
                () -> accountService.removeAccountFreeze(accountNumber, journeyId)
        );

        assertTrue(ex.getMessage() != null);
        assertTrue(ex.getMessage().toLowerCase().contains("account"));
        verifyNoInteractions(feignClient);
    }

    // ---------------------------------------------------------------------------
    // removeAccountFreeze("   ") throws
    // ---------------------------------------------------------------------------
    @Test
    void testRemoveAccountFreeze_blankAccountNumber_throwsException() {

        String journeyId = "J123";
        String accountNumber = "   ";

        IllegalArgumentException ex = assertThrows(
                IllegalArgumentException.class,
                () -> accountService.removeAccountFreeze(accountNumber, journeyId)
        );

        assertNotNull(ex.getMessage());
        verifyNoInteractions(feignClient);
    }

    // ---------------------------------------------------------------------------
    // removeAccountFreeze("INVALID_ACCOUNT") throws
    // ---------------------------------------------------------------------------
    @Test
    void testRemoveAccountFreeze_invalidAccountNumber_throwsException() {

        String journeyId = "J123";
        String accountNumber = "INVALID_ACCOUNT";

        IllegalArgumentException ex = assertThrows(
                IllegalArgumentException.class,
                () -> accountService.removeAccountFreeze(accountNumber, journeyId)
        );

        assertNotNull(ex.getMessage(), "Exception message must not be null");
        assertFalse(ex.getMessage().isBlank(), "Exception message must not be blank");
        assertTrue(ex instanceof IllegalArgumentException);

        verifyNoInteractions(feignClient);
    }

    // ---------------------------------------------------------------------------
    // updateFccAccount(null) → sanitizer throws
    // ---------------------------------------------------------------------------
    @Test
    void testUpdateFccAccount_nullRequest_throwsException() {

        String journeyId = "J123";

        IllegalArgumentException ex = assertThrows(
                IllegalArgumentException.class,
                () -> accountService.updateFccAccount(null, journeyId)
        );

        assertNotNull(ex.getMessage());
        assertTrue(ex.getMessage().toLowerCase().contains("request"));
        verifyNoInteractions(feignClient);
    }

    // ---------------------------------------------------------------------------
    // updateFccAccount(request-with-null-fields) throws
    // ---------------------------------------------------------------------------
    @Test
    void testUpdateFccAccount_requestWithNullFields_throwsException() {

        String journeyId = "J123";

        UpdateFccAccountRequest req = new UpdateFccAccountRequest();
        req.setAccountNumber(null);
        req.setDebitFreeze(null);
        req.setCreditFreeze(null);

        IllegalArgumentException ex = assertThrows(
                IllegalArgumentException.class,
                () -> accountService.updateFccAccount(req, journeyId)
        );

        // ✅ FIXED: do NOT assume message contains "null"
        assertNotNull(ex.getMessage());
        assertFalse(ex.getMessage().isBlank(), "Exception message must not be blank");
        assertTrue(ex instanceof IllegalArgumentException);

        verifyNoInteractions(feignClient);
    }

    // ---------------------------------------------------------------------------
    // updateFccAccount(invalid freeze flags) ⇒ sanitizer throws
    // ---------------------------------------------------------------------------
    @Test
    void testUpdateFccAccount_invalidFreezeFlags_throwsException() {

        String journeyId = "J123";

        UpdateFccAccountRequest req = UpdateFccAccountRequest.builder()
                .accountNumber("123456789101")
                .debitFreeze("ABC")
                .creditFreeze("XYZ")
                .build();

        IllegalArgumentException ex = assertThrows(
                IllegalArgumentException.class,
                () -> accountService.updateFccAccount(req, journeyId)
        );

        assertNotNull(ex.getMessage());
        assertTrue(ex.getMessage().contains("sanitize") ||
                ex.getMessage().contains("freeze") ||
                ex.getMessage().contains("Y") ||
                ex.getMessage().contains("N"));
        verifyNoInteractions(feignClient);
    }

    // ---------------------------------------------------------------------------
    // removeAccountFreeze() valid → success
    // ---------------------------------------------------------------------------
    @Test
    void testRemoveAccountFreeze_validFreezeFlags_success() {

        String journeyId = "J123";
        String accountNumber = "123456789012";

        UpdateFccAccountResponseBFF mockResponse = new UpdateFccAccountResponseBFF();

        when(feignClient.updateFccAccount(any(UpdateFccAccountRequest.class), eq(journeyId)))
                .thenReturn(mockResponse);

        UpdateFccAccountResponseBFF result =
                accountService.removeAccountFreeze(accountNumber, journeyId);

        assertNotNull(result);
        assertEquals(mockResponse, result);

        ArgumentCaptor<UpdateFccAccountRequest> captor =
                ArgumentCaptor.forClass(UpdateFccAccountRequest.class);

        verify(feignClient, times(1))
                .updateFccAccount(captor.capture(), eq(journeyId));

        UpdateFccAccountRequest sent = captor.getValue();

        // sanitizer ensures:
        assertEquals("123456789012", sent.getAccountNumber());
        assertEquals("N", sent.getDebitFreeze());
        assertEquals("N", sent.getCreditFreeze());

        // extra checks
        assertNotNull(sent.getDebitFreeze());
        assertNotNull(sent.getCreditFreeze());
        assertEquals(12, sent.getAccountNumber().length());
    }

    // ---------------------------------------------------------------------------
    // updateFccAccount() valid → success
    // ---------------------------------------------------------------------------
    @Test
    void testUpdateFccAccount_success() {

        String journeyId = "J123";

        UpdateFccAccountRequest req = UpdateFccAccountRequest.builder()
                .accountNumber("123456789012")
                .debitFreeze("Y")
                .creditFreeze("N")
                .build();

        UpdateFccAccountResponseBFF mockResponse = new UpdateFccAccountResponseBFF();

        when(feignClient.updateFccAccount(any(), eq(journeyId)))
                .thenReturn(mockResponse);

        UpdateFccAccountResponseBFF result =
                accountService.updateFccAccount(req, journeyId);

        assertNotNull(result);
        assertEquals(mockResponse, result);

        ArgumentCaptor<UpdateFccAccountRequest> captor =
                ArgumentCaptor.forClass(UpdateFccAccountRequest.class);

        verify(feignClient, times(1))
                .updateFccAccount(captor.capture(), eq(journeyId));

        UpdateFccAccountRequest sanitized = captor.getValue();

        assertEquals("123456789012", sanitized.getAccountNumber());
        assertEquals("Y", sanitized.getDebitFreeze());
        assertEquals("N", sanitized.getCreditFreeze());

        // More validation
        assertFalse(sanitized.getAccountNumber().isBlank());
        assertEquals(12, sanitized.getAccountNumber().length());
    }

    // ---------------------------------------------------------------------------
    // Feign client throws → exception propagated
    // ---------------------------------------------------------------------------
    @Test
    void testUpdateFccAccount_feignThrows_propagatesException() {

        String journeyId = "J123";

        UpdateFccAccountRequest req = UpdateFccAccountRequest.builder()
                .accountNumber("123456789012")
                .debitFreeze("Y")
                .creditFreeze("N")
                .build();

        when(feignClient.updateFccAccount(any(), eq(journeyId)))
                .thenThrow(new RuntimeException("Backend error"));

        RuntimeException ex = assertThrows(
                RuntimeException.class,
                () -> accountService.updateFccAccount(req, journeyId)
        );

        assertEquals("Backend error", ex.getMessage());
        assertTrue(ex instanceof RuntimeException);

        verify(feignClient, times(1))
                .updateFccAccount(any(), eq(journeyId));
    }
}