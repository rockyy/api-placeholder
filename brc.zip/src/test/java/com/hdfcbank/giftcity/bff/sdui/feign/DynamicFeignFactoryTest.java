package com.hdfcbank.giftcity.bff.sdui.feign;

import com.hdfcbank.common.models.vo.mdc.MDCValues;
import com.hdfcbank.giftcity.bff.sdui.model.Header;
import feign.FeignException;
import feign.Request;
import feign.Response;
import feign.okhttp.OkHttpClient;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.MockedConstruction;
import org.mockito.MockedStatic;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.cloud.openfeign.support.FeignHttpMessageConverters;
import org.springframework.cloud.openfeign.support.SpringEncoder;

import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.mockConstruction;
import static org.mockito.Mockito.mockStatic;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

class DynamicFeignFactoryTest {

    @Test
    void getClient_shouldSendStandardHeadersWithoutCustomHeaders() throws Exception {
        Request request = executeRequest(null);

        assertEquals(List.of("Bearer access-token"), request.headers().get("Authorization"));
        assertEquals(List.of("application/json"), request.headers().get("Content-Type"));
        assertEquals(List.of("application/json"), request.headers().get("Accept"));
        assertEquals(List.of("test-agent"), request.headers().get("User-Agent"));
    }

    @Test
    void getClient_shouldForwardCustomHeaders() throws Exception {
        Request request = executeRequest(List.of(
                Header.builder().key("X-Correlation-ID").value("correlation-123").build()));

        assertEquals(List.of("correlation-123"), request.headers().get("X-Correlation-ID"));
        assertEquals(List.of("Bearer access-token"), request.headers().get("Authorization"));
        assertEquals("https://datasource.example.com", request.url().replaceAll("/$", ""));
    }

    private Request executeRequest(List<Header> headers) throws Exception {
        OkHttpClient transport = mock(OkHttpClient.class);
        @SuppressWarnings("unchecked")
        ObjectProvider<FeignHttpMessageConverters> converters = mock(ObjectProvider.class);
        when(transport.execute(any(Request.class), any(Request.Options.class))).thenAnswer(invocation ->
                Response.builder().request(invocation.getArgument(0))
                        .status(503).reason("Unavailable").headers(Map.of())
                        .body("Unavailable", StandardCharsets.UTF_8).build());

        // Isolate header construction from Spring's message-converter configuration.
        try (MockedConstruction<SpringEncoder> encoders = mockConstruction(SpringEncoder.class);
             MockedStatic<MDCValues> mdc = mockStatic(MDCValues.class)) {
            mdc.when(MDCValues::getAccessToken).thenReturn("access-token");
            mdc.when(MDCValues::getUserAgent).thenReturn("test-agent");
            DataSourceFeignClient client = new DynamicFeignFactory(transport, converters)
                    .getClient("https://datasource.example.com", headers);

            FeignException exception = assertThrows(FeignException.class,
                    () -> client.callDataSourceAPI(Map.of("id", 1)));

            assertEquals(503, exception.status());
            ArgumentCaptor<Request> request = ArgumentCaptor.forClass(Request.class);
            verify(transport).execute(request.capture(), any(Request.Options.class));
            return request.getValue();
        }
    }
}
