package com.hdfcbank.giftcity.bff.application.mapper;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hdfcbank.common.models.vo.journey.JourneyData;
import com.hdfcbank.common.models.vo.journey.Profile;
import com.hdfcbank.giftcity.bff.commons.model.FcGcProfile;
import com.hdfcbank.giftcity.bff.commons.model.FtsDetails;
import com.hdfcbank.giftcity.bff.customer.config.CustomerApiProperties;
import com.hdfcbank.giftcity.bff.customer.constants.CustomerConstants;
import com.hdfcbank.giftcity.bff.customer.utility.CustomerUtil;
import com.hdfcbank.service.adapters.vo.account.FTSAccountOpeningRequest;
import org.junit.jupiter.api.*;
import org.mapstruct.factory.Mappers;
import org.mockito.MockedStatic;

import java.lang.reflect.Field;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class FTSAccountOpeningMapperTest {

    private FTSAccountOpeningMapper mapper;

    private ObjectMapper objectMapper;
    private CustomerApiProperties customerApiProperties;
    private CustomerApiProperties.AOFDetails aofDetails;

    private MockedStatic<CustomerUtil> customerUtilMock;

    @BeforeEach
    void setup() throws Exception {
        mapper = Mappers.getMapper(FTSAccountOpeningMapper.class);

        objectMapper = mock(ObjectMapper.class);

        customerApiProperties = mock(CustomerApiProperties.class);
        aofDetails = mock(CustomerApiProperties.AOFDetails.class);
        when(customerApiProperties.getAofDetails()).thenReturn(aofDetails);

        // Inject dependencies using reflection
        inject("objectMapper", objectMapper);
        inject("customerApiProperties", customerApiProperties);

        customerUtilMock = mockStatic(CustomerUtil.class);
    }

    @AfterEach
    void tearDown() {
        customerUtilMock.close();
    }

    private void inject(String fieldName, Object value) throws Exception {
        Field field = mapper.getClass().getSuperclass().getDeclaredField(fieldName);
        field.setAccessible(true);
        field.set(mapper, value);
    }

      
    //   TEST: toFTSAccountOpeningRequest (MAIN MAPPER)
      
    @Test
    void testToFTSAccountOpeningRequest() {

        // Journey data
        JourneyData journeyData = JourneyData.builder()
                .referenceNo("REF123")
                .profile(Profile.builder().panNumber("ABCDE1234F").build())
                .build();

        // FcGcProfile returned via static util
        FcGcProfile fcGcProfile = FcGcProfile.builder()
                .accountNumber("ACCT999")
                .customerNumber("CUST999")
                .build();

        customerUtilMock.when(() -> CustomerUtil.getFCGiftCityProfile(journeyData))
                .thenReturn(Optional.of(fcGcProfile));

        FtsDetails ftsDetails = FtsDetails.builder()
                .uploadedZipFileLocation("/tmp/zip1.zip")
                .build();

        // Dummy holderInfo list
        List<FTSAccountOpeningRequest.HolderInfo> holders = List.of(
                FTSAccountOpeningRequest.HolderInfo.builder().customerId("C1").build()
        );

        FTSAccountOpeningRequest req = mapper.toFTSAccountOpeningRequest(
                journeyData,
                journeyData.getProfile(),
                ftsDetails,
                holders
        );

        assertEquals("REF123", req.getBarcode());
        assertEquals("ACCT999", req.getAccountNumber());
        assertEquals("ABCDE1234F", req.getPanNumber());
        assertEquals("/tmp/zip1.zip", req.getZipFilePath());
        assertEquals(holders, req.getHolderInfo());

        String today = LocalDate.now().format(DateTimeFormatter.ofPattern("dd-MMM-yyyy"));
        assertEquals(today, req.getAccountOpenedDate());
        assertEquals(today, req.getAccountActivationDate());

        assertEquals("", req.getAccountNo1());
        assertEquals("", req.getAccountNo2());
        assertEquals("", req.getAccountNo3());
        assertEquals("", req.getAccountNo4());
        assertEquals("", req.getLeadNumber());
        assertEquals("", req.getScanningLocation());
        assertEquals("Authorised", req.getCMatchedRemark());
        assertEquals("", req.getReimbursementAcno());
    }

      
    //   TEST: toHolderInfo (SECOND MAPPER)
      
    @Test
    void testToHolderInfo() {

        JourneyData journeyData = JourneyData.builder().build();

        Profile profile = Profile.builder()
                .fullName("Arijit Test")
                .dob("1990-01-01")
                .build();

        FcGcProfile fcGcProfile = FcGcProfile.builder()
                .customerNumber("CUST999")
                .build();

        customerUtilMock.when(() -> CustomerUtil.getFCGiftCityProfile(journeyData))
                .thenReturn(Optional.of(fcGcProfile));

        when(aofDetails.getDocValidation()).thenReturn("DOC-VALID");
        when(aofDetails.getAofOpeningDocId()).thenReturn("AOF-ID");
        when(aofDetails.getAccStatementDocId()).thenReturn("ACC-ID");
        when(aofDetails.getClientSignatureDocId()).thenReturn("SIG-ID");

        when(aofDetails.getAofOpeningFileName()).thenReturn("AOF-FILE");
        when(aofDetails.getAccStatementFileName()).thenReturn("ACC-FILE");
        when(aofDetails.getClientSignatureFileName()).thenReturn("SIG-FILE");

        FTSAccountOpeningRequest.HolderInfo info =
                mapper.toHolderInfo(journeyData, profile, "/img/x.png",
                        CustomerConstants.ACCOUNT_STATEMENT1_DOC_REF);

        assertEquals("CUST999", info.getCustomerId());
        assertEquals("Arijit Test", info.getCustomerName());
        assertEquals("/img/x.png", info.getImagePath());
        assertEquals("POA", info.getAofProofTagging());  // ACCOUNT_STATEMENT -> POA
        assertEquals("DOC-VALID", info.getDocValidation());
        assertEquals("ACC-FILE", info.getFileName());
        assertEquals("ACC-ID", info.getDocTypeId());
        assertEquals("01-Jan-1990", info.getCustomerDob());
    }

      
    //   TEST: getAofProofTagging
      
    @Test
    void testGetAofProofTagging() {
        assertEquals(
                CustomerConstants.AOF_PROOF_TAGGING_POA,
                mapper.getAofProofTagging(CustomerConstants.ACCOUNT_STATEMENT1_DOC_REF)
        );

        assertEquals(
                CustomerConstants.AOF_PROOF_TAGGING_OTHER,
                mapper.getAofProofTagging("UNKNOWN")
        );
    }

      
    //   TEST: getDocTypeId
      
    @Test
    void testGetDocTypeId() {

        when(aofDetails.getAofOpeningDocId()).thenReturn("OPEN-ID");
        when(aofDetails.getAccStatementDocId()).thenReturn("ACC-ID");
        when(aofDetails.getClientSignatureDocId()).thenReturn("SIG-ID");

        assertEquals("OPEN-ID",
                mapper.getDocTypeId(CustomerConstants.AOF_WITH_ANNEXTURE_DOC_REF));

        assertEquals("ACC-ID",
                mapper.getDocTypeId(CustomerConstants.ACCOUNT_STATEMENT1_DOC_REF));

        assertEquals("SIG-ID",
                mapper.getDocTypeId(CustomerConstants.CUSTOMER_SIGNATURE_DOC_REF));

        assertEquals("",
                mapper.getDocTypeId("UNKNOWN"));
    }

      
    //   TEST: getFileName
      
    @Test
    void testGetFileName() {

        when(aofDetails.getAofOpeningFileName()).thenReturn("OPEN-FILE");
        when(aofDetails.getAccStatementFileName()).thenReturn("ACC-FILE");
        when(aofDetails.getClientSignatureFileName()).thenReturn("SIG-FILE");

        assertEquals("OPEN-FILE",
                mapper.getFileName(CustomerConstants.AOF_WITH_ANNEXTURE_DOC_REF));

        assertEquals("ACC-FILE",
                mapper.getFileName(CustomerConstants.ACCOUNT_STATEMENT1_DOC_REF));

        assertEquals("SIG-FILE",
                mapper.getFileName(CustomerConstants.CUSTOMER_SIGNATURE_DOC_REF));

        assertEquals("",
                mapper.getFileName("UNKNOWN"));
    }

      
    //   TEST: getDocValidation
      
    @Test
    void testGetDocValidation() {
        when(aofDetails.getDocValidation()).thenReturn("VALID123");
        assertEquals("VALID123", mapper.getDocValidation());
    }

      
    //   TEST: formatDob
      
    @Test
    void testFormatDob() {
        assertEquals("01-Jan-1990", mapper.formatDob("1990-01-01"));
        assertNull(mapper.formatDob(null));
        assertNull(mapper.formatDob(""));
        assertNull(mapper.formatDob(" "));
    }
}