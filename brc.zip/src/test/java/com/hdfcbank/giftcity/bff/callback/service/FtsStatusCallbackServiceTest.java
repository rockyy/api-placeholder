package com.hdfcbank.giftcity.bff.callback.service;

import com.hdfcbank.giftcity.bff.application.events.BackgroundEvents;
import com.hdfcbank.giftcity.bff.application.service.BackgroundEventPublisherService;
import com.hdfcbank.giftcity.bff.callback.model.FtsStatusCallbackRequest;
import com.hdfcbank.giftcity.bff.callback.model.FtsStatusCallbackResponse;
import com.hdfcbank.giftcity.bff.callback.model.FtsCallbackPageData;
import com.hdfcbank.giftcity.bff.commons.enums.CommonJourneyStates;
import com.hdfcbank.giftcity.bff.commons.enums.JourneyPageName;
import com.hdfcbank.giftcity.bff.commons.model.FcGcProfile;
import com.hdfcbank.giftcity.bff.customer.service.CustomerService;
import com.hdfcbank.giftcity.bff.infrastructure.service.JourneyService;

import com.hdfcbank.common.models.vo.journey.JourneyData;
import com.hdfcbank.common.models.vo.journey.Profile;

import com.hdfcbank.service.adapters.vo.customer.CloseCustomerResponse;
import com.hdfcbank.service.adapters.vo.customer.CloseCustomerResponse.CloseCustomerData;
import com.hdfcbank.service.adapters.vo.account.TransactionStatus;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;
import com.hdfcbank.common.models.vo.mdc.MDCValues;

import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class FtsStatusCallbackServiceTest {

    @Mock private JourneyService journeyService;
    @Mock private CustomerService customerService;
    @Mock private BackgroundEventPublisherService backgroundEventPublisherService;

    @InjectMocks
    private FtsStatusCallbackService service;

    @AfterEach
    void clearMdc() {
        MDCValues.clear();
    }

    private JourneyData journey(String id, String customerId, String number) {
        JourneyData jd = new JourneyData();
        jd.setJourneyId(id);
        jd.setJourneyName("JourneyName");

        Profile p = new Profile();
        p.setCustomerId(customerId);
        p.setNumber(number);
        jd.setProfile(p);

        return jd;
    }

    private FtsStatusCallbackRequest req(String code) {
        FtsStatusCallbackRequest r = new FtsStatusCallbackRequest();
        r.setBarCode("BAR123");
        FtsStatusCallbackRequest.Status s = new FtsStatusCallbackRequest.Status();
        s.setCode(code);
        s.setDesc("DESC");
        r.setStatus(s);
        return r;
    }

    // ---------------- Tests ------------------

    @Test
    void testInvalidStatus() {
        FtsStatusCallbackResponse res = service.processFtsStatusCallback(req("999"));

        assertNotNull(res);
        assertEquals("BAR123", res.getData().getBarCode());
        verifyNoInteractions(journeyService, customerService, backgroundEventPublisherService);
    }

    @Test
    void testJourneyNotFound() {
        when(journeyService.fetchJourneyByReferenceNo("BAR123")).thenReturn(Optional.empty());

        FtsStatusCallbackResponse res = service.processFtsStatusCallback(req("000"));

        assertNotNull(res);
        assertEquals("BAR123", res.getData().getBarCode());
        verifyNoInteractions(customerService, backgroundEventPublisherService);
    }

    @Test
    void testSuccessCase() {
        JourneyData j = journey("J1", "CUST123", "CUSTNUM123");
        when(journeyService.fetchJourneyByReferenceNo("BAR123")).thenReturn(Optional.of(j));

        FtsStatusCallbackResponse res = service.processFtsStatusCallback(req("000"));

        assertNotNull(res);
        verify(journeyService).recordJourneyState("J1", CommonJourneyStates.FTS_SUCCESS_CALLBACK);
        verify(backgroundEventPublisherService).sendBackgroundEvent(
                "J1", "CUST123", BackgroundEvents.FCC_ACCOUNT_UNFREEZE, Map.of());
        verify(backgroundEventPublisherService).sendBackgroundEvent(
                "J1", "CUST123", BackgroundEvents.CUSTOMER_AOF_EMAIL_NOTIFY, Map.of());
        verify(backgroundEventPublisherService).sendBackgroundEvent(
                "J1", "CUST123", BackgroundEvents.PURGE_DOCUMENTS, Map.of());
        verifyNoMoreInteractions(backgroundEventPublisherService);

        ArgumentCaptor<FtsCallbackPageData> payload = ArgumentCaptor.forClass(FtsCallbackPageData.class);
        verify(journeyService).updateJourney(eq("J1"),
                eq(JourneyPageName.FTS_STATUS_CALLBACK.getPageName()), payload.capture(),
                eq(CommonJourneyStates.FTS_CALLBACK_RECEIVED));
        assertEquals("BAR123", payload.getValue().getBarCode());
        assertEquals("000", payload.getValue().getStatusCode());
        assertEquals("DESC", payload.getValue().getStatusDesc());
    }

    @Test
    void testReject_customerNumberMissing() {

        JourneyData j = journey("J2", "CUST123", null);
        when(journeyService.fetchJourneyByReferenceNo("BAR123")).thenReturn(Optional.of(j));

        try (MockedStatic<JourneyService> mocked = mockStatic(JourneyService.class)) {

            mocked.when(() -> JourneyService.extractFromJourney(
                    eq(j),
                    eq(JourneyPageName.CUSTOMER_FC_GIFT_CITY_DETAIL.getPageName()),
                    eq(FcGcProfile.class),
                    any()
            )).thenReturn(Optional.empty());

            FtsStatusCallbackResponse res = service.processFtsStatusCallback(req("888"));
            assertNotNull(res);

            verify(journeyService).recordJourneyState("J2", CommonJourneyStates.FTS_REJECT_CALLBACK);
            verifyNoInteractions(customerService);
        }
    }

    @Test
    void testReject_customerCloseSuccess() {

        JourneyData j = journey("J3", "CUST123", "CUSTNUM123");
        when(journeyService.fetchJourneyByReferenceNo("BAR123")).thenReturn(Optional.of(j));

        try (MockedStatic<JourneyService> mocked = mockStatic(JourneyService.class)) {

            mocked.when(() -> JourneyService.extractFromJourney(
                    any(), anyString(), eq(FcGcProfile.class), any()
            )).thenReturn(Optional.of("CUSTNUM123"));

            TransactionStatus ts = TransactionStatus.builder()
                    .status(TransactionStatus.SUCCESS)
                    .build();

            CloseCustomerData data = CloseCustomerData.builder()
                    .customerNumber("CUSTNUM123")
                    .transactionStatus(ts)
                    .build();

            CloseCustomerResponse cr = CloseCustomerResponse.builder().data(data).build();

            when(customerService.closeFccCustomer("CUSTNUM123", "J3"))
                    .thenReturn(cr);

            service.processFtsStatusCallback(req("888"));

            verify(journeyService).recordJourneyState("J3",
                    CommonJourneyStates.FCC_CLOSE_CUSTOMER_SUCCESS);
        }
    }

    @Test
    void testReject_customerCloseFailure() {

        JourneyData j = journey("J4", "CUST123", "CUSTNUM999");
        when(journeyService.fetchJourneyByReferenceNo("BAR123")).thenReturn(Optional.of(j));

        try (MockedStatic<JourneyService> mocked = mockStatic(JourneyService.class)) {

            mocked.when(() -> JourneyService.extractFromJourney(
                    any(), anyString(), eq(FcGcProfile.class), any()
            )).thenReturn(Optional.of("CUSTNUM999"));

            TransactionStatus ts = TransactionStatus.builder()
                    .status("FAILED")
                    .build();

            CloseCustomerData data = CloseCustomerData.builder()
                    .customerNumber("CUSTNUM999")
                    .transactionStatus(ts)
                    .build();

            CloseCustomerResponse cr = CloseCustomerResponse.builder().data(data).build();

            when(customerService.closeFccCustomer("CUSTNUM999", "J4"))
                    .thenReturn(cr);

            service.processFtsStatusCallback(req("888"));

            verify(journeyService).recordJourneyState("J4",
                    CommonJourneyStates.FCC_CLOSE_CUSTOMER_FAILURE);
        }
    }

    @Test
    void testOriginalsReceived() {
        JourneyData j = journey("J5", "CUST123", "CUSTNUM321");
        when(journeyService.fetchJourneyByReferenceNo("BAR123")).thenReturn(Optional.of(j));

        service.processFtsStatusCallback(req("900"));

        verify(journeyService).recordJourneyState("J5",
                CommonJourneyStates.FTS_DOCS_RECEIVED_CALLBACK);
    }

    @Test
    void testOriginalsNotReceived() {
        JourneyData j = journey("J6", "CUST123", "CUSTNUM456");
        when(journeyService.fetchJourneyByReferenceNo("BAR123")).thenReturn(Optional.of(j));

        service.processFtsStatusCallback(req("901"));

        verify(journeyService).recordJourneyState("J6",
                CommonJourneyStates.FTS_DOCS_NOT_RECEIVED_CALLBACK);
    }

    @Test
    void callbackSaveFailure_shouldPropagateBeforeBusinessProcessing() {
        JourneyData j = journey("J7", "CUST123", "CUSTNUM999");
        when(journeyService.fetchJourneyByReferenceNo("BAR123"))
                .thenReturn(Optional.of(j));

        RuntimeException failure = new RuntimeException("Journey unavailable");
        doThrow(failure).when(journeyService).updateJourney(eq("J7"),
                eq(JourneyPageName.FTS_STATUS_CALLBACK.getPageName()), any(FtsCallbackPageData.class),
                eq(CommonJourneyStates.FTS_CALLBACK_RECEIVED));

        assertSame(failure, assertThrows(RuntimeException.class,
                () -> service.processFtsStatusCallback(req("000"))));
        verify(journeyService, never()).recordJourneyState(anyString(), any());
        verifyNoInteractions(customerService, backgroundEventPublisherService);
    }

    @Test
    void testProcessChecksExceptionIsCaught() {

        JourneyData j = journey("J200", "CUST_X", "CUSTNUM_X");
        when(journeyService.fetchJourneyByReferenceNo("BAR123"))
                .thenReturn(Optional.of(j));

        // Simulate failure when background event is sent
        doThrow(new RuntimeException("boom"))
                .when(backgroundEventPublisherService)
                .sendBackgroundEvent(any(), any(), any(), anyMap());

        FtsStatusCallbackResponse res = service.processFtsStatusCallback(req("000"));

        assertNotNull(res);

        verify(journeyService).recordJourneyState(
                eq("J200"),
                eq(CommonJourneyStates.FTS_CALLBACK_PROCESSING_FAILED)
        );
    }

    @Test
    void reject_shouldRecordCloseFailureWhenResponseIsNull() {
        assertCustomerCloseFailure(null);
    }

    @Test
    void reject_shouldRecordCloseFailureWhenDataIsNull() {
        assertCustomerCloseFailure(CloseCustomerResponse.builder().build());
    }

    @Test
    void reject_shouldRecordCloseFailureWhenTransactionStatusIsNull() {
        assertCustomerCloseFailure(CloseCustomerResponse.builder()
                .data(CloseCustomerData.builder().customerNumber("CUSTNUM123").build())
                .build());
    }

    private void assertCustomerCloseFailure(CloseCustomerResponse response) {
        JourneyData journeyData = journey("J-CLOSE", "CUST123", "CUSTNUM123");
        when(journeyService.fetchJourneyByReferenceNo("BAR123"))
                .thenReturn(Optional.of(journeyData));
        when(customerService.closeFccCustomer("CUSTNUM123", "J-CLOSE"))
                .thenReturn(response);

        try (MockedStatic<JourneyService> mocked = mockStatic(JourneyService.class)) {
            mocked.when(() -> JourneyService.extractFromJourney(
                    eq(journeyData), anyString(), eq(FcGcProfile.class), any()))
                    .thenReturn(Optional.of("CUSTNUM123"));

            FtsStatusCallbackResponse acknowledgement = service.processFtsStatusCallback(req("888"));

            assertEquals("BAR123", acknowledgement.getData().getBarCode());
            verify(customerService).closeFccCustomer("CUSTNUM123", "J-CLOSE");
            verify(journeyService).recordJourneyState(
                    "J-CLOSE", CommonJourneyStates.FCC_CLOSE_CUSTOMER_FAILURE);
            verify(journeyService, never()).recordJourneyState(
                    anyString(), eq(CommonJourneyStates.FCC_CLOSE_CUSTOMER_SUCCESS));
        }
    }
}
