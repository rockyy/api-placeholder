# Insurance BFF unit tests

Tests follow the current production classes, request constraints, and journey states. Production sources are unchanged. The POM and Sonar properties share the existing Sonar analysis exclusions and report paths.

## Run

Use JDK 25 and Maven with the team's repository settings for the private HDFC artifacts, including `com.hdfcbank:iop-insurance-adapter:0.0.3-release`:

```sh
mvn -s /path/to/settings.xml clean verify
```

For an exported source directory without `.git`, append `-Dmaven.gitcommitid.skip=true`. This skips only Git metadata generation.

Maven Surefire writes test results to `target/surefire-reports`. The test lifecycle generates JaCoCo HTML and XML coverage reports in `target/site/jacoco` after Surefire completes. Sonar imports `target/site/jacoco/jacoco.xml` for coverage and `target/surefire-reports` for test execution results. `mvn verify` additionally enforces the inherited per-package thresholds: 80% line coverage and 50% branch coverage. Use `mvn test` when only tests and reports are needed.

JaCoCo agent, report, and check exclusions match the existing Sonar policy, including `mapper` packages and the application class. Tests for those classes still run, but those classes do not contribute to the reported coverage. Coverage percentages using this scope are not directly comparable with earlier reports that included them. Keep `jacoco.exclusions`, the individual JaCoCo exclude entries, and both Sonar exclusion properties aligned when changing the policy.

## Scope

- Loan identification, STATIC/DYNAMIC identifiers, masking, loan details, cancellation, KFS, e-sign status/resend, and final proposal payload/persistence.
- Product decision parameters, catalog mapping, pricing request reuse, answer defaults/lookups, EMI calculations, and failure propagation.
- Proposal submission and LG/LC details, callback dispatch and persistence, and scheduler status processing.
- OTP generation/validation, accepted and declined consents, SQS message contents, and cooling-period persistence.
- Custom request validators, standalone MVC JSON binding/validation, settings merging/cache behavior, checksum normalization, nominee age boundaries, and journey path helpers.
- Journey prerequisite advice through a real Spring AOP proxy, including context cleanup on success and failure; process/communication response-code handling.
- Proposal questions grouped by borrower and property, quote fallback, nominee options, combined product coverage/tenure, policy links, and configured pricing-answer expressions.
- Controller success contracts, downstream request/channel/journey routing, failure persistence, exception/drop-off responses, property binding, cache behavior, and executor/scheduler lifecycle.

Service tests mock remote clients and repositories. Pricing and scheduler processing execute inline; executor lifecycle tests shut down the real executors they create. Tests make no network, MongoDB, Redis, SQS, or config-server connections. Standalone MVC tests exercise binding and `@Valid`; they do not exercise the application's security filters or cooling-period aspects from dependencies.

The suite tests supported current behavior. The production gaps found in the review (pricing response freshness, reference/journey identifier consistency, retry bookkeeping, nested validation wiring, failure-recorder initialization and failure-context cleanup) are still separate production changes. Coverage must be checked with the JaCoCo gate; passing tests alone do not establish coverage compliance or resolve those gaps.
