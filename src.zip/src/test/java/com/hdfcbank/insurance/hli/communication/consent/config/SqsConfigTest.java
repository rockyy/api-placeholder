package com.hdfcbank.insurance.hli.communication.consent.config;

import org.junit.jupiter.api.Test;
import org.springframework.test.util.ReflectionTestUtils;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.sqs.SqsClient;
import software.amazon.awssdk.services.sqs.SqsClientBuilder;
import java.net.URI;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class SqsConfigTest {
    @Test
    void createsConsentsClientWithConfiguredRegionAndEndpoint() {
        var aws = new AwsProperties();
        aws.setRegion("ap-south-1");
        var consents = new ConsentsApiProperties();
        consents.setQueueUrl("https://sqs.example.test/consents");
        var config = new SqsConfig();
        ReflectionTestUtils.setField(config, "awsProperties", aws);
        ReflectionTestUtils.setField(config, "consentsApiProperties", consents);
        var builder = mock(SqsClientBuilder.class, RETURNS_SELF);
        var client = mock(SqsClient.class);
        when(builder.build()).thenReturn(client);
        try (var factory = mockStatic(SqsClient.class)) {
            factory.when(SqsClient::builder).thenReturn(builder);
            assertSame(client, config.sqsClient());
        }
        verify(builder).region(Region.AP_SOUTH_1);
        verify(builder).endpointOverride(URI.create("https://sqs.example.test/consents"));
        verify(builder).build();
    }
}
