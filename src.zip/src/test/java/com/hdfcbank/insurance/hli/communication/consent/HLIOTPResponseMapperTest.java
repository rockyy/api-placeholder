package com.hdfcbank.insurance.hli.communication.consent;

import com.hdfcbank.insurance.adapter.communication.response.GenerateOTPResponse;
import org.junit.jupiter.api.Test;
import org.mapstruct.factory.Mappers;
import static org.junit.jupiter.api.Assertions.*;

class HLIOTPResponseMapperTest {
    private final HLIOTPResponseMapper mapper = Mappers.getMapper(HLIOTPResponseMapper.class);

    @Test
    void preservesTransactionReferenceAndLeavesAttemptCountersForCoolingAspect() {
        var response = mapper.otpResponseMapper(GenerateOTPResponse.builder().txnRef("TXN123").build());
        assertEquals("TXN123", response.getTxnRef());
        assertNull(response.getRetryOtpAttemptsConsumed());
        assertNull(response.getVerifyOtpAttemptsLeft());
    }

    @Test
    void missingDownstreamDataProducesNoMappedResponse() { assertNull(mapper.otpResponseMapper(null)); }
}
