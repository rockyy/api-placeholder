package com.hdfcbank.insurance.hli.process.service;

import com.hdfcbank.common.models.vo.core.ApiResponse;
import com.hdfcbank.insurance.adapter.process.clients.feign.insurance.HLIProcessLayerFeignClient;
import com.hdfcbank.insurance.adapter.process.models.request.*;
import com.hdfcbank.insurance.adapter.process.models.response.*;
import com.hdfcbank.insurance.hli.common.core.ProcessLayerAPIResponseValidator;
import com.hdfcbank.insurance.hli.common.core.properties.HLIStatusCodes;
import com.hdfcbank.insurance.hli.common.properties.HLIAppProperties;
import com.hdfcbank.insurance.hli.process.service.impl.ProcessServiceCall;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.context.ApplicationContext;
import static com.hdfcbank.insurance.hli.support.JourneyTestData.JOURNEY_ID;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ProcessServiceCallTest {
    @Mock private HLIProcessLayerFeignClient client;
    private ProcessServiceCall service;

    @BeforeEach
    void setUp() {
        var properties = new HLIAppProperties();
        properties.setChannel("WEB");
        service = new ProcessServiceCall(client, properties);
        var context = mock(ApplicationContext.class);
        lenient().when(context.getBean(HLIStatusCodes.class)).thenReturn(new HLIStatusCodes());
        new ProcessLayerAPIResponseValidator().setApplicationContext(context);
    }

    @AfterEach
    void cleanUp() { new ProcessLayerAPIResponseValidator().setApplicationContext(null); }

    @Test
    void premiumQuestionsPreservesPayloadChannelAndJourneyIdentifier() {
        var request = new PremiumQuestionRequest();
        var expected = new PremiumQuestionResponse();
        when(client.getPremiumQuestion(request, "WEB", JOURNEY_ID)).thenReturn(ApiResponse.success(expected));
        assertSame(expected, service.premiumQuestionServiceCall(JOURNEY_ID, request));
        verify(client).getPremiumQuestion(request, "WEB", JOURNEY_ID);
    }

    @Test
    void premiumAnswersPreservesPayloadChannelAndJourneyIdentifier() {
        var request = new SubmitPremiumAnswerRequest();
        var expected = new SubmitPremiumAnswerResponse();
        when(client.submitPremiumAnswer(request, JOURNEY_ID, "WEB")).thenReturn(ApiResponse.success(expected));
        assertSame(expected, service.submitPremiumAnswerCall(JOURNEY_ID, request));
        verify(client).submitPremiumAnswer(request, JOURNEY_ID, "WEB");
    }

    @Test
    void pricingPreservesPayloadChannelAndJourneyIdentifier() {
        var request = new PricingRequest();
        var expected = new PricingResponse();
        when(client.getPricing(request, JOURNEY_ID, "WEB")).thenReturn(ApiResponse.success(expected));
        assertSame(expected, service.pricingServiceCall(JOURNEY_ID, request));
        verify(client).getPricing(request, JOURNEY_ID, "WEB");
    }

    @Test
    void loanDetailsPreservesPayloadChannelAndJourneyIdentifier() {
        var request = new GetLoanDetailRequest();
        var expected = new GetLoanDetailResponse();
        when(client.getLoanDetail(request, "WEB", JOURNEY_ID)).thenReturn(ApiResponse.success(expected));
        assertSame(expected, service.getLoanDetailCall(request, JOURNEY_ID));
        verify(client).getLoanDetail(request, "WEB", JOURNEY_ID);
    }

    @Test
    void proposalAnswersPreservesPayloadChannelAndJourneyIdentifier() {
        var request = new SubmitAnswerRequest();
        var expected = new SubmitAnswerResponse();
        when(client.submitProposalCall(request, JOURNEY_ID, "WEB")).thenReturn(ApiResponse.success(expected));
        assertSame(expected, service.submitAnswerProcessCall(request, JOURNEY_ID));
        verify(client).submitProposalCall(request, JOURNEY_ID, "WEB");
    }

    @Test
    void proposalQuestionsPreservesPayloadChannelAndJourneyIdentifier() {
        var request = new ProposalQuestionRequest();
        var expected = new ProposalQuestionResponse();
        when(client.getProposalQuestion(request, "WEB", JOURNEY_ID)).thenReturn(ApiResponse.success(expected));
        assertSame(expected, service.proposalQuestionProcessCall(request, JOURNEY_ID));
        verify(client).getProposalQuestion(request, "WEB", JOURNEY_ID);
    }

    @Test
    void identificationPreservesPayloadChannelAndJourneyIdentifier() {
        var request = new IdentifyRequest();
        var expected = new IdentifyResponse();
        when(client.identify(request, "WEB", JOURNEY_ID)).thenReturn(ApiResponse.success(expected));
        assertSame(expected, service.identifyServiceCall(request, JOURNEY_ID));
        verify(client).identify(request, "WEB", JOURNEY_ID);
    }

    @Test
    void recommendationsPreservesPayloadChannelAndJourneyIdentifier() {
        var request = new RecommendedProductRequest();
        var expected = new RecommendedProductResponse();
        when(client.getRecommendedProductsCall(request, JOURNEY_ID, "WEB")).thenReturn(ApiResponse.success(expected));
        assertSame(expected, service.recommendedProductCall(JOURNEY_ID, request));
        verify(client).getRecommendedProductsCall(request, JOURNEY_ID, "WEB");
    }

    @Test
    void catalogPreservesPayloadChannelAndJourneyIdentifier() {
        var request = new CurateProductRequest();
        var expected = new CurateProductResponse();
        when(client.getCurateProductsCall(request, JOURNEY_ID, "WEB")).thenReturn(ApiResponse.success(expected));
        assertSame(expected, service.curateProductCall(JOURNEY_ID, request));
        verify(client).getCurateProductsCall(request, JOURNEY_ID, "WEB");
    }

    @Test
    void contentPreservesPayloadChannelAndJourneyIdentifier() {
        var request = new ContentGroupRequest();
        var expected = new ContentGroupResponse();
        when(client.getContentGroupCall(request, JOURNEY_ID, "WEB")).thenReturn(expected);
        assertSame(expected, service.contentGroupCall(request, JOURNEY_ID));
        verify(client).getContentGroupCall(request, JOURNEY_ID, "WEB");
    }

    @Test
    void kfsPreservesPayloadChannelAndJourneyIdentifier() {
        var request = new KFSDetailRequest();
        var expected = new KFSDetailResponse();
        when(client.getKFSDetails(request, JOURNEY_ID, "WEB")).thenReturn(ApiResponse.success(expected));
        assertSame(expected, service.getKFSDetailCall(request, JOURNEY_ID));
        verify(client).getKFSDetails(request, JOURNEY_ID, "WEB");
    }

    @Test
    void esignInitiationPreservesPayloadChannelAndJourneyIdentifier() {
        var request = new InitiateEsignRequest();
        var expected = new InitiateEsignResponse();
        when(client.initiateEsign(request, "WEB", JOURNEY_ID)).thenReturn(ApiResponse.success(expected));
        assertSame(expected, service.initiateEsignCall(request, JOURNEY_ID));
        verify(client).initiateEsign(request, "WEB", JOURNEY_ID);
    }

    @Test
    void esignResendPreservesPayloadChannelAndJourneyIdentifier() {
        var request = new ResendESignLinkRequest();
        var expected = new ResendESignLinkResponse();
        when(client.resendESignLink(request, "WEB", JOURNEY_ID)).thenReturn(ApiResponse.success(expected));
        assertSame(expected, service.resendESignLink(request, JOURNEY_ID));
        verify(client).resendESignLink(request, "WEB", JOURNEY_ID);
    }

    @Test
    void esignStatusPreservesPayloadChannelAndJourneyIdentifier() {
        var request = new ESignStatusRequest();
        var expected = new ESignStatusResponse();
        when(client.eSignStatus(request, "WEB", JOURNEY_ID)).thenReturn(ApiResponse.success(expected));
        assertSame(expected, service.eSignStatus(request, JOURNEY_ID));
        verify(client).eSignStatus(request, "WEB", JOURNEY_ID);
    }

    @Test
    void ipfStatusPreservesPayloadChannelAndJourneyIdentifier() {
        var request = new IPFStatusRequest();
        var expected = new IPFStatusResponse();
        when(client.checkIPFStatus(request, "WEB", JOURNEY_ID)).thenReturn(ApiResponse.success(expected));
        assertSame(expected, service.checkIPFStatus(request, JOURNEY_ID));
        verify(client).checkIPFStatus(request, "WEB", JOURNEY_ID);
    }

    @Test
    void finalProposalPreservesPayloadChannelAndJourneyIdentifier() {
        var request = new SubmitFinalProposalRequest();
        var expected = new SubmitFinalProposalResponse();
        when(client.submitFinalProposal(request, "WEB", JOURNEY_ID)).thenReturn(ApiResponse.success(expected));
        assertSame(expected, service.finalProposalSubmission(request, JOURNEY_ID));
        verify(client).submitFinalProposal(request, "WEB", JOURNEY_ID);
    }

    @Test
    void leadCancellationPreservesPayloadChannelAndJourneyIdentifier() {
        var request = new CancelLeadRequest();
        var expected = new CancelLeadsResponse();
        when(client.cancelLead(request, "WEB", JOURNEY_ID)).thenReturn(ApiResponse.success(expected));
        assertSame(expected, service.cancelLead(request, JOURNEY_ID));
        verify(client).cancelLead(request, "WEB", JOURNEY_ID);
    }

    @Test
    void lglcPreservesPayloadChannelAndJourneyIdentifier() {
        var request = new LGLCRequest();
        var expected = new LGLCResponse();
        when(client.getLgLcDetails(request, "WEB", JOURNEY_ID)).thenReturn(ApiResponse.success(expected));
        assertSame(expected, service.getLgLcDetails(request, JOURNEY_ID));
        verify(client).getLgLcDetails(request, "WEB", JOURNEY_ID);
    }
}
