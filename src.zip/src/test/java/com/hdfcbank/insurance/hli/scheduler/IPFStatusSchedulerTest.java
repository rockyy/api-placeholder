package com.hdfcbank.insurance.hli.scheduler;

import com.hdfcbank.job.scheduler.common.model.ExecutionStatus;
import com.hdfcbank.job.scheduler.common.model.JobSchedule;
import org.junit.jupiter.api.Test;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class IPFStatusSchedulerTest {
    @Test
    void distributedJobDispatchesRepositoryBatchAndReportsCompletion() {
        var service = mock(IPFSchedulerService.class);
        var scheduler = new IPFStatusScheduler(service);
        assertEquals(ExecutionStatus.COMPLETED, scheduler.execute(mock(JobSchedule.class)));
        verify(service).processRecords(List.of());
    }

    @Test
    void dispatchFailurePropagatesToDistributedScheduler() {
        var service = mock(IPFSchedulerService.class);
        var failure = new IllegalStateException("batch failed");
        doThrow(failure).when(service).processRecords(List.of());
        assertSame(failure, assertThrows(IllegalStateException.class,
                () -> new IPFStatusScheduler(service).execute(mock(JobSchedule.class))));
    }
}
