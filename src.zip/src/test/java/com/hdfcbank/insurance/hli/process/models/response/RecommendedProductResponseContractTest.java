package com.hdfcbank.insurance.hli.process.models.response;

import org.junit.jupiter.api.Test;
import tools.jackson.databind.ObjectMapper;
import static org.junit.jupiter.api.Assertions.*;

class RecommendedProductResponseContractTest {
    @Test
    void responseBindsNestedProductAndEmptyCoverObject() {
        var response = new ObjectMapper().readValue(
                "{\"recommendationCombos\":[{\"comboCode\":\"COMBO1\",\"loanTerm\":0,\"product\":[{\"code\":\"HDFC_3D\",\"covers\":[{}]}]}]}",
                HLIRecommendedProductResponse.class);
        var combo = response.getRecommendationCombos().getFirst();
        assertEquals("COMBO1", combo.getComboCode());
        assertEquals("HDFC_3D", combo.getProduct().getFirst().getCode());
        assertEquals(1, combo.getProduct().getFirst().getCovers().size());
        assertNotNull(combo.getProduct().getFirst().getCovers().getFirst());
    }
}
