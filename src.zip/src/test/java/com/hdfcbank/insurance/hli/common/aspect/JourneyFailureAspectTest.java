package com.hdfcbank.insurance.hli.common.aspect;

import com.hdfcbank.adapters.clients.feign.journey.JourneyServiceFeignClient;
import com.hdfcbank.adapters.vo.UpdateSystemDataJourneyRequest;
import com.hdfcbank.insurance.hli.common.annotation.FailureState;
import com.hdfcbank.insurance.hli.common.config.FailureStateContextHolder;
import com.hdfcbank.insurance.hli.common.config.JourneyContextHolder;
import com.hdfcbank.insurance.hli.common.enums.HLICustomCommonApiStatusCodes;
import com.hdfcbank.insurance.hli.common.exception.CustomValidationException;
import org.aspectj.lang.JoinPoint;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import java.util.List;
import static com.hdfcbank.insurance.hli.common.enums.JourneyStateName.*;
import static com.hdfcbank.insurance.hli.support.JourneyTestData.*;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class JourneyFailureAspectTest {
    private final JourneyServiceFeignClient client = mock(JourneyServiceFeignClient.class);
    private final JourneyFailureAspect aspect = new JourneyFailureAspect(client);

    @AfterEach
    void cleanUp() {
        FailureStateContextHolder.clear();
        FailureStateContextHolder.clearJourneyID();
        JourneyContextHolder.clear();
    }

    @Test
    void capturesAnnotatedFailureStateAndJourneyIdentifier() throws Exception {
        var point = mock(JoinPoint.class);
        when(point.getArgs()).thenReturn(new Object[]{JOURNEY_NAME, JOURNEY_ID, 42});
        var annotation = Endpoint.class.getDeclaredMethod("execute").getAnnotation(FailureState.class);
        new FailureStateCaptureAspect().captureFailureState(point, annotation);
        assertEquals(FAILED_FETCH_PRICING, FailureStateContextHolder.get());
        assertEquals(JOURNEY_ID, FailureStateContextHolder.getJourneyId());
    }

    @Test
    void persistsFailureDetailsAndStateForCurrentJourney() {
        JourneyContextHolder.setJourneyData(journey());
        FailureStateContextHolder.setJourneyId("fallback-id");
        FailureStateContextHolder.set(FAILED_FETCH_PRICING);
        var cause = new IllegalArgumentException("invalid price");
        aspect.handleFailure(new IllegalStateException("pricing failed", cause));
        var saved = ArgumentCaptor.forClass(UpdateSystemDataJourneyRequest.class);
        verify(client).update(saved.capture());
        assertEquals(JOURNEY_ID, saved.getValue().getJourneyId());
        var detail = (JourneyFailureDetail) saved.getValue().getData().get("journeyFailureDetail");
        assertEquals("FAILED_FETCH_PRICING", detail.getFailedState());
        assertEquals("pricing failed", detail.getErrorMessage());
        assertEquals("IllegalStateException", detail.getExceptionType());
        assertTrue(detail.getRootCause().contains("invalid price"));
        assertNotNull(detail.getTimestamp());
        verify(client).updateJourneyState(JOURNEY_ID, "FAILED_FETCH_PRICING");
        assertNull(FailureStateContextHolder.get());
    }

    @Test
    void usesCapturedJourneyWhenThereIsNoJourneyContext() {
        FailureStateContextHolder.setJourneyId(JOURNEY_ID);
        FailureStateContextHolder.set(FAILED_GET_DETAIL);
        aspect.handleFailure(new IllegalStateException("failed"));
        verify(client).updateJourneyState(JOURNEY_ID, "FAILED_GET_DETAIL");
    }

    @Test
    void customValidationDoesNotPersistTechnicalFailure() {
        FailureStateContextHolder.set(FAILED_GET_DETAIL);
        aspect.handleFailure(new CustomValidationException(HLICustomCommonApiStatusCodes.CUSTOM_VALIDATION_EXCEPTION,
                "Not eligible", "FULL_SCREEN", List.of("eligibility failed")));
        verifyNoInteractions(client);
        assertNull(FailureStateContextHolder.get());
    }

    @Test
    void missingJourneyOrFailureStateDoesNotWriteFailure() {
        aspect.handleFailure(new IllegalStateException("missing journey"));
        FailureStateContextHolder.setJourneyId(JOURNEY_ID);
        aspect.handleFailure(new IllegalStateException("missing state"));
        verifyNoInteractions(client);
    }

    @Test
    void persistenceFailureDoesNotReplaceOriginalFailureAndClearsFailureState() {
        FailureStateContextHolder.setJourneyId(JOURNEY_ID);
        FailureStateContextHolder.set(FAILED_GET_DETAIL);
        doThrow(new IllegalStateException("database unavailable")).when(client).update(any(UpdateSystemDataJourneyRequest.class));
        assertDoesNotThrow(() -> aspect.handleFailure(new IllegalStateException("original failure")));
        assertNull(FailureStateContextHolder.get());
        verify(client, never()).updateJourneyState(anyString(), anyString());
    }

    static class Endpoint {
        @FailureState(FAILED_FETCH_PRICING)
        void execute() { }
    }
}
