package com.hdfcbank.insurance.hli.support;

import com.hdfcbank.common.models.vo.journey.JourneyData;
import com.hdfcbank.insurance.adapter.process.models.response.GetLoanDetailResponse;
import com.hdfcbank.insurance.adapter.process.models.response.PricingResponse;
import com.hdfcbank.insurance.adapter.process.models.response.ProposalQuestionResponse;
import tools.jackson.databind.ObjectMapper;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public final class ProposalQuestionTestData {
    private ProposalQuestionTestData() { }

    public static JourneyData journeyWithBorrowers() {
        var journey = JourneyTestData.journey();
        var loan = new HashMap<String, Object>(journey.getJourneyDetail().getSystemData().get("getLoanDetail"));
        loan.put("property", Map.of("propertyNo", "PROP1"));
        loan.put("customers", List.of(customer("C2", "C"), customer("B1", "B"), customer("X3", "G")));
        journey.getJourneyDetail().getSystemData().put("getLoanDetail", loan);
        journey.getJourneyDetail().getSystemData().put("pricingResponse", new ObjectMapper().convertValue(pricing(), Map.class));
        return journey;
    }

    public static GetLoanDetailResponse.Customer customer(String id, String capacity) {
        return GetLoanDetailResponse.Customer.builder().number(id).capacity(capacity).firstName("Customer " + id)
                .dateOfBirth("01/01/1980").build();
    }

    public static ProposalQuestionResponse questions() {
        return ProposalQuestionResponse.builder().productWiseQuestions(List.of(
                ProposalQuestionResponse.ProductWiseQuestions.builder().code("LIFE")
                        .questions(List.of(question("B1", "health"), question("C2", "health"),
                                question("PROP1", "property"), question("OTHER", "ignored"))).build(),
                ProposalQuestionResponse.ProductWiseQuestions.builder().code("PROPERTY")
                        .questions(List.of(question("PROP1", "property"))).build())).build();
    }

    public static ProposalQuestionResponse.Question question(String id, String key) {
        return ProposalQuestionResponse.Question.builder().entityId(id).questionKey(key).build();
    }

    public static PricingResponse pricing() {
        return PricingResponse.builder().quotes(List.of(
                PricingResponse.Quote.builder().entityId("B1").productCode("LIFE").quoteId("QB").build(),
                PricingResponse.Quote.builder().entityId("C2").productCode("LIFE").quoteId("QC").build(),
                PricingResponse.Quote.builder().entityId("PROP1").productCode("PROPERTY").quoteId("QP").build())).build();
    }
}
