package com.hdfcbank.insurance.hli.process.models.enums;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import static org.junit.jupiter.api.Assertions.*;

class ProductAndOccupationMappingTest {
    @ParameterizedTest
    @CsvSource({"employed,Salaried", "self employed,Self Employee", "student,Others", "unknown,Others"})
    void occupationUsesNormalizedMappingAndDefault(String input, String expected) {
        assertEquals(expected, OccupationMapping.getMappedValue(input));
    }

    @Test
    void missingOccupationUsesDefault() { assertEquals("Others", OccupationMapping.getMappedValue(null)); }

    @ParameterizedTest
    @CsvSource({"hdfc_ergo_hca_option_1,Essential Plan (9 illnesses)",
            "HDFC_ERGO_HCA_OPTION_2,Silver Plus Plan (19 illnesses)",
            "HDFC_ERGO_HCA_OPTION_3,Platinum Plan (52 illnesses)", "unknown,Unknown Plan"})
    void hcaOptionResolvesKnownPlansAndUnknownFallback(String input, String expected) {
        assertEquals(expected, HCAOptions.getMappedValue(input));
    }

    @Test
    void missingHcaOptionReturnsNull() { assertNull(HCAOptions.getMappedValue(null)); }

    @ParameterizedTest
    @CsvSource({"HDFC_BGR_4,PROPERTY_COVER", "HDFC_ERGO_HCA,PROPERTY_COVER",
            "HDFC_ERGO_HCA_FLOATER,PROPERTY_COVER", "HDFC_3D,LIFE_COVER", "HDFC_GCP_PLUS,LIFE_COVER"})
    void productCodesResolveTheirCategory(String code, ProductCode expected) {
        assertEquals(expected, ProductCode.fromProductCode(code).orElseThrow());
    }

    @Test
    void unrecognizedProductHasNoCategory() { assertTrue(ProductCode.fromProductCode("unknown").isEmpty()); }
}
