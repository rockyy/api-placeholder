package com.hdfcbank.insurance.hli.scheduler.entities;

import org.junit.jupiter.api.Test;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

class PurchaseIPFStatusEntityTest {
    @Test
    void statusHistorySortsChronologically() {
        var older = PurchaseIPFStatusEntity.IPFStatusHistory.builder().lastModified(Instant.parse("2026-01-01T00:00:00Z")).build();
        var newer = PurchaseIPFStatusEntity.IPFStatusHistory.builder().lastModified(Instant.parse("2026-01-02T00:00:00Z")).build();
        var history = new ArrayList<>(List.of(newer, older));
        Collections.sort(history);
        assertEquals(List.of(older, newer), history);
        assertEquals(0, older.compareTo(older));
    }
}
