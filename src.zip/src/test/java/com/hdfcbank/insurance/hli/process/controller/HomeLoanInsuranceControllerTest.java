package com.hdfcbank.insurance.hli.process.controller;

import com.hdfcbank.common.models.vo.core.ApiResponse;
import com.hdfcbank.insurance.adapter.process.models.response.*;
import com.hdfcbank.insurance.hli.process.models.EsignResponse;
import com.hdfcbank.insurance.hli.process.models.request.ResendESignResponse;
import com.hdfcbank.insurance.hli.process.models.response.*;
import com.hdfcbank.insurance.hli.process.models.request.CallbackRequest;
import com.hdfcbank.insurance.hli.process.models.enums.CallbackType;
import com.hdfcbank.insurance.hli.process.models.response.CallbackResponse;
import com.hdfcbank.insurance.hli.process.models.response.HLILoanDetailResponse;
import com.hdfcbank.insurance.hli.process.service.CallbackService;
import com.hdfcbank.insurance.hli.process.service.HLIDetailService;
import com.hdfcbank.insurance.hli.process.service.HLIProductService;
import com.hdfcbank.insurance.hli.process.service.impl.HLIPricingImpl;
import com.hdfcbank.insurance.hli.process.service.impl.HLIQuestionServiceImpl;
import com.hdfcbank.insurance.hli.scheduler.IPFSchedulerService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@ExtendWith(MockitoExtension.class)
class HomeLoanInsuranceControllerTest {
    @Mock private HLIDetailService detailService;
    @Mock private HLIProductService productService;
    @Mock private HLIPricingImpl pricingService;
    @Mock private HLIQuestionServiceImpl questionService;
    @Mock private CallbackService callbackService;
    @Mock private IPFSchedulerService schedulerService;
    @InjectMocks private HomeLoanInsuranceController controller;
    private MockMvc mvc;

    @BeforeEach
    void setUp() {
        // Standalone MVC exercises JSON binding and @Valid without infrastructure or AOP.
        mvc = MockMvcBuilders.standaloneSetup(controller)
                .addPlaceholderValue("app.base-path", "/api/v1/hli/insurance").build();
    }

    @Test
    void cancellationCompletesBeforeRefetchingDetails() {
        var expected = ApiResponse.success(new HLILoanDetailResponse());
        when(detailService.fetchLoanDetail()).thenReturn(expected);
        assertSame(expected, controller.cancelPreviousJourneys());
        var order = inOrder(detailService);
        order.verify(detailService).cancelAllJourneys();
        order.verify(detailService).fetchLoanDetail();
    }

    @Test
    void cancellationFailurePreventsDetailFetch() {
        doThrow(new IllegalStateException("cancel failed")).when(detailService).cancelAllJourneys();
        assertThrows(IllegalStateException.class, controller::cancelPreviousJourneys);
        verify(detailService, never()).fetchLoanDetail();
    }

    @Test
    void validPricingQuestionRequestIsBoundAndPassedToService() throws Exception {
        when(pricingService.fetchPricingDetails(any())).thenReturn(ApiResponse.success(new PremiumQuestionResponse()));
        mvc.perform(post("/api/v1/hli/insurance/fetchPriceQuestions")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"products\":[{\"code\":\"HDFC_3D\",\"entityIds\":[\"C123\"]}]}"))
                .andExpect(status().isOk()).andExpect(jsonPath("$.status.code").value("0000"));
        verify(pricingService).fetchPricingDetails(argThat(r -> r.getProducts().size() == 1
                && "HDFC_3D".equals(r.getProducts().getFirst().getCode())
                && r.getProducts().getFirst().getEntityIds().equals(java.util.List.of("C123"))));
    }

    @ParameterizedTest
    @ValueSource(strings = {
            "{}", "{\"products\":[]}",
            "{\"products\":[{\"code\":\" \",\"entityIds\":[\"C123\"]}]}",
            "{\"products\":[{\"code\":\"HDFC_3D\",\"entityIds\":[]}]}",
            "{\"products\":[{\"code\":\"HDFC_3D\",\"entityIds\":[\" \"]}]}"})
    void invalidPricingQuestionsAreRejectedBeforeServiceCall(String json) throws Exception {
        mvc.perform(post("/api/v1/hli/insurance/fetchPriceQuestions")
                        .contentType(MediaType.APPLICATION_JSON).content(json))
                .andExpect(status().isBadRequest());
        verifyNoInteractions(pricingService);
    }

    @Test
    void invalidStaticDobIsRejectedBeforeIdentification() throws Exception {
        mvc.perform(post("/api/v1/hli/insurance/identify").contentType(MediaType.APPLICATION_JSON)
                        .content("{\"loanFileNumber\":\"1234567890\",\"source\":\"STATIC\",\"dob\":\"invalid\"}"))
                .andExpect(status().isBadRequest());
        verifyNoInteractions(detailService);
    }

    @ParameterizedTest
    @ValueSource(strings = {"identify", "getDetail", "getProducts", "getInsuranceProducts", "fetchCatalog",
            "fetchPrice", "product/fetchProposalQuestions", "product/submitAnswer", "getKFSDetail",
            "esign/initiate", "esign/status", "esign/resendLink", "submitFinalProposal", "getLgLcDetails"})
    void supportedEndpointsBindRequestsAndReturnSuccessfulServiceResponses(String endpoint) throws Exception {
        String body = switch (endpoint) {
            case "identify" -> {
                when(detailService.identify(any(), any(), any())).thenReturn(ApiResponse.success(new HLIIdentifyResponse()));
                yield "{\"loanFileNumber\":\"1234567890\",\"source\":\"DYNAMIC\"}";
            }
            case "getDetail" -> {
                when(detailService.fetchLoanDetail()).thenReturn(ApiResponse.success(new HLILoanDetailResponse()));
                yield "";
            }
            case "getProducts" -> {
                when(productService.getRecommendedProducts()).thenReturn(ApiResponse.success(new HLIRecommendedProductResponse()));
                yield "";
            }
            case "getInsuranceProducts" -> {
                when(productService.getInsuranceProducts()).thenReturn(ApiResponse.success(new RecommendedProductResponse()));
                yield "";
            }
            case "fetchCatalog" -> {
                when(productService.getCurateProducts()).thenReturn(ApiResponse.success(new HLICurateProductResponse()));
                yield "";
            }
            case "fetchPrice" -> {
                when(pricingService.fetchPricing(any())).thenReturn(ApiResponse.success(new HLIFetchPricingResponse()));
                yield "{\"mode\":\"INITIATE_QUOTES\",\"product\":[{\"code\":\"HDFC_3D\",\"answers\":[{\"entityId\":\"C1\",\"questionKey\":\"sum_insured\",\"answer\":\"100000\"}]}]}";
            }
            case "product/fetchProposalQuestions" -> {
                when(questionService.getProposalQuestions()).thenReturn(ApiResponse.success(new HLIProposalQuestionResponse()));
                yield "";
            }
            case "product/submitAnswer" -> {
                when(questionService.submitProposal(any())).thenReturn(ApiResponse.success(new HLISubmitAnswerResponse()));
                yield "{\"questionType\":\"PROPOSAL\",\"mode\":\"INITIATE\",\"productWiseQuestions\":[{\"quoteId\":\"Q1\",\"answers\":[{\"entityId\":\"C1\",\"questionKey\":\"declaration\",\"answer\":\"yes\"}]}]}";
            }
            case "getKFSDetail" -> {
                when(detailService.fetchKFSDetail()).thenReturn(ApiResponse.success(new KFSDetailResponse()));
                yield "";
            }
            case "esign/initiate" -> {
                when(detailService.initiateEsign()).thenReturn(ApiResponse.success(EsignResponse.builder().build()));
                yield "";
            }
            case "esign/status" -> {
                when(detailService.esignStatus()).thenReturn(ApiResponse.success(EsignResponse.builder().build()));
                yield "";
            }
            case "esign/resendLink" -> {
                when(detailService.resendESignLink(any())).thenReturn(ApiResponse.success(new ResendESignResponse()));
                yield "{\"borrowerId\":\"C1\"}";
            }
            case "submitFinalProposal" -> {
                when(detailService.submitFinalProposal()).thenReturn(ApiResponse.success(new SubmitFinalProposalResponse()));
                yield "";
            }
            default -> {
                when(questionService.fetchLgLcDetails(null)).thenReturn(ApiResponse.success(new LGLCResponse()));
                yield "";
            }
        };
        mvc.perform(post("/api/v1/hli/insurance/" + endpoint).contentType(MediaType.APPLICATION_JSON).content(body))
                .andExpect(status().isOk()).andExpect(jsonPath("$.status.code").value("0000"));
        switch (endpoint) {
            case "identify" -> verify(detailService).identify(any(), any(), argThat(r -> "1234567890".equals(r.getLoanFileNumber())));
            case "fetchPrice" -> verify(pricingService).fetchPricing(argThat(r -> "INITIATE_QUOTES".equals(r.getMode())));
            case "product/submitAnswer" -> verify(questionService).submitProposal(argThat(r -> "Q1".equals(r.getProductWiseQuestions().getFirst().getQuoteId())));
            case "esign/resendLink" -> verify(detailService).resendESignLink(argThat(r -> "C1".equals(r.getBorrowerId())));
            default -> { }
        }
    }

    @Test
    void schedulerEndpointPassesRecordsToSchedulerAndReturnsAcknowledgement() throws Exception {
        mvc.perform(post("/api/v1/hli/insurance/callIPFScheduler").contentType(MediaType.APPLICATION_JSON).content("[]"))
                .andExpect(status().isOk()).andExpect(jsonPath("$.data").value("Run successfully"));
        verify(schedulerService).processRecords(java.util.List.of());
    }

    @Test
    void callbackDispatchReturnsServiceResponse() {
        var request = CallbackRequest.builder().callbackType(CallbackType.CANCEL_LEAD).data("{}").build();
        var expected = ApiResponse.success(CallbackResponse.builder().message("Success").build());
        when(callbackService.performAction(request)).thenReturn(expected);
        assertSame(expected, controller.executeAction(request));
    }
}
