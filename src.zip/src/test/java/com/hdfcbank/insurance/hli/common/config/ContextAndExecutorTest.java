package com.hdfcbank.insurance.hli.common.config;

import com.hdfcbank.insurance.hli.common.enums.JourneyStateName;
import com.hdfcbank.insurance.hli.common.properties.HLIExecutorProperties;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.slf4j.MDC;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import static com.hdfcbank.insurance.hli.support.JourneyTestData.*;
import static org.junit.jupiter.api.Assertions.*;

class ContextAndExecutorTest {
    @AfterEach
    void cleanUp() {
        FailureStateContextHolder.clear();
        FailureStateContextHolder.clearJourneyID();
        JourneyContextHolder.clear();
    }

    @Test
    void journeyAndFailureContextsAreIsolatedBetweenThreadsAndCanBeCleared() throws Exception {
        var current = journey();
        JourneyContextHolder.setJourneyData(current);
        FailureStateContextHolder.set(JourneyStateName.FAILED_GET_DETAIL);
        FailureStateContextHolder.setJourneyId(JOURNEY_ID);
        try (var other = Executors.newSingleThreadExecutor()) {
            assertTrue(other.submit(() -> JourneyContextHolder.getJourneyData() == null
                    && FailureStateContextHolder.get() == null && FailureStateContextHolder.getJourneyId() == null)
                    .get(2, TimeUnit.SECONDS));
        }
        assertSame(current, JourneyContextHolder.getJourneyData());
        assertEquals(JourneyStateName.FAILED_GET_DETAIL, FailureStateContextHolder.get());
        assertEquals(JOURNEY_ID, FailureStateContextHolder.getJourneyId());
        cleanUp();
        assertNull(JourneyContextHolder.getJourneyData());
        assertNull(FailureStateContextHolder.get());
        assertNull(FailureStateContextHolder.getJourneyId());
    }

    @Test
    void executorUsesConfiguredCapacityAndThreadPrefix() throws Exception {
        var properties = new HLIExecutorProperties();
        properties.setPoolSize(1);
        properties.setMaxPoolSize(2);
        properties.setQueueCapacity(3);
        properties.setThreadNamePrefix("insurance-unit-");
        var executor = (ThreadPoolTaskExecutor) new HLIExecutorConfiguration(properties).taskExecutor();
        try {
            assertEquals(1, executor.getCorePoolSize());
            assertEquals(2, executor.getMaxPoolSize());
            assertEquals(3, executor.getQueueCapacity());
            assertTrue(executor.submit(() -> Thread.currentThread().getName()).get(2, TimeUnit.SECONDS)
                    .startsWith("insurance-unit-"));
        } finally { executor.shutdown(); }
    }
}
