package com.hdfcbank.insurance.hli.common.handler;

import ch.qos.logback.classic.Logger;
import ch.qos.logback.classic.Level;
import ch.qos.logback.classic.spi.ILoggingEvent;
import ch.qos.logback.core.read.ListAppender;
import com.hdfcbank.insurance.hli.common.exception.HLIException;
import org.junit.jupiter.api.Test;
import org.slf4j.LoggerFactory;
import static org.junit.jupiter.api.Assertions.*;

class HLICommonExceptionHandlerTest {
    @Test
    void logsFailureSourceMessageAndOriginalException() {
        var logger = (Logger) LoggerFactory.getLogger(HLICommonExceptionHandler.class);
        var events = new ListAppender<ILoggingEvent>();
        events.start();
        logger.addAppender(events);
        try {
            new HLICommonExceptionHandler().logException("pricing", new HLIException("request failed"));
            var event = events.list.getLast();
            assertEquals(Level.ERROR, event.getLevel());
            assertTrue(event.getFormattedMessage().contains("pricing"));
            assertTrue(event.getFormattedMessage().contains("request failed"));
            assertEquals(HLIException.class.getName(), event.getThrowableProxy().getClassName());
        } finally { logger.detachAppender(events); events.stop(); }
    }
}
