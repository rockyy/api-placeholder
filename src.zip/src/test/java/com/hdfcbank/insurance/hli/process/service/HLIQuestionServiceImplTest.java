package com.hdfcbank.insurance.hli.process.service;

import com.hdfcbank.adapters.clients.feign.journey.JourneyServiceFeignClient;
import com.hdfcbank.adapters.vo.UpdateSystemDataJourneyRequest;
import com.hdfcbank.common.models.vo.journey.JourneyData;
import com.hdfcbank.insurance.adapter.process.models.response.LGLCResponse;
import com.hdfcbank.insurance.adapter.process.models.response.SubmitAnswerResponse;
import com.hdfcbank.insurance.hli.common.config.JourneyContextHolder;
import com.hdfcbank.insurance.hli.process.models.request.HLILGLCRequest;
import com.hdfcbank.insurance.hli.process.models.request.HLISubmitAnswerRequest;
import com.hdfcbank.insurance.hli.process.service.impl.HLIQuestionServiceImpl;
import com.hdfcbank.insurance.hli.process.service.impl.ProcessServiceCall;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import tools.jackson.databind.ObjectMapper;
import java.util.List;
import java.util.Map;
import static com.hdfcbank.insurance.hli.support.JourneyTestData.*;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class HLIQuestionServiceImplTest {
    @Mock private ProcessServiceCall processCall;
    @Mock private JourneyServiceFeignClient journeyClient;
    private HLIQuestionServiceImpl service;
    private JourneyData journeyData;

    @BeforeEach
    void setUp() {
        journeyData = journey();
        JourneyContextHolder.setJourneyData(journeyData);
        service = new HLIQuestionServiceImpl(processCall, new ObjectMapper(), journeyClient);
    }

    @AfterEach
    void clearContext() {
        JourneyContextHolder.clear();
    }

    @Test
    void lglcRequestUsesOptionalChannelAndPersistsMappedData() {
        var request = new HLILGLCRequest();
        request.setChannel("WEB");
        var expected = new LGLCResponse();
        when(processCall.getLgLcDetails(any(), eq(JOURNEY_ID))).thenReturn(expected);
        assertSame(expected, service.fetchLgLcDetails(request).getData());
        verify(processCall).getLgLcDetails(argThat(r -> "WEB".equals(r.getChannel())
                && LOAN_NUMBER.equals(r.getLoanFileNumber())), eq(JOURNEY_ID));
        verify(journeyClient).update(argThat((UpdateSystemDataJourneyRequest r) ->
                "LGLC_FETCH_SUCCESS".equals(r.getJourneyState().getStateName()) && r.getData().containsKey("lglcDetails")));
    }

    @Test
    void lglcRequestAllowsAbsentBody() {
        when(processCall.getLgLcDetails(any(), eq(JOURNEY_ID))).thenReturn(new LGLCResponse());
        service.fetchLgLcDetails(null);
        verify(processCall).getLgLcDetails(argThat(r -> LOAN_NUMBER.equals(r.getLoanFileNumber())
                && r.getChannel() == null), eq(JOURNEY_ID));
    }

    @Test
    void submitsProposalWithLeadLoanAndUserAnswersAndRecordsStates() {
        journeyData.getJourneyDetail().getSystemData().put("lglcDetails", Map.of("lgCode", "OLD"));
        var request = proposalRequest();
        var downstream = SubmitAnswerResponse.builder().status("Completed").proposals(List.of()).build();
        when(processCall.submitAnswerProcessCall(any(), eq(JOURNEY_ID))).thenReturn(downstream);
        var response = service.submitProposal(request);
        assertEquals("Completed", response.getData().getStatus());
        assertTrue(response.getData().getProposals().isEmpty());
        verify(processCall).submitAnswerProcessCall(argThat(r -> LEAD_ID.equals(r.getLeadId())
                && LOAN_NUMBER.equals(r.getLoanFileNumber()) && "INITIATE".equals(r.getMode())
                && "Q1".equals(r.getProductWise().getFirst().getQuoteId())
                && "yes".equals(r.getProductWise().getFirst().getAnswers().getFirst().getAnswer())), eq(JOURNEY_ID));
        var updates = ArgumentCaptor.forClass(UpdateSystemDataJourneyRequest.class);
        verify(journeyClient, times(3)).update(updates.capture());
        assertEquals(List.of("LGLC_UPDATE_SUCCESS", "PROPOSAL_SUBMIT_INITIATED", "PROPOSAL_SUBMIT_SUCCESS"),
                updates.getAllValues().stream().map(u -> u.getJourneyState().getStateName()).toList());
    }

    @Test
    void downstreamProposalFailureDoesNotRecordSubmissionSuccess() {
        journeyData.getJourneyDetail().getSystemData().put("lglcDetails", Map.of("lgCode", "OLD"));
        when(processCall.submitAnswerProcessCall(any(), eq(JOURNEY_ID))).thenThrow(new IllegalStateException("timeout"));
        assertThrows(IllegalStateException.class, () -> service.submitProposal(proposalRequest()));
        verify(journeyClient, never()).update(argThat((UpdateSystemDataJourneyRequest r) ->
                "PROPOSAL_SUBMIT_SUCCESS".equals(r.getJourneyState().getStateName())));
    }

    @Test
    void proposalQuestionsUseBorrowerQuotesAndPersistMappedResponse() {
        journeyData.getJourneyDetail().setSystemData(
                com.hdfcbank.insurance.hli.support.ProposalQuestionTestData.journeyWithBorrowers()
                        .getJourneyDetail().getSystemData());
        when(processCall.proposalQuestionProcessCall(any(), eq(JOURNEY_ID))).thenReturn(
                com.hdfcbank.insurance.hli.support.ProposalQuestionTestData.questions());
        var response = service.getProposalQuestions();
        assertEquals("B1", response.getData().getBorrowers().getFirst().getBorrower().getId());
        assertEquals("QB", response.getData().getBorrowers().getFirst().getProducts().getFirst().getQuoteId());
        verify(processCall).proposalQuestionProcessCall(argThat(r -> LEAD_ID.equals(r.getLeadId())), eq(JOURNEY_ID));
        verify(journeyClient).update(argThat((UpdateSystemDataJourneyRequest r) ->
                "PROPOSAL_QUESTION_SUCCESS".equals(r.getJourneyState().getStateName())
                        && r.getData().get("PROPOSAL_QUESTIONS") == response.getData()));
    }

    private HLISubmitAnswerRequest proposalRequest() {
        return HLISubmitAnswerRequest.builder().questionType(HLISubmitAnswerRequest.QuestionType.PROPOSAL)
                .mode(HLISubmitAnswerRequest.Mode.INITIATE).lgCode("NEW")
                .productWiseQuestions(List.of(HLISubmitAnswerRequest.ProductWiseQuestion.builder().quoteId("Q1")
                        .answers(List.of(HLISubmitAnswerRequest.ProductWiseQuestion.Answer.builder()
                                .entityId("C1").questionKey("declaration").answer("yes").build())).build())).build();
    }
}
