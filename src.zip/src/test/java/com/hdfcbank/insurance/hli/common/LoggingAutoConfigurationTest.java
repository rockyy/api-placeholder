package com.hdfcbank.insurance.hli.common;

import com.hdfcbank.starter.logging.helpers.LogHelper;
import com.hdfcbank.starter.logging.helpers.LogMaskingHelper;
import com.hdfcbank.starter.logging.properties.LoggingProperties;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.runner.ApplicationContextRunner;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;

class LoggingAutoConfigurationTest {
    private final ApplicationContextRunner runner = new ApplicationContextRunner()
            .withUserConfiguration(LoggingAutoConfiguration.class)
            .withBean(LogMaskingHelper.class, () -> mock(LogMaskingHelper.class))
            .withBean(LoggingProperties.class, LoggingProperties::new);

    @Test
    void suppliesLoggingHelperWhenNoneWasConfigured() {
        runner.run(context -> assertThat(context).hasSingleBean(LogHelper.class));
    }

    @Test
    void applicationLoggingHelperTakesPrecedence() {
        var existing = mock(LogHelper.class);
        runner.withBean(LogHelper.class, () -> existing)
                .run(context -> assertThat(context.getBean(LogHelper.class)).isSameAs(existing));
    }
}
