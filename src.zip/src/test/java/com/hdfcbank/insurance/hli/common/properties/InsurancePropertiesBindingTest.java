package com.hdfcbank.insurance.hli.common.properties;

import org.junit.jupiter.api.Test;
import org.springframework.boot.context.properties.bind.Bindable;
import org.springframework.boot.context.properties.bind.Binder;
import org.springframework.boot.context.properties.source.MapConfigurationPropertySource;
import java.util.Map;
import static org.junit.jupiter.api.Assertions.*;

class InsurancePropertiesBindingTest {
    @Test
    void bindsExecutorAndDownstreamChannelPropertiesFromExternalConfiguration() {
        var binder = new Binder(new MapConfigurationPropertySource(Map.of(
                "hli.pool-size", "2", "hli.max-pool-size", "4", "hli.queue-capacity", "8",
                "hli.thread-name-prefix", "insurance-", "app.channel", "WEB", "app.call-back-url", "https://example.test/callback")));
        var pool = binder.bind("hli", Bindable.of(HLIExecutorProperties.class)).get();
        assertEquals(2, pool.getPoolSize());
        assertEquals(4, pool.getMaxPoolSize());
        assertEquals(8, pool.getQueueCapacity());
        assertEquals("insurance-", pool.getThreadNamePrefix());
        var app = binder.bind("app", Bindable.of(HLIAppProperties.class)).get();
        assertEquals("WEB", app.getChannel());
        assertEquals("https://example.test/callback", app.getCallBackUrl());
    }

    @Test
    void bindsOrderedReturnJourneyStatesAndMessages() {
        var binder = new Binder(new MapConfigurationPropertySource(Map.of(
                "return-journey-config.return-states[0].state", "GET_DETAIL_SUCCESS",
                "return-journey-config.return-states[0].load-context", "PRODUCTS",
                "return-journey-config.return-states[0].title", "Resume",
                "return-journey-config.return-states[1].state", "FETCH_PRICING_SUCCESS")));
        var states = binder.bind("return-journey-config", Bindable.of(ReturnJourneyProperties.class)).get().getReturnStates();
        assertEquals(2, states.size());
        assertEquals("GET_DETAIL_SUCCESS", states.getFirst().getState());
        assertEquals("PRODUCTS", states.getFirst().getLoadContext());
        assertEquals("Resume", states.getFirst().getTitle());
        assertEquals("FETCH_PRICING_SUCCESS", states.getLast().getState());
    }
}
