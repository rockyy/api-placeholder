package com.hdfcbank.insurance.hli.common.providers;

import com.hdfcbank.adapters.clients.feign.journey.JourneyServiceFeignClient;
import com.hdfcbank.common.models.vo.journey.JourneyData;
import com.hdfcbank.starter.logging.models.JourneyAliases;
import com.hdfcbank.starter.logging.properties.JourneyAliasProperties;
import com.hdfcbank.starter.logging.providers.JourneyProvider;
import org.junit.jupiter.api.Test;
import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.cache.concurrent.ConcurrentMapCacheManager;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Configuration;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class JourneyProviderImplTest {
    @Configuration(proxyBeanMethods = false)
    @EnableCaching
    static class CacheConfiguration { }

    @Test
    void cachesAliasesReplacesThemOnUpdateAndDoesNotCacheMissingJourney() {
        var client = mock(JourneyServiceFeignClient.class);
        when(client.fetch("J123")).thenReturn(JourneyData.builder()
                .journeyIdAlias("public-id").journeyNameAlias("public-name").build());
        try (var context = new AnnotationConfigApplicationContext()) {
            context.register(CacheConfiguration.class);
            context.registerBean(CacheManager.class, () -> new ConcurrentMapCacheManager(JourneyProvider.JOURNEY_ALIAS_CACHE_NAME));
            context.registerBean(JourneyProviderImpl.class, () -> new JourneyProviderImpl(client, new JourneyAliasProperties()));
            context.refresh();
            var provider = context.getBean(JourneyProvider.class);
            var found = provider.findBy("J123");
            assertEquals("public-id", found.getJourneyIdAlias());
            assertEquals("public-name", found.getJourneyNameAlias());
            assertSame(found, provider.findBy("J123"));
            verify(client).fetch("J123");
            var replacement = new JourneyAliases("new-id", "new-name");
            assertSame(replacement, provider.update("J123", replacement));
            assertSame(replacement, provider.findBy("J123"));
            verify(client).fetch("J123");
            assertNull(provider.findBy("missing"));
            assertNull(provider.findBy("missing"));
            verify(client, times(2)).fetch("missing");
        }
    }
}
