# Common models unit tests

Use JDK 25 and Maven with the team's repository settings for the private
`com.hdfcbank:microservice-root:0.0.3-release` parent and managed dependencies.

```sh
mvn -Dmaven.gitcommitid.skip=true clean verify
```

The Git metadata skip is needed for this exported directory, which has no `.git`.
When all dependencies are cached locally, the same command also works with `-o`.
Use `mvn -Dmaven.gitcommitid.skip=true test` for tests and coverage reports without
the verification gate.

The suite covers response factories and status fields, error-reference formatting
and MDC fallbacks, pagination and sorting, validation and violation paths, date of
birth boundaries, collection helpers, reactive composition, and model JSON and
Java serialization. Shared regex-validator contract tests preserve blank handling,
custom expressions, substring searches, and invalid-pattern failures during the
duplication cleanup. Tests exercise current production behavior without starting
application services.

Mockito uses the test-scoped `mock-maker-subclass` configuration because these
tests do not need inline, final, or static mocking. This lets the suite run when
JVM self-attachment is unavailable. MDC tests restore the previous context after
each test or dynamic-test factory.

Surefire results are in `target/surefire-reports`. JaCoCo reports are in
`target/site/jacoco/index.html` and `target/site/jacoco/jacoco.xml`. `verify`
enforces the inherited package coverage thresholds of 80% lines and 50% branches.
JaCoCo applies its normal filtering of Lombok-generated code. The existing Sonar
exclusions remain unchanged, so Sonar's analyzed scope may differ from JaCoCo's.
