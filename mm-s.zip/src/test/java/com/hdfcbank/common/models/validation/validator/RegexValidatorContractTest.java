package com.hdfcbank.common.models.validation.validator;

import com.hdfcbank.common.models.validation.annotation.AnnotationHelper;
import com.hdfcbank.common.models.validation.annotation.BankAccountNumber;
import com.hdfcbank.common.models.validation.annotation.Email;
import com.hdfcbank.common.models.validation.annotation.MobileNumber;
import com.hdfcbank.common.models.validation.annotation.Pan;
import com.hdfcbank.common.models.validation.annotation.Url;
import jakarta.validation.ConstraintValidator;
import org.junit.jupiter.api.DynamicTest;
import org.junit.jupiter.api.TestFactory;

import java.lang.annotation.Annotation;
import java.util.Map;
import java.util.function.BiFunction;
import java.util.regex.PatternSyntaxException;
import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.*;
import static org.junit.jupiter.api.DynamicTest.dynamicTest;

class RegexValidatorContractTest {

    record ValidatorFactory(String name,
                            BiFunction<Boolean, String, ConstraintValidator<?, String>> create) {
    }

    static Stream<ValidatorFactory> validators() {
        return Stream.of(
                new ValidatorFactory("PAN", (blank, regex) -> initialized(new PanValidator(), Pan.class, blank, regex)),
                new ValidatorFactory("bank account", (blank, regex) -> initialized(new BankAccountNumberValidator(), BankAccountNumber.class, blank, regex)),
                new ValidatorFactory("email", (blank, regex) -> initialized(new EmailValidator(), Email.class, blank, regex)),
                new ValidatorFactory("mobile", (blank, regex) -> initialized(new MobileNumberValidator(), MobileNumber.class, blank, regex)),
                new ValidatorFactory("URL", (blank, regex) -> initialized(new UrlValidator(), Url.class, blank, regex))
        );
    }

    private static <A extends Annotation> ConstraintValidator<A, String> initialized(
            ConstraintValidator<A, String> validator, Class<A> annotationType, boolean allowBlank, String regex) {
        validator.initialize(AnnotationHelper.createAnnotation(annotationType,
                Map.of("allowBlank", allowBlank, "regex", regex)));
        return validator;
    }

    @TestFactory
    Stream<DynamicTest> blankValuesFollowAllowBlankWithoutCompilingRegex() {
        return validators().map(factory -> dynamicTest(factory.name(), () -> {
            ConstraintValidator<?, String> required = factory.create().apply(false, "[");
            ConstraintValidator<?, String> optional = factory.create().apply(true, "[");

            for (String blank : new String[]{null, "", " ", "\t\n"}) {
                assertFalse(required.isValid(blank, null));
                assertTrue(optional.isValid(blank, null));
            }
        }));
    }

    @TestFactory
    Stream<DynamicTest> customExpressionsKeepSearchSemanticsAndValidateOptionalNonblankValues() {
        return validators().map(factory -> dynamicTest(factory.name(), () -> {
            ConstraintValidator<?, String> search = factory.create().apply(false, "needle");
            ConstraintValidator<?, String> optional = factory.create().apply(true, "^needle$");

            assertTrue(search.isValid("prefix-needle-suffix", null));
            assertFalse(search.isValid("different", null));
            assertTrue(optional.isValid("needle", null));
            assertFalse(optional.isValid("prefix-needle-suffix", null));
            assertFalse(optional.isValid("different", null));
        }));
    }

    @TestFactory
    Stream<DynamicTest> invalidExpressionsStillFailForNonblankValues() {
        return validators().map(factory -> dynamicTest(factory.name(), () -> {
            ConstraintValidator<?, String> required = factory.create().apply(false, "[");
            ConstraintValidator<?, String> optional = factory.create().apply(true, "[");

            assertThrows(PatternSyntaxException.class, () -> required.isValid("value", null));
            assertThrows(PatternSyntaxException.class, () -> optional.isValid("value", null));
        }));
    }
}
