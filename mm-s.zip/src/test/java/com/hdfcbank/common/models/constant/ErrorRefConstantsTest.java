package com.hdfcbank.common.models.constant;

import org.junit.jupiter.api.Test;

import java.lang.reflect.Constructor;
import java.lang.reflect.Modifier;

import static org.junit.jupiter.api.Assertions.*;

class ErrorRefConstantsTest {

    @Test
    void testConstantValues() {
        assertEquals("UNKWN", ErrorRefConstants.UNKNOWN_API_IDENTIFIER);
        assertEquals("00000-00000", ErrorRefConstants.DEFAULT_JOURNEY_ID_ALIAS);
        assertEquals("UNKWN", ErrorRefConstants.DEFAULT_JOURNEY_NAME_ALIAS);
    }

    @Test
    void testConstructorIsPrivate() throws Exception {
        Constructor<ErrorRefConstants> c =
                ErrorRefConstants.class.getDeclaredConstructor();

        assertTrue(Modifier.isPrivate(c.getModifiers()));
    }
}
