package com.hdfcbank.common.models.constant;

import com.hdfcbank.common.models.vo.core.ApiResponseStatusCodeLiteral;
import org.junit.jupiter.api.DynamicTest;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestFactory;

import java.util.Arrays;
import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.*;
import static org.junit.jupiter.api.DynamicTest.dynamicTest;

class CommonApiStatusCodesTest {

    record ExpectedStatus(CommonApiStatusCodes status, String code, String message) {
    }

    @TestFactory
    Stream<DynamicTest> statusLiteralsExposeTheirPublishedCodeAndMessage() {
        return Stream.of(
                new ExpectedStatus(CommonApiStatusCodes.SUCCESS, "0000", "Request succeeded"),
                new ExpectedStatus(CommonApiStatusCodes.FAILURE, "9001", "Request failed"),
                new ExpectedStatus(CommonApiStatusCodes.INPUT_VALIDATION_ERROR, "8000", "input.validation.error"),
                new ExpectedStatus(CommonApiStatusCodes.BUSINESS_VALIDATION_ERROR, "1000", "business.validation.error"),
                new ExpectedStatus(CommonApiStatusCodes.DOWNSTREAM_API_ERROR, "9000", "downstream.api.error"),
                new ExpectedStatus(CommonApiStatusCodes.SYSTEM_ERROR, "9999", "system.error"),
                new ExpectedStatus(CommonApiStatusCodes.COOL_OFF_LIMIT_EXCEEDED_ERROR, "1800", "cooloff.limit.exceeded.error"),
                new ExpectedStatus(CommonApiStatusCodes.DEPOSITORY_CALLBACK_FAILED_ERROR, "1801", "depository.callback.failed"),
                new ExpectedStatus(CommonApiStatusCodes.CUSTOM_VALIDATION_ERROR, "5001", "custom.validation.error")
        ).map(expected -> dynamicTest(expected.status().name(), () -> {
            ApiResponseStatusCodeLiteral literal = expected.status();

            assertAll(
                    () -> assertEquals(expected.code(), literal.getCode()),
                    () -> assertEquals(expected.message(), literal.getMessage())
            );
        }));
    }

    @Test
    void statusCodesAreUnique() {
        long distinctCodes = Arrays.stream(CommonApiStatusCodes.values())
                .map(CommonApiStatusCodes::getCode)
                .distinct()
                .count();

        assertEquals(CommonApiStatusCodes.values().length, distinctCodes);
    }
}
