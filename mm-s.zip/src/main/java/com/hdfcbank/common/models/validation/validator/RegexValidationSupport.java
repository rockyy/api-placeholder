package com.hdfcbank.common.models.validation.validator;

import org.apache.commons.lang3.StringUtils;

import java.util.function.Supplier;
import java.util.regex.Pattern;

final class RegexValidationSupport {

    private RegexValidationSupport() {
    }

    static boolean isValid(String value, boolean allowBlank, Supplier<String> regexSupplier) {
        if (allowBlank && StringUtils.isBlank(value)) {
            return true;
        }
        return StringUtils.isNoneBlank(value)
                && Pattern.compile(regexSupplier.get()).matcher(value).find();
    }
}
