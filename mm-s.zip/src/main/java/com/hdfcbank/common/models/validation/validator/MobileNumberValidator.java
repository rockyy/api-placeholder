package com.hdfcbank.common.models.validation.validator;

import com.hdfcbank.common.models.validation.annotation.MobileNumber;
import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

public class MobileNumberValidator implements ConstraintValidator<MobileNumber, String> {

    private MobileNumber constraintAnnotation;

    @Override
    public void initialize(MobileNumber constraintAnnotation) {
        this.constraintAnnotation = constraintAnnotation;
    }

    @Override
    public boolean isValid(String value, ConstraintValidatorContext context) {
        return RegexValidationSupport.isValid(value, constraintAnnotation.allowBlank(), constraintAnnotation::regex);
    }
}
