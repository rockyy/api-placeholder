package com.hdfcbank.common.models.validation.validator;

import com.hdfcbank.common.models.validation.annotation.Pan;
import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

public class PanValidator implements ConstraintValidator<Pan, String> {

    private Pan constraintAnnotation;

    @Override
    public void initialize(Pan constraintAnnotation) {
        this.constraintAnnotation = constraintAnnotation;
    }

    @Override
    public boolean isValid(String value, ConstraintValidatorContext context) {
        return RegexValidationSupport.isValid(value, constraintAnnotation.allowBlank(), constraintAnnotation::regex);
    }
}
