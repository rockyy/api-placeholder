package com.hdfcbank.common.models.validation.validator;

import com.hdfcbank.common.models.validation.annotation.Url;
import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

public class UrlValidator implements ConstraintValidator<Url, String> {

    private Url constraintAnnotation;

    @Override
    public void initialize(Url constraintAnnotation) {
        this.constraintAnnotation = constraintAnnotation;
    }

    @Override
    public boolean isValid(String value, ConstraintValidatorContext context) {
        return RegexValidationSupport.isValid(value, constraintAnnotation.allowBlank(), constraintAnnotation::regex);
    }
}
