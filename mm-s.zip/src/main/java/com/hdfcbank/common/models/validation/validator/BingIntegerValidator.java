package com.hdfcbank.common.models.validation.validator;

import com.hdfcbank.common.models.validation.annotation.BigNumValidator;
import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

public class BingIntegerValidator implements ConstraintValidator<BigNumValidator, Integer> {

    @Override
    public void initialize(BigNumValidator constraintAnnotation) {
        // This constraint has no annotation-specific configuration.
    }

    @Override
    public boolean isValid(Integer value, ConstraintValidatorContext context) {
        return value != null && value > 0 && value.toString().length() <= 20;
    }
}
