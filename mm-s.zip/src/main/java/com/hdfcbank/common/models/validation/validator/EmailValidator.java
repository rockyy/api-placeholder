package com.hdfcbank.common.models.validation.validator;

import com.hdfcbank.common.models.validation.annotation.Email;
import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

public class EmailValidator implements ConstraintValidator<Email, String> {

    private Email constraintAnnotation;

    @Override
    public void initialize(Email constraintAnnotation) {
        this.constraintAnnotation = constraintAnnotation;
    }

    @Override
    public boolean isValid(String value, ConstraintValidatorContext context) {
        return RegexValidationSupport.isValid(value, constraintAnnotation.allowBlank(), constraintAnnotation::regex);
    }
}
