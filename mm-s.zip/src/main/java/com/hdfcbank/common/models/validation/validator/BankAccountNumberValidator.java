package com.hdfcbank.common.models.validation.validator;

import com.hdfcbank.common.models.validation.annotation.BankAccountNumber;
import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

public class BankAccountNumberValidator implements ConstraintValidator<BankAccountNumber, String> {

    private BankAccountNumber constraintAnnotation;

    @Override
    public void initialize(BankAccountNumber constraintAnnotation) {
        this.constraintAnnotation = constraintAnnotation;
    }

    @Override
    public boolean isValid(String value, ConstraintValidatorContext context) {
        return RegexValidationSupport.isValid(value, constraintAnnotation.allowBlank(), constraintAnnotation::regex);
    }

}
