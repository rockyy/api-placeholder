package com.hdfcbank.common.models.vo.journey;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class JourneyDetailsDataTypeTest {

    @Test
    void testEnumValues() {
        assertEquals(JourneyDetailsDataType.DOMAIN_DATA, JourneyDetailsDataType.valueOf("DOMAIN_DATA"));
        assertEquals(JourneyDetailsDataType.SYSTEM_DATA, JourneyDetailsDataType.valueOf("SYSTEM_DATA"));
    }

    @Test
    void testEnumCount() {
        // Safety check: ensures no accidental additions or removals
        assertEquals(2, JourneyDetailsDataType.values().length);
    }
}