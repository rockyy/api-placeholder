package com.hdfcbank.common.models.vo.core;

import com.hdfcbank.common.models.vo.mdc.MDCValues;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DynamicTest;
import org.junit.jupiter.api.TestFactory;
import org.slf4j.MDC;

import java.util.Map;
import java.util.function.Supplier;
import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.*;
import static org.junit.jupiter.api.DynamicTest.dynamicTest;

class ErrorRefTest {

    private Map<String, String> previousContext;

    @BeforeEach
    void saveAndClearMdc() {
        previousContext = MDC.getCopyOfContextMap();
        MDC.clear();
    }

    @AfterEach
    void restoreMdc() {
        MDC.clear();
        if (previousContext != null) {
            MDC.setContextMap(previousContext);
        }
    }

    @Test
    void explicitReferencePreservesComponentsAndFormatting() {
        ErrorRef ref = ErrorRef.of("API", "INVAL", "12345", "LOAN");

        assertEquals("API-INVAL", ref.getApiErrorCode());
        assertEquals("12345", ref.getJourneyIdAlias());
        assertEquals("LOAN", ref.getJourneyNameAlias());
        assertEquals("LOAN-API-INVAL-12345", ref.asString());
        assertEquals("LOAN-API-INVAL-12345", ErrorRef.of("API-INVAL", "12345", "LOAN").asString());
    }

    @Test
    void missingMdcUsesDefaultAliases() {
        assertEquals("UNKWN-UNKWN-INVAL-00000-00000", ErrorRef.of("INVAL").asString());
    }

    @Test
    void blankApiIdentifiersUseUnknownIdentifier() {
        for (String apiIdentifier : new String[]{null, "", " ", "\t"}) {
            ErrorRef ref = ErrorRef.of(apiIdentifier, "INVAL", "12345", "LOAN");
            assertEquals("LOAN-UNKWN-INVAL-12345", ref.asString());
        }
    }

    @Test
    void referenceCapturesMdcValuesAtCreation() {
        MDCValues.setApiNameCode("OTP");
        MDCValues.setJourneyIdAlias("12345");
        MDCValues.setJourneyNameAlias("LOAN");
        ErrorRef ref = ErrorRef.of("INVAL");

        MDCValues.setJourneyIdAlias("99999");

        assertEquals("LOAN-OTP-INVAL-12345", ref.asString());
    }

    @Test
    void blankMdcAliasesUseDefaults() {
        for (String blank : new String[]{"", " ", "\t"}) {
            MDCValues.setApiNameCode(blank);
            MDCValues.setJourneyIdAlias(blank);
            MDCValues.setJourneyNameAlias(blank);

            assertEquals("UNKWN-UNKWN-INVAL-00000-00000", ErrorRef.of("INVAL").asString());
        }
    }

    record CommonError(String code, Supplier<ErrorRef> create) {
    }

    static Stream<CommonError> commonErrors() {
        return Stream.of(
                new CommonError("UNKWN", ErrorRef::unknown),
                new CommonError("NOJID", ErrorRef::journeyIdMissing),
                new CommonError("NOJNM", ErrorRef::journeyNameMissing),
                new CommonError("INVAL", ErrorRef::inputValidation),
                new CommonError("NOJSM", ErrorRef::journeyStateMissing),
                new CommonError("COLOF", ErrorRef::cooloff),
                new CommonError("CUSVE", ErrorRef::customValidation),
                new CommonError("NOSID", ErrorRef::sessionMappingMissing),
                new CommonError("DWNER", ErrorRef::downstreamApiError),
                new CommonError("SYSER", ErrorRef::systemError)
        );
    }

    @TestFactory
    Stream<DynamicTest> namedFactoriesUseExpectedErrorCode() {
        return commonErrors().map(error -> dynamicTest(error.code(), () -> {
            MDCValues.setApiNameCode("API");
            MDCValues.setJourneyIdAlias("12345");
            MDCValues.setJourneyNameAlias("LOAN");

            assertEquals("LOAN-API-" + error.code() + "-12345", error.create().get().asString());
        }));
    }
}
