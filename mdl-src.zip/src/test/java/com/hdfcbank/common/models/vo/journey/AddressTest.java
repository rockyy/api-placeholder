package com.hdfcbank.common.models.vo.journey;

import org.junit.jupiter.api.Test;

import java.io.Serializable;

import static org.junit.jupiter.api.Assertions.*;

class AddressTest {

    @Test
    void testNoArgsConstructor() {
        Address address = new Address();

        assertNull(address.getType());
        assertNull(address.getAddress1());
        assertNull(address.getAddress2());
        assertNull(address.getAddress3());
        assertNull(address.getAddress4());
        assertNull(address.getZipCode());
        assertNull(address.getCity());
        assertNull(address.getState());
        assertNull(address.getCountry());
    }

    @Test
    void testAllArgsConstructor() {
        Address address = new Address(
                "HOME",
                "A1",
                "A2",
                "A3",
                "A4",
                "123456",
                "Mumbai",
                "MH",
                "India"
        );

        assertEquals("HOME", address.getType());
        assertEquals("A1", address.getAddress1());
        assertEquals("A2", address.getAddress2());
        assertEquals("A3", address.getAddress3());
        assertEquals("A4", address.getAddress4());
        assertEquals("123456", address.getZipCode());
        assertEquals("Mumbai", address.getCity());
        assertEquals("MH", address.getState());
        assertEquals("India", address.getCountry());
    }

    @Test
    void testBuilder() {
        Address address = Address.builder()
                .type("OFFICE")
                .address1("Line1")
                .address2("Line2")
                .address3("Line3")
                .address4("Line4")
                .zipCode("400001")
                .city("Mumbai")
                .state("MH")
                .country("India")
                .build();

        assertEquals("OFFICE", address.getType());
        assertEquals("Line1", address.getAddress1());
        assertEquals("Line2", address.getAddress2());
        assertEquals("Line3", address.getAddress3());
        assertEquals("Line4", address.getAddress4());
        assertEquals("400001", address.getZipCode());
        assertEquals("Mumbai", address.getCity());
        assertEquals("MH", address.getState());
        assertEquals("India", address.getCountry());
    }

    @Test
    void testSetters() {
        Address address = new Address();

        address.setType("TEMP");
        address.setAddress1("Addr1");
        address.setAddress2("Addr2");
        address.setAddress3("Addr3");
        address.setAddress4("Addr4");
        address.setZipCode("999999");
        address.setCity("Delhi");
        address.setState("DL");
        address.setCountry("India");

        assertEquals("TEMP", address.getType());
        assertEquals("Addr1", address.getAddress1());
        assertEquals("Addr2", address.getAddress2());
        assertEquals("Addr3", address.getAddress3());
        assertEquals("Addr4", address.getAddress4());
        assertEquals("999999", address.getZipCode());
        assertEquals("Delhi", address.getCity());
        assertEquals("DL", address.getState());
        assertEquals("India", address.getCountry());
    }

    @Test
    void testSerializable() {
        Address address = new Address();
        assertTrue(address instanceof Serializable);
    }
}