package com.hdfcbank.common.models.constant;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class CustomJWTClaimsTest {

    @Test
    void testClaimNames() {
        assertEquals("jid", CustomJWTClaims.JOURNEY_ID.getClaimName());
        assertEquals("jnm", CustomJWTClaims.JOURNEY_NAME.getClaimName());
        assertEquals("uah", CustomJWTClaims.USER_AGENT_HASH.getClaimName());
        assertEquals("ach", CustomJWTClaims.ADMIN_ACCESS_HASH.getClaimName());
        assertEquals("User", CustomJWTClaims.USER.getClaimName());
    }

    @Test
    void testEnumCount() {
        // Safety: fails if new constants added unintentionally
        assertEquals(5, CustomJWTClaims.values().length);
    }
}