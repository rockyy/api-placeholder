package com.hdfcbank.common.models.validation.validator;

import com.hdfcbank.common.models.validation.annotation.DateTimeFormat;
import jakarta.validation.ConstraintValidatorContext;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import static org.junit.jupiter.api.Assertions.*;

class DateTimeFormatValidatorTest {

    private DateTimeFormatValidator validator;
    private DateTimeFormat annotation;
    private ConstraintValidatorContext context;

    @BeforeEach
    void setup() {
        validator = new DateTimeFormatValidator();
        annotation = Mockito.mock(DateTimeFormat.class);
        context = Mockito.mock(ConstraintValidatorContext.class);

        validator.initialize(annotation);
    }

    @Test
    void testAllowBlankTrue_BlankValue_ShouldReturnTrue() {
        Mockito.when(annotation.allowBlank()).thenReturn(true);
        Mockito.when(annotation.pattern()).thenReturn("dd-MM-yyyy HH:mm:ss");

        assertTrue(validator.isValid("", context));
        assertTrue(validator.isValid("   ", context));
    }

    @Test
    void testAllowBlankFalse_BlankValue_ShouldReturnFalse() {
        Mockito.when(annotation.allowBlank()).thenReturn(false);
        Mockito.when(annotation.pattern()).thenReturn("dd-MM-yyyy HH:mm:ss");

        assertFalse(validator.isValid("", context));
        assertFalse(validator.isValid("   ", context));
    }

    @Test
    void testValidDateTime_ShouldReturnTrue() {
        Mockito.when(annotation.allowBlank()).thenReturn(false);
        Mockito.when(annotation.pattern()).thenReturn("dd-MM-yyyy HH:mm:ss");

        assertTrue(validator.isValid("25-12-2024 10:15:30", context));
    }

    @Test
    void testInvalidDateTime_ShouldReturnFalse() {
        Mockito.when(annotation.allowBlank()).thenReturn(false);
        Mockito.when(annotation.pattern()).thenReturn("dd-MM-yyyy HH:mm:ss");

        // invalid month & invalid seconds & incorrect format
        assertFalse(validator.isValid("2024-12-25 10:15:30", context));
        assertFalse(validator.isValid("25-99-2024 25:61:61", context));
    }

    @Test
    void testNonBlankButParseException_ShouldReturnFalse() {
        Mockito.when(annotation.allowBlank()).thenReturn(false);
        Mockito.when(annotation.pattern()).thenReturn("dd/MM/yyyy HH:mm:ss");

        assertFalse(validator.isValid("BAD-DATE", context));
    }
}