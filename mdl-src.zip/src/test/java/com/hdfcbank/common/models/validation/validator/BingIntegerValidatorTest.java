package com.hdfcbank.common.models.validation.validator;

import com.hdfcbank.common.models.validation.annotation.BigNumValidator;
import jakarta.validation.ConstraintValidatorContext;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import static org.junit.jupiter.api.Assertions.*;

class BingIntegerValidatorTest {

    private BingIntegerValidator validator;
    private BigNumValidator annotation;
    private ConstraintValidatorContext context;

    @BeforeEach
    void setup() {
        validator = new BingIntegerValidator();
        annotation = Mockito.mock(BigNumValidator.class);
        context = Mockito.mock(ConstraintValidatorContext.class);

        validator.initialize(annotation);
    }

    @Test
    void testNullValue_ShouldReturnFalse() {
        assertFalse(validator.isValid(null, context));
    }

    @Test
    void testZeroValue_ShouldReturnFalse() {
        assertFalse(validator.isValid(0, context));
    }

    @Test
    void testNegativeValue_ShouldReturnFalse() {
        assertFalse(validator.isValid(-5, context));
    }

    @Test
    void testValidSmallInteger_ShouldReturnTrue() {
        assertTrue(validator.isValid(12345, context));
    }

    @Test
    void testMaxInteger_ShouldReturnTrue() {
        // length = 10 digits → always valid
        assertTrue(validator.isValid(Integer.MAX_VALUE, context));
    }

    @Test
    void testMinIntegerPositiveBoundary_ShouldReturnTrue() {
        assertTrue(validator.isValid(1, context));
    }
}