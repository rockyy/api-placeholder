package com.hdfcbank.common.models.vo.misc;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class IdentifierTypeTest {

    @Test
    void testEnumValues() {
        assertEquals(IdentifierType.DOB, IdentifierType.valueOf("DOB"));
        assertEquals(IdentifierType.PAN, IdentifierType.valueOf("PAN"));
        assertEquals(IdentifierType.EMAIL, IdentifierType.valueOf("EMAIL"));
    }

    @Test
    void testEnumCount() {
        // Safety check: fails if new constants added unintentionally
        assertEquals(3, IdentifierType.values().length);
    }
}