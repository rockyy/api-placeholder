package com.hdfcbank.common.models.vo.enc;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class EncryptedModelsTest {

    private final ObjectMapper mapper = new ObjectMapper();

    @Test
    void requestAndResponsePreserveEncryptedContentAcrossJsonRoundTrips() throws Exception {
        String content = "eyJjaXBoZXIiOiIrLz0ifQ==";
        EncryptedRequest request = EncryptedRequest.builder().content(content).build();
        EncryptedResponse response = EncryptedResponse.builder().content(content).build();

        JsonNode expected = mapper.readTree("{\"content\":\"" + content + "\"}");

        assertEquals(expected, mapper.valueToTree(request));
        assertEquals(expected, mapper.valueToTree(response));
        assertEquals(content, mapper.readValue(mapper.writeValueAsString(request), EncryptedRequest.class).getContent());
        assertEquals(content, mapper.readValue(mapper.writeValueAsString(response), EncryptedResponse.class).getContent());
    }

    @Test
    void requestContentPreservesAllEnvelopeFieldsAndEscapedBody() throws Exception {
        String body = "{\"message\":\"line one\\nline two\"}";
        RequestContent content = RequestContent.builder()
                .iv("iv+/=")
                .encryptedKey("key+/=")
                .requestBody(body)
                .build();

        JsonNode json = mapper.valueToTree(content);
        RequestContent restored = mapper.treeToValue(json, RequestContent.class);

        assertEquals(3, json.size());
        assertEquals("iv+/=", json.path("iv").asText());
        assertEquals("key+/=", json.path("encryptedKey").asText());
        assertEquals(body, json.path("requestBody").asText());
        assertEquals(content.getIv(), restored.getIv());
        assertEquals(content.getEncryptedKey(), restored.getEncryptedKey());
        assertEquals(body, restored.getRequestBody());
    }
}
