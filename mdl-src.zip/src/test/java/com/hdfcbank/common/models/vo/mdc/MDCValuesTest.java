package com.hdfcbank.common.models.vo.mdc;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DynamicTest;
import org.junit.jupiter.api.TestFactory;
import org.slf4j.MDC;

import java.util.Map;
import java.util.function.Consumer;
import java.util.function.Supplier;
import java.util.stream.Stream;

import static com.hdfcbank.common.models.constant.MDCConstants.*;
import static org.junit.jupiter.api.Assertions.*;
import static org.junit.jupiter.api.DynamicTest.dynamicTest;

class MDCValuesTest {

    private Map<String, String> previousContext;

    @BeforeEach
    void saveAndClearContext() {
        previousContext = MDC.getCopyOfContextMap();
        MDC.clear();
    }

    @AfterEach
    void restoreContext() {
        MDC.clear();
        if (previousContext != null) {
            MDC.setContextMap(previousContext);
        }
    }

    record Accessor(String key, Consumer<String> set, Supplier<String> get) {
    }

    static Stream<Accessor> accessors() {
        return Stream.of(
                new Accessor(JOURNEY_ID, MDCValues::setJourneyId, MDCValues::getJourneyId),
                new Accessor(JOURNEY_NAME, MDCValues::setJourneyName, MDCValues::getJourneyName),
                new Accessor(USER_AGENT, MDCValues::setUserAgent, MDCValues::getUserAgent),
                new Accessor(CLIENT_IP, MDCValues::setClientIp, MDCValues::getClientIp),
                new Accessor(ACCESS_TOKEN, MDCValues::setAccessToken, MDCValues::getAccessToken),
                new Accessor(JOURNEY_ID_ALIAS, MDCValues::setJourneyIdAlias, MDCValues::getJourneyIdAlias),
                new Accessor(API_NAME_CODE, MDCValues::setApiNameCode, MDCValues::getApiNameCode),
                new Accessor(REQUEST_METHOD, MDCValues::setRequestMethod, MDCValues::getRequestMethod),
                new Accessor(REQUEST_URI, MDCValues::setRequestUri, MDCValues::getRequestUri),
                new Accessor(REQUEST_URL, MDCValues::setRequestUrl, MDCValues::getRequestUrl),
                new Accessor(REQUEST_HEADERS, MDCValues::setRequestHeaders, MDCValues::getRequestHeaders),
                new Accessor(REQUEST_BODY, MDCValues::setRequestBody, MDCValues::getRequestBody),
                new Accessor(RESPONSE_STATUS, MDCValues::setResponseStatus, MDCValues::getResponseStatus),
                new Accessor(RESPONSE_HEADERS, MDCValues::setResponseHeaders, MDCValues::getResponseHeaders),
                new Accessor(RESPONSE_BODY, MDCValues::setResponseBody, MDCValues::getResponseBody),
                new Accessor(TIME_TAKEN, MDCValues::setTimeTaken, MDCValues::getTimeTaken),
                new Accessor(CHANNEL, MDCValues::setChannel, MDCValues::getChannel),
                new Accessor(JOURNEY_NAME_ALIAS, MDCValues::setJourneyNameAlias, MDCValues::getJourneyNameAlias)
        );
    }

    @TestFactory
    Stream<DynamicTest> eachAccessorUsesItsOwnMdcKey() {
        return accessors().map(accessor -> dynamicTest(accessor.key(), () -> {
            MDC.clear();
            assertNull(accessor.get().get());

            accessor.set().accept("value");
            assertEquals("value", MDC.get(accessor.key()));
            assertEquals(Map.of(accessor.key(), "value"), MDCValues.getMDCAsMap());

            MDC.put(accessor.key(), "replacement");
            assertEquals("replacement", accessor.get().get());
        }));
    }

    @Test
    void blankChannelDoesNotOverwriteExistingValue() {
        for (String blank : new String[]{null, "", " ", "\t", "\n"}) {
            MDC.clear();
            MDCValues.setChannel(blank);
            assertNull(MDCValues.getChannel());

            MDCValues.setChannel("WEB");
            MDCValues.setChannel(blank);
            assertEquals("WEB", MDCValues.getChannel());
        }
    }

    @Test
    void nonblankChannelIsStoredWithoutTrimming() {
        MDCValues.setChannel(" WEB ");

        assertEquals(" WEB ", MDCValues.getChannel());
    }

    @Test
    void bulkUpdatesMergeAndReplaceValuesWithoutRemovingOtherKeys() {
        MDC.put("unrelated", "keep");
        MDCValues.setJourneyId("old");

        MDCValues.putAll(Map.of(JOURNEY_ID, "new", CHANNEL, "MOBILE"));

        assertEquals(Map.of("unrelated", "keep", JOURNEY_ID, "new", CHANNEL, "MOBILE"),
                MDCValues.getMDCAsMap());
    }

    @Test
    void snapshotIsIndependentAndClearRemovesContext() {
        MDCValues.setJourneyId("original");
        Map<String, String> snapshot = MDCValues.getMDCAsMap();
        snapshot.put(JOURNEY_ID, "changed in snapshot");
        assertEquals("original", MDCValues.getJourneyId());

        MDCValues.setJourneyId("updated");
        assertEquals("changed in snapshot", snapshot.get(JOURNEY_ID));

        MDCValues.clear();
        assertNull(MDCValues.getJourneyId());
        assertNull(MDCValues.getMDCAsMap());
    }
}
