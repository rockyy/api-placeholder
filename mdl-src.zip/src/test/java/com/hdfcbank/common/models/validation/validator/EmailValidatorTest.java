package com.hdfcbank.common.models.validation.validator;

import com.hdfcbank.common.models.validation.annotation.Email;
import jakarta.validation.ConstraintValidatorContext;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import static org.junit.jupiter.api.Assertions.*;

class EmailValidatorTest {

    private EmailValidator validator;
    private Email annotation;
    private ConstraintValidatorContext context;

    @BeforeEach
    void setup() {
        validator = new EmailValidator();
        annotation = Mockito.mock(Email.class);
        context = Mockito.mock(ConstraintValidatorContext.class);

        validator.initialize(annotation);
    }

    @Test
    void testAllowBlankTrue_BlankValue_ShouldReturnTrue() {
        Mockito.when(annotation.allowBlank()).thenReturn(true);
        Mockito.when(annotation.regex()).thenReturn(".*");

        assertTrue(validator.isValid("", context));
        assertTrue(validator.isValid("   ", context));
    }

    @Test
    void testAllowBlankFalse_BlankValue_ShouldReturnFalse() {
        Mockito.when(annotation.allowBlank()).thenReturn(false);
        Mockito.when(annotation.regex()).thenReturn(".*");

        assertFalse(validator.isValid("", context));
        assertFalse(validator.isValid("   ", context));
    }

    @Test
    void testValidEmailPattern_ShouldReturnTrue() {
        Mockito.when(annotation.allowBlank()).thenReturn(false);
        Mockito.when(annotation.regex()).thenReturn("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$");

        assertTrue(validator.isValid("test.user@domain.com", context));
        assertTrue(validator.isValid("abc123@xyz.in", context));
    }

    @Test
    void testInvalidEmailPattern_ShouldReturnFalse() {
        Mockito.when(annotation.allowBlank()).thenReturn(false);
        Mockito.when(annotation.regex()).thenReturn("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$");

        assertFalse(validator.isValid("invalid-email", context));
        assertFalse(validator.isValid("user@@domain.com", context)); // invalid chars
    }

    @Test
    void testNullValue_ShouldReturnFalse() {
        Mockito.when(annotation.allowBlank()).thenReturn(false);
        Mockito.when(annotation.regex()).thenReturn(".*");
        assertFalse(validator.isValid(null, context));
    }
}