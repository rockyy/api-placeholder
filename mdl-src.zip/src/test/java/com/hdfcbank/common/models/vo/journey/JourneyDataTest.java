package com.hdfcbank.common.models.vo.journey;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class JourneyDataTest {

    private final ObjectMapper mapper = new ObjectMapper();

    @Test
    void testNoArgsConstructor() {
        JourneyData jd = new JourneyData();

        assertNull(jd.getMobileNumber());
        assertNull(jd.getJourneyId());
        assertNull(jd.getJourneyName());
        assertNull(jd.getProfile());
        assertNull(jd.getClientIp());
        assertNull(jd.getJourneyDetail());
        assertNull(jd.getReferenceNo());
        assertNull(jd.getFinReference());
        assertNull(jd.getJourneyNameAlias());
        assertNull(jd.getJourneyIdAlias());
        assertNull(jd.getJourneyPhase());
        assertNull(jd.getCreatedOn());
        assertNull(jd.getUpdatedOn());
        assertNull(jd.getSessionDetails());
    }

    @Test
    void testAllArgsConstructor() {
        Profile profile = new Profile();
        JourneyDetail detail = new JourneyDetail();
        SessionDetail sd1 = new SessionDetail();
        SessionDetail sd2 = new SessionDetail();

        Date created = new Date();
        Date updated = new Date(created.getTime() + 5000);

        JourneyData jd = new JourneyData(
                "9876543210",
                "J123",
                "MyJourney",
                profile,
                "10.10.10.10",
                detail,
                "REF123",
                "FIN999",
                "JNAME_ALIAS",
                "JID_ALIAS",
                "PHASE1",
                created,
                updated,
                List.of(sd1, sd2)
        );

        assertEquals("9876543210", jd.getMobileNumber());
        assertEquals("J123", jd.getJourneyId());
        assertEquals("MyJourney", jd.getJourneyName());
        assertEquals(profile, jd.getProfile());
        assertEquals("10.10.10.10", jd.getClientIp());
        assertEquals(detail, jd.getJourneyDetail());
        assertEquals("REF123", jd.getReferenceNo());
        assertEquals("FIN999", jd.getFinReference());
        assertEquals("JNAME_ALIAS", jd.getJourneyNameAlias());
        assertEquals("JID_ALIAS", jd.getJourneyIdAlias());
        assertEquals("PHASE1", jd.getJourneyPhase());
        assertEquals(created, jd.getCreatedOn());
        assertEquals(updated, jd.getUpdatedOn());
        assertEquals(List.of(sd1, sd2), jd.getSessionDetails());
    }

    @Test
    void testBuilder() {
        Profile profile = new Profile();
        JourneyDetail detail = new JourneyDetail();
        SessionDetail sd = new SessionDetail();
        Date created = new Date();

        JourneyData jd = JourneyData.builder()
                .mobileNumber("9999999999")
                .journeyId("JX01")
                .journeyName("BuilderJourney")
                .profile(profile)
                .clientIp("127.0.0.1")
                .journeyDetail(detail)
                .referenceNo("REF-BUILD")
                .finReference("FIN-BUILD")
                .journeyNameAlias("BUILD_ALIAS_N")
                .journeyIdAlias("BUILD_ALIAS_I")
                .journeyPhase("PHASE-BUILD")
                .createdOn(created)
                .sessionDetails(List.of(sd))
                .build();

        assertEquals("9999999999", jd.getMobileNumber());
        assertEquals("JX01", jd.getJourneyId());
        assertEquals("BuilderJourney", jd.getJourneyName());
        assertEquals(profile, jd.getProfile());
        assertEquals("127.0.0.1", jd.getClientIp());
        assertEquals(detail, jd.getJourneyDetail());
        assertEquals("REF-BUILD", jd.getReferenceNo());
        assertEquals("FIN-BUILD", jd.getFinReference());
        assertEquals("BUILD_ALIAS_N", jd.getJourneyNameAlias());
        assertEquals("BUILD_ALIAS_I", jd.getJourneyIdAlias());
        assertEquals("PHASE-BUILD", jd.getJourneyPhase());
        assertEquals(created, jd.getCreatedOn());
        assertEquals(List.of(sd), jd.getSessionDetails());
    }

    @Test
    void testSetters() {
        JourneyData jd = new JourneyData();

        jd.setMobileNumber("12345");
        jd.setJourneyId("JID");
        jd.setJourneyName("JNAME");
        jd.setClientIp("1.1.1.1");
        jd.setReferenceNo("REF");
        jd.setFinReference("FIN");
        jd.setJourneyNameAlias("ALIAS-N");
        jd.setJourneyIdAlias("ALIAS-I");
        jd.setJourneyPhase("PHASE");
        Date now = new Date();
        jd.setCreatedOn(now);

        assertEquals("12345", jd.getMobileNumber());
        assertEquals("JID", jd.getJourneyId());
        assertEquals("JNAME", jd.getJourneyName());
        assertEquals("1.1.1.1", jd.getClientIp());
        assertEquals("REF", jd.getReferenceNo());
        assertEquals("FIN", jd.getFinReference());
        assertEquals("ALIAS-N", jd.getJourneyNameAlias());
        assertEquals("ALIAS-I", jd.getJourneyIdAlias());
        assertEquals("PHASE", jd.getJourneyPhase());
        assertEquals(now, jd.getCreatedOn());
    }

    @Test
    void testIgnoreUnknownPropertiesDuringDeserialization() throws Exception {
        String json = "{"
                + "\"mobileNumber\":\"99999\","
                + "\"journeyId\":\"JUNK-1\","
                + "\"unknownField\":\"xyz\""
                + "}";

        JourneyData jd = mapper.readValue(json, JourneyData.class);

        assertEquals("99999", jd.getMobileNumber());
        assertEquals("JUNK-1", jd.getJourneyId());
        assertNull(jd.getJourneyName());
    }

    @Test
    void testJsonFormatForDates() throws Exception {
        String json = "{"
                + "\"createdOn\":\"2023-01-01 10:20:30\","
                + "\"updatedOn\":\"2023-01-01 11:20:30\""
                + "}";

        JourneyData jd = mapper.readValue(json, JourneyData.class);

        assertNotNull(jd.getCreatedOn());
        assertNotNull(jd.getUpdatedOn());
    }

    @Test
    void testSerializable() {
        JourneyData jd = new JourneyData();
        assertTrue(jd instanceof Serializable);
    }
}