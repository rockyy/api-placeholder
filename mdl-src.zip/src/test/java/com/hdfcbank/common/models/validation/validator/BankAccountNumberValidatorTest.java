package com.hdfcbank.common.models.validation.validator;

import com.hdfcbank.common.models.validation.annotation.BankAccountNumber;
import jakarta.validation.ConstraintValidatorContext;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import static org.junit.jupiter.api.Assertions.*;

class BankAccountNumberValidatorTest {

    private BankAccountNumberValidator validator;
    private BankAccountNumber annotation;
    private ConstraintValidatorContext context;

    @BeforeEach
    void setup() {
        validator = new BankAccountNumberValidator();
        annotation = Mockito.mock(BankAccountNumber.class);
        context = Mockito.mock(ConstraintValidatorContext.class);
    }

    @Test
    void testAllowBlank_True_BlankValue_ShouldReturnTrue() {
        Mockito.when(annotation.allowBlank()).thenReturn(true);
        Mockito.when(annotation.regex()).thenReturn(".*");

        validator.initialize(annotation);

        assertTrue(validator.isValid("", context));
        assertTrue(validator.isValid("   ", context));
    }

    @Test
    void testAllowBlank_False_BlankValue_ShouldReturnFalse() {
        Mockito.when(annotation.allowBlank()).thenReturn(false);
        Mockito.when(annotation.regex()).thenReturn(".*");

        validator.initialize(annotation);

        assertFalse(validator.isValid("", context));
        assertFalse(validator.isValid("   ", context));
    }

    @Test
    void testValidRegexMatch_ShouldReturnTrue() {
        Mockito.when(annotation.allowBlank()).thenReturn(false);
        Mockito.when(annotation.regex()).thenReturn("^[0-9]{10,18}$"); // Example account regex

        validator.initialize(annotation);

        assertTrue(validator.isValid("1234567890", context));
        assertTrue(validator.isValid("987654321012345678", context));
    }

    @Test
    void testInvalidRegexMatch_ShouldReturnFalse() {
        Mockito.when(annotation.allowBlank()).thenReturn(false);
        Mockito.when(annotation.regex()).thenReturn("^[0-9]{10,18}$");

        validator.initialize(annotation);

        assertFalse(validator.isValid("ABC123", context));
        assertFalse(validator.isValid("123", context));
        assertFalse(validator.isValid("12345678AB", context));
    }

    @Test
    void testNullValue_ShouldReturnFalse() {
        Mockito.when(annotation.allowBlank()).thenReturn(false);
        Mockito.when(annotation.regex()).thenReturn("^[0-9]{10,18}$");

        validator.initialize(annotation);

        assertFalse(validator.isValid(null, context));
    }
}