package com.hdfcbank.common.models.vo.core;

import org.junit.jupiter.api.Test;
import org.springframework.data.domain.Sort;

import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

class PageDetailTest {

    @Test
    void preservesContentPaginationAndSortOrders() {
        List<Map<String, Object>> content = List.of(Map.of("id", 11), Map.of("id", 12));
        PageDetail.MasterPageSort sort = new PageDetail.MasterPageSort(
                Sort.Direction.DESC, List.of("name", "id"));

        PageDetail page = new PageDetail(content, 2, 1, sort, 7);

        assertAll(
                () -> assertEquals(content, page.getContent()),
                () -> assertEquals(2, page.getSize()),
                () -> assertEquals(1, page.getNumber()),
                () -> assertEquals(7, page.getTotalElements()),
                () -> assertEquals(4, page.getTotalPages()),
                () -> assertEquals(List.of(Sort.Order.desc("name"), Sort.Order.desc("id")),
                        page.getSort().stream().toList()),
                () -> assertTrue(page.hasNext()),
                () -> assertTrue(page.hasPrevious())
        );
    }

    @Test
    void nullOrEmptySortPropertiesProduceUnsortedPages() {
        assertTrue(new PageDetail.MasterPageSort(Sort.Direction.ASC, null).isUnsorted());
        assertTrue(new PageDetail.MasterPageSort(Sort.Direction.ASC, List.of()).isUnsorted());
        PageDetail page = new PageDetail(List.of(), 10, 0,
                new PageDetail.MasterPageSort(Sort.Direction.ASC, null), 0);

        assertTrue(page.isEmpty());
        assertEquals(0, page.getTotalElements());
        assertTrue(page.isFirst());
        assertTrue(page.isLast());
    }

    @Test
    void rejectsInvalidPageParameters() {
        PageDetail.MasterPageSort sort = new PageDetail.MasterPageSort(Sort.Direction.ASC, List.of("id"));

        assertThrows(IllegalArgumentException.class, () -> new PageDetail(List.of(), 0, 0, sort, 0));
        assertThrows(IllegalArgumentException.class, () -> new PageDetail(List.of(), -1, 0, sort, 0));
        assertThrows(IllegalArgumentException.class, () -> new PageDetail(List.of(), 10, -1, sort, 0));
    }
}
