package com.hdfcbank.common.models.vo.misc;

import org.junit.jupiter.api.Test;

import java.util.Date;

import static org.junit.jupiter.api.Assertions.*;

class GatewayContextTest {

    @Test
    void testNoArgsConstructor() {
        GatewayContext ctx = new GatewayContext();

        assertNull(ctx.getApiKey());
        assertNull(ctx.getScope());
        assertNull(ctx.getAppType());
        assertNull(ctx.getPartnerId());
        assertNull(ctx.getProductName());
        assertNull(ctx.getChannelId());
        assertNull(ctx.getAccessTokenDetails());
    }

    @Test
    void testAllArgsConstructor() {
        Date issuedAt = new Date();
        Date expiresAt = new Date(issuedAt.getTime() + 10_000);

        AccessTokenDetails tokenDetails = new AccessTokenDetails(
                "token-abc",
                issuedAt,
                expiresAt,
                10L
        );

        GatewayContext ctx = new GatewayContext(
                "key123",
                "scopeX",
                "APP",
                "partner001",
                "productABC",
                "channelXYZ",
                tokenDetails
        );

        assertEquals("key123", ctx.getApiKey());
        assertEquals("scopeX", ctx.getScope());
        assertEquals("APP", ctx.getAppType());
        assertEquals("partner001", ctx.getPartnerId());
        assertEquals("productABC", ctx.getProductName());
        assertEquals("channelXYZ", ctx.getChannelId());
        assertEquals(tokenDetails, ctx.getAccessTokenDetails());
    }

    @Test
    void testSetters() {
        GatewayContext ctx = new GatewayContext();

        AccessTokenDetails token = new AccessTokenDetails();
        token.setAccessToken("zzz");

        ctx.setApiKey("api");
        ctx.setScope("sc");
        ctx.setAppType("mobile");
        ctx.setPartnerId("pid");
        ctx.setProductName("prod");
        ctx.setChannelId("channel");
        ctx.setAccessTokenDetails(token);

        assertEquals("api", ctx.getApiKey());
        assertEquals("sc", ctx.getScope());
        assertEquals("mobile", ctx.getAppType());
        assertEquals("pid", ctx.getPartnerId());
        assertEquals("prod", ctx.getProductName());
        assertEquals("channel", ctx.getChannelId());
        assertEquals(token, ctx.getAccessTokenDetails());
    }

    @Test
    void testBuilder() {
        Date issuedAt = new Date();
        Date expiresAt = new Date(issuedAt.getTime() + 5000);

        AccessTokenDetails details = AccessTokenDetails.builder()
                .accessToken("builder-token")
                .issuedAt(issuedAt)
                .expiresAt(expiresAt)
                .tokenLifeInSec(5L)
                .build();

        GatewayContext ctx = GatewayContext.builder()
                .apiKey("api-builder")
                .scope("scope-builder")
                .appType("app-builder")
                .partnerId("partner-builder")
                .productName("product-builder")
                .channelId("channel-builder")
                .accessTokenDetails(details)
                .build();

        assertEquals("api-builder", ctx.getApiKey());
        assertEquals("scope-builder", ctx.getScope());
        assertEquals("app-builder", ctx.getAppType());
        assertEquals("partner-builder", ctx.getPartnerId());
        assertEquals("product-builder", ctx.getProductName());
        assertEquals("channel-builder", ctx.getChannelId());
        assertEquals(details, ctx.getAccessTokenDetails());
    }
}