package com.hdfcbank.common.models.validation.validator;

import com.hdfcbank.common.models.validation.annotation.AnnotationHelper;
import com.hdfcbank.common.models.validation.annotation.Url;
import jakarta.validation.ConstraintValidatorContext;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class UrlValidatorTest {

    private UrlValidator validator;
    private ConstraintValidatorContext context;

    @BeforeEach
    void setup() {
        validator = new UrlValidator();
        context = mock(ConstraintValidatorContext.class);
    }

    private Url strictUrlAnnotation(boolean allowBlank) {
        return AnnotationHelper.createAnnotation(
                Url.class,
                Map.of(
                        "allowBlank", allowBlank,
                        "regex", "^(https?:\\/\\/)([a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,}(\\/.*)?$",
                        "message", "Invalid URL"
                )
        );
    }

    @Test
    void testAllowBlankTrue_BlankValue() {
        validator.initialize(strictUrlAnnotation(true));

        assertTrue(validator.isValid("", context));
        assertTrue(validator.isValid("   ", context));
    }

    @Test
    void testAllowBlankFalse_BlankValue() {
        validator.initialize(strictUrlAnnotation(false));

        assertFalse(validator.isValid("", context));
        assertFalse(validator.isValid("   ", context));
    }

    @Test
    void testValidUrls() {
        validator.initialize(strictUrlAnnotation(false));

        assertTrue(validator.isValid("https://www.google.com", context));
        assertTrue(validator.isValid("http://example.com/path", context));
        assertTrue(validator.isValid("https://sub.domain.co.in/resource", context));
    }

    @Test
    void testInvalidUrls() {
        validator.initialize(strictUrlAnnotation(false));

        assertFalse(validator.isValid("google", context));
        assertFalse(validator.isValid("http//missing-colon.com", context));
        assertFalse(validator.isValid("http:/one-slash.com", context));
        assertFalse(validator.isValid("htp:/bad-url", context));
        assertFalse(validator.isValid("://missing.schema.com", context));
    }

    @Test
    void testNullValue() {
        validator.initialize(strictUrlAnnotation(false));
        assertFalse(validator.isValid(null, context));
    }
}