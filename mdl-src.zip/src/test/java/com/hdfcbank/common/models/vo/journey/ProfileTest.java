package com.hdfcbank.common.models.vo.journey;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;

import java.util.Date;
import java.util.List;

import static com.hdfcbank.common.models.constant.DateTimeConstants.FULL_DATE_TIME_FORMAT;
import static org.junit.jupiter.api.Assertions.*;

class ProfileTest {

    private final ObjectMapper mapper = new ObjectMapper();

    @Test
    void testNoArgsConstructor() {
        Profile p = new Profile();

        // Transient fields should be null
        assertNull(p.getAccountNumber());
        assertNull(p.getDob());
        assertNull(p.getPhoneNo());
        assertNull(p.getResiPhone());
        assertNull(p.getOffPhone());
        assertNull(p.getAccountId());

        // A few normal fields - ensure beans initialize to null/default
        assertNull(p.getSourceId());
        assertNull(p.getBranchCode());
        assertNull(p.getCustomerFullName());
        assertNull(p.getEmail());
        assertEquals(0, p.getCustomerDependents());
        assertEquals(0, p.getCustomerAnnualIncome());
    }

    @Test
    void testAllArgsConstructor() {
        Address addr = new Address();
        List<Address> addresses = List.of(addr);
        Date lastAccess = new Date();

        Profile p = new Profile(
                "AC123", "1990-01-01", "99999", "212123", "44112", "AID998",
                "SRC", "BR01",
                "A1", "A2", "A3", "A4",
                "Mumbai", "India", "MH", "400001",
                "8800112233", "Full Name", "022123123", "TypeX",
                2, "NAME", "999", "ADDR", "mail@test.com", "EmpType",
                "Employer", "30", "Mid", "Sur", "TYP", "PAN998",
                "SAS1", "DOB1", "NO1", "AAN998", "MPN123", "PCID",
                "CID123", "email@x.com", "oemail@x.com",
                "CRM01", "1234", true,
                lastAccess,
                addresses,
                "FN", "MN", "LN", "M", "S", "Mr.", "FN LN", "Short",
                "Mother", "PIN", "Prof", 200000,
                "Active", "KYCOK", true, "password",
                "Spouse", "MotherX", "FatherX", "IdentifierX", "NR",
                "KYC2020", "ETH1", "DescEth", true, "SourceData"
        );

        assertEquals("AC123", p.getAccountNumber());
        assertEquals("SRC", p.getSourceId());
        assertEquals(addresses, p.getAddresses());
        assertEquals(lastAccess, p.getLastAccessTime());
        assertTrue(p.isPanValid());
        assertTrue(p.isEtb());
        assertEquals("EmpType", p.getEmploymentType());
        assertEquals("Spouse", p.getSpouseName());
    }

    @Test
    void testBuilder() {
        Date lastAccess = new Date();
        Address addr = new Address();

        Profile p = Profile.builder()
                .accountNumber("ACC001")
                .dob("1991-01-01")
                .phoneNo("999")
                .sourceId("SRC")
                .customerFullName("John Doe")
                .customerDependents(3)
                .panValid(true)
                .lastAccessTime(lastAccess)
                .addresses(List.of(addr))
                .build();

        assertEquals("ACC001", p.getAccountNumber());
        assertEquals("SRC", p.getSourceId());
        assertEquals(3, p.getCustomerDependents());
        assertTrue(p.isPanValid());
        assertEquals(lastAccess, p.getLastAccessTime());
        assertEquals(List.of(addr), p.getAddresses());
    }

    @Test
    void testSetters() {
        Profile p = new Profile();
        p.setCustomerFullName("ABC XYZ");
        p.setCustomerAnnualIncome(900000);
        p.setPanValid(false);
        p.setGender("Female");
        p.setEmail("mail@test.com");

        assertEquals("ABC XYZ", p.getCustomerFullName());
        assertEquals(900000, p.getCustomerAnnualIncome());
        assertFalse(p.isPanValid());
        assertEquals("Female", p.getGender());
        assertEquals("mail@test.com", p.getEmail());
    }

    @Test
    void testJsonFormatForLastAccessTime() throws Exception {
        String json = "{ \"lastAccessTime\": \"2023-01-01T10:20:30Z\" }";

        Profile p = mapper.readValue(json, Profile.class);

        assertNotNull(p.getLastAccessTime(),
                "Should parse FULL_DATE_TIME_FORMAT: " + FULL_DATE_TIME_FORMAT);
    }

    @Test
    void testSerializable() {
        Profile p = new Profile();
        assertTrue(p instanceof java.io.Serializable);
    }

    @Test
    void testIgnoreUnknownFields() throws Exception {
        String json = "{"
                + "\"accountNumber\":\"AC1\","
                + "\"unknownField1\":\"xxx\","
                + "\"unknownField2\":999"
                + "}";

        Profile p = mapper.readValue(json, Profile.class);

        assertEquals("AC1", p.getAccountNumber());
        assertNull(p.getDob()); // untouched
    }
}