package com.hdfcbank.common.models.vo.misc;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DynamicTest;
import org.junit.jupiter.api.TestFactory;

import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;
import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.*;
import static org.junit.jupiter.api.DynamicTest.dynamicTest;

class MapsTest {

    static Stream<Method> factories() {
        return Arrays.stream(Maps.class.getDeclaredMethods())
                .filter(method -> method.getName().equals("of"))
                .sorted(Comparator.comparingInt(Method::getParameterCount));
    }

    @TestFactory
    Stream<DynamicTest> everyPublicFactoryPreservesAllKeyValuePairs() {
        return factories().map(factory -> dynamicTest((factory.getParameterCount() / 2) + " pairs", () -> {
            Object[] arguments = new Object[factory.getParameterCount()];
            Map<String, Integer> expected = new HashMap<>();
            for (int i = 0; i < arguments.length / 2; i++) {
                String key = "key-" + i;
                arguments[2 * i] = key;
                arguments[2 * i + 1] = i;
                expected.put(key, i);
            }

            Object result = factory.invoke(null, arguments);

            assertInstanceOf(Maps.class, result);
            assertEquals(expected, result);
        }));
    }

    @Test
    void allowsNullValuesAndReturnsMutableIndependentMaps() {
        Maps<String, String> first = Maps.of("optional", null, "required", "value");
        Maps<String, String> second = Maps.of("optional", null, "required", "value");

        assertTrue(first.containsKey("optional"));
        assertNull(first.get("optional"));
        first.put("extra", "added");
        first.remove("required");
        assertFalse(second.containsKey("extra"));
        assertEquals("value", second.get("required"));
    }

    @Test
    void rejectsNullKeys() {
        assertThrows(NullPointerException.class, () -> Maps.of(null, "value"));
        assertThrows(NullPointerException.class, () -> Maps.of("first", 1, null, 2));
    }

    @Test
    void rejectsDuplicateKeysIncludingKeysPreviouslyMappedToNull() {
        IllegalArgumentException error = assertThrows(IllegalArgumentException.class,
                () -> Maps.of("duplicate", 1, "duplicate", 2));

        assertEquals("Duplicate key duplicate", error.getMessage());
        assertThrows(IllegalArgumentException.class,
                () -> Maps.of("duplicate", null, "other", 2, "duplicate", 3));
    }
}
