package com.hdfcbank.common.models.vo.journey;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;

import java.util.Date;

import static com.hdfcbank.common.models.constant.DateTimeConstants.FULL_DATE_TIME_FORMAT;
import static org.junit.jupiter.api.Assertions.*;

class JourneyStateTest {

    private final ObjectMapper mapper = new ObjectMapper();

    @Test
    void testNoArgsConstructor() {
        JourneyState state = new JourneyState();

        assertNull(state.getStateName());
        assertNull(state.getCreatedOn());
        assertNull(state.getStateTime());
    }

    @Test
    void testAllArgsConstructor() {
        Date created = new Date();

        JourneyState state = new JourneyState(
                "INIT",
                created,
                "10:00:00"
        );

        assertEquals("INIT", state.getStateName());
        assertEquals(created, state.getCreatedOn());
        assertEquals("10:00:00", state.getStateTime());
    }

    @Test
    void testBuilder() {
        Date now = new Date();

        JourneyState state = JourneyState.builder()
                .stateName("PROCESSING")
                .createdOn(now)
                .stateTime("12:30:45")
                .build();

        assertEquals("PROCESSING", state.getStateName());
        assertEquals(now, state.getCreatedOn());
        assertEquals("12:30:45", state.getStateTime());
    }

    @Test
    void testSetters() {
        JourneyState state = new JourneyState();

        Date created = new Date();
        state.setStateName("COMPLETED");
        state.setCreatedOn(created);
        state.setStateTime("18:59:00");

        assertEquals("COMPLETED", state.getStateName());
        assertEquals(created, state.getCreatedOn());
        assertEquals("18:59:00", state.getStateTime());
    }

    @Test
    void testJsonIgnoreUnknownFields() throws Exception {
        String json = "{"
                + "\"stateName\": \"UNKNOWN\","
                + "\"createdOn\": \"2023-11-02T12:12:12Z\","
                + "\"stateTime\": \"11:11:11\","
                + "\"extraField\": \"ignoredValue\""
                + "}";

        JourneyState state = mapper.readValue(json, JourneyState.class);

        assertEquals("UNKNOWN", state.getStateName());
        assertEquals("11:11:11", state.getStateTime());
        assertNotNull(state.getCreatedOn());
    }

    @Test
    void testJsonFormatPatternForCreatedOn() throws Exception {
        String json = "{ \"createdOn\": \"2023-01-01T05:30:00Z\" }";

        JourneyState state = mapper.readValue(json, JourneyState.class);

        assertNotNull(state.getCreatedOn(),
                "createdOn should be parsed using FULL_DATE_TIME_FORMAT: " + FULL_DATE_TIME_FORMAT);
    }

    @Test
    void testSerializable() {
        JourneyState state = new JourneyState();
        assertTrue(state instanceof java.io.Serializable);
    }
}