package com.hdfcbank.common.models.vo.misc;

import org.junit.jupiter.api.Test;

import java.util.Date;

import static org.junit.jupiter.api.Assertions.*;

class AccessTokenDetailsTest {

    @Test
    void testAllArgsConstructorAndGetters() {
        Date issuedAt = new Date();
        Date expiresAt = new Date(issuedAt.getTime() + 5000);

        AccessTokenDetails details = new AccessTokenDetails(
                "token-123",
                issuedAt,
                expiresAt,
                5L
        );

        assertEquals("token-123", details.getAccessToken());
        assertEquals(issuedAt, details.getIssuedAt());
        assertEquals(expiresAt, details.getExpiresAt());
        assertEquals(5L, details.getTokenLifeInSec());
    }

    @Test
    void testSetters() {
        AccessTokenDetails details = new AccessTokenDetails();

        Date issuedAt = new Date();
        Date expiresAt = new Date(issuedAt.getTime() + 10000);

        details.setAccessToken("abc");
        details.setIssuedAt(issuedAt);
        details.setExpiresAt(expiresAt);
        details.setTokenLifeInSec(10L);

        assertEquals("abc", details.getAccessToken());
        assertEquals(issuedAt, details.getIssuedAt());
        assertEquals(expiresAt, details.getExpiresAt());
        assertEquals(10L, details.getTokenLifeInSec());
    }

    @Test
    void testNoArgsConstructor() {
        AccessTokenDetails details = new AccessTokenDetails();

        assertNull(details.getAccessToken());
        assertNull(details.getIssuedAt());
        assertNull(details.getExpiresAt());
        assertEquals(0L, details.getTokenLifeInSec());
    }

    @Test
    void testBuilder() {
        Date issuedAt = new Date();
        Date expiresAt = new Date(issuedAt.getTime() + 3000);

        AccessTokenDetails details = AccessTokenDetails.builder()
                .accessToken("builder-token")
                .issuedAt(issuedAt)
                .expiresAt(expiresAt)
                .tokenLifeInSec(3L)
                .build();

        assertEquals("builder-token", details.getAccessToken());
        assertEquals(issuedAt, details.getIssuedAt());
        assertEquals(expiresAt, details.getExpiresAt());
        assertEquals(3L, details.getTokenLifeInSec());
    }
}