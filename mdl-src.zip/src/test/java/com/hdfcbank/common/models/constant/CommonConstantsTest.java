package com.hdfcbank.common.models.constant;

import org.junit.jupiter.api.Test;

import java.lang.reflect.Constructor;

import static org.junit.jupiter.api.Assertions.*;

class CommonConstantsTest {

    @Test
    void testConstantsValues() {
        assertEquals("service", CommonConstants.SERVICE);
        assertEquals("event", CommonConstants.EVENT);
        assertEquals("retryCount", CommonConstants.RETRY_COUNT_HEADER_KEY);
        assertEquals("correlationId", CommonConstants.CORRELATION_ID);
        assertEquals("userData", CommonConstants.USER_DATA);
        assertEquals("journeyId", CommonConstants.JOURNEY_ID);
        assertEquals("x-journey-id", CommonConstants.JOURNEY_ID_HEADER);
        assertEquals("statusCode", CommonConstants.STATUS_CODE);
        assertEquals("requestUrl", CommonConstants.REQUEST_URL);
        assertEquals("NOT_AVAILABLE", CommonConstants.NOT_AVAILABLE);
        assertEquals("inbound", CommonConstants.INBOUND);
        assertEquals("outbound", CommonConstants.OUTBOUND);
        assertEquals("client_ip", CommonConstants.CLIENT_IP);
        assertEquals("User-Agent", CommonConstants.USER_AGENT);
        assertEquals("X-Forwarded-For", CommonConstants.X_FORWARDED_FOR);
    }

    @Test
    void testPrivateConstructorExists() throws Exception {
        Constructor<CommonConstants> constructor =
                CommonConstants.class.getDeclaredConstructor();

        // ✅ Constructor must be private
        assertTrue((constructor.getModifiers() & java.lang.reflect.Modifier.PRIVATE) != 0);

        // ✅ Reflective instantiation SHOULD NOT throw anything
        constructor.setAccessible(true);
        CommonConstants instance = constructor.newInstance();

        assertNotNull(instance);
    }
}