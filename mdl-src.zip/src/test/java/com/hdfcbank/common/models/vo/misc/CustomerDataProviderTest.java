package com.hdfcbank.common.models.vo.misc;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class CustomerDataProviderTest {

    @Test
    void testEnumValues() {
        assertEquals(CustomerDataProvider.CASA, CustomerDataProvider.valueOf("CASA"));
        assertEquals(CustomerDataProvider.CIF, CustomerDataProvider.valueOf("CIF"));
    }

    @Test
    void testEnumCount() {
        // Ensures no accidental enum additions/removals
        assertEquals(2, CustomerDataProvider.values().length);
    }
}