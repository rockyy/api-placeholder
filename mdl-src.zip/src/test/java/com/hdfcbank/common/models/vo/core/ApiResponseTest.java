package com.hdfcbank.common.models.vo.core;

import com.hdfcbank.common.models.constant.CommonApiStatusCodes;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

class ApiResponseTest {

    @Test
    void testNoArgsConstructor() {
        ApiResponse<String> response = new ApiResponse<>();

        assertNull(response.getStatus());
        assertNull(response.getData());
    }

    @Test
    void testAllArgsConstructor() {
        ApiResponseStatus status = ApiResponseStatus.success();
        ApiResponse<String> response = new ApiResponse<>(status, "OK");

        assertEquals(status, response.getStatus());
        assertEquals("OK", response.getData());
    }

    @Test
    void testSuperBuilder() {
        ApiResponseStatus status = ApiResponseStatus.systemError(null, "E1");

        ApiResponse<String> response = ApiResponse.<String>builder()
                .status(status)
                .data("Critical failure")
                .build();

        assertEquals(status, response.getStatus());
        assertEquals("Critical failure", response.getData());
    }

    @Test
    void testSetters() {
        ApiResponse<String> response = new ApiResponse<>();

        ApiResponseStatus status = ApiResponseStatus.success();
        response.setStatus(status);
        response.setData("DATA123");

        assertEquals(status, response.getStatus());
        assertEquals("DATA123", response.getData());
    }

    @Test
    void testSuccessFactoryMethod() {
        ApiResponse<String> response = ApiResponse.success("HELLO");

        assertStatus(CommonApiStatusCodes.SUCCESS, null, null, response.getStatus());
        assertEquals("HELLO", response.getData());
    }

    @Test
    void testSuccessFactoryMethodWithStatusLiteral() {
        ApiResponseStatusCodeLiteral literal = CommonApiStatusCodes.SUCCESS;
        ApiResponse<String> response = ApiResponse.success(literal, "WORLD");

        assertStatus(literal, null, null, response.getStatus());
        assertEquals("WORLD", response.getData());
    }

    @Test
    void testInputValidationErrorFactoryMethod() {
        ErrorRef ref = ErrorRef.of("E100", "12345", "LOAN");
        ApiResponse<String> response =
                ApiResponse.inputValidationError(ref, "field missing", "bad value");

        assertStatus(CommonApiStatusCodes.INPUT_VALIDATION_ERROR, ref,
                List.of("field missing", "bad value"), response.getStatus());
        assertNull(response.getData());
    }

    @Test
    void testBusinessValidationErrorFactoryMethod() {
        ErrorRef ref = ErrorRef.of("B200", "12345", "LOAN");
        ApiResponse<String> response =
                ApiResponse.businessValidationError(ref, "invalid state");

        assertStatus(CommonApiStatusCodes.INPUT_VALIDATION_ERROR, ref,
                List.of("invalid state"), response.getStatus());
        assertNull(response.getData());
    }

    @Test
    void testBusinessValidationErrorWithLiteral() {
        ErrorRef ref = ErrorRef.of("B300", "12345", "LOAN");
        ApiResponseStatusCodeLiteral literal = CommonApiStatusCodes.BUSINESS_VALIDATION_ERROR;

        ApiResponse<String> response =
                ApiResponse.businessValidationError(literal, ref, "condition failed");

        assertStatus(literal, ref, List.of("condition failed"), response.getStatus());
        assertNull(response.getData());
    }

    @Test
    void testDownstreamApiErrorFactoryMethod() {
        ErrorRef ref = ErrorRef.of("D100", "12345", "LOAN");
        ApiResponse<String> response =
                ApiResponse.downstreamApiError(ref, "timeout", "connection refused");

        assertStatus(CommonApiStatusCodes.DOWNSTREAM_API_ERROR, ref,
                List.of("timeout", "connection refused"), response.getStatus());
        assertNull(response.getData());
    }

    @Test
    void testSystemErrorFactoryMethod() {
        ErrorRef ref = ErrorRef.of("S100", "12345", "LOAN");
        ApiResponse<String> response =
                ApiResponse.systemError(ref, "fatal", "unexpected halt");

        assertStatus(CommonApiStatusCodes.SYSTEM_ERROR, ref,
                List.of("fatal", "unexpected halt"), response.getStatus());
        assertNull(response.getData());
    }

    @Test
    void testCustomValidationExceptionFactoryMethod() {
        ErrorRef ref = ErrorRef.of("CV100", "12345", "LOAN");
        List<String> errors = List.of("X", "Y", "Z");

        ApiResponse<String> response =
                ApiResponse.customValidationError(ref, "TYPE1", "TITLE1", errors);

        assertStatus(CommonApiStatusCodes.CUSTOM_VALIDATION_ERROR, ref, errors, response.getStatus());
        assertEquals("TYPE1", response.getStatus().getType());
        assertEquals("TITLE1", response.getStatus().getTitle());
        assertNull(response.getData());
    }

    @Test
    void testSerializable() throws Exception {
        ApiResponse<String> original = ApiResponse.success("payload");
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        try (ObjectOutputStream output = new ObjectOutputStream(bytes)) {
            output.writeObject(original);
        }
        try (ObjectInputStream input = new ObjectInputStream(new ByteArrayInputStream(bytes.toByteArray()))) {
            ApiResponse<?> restored = (ApiResponse<?>) input.readObject();
            assertEquals("payload", restored.getData());
            assertStatus(CommonApiStatusCodes.SUCCESS, null, null, restored.getStatus());
        }
    }

    @Test
    void jsonOmitsAbsentPayloadAndStatusFields() {
        ObjectMapper mapper = new ObjectMapper();
        ApiResponse<String> response = ApiResponse.inputValidationError(null);

        JsonNode json = mapper.valueToTree(response);

        assertEquals("8000", json.path("status").path("code").asText());
        assertEquals("input.validation.error", json.path("status").path("message").asText());
        assertFalse(json.has("data"));
        assertEquals(2, json.path("status").size());
    }

    @Test
    void jsonRoundTripPreservesGenericPayloadAndCustomStatus() throws Exception {
        ObjectMapper mapper = new ObjectMapper();
        ApiResponse<Map<String, List<Integer>>> original = ApiResponse.success(
                ApiResponseStatusCode.PROCESSING, Map.of("items", List.of(1, 2)));

        ApiResponse<Map<String, List<Integer>>> restored = mapper.readValue(
                mapper.writeValueAsString(original), new TypeReference<>() {});

        assertEquals(Map.of("items", List.of(1, 2)), restored.getData());
        assertStatus(ApiResponseStatusCode.PROCESSING, null, null, restored.getStatus());
    }

    private static void assertStatus(ApiResponseStatusCodeLiteral literal, ErrorRef ref,
                                     List<String> errors, ApiResponseStatus status) {
        assertAll(
                () -> assertEquals(literal.getCode(), status.getCode()),
                () -> assertEquals(literal.getMessage(), status.getMessage()),
                () -> assertEquals(ref == null ? null : ref.asString(), status.getErrorRef()),
                () -> assertEquals(errors, status.getErrors())
        );
    }
}
