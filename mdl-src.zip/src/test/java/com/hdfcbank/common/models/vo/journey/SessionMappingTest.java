package com.hdfcbank.common.models.vo.journey;

import org.junit.jupiter.api.Test;

import java.io.Serializable;

import static org.junit.jupiter.api.Assertions.*;

class SessionMappingTest {

    @Test
    void testNoArgsConstructor() {
        SessionMapping mapping = new SessionMapping();

        assertNull(mapping.getJourneyId());
        assertNull(mapping.getJourneyName());
        assertNull(mapping.getUserAgent());
        assertNull(mapping.getAuthToken());
    }

    @Test
    void testAllArgsConstructor() {
        SessionMapping mapping = new SessionMapping(
                "J123",
                "JourneyNameX",
                "Mozilla/5.0",
                "auth-token-xyz"
        );

        assertEquals("J123", mapping.getJourneyId());
        assertEquals("JourneyNameX", mapping.getJourneyName());
        assertEquals("Mozilla/5.0", mapping.getUserAgent());
        assertEquals("auth-token-xyz", mapping.getAuthToken());
    }

    @Test
    void testSetters() {
        SessionMapping mapping = new SessionMapping();

        mapping.setJourneyId("ID999");
        mapping.setJourneyName("JourneyABC");
        mapping.setUserAgent("Chrome");
        mapping.setAuthToken("token999");

        assertEquals("ID999", mapping.getJourneyId());
        assertEquals("JourneyABC", mapping.getJourneyName());
        assertEquals("Chrome", mapping.getUserAgent());
        assertEquals("token999", mapping.getAuthToken());
    }

    @Test
    void testBuilder() {
        SessionMapping mapping = SessionMapping.builder()
                .journeyId("B-JID")
                .journeyName("BuilderJourney")
                .userAgent("Safari")
                .authToken("builder-token")
                .build();

        assertEquals("B-JID", mapping.getJourneyId());
        assertEquals("BuilderJourney", mapping.getJourneyName());
        assertEquals("Safari", mapping.getUserAgent());
        assertEquals("builder-token", mapping.getAuthToken());
    }

    @Test
    void testSerializable() {
        SessionMapping mapping = new SessionMapping();
        assertTrue(mapping instanceof Serializable);
    }
}