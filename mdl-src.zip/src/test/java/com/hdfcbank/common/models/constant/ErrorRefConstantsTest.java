package com.hdfcbank.common.models.constant;

import org.junit.jupiter.api.Test;

import java.lang.reflect.Constructor;

import static org.junit.jupiter.api.Assertions.*;

class ErrorRefConstantsTest {

    @Test
    void testConstantValues() {
        assertEquals("UNKWN", ErrorRefConstants.UNKNOWN_API_IDENTIFIER);
        assertEquals("00000-00000", ErrorRefConstants.DEFAULT_JOURNEY_ID_ALIAS);
        assertEquals("UNKWN", ErrorRefConstants.DEFAULT_JOURNEY_NAME_ALIAS);
    }

    @Test
    void testClassCannotBeInstantiated() throws Exception {
        Constructor<ErrorRefConstants> c =
                ErrorRefConstants.class.getDeclaredConstructor();

        // Constructor is expected to be public (no Lombok UtilityClass)
        // but class is a constants holder, so reflectively instantiating is allowed.
        // We verify that:
        // 1) Constructor exists
        // 2) Instantiation succeeds (should NOT throw)
        c.setAccessible(true);
        ErrorRefConstants instance = c.newInstance();

        assertNotNull(instance);
    }
}