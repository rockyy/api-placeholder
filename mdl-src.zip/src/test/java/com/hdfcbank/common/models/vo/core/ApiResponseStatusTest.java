package com.hdfcbank.common.models.vo.core;

import com.hdfcbank.common.models.constant.CommonApiStatusCodes;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DynamicTest;
import org.junit.jupiter.api.TestFactory;

import java.util.List;
import java.util.function.BiFunction;
import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.*;
import static org.junit.jupiter.api.DynamicTest.dynamicTest;

class ApiResponseStatusTest {

    private static final ErrorRef ERROR_REF = ErrorRef.of("API-INVAL", "12345", "LOAN");

    record ErrorFactory(String name, CommonApiStatusCodes code,
                        BiFunction<ErrorRef, String[], ApiResponseStatus> create) {
    }

    static Stream<ErrorFactory> errorFactories() {
        return Stream.of(
                new ErrorFactory("inputValidationError", CommonApiStatusCodes.INPUT_VALIDATION_ERROR, ApiResponseStatus::inputValidationError),
                new ErrorFactory("businessValidationError", CommonApiStatusCodes.INPUT_VALIDATION_ERROR, ApiResponseStatus::businessValidationError),
                new ErrorFactory("downstreamApiError", CommonApiStatusCodes.DOWNSTREAM_API_ERROR, ApiResponseStatus::downstreamApiError),
                new ErrorFactory("systemError", CommonApiStatusCodes.SYSTEM_ERROR, ApiResponseStatus::systemError)
        );
    }

    @TestFactory
    Stream<DynamicTest> errorFactoriesPreserveReferenceAndErrorOrder() {
        return errorFactories().map(factory -> dynamicTest(factory.name(), () -> {
            ApiResponseStatus status = factory.create().apply(ERROR_REF, new String[]{"first", "second"});

            assertAll(
                    () -> assertEquals(factory.code().getCode(), status.getCode()),
                    () -> assertEquals(factory.code().getMessage(), status.getMessage()),
                    () -> assertEquals("LOAN-API-INVAL-12345", status.getErrorRef()),
                    () -> assertEquals(List.of("first", "second"), status.getErrors()),
                    () -> assertNull(status.getType()),
                    () -> assertNull(status.getTitle())
            );
        }));
    }

    @TestFactory
    Stream<DynamicTest> errorFactoriesOmitAbsentReferencesAndEmptyErrors() {
        return errorFactories().map(factory -> dynamicTest(factory.name(), () -> {
            ApiResponseStatus emptyErrors = factory.create().apply(null, new String[0]);
            ApiResponseStatus nullErrors = factory.create().apply(null, null);

            assertAll(
                    () -> assertNull(emptyErrors.getErrorRef()),
                    () -> assertNull(emptyErrors.getErrors()),
                    () -> assertNull(nullErrors.getErrorRef()),
                    () -> assertNull(nullErrors.getErrors())
            );
        }));
    }

    @Test
    void constructorsUseSuppliedStatusLiteralAndNormalizeEmptyLists() {
        ApiResponseStatusCodeLiteral literal = GenericApiResponseStatusCodeLiteral.of("8123", "Custom failure");
        ApiResponseStatus withError = new ApiResponseStatus(literal, "missing field");
        ApiResponseStatus withErrors = new ApiResponseStatus(literal, List.of("one", "two"));

        assertAll(
                () -> assertEquals("8123", withError.getCode()),
                () -> assertEquals("Custom failure", withError.getMessage()),
                () -> assertEquals(List.of("missing field"), withError.getErrors()),
                () -> assertEquals(List.of("one", "two"), withErrors.getErrors()),
                () -> assertNull(new ApiResponseStatus(literal).getErrors()),
                () -> assertNull(new ApiResponseStatus(literal, List.of()).getErrors()),
                () -> assertNull(new ApiResponseStatus(literal, (List<String>) null).getErrors())
        );
    }

    @Test
    void successCanUseDefaultOrCustomStatusWithoutErrors() {
        ApiResponseStatus defaultStatus = ApiResponseStatus.success();
        ApiResponseStatus customStatus = ApiResponseStatus.success(ApiResponseStatusCode.PROCESSING);

        assertAll(
                () -> assertEquals("0000", defaultStatus.getCode()),
                () -> assertEquals("Request succeeded", defaultStatus.getMessage()),
                () -> assertEquals("0002", customStatus.getCode()),
                () -> assertEquals("Request is currently processing", customStatus.getMessage()),
                () -> assertNull(customStatus.getErrorRef()),
                () -> assertNull(customStatus.getErrors())
        );
    }

    @Test
    void customBusinessErrorUsesProvidedCodeAndMessage() {
        ApiResponseStatusCodeLiteral literal = GenericApiResponseStatusCodeLiteral.of("8123", "Rule rejected");
        ApiResponseStatus status = ApiResponseStatus.businessValidationError(literal, ERROR_REF, "reason");

        assertEquals("8123", status.getCode());
        assertEquals("Rule rejected", status.getMessage());
        assertEquals(ERROR_REF.asString(), status.getErrorRef());
        assertEquals(List.of("reason"), status.getErrors());
    }

    @Test
    void customValidationPreservesProblemDetailsAndNormalizesEmptyErrors() {
        ApiResponseStatus status = ApiResponseStatus.customValidationException(
                ERROR_REF, "eligibility", "Invalid age", List.of("age is out of range"));

        assertAll(
                () -> assertEquals("5001", status.getCode()),
                () -> assertEquals("custom.validation.error", status.getMessage()),
                () -> assertEquals(ERROR_REF.asString(), status.getErrorRef()),
                () -> assertEquals("eligibility", status.getType()),
                () -> assertEquals("Invalid age", status.getTitle()),
                () -> assertEquals(List.of("age is out of range"), status.getErrors()),
                () -> assertNull(ApiResponseStatus.customValidationException(null, null, null, null).getErrors()),
                () -> assertNull(ApiResponseStatus.customValidationException(null, null, null, List.of()).getErrors())
        );
    }
}
