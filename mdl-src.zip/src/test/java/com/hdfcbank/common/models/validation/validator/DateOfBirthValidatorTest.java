package com.hdfcbank.common.models.validation.validator;

import com.hdfcbank.common.models.validation.annotation.DateOfBirth;
import com.hdfcbank.common.models.vo.core.DobAgeConfig;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.ConstraintValidatorContext;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;

import static org.junit.jupiter.api.Assertions.*;

class DateOfBirthValidatorTest {

    private DateOfBirthValidator validator;
    private DateOfBirth annotation;
    private DobAgeConfig dobAgeConfig;
    private HttpServletRequest request;
    private ConstraintValidatorContext context;

    @BeforeEach
    void setup() {
        validator = new DateOfBirthValidator();

        annotation = Mockito.mock(DateOfBirth.class);
        dobAgeConfig = Mockito.mock(DobAgeConfig.class);
        request = Mockito.mock(HttpServletRequest.class);
        context = Mockito.mock(ConstraintValidatorContext.class);

        inject("dobAgeConfig", dobAgeConfig);
        inject("request", request);

        validator.initialize(annotation);
    }

    private void inject(String fieldName, Object value) {
        try {
            var field = DateOfBirthValidator.class.getDeclaredField(fieldName);
            field.setAccessible(true);
            field.set(validator, value);
        } catch (ReflectiveOperationException e) {
            throw new AssertionError("Cannot inject test dependency " + fieldName, e);
        }
    }

    @Test
    void testAllowBlank_True_BlankValue() {
        Mockito.when(annotation.allowBlank()).thenReturn(true);
        Mockito.when(annotation.pattern()).thenReturn("dd-MM-yyyy");

        assertTrue(validator.isValid("", context));
        assertTrue(validator.isValid("   ", context));
    }

    @Test
    void testAllowBlank_False_BlankValue() {
        Mockito.when(annotation.allowBlank()).thenReturn(false);
        Mockito.when(annotation.pattern()).thenReturn("dd-MM-yyyy");

        assertFalse(validator.isValid("", context));
        assertFalse(validator.isValid("   ", context));
    }

    @Test
    void testAgeValidationDisabled_ShouldReturnTrue() {
        Mockito.when(annotation.allowBlank()).thenReturn(false);
        Mockito.when(annotation.ageValidation()).thenReturn(false);
        Mockito.when(annotation.pattern()).thenReturn("dd-MM-yyyy");

        assertTrue(validator.isValid("01-01-2000", context));
    }

    @Test
    void testValidAgeWithinRange_ShouldReturnTrue() {
        Mockito.when(annotation.allowBlank()).thenReturn(false);
        Mockito.when(annotation.ageValidation()).thenReturn(true);
        Mockito.when(annotation.pattern()).thenReturn("dd-MM-yyyy");
        Mockito.when(request.getHeader("x-journey-name")).thenReturn("loan");

        HashMap<String, DobAgeConfig.AgeRange> map = new HashMap<>();
        DobAgeConfig.AgeRange ageRange = new DobAgeConfig.AgeRange();
        ageRange.setMinAge(18);
        ageRange.setMaxAge(60);
        map.put("loan", ageRange);

        Mockito.when(dobAgeConfig.getValidation()).thenReturn(map);

        LocalDate dob = LocalDate.now().minusYears(30);
        String value = dob.format(DateTimeFormatter.ofPattern("dd-MM-yyyy"));

        assertTrue(validator.isValid(value, context));
    }

    @Test
    void testTooYoung_ShouldReturnFalse() {
        Mockito.when(annotation.allowBlank()).thenReturn(false);
        Mockito.when(annotation.ageValidation()).thenReturn(true);
        Mockito.when(annotation.pattern()).thenReturn("dd-MM-yyyy");
        Mockito.when(request.getHeader("x-journey-name")).thenReturn("loan");

        HashMap<String, DobAgeConfig.AgeRange> map = new HashMap<>();
        DobAgeConfig.AgeRange ageRange = new DobAgeConfig.AgeRange();
        ageRange.setMinAge(18);
        ageRange.setMaxAge(60);
        map.put("loan", ageRange);

        Mockito.when(dobAgeConfig.getValidation()).thenReturn(map);

        LocalDate dob = LocalDate.now().minusYears(10);
        String value = dob.format(DateTimeFormatter.ofPattern("dd-MM-yyyy"));

        assertFalse(validator.isValid(value, context));
    }

    @Test
    void testTooOld_ShouldReturnFalse() {
        Mockito.when(annotation.allowBlank()).thenReturn(false);
        Mockito.when(annotation.ageValidation()).thenReturn(true);
        Mockito.when(annotation.pattern()).thenReturn("dd-MM-yyyy");
        Mockito.when(request.getHeader("x-journey-name")).thenReturn("loan");

        HashMap<String, DobAgeConfig.AgeRange> map = new HashMap<>();
        DobAgeConfig.AgeRange ageRange = new DobAgeConfig.AgeRange();
        ageRange.setMinAge(18);
        ageRange.setMaxAge(60);
        map.put("loan", ageRange);

        Mockito.when(dobAgeConfig.getValidation()).thenReturn(map);

        LocalDate dob = LocalDate.now().minusYears(90);
        String value = dob.format(DateTimeFormatter.ofPattern("dd-MM-yyyy"));

        assertFalse(validator.isValid(value, context));
    }

    @Test
    void testInvalidPattern_ShouldReturnFalse() {
        Mockito.when(annotation.allowBlank()).thenReturn(false);
        Mockito.when(annotation.ageValidation()).thenReturn(true);

        Mockito.when(annotation.pattern()).thenReturn("yyyy/MM/dd");

        assertFalse(validator.isValid("31-12-2000", context));
    }

    @Test
    void nullBirthDateFollowsAllowBlankWithoutAccessingDependencies() {
        Mockito.when(annotation.allowBlank()).thenReturn(true);
        assertTrue(validator.isValid(null, context));

        Mockito.when(annotation.allowBlank()).thenReturn(false);
        assertFalse(validator.isValid(null, context));
        Mockito.verifyNoInteractions(request, dobAgeConfig);
    }

    @Test
    void ageValidationRejectsMissingJourneyConfiguration() {
        Mockito.when(annotation.pattern()).thenReturn("yyyy-MM-dd");
        Mockito.when(annotation.ageValidation()).thenReturn(true);
        Mockito.when(request.getHeader("x-journey-name")).thenReturn("unknown");
        Mockito.when(dobAgeConfig.getValidation()).thenReturn(new HashMap<>());

        assertFalse(validator.isValid("1990-01-01", context));
    }

    @Test
    void ageValidationRejectsMissingConfigurationMapAndHeaderFailures() {
        Mockito.when(annotation.pattern()).thenReturn("yyyy-MM-dd");
        Mockito.when(annotation.ageValidation()).thenReturn(true);

        assertFalse(validator.isValid("1990-01-01", context));

        Mockito.when(request.getHeader("x-journey-name")).thenThrow(new IllegalStateException("request unavailable"));
        assertFalse(validator.isValid("1990-01-01", context));
    }

    @Test
    void ageValidationAcceptsBirthdayAndRejectsAdjacentDatesOutsideRange() {
        Mockito.when(annotation.pattern()).thenReturn("yyyy-MM-dd");
        Mockito.when(annotation.ageValidation()).thenReturn(true);
        Mockito.when(request.getHeader("x-journey-name")).thenReturn("loan");
        DobAgeConfig.AgeRange ageRange = new DobAgeConfig.AgeRange();
        ageRange.setMinAge(18);
        ageRange.setMaxAge(60);
        HashMap<String, DobAgeConfig.AgeRange> ranges = new HashMap<>();
        ranges.put("loan", ageRange);
        Mockito.when(dobAgeConfig.getValidation()).thenReturn(ranges);

        LocalDate today = LocalDate.now();
        LocalDate youngest = today.minusYears(18);
        LocalDate oldest = today.minusYears(60);
        // If February 29 has no matching birth date, March 1 is the first eligible date.
        if (oldest.plusYears(60).isBefore(today)) {
            oldest = oldest.plusDays(1);
        }

        assertTrue(validator.isValid(youngest.toString(), context));
        assertTrue(validator.isValid(oldest.toString(), context));
        assertFalse(validator.isValid(youngest.plusDays(1).toString(), context));
        assertFalse(validator.isValid(oldest.minusDays(1).toString(), context));
    }
}
