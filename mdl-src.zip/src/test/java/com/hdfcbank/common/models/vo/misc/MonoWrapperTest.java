package com.hdfcbank.common.models.vo.misc;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DynamicTest;
import org.junit.jupiter.api.TestFactory;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.BiFunction;
import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.*;
import static org.junit.jupiter.api.DynamicTest.dynamicTest;

class MonoWrapperTest {

    @Test
    void testOfFactoryMethod() {
        Mono<String> mono = Mono.just("A");
        MonoWrapper<String> wrapper = MonoWrapper.of(mono);

        StepVerifier.create(
                        wrapper.drop(Mono.just("ignored"))
                ).expectNext("A")
                .verifyComplete();
    }

    @Test
    void testDropKeepsLeftMono() {
        Mono<String> left = Mono.just("LEFT");
        Mono<Integer> right = Mono.just(999);

        MonoWrapper<String> wrapper = MonoWrapper.of(left);

        StepVerifier.create(wrapper.drop(right))
                .expectNext("LEFT")
                .verifyComplete();
    }

    @Test
    void testKeepKeepsRightMono() {
        Mono<String> left = Mono.just("LEFT");
        Mono<Integer> right = Mono.just(123);

        MonoWrapper<String> wrapper = MonoWrapper.of(left);

        StepVerifier.create(wrapper.keep(right))
                .expectNext(123)
                .verifyComplete();
    }

    @Test
    void testDropLeftMonoMono() {
        Mono<String> left = Mono.just("L");
        Mono<String> right = Mono.just("R");

        StepVerifier.create(MonoWrapper.dropLeft(left, right))
                .expectNext("R")
                .verifyComplete();
    }

    @Test
    void testDropLeftObjectMono() {
        String left = "OBJ-L";
        Mono<String> right = Mono.just("R");

        StepVerifier.create(MonoWrapper.dropLeft(left, right))
                .expectNext("R")
                .verifyComplete();
    }

    @Test
    void testDropRightMonoMono() {
        Mono<String> left = Mono.just("L");
        Mono<String> right = Mono.just("R");

        StepVerifier.create(MonoWrapper.dropRight(left, right))
                .expectNext("L")
                .verifyComplete();
    }

    @Test
    void testDropRightMonoObject() {
        Mono<String> left = Mono.just("L");
        String right = "OBJ-R";

        StepVerifier.create(MonoWrapper.dropRight(left, right))
                .expectNext("L")
                .verifyComplete();
    }

    record Composition(String name, BiFunction<Mono<String>, Mono<String>, Mono<String>> compose) {
    }

    static Stream<Composition> compositions() {
        return Stream.of(
                new Composition("drop", (left, right) -> MonoWrapper.of(left).drop(right)),
                new Composition("keep", (left, right) -> MonoWrapper.of(left).keep(right)),
                new Composition("dropLeft", MonoWrapper::dropLeft),
                new Composition("dropRight", MonoWrapper::dropRight)
        );
    }

    @TestFactory
    Stream<DynamicTest> errorsFromEitherSourceArePropagated() {
        return compositions().map(composition -> dynamicTest(composition.name(), () -> {
            IllegalStateException failure = new IllegalStateException("source failed");

            StepVerifier.create(composition.compose().apply(Mono.error(failure), Mono.just("right")))
                    .expectErrorSatisfies(error -> assertSame(failure, error))
                    .verify();
            StepVerifier.create(composition.compose().apply(Mono.just("left"), Mono.error(failure)))
                    .expectErrorSatisfies(error -> assertSame(failure, error))
                    .verify();
        }));
    }

    @TestFactory
    Stream<DynamicTest> emptySourcePreventsEmissionFromEitherSide() {
        return compositions().map(composition -> dynamicTest(composition.name(), () -> {
            StepVerifier.create(composition.compose().apply(Mono.empty(), Mono.just("right")))
                    .verifyComplete();
            StepVerifier.create(composition.compose().apply(Mono.just("left"), Mono.empty()))
                    .verifyComplete();
        }));
    }

    @Test
    void sourceSideEffectsAreLazyAndRunOnEachSubscription() {
        AtomicInteger leftCalls = new AtomicInteger();
        AtomicInteger rightCalls = new AtomicInteger();
        Mono<Integer> result = MonoWrapper.of(Mono.fromSupplier(leftCalls::incrementAndGet))
                .keep(Mono.fromSupplier(rightCalls::incrementAndGet));

        assertEquals(0, leftCalls.get());
        assertEquals(0, rightCalls.get());
        StepVerifier.create(result).expectNext(1).verifyComplete();
        StepVerifier.create(result).expectNext(2).verifyComplete();
        assertEquals(2, leftCalls.get());
        assertEquals(2, rightCalls.get());
    }
}
