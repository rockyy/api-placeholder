package com.hdfcbank.common.models.vo.journey;

import org.junit.jupiter.api.Test;

import java.io.Serializable;

import static org.junit.jupiter.api.Assertions.*;

class SessionDetailTest {

    @Test
    void testNoArgsConstructor() {
        SessionDetail sd = new SessionDetail();

        assertNull(sd.getSessionId());
        assertNull(sd.getUserAgent());
        assertNull(sd.getIp());
    }

    @Test
    void testAllArgsConstructor() {
        SessionDetail sd = new SessionDetail(
                "SID123",
                "Mozilla/5.0",
                "127.0.0.1"
        );

        assertEquals("SID123", sd.getSessionId());
        assertEquals("Mozilla/5.0", sd.getUserAgent());
        assertEquals("127.0.0.1", sd.getIp());
    }

    @Test
    void testSetters() {
        SessionDetail sd = new SessionDetail();

        sd.setSessionId("ABCD");
        sd.setUserAgent("Chrome");
        sd.setIp("10.10.10.10");

        assertEquals("ABCD", sd.getSessionId());
        assertEquals("Chrome", sd.getUserAgent());
        assertEquals("10.10.10.10", sd.getIp());
    }

    @Test
    void testBuilder() {
        SessionDetail sd = SessionDetail.builder()
                .sessionId("BUILDER-SID")
                .userAgent("Builder-Agent")
                .ip("192.168.1.1")
                .build();

        assertEquals("BUILDER-SID", sd.getSessionId());
        assertEquals("Builder-Agent", sd.getUserAgent());
        assertEquals("192.168.1.1", sd.getIp());
    }

    @Test
    void testSerializable() {
        SessionDetail sd = new SessionDetail();
        assertTrue(sd instanceof Serializable);
    }
}