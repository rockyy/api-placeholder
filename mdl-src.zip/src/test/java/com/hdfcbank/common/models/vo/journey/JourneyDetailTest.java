package com.hdfcbank.common.models.vo.journey;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

class JourneyDetailTest {

    private final ObjectMapper mapper = new ObjectMapper();

    @Test
    void testNoArgsConstructor() {
        JourneyDetail detail = new JourneyDetail();

        assertNull(detail.getJourneyStates());
        assertNull(detail.getSystemData());
        assertNull(detail.getDomainData());
    }

    @Test
    void testAllArgsConstructor() {
        JourneyState st1 = new JourneyState();
        JourneyState st2 = new JourneyState();
        JourneyPage page = new JourneyPage();

        Map<String, Map<String, ?>> sysData = Map.of(
                "SYS", Map.of("k1", "v1")
        );

        Map<String, JourneyPage> domainData = Map.of(
                "PG1", page
        );

        JourneyDetail detail = new JourneyDetail(
                List.of(st1, st2),
                sysData,
                domainData
        );

        assertEquals(List.of(st1, st2), detail.getJourneyStates());
        assertEquals(sysData, detail.getSystemData());
        assertEquals(domainData, detail.getDomainData());
    }

    @Test
    void testBuilderWithSingularList() {
        JourneyState st1 = new JourneyState();
        JourneyState st2 = new JourneyState();

        JourneyDetail detail = JourneyDetail.builder()
                .journeyState(st1)      // @Singular adds one
                .journeyState(st2)      // adds another
                .systemData(Map.of("A", Map.of("B", "C")))
                .domainData(Map.of("P1", new JourneyPage()))
                .build();

        assertEquals(List.of(st1, st2), detail.getJourneyStates());
        assertEquals("C", detail.getSystemData().get("A").get("B"));
        assertTrue(detail.getDomainData().containsKey("P1"));
    }

    @Test
    void testBuilderWithList() {
        JourneyState st1 = new JourneyState();
        JourneyState st2 = new JourneyState();

        JourneyDetail detail = JourneyDetail.builder()
                .journeyStates(List.of(st1, st2))  // full list
                .systemData(Map.of("X", Map.of("Y", 123)))
                .domainData(Map.of("PG", new JourneyPage()))
                .build();

        assertEquals(List.of(st1, st2), detail.getJourneyStates());
        assertEquals(123, detail.getSystemData().get("X").get("Y"));
        assertTrue(detail.getDomainData().containsKey("PG"));
    }

    @Test
    void testSetters() {
        JourneyDetail detail = new JourneyDetail();

        JourneyState st = new JourneyState();
        JourneyPage pg = new JourneyPage();

        detail.setJourneyStates(List.of(st));
        detail.setSystemData(Map.of("K", Map.of("N", "VV")));
        detail.setDomainData(Map.of("DP", pg));

        assertEquals(List.of(st), detail.getJourneyStates());
        assertEquals("VV", detail.getSystemData().get("K").get("N"));
        assertEquals(pg, detail.getDomainData().get("DP"));
    }

    @Test
    void testJsonIgnoreUnknownFields() throws Exception {
        String json = "{"
                + "\"journeyStates\":[],"
                + "\"systemData\":{\"SYS\":{\"k\":\"v\"}},"
                + "\"domainData\":{},"
                + "\"unknownField\":123"
                + "}";

        JourneyDetail detail = mapper.readValue(json, JourneyDetail.class);

        assertNotNull(detail.getJourneyStates());
        assertTrue(detail.getJourneyStates().isEmpty());
        assertEquals("v", detail.getSystemData().get("SYS").get("k"));
        assertNotNull(detail.getDomainData());
    }

    @Test
    void testSerializable() {
        JourneyDetail detail = new JourneyDetail();
        assertTrue(detail instanceof java.io.Serializable);
    }
}