package com.hdfcbank.common.models.constant;

import org.junit.jupiter.api.Test;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;

import static org.junit.jupiter.api.Assertions.*;

class MDCConstantsTest {

    @Test
    void testConstantValues() {
        assertEquals("mdc-journey-id", MDCConstants.JOURNEY_ID);
        assertEquals("mdc-journey-name", MDCConstants.JOURNEY_NAME);
        assertEquals("mdc-journey-id-alias", MDCConstants.JOURNEY_ID_ALIAS);
        assertEquals("mdc-journey-name-alias", MDCConstants.JOURNEY_NAME_ALIAS);
        assertEquals("mdc-api-name", MDCConstants.API_NAME_CODE);
        assertEquals("mdc-session-id", MDCConstants.SESSION_ID);
        assertEquals("mdc-user-agent", MDCConstants.USER_AGENT);
        assertEquals("mdc-client-ip", MDCConstants.CLIENT_IP);
        assertEquals("mdc-request-method", MDCConstants.REQUEST_METHOD);
        assertEquals("mdc-request-uri", MDCConstants.REQUEST_URI);
        assertEquals("mdc-request-url", MDCConstants.REQUEST_URL);
        assertEquals("mdc-request-headers", MDCConstants.REQUEST_HEADERS);
        assertEquals("mdc-request-body", MDCConstants.REQUEST_BODY);
        assertEquals("mdc-response-status", MDCConstants.RESPONSE_STATUS);
        assertEquals("mdc-response-headers", MDCConstants.RESPONSE_HEADERS);
        assertEquals("mdc-response-body", MDCConstants.RESPONSE_BODY);
        assertEquals("mdc-time-taken", MDCConstants.TIME_TAKEN);
        assertEquals("mdc-access-token", MDCConstants.ACCESS_TOKEN);
        assertEquals("mdc-channel", MDCConstants.CHANNEL);
    }

    @Test
    void testUtilityClassConstructor() throws Exception {
        Constructor<MDCConstants> constructor =
                MDCConstants.class.getDeclaredConstructor();

        // ✅ Must be private because of Lombok @UtilityClass
        assertTrue((constructor.getModifiers() & java.lang.reflect.Modifier.PRIVATE) != 0);

        constructor.setAccessible(true);

        // ✅ Lombok @UtilityClass ALWAYS throws UnsupportedOperationException
        InvocationTargetException ex =
                assertThrows(InvocationTargetException.class, constructor::newInstance);

        assertNotNull(ex.getCause());
        assertTrue(ex.getCause() instanceof UnsupportedOperationException);
        assertEquals("This is a utility class and cannot be instantiated",
                ex.getCause().getMessage());
    }
}