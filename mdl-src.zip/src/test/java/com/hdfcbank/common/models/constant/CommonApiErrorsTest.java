package com.hdfcbank.common.models.constant;
import com.hdfcbank.common.models.constant.CommonApiErrors;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class CommonApiErrorsTest {

    @Test
    void testEnumNamesAndDescriptions() {

        assertEquals("Missing session id from cookie",
                CommonApiErrors.MISID.getDescription());

        assertEquals("Missing session id from claims",
                CommonApiErrors.MISCL.getDescription());

        assertEquals("No valid session available",
                CommonApiErrors.NOSID.getDescription());

        assertEquals("Header 'x-journey-id' is required",
                CommonApiErrors.NOJID.getDescription());

        assertEquals("Header 'x-journey-name' is required",
                CommonApiErrors.NOJNM.getDescription());

        assertEquals("Journey State is Missing",
                CommonApiErrors.NOJSM.getDescription());

        assertEquals("Timeout error",
                CommonApiErrors.TIMOT.getDescription());

        assertEquals("Input validation error",
                CommonApiErrors.INVAL.getDescription());

        assertEquals("Business validation error",
                CommonApiErrors.BUSVL.getDescription());

        assertEquals("Bad request error",
                CommonApiErrors.BADRQ.getDescription());

        assertEquals("Downstream api error",
                CommonApiErrors.DWNER.getDescription());

        assertEquals("System error",
                CommonApiErrors.SYSER.getDescription());

        assertEquals("Unknown error",
                CommonApiErrors.UNKWN.getDescription());

        assertEquals("Cooloff error",
                CommonApiErrors.COLOF.getDescription());

        assertEquals("Callback failed",
                CommonApiErrors.DPCAL.getDescription());

        assertEquals("Custom Validation error",
                CommonApiErrors.CUSVE.getDescription());
    }

    @Test
    void testTotalEnumCount() {
        // safety test: fails if future enum entries are added unintentionally
        assertEquals(16, CommonApiErrors.values().length);
    }
}