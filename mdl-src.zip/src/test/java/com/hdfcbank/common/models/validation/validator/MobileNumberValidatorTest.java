package com.hdfcbank.common.models.validation.validator;

import com.hdfcbank.common.models.validation.annotation.AnnotationHelper;
import com.hdfcbank.common.models.validation.annotation.MobileNumber;
import jakarta.validation.ConstraintValidatorContext;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class MobileNumberValidatorTest {

    private MobileNumberValidator validator;
    private MobileNumber annotation;
    private ConstraintValidatorContext context;

    @BeforeEach
    void setup() {
        validator = new MobileNumberValidator();
        annotation = AnnotationHelper.createAnnotation(
                MobileNumber.class,
                Map.of(
                        "allowBlank", false,
                        "regex", "^[6-9][0-9]{9}$",   // Indian mobile format
                        "message", "Invalid mobile number"
                )
        );
        context = mock(ConstraintValidatorContext.class);

        validator.initialize(annotation);
    }

    @Test
    void testAllowBlankTrue_BlankValue() {
        MobileNumber ann = AnnotationHelper.createAnnotation(
                MobileNumber.class,
                Map.of(
                        "allowBlank", true,
                        "regex", "^[6-9][0-9]{9}$",
                        "message", "Invalid mobile number"
                )
        );
        validator.initialize(ann);

        assertTrue(validator.isValid("", context));
        assertTrue(validator.isValid("   ", context));
    }

    @Test
    void testAllowBlankFalse_BlankValue() {
        assertFalse(validator.isValid("", context));
        assertFalse(validator.isValid("   ", context));
    }

    @Test
    void testValidMobileNumber() {
        assertTrue(validator.isValid("9876543210", context));
        assertTrue(validator.isValid("9123456789", context));
    }

    @Test
    void testInvalidMobileNumber() {
        assertFalse(validator.isValid("1234567890", context)); // starts with 1: invalid
        assertFalse(validator.isValid("987654321", context));  // too short
        assertFalse(validator.isValid("98765432101", context)); // too long
        assertFalse(validator.isValid("98A6543210", context)); // invalid character
    }

    @Test
    void testNullValue() {
        assertFalse(validator.isValid(null, context));
    }
}