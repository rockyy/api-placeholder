package com.hdfcbank.common.models.validation.validator;

import com.hdfcbank.common.models.validation.annotation.AnnotationHelper;
import com.hdfcbank.common.models.validation.annotation.ValueOfEnum;
import jakarta.validation.ConstraintValidatorContext;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class ValueOfEnumValidatorTest {

    private ValueOfEnumValidator validator;
    private ConstraintValidatorContext context;
    private ConstraintValidatorContext.ConstraintViolationBuilder builder;

    enum SampleEnum { ONE, TWO, THREE }

    @BeforeEach
    void setup() {
        validator = new ValueOfEnumValidator();
        context = mock(ConstraintValidatorContext.class);
        builder = mock(ConstraintValidatorContext.ConstraintViolationBuilder.class);

        when(context.buildConstraintViolationWithTemplate(anyString())).thenReturn(builder);
        when(builder.addConstraintViolation()).thenReturn(context);
    }

    private ValueOfEnum annotation(boolean strictMode, boolean allowBlank) {
        return AnnotationHelper.createAnnotation(
                ValueOfEnum.class,
                Map.of(
                        "value", SampleEnum.class,
                        "strictMode", strictMode,
                        "allowBlank", allowBlank,
                        "message", "Invalid Enum"
                )
        );
    }

    // ✅ allowBlank = true → blank returns true
    @Test
    void testAllowBlankTrue_BlankValue() {
        validator.initialize(annotation(false, true));

        assertTrue(validator.isValid("", context));
        assertTrue(validator.isValid("   ", context));
    }

    // ✅ allowBlank = false → blank returns false
    @Test
    void testAllowBlankFalse_BlankValue() {
        validator.initialize(annotation(false, false));

        assertFalse(validator.isValid("", context));
        assertFalse(validator.isValid("   ", context));
    }

    // ✅ strictMode = false → case-insensitive allowed
    @Test
    void testNonStrictMode_ValidCaseInsensitive() {
        validator.initialize(annotation(false, false));

        assertTrue(validator.isValid("one", context));
        assertTrue(validator.isValid("TWO", context));
        assertTrue(validator.isValid("three", context));
    }

    // ✅ strictMode = true → case-sensitive must match EXACT
    @Test
    void testStrictMode_CaseSensitive() {
        validator.initialize(annotation(true, false));

        assertTrue(validator.isValid("ONE", context));
        assertFalse(validator.isValid("one", context));
        assertFalse(validator.isValid("Two", context));
    }

    // ✅ invalid value → triggers violation builder
    @Test
    void testInvalidEnumValue_ShouldAddConstraintViolation() {
        validator.initialize(annotation(false, false));

        assertFalse(validator.isValid("INVALID", context));

        verify(context).disableDefaultConstraintViolation();
        verify(context).buildConstraintViolationWithTemplate(contains("ONE"));
        verify(builder).addConstraintViolation();
    }

    // ✅ null should return false (unless allowBlank = true)
    @Test
    void testNullValue() {
        validator.initialize(annotation(false, false));

        assertFalse(validator.isValid(null, context));
    }
}