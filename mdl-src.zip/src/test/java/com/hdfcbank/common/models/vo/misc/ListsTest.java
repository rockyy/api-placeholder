package com.hdfcbank.common.models.vo.misc;

import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Function;

import static org.junit.jupiter.api.Assertions.*;

class ListsTest {

    @Test
    void testMapMultipleElements() {
        List<Integer> input = List.of(1, 2, 3);
        List<String> output = Lists.of(input, i -> "N-" + i);
        assertEquals(List.of("N-1", "N-2", "N-3"), output);
    }

    @Test
    void testMapSingleElement() {
        List<String> input = List.of("x");
        List<Integer> output = Lists.of(input, String::length);
        assertEquals(List.of(1), output);
    }

    @Test
    void testEmptyList() {
        List<String> input = List.of();
        List<String> output = Lists.of(input, s -> s);
        assertTrue(output.isEmpty());
    }

    @Test
    void testOrderPreserved() {
        List<String> input = List.of("first", "second", "third");
        List<Integer> output = Lists.of(input, String::length);
        assertEquals(List.of(5, 6, 5), output);
    }

    @Test
    void testMapperReturnsNullValues() {
        List<String> input = List.of("a", "b");

        List<String> output = Lists.of(input, s -> null);

        // ✅ List.of(null, null) is illegal → use Arrays.asList() instead
        assertEquals(java.util.Arrays.asList(null, null), output);
    }

    @Test
    void nullInputReturnsEmptyListWithoutCallingMapper() {
        AtomicInteger calls = new AtomicInteger();

        List<String> output = Lists.of(null, value -> {
            calls.incrementAndGet();
            return "mapped";
        });

        assertTrue(output.isEmpty());
        assertEquals(0, calls.get());
        assertTrue(Lists.of(null, null).isEmpty());
    }

    @Test
    void nonnullInputRequiresMapperEvenWhenEmpty() {
        NullPointerException error = assertThrows(NullPointerException.class,
                () -> Lists.of(List.of("value"), null));

        assertEquals("Mapper function cannot be null", error.getMessage());
        assertThrows(NullPointerException.class, () -> Lists.of(List.of(), null));
    }

    @Test
    void mapperFailureIsPropagatedAndInputIsUnchanged() {
        IllegalStateException failure = new IllegalStateException("mapping failed");
        List<String> input = List.of("value");

        IllegalStateException thrown = assertThrows(IllegalStateException.class,
                () -> Lists.of(input, value -> { throw failure; }));

        assertSame(failure, thrown);
        assertEquals(List.of("value"), input);
    }

    @Test
    void mappedResultCanBeChangedWithoutChangingInput() {
        List<String> input = List.of("one", "two");
        List<String> output = Lists.of(input, Function.identity());

        output.add("three");

        assertEquals(List.of("one", "two"), input);
        assertEquals(List.of("one", "two", "three"), output);
    }
}
