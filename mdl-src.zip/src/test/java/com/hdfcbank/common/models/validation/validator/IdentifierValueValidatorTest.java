package com.hdfcbank.common.models.validation.validator;

import com.hdfcbank.common.models.validation.annotation.AnnotationHelper;
import com.hdfcbank.common.models.validation.annotation.IdentifierValue;
import com.hdfcbank.common.models.validation.annotation.DateOfBirth;
import com.hdfcbank.common.models.validation.annotation.Pan;
import jakarta.validation.ConstraintValidatorContext;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.config.AutowireCapableBeanFactory;
import org.springframework.context.ApplicationContext;

import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;
import static org.mockito.ArgumentMatchers.*;

class IdentifierValueValidatorTest {

    private IdentifierValueValidator validator;
    private IdentifierValue annotation;
    private ApplicationContext applicationContext;
    private AutowireCapableBeanFactory beanFactory;
    private ConstraintValidatorContext context;
    private ConstraintValidatorContext.ConstraintViolationBuilder builder;
    private ConstraintValidatorContext.ConstraintViolationBuilder.NodeBuilderCustomizableContext nodeBuilder;

    public static class TestObject {

        private String identifierName;
        private String identifierValue;

        public TestObject(String identifierName, String identifierValue) {
            this.identifierName = identifierName;
            this.identifierValue = identifierValue;
        }

        public String getIdentifierName() { return identifierName; }

        public String getIdentifierValue() { return identifierValue; }
    }

    @BeforeEach
    void setup() {

        validator = new IdentifierValueValidator();
        annotation = mock(IdentifierValue.class);
        applicationContext = mock(ApplicationContext.class);
        beanFactory = mock(AutowireCapableBeanFactory.class);
        context = mock(ConstraintValidatorContext.class);

        builder = mock(ConstraintValidatorContext.ConstraintViolationBuilder.class);
        nodeBuilder = mock(ConstraintValidatorContext.ConstraintViolationBuilder.NodeBuilderCustomizableContext.class);

        inject("applicationContext", applicationContext);

        when(annotation.identifierNameFieldName()).thenReturn("identifierName");
        when(annotation.identifierValueFieldName()).thenReturn("identifierValue");
        when(annotation.message()).thenReturn("PAN invalid");   // ✅ IMPORTANT FIX

        validator.initialize(annotation);

        when(applicationContext.getAutowireCapableBeanFactory()).thenReturn(beanFactory);

        // ✅ FIXED: ensure complete constraint builder chain
        when(context.buildConstraintViolationWithTemplate(anyString())).thenReturn(builder);
        when(builder.addPropertyNode(anyString())).thenReturn(nodeBuilder);
        when(nodeBuilder.addConstraintViolation()).thenReturn(context);
    }

    private void inject(String fieldName, Object value) {
        try {
            var field = IdentifierValueValidator.class.getDeclaredField(fieldName);
            field.setAccessible(true);
            field.set(validator, value);
        } catch (ReflectiveOperationException e) {
            throw new AssertionError("Cannot inject test dependency " + fieldName, e);
        }
    }

    // ✅ Valid PAN
    @Test
    void testValidPanIdentifier() {

        Pan panAnn = AnnotationHelper.createAnnotation(
                Pan.class,
                Map.of("regex", "^[A-Z]{5}[0-9]{4}[A-Z]$", "message", "Invalid PAN")
        );

        when(annotation.pan()).thenReturn(panAnn);

        TestObject obj = new TestObject("PAN", "ABCDE1234F");

        assertTrue(validator.isValid(obj, context));
        verifyNoInteractions(context, applicationContext);
    }

    // ✅ Invalid PAN (constraint builder MUST NOT be null now)
    @Test
    void testInvalidPanIdentifierValue() {

        Pan panAnn = AnnotationHelper.createAnnotation(
                Pan.class,
                Map.of("regex", "^[A-Z]{5}[0-9]{4}[A-Z]$", "message", "Invalid PAN")
        );

        when(annotation.pan()).thenReturn(panAnn);

        TestObject obj = new TestObject("PAN", "INVALIDPAN");

        assertFalse(validator.isValid(obj, context));

        verify(context).disableDefaultConstraintViolation();
        verify(context).buildConstraintViolationWithTemplate("PAN invalid");
        verify(builder).addPropertyNode("identifierValue");
        verify(nodeBuilder).addConstraintViolation();
    }

    // ✅ Valid DOB
    @Test
    void testValidDobIdentifier() {

        DateOfBirth dobAnn = AnnotationHelper.createAnnotation(
                DateOfBirth.class,
                Map.of("pattern", "dd-MM-yyyy",
                        "allowBlank", false,
                        "ageValidation", false,
                        "message", "Invalid DOB")
        );

        when(annotation.dateOfBirth()).thenReturn(dobAnn);

        TestObject obj = new TestObject("DOB", "01-01-1990");

        DateOfBirthValidator dobValidator = spy(new DateOfBirthValidator());

        when(beanFactory.createBean(DateOfBirthValidator.class)).thenReturn(dobValidator);

        assertTrue(validator.isValid(obj, context));
        verify(dobValidator).initialize(dobAnn);
        verify(dobValidator).isValid("01-01-1990", context);
        verifyNoInteractions(context);
    }

    // ✅ EMAIL → null validator → NPE
    @Test
    void testEmailIdentifierReturnsNullValidator() {
        TestObject obj = new TestObject("EMAIL", "abc@test.com");
        assertThrows(NullPointerException.class, () -> validator.isValid(obj, context));
    }

    // ✅ Invalid name
    @Test
    void testInvalidIdentifierName() {
        TestObject obj = new TestObject("WRONG_TYPE", "123");
        assertFalse(validator.isValid(obj, context));
        verify(context).buildConstraintViolationWithTemplate("must be any of [DOB, PAN, EMAIL]");
        verify(builder).addConstraintViolation();
        verifyNoInteractions(applicationContext);
    }

    // ✅ BeanUtils failure fully caught now
    @Test
    void testBeanUtilsException() {

        TestObject obj = new TestObject("PAN", "XYZ") {
            @Override
            public String getIdentifierName() {
                throw new RuntimeException("BeanUtils failure");
            }
        };

        assertFalse(validator.isValid(obj, context));
    }

    @Test
    void missingBeanPropertiesAndNullObjectAreRejected() {
        assertFalse(validator.isValid(new Object(), context));
        assertFalse(validator.isValid(null, context));
        verifyNoInteractions(context, applicationContext);
    }

    @Test
    void invalidDobCreatesViolationOnValueField() {
        DateOfBirth dob = AnnotationHelper.createAnnotation(DateOfBirth.class, Map.of());
        when(annotation.dateOfBirth()).thenReturn(dob);
        when(beanFactory.createBean(DateOfBirthValidator.class)).thenReturn(new DateOfBirthValidator());

        assertFalse(validator.isValid(new TestObject("DOB", "not-a-date"), context));

        verify(context).disableDefaultConstraintViolation();
        verify(context).buildConstraintViolationWithTemplate("PAN invalid");
        verify(builder).addPropertyNode("identifierValue");
        verify(nodeBuilder).addConstraintViolation();
    }

    public static class CustomFields {
        public String getType() { return "PAN"; }
        public String getNumber() { return "invalid"; }
    }

    @Test
    void configuredFieldNamesControlLookupAndViolationPath() {
        when(annotation.identifierNameFieldName()).thenReturn("type");
        when(annotation.identifierValueFieldName()).thenReturn("number");
        when(annotation.pan()).thenReturn(AnnotationHelper.createAnnotation(Pan.class, Map.of()));

        assertFalse(validator.isValid(new CustomFields(), context));

        verify(builder).addPropertyNode("number");
        verify(nodeBuilder).addConstraintViolation();
    }
}
