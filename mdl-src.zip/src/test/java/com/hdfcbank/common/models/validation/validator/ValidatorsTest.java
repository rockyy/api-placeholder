package com.hdfcbank.common.models.validation.validator;

import com.hdfcbank.common.models.validation.annotation.BankAccountNumber;
import com.hdfcbank.common.models.validation.annotation.BigNumValidator;
import com.hdfcbank.common.models.validation.annotation.DateOfBirth;
import com.hdfcbank.common.models.validation.annotation.DateTimeFormat;
import com.hdfcbank.common.models.validation.annotation.Email;
import com.hdfcbank.common.models.validation.annotation.MobileNumber;
import com.hdfcbank.common.models.validation.annotation.Pan;
import com.hdfcbank.common.models.validation.annotation.Url;
import com.hdfcbank.common.models.validation.annotation.ValidValue;
import com.hdfcbank.common.models.validation.annotation.ValueOfEnum;
import jakarta.validation.ConstraintValidatorContext;
import org.junit.jupiter.api.Test;

import java.lang.reflect.Proxy;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

class ValidatorsTest {

    enum Color { RED, BLUE }

    static class Sample {
        @MobileNumber
        String mobile;
        @MobileNumber(allowBlank = true)
        String optionalMobile;
        @Email
        String email;
        @Email(allowBlank = true)
        String optionalEmail;
        @Pan
        String pan;
        @Pan(allowBlank = true)
        String optionalPan;
        @Url
        String url;
        @Url(allowBlank = true)
        String optionalUrl;
        @BankAccountNumber
        String account;
        @BankAccountNumber(allowBlank = true)
        String optionalAccount;
        @DateTimeFormat
        String date;
        @DateTimeFormat(allowBlank = true)
        String optionalDate;
        @DateOfBirth
        String dob;
        @DateOfBirth(allowBlank = true)
        String optionalDob;
        @ValueOfEnum(value = Color.class)
        String color;
        @ValueOfEnum(value = Color.class, allowBlank = true)
        String optionalColor;
        @ValueOfEnum(value = Color.class, strictMode = true)
        String strictColor;
        @BigNumValidator
        Integer number;
        @ValidValue(validatorDefinition = ValidValueValidator.DefaultValidatorDefinition.class)
        String validValue;
    }

    @Test
    void mobileNumber() throws Exception {
        MobileNumberValidator validator = new MobileNumberValidator();
        validator.initialize(Sample.class.getDeclaredField("mobile").getAnnotation(MobileNumber.class));
        assertTrue(validator.isValid("9876543210", null));
        assertFalse(validator.isValid("123", null));
        assertFalse(validator.isValid("", null));

        MobileNumberValidator optional = new MobileNumberValidator();
        optional.initialize(Sample.class.getDeclaredField("optionalMobile").getAnnotation(MobileNumber.class));
        assertTrue(optional.isValid("", null));
    }

    @Test
    void email() throws Exception {
        EmailValidator validator = new EmailValidator();
        validator.initialize(Sample.class.getDeclaredField("email").getAnnotation(Email.class));
        assertTrue(validator.isValid("user@hdfc.com", null));
        assertFalse(validator.isValid("bad", null));
        assertFalse(validator.isValid("", null));

        EmailValidator optional = new EmailValidator();
        optional.initialize(Sample.class.getDeclaredField("optionalEmail").getAnnotation(Email.class));
        assertTrue(optional.isValid("", null));
    }

    @Test
    void pan() throws Exception {
        PanValidator validator = new PanValidator();
        validator.initialize(Sample.class.getDeclaredField("pan").getAnnotation(Pan.class));
        assertTrue(validator.isValid("ABCDE1234F", null));
        assertFalse(validator.isValid("123", null));
        assertFalse(validator.isValid("", null));

        PanValidator optional = new PanValidator();
        optional.initialize(Sample.class.getDeclaredField("optionalPan").getAnnotation(Pan.class));
        assertTrue(optional.isValid("", null));
    }

    @Test
    void url() throws Exception {
        UrlValidator validator = new UrlValidator();
        validator.initialize(Sample.class.getDeclaredField("url").getAnnotation(Url.class));
        assertTrue(validator.isValid("https://hdfcbank.com/path", null));
        assertFalse(validator.isValid("not-a-url", null));
        assertFalse(validator.isValid("", null));

        UrlValidator optional = new UrlValidator();
        optional.initialize(Sample.class.getDeclaredField("optionalUrl").getAnnotation(Url.class));
        assertTrue(optional.isValid("", null));
    }

    @Test
    void bankAccount() throws Exception {
        BankAccountNumberValidator validator = new BankAccountNumberValidator();
        validator.initialize(Sample.class.getDeclaredField("account").getAnnotation(BankAccountNumber.class));
        assertTrue(validator.isValid("1234567890", null));
        assertFalse(validator.isValid("abc", null));
        assertFalse(validator.isValid("", null));

        BankAccountNumberValidator optional = new BankAccountNumberValidator();
        optional.initialize(Sample.class.getDeclaredField("optionalAccount").getAnnotation(BankAccountNumber.class));
        assertTrue(optional.isValid("", null));
    }

    @Test
    void dateTimeFormat() throws Exception {
        DateTimeFormatValidator validator = new DateTimeFormatValidator();
        validator.initialize(Sample.class.getDeclaredField("date").getAnnotation(DateTimeFormat.class));
        assertTrue(validator.isValid("2026-01-31", null));
        assertFalse(validator.isValid("31-01-2026", null));
        assertFalse(validator.isValid("", null));

        DateTimeFormatValidator optional = new DateTimeFormatValidator();
        optional.initialize(Sample.class.getDeclaredField("optionalDate").getAnnotation(DateTimeFormat.class));
        assertTrue(optional.isValid("", null));
    }

    @Test
    void dateOfBirthWithoutAgeCheck() throws Exception {
        DateOfBirthValidator validator = new DateOfBirthValidator();
        validator.initialize(Sample.class.getDeclaredField("dob").getAnnotation(DateOfBirth.class));
        assertTrue(validator.isValid("1990-01-31", null));
        assertFalse(validator.isValid("not-a-date", null));
        assertFalse(validator.isValid("", null));

        DateOfBirthValidator optional = new DateOfBirthValidator();
        optional.initialize(Sample.class.getDeclaredField("optionalDob").getAnnotation(DateOfBirth.class));
        assertTrue(optional.isValid("", null));
    }

    @Test
    void valueOfEnum() throws Exception {
        ValueOfEnumValidator validator = new ValueOfEnumValidator();
        validator.initialize(Sample.class.getDeclaredField("color").getAnnotation(ValueOfEnum.class));
        assertTrue(validator.isValid("red", null));
        assertTrue(validator.isValid("BLUE", null));

        ValueOfEnumValidator optional = new ValueOfEnumValidator();
        optional.initialize(Sample.class.getDeclaredField("optionalColor").getAnnotation(ValueOfEnum.class));
        assertTrue(optional.isValid("", null));

        ValueOfEnumValidator strict = new ValueOfEnumValidator();
        strict.initialize(Sample.class.getDeclaredField("strictColor").getAnnotation(ValueOfEnum.class));
        assertTrue(strict.isValid("RED", null));
        assertFalse(strict.isValid("red", noOpContext()));
    }

    @Test
    void bigInteger() throws Exception {
        BingIntegerValidator validator = new BingIntegerValidator();
        validator.initialize(Sample.class.getDeclaredField("number").getAnnotation(BigNumValidator.class));
        assertTrue(validator.isValid(12, null));
        assertFalse(validator.isValid(0, null));
        assertFalse(validator.isValid(null, null));
    }

    @Test
    void validValueDefaultDefinition() throws Exception {
        ValidValueValidator validator = new ValidValueValidator();
        validator.initialize(Sample.class.getDeclaredField("validValue").getAnnotation(ValidValue.class));
        assertTrue(validator.isValid("anything", null));
    }

    private static ConstraintValidatorContext noOpContext() {
        Object builder = Proxy.newProxyInstance(
                ConstraintValidatorContext.class.getClassLoader(),
                new Class<?>[]{ConstraintValidatorContext.ConstraintViolationBuilder.class},
                (proxy, method, args) -> null);
        return (ConstraintValidatorContext) Proxy.newProxyInstance(
                ConstraintValidatorContext.class.getClassLoader(),
                new Class<?>[]{ConstraintValidatorContext.class},
                (proxy, method, args) -> "buildConstraintViolationWithTemplate".equals(method.getName()) ? builder : null);
    }
}
