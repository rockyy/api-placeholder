package com.hdfcbank.common.models.validation.validator;

import com.hdfcbank.common.models.validation.annotation.AnnotationHelper;
import com.hdfcbank.common.models.validation.annotation.ValidValue;
import jakarta.validation.ConstraintValidatorContext;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.config.AutowireCapableBeanFactory;
import org.springframework.context.ApplicationContext;

import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class ValidValueValidatorTest {

    private ValidValueValidator validator;
    private ApplicationContext applicationContext;
    private ConstraintValidatorContext context;

    // Custom validator for testing
    public static class CustomValidator implements ValidValueValidator.ValidatorDefinition {
        @Override
        public <T> boolean isValid(ValidValue annotation, T value, ConstraintValidatorContext context) {
            return value != null && value.toString().equals("OK");
        }
    }

    @BeforeEach
    void setup() {
        validator = new ValidValueValidator();
        applicationContext = mock(ApplicationContext.class);
        context = mock(ConstraintValidatorContext.class);

        injectField("applicationContext", applicationContext);
    }

    private void injectField(String fieldName, Object value) {
        try {
            var field = ValidValueValidator.class.getDeclaredField(fieldName);
            field.setAccessible(true);
            field.set(validator, value);
        } catch (ReflectiveOperationException e) {
            throw new AssertionError("Cannot inject test dependency " + fieldName, e);
        }
    }

    // ✅ UseBean=false → instantiate via BeanUtils
    @Test
    void testInstantiateValidatorDefinition() {

        ValidValue annotation = AnnotationHelper.createAnnotation(
                ValidValue.class,
                Map.of(
                        "validatorDefinition", CustomValidator.class,
                        "useBean", false,
                        "message", "Invalid"
                )
        );

        validator.initialize(annotation);

        assertTrue(validator.isValid("OK", context));
        assertFalse(validator.isValid("NOPE", context));
    }

    // ✅ UseBean=true → get bean from applicationContext
    @Test
    void testUseBeanValidatorDefinition() {

        CustomValidator bean = spy(new CustomValidator());

        when(applicationContext.getBean(CustomValidator.class))
                .thenReturn(bean);

        ValidValue annotation = AnnotationHelper.createAnnotation(
                ValidValue.class,
                Map.of(
                        "validatorDefinition", CustomValidator.class,
                        "useBean", true,
                        "message", "Invalid"
                )
        );

        validator.initialize(annotation);

        assertTrue(validator.isValid("OK", context));
        assertFalse(validator.isValid("OTHER", context));


        verify(bean, times(2))
                .isValidValue(eq(annotation), any(), eq(context));
    }

    // ✅ DefaultValidatorDefinition always returns true
    @Test
    void testDefaultValidatorDefinition() {

        ValidValue annotation = AnnotationHelper.createAnnotation(
                ValidValue.class,
                Map.of(
                        "validatorDefinition", ValidValueValidator.DefaultValidatorDefinition.class,
                        "useBean", false,
                        "message", "Invalid"
                )
        );

        validator.initialize(annotation);

        assertTrue(validator.isValid(null, context));
        assertTrue(validator.isValid("whatever", context));
    }
}
