package com.hdfcbank.common.models.constant;

import org.junit.jupiter.api.Test;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;

import static org.junit.jupiter.api.Assertions.*;

class RequestHeadersTest {

    @Test
    void testConstantValues() {
        assertEquals("Authorization", RequestHeaders.AUTHORIZATION);
        assertEquals("x-us-id", RequestHeaders.USER_SESSION_ID);
        assertEquals("x-journey-id", RequestHeaders.JOURNEY_ID);
        assertEquals("x-journey-name", RequestHeaders.JOURNEY_NAME);
        assertEquals("User-Agent", RequestHeaders.USER_AGENT);
        assertEquals("X-Forwarded-For", RequestHeaders.X_FORWARDED_FOR);
        assertEquals("x-client-auth", RequestHeaders.CLIENT_AUTH);
        assertEquals("x-channel", RequestHeaders.CHANNEL);
    }

    @Test
    void testUtilityClassConstructor() throws Exception {
        Constructor<RequestHeaders> constructor =
                RequestHeaders.class.getDeclaredConstructor();

        // ✅ Lombok @UtilityClass makes constructor PRIVATE
        assertTrue((constructor.getModifiers() & java.lang.reflect.Modifier.PRIVATE) != 0);

        // ✅ And it throws UnsupportedOperationException when instantiated
        constructor.setAccessible(true);

        InvocationTargetException ex =
                assertThrows(InvocationTargetException.class, constructor::newInstance);

        // ✅ Verify the REAL underlying exception
        assertNotNull(ex.getCause());
        assertTrue(ex.getCause() instanceof UnsupportedOperationException);
        assertEquals("This is a utility class and cannot be instantiated",
                ex.getCause().getMessage());
    }
}