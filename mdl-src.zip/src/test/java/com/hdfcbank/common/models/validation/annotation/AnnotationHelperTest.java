package com.hdfcbank.common.models.validation.annotation;

import jakarta.validation.Payload;
import org.junit.jupiter.api.Test;

import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

class AnnotationHelperTest {

    interface TestGroup {
    }

    interface TestPayload extends Payload {
    }

    @Test
    void usesAnnotationDefaultsWhenNoOverridesAreProvided() {
        BankAccountNumber annotation = AnnotationHelper.createAnnotation(BankAccountNumber.class, Map.of());

        assertSame(BankAccountNumber.class, annotation.annotationType());
        assertEquals("^\\d{1,20}$", annotation.regex());
        assertFalse(annotation.allowBlank());
        assertEquals("invalid bank account number, must be numeric and between 1 - 20 digits", annotation.message());
        assertArrayEquals(new Class<?>[0], annotation.groups());
        assertArrayEquals(new Class<?>[0], annotation.payload());
    }

    @Test
    void overridesScalarAndArrayMembersWhileRetainingOtherDefaults() {
        Pan annotation = AnnotationHelper.createAnnotation(Pan.class, Map.of(
                "regex", "^CUSTOM$",
                "message", "Custom PAN message",
                "allowBlank", true,
                "groups", new Class<?>[]{TestGroup.class},
                "payload", new Class<?>[]{TestPayload.class}));

        assertSame(Pan.class, annotation.annotationType());
        assertEquals("^CUSTOM$", annotation.regex());
        assertEquals("Custom PAN message", annotation.message());
        assertTrue(annotation.allowBlank());
        assertArrayEquals(new Class<?>[]{TestGroup.class}, annotation.groups());
        assertArrayEquals(new Class<?>[]{TestPayload.class}, annotation.payload());
    }

    @Test
    void supportsNestedAnnotationOverridesAndDefaults() {
        DateOfBirth dob = AnnotationHelper.createAnnotation(DateOfBirth.class, Map.of("pattern", "dd/MM/yyyy"));
        IdentifierValue annotation = AnnotationHelper.createAnnotation(IdentifierValue.class, Map.of("dateOfBirth", dob));

        assertSame(dob, annotation.dateOfBirth());
        assertEquals("dd/MM/yyyy", annotation.dateOfBirth().pattern());
        assertEquals("[A-Z]{5}[0-9]{4}[A-Z]{1}", annotation.pan().regex());
        assertEquals("identifierName", annotation.identifierNameFieldName());
        assertEquals("identifierValue", annotation.identifierValueFieldName());
    }
}
