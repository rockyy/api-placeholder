package com.hdfcbank.common.models.constant;

import org.junit.jupiter.api.Test;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;

import static org.junit.jupiter.api.Assertions.*;

class DateTimeConstantsTest {

    @Test
    void testConstantValues() {
        assertEquals("yyyy-MM-dd", DateTimeConstants.DATE_FORMAT);
        assertEquals("HH:mm:ss", DateTimeConstants.TIME_FORMAT);
        assertEquals("yyyy-MM-dd HH:mm:ss", DateTimeConstants.DATE_TIME_FORMAT);
        assertEquals("yyyy-MM-dd'T'HH:mm:ss'Z'", DateTimeConstants.FULL_DATE_TIME_FORMAT);
    }

    @Test
    void testUtilityClassPrivateConstructor() throws Exception {
        Constructor<DateTimeConstants> constructor =
                DateTimeConstants.class.getDeclaredConstructor();

        // Constructor must be private
        assertTrue((constructor.getModifiers() & java.lang.reflect.Modifier.PRIVATE) != 0);

        constructor.setAccessible(true);

        InvocationTargetException ex =
                assertThrows(InvocationTargetException.class, constructor::newInstance);

        // Cause MUST be UnsupportedOperationException
        assertTrue(ex.getCause() instanceof UnsupportedOperationException);
        assertEquals("This is a utility class and cannot be instantiated",
                ex.getCause().getMessage());
    }
}