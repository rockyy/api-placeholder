package com.hdfcbank.common.models.vo.journey;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;

import java.util.Date;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

class JourneyPageTest {

    private final ObjectMapper mapper = new ObjectMapper();

    @Test
    void testNoArgsConstructor() {
        JourneyPage page = new JourneyPage();

        assertNull(page.getPageName());
        assertNull(page.getCreatedOn());
        assertNull(page.getUserInputs());
    }

    @Test
    void testAllArgsConstructor() {
        Date created = new Date();
        Map<String,Object> inputs = Map.of(
                "key1", "value1",
                "key2", 100
        );

        JourneyPage page = new JourneyPage(
                "HomePage",
                created,
                inputs
        );

        assertEquals("HomePage", page.getPageName());
        assertEquals(created, page.getCreatedOn());
        assertEquals(inputs, page.getUserInputs());
    }

    @Test
    void testBuilder() {
        Date now = new Date();
        JourneyPage page = JourneyPage.builder()
                .pageName("Dashboard")
                .createdOn(now)
                .userInputs(Map.of("x", "y"))
                .build();

        assertEquals("Dashboard", page.getPageName());
        assertEquals(now, page.getCreatedOn());
        assertEquals("y", page.getUserInputs().get("x"));
    }

    @Test
    void testSetters() {
        JourneyPage page = new JourneyPage();

        Date created = new Date();
        Map<String,Object> inputs = Map.of("alpha", 123);

        page.setPageName("Settings");
        page.setCreatedOn(created);
        page.setUserInputs(inputs);

        assertEquals("Settings", page.getPageName());
        assertEquals(created, page.getCreatedOn());
        assertEquals(123, page.getUserInputs().get("alpha"));
    }

    @Test
    void testJsonIgnoreUnknownFields() throws Exception {
        String json = "{"
                + "\"pageName\": \"Summary\","
                + "\"createdOn\": \"2023-01-01T10:00:00Z\","
                + "\"userInputs\": {\"A\":\"B\"},"
                + "\"unknownField\": \"shouldBeIgnored\""
                + "}";

        JourneyPage page = mapper.readValue(json, JourneyPage.class);

        assertEquals("Summary", page.getPageName());
        assertNotNull(page.getUserInputs());
        assertEquals("B", page.getUserInputs().get("A"));
    }

    @Test
    void testSerializable() {
        JourneyPage page = new JourneyPage();
        assertTrue(page instanceof java.io.Serializable);
    }
}