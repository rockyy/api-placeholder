package com.hdfcbank.common.models.validation.validator;

import com.hdfcbank.common.models.validation.annotation.AnnotationHelper;
import com.hdfcbank.common.models.validation.annotation.Pan;
import jakarta.validation.ConstraintValidatorContext;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class PanValidatorTest {

    private PanValidator validator;
    private ConstraintValidatorContext context;

    @BeforeEach
    void setup() {
        validator = new PanValidator();
        context = mock(ConstraintValidatorContext.class);
    }

    @Test
    void testAllowBlankTrue_BlankValue() {
        Pan ann = AnnotationHelper.createAnnotation(
                Pan.class,
                Map.of(
                        "allowBlank", true,
                        "regex", "^[A-Z]{5}[0-9]{4}[A-Z]$",
                        "message", "Invalid PAN"
                )
        );

        validator.initialize(ann);

        assertTrue(validator.isValid("", context));
        assertTrue(validator.isValid("   ", context));
    }

    @Test
    void testAllowBlankFalse_BlankValue() {
        Pan ann = AnnotationHelper.createAnnotation(
                Pan.class,
                Map.of(
                        "allowBlank", false,
                        "regex", "^[A-Z]{5}[0-9]{4}[A-Z]$",
                        "message", "Invalid PAN"
                )
        );

        validator.initialize(ann);

        assertFalse(validator.isValid("", context));
        assertFalse(validator.isValid("   ", context));
    }

    @Test
    void testValidPan() {
        Pan ann = AnnotationHelper.createAnnotation(
                Pan.class,
                Map.of(
                        "allowBlank", false,
                        "regex", "^[A-Z]{5}[0-9]{4}[A-Z]$",
                        "message", "Invalid PAN"
                )
        );

        validator.initialize(ann);

        assertTrue(validator.isValid("ABCDE1234F", context));
        assertTrue(validator.isValid("QQQQQ9999Z", context));
    }

    @Test
    void testInvalidPan() {
        Pan ann = AnnotationHelper.createAnnotation(
                Pan.class,
                Map.of(
                        "allowBlank", false,
                        "regex", "^[A-Z]{5}[0-9]{4}[A-Z]$",
                        "message", "Invalid PAN"
                )
        );

        validator.initialize(ann);

        // invalid format cases
        assertFalse(validator.isValid("abcde1234f", context));  // lowercase
        assertFalse(validator.isValid("ABCDE12345", context));  // ends with digit
        assertFalse(validator.isValid("ABCDE12F4F", context));  // invalid position
        assertFalse(validator.isValid("ABCDE123", context));    // too short
        assertFalse(validator.isValid("ABCDE1234FF", context)); // too long
        assertFalse(validator.isValid("ABCDE12FZZ", context));  // wrong numeric section
        assertFalse(validator.isValid("1234512345", context));  // missing letters
    }

    @Test
    void testNullValue() {
        Pan ann = AnnotationHelper.createAnnotation(
                Pan.class,
                Map.of(
                        "allowBlank", false,
                        "regex", "^[A-Z]{5}[0-9]{4}[A-Z]$",
                        "message", "Invalid PAN"
                )
        );

        validator.initialize(ann);
        assertFalse(validator.isValid(null, context));
    }
}