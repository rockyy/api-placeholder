package com.hdfcbank.common.models.vo.core;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ApiErrorResponseTest {

    @Test
    void testNoArgsConstructor() {
        ApiErrorResponse response = new ApiErrorResponse();

        assertNull(response.getStatus());
        assertNull(response.getData());
    }

    @Test
    void testSuperBuilder() {
        ApiResponseStatus status = ApiResponseStatus.systemError(null, "E1");

        ApiErrorResponse response = ApiErrorResponse.builder()
                .status(status)
                .data("Critical failure occurred")
                .build();

        assertEquals(status, response.getStatus());
        assertEquals("Critical failure occurred", response.getData());
    }

    @Test
    void testInheritedSetters() {
        ApiErrorResponse response = new ApiErrorResponse();

        ApiResponseStatus status = ApiResponseStatus.businessValidationError(null, "ERR01");
        response.setStatus(status);
        response.setData("Invalid Input");

        assertEquals(status, response.getStatus());
        assertEquals("Invalid Input", response.getData());
    }

    @Test
    void testTypeParameterIsString() {
        ApiErrorResponse response = ApiErrorResponse.builder()
                .data("ErrorStringValue")
                .build();

        // ensures payload type is String
        assertTrue(response.getData() instanceof String);
    }

    @Test
    void specializedErrorBuildersPreserveInheritedStatusAndPayload() {
        ApiResponseStatus status = ApiResponseStatus.systemError(null, "failure");
        BadRequestErrorResponse badRequest = BadRequestErrorResponse.builder()
                .status(status).data("invalid request").build();
        DownstreamErrorResponse downstream = DownstreamErrorResponse.builder()
                .status(status).data("service unavailable").build();

        assertSame(status, badRequest.getStatus());
        assertEquals("invalid request", badRequest.getData());
        assertSame(status, downstream.getStatus());
        assertEquals("service unavailable", downstream.getData());
    }
}
