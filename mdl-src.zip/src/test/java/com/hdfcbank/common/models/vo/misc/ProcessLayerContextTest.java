package com.hdfcbank.common.models.vo.misc;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ProcessLayerContextTest {

    @Test
    void testNoArgsConstructor() {
        ProcessLayerContext ctx = new ProcessLayerContext();

        assertNull(ctx.getBankJourneyId());
        assertNull(ctx.getPartnerId());
        assertNull(ctx.getProductName());
        assertNull(ctx.getChannelId());
        assertNull(ctx.getFlowToken());
    }

    @Test
    void testSettersAndGetters() {
        ProcessLayerContext ctx = new ProcessLayerContext();

        ctx.setBankJourneyId("J123");
        ctx.setPartnerId("P001");
        ctx.setProductName("SAVINGS");
        ctx.setChannelId("MOBILE");
        ctx.setFlowToken("TOKEN-XYZ");

        assertEquals("J123", ctx.getBankJourneyId());
        assertEquals("P001", ctx.getPartnerId());
        assertEquals("SAVINGS", ctx.getProductName());
        assertEquals("MOBILE", ctx.getChannelId());
        assertEquals("TOKEN-XYZ", ctx.getFlowToken());
    }

    @Test
    void testFullPopulation() {
        ProcessLayerContext ctx = new ProcessLayerContext();

        ctx.setBankJourneyId("BJID-999");
        ctx.setPartnerId("PartnerABC");
        ctx.setProductName("InvestmentProduct");
        ctx.setChannelId("WEB");
        ctx.setFlowToken("FLOW-12345");

        assertAll(
                () -> assertEquals("BJID-999", ctx.getBankJourneyId()),
                () -> assertEquals("PartnerABC", ctx.getPartnerId()),
                () -> assertEquals("InvestmentProduct", ctx.getProductName()),
                () -> assertEquals("WEB", ctx.getChannelId()),
                () -> assertEquals("FLOW-12345", ctx.getFlowToken())
        );
    }
}