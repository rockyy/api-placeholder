package com.hdfcbank.common.models.constant;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
public enum CommonApiErrors {
    MISID("Missing session id from cookie"),
    MISCL("Missing session id from claims"),
    NOSID("No valid session available"),
    NOJID("Header 'x-journey-id' is required"),
    NOJNM("Header 'x-journey-name' is required"),
    NOJSM("Journey State is Missing"),
    TIMOT("Timeout error"),
    INVAL("Input validation error"),
    BUSVL("Business validation error"),
    BADRQ("Bad request error"),
    DWNER("Downstream api error"),
    SYSER("System error"),
    UNKWN("Unknown error"),
    COLOF("Cooloff error"),

    DPCAL("Callback failed"),
    CUSVE("Custom Validation error")

    ;

    private final String description;

    public String getDescription() {
        return description;
    }
}
