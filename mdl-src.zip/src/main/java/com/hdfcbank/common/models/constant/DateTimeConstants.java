package com.hdfcbank.common.models.constant;

import lombok.experimental.UtilityClass;

@UtilityClass
public class DateTimeConstants {
    public static final String DATE_FORMAT = "yyyy-MM-dd";
    public static final String TIME_FORMAT = "HH:mm:ss";
    public static final String DATE_TIME_FORMAT = "yyyy-MM-dd HH:mm:ss";
    public static final String FULL_DATE_TIME_FORMAT = "yyyy-MM-dd'T'HH:mm:ss'Z'";
}
