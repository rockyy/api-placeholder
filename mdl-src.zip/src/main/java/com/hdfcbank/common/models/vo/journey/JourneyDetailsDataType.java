package com.hdfcbank.common.models.vo.journey;

public enum JourneyDetailsDataType {
    DOMAIN_DATA, SYSTEM_DATA
}
