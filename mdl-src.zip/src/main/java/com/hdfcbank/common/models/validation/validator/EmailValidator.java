package com.hdfcbank.common.models.validation.validator;

import com.hdfcbank.common.models.validation.annotation.Email;
import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;
import org.apache.commons.lang3.StringUtils;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class EmailValidator implements ConstraintValidator<Email, String> {

    private Email constraintAnnotation;

    @Override
    public void initialize(Email constraintAnnotation) {
        this.constraintAnnotation = constraintAnnotation;
    }

    @Override
    public boolean isValid(String value, ConstraintValidatorContext context) {
        if (constraintAnnotation.allowBlank() && StringUtils.isBlank(value)) {
            return true;
        }
        if (StringUtils.isNoneBlank(value)) {
            Pattern pattern = Pattern.compile(constraintAnnotation.regex());
            Matcher matcher = pattern.matcher(value);
            return matcher.find();
        }
        return false;
    }
}
