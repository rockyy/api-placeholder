package com.hdfcbank.common.models.constant;

import com.hdfcbank.common.models.vo.core.ApiResponseStatusCodeLiteral;
import lombok.Getter;
import lombok.RequiredArgsConstructor;

@Getter
@RequiredArgsConstructor
public enum CommonApiStatusCodes implements ApiResponseStatusCodeLiteral {
    SUCCESS("0000", "Request succeeded"),
    FAILURE("9001", "Request failed"),
    INPUT_VALIDATION_ERROR("8000", "input.validation.error"),
    BUSINESS_VALIDATION_ERROR("1000", "business.validation.error"),
    DOWNSTREAM_API_ERROR("9000", "downstream.api.error"),
    SYSTEM_ERROR("9999", "system.error"),
    COOL_OFF_LIMIT_EXCEEDED_ERROR("1800", "cooloff.limit.exceeded.error"),
    DEPOSITORY_CALLBACK_FAILED_ERROR("1801", "depository.callback.failed"),
    CUSTOM_VALIDATION_ERROR("5001", "custom.validation.error");
    private final String code;
    private final String message;
}
