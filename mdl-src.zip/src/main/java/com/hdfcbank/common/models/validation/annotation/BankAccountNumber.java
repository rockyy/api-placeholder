package com.hdfcbank.common.models.validation.annotation;

import com.hdfcbank.common.models.validation.validator.BankAccountNumberValidator;
import jakarta.validation.Constraint;
import jakarta.validation.Payload;

import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import static java.lang.annotation.ElementType.*;

@Target({METHOD, FIELD, ANNOTATION_TYPE, CONSTRUCTOR, PARAMETER, TYPE_USE})
@Retention(RetentionPolicy.RUNTIME)
@Documented
@Constraint(validatedBy = BankAccountNumberValidator.class)
public @interface BankAccountNumber {

    String regex() default "^\\d{1,20}$"; // bank account must be between 1 and 20 digits

    String message() default "invalid bank account number, must be numeric and between 1 - 20 digits";

    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};

    boolean allowBlank() default false;
}
