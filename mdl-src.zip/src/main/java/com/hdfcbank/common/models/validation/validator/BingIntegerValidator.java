package com.hdfcbank.common.models.validation.validator;

import com.hdfcbank.common.models.validation.annotation.BigNumValidator;
import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

public class BingIntegerValidator implements ConstraintValidator<BigNumValidator, Integer> {

    private BigNumValidator constraintAnnotation;


    @Override
    public void initialize(BigNumValidator constraintAnnotation) {
        this.constraintAnnotation = constraintAnnotation;    }

    @Override
    public boolean isValid(Integer value, ConstraintValidatorContext context) {
        if (value == null || value <= 0) {
            return false;
        }
        int length = value.toString().length();
        if(length > 20)
            return false;
        return true;
    }
}
