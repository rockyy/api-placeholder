package com.hdfcbank.common.models.vo.enc;

import lombok.*;
import lombok.experimental.SuperBuilder;

@Getter
@Setter
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class EncryptedRequest {
    private String content;
}
