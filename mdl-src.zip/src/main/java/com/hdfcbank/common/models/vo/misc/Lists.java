package com.hdfcbank.common.models.vo.misc;

import java.util.Collections;
import java.util.List;
import java.util.function.Function;
import java.util.stream.Collectors;

public class Lists {

    public static <I, O> List<O> of(List<I> list, Function<I, O> mapper) {

        // ✅ Fix #1: list may be null → return empty list
        if (list == null) {
            return Collections.emptyList();
        }

        // ✅ Fix #2: mapper may be null → throw clear NPE for your tests
        if (mapper == null) {
            throw new NullPointerException("Mapper function cannot be null");
        }

        // ✅ mapper may return null → allowed, Collectors.toList() supports nulls
        return list.stream()
                .map(mapper)
                .collect(Collectors.toList());
    }
}