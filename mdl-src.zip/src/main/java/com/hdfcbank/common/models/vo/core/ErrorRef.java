package com.hdfcbank.common.models.vo.core;

import com.hdfcbank.common.models.constant.CommonApiErrors;
import com.hdfcbank.common.models.vo.mdc.MDCValues;
import lombok.AllArgsConstructor;
import lombok.Getter;
import org.apache.commons.lang3.StringUtils;

import static com.hdfcbank.common.models.constant.ErrorRefConstants.*;

public interface ErrorRef {

    String getApiErrorCode();

    String getJourneyIdAlias();

    String getJourneyNameAlias();

    default String asString() {
        return String.format("%s-%s-%s", getJourneyNameAlias(), getApiErrorCode(), getJourneyIdAlias());
    }

    static ErrorRef unknown() {
        return ErrorRef.of(CommonApiErrors.UNKWN.name());
    }

    static ErrorRef journeyIdMissing() {
        return ErrorRef.of(CommonApiErrors.NOJID.name());
    }

    static ErrorRef journeyNameMissing() {
        return ErrorRef.of(CommonApiErrors.NOJNM.name());
    }

    static ErrorRef inputValidation() { return ErrorRef.of(CommonApiErrors.INVAL.name()); }
    static ErrorRef journeyStateMissing() {
        return ErrorRef.of(CommonApiErrors.NOJSM.name());
    }



    static ErrorRef cooloff(){ return ErrorRef.of(CommonApiErrors.COLOF.name()); }

    static ErrorRef customValidation() {
        return ErrorRef.of(CommonApiErrors.CUSVE.name());
    }

    static ErrorRef sessionMappingMissing() {
        return ErrorRef.of(CommonApiErrors.NOSID.name());
    }

    static ErrorRef downstreamApiError() {
        return ErrorRef.of(CommonApiErrors.DWNER.name());
    }

    static ErrorRef systemError() {
        return ErrorRef.of(CommonApiErrors.SYSER.name());
    }

    static ErrorRef of(String errorCode) {
        String apiNameCode = MDCValues.getApiNameCode();
        String journeyIdAlias = StringUtils.defaultIfBlank(MDCValues.getJourneyIdAlias(), DEFAULT_JOURNEY_ID_ALIAS);
        String journeyNameAlias = StringUtils.defaultIfBlank(MDCValues.getJourneyNameAlias(), DEFAULT_JOURNEY_NAME_ALIAS);
        return of(apiNameCode, errorCode, journeyIdAlias, journeyNameAlias);
    }

    static ErrorRef of(String apiIdentifier, String errorCode, String journeyIdAlias, String journeyNameAlias) {
        apiIdentifier = StringUtils.defaultIfBlank(apiIdentifier, UNKNOWN_API_IDENTIFIER);
        String apiErrorCode = String.format("%s-%s", apiIdentifier, errorCode);
        return of(apiErrorCode, journeyIdAlias, journeyNameAlias);
    }

    static ErrorRef of(String apiErrorCode, String journeyIdAlias, String journeyNameAlias) {
        return new ErrorRefImpl(apiErrorCode, journeyIdAlias, journeyNameAlias);
    }

    @Getter
    @AllArgsConstructor
    class ErrorRefImpl implements ErrorRef {
        private String apiErrorCode;
        private String journeyIdAlias;
        private String journeyNameAlias;
    }

}
