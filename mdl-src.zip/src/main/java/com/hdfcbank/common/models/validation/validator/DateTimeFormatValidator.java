package com.hdfcbank.common.models.validation.validator;

import com.hdfcbank.common.models.validation.annotation.DateTimeFormat;
import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;
import org.apache.commons.lang3.StringUtils;

import java.time.format.DateTimeFormatter;

public class DateTimeFormatValidator implements ConstraintValidator<DateTimeFormat, String> {

    private DateTimeFormat constraintAnnotation;

    @Override
    public void initialize(DateTimeFormat constraintAnnotation) {
        this.constraintAnnotation = constraintAnnotation;
    }

    @Override
    public boolean isValid(String value, ConstraintValidatorContext context) {
        if (constraintAnnotation.allowBlank() && StringUtils.isBlank(value)) {
            return true;
        }
        if (StringUtils.isNoneBlank(value)) {
            try {
                DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern(constraintAnnotation.pattern());
                dateTimeFormatter.parse(value);
                return true;
            } catch (Exception e) {
                // silently skip exception
            }
        }
        return false;
    }
}