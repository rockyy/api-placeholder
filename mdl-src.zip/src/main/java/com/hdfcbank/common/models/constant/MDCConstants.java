package com.hdfcbank.common.models.constant;

import lombok.experimental.UtilityClass;

@UtilityClass
public class MDCConstants {
    public static final String JOURNEY_ID = "mdc-journey-id";
    public static final String JOURNEY_NAME = "mdc-journey-name";
    public static final String JOURNEY_ID_ALIAS = "mdc-journey-id-alias";
    public static final String JOURNEY_NAME_ALIAS = "mdc-journey-name-alias";
    public static final String API_NAME_CODE = "mdc-api-name";
    public static final String SESSION_ID = "mdc-session-id";
    public static final String USER_AGENT = "mdc-user-agent";
    public static final String CLIENT_IP = "mdc-client-ip";
    public static final String REQUEST_METHOD = "mdc-request-method";
    public static final String REQUEST_URI = "mdc-request-uri";
    public static final String REQUEST_URL = "mdc-request-url";
    public static final String REQUEST_HEADERS = "mdc-request-headers";
    public static final String REQUEST_BODY = "mdc-request-body";
    public static final String RESPONSE_STATUS = "mdc-response-status";
    public static final String RESPONSE_HEADERS = "mdc-response-headers";
    public static final String RESPONSE_BODY = "mdc-response-body";
    public static final String TIME_TAKEN = "mdc-time-taken";
    public static final String ACCESS_TOKEN = "mdc-access-token";
    public static final String CHANNEL = "mdc-channel";
}
