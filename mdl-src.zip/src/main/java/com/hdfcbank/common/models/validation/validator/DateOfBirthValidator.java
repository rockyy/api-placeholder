package com.hdfcbank.common.models.validation.validator;

import com.hdfcbank.common.models.validation.annotation.DateOfBirth;
import com.hdfcbank.common.models.vo.core.DobAgeConfig;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;

@Slf4j
public class DateOfBirthValidator implements ConstraintValidator<DateOfBirth, String> {

    private DateOfBirth constraintAnnotation;

    @Autowired
    private DobAgeConfig dobAgeConfig;

    @Autowired
    private HttpServletRequest request;

    @Override
    public void initialize(DateOfBirth constraintAnnotation) {
        this.constraintAnnotation = constraintAnnotation;
    }

    @Override
    public boolean isValid(String value, ConstraintValidatorContext context) {
        if (constraintAnnotation.allowBlank() && StringUtils.isBlank(value)) {
            return true;
        }
        if (StringUtils.isBlank(value)) {
            return false;
        }
        try {
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern(constraintAnnotation.pattern());
            LocalDate dob = LocalDate.parse(value, formatter);
            if (!constraintAnnotation.ageValidation()) {
                return true;
            }
            String journeyName = request.getHeader("x-journey-name");
            int minAge = dobAgeConfig.getValidation().get(journeyName).getMinAge();
            int maxAge = dobAgeConfig.getValidation().get(journeyName).getMaxAge();
            LocalDate today = LocalDate.now();
            boolean isMinValid = !today.isBefore(dob.plusYears(minAge));
            boolean isMaxValid = !today.isAfter(dob.plusYears(maxAge));
            return isMinValid && isMaxValid;
        } catch (Exception e) {
            return false;
        }
    }
}