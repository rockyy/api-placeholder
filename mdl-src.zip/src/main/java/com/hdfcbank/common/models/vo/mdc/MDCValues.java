package com.hdfcbank.common.models.vo.mdc;


import org.slf4j.MDC;

import java.util.Map;

import static com.hdfcbank.common.models.constant.MDCConstants.*;

public interface MDCValues {

    static String getJourneyId() {
        return MDC.get(JOURNEY_ID);
    }

    static void setJourneyId(String journeyId) {
        MDC.put(JOURNEY_ID, journeyId);
    }

    static String getJourneyName() {
        return MDC.get(JOURNEY_NAME);
    }

    static void setJourneyName(String journeyName) {
        MDC.put(JOURNEY_NAME, journeyName);
    }

    static String getUserAgent() {
        return MDC.get(USER_AGENT);
    }

    static void setUserAgent(String userAgent) {
        MDC.put(USER_AGENT, userAgent);
    }

    static String getClientIp() {
        return MDC.get(CLIENT_IP);
    }

    static void setClientIp(String clientIp) {
        MDC.put(CLIENT_IP, clientIp);
    }

    static String getAccessToken() {
        return MDC.get(ACCESS_TOKEN);
    }

    static void setAccessToken(String accessToken) {
        MDC.put(ACCESS_TOKEN, accessToken);
    }

    static String getJourneyIdAlias() {
        return MDC.get(JOURNEY_ID_ALIAS);
    }

    static void setJourneyIdAlias(String journeyIdAlias) {
        MDC.put(JOURNEY_ID_ALIAS, journeyIdAlias);
    }

    static String getApiNameCode() {
        return MDC.get(API_NAME_CODE);
    }

    static void setApiNameCode(String apiNameCode) {
        MDC.put(API_NAME_CODE, apiNameCode);
    }

    static String getRequestMethod() {
        return MDC.get(REQUEST_METHOD);
    }

    static void setRequestMethod(String requestMethod) {
        MDC.put(REQUEST_METHOD, requestMethod);
    }

    static String getRequestUri() {
        return MDC.get(REQUEST_URI);
    }

    static void setRequestUri(String requestUrl) {
        MDC.put(REQUEST_URI, requestUrl);
    }

    static String getRequestUrl() {
        return MDC.get(REQUEST_URL);
    }

    static void setRequestUrl(String requestUrl) {
        MDC.put(REQUEST_URL, requestUrl);
    }

    static String getRequestHeaders() {
        return MDC.get(REQUEST_HEADERS);
    }

    static void setRequestHeaders(String requestHeaders) {
        MDC.put(REQUEST_HEADERS, requestHeaders);
    }

    static String getRequestBody() {
        return MDC.get(REQUEST_BODY);
    }

    static void setRequestBody(String requestBody) {
        MDC.put(REQUEST_BODY, requestBody);
    }

    static String getResponseStatus() {
        return MDC.get(RESPONSE_STATUS);
    }

    static void setResponseStatus(String responseStatus) {
        MDC.put(RESPONSE_STATUS, responseStatus);
    }

    static String getResponseHeaders() {
        return MDC.get(RESPONSE_HEADERS);
    }

    static void setResponseHeaders(String responseHeaders) {
        MDC.put(RESPONSE_HEADERS, responseHeaders);
    }

    static String getResponseBody() {
        return MDC.get(RESPONSE_BODY);
    }

    static void setResponseBody(String responseBody) {
        MDC.put(RESPONSE_BODY, responseBody);
    }

    static String getTimeTaken() {
        return MDC.get(TIME_TAKEN);
    }

    static void setTimeTaken(String timeTaken) {
        MDC.put(TIME_TAKEN, timeTaken);
    }

    static String getChannel() {
        return MDC.get(CHANNEL);
    }

    static void setChannel(String channel) {
        if (channel != null && !channel.trim().isEmpty()) {
            MDC.put(CHANNEL, channel);
        }
    }

    static void setJourneyNameAlias(String journeyNameAlias) {
        MDC.put(JOURNEY_NAME_ALIAS, journeyNameAlias);
    }
    static String getJourneyNameAlias() {
        return MDC.get(JOURNEY_NAME_ALIAS);
    }

    static Map<String, String> getMDCAsMap() {
        return MDC.getCopyOfContextMap();
    }

    static void putAll(Map<String, String> map) {
        map.forEach(MDC::put);
    }

    static void clear() {
        MDC.clear();
    }

}
