package com.hdfcbank.common.models.vo.misc;

public enum CustomerDataProvider {
    CASA,
    CIF,

}
