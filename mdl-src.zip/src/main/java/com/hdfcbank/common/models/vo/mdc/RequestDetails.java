package com.hdfcbank.common.models.vo.mdc;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class RequestDetails {
    private String clientIp;
    private String userAgent;
    private String method;
    private String url;
    private String requestHeaders;
    private String requestBody;
    private String responseStatus;
    private String responseHeaders;
    private String responseBody;
    private String timeTaken;
    private String logMessage;
}
