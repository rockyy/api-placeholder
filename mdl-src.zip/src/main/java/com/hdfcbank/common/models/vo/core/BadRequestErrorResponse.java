package com.hdfcbank.common.models.vo.core;

import lombok.experimental.SuperBuilder;

@SuperBuilder
public class BadRequestErrorResponse extends ApiErrorResponse {
}
