package com.hdfcbank.common.models.vo.journey;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.*;
import org.springframework.data.annotation.CreatedDate;

import java.io.Serial;
import java.io.Serializable;
import java.util.Date;

import static com.hdfcbank.common.models.constant.DateTimeConstants.FULL_DATE_TIME_FORMAT;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class JourneyState implements Serializable {

    @Serial
    private static final long serialVersionUID = 1L;

    private String stateName;
    @CreatedDate
    @JsonFormat(pattern = FULL_DATE_TIME_FORMAT)
    private Date createdOn;
    private String stateTime;
}
