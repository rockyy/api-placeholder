package com.hdfcbank.common.models.vo.journey;

import lombok.*;

import java.io.Serial;
import java.io.Serializable;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SessionDetail implements Serializable {

    @Serial
    private static final long serialVersionUID = 1L;

    private String sessionId;
    private String userAgent;
    private String ip;
}