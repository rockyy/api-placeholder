package com.hdfcbank.common.models.validation.annotation;

import com.hdfcbank.common.models.validation.validator.ValueOfEnumValidator;
import jakarta.validation.Constraint;
import jakarta.validation.Payload;

import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import static java.lang.annotation.ElementType.*;

@Target({METHOD, FIELD, ANNOTATION_TYPE, CONSTRUCTOR, PARAMETER, TYPE_USE})
@Retention(RetentionPolicy.RUNTIME)
@Documented
@Constraint(validatedBy = ValueOfEnumValidator.class)
public @interface ValueOfEnum {
    Class<? extends Enum<?>> value();

    String message() default "must be any of enum {value}";

    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};

    boolean strictMode() default false;

    boolean allowBlank() default false;
}