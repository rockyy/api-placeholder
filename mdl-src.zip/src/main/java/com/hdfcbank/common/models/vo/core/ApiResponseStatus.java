package com.hdfcbank.common.models.vo.core;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.util.CollectionUtils;

import java.io.Serial;
import java.io.Serializable;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static com.hdfcbank.common.models.constant.CommonApiStatusCodes.*;

@Getter
@Setter
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ApiResponseStatus implements Serializable {

    @Serial
    private static final long serialVersionUID = 1L;

    private String code;
    private String message;
    private String errorRef;
    private List<String> errors;
    private String type;
    private String title;

    private ApiResponseStatus(String code, String message, List<String> errors) {
        this.code = code;
        this.message = message;
        this.errors = CollectionUtils.isEmpty(errors) ? null : errors;
    }

    private ApiResponseStatus(String code, String message, String errorRef, List<String> errors) {
        this.code = code;
        this.message = message;
        this.errorRef = errorRef;
        this.errors = CollectionUtils.isEmpty(errors) ? null : errors;
    }

    private ApiResponseStatus(String code, String message, String errorRef, String type, String title, List<String> errors) {
        this.code = code;
        this.message = message;
        this.errorRef = errorRef;
        this.type = type;
        this.title = title;
        this.errors = CollectionUtils.isEmpty(errors) ? null : errors;
    }

    public ApiResponseStatus(ApiResponseStatusCodeLiteral apiResponseStatusCode, String error) {
        this(apiResponseStatusCode.getCode(), apiResponseStatusCode.getMessage(), Collections.singletonList(error));
    }

    public ApiResponseStatus(ApiResponseStatusCodeLiteral apiResponseStatusCode, List<String> errors) {
        this(apiResponseStatusCode.getCode(), apiResponseStatusCode.getMessage(), errors);
    }

    public ApiResponseStatus(ApiResponseStatusCodeLiteral apiResponseStatusCode) {
        this(apiResponseStatusCode.getCode(), apiResponseStatusCode.getMessage(), (List<String>) null);
    }

    public static ApiResponseStatus success() {
        return with(SUCCESS, null);
    }

    public static ApiResponseStatus success(ApiResponseStatusCodeLiteral apiResponseStatusCode) {
        return with(apiResponseStatusCode, null);
    }

    public static ApiResponseStatus inputValidationError(ErrorRef errorRef, String... errors) {
        return with(INPUT_VALIDATION_ERROR, errorRef, errors);
    }

    public static ApiResponseStatus businessValidationError(ErrorRef errorRef, String... errors) {
        return with(INPUT_VALIDATION_ERROR, errorRef, errors);
    }

    public static ApiResponseStatus businessValidationError(ApiResponseStatusCodeLiteral apiResponseStatusCode, ErrorRef errorRef, String... errors) {
        return with(apiResponseStatusCode, errorRef, errors);
    }

    public static ApiResponseStatus downstreamApiError(ErrorRef errorRef, String... errors) {
        return with(DOWNSTREAM_API_ERROR, errorRef, errors);
    }

    public static ApiResponseStatus systemError(ErrorRef errorRef, String... errors) {
        return with(SYSTEM_ERROR, errorRef, errors);
    }

    public static ApiResponseStatus customValidationException(ErrorRef errorRef, String type, String title, List<String> errorsList) {
        return with(CUSTOM_VALIDATION_ERROR, errorRef, type, title, errorsList);
    }

    public static ApiResponseStatus with(ApiResponseStatusCodeLiteral apiResponseStatusCode, ErrorRef errorRef, String... errors) {
        String errorRefStr = Optional.ofNullable(errorRef).map(ErrorRef::asString).orElse(null);
        List<String> errorsList = Optional.ofNullable(errors).map(List::of).orElse(null);
        return new ApiResponseStatus(apiResponseStatusCode.getCode(), apiResponseStatusCode.getMessage(), errorRefStr, errorsList);
    }

    public static ApiResponseStatus with(ApiResponseStatusCodeLiteral apiResponseStatusCode, ErrorRef errorRef, String type, String title, List<String> errorsList) {
        String errorRefStr = Optional.ofNullable(errorRef).map(ErrorRef::asString).orElse(null);
        return new ApiResponseStatus(apiResponseStatusCode.getCode(), apiResponseStatusCode.getMessage(), errorRefStr, type, title, errorsList);
    }

}
