package com.hdfcbank.common.models.vo.misc;

import lombok.Getter;

@Getter
public enum IdentifierType {
    DOB,
    PAN,
    EMAIL
    ;
}
