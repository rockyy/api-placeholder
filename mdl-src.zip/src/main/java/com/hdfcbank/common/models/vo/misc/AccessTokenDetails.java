package com.hdfcbank.common.models.vo.misc;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.SuperBuilder;

import java.io.Serializable;
import java.util.Date;

@Getter
@Setter
@SuperBuilder
@AllArgsConstructor
@NoArgsConstructor
public class AccessTokenDetails implements Serializable {
    private String accessToken;
    private Date issuedAt;
    private Date expiresAt;
    private long tokenLifeInSec;
}