package com.hdfcbank.common.models.vo.journey;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.*;

import java.io.Serial;
import java.io.Serializable;
import java.util.List;
import java.util.Map;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class JourneyDetail implements Serializable {

    @Serial
    private static final long serialVersionUID = 1L;

    @Singular
    private List<JourneyState> journeyStates;
    private Map<String, Map<String, ?>> systemData;
    private Map<String, JourneyPage> domainData;
}
