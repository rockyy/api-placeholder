package com.hdfcbank.common.models.vo.journey;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.*;

import java.io.Serial;
import java.io.Serializable;
import java.util.Date;
import java.util.List;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class JourneyData implements Serializable {

    @Serial
    private static final long serialVersionUID = 1L;

    private String mobileNumber;
    private String journeyId;
    private String journeyName;
    private Profile profile;
    private String clientIp;
    private JourneyDetail journeyDetail;
    private String referenceNo;
    private String finReference;
    private String journeyNameAlias;
    private String journeyIdAlias;
    private String journeyPhase;
    @JsonFormat(pattern = "yyyy-MM-dd hh:mm:ss")
    private Date createdOn;
    @JsonFormat(pattern = "yyyy-MM-dd hh:mm:ss")
    private Date updatedOn;
    private List<SessionDetail> sessionDetails;
}
