package com.hdfcbank.common.models.vo.journey;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.*;

import java.io.Serial;
import java.io.Serializable;
import java.util.Date;
import java.util.Map;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class JourneyPage implements Serializable {

    @Serial
    private static final long serialVersionUID = 1L;

    private String pageName;
    private Date createdOn;
    private Map<String, Object> userInputs;
}
