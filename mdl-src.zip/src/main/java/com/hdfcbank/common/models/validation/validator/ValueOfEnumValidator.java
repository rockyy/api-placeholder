package com.hdfcbank.common.models.validation.validator;

import com.hdfcbank.common.models.validation.annotation.ValueOfEnum;
import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;
import org.apache.commons.lang3.StringUtils;

import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class ValueOfEnumValidator implements ConstraintValidator<ValueOfEnum, String> {
    private List<String> acceptedValues;
    private boolean strictMode;

    private boolean allowBlank;

    @Override
    public void initialize(ValueOfEnum annotation) {
        acceptedValues = Stream.of(annotation.value().getEnumConstants())
                .map(Enum::name)
                .collect(Collectors.toList());
        strictMode = annotation.strictMode();
        allowBlank = annotation.allowBlank();
    }

    @Override
    public boolean isValid(String value, ConstraintValidatorContext context) {
        if (allowBlank && StringUtils.isBlank(value)) {
            return true;
        }
        boolean isValid = false;
        if (null != value) {
            Predicate<String> fn = strictMode ? value::equals : value::equalsIgnoreCase;
            isValid = acceptedValues.stream().anyMatch(fn);
        }

        if (!isValid) {
            context.disableDefaultConstraintViolation();
            context.buildConstraintViolationWithTemplate("must be any of " + acceptedValues)
                    .addConstraintViolation();
        }

        return isValid;
    }
}