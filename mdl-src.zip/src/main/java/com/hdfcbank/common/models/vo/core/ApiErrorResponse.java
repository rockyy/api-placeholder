package com.hdfcbank.common.models.vo.core;

import lombok.AllArgsConstructor;
import lombok.experimental.SuperBuilder;

@SuperBuilder
@AllArgsConstructor
public class ApiErrorResponse extends ApiResponse<String> {

}