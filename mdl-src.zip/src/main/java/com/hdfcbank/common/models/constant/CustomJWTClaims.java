package com.hdfcbank.common.models.constant;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

@Getter
@RequiredArgsConstructor
public enum CustomJWTClaims {
    JOURNEY_ID("jid"),
    JOURNEY_NAME("jnm"),
    USER_AGENT_HASH("uah"),
    ADMIN_ACCESS_HASH("ach"),
    USER("User");

    private final String claimName;
}
