package com.hdfcbank.common.models.vo.core;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum ApiResponseStatusCode implements ApiResponseStatusCodeLiteral {
    // All success code should be starting with 0
    SUCCESS("0000", "Request succeeded"),
    INITIATED("0001", "Request initiated successfully"),
    PROCESSING("0002", "Request is currently processing"),
    PROCESSED("0003", "Request processed successfully"),

    // All business failure should be starting with 8
    INVALID_REQUEST("8001", "Invalid request"),
    VALIDATION_ERROR("8002", "Validation error"),

    // All failure codes should be starting with 9
    FAILURE("9001", "Request failed"),
    DOWNSTREAM_API_ERROR("9002", "Downstream api error"),
    APPLICATION_ERROR("9999", "Internal server error");

    private final String code;
    private final String message;
}
