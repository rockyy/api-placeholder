package com.hdfcbank.common.models.vo.core;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@JsonIgnoreProperties({"pageable"})
public class PageDetail extends PageImpl<Map<String, Object>> {

    @JsonCreator
    public PageDetail(List<Map<String, Object>> content, int size, int number, MasterPageSort sort, long totalElements) {
        super(content,PageRequest.of(number,size,sort),totalElements);
    }

    public static class MasterPageSort extends Sort {
        @JsonCreator
        protected MasterPageSort(Direction direction, List<String> properties) {
            super(Optional.ofNullable(properties).orElseGet(Collections::emptyList).stream().map(it -> new Order(direction, it)).toList());
        }
    }

}
