package com.hdfcbank.common.models.vo.core;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public class GenericApiResponseStatusCodeLiteral implements ApiResponseStatusCodeLiteral {

    private String code;
    private String message;

    public static ApiResponseStatusCodeLiteral of(String code, String message) {
        return new GenericApiResponseStatusCodeLiteral(code, message);
    }
}