package com.hdfcbank.common.models.constant;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class CommonConstants {

    public static final String SERVICE = "service";
    public static final String EVENT = "event";
    public static final String RETRY_COUNT_HEADER_KEY = "retryCount";
    public static final String CORRELATION_ID = "correlationId";
    public static final String USER_DATA = "userData";
    public static final String JOURNEY_ID = "journeyId";
    public static final String JOURNEY_ID_HEADER = "x-journey-id";
    public static final String STATUS_CODE = "statusCode" ;
    public static final String REQUEST_URL = "requestUrl" ;
    public static final String NOT_AVAILABLE = "NOT_AVAILABLE";
    public static final String INBOUND = "inbound";
    public static final String OUTBOUND = "outbound";
    public static final String CLIENT_IP= "client_ip";
    public static final String USER_AGENT="User-Agent";
    public static final String X_FORWARDED_FOR="X-Forwarded-For";
}