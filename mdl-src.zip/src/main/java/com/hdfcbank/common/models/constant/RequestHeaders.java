package com.hdfcbank.common.models.constant;

import lombok.experimental.UtilityClass;

@UtilityClass
public class RequestHeaders {
    public static final String AUTHORIZATION = "Authorization";
    public static final String USER_SESSION_ID = "x-us-id";
    public static final String JOURNEY_ID = "x-journey-id";
    public static final String JOURNEY_NAME = "x-journey-name";
    public static final String USER_AGENT = "User-Agent";
    public static final String X_FORWARDED_FOR = "X-Forwarded-For";
    public static final String CLIENT_AUTH = "x-client-auth";
    public static final String CHANNEL = "x-channel";
}
