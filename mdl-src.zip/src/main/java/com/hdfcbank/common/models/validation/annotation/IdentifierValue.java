package com.hdfcbank.common.models.validation.annotation;

import com.hdfcbank.common.models.validation.validator.IdentifierValueValidator;
import jakarta.validation.Constraint;
import jakarta.validation.Payload;

import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import static java.lang.annotation.ElementType.*;

@Target({TYPE, METHOD, FIELD, ANNOTATION_TYPE, CONSTRUCTOR, PARAMETER, TYPE_USE})
@Retention(RetentionPolicy.RUNTIME)
@Documented
@Constraint(validatedBy = IdentifierValueValidator.class)
public @interface IdentifierValue {

    String message() default "invalid Request";

    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};

    String identifierNameFieldName() default "identifierName";

    String identifierValueFieldName() default "identifierValue";

    DateOfBirth dateOfBirth() default @DateOfBirth;

    Pan pan() default @Pan;
}