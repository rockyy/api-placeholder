package com.hdfcbank.common.models.vo.misc;

import lombok.RequiredArgsConstructor;
import reactor.core.publisher.Mono;

@RequiredArgsConstructor
public class MonoWrapper<T> {
    private final Mono<T> thisMono;

    public static <T> MonoWrapper<T> of(Mono<T> mono) {
        return new MonoWrapper<>(mono);
    }

    public <O> Mono<T> drop(Mono<O> otherMono) {
        return dropRight(thisMono, otherMono);
    }

    public <O> Mono<O> keep(Mono<O> otherMono) {
        return dropLeft(thisMono, otherMono);
    }

    public static <L, R> Mono<R> dropLeft(Mono<L> left, Mono<R> right) {
        return Mono.zip(left, right, (l, r) -> r);
    }

    public static <L, R> Mono<R> dropLeft(L leftObject, Mono<R> right) {
        return dropLeft(Mono.just(leftObject), right);
    }

    public static <L, R> Mono<L> dropRight(Mono<L> left, Mono<R> right) {
        return Mono.zip(left, right, (l, r) -> l);
    }

    public static <L, R> Mono<L> dropRight(Mono<L> left, R rightObject) {
        return dropRight(left, Mono.just(rightObject));
    }

}
