package com.hdfcbank.common.models.vo.journey;

import lombok.*;

import java.io.Serial;
import java.io.Serializable;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SessionMapping implements Serializable {

    @Serial
    private static final long serialVersionUID = 1L;

    private String journeyId;
    private String journeyName;
    private String userAgent;
    private String authToken;
}
