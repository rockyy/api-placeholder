package com.hdfcbank.common.models.vo.misc;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.SuperBuilder;

import java.io.Serializable;

@Getter
@Setter
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class GatewayContext implements Serializable {
    private String apiKey;
    private String scope;
    private String appType;
    private String partnerId;
    private String productName;
    private String channelId;
    private AccessTokenDetails accessTokenDetails;
}