package com.hdfcbank.common.models.validation.validator;

import com.hdfcbank.common.models.validation.annotation.ValidValue;
import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;
import lombok.SneakyThrows;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;

public class ValidValueValidator implements ConstraintValidator<ValidValue, Object> {

    @Autowired
    private ApplicationContext applicationContext;

    private ValidValue constraintAnnotation;

    @Override
    public void initialize(ValidValue constraintAnnotation) {
        this.constraintAnnotation = constraintAnnotation;
    }

    @Override
    public boolean isValid(Object value, ConstraintValidatorContext context) {
        ValidatorDefinition validatorDefinition = getValidatorDefinition();
        return validatorDefinition.isValidValue(constraintAnnotation, value, context);
    }

    @SneakyThrows
    private ValidatorDefinition getValidatorDefinition() {
        Class<? extends ValidatorDefinition> validatorDefinitionClass = constraintAnnotation.validatorDefinition();
        if (constraintAnnotation.useBean()) {
            return applicationContext.getBean(validatorDefinitionClass);
        }
        return BeanUtils.instantiateClass(validatorDefinitionClass);
    }

    public static interface ValidatorDefinition {
        default boolean isValidValue(ValidValue annotation, Object value, ConstraintValidatorContext context) {
            return isValid(annotation, value, context);
        }

        <T> boolean isValid(ValidValue annotation, T value, ConstraintValidatorContext context);
    }

    public static class DefaultValidatorDefinition implements ValidatorDefinition {
        @Override
        public boolean isValid(ValidValue annotation, Object value, ConstraintValidatorContext context) {
            return true;
        }
    }
}