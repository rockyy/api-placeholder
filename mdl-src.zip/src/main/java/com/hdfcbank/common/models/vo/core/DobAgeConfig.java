package com.hdfcbank.common.models.vo.core;

import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import java.util.HashMap;

@Getter
@Setter
@Component
@ConfigurationProperties(prefix = "customer.dob")
public class DobAgeConfig {
    HashMap<String,AgeRange> validation;

    @Getter
    @Setter
    public static class AgeRange{
        private int minAge;
        private int maxAge;
    }
}
