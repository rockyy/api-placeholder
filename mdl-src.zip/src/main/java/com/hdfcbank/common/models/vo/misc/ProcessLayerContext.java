package com.hdfcbank.common.models.vo.misc;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

@Getter
@Setter
public class ProcessLayerContext implements Serializable {
    private String bankJourneyId;
    private String partnerId;
    private String productName;
    private String channelId;
    private String flowToken;
}
