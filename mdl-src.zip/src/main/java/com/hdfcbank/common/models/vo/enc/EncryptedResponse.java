package com.hdfcbank.common.models.vo.enc;

import lombok.*;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class EncryptedResponse {
    private String content;
}
