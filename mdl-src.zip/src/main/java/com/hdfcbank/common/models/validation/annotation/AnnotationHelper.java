package com.hdfcbank.common.models.validation.annotation;

import lombok.experimental.UtilityClass;

import java.lang.annotation.Annotation;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.Map;

@UtilityClass
public class AnnotationHelper {
    public static <A extends Annotation> A createAnnotation(Class<A> annotationClass, Map<String, ?> annotationValues) {
        return (A) Proxy.newProxyInstance(annotationClass.getClassLoader(), new Class[]{annotationClass},
                (Object proxy, Method method, Object[] args) -> {
                    Object value = annotationValues.get(method.getName());
                    if (null != value) {
                        return value; // Return the provided value
                    } else if (method.getName().equals("annotationType")) {
                        return annotationClass; // Return the annotation type
                    }
                    return method.getDefaultValue(); // Return the default if nothing is set
                }
        );
    }
}
