package com.hdfcbank.common.models.vo.core;

public interface ApiResponseStatusCodeLiteral {
    String getCode();

    String getMessage();
}
