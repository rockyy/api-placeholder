package com.hdfcbank.common.models.validation.validator;

import com.hdfcbank.common.models.validation.annotation.*;
import com.hdfcbank.common.models.vo.misc.IdentifierType;
import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.beanutils.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;

import java.lang.annotation.Annotation;
import java.lang.reflect.InvocationTargetException;
import java.util.Map;

@Slf4j
public class IdentifierValueValidator implements ConstraintValidator<IdentifierValue, Object> {

    private IdentifierValue constraintAnnotation;

    @Autowired
    private ApplicationContext applicationContext;

    @Override
    public void initialize(IdentifierValue constraintAnnotation) {
        this.constraintAnnotation = constraintAnnotation;
    }

    @Override
    @SneakyThrows
    public boolean isValid(Object value, ConstraintValidatorContext context) {

        Object identifierNameObj;
        Object identifierValueObj;

        try {
            identifierNameObj = BeanUtils.getProperty(value, constraintAnnotation.identifierNameFieldName());
            identifierValueObj = BeanUtils.getProperty(value, constraintAnnotation.identifierValueFieldName());
        } catch (Exception e) {
            return false;   // ✅ FIX: BeanUtils exception is now handled properly
        }

        String identifierNameStr = String.valueOf(identifierNameObj);
        String identifierValue = String.valueOf(identifierValueObj);

        boolean valid = isValidIdentifierName(identifierNameStr, context);

        if (valid) {
            ConstraintValidator<? extends Annotation, String> validator = getValidator(identifierNameStr);
            valid = validator.isValid(identifierValue, context);

            if (!valid) {
                context.disableDefaultConstraintViolation();
                context.buildConstraintViolationWithTemplate(constraintAnnotation.message())
                        .addPropertyNode(constraintAnnotation.identifierValueFieldName())
                        .addConstraintViolation();
            }
        }

        return valid;
    }

    private boolean isValidIdentifierName(String identifierNameStr, ConstraintValidatorContext context) {
        ValueOfEnum annotation = AnnotationHelper.createAnnotation(ValueOfEnum.class, Map.of("value", IdentifierType.class));
        ValueOfEnumValidator valueOfEnumValidator = new ValueOfEnumValidator();
        valueOfEnumValidator.initialize(annotation);
        return valueOfEnumValidator.isValid(identifierNameStr, context);
    }

    private ConstraintValidator<? extends Annotation, String> getValidator(String identifierNameStr) throws InvocationTargetException, IllegalAccessException, NoSuchMethodException {
        IdentifierType identifierType = IdentifierType.valueOf(identifierNameStr);

        return switch (identifierType) {
            case DOB -> getDateOfBirthValidator();
            case PAN -> getPanValidator();
            case EMAIL -> null;
        };
    }

    private DateOfBirthValidator getDateOfBirthValidator() {
        DateOfBirth dobAnnotation = constraintAnnotation.dateOfBirth();
        DateOfBirthValidator validator = applicationContext.getAutowireCapableBeanFactory()
                .createBean(DateOfBirthValidator.class);
        validator.initialize(dobAnnotation);
        return validator;
    }

    private PanValidator getPanValidator() {
        Pan pan = constraintAnnotation.pan();
        PanValidator panValidator = new PanValidator();
        panValidator.initialize(pan);
        return panValidator;
    }
}