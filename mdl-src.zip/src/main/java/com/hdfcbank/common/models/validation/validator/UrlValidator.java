package com.hdfcbank.common.models.validation.validator;

import com.hdfcbank.common.models.validation.annotation.Url;
import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;
import org.apache.commons.lang3.StringUtils;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class UrlValidator implements ConstraintValidator<Url, String> {

    private Url constraintAnnotation;

    @Override
    public void initialize(Url constraintAnnotation) {
        this.constraintAnnotation = constraintAnnotation;
    }

    @Override
    public boolean isValid(String value, ConstraintValidatorContext context) {
        if (constraintAnnotation.allowBlank() && StringUtils.isBlank(value)) {
            return true;
        }
        if (StringUtils.isNoneBlank(value)) {
            Pattern pattern = Pattern.compile(constraintAnnotation.regex());
            Matcher matcher = pattern.matcher(value);
            return matcher.find();
        }
        return false;
    }
}
