package com.hdfcbank.common.models.vo.journey;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.*;

import java.io.Serial;
import java.io.Serializable;
import java.util.Date;
import java.util.List;

import static com.hdfcbank.common.models.constant.DateTimeConstants.FULL_DATE_TIME_FORMAT;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class Profile implements Serializable {

    @Serial
    private static final long serialVersionUID = 1L;

    private transient String accountNumber;
    private transient String dob;
    private transient String phoneNo;
    private transient String resiPhone;
    private transient String offPhone;
    private transient String accountId;

    private String sourceId;
    private String branchCode;
    private String address1;
    private String address2;
    private String address3;
    private String address4;
    private String city;
    private String country;
    private String state;
    private String zipCode;
    private String customerMobileNo;
    private String customerFullName;
    private String customerResidencePhoneNo;
    private String customerType;
    private int customerDependents;
    private String name;
    private String mobileNumber;
    private String address;
    private String email;
    private String employmentType;
    private String employerName;
    private String age;
    private String middleNames;
    private String surName;
    private String type;
    private String panNumber;
    private String sasId;
    private String dateOfBirth;
    private String number;
    private String aanNumber;
    private String mpnIdentity;
    private String pseudoCustomerId;
    private String customerId;
    private String emailId;
    private String officialEmailId;
    private String crmLeadKey;
    private String card4Digits;
    private boolean panValid;
    @JsonFormat(pattern = FULL_DATE_TIME_FORMAT)
    private Date lastAccessTime;
    private List<Address> addresses;
    private String firstName;
    private String middleName;
    private String lastName;
    private String gender;
    private String maritalStatus;
    private String title;
    private String fullName;
    private String shortName;
    private String motherMaidenName;
    private String pinCode;
    private String customerProfession;
    private int customerAnnualIncome;

    private String accountStatus;
    private String kyc;
    private boolean isStaff;
    private String loginType;
    private String spouseName;
    private String motherName;
    private String fatherName;
    private String identifierName;
    private String nrFlag;

    private String kycDate;
    private String ethnicCode;
    private String ethnicCodeDesc;
    private boolean etb;
    private String source;
}