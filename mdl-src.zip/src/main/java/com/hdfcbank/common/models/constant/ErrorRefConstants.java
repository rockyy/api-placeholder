package com.hdfcbank.common.models.constant;

public class ErrorRefConstants {
    public static final String UNKNOWN_API_IDENTIFIER = "UNKWN";
    public static final String DEFAULT_JOURNEY_ID_ALIAS = "00000-00000";
        public static final String DEFAULT_JOURNEY_NAME_ALIAS = "UNKWN";

}
