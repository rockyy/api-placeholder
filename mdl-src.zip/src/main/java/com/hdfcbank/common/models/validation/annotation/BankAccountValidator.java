package com.hdfcbank.common.models.validation.annotation;


import com.hdfcbank.common.models.validation.validator.BankAccountNumberValidator;
import com.hdfcbank.common.models.validation.validator.BingIntegerValidator;
import jakarta.validation.Constraint;
import jakarta.validation.Payload;

import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import static java.lang.annotation.ElementType.*;

@Target({METHOD, FIELD, ANNOTATION_TYPE, CONSTRUCTOR, PARAMETER, TYPE_USE})
@Retention(RetentionPolicy.RUNTIME)
@Documented
@Constraint(validatedBy = BankAccountNumberValidator.class)
public @interface BankAccountValidator {

    String message() default "Invalid bank account number";

    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};
}
