package com.hdfcbank.common.models.vo.journey;

import lombok.*;

import java.io.Serial;
import java.io.Serializable;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Address implements Serializable {

    @Serial
    private static final long serialVersionUID = 1L;

    private String type;
    private String address1;
    private String address2;
    private String address3;
    private String address4;
    private String zipCode;
    private String city;
    private String state;
    private String country;
}
