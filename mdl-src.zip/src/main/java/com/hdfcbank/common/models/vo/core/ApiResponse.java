package com.hdfcbank.common.models.vo.core;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.SuperBuilder;

import java.io.Serial;
import java.io.Serializable;
import java.util.List;

@Getter
@Setter
@SuperBuilder
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ApiResponse<T> implements Serializable {

    @Serial
    private static final long serialVersionUID = 1L;

    private ApiResponseStatus status;
    private T data;

    public static <T> ApiResponse<T> success(T data) {
        return new ApiResponse<>(ApiResponseStatus.success(), data);
    }

    public static <T> ApiResponse<T> success(ApiResponseStatusCodeLiteral apiResponseStatusCode, T data) {
        return new ApiResponse<>(ApiResponseStatus.success(apiResponseStatusCode), data);
    }

    public static <T> ApiResponse<T> inputValidationError(ErrorRef errorRef, String... errors) {
        return new ApiResponse<>(ApiResponseStatus.inputValidationError(errorRef, errors), null);
    }

    public static <T> ApiResponse<T> businessValidationError(ErrorRef errorRef, String... errors) {
        return new ApiResponse<>(ApiResponseStatus.businessValidationError(errorRef, errors), null);
    }

    public static <T> ApiResponse<T> businessValidationError(ApiResponseStatusCodeLiteral apiResponseStatusCode, ErrorRef errorRef, String... errors) {
        return new ApiResponse<>(ApiResponseStatus.businessValidationError(apiResponseStatusCode, errorRef, errors), null);
    }

    public static <T> ApiResponse<T> downstreamApiError(ErrorRef errorRef, String... errors) {
        return new ApiResponse<>(ApiResponseStatus.downstreamApiError(errorRef, errors), null);
    }

    public static <T> ApiResponse<T> systemError(ErrorRef errorRef, String... errors) {
        return new ApiResponse<>(ApiResponseStatus.systemError(errorRef, errors), null);
    }

    public static <T> ApiResponse<T> customValidationError(ErrorRef errorRef, String type, String title, List<String> errorsList) {
        return new ApiResponse<>(ApiResponseStatus.customValidationException(errorRef, type, title, errorsList), null);
    }
}
