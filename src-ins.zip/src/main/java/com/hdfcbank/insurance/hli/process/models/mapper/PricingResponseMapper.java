package com.hdfcbank.insurance.hli.process.models.mapper;

import com.hdfcbank.insurance.adapter.process.models.response.PricingResponse;
import com.hdfcbank.insurance.hli.process.models.response.HLIFetchPricingResponse;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;

@Mapper(componentModel = "spring")
public interface PricingResponseMapper {

    HLIFetchPricingResponse toHLIFetchPricingResponse(PricingResponse response);

    // Manually convert the three numeric fields
    @Mapping(target = "basePremium", source = "basePremium", qualifiedByName = "stringToDouble")
    @Mapping(target = "tax", source = "tax", qualifiedByName = "stringToDouble")
    @Mapping(target = "totalPremium", source = "totalPremium", qualifiedByName = "stringToDouble")
    HLIFetchPricingResponse.Quotes toQuotes(PricingResponse.Quote quote);

    // Converter
    @Named("stringToDouble")
    default Double stringToDouble(String value) {
        if (value == null || value.isBlank()) return null;
        try {
            return Double.valueOf(value);
        } catch (NumberFormatException e) {
            return null;
        }
    }
}

