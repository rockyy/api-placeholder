package com.hdfcbank.insurance.hli.process.service.impl.proposalQuestion;

import com.hdfcbank.insurance.adapter.process.models.response.ProposalQuestionResponse;
import org.apache.commons.lang3.ObjectUtils;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

class ProposalQuestionListToMapMapper {
    public static Map<String, List<ProposalQuestionResponse.Question>> toProductQuestionMap(ProposalQuestionResponse response,String entityId,String propertyNumber) {
        if (response == null || ObjectUtils.isEmpty(response.getProductWiseQuestions())) {
            return Collections.emptyMap();
        }

        return response.getProductWiseQuestions().stream()
                .filter(productWiseQuestions -> !ObjectUtils.isEmpty(productWiseQuestions.getCode()))
                .collect(Collectors.toMap(
                        ProposalQuestionResponse.ProductWiseQuestions::getCode,
                        productQuestions -> ObjectUtils.isEmpty(productQuestions.getQuestions()) ? Collections.emptyList() : productQuestions.getQuestions().stream()
                                .filter(questionEntity -> questionEntity.getEntityId().equalsIgnoreCase(entityId) || questionEntity.getEntityId().equalsIgnoreCase(propertyNumber)).toList()
                ));
    }
}
