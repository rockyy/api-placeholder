package com.hdfcbank.insurance.hli.util;

import lombok.experimental.UtilityClass;
import lombok.extern.slf4j.Slf4j;
import tools.jackson.databind.JsonNode;
import tools.jackson.databind.ObjectMapper;
import tools.jackson.databind.SerializationFeature;
import tools.jackson.databind.json.JsonMapper;
import tools.jackson.databind.node.ArrayNode;
import tools.jackson.databind.node.ObjectNode;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Comparator;
import java.util.List;
import java.util.TreeMap;

@UtilityClass
@Slf4j
public class ChecksumUtil {

    private static final ObjectMapper MAPPER = JsonMapper.builder().enable(SerializationFeature.ORDER_MAP_ENTRIES_BY_KEYS).build();

    /**
     * Generates a canonical SHA-256 checksum for the given object.
     */
    public static String generateCanonicalChecksum(Object obj) {
        try {
            JsonNode node = MAPPER.valueToTree(obj);
            JsonNode normalized = normalize(node);
            String canonicalJson = MAPPER.writeValueAsString(normalized);
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(canonicalJson.getBytes(StandardCharsets.UTF_8));
            return Base64.getEncoder().encodeToString(hash);
        } catch (Exception e) {
            log.error("Error generating canonical checksum", e);
            throw new IllegalStateException("Unable to generate canonical checksum", e);
        }
    }

    /** Recursively normalizes JSON.*/
    private static JsonNode normalize(JsonNode node) {
        if (node == null) {
            return null;
        }
        if (node.isObject()) {
            ObjectNode sortedNode = MAPPER.createObjectNode();
            TreeMap<String, JsonNode> sortedProperties = new TreeMap<>();
            node.properties().forEach(entry -> sortedProperties.put(entry.getKey(), normalize(entry.getValue())));
            sortedProperties.forEach(sortedNode::set);
            return sortedNode;
        }
        if (node.isArray()) {

            ArrayNode arrayNode = MAPPER.createArrayNode();

            List<JsonNode> list = new ArrayList<>();

            node.forEach(element -> list.add(normalize(element)));

            list.sort(Comparator.<JsonNode, String>comparing(jsonNode -> getStringValue(jsonNode, "questionKey")).thenComparing(jsonNode -> getStringValue(jsonNode, "entityId")).thenComparing(jsonNode -> getStringValue(jsonNode, "code")));

            list.forEach(arrayNode::add);

            return arrayNode;
        }


        if (node.isNumber() || node.isString()) {
            return MAPPER.stringNode(node.asString());
        }
        return node;
    }

    /*** Compares two objects using their canonical checksums.*/
    public static boolean areEqual(Object obj1, Object obj2) {
        return generateCanonicalChecksum(obj1).equals(generateCanonicalChecksum(obj2));
    }

    private static String getStringValue(JsonNode node, String fieldName) {
        if (node == null || !node.isObject()) {
            return "";
        }

        JsonNode value = node.get(fieldName);

        if (value == null || value.isNull()) {
            return "";
        }

        return value.asString("");
    }


}