package com.hdfcbank.insurance.hli.setting.models;

import tools.jackson.databind.JsonNode;
import com.hdfcbank.common.models.vo.core.ApiResponse;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import lombok.experimental.SuperBuilder;

@Getter
@Setter
@ToString
@SuperBuilder
public class SettingsResponse extends ApiResponse<JsonNode> {
}
