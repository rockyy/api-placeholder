package com.hdfcbank.insurance.hli.process.annotations;

import com.hdfcbank.insurance.hli.process.models.enums.SourceSystem;
import com.hdfcbank.insurance.hli.process.validators.HLISubmitAnswerValidator;
import jakarta.validation.Constraint;
import jakarta.validation.Payload;

import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;

import static java.lang.annotation.ElementType.*;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

@Constraint(validatedBy = HLISubmitAnswerValidator.class)
@Target({TYPE, FIELD, ANNOTATION_TYPE})
@Retention(RUNTIME)
@Documented
public @interface HLISubmitAnswerRequestValidator {
    String message() default "Values can't be null or empty";

    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};

    SourceSystem[] allowed() default {};
}
