package com.hdfcbank.insurance.hli.communication.consent.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.SuperBuilder;

import java.util.List;
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@SuperBuilder
public class HLICustomerConsentRequest {
    private List<CustomerConsentRequest> customerConsentRequest;
}
