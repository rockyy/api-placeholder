package com.hdfcbank.insurance.hli.process.service.impl;


import com.hdfcbank.adapters.clients.feign.journey.JourneyServiceFeignClient;
import com.hdfcbank.common.models.vo.core.ApiResponse;
import com.hdfcbank.common.models.vo.journey.JourneyData;
import com.hdfcbank.insurance.adapter.process.models.request.LGLCRequest;
import com.hdfcbank.insurance.adapter.process.models.request.ProposalQuestionRequest;
import com.hdfcbank.insurance.adapter.process.models.request.SubmitAnswerRequest;
import com.hdfcbank.insurance.adapter.process.models.response.LGLCResponse;
import com.hdfcbank.insurance.adapter.process.models.response.PricingResponse;
import com.hdfcbank.insurance.adapter.process.models.response.ProposalQuestionResponse;
import com.hdfcbank.insurance.adapter.process.models.response.SubmitAnswerResponse;
import com.hdfcbank.insurance.hli.common.config.JourneyContextHolder;
import com.hdfcbank.insurance.hli.common.constant.HLICommonConstants;
import com.hdfcbank.insurance.hli.common.enums.JourneyStateName;
import com.hdfcbank.insurance.hli.process.models.mapper.LGLCDataMapper;
import com.hdfcbank.insurance.hli.process.models.mapper.SubmitProposalMapper;
import com.hdfcbank.insurance.hli.process.models.request.HLILGLCRequest;
import com.hdfcbank.insurance.hli.process.models.request.HLISubmitAnswerRequest;
import com.hdfcbank.insurance.hli.process.models.response.HLILGLCResponse;
import com.hdfcbank.insurance.hli.process.models.response.HLIProposalQuestionResponse;
import com.hdfcbank.insurance.hli.process.models.response.HLISubmitAnswerResponse;
import com.hdfcbank.insurance.hli.process.service.HLIQuestionService;
import com.hdfcbank.insurance.hli.process.service.impl.proposalQuestion.HLIProposalQuestionsResponseMapper;
import com.hdfcbank.insurance.hli.util.JourneyUtil;
import com.hdfcbank.insurance.hli.util.TextSanityUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import tools.jackson.databind.ObjectMapper;

import java.util.Map;
import java.util.stream.Collectors;

@Service
@Slf4j
@RequiredArgsConstructor
public class HLIQuestionServiceImpl implements HLIQuestionService {

    private final ProcessServiceCall processServiceCall;
    private final ObjectMapper mapper;
    private final JourneyServiceFeignClient journeyServiceFeignClient;

    /**
     * This method will send call to that method which is having logic for
     * mapping to invoke process endpoint and to do mapping for BFF response.
     *
     * @return ApiResponse<HLIPremiumQuestionResponse>
     */
    @Override
    public ApiResponse<HLIProposalQuestionResponse> getProposalQuestions() {
        JourneyData journeyData = JourneyContextHolder.getJourneyData();
        String leadId = JourneyUtil.extractLeadId(journeyData);
        ProposalQuestionRequest proposalQuestionRequest = ProposalQuestionRequest.builder().leadId(leadId).build();
        ProposalQuestionResponse proposalQuestionsResponse = processServiceCall.proposalQuestionProcessCall(proposalQuestionRequest, journeyData.getJourneyId());
        // Extract pricing response and current status
        PricingResponse pricingResponse = mapper.convertValue(JourneyUtil.getDataFromJourneyService(journeyData.getJourneyDetail().getSystemData(), HLICommonConstants.PRICING_RESPONSE), PricingResponse.class);
        HLIProposalQuestionResponse hLIProposalQuestionResponse = HLIProposalQuestionsResponseMapper.getHliProposalQuestionResponse(
                journeyData.getJourneyDetail(), proposalQuestionsResponse, pricingResponse
        );
        journeyServiceFeignClient.update(JourneyUtil.toUpdateSystemDataRequest(journeyData.getJourneyId(), HLICommonConstants.PROPOSAL_QUESTIONS, hLIProposalQuestionResponse, JourneyStateName.PROPOSAL_QUESTION_SUCCESS));
        return ApiResponse.success(hLIProposalQuestionResponse);
    }

    @Override
    public ApiResponse<HLISubmitAnswerResponse> submitProposal(HLISubmitAnswerRequest hliSubmitAnswerRequest) {
        JourneyData journeyData = JourneyContextHolder.getJourneyData();
        String leadId = JourneyUtil.extractLeadId(journeyData);
        String loanFileNumber = JourneyUtil.getDataFromJourneyService(journeyData.getJourneyDetail().getSystemData(),
                HLICommonConstants.LOAN_FILE_NUMBER_KEY).toString();
        HLILGLCResponse hliLgLcResponse = JourneyUtil.updateAndGetLglcJourneyData(journeyData, journeyServiceFeignClient, mapper,
                hliSubmitAnswerRequest.getLgCode(), hliSubmitAnswerRequest.getLifeLCCode(), hliSubmitAnswerRequest.getNonLifeLCCode(), hliSubmitAnswerRequest.getAgencyCode());
        SubmitAnswerRequest submitAnswerRequest = SubmitProposalMapper.submitAnswerRequestMapping(hliSubmitAnswerRequest, hliLgLcResponse, leadId, loanFileNumber);
        journeyServiceFeignClient.update(JourneyUtil.toUpdateSystemDataRequest(journeyData.getJourneyId(), HLICommonConstants.PROPOSAL_REQUEST, hliSubmitAnswerRequest, JourneyStateName.PROPOSAL_SUBMIT_INITIATED));
        log.info("submit proposal request :: {}", TextSanityUtil.sanitize(submitAnswerRequest.toString()));
        SubmitAnswerResponse submitAnswerResponse = processServiceCall.submitAnswerProcessCall(submitAnswerRequest, journeyData.getJourneyId());
        HLISubmitAnswerResponse hliSubmitAnswerResponse = SubmitProposalMapper.hliSubmitProposalResponseMapping(submitAnswerResponse);
        journeyServiceFeignClient.update(JourneyUtil.toUpdateSystemDataRequest(journeyData.getJourneyId(), HLICommonConstants.PROPOSAL_RESPONSE, hliSubmitAnswerResponse, JourneyStateName.PROPOSAL_SUBMIT_SUCCESS));
        return ApiResponse.success(hliSubmitAnswerResponse);
    }

    @Override
    public ApiResponse<LGLCResponse> fetchLgLcDetails(HLILGLCRequest request) {
        JourneyData journeyData = JourneyContextHolder.getJourneyData();
        String loanFileNumber = JourneyUtil.getDataFromJourneyService(journeyData.getJourneyDetail().getSystemData(),
                HLICommonConstants.LOAN_FILE_NUMBER_KEY).toString();
        LGLCRequest lglcRequest = LGLCRequest.builder().loanFileNumber(loanFileNumber).build();
        if(request != null && request.getChannel() != null) {
            lglcRequest.setChannel(request.getChannel());
        }
        LGLCResponse lglcResponse = processServiceCall.getLgLcDetails(lglcRequest, journeyData.getJourneyId());
        journeyServiceFeignClient.update(JourneyUtil.toUpdateSystemDataRequest(journeyData.getJourneyId(), HLICommonConstants.LGLC_DETAILS,
                LGLCDataMapper.map(lglcResponse), JourneyStateName.LGLC_FETCH_SUCCESS));
        return ApiResponse.success(lglcResponse);
    }
}
