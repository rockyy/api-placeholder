package com.hdfcbank.insurance.hli.process.models;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.hdfcbank.insurance.hli.process.models.enums.DocumentType;
import lombok.*;

@Getter
@Setter
@ToString
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class EsignDocumentStorageDetail{
    private String documentReferenceId;
    private String signerId;
    private DocumentType documentType;
    private String quoteId;
}
