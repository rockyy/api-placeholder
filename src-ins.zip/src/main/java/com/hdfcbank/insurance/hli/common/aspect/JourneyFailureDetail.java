package com.hdfcbank.insurance.hli.common.aspect;

import lombok.Builder;
import lombok.Data;

import java.time.Instant;

@Data
@Builder
public class JourneyFailureDetail {

    private String failedState;
    private String errorMessage;
    private String exceptionType;
    private String rootCause;
    private Instant timestamp;
}