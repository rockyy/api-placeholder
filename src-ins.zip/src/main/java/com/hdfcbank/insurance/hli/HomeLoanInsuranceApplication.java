package com.hdfcbank.insurance.hli;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.annotation.ComponentScan;
import com.hdfcbank.security.utils.SSLHelperUtil;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;

@EnableAspectJAutoProxy
@SpringBootApplication
@EnableFeignClients(basePackages = "com.hdfcbank")
@ComponentScan(basePackages = {"com.hdfcbank","com.hdfcbank.job.scheduler"})
@EnableMongoRepositories(basePackages = "com.hdfcbank")
@EnableCaching
public class HomeLoanInsuranceApplication {

    public static void main(String[] args) {
        SSLHelperUtil.setupSSLProperties();
        SpringApplication.run(HomeLoanInsuranceApplication.class, args);
    }

}
