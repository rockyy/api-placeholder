package com.hdfcbank.insurance.hli.common.exception;

import com.hdfcbank.common.models.vo.core.ApiResponseStatusCodeLiteral;
import com.hdfcbank.insurance.hli.common.enums.HLICustomCommonApiStatusCodes;
import lombok.Getter;
import org.apache.commons.lang3.StringUtils;

import java.util.List;

@Getter
public class CustomValidationException extends RuntimeException{
    private final ApiResponseStatusCodeLiteral apiResponseStatusCodeLiteral;
    private final List<String> errors;
    private final String title;
    private final String screen;

    public CustomValidationException(HLICustomCommonApiStatusCodes customerApiStatusCode, String title, String screen, List<String> errors) {
        super(StringUtils.join(",",errors));
        this.apiResponseStatusCodeLiteral = customerApiStatusCode;
        this.errors = errors;
        this.title=title;
        this.screen=screen;
    }
}
