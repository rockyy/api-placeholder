package com.hdfcbank.insurance.hli.process.service.impl.proposalQuestion;

import tools.jackson.databind.ObjectMapper;
import com.hdfcbank.common.models.vo.journey.JourneyDetail;
import com.hdfcbank.insurance.adapter.process.models.response.GetLoanDetailResponse;
import com.hdfcbank.insurance.hli.process.models.HLIBorrower;
import lombok.experimental.UtilityClass;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.ObjectUtils;
import org.springframework.boot.json.JsonParseException;

import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.stream.Collectors;

import static com.hdfcbank.insurance.hli.common.constant.HLICommonConstants.HOME_LOAN_DETAIL;

@Slf4j
@UtilityClass
    public class BorrowerUtility {

    public static List<GetLoanDetailResponse.Customer> getListOfBorrower(JourneyDetail journeyDetail){
        try{
            Map<String, ?> detailMap = journeyDetail.getSystemData().get(HOME_LOAN_DETAIL);
            GetLoanDetailResponse loanDetailResponse = new ObjectMapper().convertValue(detailMap, GetLoanDetailResponse.class);
            return loanDetailResponse.getCustomers();
        }
        catch (JsonParseException e) {
            log.error("Exception in getting home loan detail from Journey DB {}", e.getMessage());
            //TODO : throw runtime exception
            return Collections.emptyList();
        }
    }

    public static List<GetLoanDetailResponse.Customer> getListOfNomineeForBorrower(
            List<GetLoanDetailResponse.Customer> listOfBorrower, GetLoanDetailResponse.Customer selectedCustomer) {

        if (listOfBorrower == null || selectedCustomer == null) {
            return Collections.emptyList();
        }
        String selectedCustomerId = selectedCustomer.getNumber();
        return listOfBorrower.stream()
                .filter(customer -> customer.getNumber() != null)
                .filter(customer -> !customer.getNumber().equalsIgnoreCase(selectedCustomerId))  // remove selected customer
                .filter(customer -> isAge18OrMore(customer.getDateOfBirth()))
                .collect(Collectors.toList());
    }

    private boolean isAge18OrMore(String dob) {
        if (dob == null || dob.isBlank()) return false;
        LocalDate birthDate = parseDOB(dob);
        if (birthDate == null) return false;
        return Period.between(birthDate, LocalDate.now()).getYears() >= 18;
    }

    private LocalDate parseDOB(String dob) {
        List<DateTimeFormatter> formatters = List.of(
                DateTimeFormatter.ofPattern("dd-MMM-yyyy", Locale.ENGLISH), // e.g., 03-Apr-1981
                DateTimeFormatter.ofPattern("dd/MM/yyyy")// e.g., 15/10/1969
        );
        for (DateTimeFormatter fmt : formatters) {
            try {
                return LocalDate.parse(dob, fmt);
            }
            catch(Exception exception) {
                log.info("Exception in filtering customer from Journey DB parsing DOB {}", exception.getMessage());
            }
        }
        return null; // neither pattern worked
    }

    public static HLIBorrower mapCustomerToBorrower(GetLoanDetailResponse.Customer customer) {
        if (customer == null) {
            return null;
        }
        String fullName = buildFullName(customer.getFirstName(), customer.getMiddleName(), customer.getLastName());
        return HLIBorrower.builder()
                .name(fullName)
                .id(customer.getNumber())
                .relationToBorrower(customer.getRelationToBorrower())
                .dateOfBirth(customer.getDateOfBirth())
                .gender(customer.getSex())
                .capacityDesc(customer.getCapacityDesc())
                .email(customer.getEmail())
                .mobileNumber(customer.getMobile())
                .build();
    }

    private static String buildFullName(String first, String middle, String last) {
        StringBuilder sb = new StringBuilder();
        if (!ObjectUtils.isEmpty(first)) {
            sb.append(first.trim());
        }
        if (!ObjectUtils.isEmpty(middle)) {
            if (!ObjectUtils.isEmpty(sb.toString())) sb.append(" ");
            sb.append(middle.trim());
        }
        if (!ObjectUtils.isEmpty(last)) {
            if (!ObjectUtils.isEmpty(sb.toString())) sb.append(" ");
            sb.append(last.trim());
        }
        return sb.toString();
    }
}
