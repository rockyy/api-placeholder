package com.hdfcbank.insurance.hli.process.models.mapper;

import com.hdfcbank.insurance.adapter.process.models.response.LGLCResponse;
import com.hdfcbank.insurance.hli.process.models.enums.LCUserType;
import com.hdfcbank.insurance.hli.process.models.response.HLILGLCResponse;
import lombok.experimental.UtilityClass;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@UtilityClass
public class LGLCDataMapper {

    public static HLILGLCResponse map(LGLCResponse source) {
        HLILGLCResponse.LifeLc lifeLc = null;
        HLILGLCResponse.LifeLc nonLifeLc = null;
        if (source.getLcDetails() != null) {
            for (LGLCResponse.LCDetails lc : source.getLcDetails()) {
                HLILGLCResponse.LifeLc mappedLc = HLILGLCResponse.LifeLc.builder().lcCode(null).bancaCode(lc.getBancaCode()).leadRefNumber(lc.getLeadRefNumber()).build();

                LCUserType userType = LCUserType.valueOf(lc.getLcType().toUpperCase());
                switch (userType) {
                    case HSALES -> {
                        lifeLc = mappedLc;
                        nonLifeLc = mappedLc;
                    }
                    case HLIFE -> lifeLc = mappedLc;
                    case HERGO -> nonLifeLc = mappedLc;
                }
            }
        }

        return HLILGLCResponse.builder()
                .lgCode(source.getLgDetails() != null ? source.getLgDetails().getLgCode() : null)
                .salesExeCd(source.getSalesExeCode())
                .originMode(source.getOriginMode())
                .agencyCode(source.getAgencyCode())
                .associateCd(source.getAssociateCd())
                .filler1(source.getFiller1())
                .nonLifeLc(nonLifeLc)
                .lifeLc(lifeLc)
                .lgFieldLabel(source.getLgDetails() != null ? source.getLgDetails().getLgFieldLabel() : null)
                .lcFieldLabel(source.getLcFieldLabel() != null ? source.getLcFieldLabel() : null)
                .hSaleCenterCode(source.getHSaleCenterCode() != null ? source.getHSaleCenterCode() : null)
                .build();
    }
}
