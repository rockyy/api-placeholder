package com.hdfcbank.insurance.hli.process.models;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Builder
@Getter
@Setter
public class EsignResponse {
    private BorrowersEsignDetail borrowerEsignDetail;
}
