package com.hdfcbank.insurance.hli.process.models.response;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@ToString
public class HLILGLCResponse {

    private String lgCode;
    private LifeLc lifeLc;
    private LifeLc nonLifeLc;
    private String salesExeCd;
    private String originMode;
    private String agencyCode;
    private String associateCd;
    private String filler1;
    private String lgFieldLabel;
    private String lcFieldLabel;
    private String hSaleCenterCode;

    @Getter
    @Setter
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    @ToString
    public static class LifeLc {
        private String lcCode;
        private String bancaCode;
        private String leadRefNumber;
    }
}
