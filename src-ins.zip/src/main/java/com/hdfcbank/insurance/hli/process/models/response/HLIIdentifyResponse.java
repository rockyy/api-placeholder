package com.hdfcbank.insurance.hli.process.models.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class HLIIdentifyResponse {
    @JsonProperty(defaultValue = "true")
    private String isEligible;
    @JsonProperty("borrowerFirstName")
    private String borrowerFirstName;
    @JsonProperty(defaultValue = "********3456")
    private String loanFileNumber;
    @JsonProperty(defaultValue = "** *** 2000")
    private String borrowerDob;
    @JsonProperty(defaultValue = "+91 ******9876")
    private String borrowerMobile;

}
