package com.hdfcbank.insurance.hli.common.annotation;

import com.hdfcbank.insurance.hli.common.enums.JourneyStateName;

import java.lang.annotation.*;

@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface FailureState {

    JourneyStateName value();
}