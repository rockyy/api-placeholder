package com.hdfcbank.insurance.hli.process.models;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import tools.jackson.databind.JsonNode;
import com.hdfcbank.insurance.hli.process.models.enums.SourceSystem;
import com.hdfcbank.insurance.hli.process.models.mapper.HLICallbackPayload;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Pattern;
import lombok.*;

import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@ToString
@JsonIgnoreProperties(ignoreUnknown = true)
public class SubmitFinalProposalCallback implements HLICallbackPayload {

    private String journeyId;
    private JsonNode submitILPSProposalRequest;
    private SubmitILPSProposalResponse submitILPSProposalResponse;

    @Getter
    @Setter
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    @ToString
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class SubmitILPSProposalResponse {
        @JsonProperty("SIGNED_DOCUMENT")
        private List<SignedDocument> signedDocument;

        @JsonProperty("LOAN_DETAIL")
        private LoanDetailResponse loanDetail;

        @JsonProperty("PRODUCT_INFO")
        private ProductInfoResponse productInfo;

        @Getter
        @Setter
        @NoArgsConstructor
        @AllArgsConstructor
        @Builder
        @ToString
        @JsonIgnoreProperties(ignoreUnknown = true)
        public static class LoanDetailResponse {

            @JsonProperty("PARENT_FILE_NUMBER")
            private String parentFileNumber;

            @JsonProperty("JOURNEY_ID")
            private String journeyId;

            @JsonProperty("IPF_FILE_NUMBER")
            private String ipfFileNumber;

            @JsonProperty("FILLER1")
            private String filler1;

            @JsonProperty("FILLER2")
            private String filler2;
        }

        @Getter
        @Setter
        @NoArgsConstructor
        @AllArgsConstructor
        @Builder
        @ToString
        @JsonIgnoreProperties(ignoreUnknown = true)
        public static class ProductInfoResponse {

            @JsonProperty("BGR")
            private Product bgr;

            @JsonProperty("HCA")
            private Product hca;

            @JsonProperty("CPPLUS")
            private List<Product> cpplus;
        }

        @Getter
        @Setter
        @NoArgsConstructor
        @AllArgsConstructor
        @Builder
        @ToString
        @JsonIgnoreProperties(ignoreUnknown = true)
        public static class Product {

            @JsonProperty("INSURANCE_QUOTE_ID")
            private String insuranceQuoteId;

            @JsonProperty("POLICY_REC_NO")
            private String policyRecNo;

            @JsonProperty("FILLER3")
            private String filler3;
        }

        @Getter
        @Setter
        @NoArgsConstructor
        @AllArgsConstructor
        @Builder
        @ToString
        @JsonIgnoreProperties(ignoreUnknown = true)
        public static class HcaProduct {

            @JsonProperty("INSURANCE_QUOTE_ID")
            private String insuranceQuoteId;

            @JsonProperty("POLICY_REC_NO")
            private String policyRecNo;

            @JsonProperty("FILLER4")
            private String filler4;
        }

        @Getter
        @Setter
        @NoArgsConstructor
        @AllArgsConstructor
        @Builder
        @ToString
        @JsonIgnoreProperties(ignoreUnknown = true)
        public static class CppProduct {

            @JsonProperty("INSURANCE_QUOTE_ID")
            private String insuranceQuoteId;

            @JsonProperty("POLICY_REC_NO")
            private String policyRecNo;

            @JsonProperty("FILLER5")
            private String filler5;
        }

        @Getter
        @Setter
        @NoArgsConstructor
        @AllArgsConstructor
        @Builder
        @ToString
        @JsonIgnoreProperties(ignoreUnknown = true)
        public static class SignedDocument {

            @JsonProperty("QUOTE_ID")
            private String quoteId;

            @JsonProperty("STATUS")
            private String status;

            @JsonProperty("SUCCESS_MESSAGE")
            private String successMessage;

            @JsonProperty("ERRORS")
            private Object errors;

            @JsonProperty("LEAD_STATUS")
            private String leadStatus;
        }
    }
}
