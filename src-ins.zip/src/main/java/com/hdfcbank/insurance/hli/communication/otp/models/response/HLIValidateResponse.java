package com.hdfcbank.insurance.hli.communication.otp.models.response;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@ToString
public class HLIValidateResponse {
    private Integer incorrectAttempts;
    private boolean otpValidated;
    private int retryOtpAttemptsConsumed;
    private int retryOtpAttemptsLeft;
    private int verifyOtpAttemptsConsumed;
    private int verifyOtpAttemptsLeft;
}
