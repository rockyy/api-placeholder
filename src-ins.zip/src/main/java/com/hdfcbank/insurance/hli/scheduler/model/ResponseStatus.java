package com.hdfcbank.insurance.hli.scheduler.model;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum ResponseStatus {

    APPR("APPR", "APPR"),
    SANC("SANC", "SANC"),
    DBFX("DBFX", "DBFX"),
    FD_DBMD("FD_DBMD", "FD/DBMD"),
    CN("CN", "CN"),
    CL("CL", "CL");

    private final String display;
    private final String ipfStatusCode;
}
