package com.hdfcbank.insurance.hli.process.service;

import com.hdfcbank.common.models.vo.core.ApiResponse;
import com.hdfcbank.insurance.adapter.process.models.response.LGLCResponse;
import com.hdfcbank.insurance.hli.process.models.request.HLILGLCRequest;
import com.hdfcbank.insurance.hli.process.models.request.HLISubmitAnswerRequest;
import com.hdfcbank.insurance.hli.process.models.response.HLIProposalQuestionResponse;
import com.hdfcbank.insurance.hli.process.models.response.HLISubmitAnswerResponse;

public interface HLIQuestionService {

    ApiResponse<HLIProposalQuestionResponse> getProposalQuestions();
    ApiResponse<HLISubmitAnswerResponse> submitProposal(HLISubmitAnswerRequest hliSubmitAnswerRequest);
    ApiResponse<LGLCResponse> fetchLgLcDetails(HLILGLCRequest request);
}
