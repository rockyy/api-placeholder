package com.hdfcbank.insurance.hli.process.models.request;

import com.hdfcbank.insurance.hli.process.models.enums.CallbackType;
import jakarta.validation.constraints.NotEmpty;
import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@ToString
public class ResendESignRequest {

    @NotEmpty
    private String borrowerId;
}
