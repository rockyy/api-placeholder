package com.hdfcbank.insurance.hli.process.service;

import com.hdfcbank.common.models.vo.core.ApiResponse;
import com.hdfcbank.insurance.adapter.process.models.response.PremiumQuestionResponse;
import com.hdfcbank.insurance.hli.process.models.request.HLIFetchPricingRequest;
import com.hdfcbank.insurance.hli.process.models.request.HLIFetchPricingDetailsRequest;
import com.hdfcbank.insurance.hli.process.models.response.HLIFetchPricingResponse;

import java.util.concurrent.ExecutionException;

public interface HLIPricingService {

    ApiResponse<HLIFetchPricingResponse> fetchPricing(HLIFetchPricingRequest hliFetchPricingRequest) throws ExecutionException, InterruptedException;

    ApiResponse<PremiumQuestionResponse> fetchPricingDetails(HLIFetchPricingDetailsRequest hliFetchPricingDetailsRequest);

}
