package com.hdfcbank.insurance.hli.util;

import com.hdfcbank.insurance.hli.common.constant.HLICommonConstants;
import com.hdfcbank.insurance.hli.process.models.response.HLIIdentifyResponse;
import lombok.experimental.UtilityClass;

@UtilityClass
public class HLIFieldMasking {

    public static void fieldsMasking(HLIIdentifyResponse hliIdentifyResponse) {
        hliIdentifyResponse.setBorrowerDob(maskBorrowerDob(hliIdentifyResponse.getBorrowerDob()));
        hliIdentifyResponse.setBorrowerMobile(maskBorrowerMobile(hliIdentifyResponse.getBorrowerMobile()));
        hliIdentifyResponse.setLoanFileNumber(maskLoanFileNumber(hliIdentifyResponse.getLoanFileNumber()));
    }

    // Mask loan file number: "**** **2345"
    public static String maskLoanFileNumber(String loanFileNumber) {
        if (loanFileNumber == null || loanFileNumber.length() <= HLICommonConstants.UNMASKED_VALUE_LOAN_NUMBER) {
            return loanFileNumber;
        }
        int unmaskedLength = HLICommonConstants.UNMASKED_VALUE_LOAN_NUMBER;
        int maskedLength = loanFileNumber.length() - unmaskedLength;

        String visiblePart = loanFileNumber.substring(maskedLength);
        String maskedPart = "*".repeat(maskedLength);

        return maskedPart + visiblePart;
    }

    // Mask borrower DOB: "** *** 1990"
    public static String maskBorrowerDob(String dob) {
        if (dob == null || dob.length() < 4) return dob;

        String[] parts = dob.split("[/\\-\\s]"); // split by /, -, or space
        if (parts.length != 3) return dob;

        return "%s %s %s".formatted(
                "*".repeat(parts[0].length()),
                "*".repeat(parts[1].length()),
                parts[2]
        );
    }

    // Mask mobile: "+91 ******6780"
    public static String maskBorrowerMobile(String mobile) {

        if (mobile == null || mobile.length() <= HLICommonConstants.UNMASKED_VALUE_SUFFIX) {
            return mobile;
        }
        Integer unmaskedLength = HLICommonConstants.UNMASKED_VALUE_SUFFIX;
        Integer unMaskCountryCode = HLICommonConstants.UNMASKED_VALUE_PREFIX;
        String substring = mobile.substring(mobile.length() - unmaskedLength);
        if (mobile.startsWith("+") && mobile.length() > unMaskCountryCode + unmaskedLength) {
            String countryCode = mobile.substring(0, unMaskCountryCode);
            String middleMasked = "*".repeat(mobile.length() - unMaskCountryCode - unmaskedLength);
            return countryCode + middleMasked + substring;
        } else {
            String masked = "*".repeat(mobile.length() - unmaskedLength);
            return  masked + substring;
        }
    }
}