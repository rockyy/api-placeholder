package com.hdfcbank.insurance.hli.process.models.request;

import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import java.util.Map;

@Component
@ConfigurationProperties(prefix = "decision")
@Getter
@Setter
public class DecisionParameterConfig {
    private Map<String, String> parameters;
}