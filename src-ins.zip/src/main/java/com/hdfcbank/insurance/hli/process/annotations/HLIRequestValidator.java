package com.hdfcbank.insurance.hli.process.annotations;

import com.hdfcbank.insurance.hli.process.validators.LoanIdentifiersValidator;
import com.hdfcbank.insurance.hli.process.models.enums.SourceSystem;
import jakarta.validation.Constraint;
import jakarta.validation.Payload;

import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;

import static java.lang.annotation.ElementType.*;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

@Constraint(validatedBy = LoanIdentifiersValidator.class)
@Target({TYPE, FIELD, ANNOTATION_TYPE})
@Retention(RUNTIME)
@Documented
public @interface HLIRequestValidator {
    String message() default "DOB must contain a valid value";

    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};
    SourceSystem[] allowed() default {};
}
