package com.hdfcbank.insurance.hli.communication.consent.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableAsync;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.sqs.SqsClient;

import java.net.URI;

@Configuration("consentsSqs")
@EnableAsync
public class SqsConfig {

    @Autowired
    private ConsentsApiProperties consentsApiProperties;

    @Autowired
    private AwsProperties awsProperties;

    @Bean("consentsSqsClient")
    public SqsClient sqsClient() {
        return SqsClient.builder()
                .region(Region.of(awsProperties.getRegion()))
                .endpointOverride(URI.create(consentsApiProperties.getQueueUrl()))
                .build();
    }
}