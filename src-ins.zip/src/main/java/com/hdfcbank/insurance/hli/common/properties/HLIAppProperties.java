package com.hdfcbank.insurance.hli.common.properties;

import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties(prefix = "app")
@Getter
@Setter
public class HLIAppProperties {
    private String channel;
    private String callBackUrl;

}
