package com.hdfcbank.insurance.hli.process.models.response;

import lombok.*;

import java.math.BigDecimal;
import java.util.List;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class InsuranceProductsResponse {

    private List<Combo> combos;
    private List<Product> product;

    @Getter
    @Setter
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class Combo {
        private String comboCode;
        private String comboName;
        private Double totalPremium;
        private BigDecimal sumInsured;
        private BigDecimal totalEmiValue;
        private int loanTerm;
        private AdditionalFeature additionalFeature;
    }

    @Getter
    @Setter
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class Product {
        private String code;
        private String productName;
        private BigDecimal suggestedBaseSumInsured;
        private BigDecimal suggestedRevisedSumInsured;
        private String suggestedPlan;
        private Double premium;
        private Double emiValue;
        private String type;
        private String name;
        private String featureTitle;
        private Integer suggestedTenure;
        private String pdfTitle;
        private String pdfUrl;
        private List<Feature> features;
        private Category category;
        private List<ProductConfig> productConfigs;
        private Integer policyStartDelay;
    }

    @Getter
    @Setter
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class AdditionalFeature{
        private String type;
        private String featureTitle;
        private String name;
        private String pdfTitle;
        private String pdfUrl;
        private List<Feature> features;
    }

    @Getter
    @Setter
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class Feature {
        private String code;
        private String name;
        private String description;
        private Integer order;
        private String icon;
    }

    @Getter
    @Setter
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class Icon {
        private String imageType;
        private String url;
        private String fileName;
        private String fileSize;
    }
    @Getter
    @Setter
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class Category {
        private Integer id;
        private String categoryName;
        private String templateName;
        private String code;
    }

    @Getter
    @Setter
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class ProductConfig {
        private String key;
        private String value;
    }
}