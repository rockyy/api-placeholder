package com.hdfcbank.insurance.hli.process.validators;

import com.hdfcbank.insurance.hli.common.constant.HLICommonConstants;
import com.hdfcbank.insurance.hli.common.enums.HLICustomCommonApiStatusCodes;
import com.hdfcbank.insurance.hli.process.annotations.HLIPremiumRequestValidator;
import com.hdfcbank.insurance.hli.process.models.request.HLIPremiumQuestionRequest;
import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.util.Objects;

@Slf4j
public class HLIPremiumQuestionValidator implements ConstraintValidator<HLIPremiumRequestValidator, HLIPremiumQuestionRequest> {

    @Override
    public boolean isValid(HLIPremiumQuestionRequest hliPremiumQuestionRequest, ConstraintValidatorContext constraintValidatorContext) {
        if (Objects.isNull(hliPremiumQuestionRequest.getSelectedProducts()) || hliPremiumQuestionRequest.getSelectedProducts().isEmpty()) {
            constraintValidatorContext.disableDefaultConstraintViolation();
            constraintValidatorContext.buildConstraintViolationWithTemplate(HLICustomCommonApiStatusCodes.SELECTED_PRODUCT_NOT_FOUND.getMessage())
                    .addPropertyNode(HLICommonConstants.SELECTED_PRODUCT_NOT_FOUND)
                    .addConstraintViolation();
            return false;
        }
        for (HLIPremiumQuestionRequest.SelectedProduct selectedProduct : hliPremiumQuestionRequest.getSelectedProducts()) {
            if (StringUtils.isEmpty(selectedProduct.getCode())) {
                constraintValidatorContext.disableDefaultConstraintViolation();
                constraintValidatorContext.buildConstraintViolationWithTemplate(HLICustomCommonApiStatusCodes.SELECTED_PRODUCT_NOT_FOUND_CODE.getMessage())
                        .addPropertyNode(HLICommonConstants.SELECTED_PRODUCT_CODE_NOT_FOUND)
                        .addConstraintViolation();
                return false;
            }

            for (String entityIds : selectedProduct.getEntityIds()) {
                if (StringUtils.isEmpty(entityIds)) {
                    constraintValidatorContext.disableDefaultConstraintViolation();
                    constraintValidatorContext.buildConstraintViolationWithTemplate(HLICustomCommonApiStatusCodes.SELECTED_PRODUCT_NOT_FOUND_ENTITY_ID.getMessage())
                            .addPropertyNode(HLICommonConstants.SELECTED_PRODUCT_ENTITY_ID_NOT_FOUND)
                            .addConstraintViolation();
                    return false;
                }
            }
        }
        return true;
    }
}
