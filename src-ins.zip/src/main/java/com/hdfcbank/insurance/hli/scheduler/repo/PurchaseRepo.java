package com.hdfcbank.insurance.hli.scheduler.repo;

import com.hdfcbank.insurance.hli.scheduler.entities.PurchaseIPFStatusEntity;
import com.hdfcbank.insurance.hli.scheduler.model.Status;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.data.mongodb.repository.Update;

import java.time.Instant;
import java.util.List;


public interface PurchaseRepo extends MongoRepository<PurchaseIPFStatusEntity, String> {

    @Query(value = "{ " +
            " 'journeyName': ?0, " +
            " 'purchaseStatus': { $in: ?1 }, " +
            " 'ipfStatus': { $in: ?2 } " +
            "}")
    List<PurchaseIPFStatusEntity> findByJourneyNameAndPurchaseStatusInAndIpfStatusIn(
            String journeyName,
            List<Status> statuses,
            List<String> ipfStatuses
    );


    @Query("{ '_id': ?0 }")
    @Update("{ '$set': { 'purchaseStatus': ?1, 'modifiedDate': ?2 } }")
    void updateStatus(String journeyId, Status status, Instant modifiedDate);
}