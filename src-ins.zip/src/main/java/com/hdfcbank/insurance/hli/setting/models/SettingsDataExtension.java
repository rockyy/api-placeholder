package com.hdfcbank.insurance.hli.setting.models;

import tools.jackson.core.JacksonException;
import tools.jackson.databind.ObjectMapper;
import lombok.Getter;
import lombok.RequiredArgsConstructor;

import java.util.function.Function;

@Getter
@RequiredArgsConstructor
public enum SettingsDataExtension {
    json(str -> {
        try {
            return new ObjectMapper().readTree(str);
        } catch (JacksonException e) {
            throw new RuntimeException(e);
        }
    }),
    html(Function.identity());

    private final Function<String, ?> parser;
}
