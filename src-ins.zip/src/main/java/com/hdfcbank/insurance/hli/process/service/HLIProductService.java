package com.hdfcbank.insurance.hli.process.service;

import com.hdfcbank.common.models.vo.core.ApiResponse;
import com.hdfcbank.insurance.adapter.process.models.response.RecommendedProductResponse;
import com.hdfcbank.insurance.hli.process.models.response.HLICurateProductResponse;
import com.hdfcbank.insurance.hli.process.models.response.HLIRecommendedProductResponse;

import java.util.concurrent.ExecutionException;

public interface HLIProductService {

    ApiResponse<HLIRecommendedProductResponse> getRecommendedProducts();

    ApiResponse<RecommendedProductResponse> getInsuranceProducts();

    ApiResponse<HLICurateProductResponse> getCurateProducts();
}
