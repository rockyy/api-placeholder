package com.hdfcbank.insurance.hli.communication.otp.service;

import com.hdfcbank.common.models.vo.core.ApiResponse;
import com.hdfcbank.insurance.hli.communication.otp.models.request.HLIValidateRequest;
import com.hdfcbank.insurance.hli.communication.otp.models.response.HLIConsentResponse;
import com.hdfcbank.insurance.hli.communication.otp.models.response.HLIValidateResponse;

public interface CommunicationService {

    ApiResponse<HLIConsentResponse> generateOTP(String journeyName, String journeyId);

    ApiResponse<HLIValidateResponse> validateCustomer(String journeyName, String journeyId, HLIValidateRequest hliValidateRequest);
}
