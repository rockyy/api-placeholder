package com.hdfcbank.insurance.hli.setting.models;
import com.hdfcbank.common.models.validation.annotation.ValueOfEnum;
import lombok.*;

@Getter
@Setter
@ToString
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SettingsRequest {
   @ValueOfEnum(SettingsDataExtension.class)
    private String extension;
}