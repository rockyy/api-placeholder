package com.hdfcbank.insurance.hli.process.models.mapper;


import com.hdfcbank.insurance.hli.process.models.response.HLIIdentifyResponse;
import com.hdfcbank.insurance.adapter.process.models.response.IdentifyResponse;
import org.mapstruct.Mapper;


@Mapper(componentModel = "spring")
public interface HLIIdentifyResponseMapper {
    HLIIdentifyResponse toHLIIdentifyResponse(IdentifyResponse data);

}
