package com.hdfcbank.insurance.hli.process.models.mapper;

import com.hdfcbank.insurance.hli.process.models.FinalProposalResponse;
import com.hdfcbank.insurance.hli.process.models.SubmitFinalProposalCallback;
import com.hdfcbank.insurance.hli.process.models.response.HLISubmitAnswerResponse;
import org.mapstruct.Mapper;
import org.mapstruct.ReportingPolicy;

import java.util.List;
import java.util.Objects;
import java.util.stream.Stream;

import static com.hdfcbank.insurance.hli.common.constant.HLICommonConstants.*;

@Mapper(componentModel = "spring", unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface SubmitFinalProposalMapper {
    FinalProposalResponse mapToFinalProposalResponse(SubmitFinalProposalCallback.SubmitILPSProposalResponse submitFinalProposalResponse);


    default SubmitFinalProposalCallback.SubmitILPSProposalResponse mapFinalProposal (String loanFileNumber,String journeyId
    ,   List<HLISubmitAnswerResponse.Proposal> proposals){
        return SubmitFinalProposalCallback.SubmitILPSProposalResponse.builder()
                .loanDetail(
                        SubmitFinalProposalCallback.SubmitILPSProposalResponse.LoanDetailResponse.builder()
                                .parentFileNumber(loanFileNumber)
                                .journeyId(journeyId)
                                .build()
                )
                .productInfo(mapProductInfo(proposals))
                .build();
    }
    default SubmitFinalProposalCallback.SubmitILPSProposalResponse.ProductInfoResponse mapProductInfo(
            List<HLISubmitAnswerResponse.Proposal> proposals
    ) {
        return SubmitFinalProposalCallback.SubmitILPSProposalResponse.ProductInfoResponse.builder()
                .bgr(getQuoteId(proposals, HDFC_BGR_4))
                .hca(getQuoteId(proposals, HDFC_ERGO_HCA))
                .cpplus(
                        Stream.of(
                                        getQuoteId(proposals, HDFC_GCP_PLUS),
                                        getQuoteId(proposals, HDFC_3D)
                                )
                                .filter(Objects::nonNull)
                                .toList()
                )
                .build();
    }


    default SubmitFinalProposalCallback.SubmitILPSProposalResponse.Product getQuoteId(
            List<HLISubmitAnswerResponse.Proposal> proposals,
            String productCode
    ) {
        if (proposals == null) return null;

        return proposals.stream()
                .filter(p -> p.getProductCode().equalsIgnoreCase(productCode))
                .map(p -> SubmitFinalProposalCallback.SubmitILPSProposalResponse.Product.builder()
                        .insuranceQuoteId(p.getQuoteId())
                        .build())
                .findFirst()
                .orElse(null);
    }
}
