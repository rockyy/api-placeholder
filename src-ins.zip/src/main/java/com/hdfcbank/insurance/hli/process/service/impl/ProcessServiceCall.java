package com.hdfcbank.insurance.hli.process.service.impl;

import com.hdfcbank.insurance.adapter.process.clients.feign.insurance.HLIProcessLayerFeignClient;
import com.hdfcbank.insurance.adapter.process.models.request.*;
import com.hdfcbank.insurance.adapter.process.models.response.*;
import com.hdfcbank.insurance.hli.common.core.ProcessLayerAPIResponseValidator;
import com.hdfcbank.insurance.hli.common.core.models.HLIAPIRequestName;
import com.hdfcbank.insurance.hli.common.properties.HLIAppProperties;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class ProcessServiceCall {
    private final HLIProcessLayerFeignClient hliProcessLayerFeignClient;
    private final HLIAppProperties hliAppProperties;

    /**
     * This method will invoke the process API to get premium questions.
     *
     * @param journeyId
     * @param premiumQuestionRequest
     * @return ApiResponse<PremiumQuestionResponse>
     */
    public PremiumQuestionResponse premiumQuestionServiceCall(String journeyId, PremiumQuestionRequest premiumQuestionRequest) {
        return ProcessLayerAPIResponseValidator.validateApiResponse(HLIAPIRequestName.FETCH_PRICE, hliProcessLayerFeignClient.getPremiumQuestion(premiumQuestionRequest, hliAppProperties.getChannel(), journeyId));
    }

    public SubmitPremiumAnswerResponse submitPremiumAnswerCall(String journeyId, SubmitPremiumAnswerRequest submitPremiumAnswerRequest) {

        return ProcessLayerAPIResponseValidator.validateApiResponse(HLIAPIRequestName.FETCH_PRICE, hliProcessLayerFeignClient.submitPremiumAnswer(submitPremiumAnswerRequest, journeyId, hliAppProperties.getChannel()));
    }

    public PricingResponse pricingServiceCall(String journeyId, PricingRequest pricingRequest) {
        return ProcessLayerAPIResponseValidator.validateApiResponse(HLIAPIRequestName.FETCH_PRICE, hliProcessLayerFeignClient.getPricing(pricingRequest, journeyId, hliAppProperties.getChannel()));
    }

    public GetLoanDetailResponse getLoanDetailCall(GetLoanDetailRequest getLoanDetailRequest, String journeyId) {
        return ProcessLayerAPIResponseValidator.validateApiResponse(HLIAPIRequestName.GET_LOAN_DETAILS, hliProcessLayerFeignClient.getLoanDetail(getLoanDetailRequest, hliAppProperties.getChannel(), journeyId));
    }

    public SubmitAnswerResponse submitAnswerProcessCall(SubmitAnswerRequest submitAnswerRequest, String journeyId) {
        return ProcessLayerAPIResponseValidator.validateApiResponse(HLIAPIRequestName.SUBMIT_ANSWER, hliProcessLayerFeignClient.submitProposalCall(submitAnswerRequest, journeyId, hliAppProperties.getChannel()));
    }

    public ProposalQuestionResponse proposalQuestionProcessCall(ProposalQuestionRequest proposalQuestionRequest, String journeyId) {
        return ProcessLayerAPIResponseValidator.validateApiResponse(HLIAPIRequestName.PROPOSAL_QUESTION, hliProcessLayerFeignClient.getProposalQuestion(proposalQuestionRequest,
                hliAppProperties.getChannel(), journeyId));
    }

    public IdentifyResponse identifyServiceCall(IdentifyRequest identifyRequest,String journeyId){
        return ProcessLayerAPIResponseValidator.validateApiResponse(HLIAPIRequestName.IDENTIFY, hliProcessLayerFeignClient.identify(identifyRequest, hliAppProperties.getChannel(), journeyId));
    }
    public RecommendedProductResponse recommendedProductCall(String journeyId, RecommendedProductRequest recommendedProductRequest) {
        return ProcessLayerAPIResponseValidator.validateApiResponse(HLIAPIRequestName.RECOMMENDED_PRODUCT,
                hliProcessLayerFeignClient.getRecommendedProductsCall(recommendedProductRequest, journeyId, hliAppProperties.getChannel()), RecommendedProductResponse::new);
    }

    public CurateProductResponse curateProductCall(String journeyId, CurateProductRequest curateProductRequest) {
        return ProcessLayerAPIResponseValidator.validateApiResponse(HLIAPIRequestName.RECOMMENDED_PRODUCT,hliProcessLayerFeignClient.getCurateProductsCall(curateProductRequest, journeyId, hliAppProperties.getChannel()));
    }

    public ContentGroupResponse contentGroupCall(ContentGroupRequest contentGroupRequest, String journeyId) {
        return hliProcessLayerFeignClient.getContentGroupCall(contentGroupRequest, journeyId, hliAppProperties.getChannel());
    }

    public KFSDetailResponse getKFSDetailCall(KFSDetailRequest contentGroupRequest, String journeyId) {
        return ProcessLayerAPIResponseValidator.validateApiResponse(HLIAPIRequestName.GET_KFS_DETAIL,hliProcessLayerFeignClient.getKFSDetails(contentGroupRequest, journeyId, hliAppProperties.getChannel()));
    }

    public InitiateEsignResponse initiateEsignCall(InitiateEsignRequest initiateEsignRequest, String journeyId) {
        return ProcessLayerAPIResponseValidator.validateApiResponse(HLIAPIRequestName.INITIATE_ESIGN,hliProcessLayerFeignClient.initiateEsign(initiateEsignRequest, hliAppProperties.getChannel(),journeyId));
    }

    public ResendESignLinkResponse resendESignLink(ResendESignLinkRequest resendESignLinkRequest, String journeyId) {
        return ProcessLayerAPIResponseValidator.validateApiResponse(HLIAPIRequestName.RESEND_ESIGN_LINK,hliProcessLayerFeignClient.resendESignLink(resendESignLinkRequest, hliAppProperties.getChannel(),journeyId));
    }

    public ESignStatusResponse eSignStatus(ESignStatusRequest eSignStatusRequest, String journeyId) {
        return ProcessLayerAPIResponseValidator.validateApiResponse(HLIAPIRequestName.ESIGN_STATUS,hliProcessLayerFeignClient.eSignStatus(eSignStatusRequest, hliAppProperties.getChannel(), journeyId));
    }
    public IPFStatusResponse checkIPFStatus(IPFStatusRequest ipfStatusRequest, String journeyId) {
        return ProcessLayerAPIResponseValidator.validateApiResponse(HLIAPIRequestName.ESIGN_STATUS,hliProcessLayerFeignClient.checkIPFStatus(ipfStatusRequest, hliAppProperties.getChannel(), journeyId));
    }

    public SubmitFinalProposalResponse finalProposalSubmission(SubmitFinalProposalRequest submitFinalProposalRequest,String journeyId){
        return ProcessLayerAPIResponseValidator.validateApiResponse(HLIAPIRequestName.FINAL_PROPOSAL_SUBMISSION,hliProcessLayerFeignClient.submitFinalProposal(submitFinalProposalRequest, hliAppProperties.getChannel(), journeyId));
    }
    public CancelLeadsResponse cancelLead(CancelLeadRequest cancelLeadRequest,String journeyId){
        return ProcessLayerAPIResponseValidator.validateApiResponse(HLIAPIRequestName.CANCEL_ELAD,hliProcessLayerFeignClient.cancelLead(cancelLeadRequest, hliAppProperties.getChannel(), journeyId));
    }

    public LGLCResponse getLgLcDetails(LGLCRequest lglcRequest,String journeyId) {
        return ProcessLayerAPIResponseValidator.validateApiResponse(HLIAPIRequestName.FETCH_LGLC, hliProcessLayerFeignClient.getLgLcDetails(lglcRequest, hliAppProperties.getChannel(), journeyId));
    }
}
