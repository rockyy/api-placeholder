package com.hdfcbank.insurance.hli.communication.otp.models.response;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@ToString
public class HLIConsentResponse {
    private String txnRef;

    private Integer retryOtpAttemptsConsumed;
    private Integer retryOtpAttemptsLeft;
    private Integer verifyOtpAttemptsConsumed;
    private Integer verifyOtpAttemptsLeft;
}
