package com.hdfcbank.insurance.hli.communication.consent.service;

import tools.jackson.databind.ObjectMapper;
import com.hdfcbank.common.models.vo.journey.JourneyData;
import com.hdfcbank.insurance.hli.common.constant.HLICommonConstants;
import com.hdfcbank.insurance.hli.communication.consent.config.ConsentsApiProperties;
import com.hdfcbank.insurance.hli.communication.consent.model.CustomerConsentRequest;
import com.hdfcbank.insurance.hli.communication.consent.model.HLICustomerConsentRequest;
import com.hdfcbank.insurance.hli.communication.consent.model.SubmitCustomerConsentRequest;
import com.hdfcbank.insurance.hli.util.TextSanityUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import software.amazon.awssdk.services.sqs.SqsClient;
import software.amazon.awssdk.services.sqs.model.SendMessageRequest;
import software.amazon.awssdk.services.sqs.model.SendMessageResponse;

import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Slf4j
@Service
public class ConsentService {

    @Autowired
    private ConsentsApiProperties consentsApiProperties;

    @Autowired
    @Qualifier("consentsSqsClient")
    private SqsClient sqsClient;

    private final ObjectMapper mapper = new ObjectMapper();
    private static final String MOBILE_NUMBER_IDENTIFIER = "MOBILE_NUMBER";

    public void storeConsentsData(HLICustomerConsentRequest consent, JourneyData journeyData) {
        log.info("Storing consents for journeyId={}", TextSanityUtil.sanitize(journeyData.getJourneyId()));
        SubmitCustomerConsentRequest submitCustomerConsentRequest = SubmitCustomerConsentRequest.builder()
                .journeyName(journeyData.getJourneyName())
                .journeyId(journeyData.getJourneyId())
                .customerDetails(
                        SubmitCustomerConsentRequest.CustomerDetail
                                .builder()
                                .pan(journeyData.getProfile().getPanNumber())
                                .firstName(journeyData.getProfile().getCustomerFullName())
                                .lastName(StringUtils.EMPTY)
                                .dateOfBirth(journeyData.getProfile().getDateOfBirth())
                                .identifier(HLICommonConstants.ISD_CODE_INDIA + journeyData.getMobileNumber())
                                .identifierType(MOBILE_NUMBER_IDENTIFIER)
                                .build()
                )
                .build();

        publishToSqs(submitCustomerConsentRequest, consent.getCustomerConsentRequest());
    }

    private void publishToSqs(SubmitCustomerConsentRequest submitCustomerConsentRequest,
                              List<CustomerConsentRequest> consents) {

        try {
            List<SubmitCustomerConsentRequest.Consent> consentsList = new ArrayList<>();
            for (CustomerConsentRequest con : consents) {
                SubmitCustomerConsentRequest.Consent consent = SubmitCustomerConsentRequest.Consent.builder()
                        .key(con.getKey())
                        .acceptance(con.isAcceptance())
                        .build();
                consentsList.add(consent);
            }

            submitCustomerConsentRequest.getCustomerDetails().setConsents(consentsList);
            submitCustomerConsentRequest.getCustomerDetails().setConsentsCapturedDate(changeDateFormat(new Date()));

            String message = mapper.writeValueAsString(submitCustomerConsentRequest);

            log.info("Preparing to send message to SQS. Message body: {}", TextSanityUtil.sanitize(message));

            SendMessageRequest sendMessageRequest = SendMessageRequest.builder()
                    .queueUrl(consentsApiProperties.getQueueUrl())
                    .messageBody(message)
                    .build();

            SendMessageResponse response = sqsClient.sendMessage(sendMessageRequest);
            log.info("Message sent to queue: {}, messageId: {}, MD5: {}",
                    TextSanityUtil.sanitize(consentsApiProperties.getQueueUrl()),
                    TextSanityUtil.sanitize(response.messageId()),
                    TextSanityUtil.sanitize(response.md5OfMessageBody())
            );

        } catch (Exception e) {
            log.error("Error sending consent message to SQS queue {}", consentsApiProperties.getQueueUrl(), e);
        }
    }

    private String changeDateFormat(Date inputDate) {
        ZonedDateTime zonedDateTime = inputDate.toInstant().atZone(ZoneId.of(HLICommonConstants.UTC));
        DateTimeFormatter outputFormatter = DateTimeFormatter.ofPattern(HLICommonConstants.CAPTURED_DATE_OUTPUT_FORMAT);
        return zonedDateTime.format(outputFormatter);
    }
}