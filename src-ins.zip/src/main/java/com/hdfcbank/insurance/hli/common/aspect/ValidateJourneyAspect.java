package com.hdfcbank.insurance.hli.common.aspect;

import com.hdfcbank.adapters.clients.feign.journey.JourneyServiceFeignClient;
import com.hdfcbank.common.models.constant.RequestHeaders;
import com.hdfcbank.common.models.vo.core.ErrorRef;
import com.hdfcbank.common.models.vo.journey.JourneyData;
import com.hdfcbank.common.models.vo.journey.JourneyState;
import com.hdfcbank.exception.BusinessValidationException;
import com.hdfcbank.insurance.adapter.common.util.CustomValidationStatus;
import com.hdfcbank.insurance.hli.common.annotation.ValidateJourney;
import com.hdfcbank.insurance.hli.common.config.JourneyContextHolder;
import com.hdfcbank.insurance.hli.common.constant.HLICommonConstants;
import com.hdfcbank.insurance.hli.common.enums.HLICustomCommonApiStatusCodes;
import com.hdfcbank.insurance.hli.common.enums.JourneyStateName;
import com.hdfcbank.insurance.hli.common.exception.CustomValidationException;
import com.hdfcbank.insurance.hli.util.TextSanityUtil;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Objects;


@Aspect
@Component
@RequiredArgsConstructor
@Slf4j
public class ValidateJourneyAspect {

    private final JourneyServiceFeignClient journeyService;

    @Before("@annotation(com.hdfcbank.insurance.hli.common.annotation.ValidateJourney)")
    public void validateJourney(JoinPoint joinPoint) {
        MethodSignature signature = (MethodSignature) joinPoint.getSignature();
        ValidateJourney validateJourney = signature.getMethod().getAnnotation(ValidateJourney.class);
        String journeyId = extractJourneyIdFromHeader();
        log.info("Journey Id is :: {}", TextSanityUtil.sanitize(journeyId));
        JourneyData journeyData = journeyService.fetch(journeyId);
        if (journeyData == null) {
            throw new BusinessValidationException(ErrorRef.of(HLICustomCommonApiStatusCodes.JOURNEY_DETAILS_NOT_FOUND.getCode()),HLICustomCommonApiStatusCodes.JOURNEY_DETAILS_NOT_FOUND.getMessage());
        }

        List<String> journeyStates = journeyData.getJourneyDetail()
                .getJourneyStates()
                .stream()
                .map(JourneyState::getStateName)
                .toList();

        checkDropOffState(journeyData, journeyStates);
        validateJourneyState(journeyStates, validateJourney, journeyId);
        JourneyContextHolder.setJourneyData(journeyData);
    }

    private void checkDropOffState(JourneyData journeyData, List<String> journeyStates) {

        if (journeyStates.contains(JourneyStateName.BUSINESS_VALIDATION_FAILED.name())) {
            Map<String, Map<String, ?>> systemData = journeyData.getJourneyDetail().getSystemData();
            Map<String, Object> journeyDetail = (Map<String, Object>) systemData.get(HLICommonConstants.JOURNEY_STATUS_DETAIL);

            if (Objects.nonNull(journeyDetail)) {
                Object dropOff = journeyDetail.get(HLICommonConstants.JOURNEY_DROP_OFF);
                if (dropOff instanceof CustomValidationStatus apiResponseStatus) {
                    throw new CustomValidationException(
                            HLICustomCommonApiStatusCodes.CUSTOM_VALIDATION_EXCEPTION,
                            apiResponseStatus.getTitle(),
                            apiResponseStatus.getType(),
                            apiResponseStatus.getErrors()
                    );
                }
            }
        }
    }

    private void validateJourneyState(List<String> journeyStates, ValidateJourney validateJourney, String journeyId) {

        for (JourneyStateName state : validateJourney.shouldExists()) {
            if (!journeyStates.contains(state.name())) {
                log.error("Required journey state missing for journeyId: {}. Required state: {}", journeyId, state);
                stateNotMaintainedException();
            }
        }

        for (JourneyStateName state : validateJourney.shouldNotExists()) {
            if (journeyStates.contains(state.name())) {
                log.error("Journey state should not be present for journeyId: {}. State: {}", journeyId, state);
                stateNotMaintainedException();
            }
        }

        if (validateJourney.hasAny().length > 0) {
            boolean foundAny = Arrays.stream(validateJourney.hasAny())
                    .map(JourneyStateName::name)
                    .anyMatch(journeyStates::contains);

            if (!foundAny) {
                log.error("None of the expected states are present for journeyId: {}. Expected any of: {}", journeyId, Arrays.toString(validateJourney.hasAny()));
                stateNotMaintainedException();
            }
        }
    }

    private void stateNotMaintainedException() {
        throw new BusinessValidationException(
                ErrorRef.of(HLICustomCommonApiStatusCodes
                        .JOURNEY_STATE_NOT_MAINTAINED.getCode()),
                HLICustomCommonApiStatusCodes
                        .JOURNEY_STATE_NOT_MAINTAINED.getMessage());
    }

    @After("@annotation(com.hdfcbank.insurance.hli.common.annotation.ValidateJourney)")
    public void clearJourneyContext() {
        JourneyContextHolder.clear();
    }

    private String extractJourneyIdFromHeader() {
        ServletRequestAttributes attributes = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
        if (attributes == null) {
            log.error("RequestAttributes is null — cannot extract header");
            return null;
        }
        HttpServletRequest request = attributes.getRequest();
        return request.getHeader(RequestHeaders.JOURNEY_ID);
    }

}



