package com.hdfcbank.insurance.hli.process.models.request;

import com.hdfcbank.insurance.hli.process.annotations.HLIPremiumRequestValidator;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.*;

import java.util.List;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@HLIPremiumRequestValidator
public class HLIPremiumQuestionRequest {
    @NotNull
    @NotEmpty
    private String questionType;
    @NotNull
    private List<SelectedProduct> selectedProducts;

    @Getter
    @Setter
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class SelectedProduct {
        @NotNull
        @NotEmpty
        private String code;
        @NotNull
        @NotEmpty
        private List<String> entityIds;
    }
}
