package com.hdfcbank.insurance.hli.process.models;

import lombok.experimental.UtilityClass;

@UtilityClass
public class HLIProcessConstant {
    // Request page names
    public static final String PAGE_LANDING = "landing";
    // Entity Types
    public static final String ENTITY_TYPE_PRODUCT = "product";
    // Section Titles
    public static final String SECTION_ADDITIONAL = "ADDITIONAL";
    public static final String SECTION_VIEW_POLICY_DETAILS = "policy_details";
    // Map Keys for detailsMap
    public static final String KEY_PRODUCT_TYPE = "productType";
    public static final String KEY_PRODUCT_NAME = "productName";
    public static final String KEY_PRODUCT_TITLE = "productTitle";
    public static final String KEY_PDF_TITLE = "PDF_TITLE";
    public static final String KEY_PDF_URL = "PDF_URL";
    public static final String KEY_COVERAGES = "Coverages";

}