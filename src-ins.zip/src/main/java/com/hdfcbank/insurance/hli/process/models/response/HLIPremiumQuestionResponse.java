package com.hdfcbank.insurance.hli.process.models.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@Builder
public class HLIPremiumQuestionResponse {
    private List<GenericQuestion> genericQuestions;
    private List<ProductWiseQuestion> productWiseQuestions;


    @Getter
    @Setter
    @Builder
    public static class GenericQuestion {
        private String questionKey;
        private String question;
        private String valueType;
        private List<String> options;
        private Integer sequence;
        private Validation validations;
        private Boolean isMandatory;
    }

    @Getter
    @Setter
    @Builder
    public static class ProductWiseQuestion {
        private String code;
        private String quoteId;
        private List<Question> questions;
    }

    @Getter
    @Setter
    @Builder
    public static class Question {
        private String questionKey;
        @JsonProperty(value = "question")
        private String questionType;
        private String valueType;
        private List<String> options;
        private int sequence;
        private Validation validations;
        private boolean isMandatory;
    }

    @Getter
    @Setter
    @Builder
    public static class Validation {
        private String validationType;
        private String validationValue;
        private String validationMessage;
    }
}
