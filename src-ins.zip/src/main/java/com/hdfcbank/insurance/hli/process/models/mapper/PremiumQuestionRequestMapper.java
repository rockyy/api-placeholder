package com.hdfcbank.insurance.hli.process.models.mapper;


import com.hdfcbank.insurance.adapter.process.models.request.PremiumQuestionRequest;
import com.hdfcbank.insurance.hli.process.models.request.HLIFetchPricingDetailsRequest;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring")
public interface PremiumQuestionRequestMapper {

    @Mapping(target = "leadId", source = "leadId")
    @Mapping(source = "source.products", target = "selectedProducts")
    PremiumQuestionRequest toPremiumQuestionRequest(HLIFetchPricingDetailsRequest source, String leadId);

    PremiumQuestionRequest.SelectedProduct toSelectedProduct(HLIFetchPricingDetailsRequest.Products product);
}

