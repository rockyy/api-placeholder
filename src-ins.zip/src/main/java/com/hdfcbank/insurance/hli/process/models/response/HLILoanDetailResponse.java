package com.hdfcbank.insurance.hli.process.models.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.*;

import java.math.BigDecimal;
import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@ToString
@JsonInclude(JsonInclude.Include.NON_NULL)
public class HLILoanDetailResponse {

    private String maxIpfLimit;
    private String currency;
    private BigDecimal loanValue;
    private Integer loanTenure;
    private List<Customer> customers;
    private Property property;
    private ReturnJourneyDetail returnJourneyDetail;

    @Getter
    @Setter
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    @ToString
    public static class Customer{
        private String id;
        private String name;
        private String relationToBorrower;
        private String dateOfBirth;
        private String gender;
        private String occupation;
        private String pan;
        private String education;
        private String number;
        private BigDecimal grossAnnualIncome;
    }

    @Getter
    @Setter
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    @ToString
    public static class Property{
        private String id;
        private String name;
    }

    @Getter
    @Setter
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    @ToString
    public static class ReturnJourneyDetail{
        private String lastState;
        private String loadContext;
        private String oldJourneyId;
        private String lastStateMessage;
        private String title;
        private String esignInitiatedDate;
    }
}
