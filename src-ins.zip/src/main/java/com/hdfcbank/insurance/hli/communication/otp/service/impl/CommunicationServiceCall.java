package com.hdfcbank.insurance.hli.communication.otp.service.impl;

import com.hdfcbank.insurance.adapter.communication.clients.CommunicationServiceFeignClient;
import com.hdfcbank.insurance.adapter.communication.request.GenerateOTPRequest;
import com.hdfcbank.insurance.adapter.communication.request.ValidateOTPRequest;
import com.hdfcbank.insurance.adapter.communication.response.GenerateOTPResponse;
import com.hdfcbank.insurance.adapter.communication.response.ValidateOTPResponse;
import com.hdfcbank.insurance.hli.common.core.CustomAPIResponseValidator;
import com.hdfcbank.insurance.hli.common.core.models.HLIAPIRequestName;
import com.hdfcbank.insurance.hli.common.properties.HLIAppProperties;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

@Slf4j
@RequiredArgsConstructor
@Component
public class CommunicationServiceCall {
    private final CommunicationServiceFeignClient communicationServiceFeignClient;
    private final HLIAppProperties hliAppProperties;

    public GenerateOTPResponse sendOtp(String journeyId, GenerateOTPRequest generateOTPRequest) {
        return CustomAPIResponseValidator.validateApiResponse(HLIAPIRequestName.SEND_OTP, communicationServiceFeignClient.sendOTP(journeyId, hliAppProperties.getChannel(), generateOTPRequest));
    }

    public ValidateOTPResponse validateOTPCall(ValidateOTPRequest validateOTPRequest, String journeyID){
        return CustomAPIResponseValidator.validateApiResponse(HLIAPIRequestName.VALIDATE_OTP, communicationServiceFeignClient.validateCustomer(validateOTPRequest,journeyID, hliAppProperties.getChannel()));
    }
}
