package com.hdfcbank.insurance.hli.process.models;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class SignerInfo {

    private String signerRefId;
    private String signerId;
    private String documentId;
    private String referenceDocId;
    private String signedAt;
}