package com.hdfcbank.insurance.hli.process.service;

import com.hdfcbank.common.models.vo.core.ApiResponse;
import com.hdfcbank.insurance.hli.process.models.request.CallbackRequest;
import com.hdfcbank.insurance.hli.process.models.response.CallbackResponse;

public interface CallbackService {
 ApiResponse<CallbackResponse> performAction(CallbackRequest callbackRequest);
}
