package com.hdfcbank.insurance.hli.process.validators;

import com.hdfcbank.insurance.hli.common.enums.HLICustomCommonApiStatusCodes;
import com.hdfcbank.insurance.hli.common.constant.HLICommonConstants;
import com.hdfcbank.insurance.hli.process.models.enums.SourceSystem;
import com.hdfcbank.insurance.hli.process.annotations.HLIRequestValidator;
import com.hdfcbank.insurance.hli.process.models.request.HLIIdentifyRequest;
import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;
import lombok.extern.slf4j.Slf4j;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.Set;

@Slf4j
public class LoanIdentifiersValidator implements ConstraintValidator<HLIRequestValidator, HLIIdentifyRequest> {
    private Set<SourceSystem> allowedSources;

    @Override
    public void initialize(HLIRequestValidator annotation) {
        allowedSources = Set.of(annotation.allowed());
    }
    @Override
    public boolean isValid(HLIIdentifyRequest hliIdentifyRequest, ConstraintValidatorContext constraintValidatorContext) {
      log.info("Request validation started for loan number {} Status is :: {}",hliIdentifyRequest.getLoanFileNumber(),hliIdentifyRequest.getSource());
        if(allowedSources.contains(hliIdentifyRequest.getSource())){
            constraintValidatorContext.disableDefaultConstraintViolation();
            constraintValidatorContext.buildConstraintViolationWithTemplate(HLICustomCommonApiStatusCodes.SOURCE_NOT_FOUND.getMessage())
                    .addPropertyNode(HLICommonConstants.SOURCE_PROPERTY_NODE)
                    .addConstraintViolation();
            return false;
        }
        if(hliIdentifyRequest.getSource().equals(SourceSystem.STATIC) && hliIdentifyRequest.getDob()==null){
            constraintValidatorContext.disableDefaultConstraintViolation();
            constraintValidatorContext.buildConstraintViolationWithTemplate(HLICustomCommonApiStatusCodes.DOB_NOT_FOUND.getMessage())
                    .addPropertyNode(HLICommonConstants.DOB_PROPERTY_NODE)
                    .addConstraintViolation();
            return false;
        }
        if(hliIdentifyRequest.getSource().equals(SourceSystem.STATIC)){
            DateTimeFormatter DOB_FORMATTER = DateTimeFormatter.ofPattern(HLICommonConstants.DOB_FORMAT);
            try{
                LocalDate.parse(hliIdentifyRequest.getDob(), DOB_FORMATTER);
            } catch (DateTimeParseException e) {
                constraintValidatorContext.disableDefaultConstraintViolation();
                constraintValidatorContext.buildConstraintViolationWithTemplate(HLICustomCommonApiStatusCodes.INVALID_DOB_FORMAT.getMessage())
                        .addPropertyNode(HLICommonConstants.DOB_PROPERTY_NODE)
                        .addConstraintViolation();
                return false;
            }
        }
        return true;
    }
}
