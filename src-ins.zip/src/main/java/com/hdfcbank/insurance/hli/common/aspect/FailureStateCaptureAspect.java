package com.hdfcbank.insurance.hli.common.aspect;

import com.hdfcbank.insurance.hli.common.annotation.FailureState;
import com.hdfcbank.insurance.hli.common.config.FailureStateContextHolder;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.stereotype.Component;

import java.lang.reflect.Method;

@Aspect
@Component
@Slf4j
public class FailureStateCaptureAspect {

    @Before("@annotation(failureState)")
    public void captureFailureState(JoinPoint joinPoint, FailureState failureState) {

        FailureStateContextHolder.set(failureState.value());

        log.debug("Failure state captured : {}", failureState.value());

        for (Object arg : joinPoint.getArgs()) {
            if (arg instanceof String journeyId) {
                FailureStateContextHolder.setJourneyId(journeyId);
            }
        }
    }
}