package com.hdfcbank.insurance.hli.scheduler.model;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum CancelLeadStatus {
    PURCHASED,
    SUCCESS,
    FAILED
}