package com.hdfcbank.insurance.hli.process.models.response;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CallbackResponse {
   private String message;
}
