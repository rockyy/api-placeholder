package com.hdfcbank.insurance.hli.process.models.enums;

import lombok.Getter;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;
//TODO: convert this into property from yaml
@Getter
public enum ProductCode {

    PROPERTY_COVER(List.of("BORROWER"),"Property", "Property Cover", "Property Coverages", List.of("HDFC_BGR_4", "HDFC_ERGO_HCA", "HDFC_ERGO_HCA_FLOATER")),
    LIFE_COVER(List.of("BORROWER","CO BORROWER"),"Life", "Life Cover", "Life Coverages", List.of("HDFC_3D", "HDFC_GCP_PLUS"));

    private final List<String> ownerType;
    private final String type;
    private final String name;
    private final String featureTitle;
    private final List<String> productCodes;

    ProductCode(List<String> ownerType, String type, String name, String featureTitle, List<String> productCodes) {
        this.ownerType = ownerType;
        this.type = type;
        this.name = name;
        this.featureTitle = featureTitle;
        this.productCodes = productCodes;
    }

    /**
     * Finds the product category by product code.
     *
     * @param productCode code of the product
     * @return Optional<ProductCategory> if found, else Optional.empty()
     */
    public static Optional<ProductCode> fromProductCode(String productCode) {
        return Arrays.stream(values())
                .filter(category -> category.productCodes.contains(productCode))
                .findFirst();
    }

}