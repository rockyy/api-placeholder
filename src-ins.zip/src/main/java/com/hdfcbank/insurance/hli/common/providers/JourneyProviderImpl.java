package com.hdfcbank.insurance.hli.common.providers;

import com.hdfcbank.adapters.clients.feign.journey.JourneyServiceFeignClient;
import com.hdfcbank.common.models.vo.journey.JourneyData;
import com.hdfcbank.starter.logging.models.JourneyAliases;
import com.hdfcbank.starter.logging.properties.JourneyAliasProperties;
import com.hdfcbank.starter.logging.providers.JourneyProvider;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
@Getter
public class JourneyProviderImpl implements JourneyProvider {
    private final JourneyServiceFeignClient journeyServiceFeignClient;
    private final JourneyAliasProperties journeyAliasProperties;

    @Override
    public JourneyData fetch(String journeyId) {
        return journeyServiceFeignClient.fetch(journeyId);
    }

    @Override
    @Cacheable(value = {JOURNEY_ALIAS_CACHE_NAME}, key = "#journeyId", unless = "#result == null")
    public JourneyAliases findBy(String journeyId) {
        return JourneyProvider.super.findBy(journeyId);
    }

    @Override
    @CachePut(value = {JOURNEY_ALIAS_CACHE_NAME}, key = "#journeyId")
    public JourneyAliases update(String journeyId, JourneyAliases journeyAliases) {
        return JourneyProvider.super.update(journeyId, journeyAliases);
    }
}
