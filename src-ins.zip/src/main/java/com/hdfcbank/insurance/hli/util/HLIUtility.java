package com.hdfcbank.insurance.hli.util;

import com.hdfcbank.common.models.vo.journey.JourneyData;
import com.hdfcbank.insurance.hli.common.constant.HLICommonConstants;
import lombok.experimental.UtilityClass;
import lombok.extern.slf4j.Slf4j;

@UtilityClass
@Slf4j
public class HLIUtility {

    public static Double mapToDouble(Object value) {
        if (value == null) {
            return 0.0;
        }
        if (value instanceof Number) {
            return ((Number) value).doubleValue();
        }
        String s = value.toString().trim();
        if (s.isEmpty() || s.equalsIgnoreCase("null")) {
            return 0.0;
        }
        try {
            return Double.parseDouble(s);
        } catch (NumberFormatException ex) {
            log.warn("Invalid number value received: {}", value);
            return 0.0;
        }
    }

}
