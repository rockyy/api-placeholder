package com.hdfcbank.insurance.hli.common.properties;
import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
@Configuration
@ConfigurationProperties(prefix = "scheduler.ipf")
@Getter
@Setter
public class IPFSchedulerConfig {

    private Config config;

    @Getter
    @Setter
    public static class Config {
        private int entitiesToProcess;
        private int corePoolSize;
        private int maximumPoolSize;
        private int initialDelay;
        private int keepTimeAlive;
        private int threadCapacity;
        private int maxRetryPerRun;
        private int maxRetryRunPerBatch;
        private int entitiesProcessDuration;
    }
}