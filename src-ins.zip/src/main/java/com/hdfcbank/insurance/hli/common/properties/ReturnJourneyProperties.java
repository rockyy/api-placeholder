package com.hdfcbank.insurance.hli.common.properties;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import java.time.Duration;
import java.util.List;

@Component
@ConfigurationProperties(prefix = "return-journey-config")
@Getter
@Setter
public class ReturnJourneyProperties {
    private List<ReturnState> returnStates;

    @Data
    public static class ReturnState {
        private String state;
        private String loadContext;
        private String message;
        private String title;
    }
}
