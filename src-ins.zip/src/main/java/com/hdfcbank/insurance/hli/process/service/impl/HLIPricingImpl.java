package com.hdfcbank.insurance.hli.process.service.impl;



import com.hdfcbank.adapters.clients.feign.journey.JourneyServiceFeignClient;
import com.hdfcbank.common.models.vo.core.ApiResponse;
import com.hdfcbank.common.models.vo.journey.JourneyData;
import com.hdfcbank.exception.BusinessValidationException;
import com.hdfcbank.insurance.adapter.process.models.request.PremiumQuestionRequest;
import com.hdfcbank.insurance.adapter.process.models.request.PricingRequest;
import com.hdfcbank.insurance.adapter.process.models.request.SubmitPremiumAnswerRequest;
import com.hdfcbank.insurance.adapter.process.models.response.PremiumQuestionResponse;
import com.hdfcbank.insurance.adapter.process.models.response.PricingResponse;
import com.hdfcbank.insurance.hli.common.config.JourneyContextHolder;
import com.hdfcbank.insurance.hli.common.constant.HLICommonConstants;
import com.hdfcbank.insurance.hli.common.enums.JourneyStateName;
import com.hdfcbank.insurance.hli.process.models.mapper.HLIFetchPricingMapper;
import com.hdfcbank.insurance.hli.process.models.mapper.HLIProductMapping;
import com.hdfcbank.insurance.hli.process.models.mapper.PremiumQuestionRequestMapper;
import com.hdfcbank.insurance.hli.process.models.mapper.PricingResponseMapper;
import com.hdfcbank.insurance.hli.process.models.request.HLIFetchPricingDetailsRequest;
import com.hdfcbank.insurance.hli.process.models.request.HLIFetchPricingRequest;
import com.hdfcbank.insurance.hli.process.models.response.HLIFetchPricingResponse;
import com.hdfcbank.insurance.hli.process.service.HLIPricingService;
import com.hdfcbank.insurance.hli.process.service.config.ProductConfiguration;
import com.hdfcbank.insurance.hli.util.ChecksumUtil;
import com.hdfcbank.insurance.hli.util.JourneyUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.expression.ExpressionParser;
import org.springframework.expression.spel.standard.SpelExpressionParser;
import org.springframework.expression.spel.support.StandardEvaluationContext;
import org.springframework.stereotype.Service;
import tools.jackson.databind.JsonNode;
import tools.jackson.databind.ObjectMapper;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class HLIPricingImpl implements HLIPricingService {

    private final JourneyServiceFeignClient journeyServiceFeignClient;
    private final ProcessServiceCall processServiceCall;
    private final Executor asyncExecutor;
    private final ObjectMapper mapper;
    private final PricingResponseMapper pricingResponseMapper;
    private final PremiumQuestionRequestMapper premiumQuestionRequestMapper;
    private final HLIFetchPricingMapper hliFetchPricingMapper;
    private final ProductConfiguration productConfiguration;


    public ApiResponse<HLIFetchPricingResponse> fetchPricing(HLIFetchPricingRequest hliFetchPricingRequest) throws BusinessValidationException {

        JourneyData journeyData = JourneyContextHolder.getJourneyData();
        String leadId = JourneyUtil.getDataFromJourneyService(journeyData.getJourneyDetail().getSystemData(), HLICommonConstants.LEAD_ID_KEY).toString();

        // Extract existing pricing response or create default
        Object pricingResponseObj = JourneyUtil.getByPath(journeyData.getJourneyDetail().getSystemData(), HLICommonConstants.PRICING_RESPONSE);

        // Check if current request matches existing pricing request
        Object existingRequest = JourneyUtil.getByPath(journeyData.getJourneyDetail().getSystemData(), HLICommonConstants.PRICING_REQUEST_PATH);
        boolean isMatchingExistingRequest = Objects.nonNull(existingRequest) && ChecksumUtil.areEqual(hliFetchPricingRequest.getProduct(), existingRequest);
        log.info("Products match existing pricing request? {}", isMatchingExistingRequest);

        PricingResponse pricingResponse = pricingResponseObj != null && isMatchingExistingRequest ? mapper.convertValue(pricingResponseObj, PricingResponse.class) : PricingResponse.builder().status(HLICommonConstants.DEFAULT_PRICING_STATUS).build();
        if (Objects.nonNull(pricingResponse.getTotalPremium()) && !StringUtils.isEmpty(pricingResponse.getTotalPremium())) {
            pricingResponse.setMonthlyEMI(calculateEMI(pricingResponse, journeyData).setScale(0, RoundingMode.UP));
            pricingResponse.setProductTenure(calculateProductTenure(pricingResponse,journeyData));
        }
        // If request does not match existing data, call premium questions and submit answers
        if (!isMatchingExistingRequest) {
            log.info("Checksum mismatch — updating pricing request data...");
            PremiumQuestionRequest premiumQuestionRequest = hliFetchPricingMapper.toPremiumQuestionRequest(leadId, hliFetchPricingRequest);
            PremiumQuestionResponse premiumQuestionResponse = processServiceCall.premiumQuestionServiceCall(journeyData.getJourneyId(), premiumQuestionRequest);
            SubmitPremiumAnswerRequest submitRequest = buildSubmitPremiumAnswerRequest(leadId, hliFetchPricingRequest, premiumQuestionResponse, journeyData);
            processServiceCall.submitPremiumAnswerCall(journeyData.getJourneyId(), submitRequest);
            log.info("Submit premium answer successful.");
        }
        // Update system data after submission
        journeyServiceFeignClient.update(JourneyUtil.toUpdateSystemDataRequest(journeyData.getJourneyId(), HLICommonConstants.PRICING_REQUEST, hliFetchPricingRequest, JourneyStateName.FETCH_PRICING_INITIATED));
        // Trigger async pricing
        triggerPricingAsync(leadId, journeyData).join();
        return ApiResponse.success(pricingResponseMapper.toHLIFetchPricingResponse(pricingResponse));
    }

    private CompletableFuture<Void> triggerPricingAsync(String leadId, JourneyData journeyData) {
        return CompletableFuture.runAsync(() -> {
            String journeyId = journeyData.getJourneyId();
            log.info("Running pricing async task on thread {}", Thread.currentThread().getName());
            PricingRequest pricingRequest = PricingRequest.builder().leadId(leadId).build();
            PricingResponse pricingResponse = processServiceCall.pricingServiceCall(journeyId, pricingRequest);
            log.info("Pricing response is :: {}", pricingResponse.getStatus());
            pricingResponse.setMonthlyEMI(calculateEMI(pricingResponse, journeyData).setScale(0, RoundingMode.UP));
            pricingResponse.setProductTenure(calculateProductTenure(pricingResponse,journeyData));
            pricingResponse.getQuotes().forEach(quote -> {
                if (pricingResponse.getQuotes().size() > 1) {
                    BigDecimal tenure = calculateProductTenure(pricingResponse, journeyData);
                    BigDecimal tenureInYears = tenure.divide(BigDecimal.valueOf(12), 2, RoundingMode.HALF_UP);
                    quote.setMonthlyEMI(calculateMonthlyEMI(tenureInYears.toPlainString(),
                            quote.getTotalPremium(), journeyData));
                } else {
                    quote.setMonthlyEMI(calculateMonthlyEMI(quote.getPolicyTenure(),
                            quote.getTotalPremium(), journeyData));
                }
            });
            journeyServiceFeignClient.update(JourneyUtil.toUpdateSystemDataRequest(journeyId, HLICommonConstants.PRICING_RESPONSE, pricingResponse, JourneyStateName.FETCH_PRICING_SUCCESS));

        }, asyncExecutor);
    }

    private SubmitPremiumAnswerRequest buildSubmitPremiumAnswerRequest(String leadId, HLIFetchPricingRequest request, PremiumQuestionResponse premiumQuestionResponse, JourneyData journeyData) {
        List<SubmitPremiumAnswerRequest.ProductWise> productWise = premiumQuestionResponse.getProductWiseQuestions()
                .stream().map(pq -> mapProductWiseAnswers(pq, request, journeyData))
                .toList();
        return SubmitPremiumAnswerRequest.builder().leadId(leadId).mode(request.getMode()).productWise(productWise).build();
    }


    private SubmitPremiumAnswerRequest.ProductWise mapProductWiseAnswers(PremiumQuestionResponse.ProductWiseQuestion productQuestion, HLIFetchPricingRequest request, JourneyData journeyData) {
        Optional<HLIFetchPricingRequest.Product> optionalProduct = request.getProduct().stream().filter(product -> product.getCode().equals(productQuestion.getCode())).findFirst();
        List<SubmitPremiumAnswerRequest.ProductWise.Answer> productWiseAnswers = new ArrayList<>();
        if (optionalProduct.isPresent()) {
            productWiseAnswers = productQuestion.getQuestions().stream().map(question ->
                    buildAnswer(question, optionalProduct.get(), productQuestion.getCode(), journeyData))
                    .filter(Objects::nonNull).collect(Collectors.toList());
            for(HLIFetchPricingRequest.Product.Answer requestAnswerObject : optionalProduct.get().getAnswers()){
                 if(productWiseAnswers.stream().noneMatch(pwa->requestAnswerObject.getQuestionKey()
                         .equalsIgnoreCase(pwa.getQuestionKey()) && requestAnswerObject.getEntityId().equalsIgnoreCase(pwa.getEntityId()))){
                    productWiseAnswers.add(SubmitPremiumAnswerRequest.ProductWise.Answer.builder()
                            .questionKey(requestAnswerObject.getQuestionKey()).answer(requestAnswerObject.getAnswer()).entityId(requestAnswerObject.getEntityId()).build());
                 }
            }
        }

        return SubmitPremiumAnswerRequest.ProductWise.builder().code(productQuestion.getCode()).answers(productWiseAnswers).build();
    }

    private SubmitPremiumAnswerRequest.ProductWise.Answer buildAnswer(PremiumQuestionResponse.ProductWiseQuestion.Question question, HLIFetchPricingRequest.Product product, String code, JourneyData journeyData) {

        String answer = product.getAnswers().stream().filter(a -> (a.getQuestionKey().equals(question.getQuestionKey()) && a.getEntityId().equalsIgnoreCase(question.getEntityId()))).map(HLIFetchPricingRequest.Product.Answer::getAnswer).findFirst().orElse(null);
        Map<String, ProductConfiguration.AnswerDetail> productAnswerDetail = productConfiguration.getData().get(code);
        if (productAnswerDetail != null) {
            ProductConfiguration.AnswerDetail answerDetail = productAnswerDetail.get(question.getQuestionKey());
            if (answerDetail != null && answer == null) {
                if (answerDetail.getValue() != null) {
                    answer = answerDetail.getValue();
                } else if (answerDetail.getJsonPath() != null) {
                    JsonNode jsonNode = mapper.valueToTree(journeyData.getJourneyDetail().getSystemData());
                    String resolvedPath = resolveJsonPath(question, answerDetail.getJsonPath());

                    answer = JourneyUtil.getValueFromJsonPath(jsonNode, resolvedPath);
                    if (answerDetail.getExpression() != null && answer != null) {
                        answer = evaluateExpression(answerDetail.getExpression(), answer);
                    }
                }
                if (answerDetail.getLookup() != null && answer != null) {
                    String normalizedAnswer = answer.replaceAll("\\s+", "").toUpperCase();
                    Map<String, String> normalizedLookup = answerDetail.getLookup().entrySet().stream()
                                    .collect(Collectors.toMap(e -> e.getKey().replaceAll("\\s+", "").toUpperCase(Locale.ROOT), Map.Entry::getValue));
                    answer = normalizedLookup.getOrDefault(normalizedAnswer, answer);
                }
            }
        }

        return SubmitPremiumAnswerRequest.ProductWise.Answer.builder().entityId(question.getEntityId()).questionKey(question.getQuestionKey()).answer(answer).build();
    }

    private String resolveJsonPath(PremiumQuestionResponse.ProductWiseQuestion.Question question, String path) {

        if (path == null) return null;
        Map<String, String> values = new HashMap<>();
        values.put("ENTITY_ID", question.getEntityId());

        String resolvedPath = path;
        for (Map.Entry<String, String> entry : values.entrySet()) {
            resolvedPath = resolvedPath.replace("#" + entry.getKey(), entry.getValue());
        }
        return resolvedPath;
    }

    private String evaluateExpression(String rawExpression, String valueStr) {
        ExpressionParser spellParser = new SpelExpressionParser();
        String expression = rawExpression.replace("%s", "#value");
        StandardEvaluationContext context = new StandardEvaluationContext();
        context.setVariable("value", Double.parseDouble(valueStr));
        Object result = spellParser.parseExpression(expression).getValue(context);
        return result != null ? result.toString() : null;
    }

    private BigDecimal calculateEMI(PricingResponse pricingResponse, JourneyData journeyData) {
        List<String> policyTenureList = pricingResponse.getQuotes().stream().map(PricingResponse.Quote::getPolicyTenure).toList();
        if(policyTenureList.isEmpty()){
            log.info("Tenure list is empty");
            return BigDecimal.ZERO;
        }
        return HLIProductMapping.emiCalculation(policyTenureList,
                journeyData, pricingResponse.getTotalPremium());
    }


    private BigDecimal calculateMonthlyEMI(String policyTenure, String totalPremium, JourneyData journeyData) {
        log.info("Inside calculateMonthlyEMI");
        return Optional.ofNullable(policyTenure).filter(tenure -> !tenure.trim().isEmpty())
                .filter(premium -> totalPremium != null && !totalPremium.trim().isEmpty())
                .map(s -> HLIProductMapping.emiCalculation(policyTenure,
                        journeyData, totalPremium)).orElse(BigDecimal.ZERO);
    }

    private BigDecimal calculateProductTenure(PricingResponse pricingResponse, JourneyData journeyData){
        List<String> policyTenureList = pricingResponse.getQuotes().stream().map(PricingResponse.Quote::getPolicyTenure).toList();
        if(policyTenureList.isEmpty()){
            log.info("Tenure is empty");
            return BigDecimal.ZERO;
        }
        BigDecimal value = HLIProductMapping.productTenure(policyTenureList, journeyData);
        return value.multiply(BigDecimal.valueOf(HLICommonConstants.MONTHS_TO_YEAR_UNIT)).setScale(HLICommonConstants.SCALE_VALUE, RoundingMode.HALF_UP);
    }

    /**
     * @param hliFetchPricingDetailsRequest request to question of products
     * @return ApiResponse<HLIFetchPricingProductDetailsResponse>
     */
    @Override
    public ApiResponse<PremiumQuestionResponse> fetchPricingDetails(HLIFetchPricingDetailsRequest hliFetchPricingDetailsRequest) {
        log.info("Fetch pricing question details initiated");
        JourneyData journeyData = JourneyContextHolder.getJourneyData();
        journeyServiceFeignClient.update(JourneyUtil.toUpdateSystemDataRequest(journeyData.getJourneyId(), HLICommonConstants.PRICING_QUESTION_REQUEST, hliFetchPricingDetailsRequest, JourneyStateName.FETCH_PRICING_QUESTIONS_INITIATED));
        String leadId = JourneyUtil.getDataFromJourneyService(journeyData.getJourneyDetail().getSystemData(), HLICommonConstants.LEAD_ID_KEY).toString();
        PremiumQuestionRequest premiumQuestionRequest = premiumQuestionRequestMapper.toPremiumQuestionRequest(hliFetchPricingDetailsRequest, leadId);
        PremiumQuestionResponse premiumQuestionResponse = processServiceCall.premiumQuestionServiceCall(journeyData.getJourneyId(), premiumQuestionRequest);
        journeyServiceFeignClient.update(JourneyUtil.toUpdateSystemDataRequest(journeyData.getJourneyId(), HLICommonConstants.PRICING_QUESTION_RESPONSE, premiumQuestionResponse, JourneyStateName.FETCH_PRICING_QUESTIONS_SUCCESS));
        log.info("Fetch pricing question details completed");
        return ApiResponse.success(premiumQuestionResponse);
    }

}

