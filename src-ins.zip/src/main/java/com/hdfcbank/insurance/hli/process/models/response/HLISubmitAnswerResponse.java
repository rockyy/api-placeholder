package com.hdfcbank.insurance.hli.process.models.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.*;

import java.util.List;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class HLISubmitAnswerResponse {
    private String status;
    private List<Proposal> proposals;

    @Getter
    @Setter
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class Proposal {
        private String productCode;
        private String quoteId;
        private String status;
        private String medicalAdvice;
    }
}
