package com.hdfcbank.insurance.hli.process.models.enums;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

@Getter
@RequiredArgsConstructor
public enum SourceSystem {
STATIC, DYNAMIC
}
