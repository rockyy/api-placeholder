package com.hdfcbank.insurance.hli.util;

import lombok.experimental.UtilityClass;


@UtilityClass
public class TextSanityUtil {

    public static String sanitize(String request) {
        if (null != request)
            return request
                    .replace("\n", " ")
                    .replace("\r", " ")
                    .replace("\t", " ");
        return null;
    }

    public static String sanitizeForLog(Object input) {
        if (input == null) return null;
        return input.toString()
                .replaceAll("[\n\r\t]", "_"); // remove control chars
    }
}
