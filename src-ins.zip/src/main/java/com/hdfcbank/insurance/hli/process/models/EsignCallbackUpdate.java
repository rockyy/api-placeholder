package com.hdfcbank.insurance.hli.process.models;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.hdfcbank.insurance.hli.process.models.mapper.HLICallbackPayload;
import lombok.*;

import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@ToString
@JsonIgnoreProperties(ignoreUnknown = true)
public class EsignCallbackUpdate implements HLICallbackPayload {

    private String status;
    private String documentId;
    private String initiatedAt;
    private List<SignerInfo> signerInfo;
    private CustomParameter customParameter;
    private String docketId;
    private String completedAt;
    private String fileContent;
    private List<String> tiffData;
    private String journeyId;

    @Getter
    @Setter
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    @ToString
    public static class SignerInfo {
        private String signerId;
    }

    @Getter
    @Setter
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    @ToString
    public static class CustomParameter {
        private String referenceId;
    }
}
