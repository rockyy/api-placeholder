package com.hdfcbank.insurance.hli.process.models.mapper;

public interface HLICallbackPayload {
}
