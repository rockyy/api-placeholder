package com.hdfcbank.insurance.hli.communication.controller;

import com.hdfcbank.annotations.CoolingPeriod;
import com.hdfcbank.annotations.CoolingPeriodType;
import com.hdfcbank.annotations.CoolingPeriods;
import com.hdfcbank.annotations.ValidationPhase;
import com.hdfcbank.common.models.vo.core.ApiResponse;
import com.hdfcbank.insurance.hli.common.annotation.FailureState;
import com.hdfcbank.insurance.hli.common.annotation.ValidateJourney;
import com.hdfcbank.insurance.hli.communication.otp.models.request.HLIValidateRequest;
import com.hdfcbank.insurance.hli.communication.otp.models.response.HLIConsentResponse;
import com.hdfcbank.insurance.hli.communication.otp.models.response.HLIValidateResponse;
import com.hdfcbank.insurance.hli.communication.otp.service.CommunicationService;
import com.hdfcbank.starter.logging.annotations.JourneyId;
import com.hdfcbank.starter.logging.annotations.JourneyName;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import static com.hdfcbank.insurance.hli.common.enums.JourneyStateName.*;

@RestController
@RequestMapping("${app.base-path}")
@Slf4j
@RequiredArgsConstructor
public class HLICommunicationController {

    private final CommunicationService communicationService;

    /**
     * This method is used to send OTP to the client service.
     *
     * @return ApiResponse<HLIConsentResponse>
     */
    @CoolingPeriods(
            {
                    @CoolingPeriod(
                            type = CoolingPeriodType.SEND_OTP,
                            journeyName = "#journeyName",
                            identifierNames = {"loanFileNumber", "journeyName"},
                            identifierValues = {
                                    "#journeyData.journeyDetail.systemData['loanidentifydetails']['loanidentifydetails']['loanFileNumber']",
                                    "#journeyName"
                            },
                            attemptsLeftFillerField = "retryOtpAttemptsLeft",
                            attemptsConsumedFillerField = "retryOtpAttemptsConsumed",
                            incorrectAttemptCondition = "#false"
                    ),
                    @CoolingPeriod(
                            type = CoolingPeriodType.VALIDATE_OTP,
                            journeyName = "#journeyName",
                            identifierNames = {"loanFileNumber", "journeyName"},
                            identifierValues = {
                                    "#journeyData.journeyDetail.systemData['loanidentifydetails']['loanidentifydetails']['loanFileNumber']",
                                    "#journeyName"
                            },
                            attemptsLeftFillerField = "verifyOtpAttemptsLeft",
                            attemptsConsumedFillerField = "verifyOtpAttemptsConsumed",
                            incorrectAttemptCondition = "#true",
                            dropOnAttemptReach = true
                    )
            })
    @ValidateJourney(shouldExists = {ELIGIBILITY_SUCCESS})
    @FailureState(FAILED_SEND_OTP)
    @PostMapping("generateOtp")
    public ApiResponse<HLIConsentResponse> sendOTP(
            @JourneyName String journeyName,
            @JourneyId String journeyId){
        return communicationService.generateOTP(journeyName, journeyId);
    }

    /**
     * This method is used to validate OTP, shared by the communication service.
     *
     * @param hliValidateRequest
     * @return ApiResponse<HLIConsentResponse>
     */
    @CoolingPeriods(
            {
                    @CoolingPeriod(
                            type = CoolingPeriodType.SEND_OTP,
                            journeyName = "#journeyName",
                            identifierNames = {"loanFileNumber", "journeyName"},
                            identifierValues = {
                                    "#journeyData.journeyDetail.systemData['loanidentifydetails']['loanidentifydetails']['loanFileNumber']",
                                    "#journeyName"
                            },
                            attemptsLeftFillerField = "retryOtpAttemptsLeft",
                            attemptsConsumedFillerField = "retryOtpAttemptsConsumed",
                            incorrectAttemptCondition = "#true",
                            validationPhase = ValidationPhase.AFTER
                    ),
                    @CoolingPeriod(
                            type = CoolingPeriodType.VALIDATE_OTP,
                            journeyName = "#journeyName",
                            identifierNames = {"loanFileNumber", "journeyName"},
                            identifierValues = {
                                    "#journeyData.journeyDetail.systemData['loanidentifydetails']['loanidentifydetails']['loanFileNumber']",
                                    "#journeyName"
                            },
                            attemptsLeftFillerField = "verifyOtpAttemptsLeft",
                            attemptsConsumedFillerField = "verifyOtpAttemptsConsumed",
                            incorrectAttemptCondition = "#output.data.otpValidated",
                            validationPhase = ValidationPhase.AFTER,
                            dropOnAttemptReach = true,
                            clearCoolingPeriod = true
                    )
            }
    )
    @ValidateJourney(shouldExists = {SEND_OTP_SUCCESS})
    @FailureState(FAILED_VALIDATE_OTP)
    @PostMapping("validateOtp")
    public ApiResponse<HLIValidateResponse> validateOTP(
            @JourneyName String journeyName,
            @JourneyId String journeyId,
            @Valid @RequestBody HLIValidateRequest hliValidateRequest){
        log.info("Entered to sendOTP with validateOTP");

        return communicationService.validateCustomer(journeyName, journeyId, hliValidateRequest);
    }
}
