package com.hdfcbank.insurance.hli.process.models.mapper;


import com.hdfcbank.insurance.adapter.process.models.response.PremiumQuestionResponse;
import com.hdfcbank.insurance.hli.process.models.response.HLIFetchPricingProductDetailsResponse;
import org.mapstruct.Builder;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.ReportingPolicy;


@Mapper(componentModel = "spring", unmappedTargetPolicy = ReportingPolicy.IGNORE,
        builder = @Builder(disableBuilder = false))
public interface HLIFetchPricingProductDetailsMapper {

    HLIFetchPricingProductDetailsResponse mapToApiResponse(PremiumQuestionResponse source);

    HLIFetchPricingProductDetailsResponse.ProductWiseQuestion mapProductWiseQuestion(PremiumQuestionResponse.ProductWiseQuestion source);

    @Mapping(target = "subQuestions", ignore = true)
    HLIFetchPricingProductDetailsResponse.Question mapQuestion(PremiumQuestionResponse.ProductWiseQuestion.Question source);

    HLIFetchPricingProductDetailsResponse.Validation mapValidation(PremiumQuestionResponse.ProductWiseQuestion.Validations source);

    @Mapping(target = "option", ignore = true)
    HLIFetchPricingProductDetailsResponse.SpecialOption mapSpecialOption(PremiumQuestionResponse.ProductWiseQuestion.SpecialOption source);

}

