package com.hdfcbank.insurance.hli.common.core.models;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum HLIAPIRequestName {
    IDENTIFY("hli-identify"),
    RECOMMENDED_PRODUCT("hli-getProduct"),
    CONTENT_GROUP("hli-contentGroup"),
    GET_LOAN_DETAILS("hli-loan-details"),
    SUBMIT_ANSWER("hli-submit-answer"),
    FETCH_PRICE("hli-fetch-price"),
    PROPOSAL_QUESTION("hli-proposal-question"),
    ACTION("hli-action"),
    SEND_OTP("hli-send-otp"),
    VALIDATE_OTP("hli-validate-otp"),
    GET_KFS_DETAIL("hli-getKFSDetail"),
    INITIATE_ESIGN("hli-initiate-esign"),
    RESEND_ESIGN_LINK("hli-resend-esign-link"),
    ESIGN_STATUS("hli-esign-status"),
    FINAL_PROPOSAL_SUBMISSION("submit-final-proposal"),
    CANCEL_ELAD("cancel-lead"),
    FETCH_LGLC("Get-LGLC"),
    ;
    private final String apiName;
}