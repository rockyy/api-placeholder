package com.hdfcbank.insurance.hli.process.models;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.hdfcbank.insurance.hli.process.models.enums.BorrowerEsignStatus;
import com.hdfcbank.insurance.hli.process.models.enums.JourneyEsignStatus;
import lombok.*;

import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@JsonInclude(JsonInclude.Include.NON_NULL)
public class BorrowersEsignDetail {

    private List<BorrowerInfo> borrowersInfo;
    private JourneyEsignStatus journeyEsignStatus;
    private String docketId;
    private String documentId;
    private String responseTimeStamp;
    private String referenceDocId;
    private String error;
    private List<EsignDocumentStorageDetail> esignDocumentStorageDetail;
    private String expireAt;


    @Getter
    @Setter
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor

    @ToString
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class BorrowerInfo {
        private HLIBorrower borrower;
        private BorrowerEsignStatus borrowerEsignStatus;
        private SignerInfo signerInfo;
    }
}
