package com.hdfcbank.insurance.hli.common.exception;

public class HLIException extends RuntimeException{

    public HLIException() {
        super();
    }

    public HLIException(String message) {
        super(message);
    }
}
