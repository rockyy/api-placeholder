package com.hdfcbank.insurance.hli.process.models.mapper;

import com.hdfcbank.insurance.adapter.process.models.response.GetLoanDetailResponse;
import com.hdfcbank.insurance.hli.process.models.response.HLILoanDetailResponse;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.math.BigDecimal;
import java.util.List;

@Mapper(componentModel = "spring") // integrates with Spring DI
public interface GetDetailResponseMapper {

    Logger log = LoggerFactory.getLogger(GetDetailResponseMapper.class);

    @Mapping(target = "maxIpfLimit", source = "loanEligibility.maxLoan", qualifiedByName = "convertToLacs")
    @Mapping(target = "currency", constant = "INR")
    @Mapping(target = "customers", source = "customers")
    @Mapping(target = "loanValue", source = "loan.totalLoanAmount", qualifiedByName = "stringToBigDecimalForLoanValue")
    @Mapping(target = "loanTenure", source = "loan.loanTerm",qualifiedByName = "monthsToYearForLoanTenure")
    HLILoanDetailResponse toResponse(GetLoanDetailResponse source);

    @Mapping(target = "id", source = "number")
    @Mapping(target = "name", expression = "java(buildFullName(customer.getFirstName(), customer.getMiddleName(), customer.getLastName()))")
    @Mapping(target = "relationToBorrower", source = "relationToBorrower")
    @Mapping(target = "dateOfBirth", source = "dateOfBirth")
    @Mapping(target = "gender", source = "sex")
    @Mapping(target = "occupation", source = "employerName")
    @Mapping(target = "pan", source = "pan")
    @Mapping(target = "education", source = "education")
    @Mapping(target = "grossAnnualIncome",source = "income.grossAnnualIncome",qualifiedByName = "stringToBigDecimalForLoanValue")
    HLILoanDetailResponse.Customer toCustomer(GetLoanDetailResponse.Customer customer);

    // ------------------- Property Mapping -------------------
    @Mapping(target = "id", source = "propertyNo")
    @Mapping(target = "name", source = "name")
    HLILoanDetailResponse.Property toProperty(GetLoanDetailResponse.Property property);


    List<HLILoanDetailResponse.Customer> toCustomerList(List<GetLoanDetailResponse.Customer> customers);

    // helper method for full name concatenation
    default String buildFullName(String firstName, String middleName, String lastName) {
        StringBuilder fullName = new StringBuilder();
        if (firstName != null && !firstName.isBlank()) fullName.append(firstName).append(" ");
        if (middleName != null && !middleName.isBlank()) fullName.append(middleName).append(" ");
        if (lastName != null && !lastName.isBlank()) fullName.append(lastName);
        return fullName.toString().trim();
    }
    @Named("convertToLacs")
    default String convertToLacs(String value) {
        if (value == null || value.isBlank()) return null;
        try {
            double amount = Double.parseDouble(value);
            double lakhs = amount / 100_000.0;
            // round to 2 decimal places
            double rounded = Math.round(lakhs * 100.0) / 100.0;
            // remove trailing .0 if present
            String formatted;
            if (rounded == (long) rounded) {
                formatted = String.valueOf((long) rounded); // remove .0
            } else {
                formatted = String.valueOf(rounded); // keep up to 2 decimal places
            }
            return formatted + " lakh";
        } catch (NumberFormatException e) {
            return value; // fallback if invalid number
        }
    }

    @Named("stringToBigDecimalForLoanValue")
    default BigDecimal stringToBigDecimalForLoanValue(String loanValue) {
        if (loanValue == null || loanValue.trim().isEmpty()) {
            log.info("Loan value is null or empty");
            throw new RuntimeException("Loan value is null or empty");
        }
        try {
            return new BigDecimal(loanValue);
        } catch (NumberFormatException numberFormatException) {
            log.error("Error during loan value parsing");
            throw new IllegalArgumentException("Invalid loan tenure value: " + loanValue, numberFormatException);
        }
    }

    @Named("monthsToYearForLoanTenure")
    default Integer monthsToYearForLoanTenure(String loanTenure) {
        if (loanTenure == null || loanTenure.trim().isEmpty()) {
            log.info("Loan tenure is null");
            throw new RuntimeException("Loan Tenure is null or empty");
        }
        try {
            int years = Integer.parseInt(loanTenure);
            return years / 12;
        } catch (NumberFormatException numberFormatException) {
            log.error("Invalid loan tenure: {}", loanTenure, numberFormatException);
            throw new IllegalArgumentException("Invalid loan tenure value: " + loanTenure, numberFormatException);
        }
    }
}