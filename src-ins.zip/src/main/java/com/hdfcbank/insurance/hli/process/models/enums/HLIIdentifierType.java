package com.hdfcbank.insurance.hli.process.models.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum HLIIdentifierType {
    DOB("DOB"),LOAN("LOAN");
    final String value;
}