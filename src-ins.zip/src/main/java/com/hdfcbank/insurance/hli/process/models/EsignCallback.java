package com.hdfcbank.insurance.hli.process.models;

import com.hdfcbank.insurance.hli.process.models.mapper.HLICallbackPayload;
import lombok.*;

import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class EsignCallback implements HLICallbackPayload {
    private EsignResponse esignResponse;
    private String journeyId;
    private String esignInitiatedDate;
    private List<EsignDocumentStorageDetail> esignDocumentStorageDetail;



    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class EsignResponse {
        private String status;
        private String docketId;
        private String documentId;
        private String referenceDocId;
        private String responseTimeStamp;
        private List<SignerInfo> signerInfo;
        public String error;

    }

}
