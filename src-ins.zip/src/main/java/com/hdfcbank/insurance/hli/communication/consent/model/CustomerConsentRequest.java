package com.hdfcbank.insurance.hli.communication.consent.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;
import lombok.experimental.SuperBuilder;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@SuperBuilder
public class CustomerConsentRequest {
    @NonNull
    private String key;
    @NonNull
    @JsonProperty("acceptance")
    private boolean acceptance;

}
