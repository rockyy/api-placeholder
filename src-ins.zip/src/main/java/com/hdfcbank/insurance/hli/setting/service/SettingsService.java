package com.hdfcbank.insurance.hli.setting.service;

import tools.jackson.databind.JsonNode;
import tools.jackson.databind.ObjectMapper;
import com.hdfcbank.adapters.clients.feign.config.ConfigServiceFeignClient;
import com.hdfcbank.adapters.clients.feign.consents.ConsentsServiceFeignClient;
import com.hdfcbank.adapters.vo.FetchConsentsRequest;
import com.hdfcbank.adapters.vo.FetchConsentsResponse;
import com.hdfcbank.common.models.vo.core.ApiResponseStatus;
import com.hdfcbank.insurance.hli.setting.models.SettingsDataExtension;
import com.hdfcbank.insurance.hli.setting.models.SettingsResponse;
import com.hdfcbank.insurance.hli.setting.utility.SettingUtility;
import com.hdfcbank.insurance.hli.util.TextSanityUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import reactor.util.function.Tuples;

import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class SettingsService {

    private final ConfigServiceFeignClient configServiceFeignClient;
    private final ConsentsServiceFeignClient consentsServiceFeignClient;
    private final SettingUtility settingUtility;

    public SettingsResponse fetch(SettingsDataExtension settingsDataExtension, String journeyName) {
        log.info("Getting settings from server for label: {} and extension: {}", TextSanityUtil.sanitize(journeyName), TextSanityUtil.sanitize(settingsDataExtension.name()));
        if (settingUtility.mergeConfigAndConsents(null, journeyName) == null) {
            settingUtility.evictCache(journeyName);
            List<FetchConsentsResponse.Consent> consentsResponse = consentsServiceFeignClient.fetchConsentsByJourneyName(
                    FetchConsentsRequest.builder().journeyName(journeyName).build()
            );
            Object configResponse = settingsDataExtension.getParser().apply(
                    configServiceFeignClient.getData(journeyName, settingsDataExtension.name())
            );
            JsonNode configNode = (JsonNode) configResponse;
            JsonNode consentsNode = new ObjectMapper().valueToTree(consentsResponse);
            return SettingsResponse.builder()
                    .status(ApiResponseStatus.success())
                    .data(settingUtility.mergeConfigAndConsents(Tuples.of(configNode, consentsNode), journeyName))
                    .build();
        }
        else {
            return SettingsResponse.builder()
                    .status(ApiResponseStatus.success())
                    .data(settingUtility.mergeConfigAndConsents(null, journeyName))
                    .build();
        }
    }
}
