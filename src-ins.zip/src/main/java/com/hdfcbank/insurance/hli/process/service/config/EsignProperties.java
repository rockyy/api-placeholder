package com.hdfcbank.insurance.hli.process.service.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

@Data
@Component
@ConfigurationProperties(prefix = "esign")
public class EsignProperties {
    private ExceptionMessage exceptionMessage;
    private int expiry;

    @Data
    public static class ExceptionMessage{
        private Popup popup;
        private Map<String, List<FieldDetail>> fieldsDetail;
    }

    @Data
    public static class Popup {
        private String fullScreen;
    }

    @Data
    public static class FieldDetail {
        private String type;
        private String code;
        private String messageHeading;
        private String message;
    }
}