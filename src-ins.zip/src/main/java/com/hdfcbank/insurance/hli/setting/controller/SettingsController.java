package com.hdfcbank.insurance.hli.setting.controller;

import com.hdfcbank.insurance.hli.setting.models.SettingsRequest;
import com.hdfcbank.insurance.hli.setting.models.SettingsDataExtension;
import com.hdfcbank.insurance.hli.setting.models.SettingsResponse;
import com.hdfcbank.insurance.hli.setting.service.SettingsService;
import com.hdfcbank.insurance.hli.util.TextSanityUtil;
import com.hdfcbank.starter.logging.annotations.JourneyName;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("${app.base-path}")
@RequiredArgsConstructor
@Slf4j
public class SettingsController {
    private final SettingsService settingsService;

    @PostMapping("/settings")
    public SettingsResponse fetch(@Valid @RequestBody SettingsRequest request,@JourneyName String journeyName) {
        log.info("Inside settings controller :: {}", TextSanityUtil.sanitize(journeyName));
        SettingsDataExtension settingsDataExtension = SettingsDataExtension.valueOf(request.getExtension());
        return settingsService.fetch(settingsDataExtension, journeyName);
    }
}
