package com.hdfcbank.insurance.hli.process.annotations;


import com.hdfcbank.insurance.hli.process.validators.HLIFetchPricingValidator;
import jakarta.validation.Constraint;
import jakarta.validation.Payload;

import java.lang.annotation.*;


@Documented
@Constraint(validatedBy = HLIFetchPricingValidator.class)
@Target({ ElementType.TYPE })
@Retention(RetentionPolicy.RUNTIME)
public @interface ValidHLIFetchPricing {
    String message() default "HLIFetchPricing object is invalid";

    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};
}
