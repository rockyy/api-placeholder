package com.hdfcbank.insurance.hli.process.models.response;
import com.hdfcbank.insurance.adapter.process.models.response.ProposalQuestionResponse;
import com.hdfcbank.insurance.hli.process.models.HLIBorrower;
import lombok.*;

import java.util.List;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class HLIProposalQuestionResponse {

    private List<HLIBorrowerWrapper> borrowers;
    private String lGCode;

    // ================= Borrower Wrapper =================
    @Getter
    @Setter
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    @ToString
    public static class HLIBorrowerWrapper {
        private HLIBorrower borrower;
        private List<HLIProductQuestionsAndNominee> products;
    }

    // ================= Product =================
    @Getter
    @Setter
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    @ToString
    public static class HLIProductQuestionsAndNominee {
        private String code;
        private String name;
        private String type;
        private String quoteId;
        private HLINominee nominee;
        private List<ProposalQuestionResponse.Question> productQuestions;
    }

    // ================= Nominee =================
    @Getter
    @Setter
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    @ToString
    public static class HLINominee {
        private List<HLIBorrower> options;
    }
}