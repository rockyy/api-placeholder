package com.hdfcbank.insurance.hli.communication.otp.models.request;


import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.*;

import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@ToString
public class HLIValidateRequest {
    @NotNull
    private String otp;
    @NotNull
    private String txnRef;
    @NotEmpty
    private List<LogInConsentData> logInConsentData;

    @Getter
    @Setter
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    @ToString
    public static class LogInConsentData{
        @NotNull
        private String consentKey;
        @NotNull
        private Boolean consentAccepted;
    }
}
