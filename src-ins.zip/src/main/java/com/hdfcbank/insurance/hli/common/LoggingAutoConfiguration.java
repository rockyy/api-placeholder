package com.hdfcbank.insurance.hli.common;

import com.hdfcbank.starter.logging.helpers.LogHelper;
import com.hdfcbank.starter.logging.helpers.LogMaskingHelper;
import com.hdfcbank.starter.logging.properties.LoggingProperties;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class LoggingAutoConfiguration {

    @Bean
    @ConditionalOnMissingBean
    public LogHelper logHelper(LogMaskingHelper logMaskingHelper, LoggingProperties loggingProperties) {
        return new LogHelper(logMaskingHelper, loggingProperties);
    }
}
