package com.hdfcbank.insurance.hli.process.models.request;

import jakarta.validation.constraints.NotEmpty;
import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ResendESignResponse {

    private String status;
    private String message;
}
