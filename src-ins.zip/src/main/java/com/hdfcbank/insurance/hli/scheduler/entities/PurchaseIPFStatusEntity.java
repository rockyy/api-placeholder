package com.hdfcbank.insurance.hli.scheduler.entities;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.hdfcbank.insurance.adapter.process.models.response.IPFStatusResponse;
import com.hdfcbank.insurance.hli.process.models.SubmitFinalProposalCallback;
import com.hdfcbank.insurance.hli.scheduler.model.IPFStatus;
import com.hdfcbank.insurance.hli.scheduler.model.Status;
import lombok.*;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.Instant;
import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Document(collection = "purchase")
@JsonIgnoreProperties(ignoreUnknown = true)
@ToString
public class PurchaseIPFStatusEntity {

    @Id
    @JsonProperty("_id")
    private String id;

    @JsonProperty("journeyName")
    private String journeyName;

    @JsonProperty("purchaseStatus")
    private Status purchaseStatus;

    @JsonProperty("ipfStatus")
    private String ipfStatus;

    @JsonProperty("ipfStatusHistory")
    private List<IPFStatusHistory> ipfStatusHistory;

    @JsonProperty("productPurchaseRequest")
    private SubmitFinalProposalCallback.SubmitILPSProposalResponse productPurchaseRequest;

    @JsonProperty("purchaseResponse")
    private IPFStatusResponse purchaseResponse;

    @JsonProperty("processType")
    private String processType;

    @JsonProperty("createdDate")
    private Instant createdDate;

    @JsonProperty("modifiedDate")
    private Instant modifiedDate;

    @JsonProperty("retryCount")
    private Integer retryCount;

    @JsonProperty(value = "_class")
    private String clazz;

    // -------------------- NESTED CLASS --------------------

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class IPFStatusHistory implements Comparable<IPFStatusHistory> {

        @JsonProperty("oldStatus")
        private IPFStatus oldStatus;

        @JsonProperty("newStatus")
        private IPFStatus newStatus;

        @JsonProperty("lastModified")
        private Instant lastModified;

        @Override
        public int compareTo(IPFStatusHistory other) {
            return this.lastModified.compareTo(other.lastModified);
        }
    }
}
