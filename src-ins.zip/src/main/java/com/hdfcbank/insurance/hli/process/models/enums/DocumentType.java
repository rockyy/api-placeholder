package com.hdfcbank.insurance.hli.process.models.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum DocumentType {
    KFS,MIF,MID;
}