package com.hdfcbank.insurance.hli.common.config;

import com.hdfcbank.insurance.hli.common.properties.HLIExecutorProperties;
import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import java.util.concurrent.Executor;

@Configuration
@EnableAsync
@RequiredArgsConstructor
public class HLIExecutorConfiguration {

    private final HLIExecutorProperties hliExecutorProperties;

    /**
     * This method having logic to create bean configuration for Executor service.
     *
     * @return Executor
     */
    @Bean("taskExecutor")
    public Executor taskExecutor() {
        ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
        executor.setCorePoolSize(hliExecutorProperties.getPoolSize());
        executor.setMaxPoolSize(hliExecutorProperties.getMaxPoolSize());
        executor.setQueueCapacity(hliExecutorProperties.getQueueCapacity());
        executor.setThreadNamePrefix(hliExecutorProperties.getThreadNamePrefix());
        executor.initialize();
        return executor;
    }
}
