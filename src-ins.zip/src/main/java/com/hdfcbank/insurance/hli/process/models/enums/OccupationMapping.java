package com.hdfcbank.insurance.hli.process.models.enums;

import lombok.Getter;

import java.util.Arrays;
import java.util.Locale;

@Getter
public enum OccupationMapping {

    EMPLOYED("Salaried"),
    SELF_EMPLOYED("Self Employee"),
    STUDENT("Others"),
    HOME_MAKER("Others"),
    RETIRED("Others"),
    PENSIONER("Others"),
    UN_EMPLOYED("Others");

    private final String mappedValue;

    OccupationMapping(String mappedValue) {
        this.mappedValue = mappedValue;
    }

    /**
     * Converts string input to enum safely and returns mapped value.
     */
    public static String getMappedValue(String input) {
        if (input == null) {
            return "Others";
        }

        String normalized = input.toUpperCase(Locale.ROOT).replace(" ", "_");

        return Arrays.stream(OccupationMapping.values())
                .filter(e -> normalized.equals(e.name()))
                .findFirst()
                .map(OccupationMapping::getMappedValue)
                .orElse("Others");
    }
}