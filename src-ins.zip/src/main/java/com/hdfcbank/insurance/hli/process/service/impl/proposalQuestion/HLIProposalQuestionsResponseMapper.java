package com.hdfcbank.insurance.hli.process.service.impl.proposalQuestion;

import com.hdfcbank.common.models.vo.journey.JourneyDetail;
import com.hdfcbank.insurance.adapter.process.models.response.GetLoanDetailResponse;
import com.hdfcbank.insurance.adapter.process.models.response.PricingResponse;
import com.hdfcbank.insurance.adapter.process.models.response.ProposalQuestionResponse;
import com.hdfcbank.insurance.hli.process.models.response.HLIProposalQuestionResponse;
import com.hdfcbank.insurance.hli.util.JourneyUtil;
import lombok.experimental.UtilityClass;
import lombok.extern.slf4j.Slf4j;

import java.util.*;

@Slf4j
@UtilityClass
public class HLIProposalQuestionsResponseMapper {

    public static HLIProposalQuestionResponse getHliProposalQuestionResponse(
            JourneyDetail journeyDetail, ProposalQuestionResponse processLayerProposalQuestionResponse, PricingResponse pricingResponse
    ) {
        HLIProposalQuestionResponse hliProposalQuestionResponse = new HLIProposalQuestionResponse();
        List<GetLoanDetailResponse.Customer> borrowerList = BorrowerUtility.getListOfBorrower(journeyDetail);
        String propNumber = String.valueOf(JourneyUtil.getByPath(journeyDetail.getSystemData(), "getLoanDetail.property.propertyNo"));
        List<HLIProposalQuestionResponse.HLIBorrowerWrapper> borrowerWrappers = new ArrayList<>();
        Map<String, Integer> order = Map.of(
                "B", 1,
                "C", 2
        );
        borrowerList.sort(Comparator.comparing(b -> order.getOrDefault(b.getCapacity(), 99)));
        borrowerList.forEach(selectedBorrower -> {
            List<GetLoanDetailResponse.Customer> nomineeList =
                    BorrowerUtility.getListOfNomineeForBorrower(borrowerList, selectedBorrower);

            HLIProposalQuestionResponse.HLIBorrowerWrapper hliBorrowerWrapper = HLIProposalQuestionResponse.HLIBorrowerWrapper.builder()
                    .borrower(BorrowerUtility.mapCustomerToBorrower(selectedBorrower))
                    .build();
            List<HLIProposalQuestionResponse.HLIProductQuestionsAndNominee> productQuestionsAndNominees = getHliProductQuestionsAndNominees(processLayerProposalQuestionResponse, pricingResponse, selectedBorrower, propNumber, nomineeList);
            if(!productQuestionsAndNominees.isEmpty()){
                hliBorrowerWrapper.setProducts(productQuestionsAndNominees);
                borrowerWrappers.add(hliBorrowerWrapper);
                hliProposalQuestionResponse.setBorrowers(borrowerWrappers);
            }
        });
        return hliProposalQuestionResponse;
    }

    private static List<HLIProposalQuestionResponse.HLIProductQuestionsAndNominee> getHliProductQuestionsAndNominees(ProposalQuestionResponse processLayerProposalQuestionResponse, PricingResponse pricingResponse, GetLoanDetailResponse.Customer selectedBorrower, String propNumber, List<GetLoanDetailResponse.Customer> nomineeList) {
        return processLayerProposalQuestionResponse.getProductWiseQuestions().stream()
                .map(productWiseQuestions -> {
                    List<ProposalQuestionResponse.Question> questionListForBorrower =
                            productWiseQuestions.getQuestions().stream()
                                    .filter(q -> q.getEntityId().equals(selectedBorrower.getNumber()) || (q.getEntityId().equals(propNumber) && selectedBorrower.getCapacity().equals("B")))
                                    .toList();
                    if (!questionListForBorrower.isEmpty()) {
                        return HLIProposalQuestionResponse.HLIProductQuestionsAndNominee.builder()
                                .code(productWiseQuestions.getCode())
                                .quoteId(mapQuoteId(selectedBorrower, productWiseQuestions, pricingResponse))
                                .nominee(NomineeUtility.getProposalNominee(nomineeList))
                                .name(productWiseQuestions.getCode())
                                .productQuestions(questionListForBorrower)
                                .build();
                    }
                    return null;
                })
                .filter(Objects::nonNull)
                .toList();
    }

    private static String mapQuoteId(GetLoanDetailResponse.Customer selectedBorrower, ProposalQuestionResponse.ProductWiseQuestions productWiseQuestions, PricingResponse pricingResponse) {
        Optional<PricingResponse.Quote> optionalQuote = pricingResponse.getQuotes().stream().filter(quote -> quote.getEntityId().equals(selectedBorrower.getNumber()) && quote.getProductCode().equals(productWiseQuestions.getCode())).findAny();
        if (optionalQuote.isPresent()) {
            return optionalQuote.get().getQuoteId();
        } else {
            return pricingResponse.getQuotes().stream().filter(quote -> quote.getProductCode().equals(productWiseQuestions.getCode())).findAny().get().getQuoteId();
        }
    }

}
