package com.hdfcbank.insurance.hli.process.service;

import com.hdfcbank.common.models.vo.core.ApiResponse;
import com.hdfcbank.insurance.adapter.process.models.response.KFSDetailResponse;
import com.hdfcbank.insurance.adapter.process.models.response.SubmitFinalProposalResponse;
import com.hdfcbank.insurance.hli.process.models.EsignResponse;
import com.hdfcbank.insurance.hli.process.models.request.HLIIdentifyRequest;
import com.hdfcbank.insurance.hli.process.models.request.ResendESignRequest;
import com.hdfcbank.insurance.hli.process.models.request.ResendESignResponse;
import com.hdfcbank.insurance.hli.process.models.response.HLIIdentifyResponse;
import com.hdfcbank.insurance.hli.process.models.response.HLILoanDetailResponse;


public interface HLIDetailService {
    ApiResponse<HLIIdentifyResponse> identify(String journeyName,String journeyId, HLIIdentifyRequest loanIdentifyRequest);

    ApiResponse<HLILoanDetailResponse> fetchLoanDetail();

    void cancelAllJourneys();

    ApiResponse<KFSDetailResponse> fetchKFSDetail();

    ApiResponse<EsignResponse> initiateEsign();

    ApiResponse<EsignResponse> esignStatus();

    ApiResponse<ResendESignResponse> resendESignLink(ResendESignRequest request);

    ApiResponse<SubmitFinalProposalResponse> submitFinalProposal();
}
