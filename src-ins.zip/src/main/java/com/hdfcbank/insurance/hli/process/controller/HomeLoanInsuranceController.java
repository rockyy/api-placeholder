package com.hdfcbank.insurance.hli.process.controller;

import com.hdfcbank.common.models.vo.core.ApiResponse;
import com.hdfcbank.insurance.adapter.process.models.response.*;
import com.hdfcbank.insurance.hli.common.annotation.FailureState;
import com.hdfcbank.insurance.hli.common.annotation.ValidateJourney;
import com.hdfcbank.insurance.hli.common.enums.JourneyStateName;
import com.hdfcbank.insurance.hli.process.models.EsignResponse;
import com.hdfcbank.insurance.hli.process.models.request.*;
import com.hdfcbank.insurance.hli.process.models.response.*;
import com.hdfcbank.insurance.hli.process.service.CallbackService;
import com.hdfcbank.insurance.hli.process.service.HLIDetailService;
import com.hdfcbank.insurance.hli.process.service.HLIProductService;
import com.hdfcbank.insurance.hli.process.service.impl.HLIPricingImpl;
import com.hdfcbank.insurance.hli.process.service.impl.HLIQuestionServiceImpl;
import com.hdfcbank.insurance.hli.scheduler.IPFSchedulerService;
import com.hdfcbank.insurance.hli.scheduler.entities.PurchaseIPFStatusEntity;
import com.hdfcbank.insurance.hli.util.TextSanityUtil;
import com.hdfcbank.starter.logging.annotations.JourneyId;
import com.hdfcbank.starter.logging.annotations.JourneyName;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

import static com.hdfcbank.insurance.hli.common.enums.JourneyStateName.*;

@Slf4j
@RestController
@RequiredArgsConstructor
@RequestMapping("${app.base-path}")
@Tag(name = "Home Loan Insurance API", description = "Endpoints for Home Loan Insurance Operations")
public class HomeLoanInsuranceController {

    private final HLIDetailService hliService;
    private final HLIProductService hliProductService;
    private final HLIPricingImpl fetchPricing;
    private final HLIQuestionServiceImpl questionService;
    private final CallbackService callbackService;
    private final IPFSchedulerService schedulerService;

    /**
     * This method is used to identify the loan.
     *
     * @param loanIdentifyRequest
     * @return ApiResponse<HLIIdentifyResponse>
     */
    @FailureState(FAILED_ELIGIBILITY)
    @PostMapping("identify")
    public ApiResponse<HLIIdentifyResponse> identify(@JourneyName String journeyName, @JourneyId String journeyId, @Valid @RequestBody HLIIdentifyRequest loanIdentifyRequest) {
        log.info("Entered to identify");
        return hliService.identify(journeyName,journeyId,loanIdentifyRequest);
    }

    /**
     * This method will process the request to get loan details
     *
     * @return ApiResponse<GetDetailResponse>
     */
    @ValidateJourney(shouldExists = {VALIDATE_OTP_SUCCESS})
    @FailureState(FAILED_GET_DETAIL)
    @PostMapping("getDetail")
    public ApiResponse<HLILoanDetailResponse> getLoanDetails() {
        log.info("Entered to getLoanDetails ");
        return hliService.fetchLoanDetail();
    }

    /**
     * This method will process the request to get loan details
     *
     * @return ApiResponse<GetDetailResponse>
     */
    @ValidateJourney(shouldExists = {VALIDATE_OTP_SUCCESS})
    @FailureState(FAILED_CANCEL_PREVOUS_JOURNEY)
    @PostMapping("cancelPreviousJourneys")
    public ApiResponse<HLILoanDetailResponse> cancelPreviousJourneys() {
        log.info("Entered to cancelPreviousJourneys");
        hliService.cancelAllJourneys();
        return hliService.fetchLoanDetail();
    }

    /**
     * This end point will process the request for get product.
     *
     * @return ApiResponse<HLIRecommendedProductResponse>
     */
    @ValidateJourney(shouldExists = {GET_DETAIL_SUCCESS})
    @FailureState(FAILED_RECOMMENDED_PRODUCT)
    @PostMapping("getProducts")
    public ApiResponse<HLIRecommendedProductResponse> getRecommendedProduct(){
        log.info("Entered to get recommended product");
        return hliProductService.getRecommendedProducts();
    }

    /**
     * This end point will process the request for get product.
     *
     * @return ApiResponse<HLIRecommendedProductResponse>
     */
    @ValidateJourney(shouldExists = {GET_DETAIL_SUCCESS})
    @FailureState(FAILED_RECOMMENDED_PRODUCT)
    @PostMapping("getInsuranceProducts")
    public ApiResponse<RecommendedProductResponse> getInsuranceProducts(){
        log.info("Entered to get insurance product");
        return hliProductService.getInsuranceProducts();
    }

    /**
     * This method will process the request for curate product.
     *
     * @return ApiResponse<HLICurateProductResponse>
     */
    @ValidateJourney(shouldExists = {GET_DETAIL_SUCCESS})
    @FailureState(FAILED_RECOMMENDED_PRODUCT)
    @PostMapping("fetchCatalog")
    public ApiResponse<HLICurateProductResponse> getCurateProduct() {
        log.info("Entered to get curate product ");
        return hliProductService.getCurateProducts();
    }

    /**
     * Endpoints that will process the request to get premium products
     *
     * @return ApiResponse<HLIFetchPricingResponse>
     */
    @ValidateJourney(shouldExists = {RECOMMENDED_PRODUCT_SUCCESS})
    @FailureState(FAILED_FETCH_PRICING)
    @PostMapping("fetchPrice")
    public ApiResponse<HLIFetchPricingResponse> fetchPricing(@Valid @RequestBody HLIFetchPricingRequest hliFetchPricingRequest) {
        log.info("Entered to get pricing with journeyId ");
        return fetchPricing.fetchPricing(hliFetchPricingRequest);
    }

    /**
     * Endpoints that will process the request to get premium products
     *
     * @return ApiResponse<HLIPremiumQuestionResponse>
     */
    @ValidateJourney(shouldExists = {FETCH_PRICING_SUCCESS})
    @FailureState(FAILED_PROPOSAL_QUESTION)
    @PostMapping("product/fetchProposalQuestions")
    public ApiResponse<HLIProposalQuestionResponse> getProposalQuestions() {
        log.info("Entered to get proposal questions with journeyId");
        return questionService.getProposalQuestions();
    }

    /**
     * Endpoints that will process the request to get premium products
     *
     * @param hliSubmitAnswerRequest
     * @return ApiResponse<HLIPremiumQuestionResponse>
     */
    @ValidateJourney(shouldExists = {PROPOSAL_QUESTION_SUCCESS})
    @FailureState(FAILED_PROPOSAL_SUBMIT)
    @PostMapping("product/submitAnswer")
    public ApiResponse<HLISubmitAnswerResponse> submitProposal(@Valid @RequestBody HLISubmitAnswerRequest hliSubmitAnswerRequest) {
        log.info("Entered to submitProposal");
        return questionService.submitProposal(hliSubmitAnswerRequest);
    }

    /**
     * This method will process the request to get loan details
     *
     * @return ApiResponse<GetDetailResponse>
     */
    @ValidateJourney(shouldExists = {PROPOSAL_SUBMIT_SUCCESS})
    @FailureState(FAILED_KFS_FETCH)
    @PostMapping("getKFSDetail")
    public ApiResponse<KFSDetailResponse> getKFSDetails() {
        log.info("Entered to getKFSDetails ");
        return hliService.fetchKFSDetail();
    }

    @ValidateJourney(shouldExists = {KFS_FETCH_SUCCESS})
    @FailureState(FAILED_ESIGN)
    @PostMapping("esign/initiate")
    public ApiResponse<EsignResponse> initiateEsign() {
        log.info("Entered to initiate e-sign");
        return hliService.initiateEsign();
    }

    @ValidateJourney(shouldExists = {ESIGN_INITIATED})
    @FailureState(FAILED_ESIGN_STATUS_CHECK)
    @PostMapping("esign/status")
    public ApiResponse<EsignResponse> esignStatus() {
        log.info("Entered to status of e-sign");
        return hliService.esignStatus();
    }

    @ValidateJourney(shouldExists = {ESIGN_INITIATED})
    @FailureState(FAILED_ESIGN_RESEND_LINK)
    @PostMapping("esign/resendLink")
    public ApiResponse<ResendESignResponse> resendESignLInk(@RequestBody ResendESignRequest request) {
        log.info("Entered to resend link of e-sign");
        return hliService.resendESignLink(request);
    }

    @ValidateJourney(hasAny = {ESIGN_STATUS_CHECK_SUCCESS,ESIGN_STATUS_CALLBACK_RECEIVED,ESIGN_INITIATE_CALLBACK_RECEIVED})
    @FailureState(FAILED_SUBMIT_FINAL_PROPOSAL)
    @PostMapping("submitFinalProposal")
    public ApiResponse<SubmitFinalProposalResponse> submitFinalProposal() {
        log.info("Entered to submit final proposal...");
        return hliService.submitFinalProposal();
    }

    @FailureState(FAILED_ACTIONS_API)
    @PostMapping("actions")
    public ApiResponse<CallbackResponse> executeAction(@RequestBody CallbackRequest request) {
        log.info("Entered to execute action : {}", TextSanityUtil.sanitize(request.getCallbackType().toString()));
        return callbackService.performAction(request);
    }

    @ValidateJourney(shouldExists = {GET_DETAIL_SUCCESS})
    @FailureState(FAILED_FETCH_PRICING_QUESTIONS)
    @PostMapping("fetchPriceQuestions")
    public ApiResponse<PremiumQuestionResponse> fetchPricingDetails(@Valid @RequestBody HLIFetchPricingDetailsRequest hliFetchPricingDetailsRequest) {
        log.info("Entered to get pricing details with journeyId ");
        return fetchPricing.fetchPricingDetails(hliFetchPricingDetailsRequest);
    }

    /**
     * Remove below method when integration testing is done for IPS Status Scheduler
     * @return
     */
    @FailureState(FAILED_IPF_SCHEDULER)
    @PostMapping("callIPFScheduler")
    public ApiResponse<String> executeIPFScheduler( @RequestBody List<PurchaseIPFStatusEntity> list) {
        log.info("Scheduler started");
        schedulerService.processRecords(list);
        return ApiResponse.success("Run successfully");
    }

    @ValidateJourney(shouldExists = {FETCH_PRICING_SUCCESS})
    @FailureState(FAILED_LGLC_FETCH)
    @PostMapping("getLgLcDetails")
    public ApiResponse<LGLCResponse> fetchLgLcDetails(@RequestBody(required = false) HLILGLCRequest request){
        return questionService.fetchLgLcDetails(request);
    }
}
