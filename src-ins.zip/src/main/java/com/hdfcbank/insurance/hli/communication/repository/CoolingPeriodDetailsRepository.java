package com.hdfcbank.insurance.hli.communication.repository;

import com.hdfcbank.insurance.hli.communication.entity.CoolingPeriodDetailsEntity;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.data.mongodb.repository.Update;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.Map;

@Repository
public interface CoolingPeriodDetailsRepository extends MongoRepository<CoolingPeriodDetailsEntity, Map<String, String>> {
    @Query("{'_id' : :#{#id}}")
    @Update("{'$set': {'modifiedDate': :#{#modifiedDate},'noOfAttempts': :#{#noOfAttempts}, 'expireAt': :#{#expireAt} }}")
    Long updateAttempts(@Param("id") Map<String, String> id, @Param("modifiedDate") Date modifiedDate, @Param("noOfAttempts") int noOfAttempts, @Param("expireAt") Date expireAt);

    @Query(value = "{ '_id.journeyName': ?#{#id['journeyName']}, " +
            "  '_id.coolingPeriodType': ?#{#id['coolingPeriodType']}, " +
            "  '_id.loanFileNumber': ?#{#id['loanFileNumber']} }", delete = true)
    void deleteByMapId(@Param("id") Map<String, String> id);
}
