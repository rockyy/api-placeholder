package com.hdfcbank.insurance.hli.process.models.mapper;

import com.hdfcbank.insurance.adapter.process.models.request.PremiumQuestionRequest;
import com.hdfcbank.insurance.adapter.process.models.response.PremiumQuestionResponse;
import com.hdfcbank.insurance.hli.process.models.request.HLIPremiumQuestionRequest;
import com.hdfcbank.insurance.hli.process.models.response.HLIPremiumQuestionResponse;
import lombok.experimental.UtilityClass;
import lombok.extern.slf4j.Slf4j;

import java.util.Collections;
import java.util.List;
import java.util.Optional;

@Slf4j
@UtilityClass
public class PremiumQuestionMapper {

    /**
     * This method is having logic to perform mapping to prepare process API request object.
     *
     * @param leadId
     * @param hliPremiumQuestionRequest
     * @return PremiumQuestionRequest
     */
    public static PremiumQuestionRequest toPremiumQuestionRequestMapper(String leadId, HLIPremiumQuestionRequest hliPremiumQuestionRequest) {
        return PremiumQuestionRequest.builder().leadId(leadId)
                .selectedProducts(hliPremiumQuestionRequest.getSelectedProducts().stream().map(selectedProduct ->
                        PremiumQuestionRequest.SelectedProduct.builder()
                                .code(selectedProduct.getCode()).entityIds(selectedProduct.getEntityIds()).build()).toList()).build();
    }


    /**
     * This method contains mapping logic for BFF response.
     *
     * @param leadId
     * @param premiumQuestionResponse
     * @return HLIPremiumQuestionResponse
     */
    public static HLIPremiumQuestionResponse toHLIPremiumQuestionResponseMapping(String leadId, PremiumQuestionResponse premiumQuestionResponse) {
        return HLIPremiumQuestionResponse.builder().genericQuestions(genericQuestionList(premiumQuestionResponse.getGenericQuestions())).
                productWiseQuestions(productWiseQuestionList(leadId,premiumQuestionResponse)).build();

    }

    /**
     * This method will perform mapping of generic question for BFF response.
     *
     * @param genericQuestions
     * @return List<HLIPremiumQuestionResponse.GenericQuestion>
     */
    private static List<HLIPremiumQuestionResponse.GenericQuestion> genericQuestionList(List<PremiumQuestionResponse.GenericQuestion> genericQuestions) {
        return Optional.ofNullable(genericQuestions).orElseGet(Collections::emptyList).stream().map(genericQuestion -> HLIPremiumQuestionResponse.GenericQuestion.builder()
                .questionKey(genericQuestion.getQuestionKey()).question(genericQuestion.getQuestion())
                .options(genericQuestion.getOptions()).sequence(genericQuestion.getSequence())
                .validations(Optional.ofNullable(genericQuestion.getValidations()).map(validation -> HLIPremiumQuestionResponse.Validation.builder()
                        .validationMessage(validation.getValidationMessage())
                        .validationType(validation.getValidationType())
                        .validationValue(validation.getValidationValue()).build()).orElse(null))
                .isMandatory(genericQuestion.getIsMandatory()).question(genericQuestion.getQuestion())
                .questionKey(genericQuestion.getQuestionKey()).build()).toList();
    }


    /**
     * This method will perform mapping of product wise question for BFF response.
     *
     * @param leadId
     * @param premiumQuestionResponse
     * @return List<HLIPremiumQuestionResponse.ProductWiseQuestion>
     */
    private static List<HLIPremiumQuestionResponse.ProductWiseQuestion> productWiseQuestionList(String leadId,PremiumQuestionResponse premiumQuestionResponse) {
        return Optional.ofNullable(premiumQuestionResponse.getProductWiseQuestions()).orElseGet(Collections::emptyList).stream()
                .map(productWiseQuestion -> HLIPremiumQuestionResponse.ProductWiseQuestion.builder()
                        .code(productWiseQuestion.getCode()).quoteId(leadId)
                        .questions(Optional.ofNullable(productWiseQuestion.getQuestions()).orElseGet(Collections::emptyList).stream().map(question ->
                                HLIPremiumQuestionResponse.Question.builder().questionType(question.getQuestion()).questionKey(question.getQuestionKey())
                                        .options(question.getOptions()).validations(productwiseValidation(question.getValidations()))
                                        .valueType(question.getValueType()).sequence(question.getSequence()).isMandatory(question.isMandatory()).build()).toList()).build()).toList();
    }

    /**
     * This method will perform product wise validation mapping for BFF response.
     *
     * @param validations
     * @return HLIPremiumQuestionResponse.Validation
     */
    private static HLIPremiumQuestionResponse.Validation productwiseValidation(PremiumQuestionResponse.ProductWiseQuestion.Validations validations) {
        return Optional.ofNullable(validations).map(productValidation -> HLIPremiumQuestionResponse.Validation.builder().validationValue(productValidation.getValidationValue())
                .validationMessage(productValidation.getValidationMessage()).validationValue(productValidation.getValidationValue()).build()).orElseGet(()->HLIPremiumQuestionResponse.Validation.builder().build());

    }
}
