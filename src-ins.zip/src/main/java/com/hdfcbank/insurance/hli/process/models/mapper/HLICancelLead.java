package com.hdfcbank.insurance.hli.process.models.mapper;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class HLICancelLead implements HLICallbackPayload {
    private String leadId;
    private String loanFileNumber;
}
