package com.hdfcbank.insurance.hli.scheduler;

import com.hdfcbank.job.scheduler.common.model.ExecutionStatus;
import com.hdfcbank.job.scheduler.common.model.JobSchedule;
import com.hdfcbank.job.scheduler.common.service.DistributedSchedulingExecutionService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Slf4j
@Service
@Primary
@AllArgsConstructor
public class IPFStatusScheduler implements DistributedSchedulingExecutionService {
    private final IPFSchedulerService ipfSchedulerService;
    @Override
    public ExecutionStatus execute(JobSchedule jobSchedule) {
        log.info("Scheduler Started For HLI Insurance -->> "+ LocalDateTime.now());
        ipfSchedulerService.processRecords(List.of());
        log.info("Scheduler Ended For HLI Insurance-->> "+ LocalDateTime.now());
        return ExecutionStatus.COMPLETED;
    }
}
