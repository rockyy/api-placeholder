package com.hdfcbank.insurance.hli.util;

//import tools.jackson.databind.JsonNode;
//import tools.jackson.databind.ObjectMapper;
import com.hdfcbank.adapters.clients.feign.journey.JourneyServiceFeignClient;
import com.hdfcbank.adapters.vo.UpdateSystemDataJourneyRequest;
import com.hdfcbank.common.models.constant.CommonApiStatusCodes;
import com.hdfcbank.common.models.vo.core.ErrorRef;
import com.hdfcbank.common.models.vo.journey.JourneyData;
import com.hdfcbank.common.models.vo.journey.JourneyDetail;
import com.hdfcbank.common.models.vo.journey.JourneyDetailsDataType;
import com.hdfcbank.common.models.vo.journey.Profile;
import com.hdfcbank.exception.BusinessValidationException;
import com.hdfcbank.insurance.hli.common.constant.HLICommonConstants;
import com.hdfcbank.insurance.hli.common.enums.JourneyStateName;
import com.hdfcbank.insurance.hli.process.models.response.HLIIdentifyResponse;
import com.hdfcbank.insurance.hli.process.models.response.HLILGLCResponse;
import com.hdfcbank.insurance.hli.process.service.impl.ProcessServiceCall;
import lombok.experimental.UtilityClass;
import lombok.extern.slf4j.Slf4j;
import tools.jackson.databind.JsonNode;
import tools.jackson.databind.ObjectMapper;

import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@UtilityClass
@Slf4j
public class JourneyUtil {

    public static final String DEAFULT_MOBILE = "0000000000";
    private static final Pattern SIMPLE_FILTER = Pattern.compile("@\\.([a-zA-Z0-9_]+)=='([^']*)'");

    /**
     * This method is used to perform mapping for Journey save request.
     *
     * @param journeyId
     * @param pageName
     * @param hliIdentifyResponse
     * @param journeyStateName
     * @param journeyName
     * @param refNumber
     * @return JourneyData
     */
    public JourneyData toSaveJourneyDataRequest(String journeyId, String pageName, HLIIdentifyResponse hliIdentifyResponse, JourneyStateName journeyStateName, String journeyName, String refNumber) {
        Map<String, Object> dataMap = new HashMap<>();
        dataMap.put(pageName, hliIdentifyResponse);
        Map<String, Map<String, ?>> systemDataMap = new HashMap<>();
        systemDataMap.put(pageName, dataMap);
        return JourneyData.builder().referenceNo(refNumber).mobileNumber(Objects.isNull(hliIdentifyResponse.getBorrowerMobile()) ? DEAFULT_MOBILE : hliIdentifyResponse.getBorrowerMobile()).journeyId(journeyId)
                .journeyName(journeyName).profile(Profile.builder()
                        .customerFullName(hliIdentifyResponse.getBorrowerFirstName())
                        .mobileNumber(hliIdentifyResponse.getBorrowerMobile())
                        .dateOfBirth(hliIdentifyResponse.getBorrowerDob()).build())
                .journeyDetail(JourneyDetail.builder().journeyState(JourneyStateMapper.toJourneyState(journeyStateName.name()))
                        .systemData(systemDataMap).build()).createdOn(new Date()).updatedOn(new Date()).build();
    }


    /**
     * This method is used to perform mapping for Journey update request.
     *
     * @param journeyId
     * @param pageName
     * @param data
     * @param journeyStateName
     * @return UpdateSystemDataJourneyRequest
     */
    public <T> UpdateSystemDataJourneyRequest toUpdateSystemDataRequest(String journeyId, String pageName, T data, JourneyStateName journeyStateName) {
        Map<String, T> dataMap = new HashMap<>();
        dataMap.put(pageName, data);
        return UpdateSystemDataJourneyRequest.builder()
                .journeyId(journeyId)
                .journeyState(JourneyStateMapper.toJourneyState(journeyStateName.name()))
                .data(dataMap)
                .dataType(JourneyDetailsDataType.SYSTEM_DATA)
                .build();
    }

    public void updateJourneyAsInactive(JourneyData journeyData, JourneyServiceFeignClient journeyServiceFeignClient) {
        Map<String, Map<String, ?>> systemData = journeyData.getJourneyDetail().getSystemData();
        Map<String, Object> journeyDetail = (Map<String, Object>) systemData.get(HLICommonConstants.JOURNEY_STATUS_DETAIL);
        if (journeyDetail == null) {
            log.error("Error fetching journey status Detail data for journeyId :{}", journeyData.getJourneyId());
            journeyDetail = new HashMap<>();
        }
        journeyDetail.put(HLICommonConstants.JOURNEY_STATUS, HLICommonConstants.LEAD_STATUS_IN_ACTIVE);
        journeyServiceFeignClient.update(JourneyUtil.toUpdateSystemDataRequest(journeyData.getJourneyId(),
                HLICommonConstants.JOURNEY_STATUS_DETAIL, journeyDetail,
                JourneyStateName.JOURNEY_MARKED_INACTIVE));
        log.info("Updated journey {} status → {}", TextSanityUtil.sanitize(journeyData.getJourneyId()), HLICommonConstants.LEAD_STATUS_IN_ACTIVE);
    }

    public <T> void updateJourneyDetailDropOff(JourneyData journeyData,
                                               JourneyServiceFeignClient journeyServiceFeignClient,
                                               ProcessServiceCall processServiceCall,
                                               T apiResponseStatus) {
        Map<String, Map<String, ?>> systemData = journeyData.getJourneyDetail().getSystemData();

        @SuppressWarnings("unchecked")
        Map<String, Object> journeyDetail = (Map<String, Object>) systemData.getOrDefault(HLICommonConstants.JOURNEY_STATUS_DETAIL, new HashMap<>());
        String loanFileNumber = JourneyUtil.getDataFromJourneyService(journeyData.getJourneyDetail().getSystemData(), HLICommonConstants.LOAN_FILE_NUMBER_KEY).toString();

        journeyDetail.put(HLICommonConstants.JOURNEY_STATUS, HLICommonConstants.LEAD_STATUS_IN_ACTIVE );
        journeyDetail.put(HLICommonConstants.JOURNEY_DROP_OFF, apiResponseStatus);

        journeyServiceFeignClient.update(JourneyUtil.toUpdateSystemDataRequest(
                journeyData.getJourneyId(),
                HLICommonConstants.JOURNEY_STATUS_DETAIL,
                journeyDetail,
                JourneyStateName.DROP_OFF_CUSTOMER_EXCLUDED
        ));
//        processServiceCall.cancelLead(CancelLeadRequest.builder().loanFileNumber(loanFileNumber).build(), journeyData.getJourneyId());
        log.info("Lead Cancelled for Loan File Number: {} and JourneyId: {} Marked Inactive", TextSanityUtil.sanitize(loanFileNumber), TextSanityUtil.sanitize(journeyData.getJourneyId()));
    }

    public HLILGLCResponse updateAndGetLglcJourneyData(JourneyData journeyData,
                                                       JourneyServiceFeignClient journeyServiceFeignClient,
                                                       ObjectMapper mapper,
                                                       String lgCode, String lifeLcCode, String nonLifeLcCode, String agencyCode) {
        Map<String, Map<String, ?>> systemData = journeyData.getJourneyDetail().getSystemData();
        Map<String, Object> journeyDetail = (Map<String, Object>) systemData.get(HLICommonConstants.LGLC_DETAILS);
        if (journeyDetail == null) {
            throw new BusinessValidationException(ErrorRef.of(CommonApiStatusCodes.BUSINESS_VALIDATION_ERROR.getCode()),
                    CommonApiStatusCodes.BUSINESS_VALIDATION_ERROR.getMessage(), "LGLC Details not Found");
        }

        HLILGLCResponse lglcDetails = mapper.convertValue(journeyDetail, HLILGLCResponse.class);
        setLgLcSelectedFields(lglcDetails, lgCode, lifeLcCode, nonLifeLcCode, agencyCode);

        Map<String, Object> updatedLgLcDetails = mapper.convertValue(lglcDetails, Map.class);
        journeyServiceFeignClient.update(JourneyUtil.toUpdateSystemDataRequest(journeyData.getJourneyId(),
                HLICommonConstants.LGLC_DETAILS, updatedLgLcDetails,
                JourneyStateName.LGLC_UPDATE_SUCCESS));
        log.info("Updated LGLC Data for journey {}", TextSanityUtil.sanitize(journeyData.getJourneyId()));

        return lglcDetails;
    }

    private void setLgLcSelectedFields(HLILGLCResponse lglcDetails, String lgCode,
                                       String lifeLcCode, String nonLifeLcCode, String agencyCode) {
        lglcDetails.setLgCode(lgCode);
        if(lglcDetails.getFiller1() != null) lglcDetails.setFiller1(lgCode);
        if(lglcDetails.getLifeLc() != null) lglcDetails.getLifeLc().setLcCode(lifeLcCode);
        if(lglcDetails.getNonLifeLc() != null) lglcDetails.getNonLifeLc().setLcCode(nonLifeLcCode);
        if(agencyCode != null) lglcDetails.setAgencyCode(agencyCode);
    }

    public Object getDataFromJourneyService(Map<String, ?> systemData, String keyPath) {
        if (systemData == null || keyPath == null || keyPath.isEmpty()) {
            return "";
        }
        String[] keys = keyPath.split("\\.");
        Object current = systemData;
        for (String key : keys) {
            if (!(current instanceof Map<?, ?> currentMap)) {
                return "";
            }
            current = currentMap.get(key);

            if (current == null) {
                return "";
            }
        }
        // If found value is null, return empty string
        return current != null ? current : "";
    }


    public static Object getByPath(Object root, String path) {
        if (root == null || path == null) return null;
        return extract(root, path.split("\\."), 0);
    }

    @SuppressWarnings("unchecked")
    private static Object extract(Object current, String[] parts, int index) {
        if (current == null) return null;
        if (index == parts.length) return current;
        String key = parts[index];
        // ---- CASE 1: MAP ----
        if (current instanceof Map) {
            Map<String, Object> map = (Map<String, Object>) current;
            Object next = map.get(key);
            return extract(next, parts, index + 1);
        }
        // ---- CASE 2: LIST ----
        if (current instanceof List<?> list) {

            List<Object> result = new ArrayList<>();
            for (Object element : list) {
                Object value = extract(element, parts, index);
                if (value != null) result.add(value);
            }
            return result.get(0);
        }
        // ---- CASE 3: Primitive (String/Number/etc.) ----
        return current;
    }

    @SuppressWarnings("unchecked")
    public static Map<String, Object> convertToMap(Object input) {
        if (input == null) {
            return Collections.emptyMap();
        }
        // If already a Map → cast and convert child elements
        if (input instanceof Map) {
            Map<String, Object> original = (Map<String, Object>) input;
            Map<String, Object> result = new HashMap<>();

            for (Map.Entry<String, Object> entry : original.entrySet()) {
                result.put(entry.getKey(), convertValue(entry.getValue()));
            }
            return result;
        }
        // If not a map/document, return empty
        return Collections.emptyMap();
    }

    private static Object convertValue(Object value) {
        if (value == null) return null;
        if (value instanceof Map) {
            return convertToMap(value);
        }
        if (value instanceof List<?> list) {
            return new ArrayList<>(list);
        }
        // simple values: String, Integer, Double, Boolean, etc.
        return value;
    }


    public static String extractLeadId(JourneyData journeyData) {
        return JourneyUtil.getDataFromJourneyService(
                journeyData.getJourneyDetail().getSystemData(),
                HLICommonConstants.LEAD_ID_KEY
        ).toString();
    }

    public String getValueFromJsonPath(JsonNode root, String path) {
        if (root == null || path == null || path.isBlank()) {
            return null;
        }
        JsonNode current = root;
        List<String> tokens = splitSafely(path);
        for (String token : tokens) {
            if (token.contains("[?(")) {
                String arrayName = token.substring(0, token.indexOf("["));
                JsonNode arrayNode = current.path(arrayName);
                if (!arrayNode.isArray()) {
                    return null;
                }
                Matcher matcher = SIMPLE_FILTER.matcher(token);
                if (!matcher.find()) {
                    return null;
                }
                String field = matcher.group(1);
                String value = matcher.group(2);
                JsonNode matched = null;
                for (JsonNode node : arrayNode) {
                    if (value.equalsIgnoreCase(node.path(field).asText())) {
                        matched = node;
                        break;
                    }
                }
                if (matched == null) {
                    return null;
                }
                current = matched;
            } else {
                current = current.path(token);
                if (current.isMissingNode()) {
                    return null;
                }
            }
        }
        if (current.isArray()) {
            if (current.isEmpty()) {
                return null;
            }
            JsonNode firstElement = current.get(0);
            return firstElement.isValueNode() ? firstElement.asText() : firstElement.toString();
        }
        return current.isValueNode() ? current.asText() : null;
    }

    private List<String> splitSafely(String path) {
        List<String> tokens = new ArrayList<>();
        StringBuilder current = new StringBuilder();
        int bracketDepth = 0;

        for (char c : path.toCharArray()) {
            if (c == '[') bracketDepth++;
            if (c == ']') bracketDepth--;

            if (c == '.' && bracketDepth == 0) {
                tokens.add(current.toString());
                current.setLength(0);
            } else {
                current.append(c);
            }
        }
        if (!current.isEmpty()) {
            tokens.add(current.toString());
        }
        return tokens;
    }
}
