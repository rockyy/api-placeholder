package com.hdfcbank.insurance.hli.process.service.config;


import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import java.util.Map;

@Data
@Configuration
@ConfigurationProperties(prefix = "product-answer-config")
public class ProductConfiguration {
    private Map<String, Map<String, AnswerDetail>> data;
    @Data
    public static class AnswerDetail {
        private String value;
        private String jsonPath;
        private Map<String, String> mappingRef;
        private Map<String, String> lookup;
        private String expression;
    }
}
