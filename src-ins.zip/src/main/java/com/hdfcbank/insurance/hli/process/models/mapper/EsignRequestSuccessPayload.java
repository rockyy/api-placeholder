package com.hdfcbank.insurance.hli.process.models.mapper;

public class EsignRequestSuccessPayload {
}
