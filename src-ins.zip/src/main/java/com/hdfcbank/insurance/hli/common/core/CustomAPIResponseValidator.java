package com.hdfcbank.insurance.hli.common.core;

import com.hdfcbank.common.models.constant.CommonApiErrors;
import com.hdfcbank.common.models.constant.CommonApiStatusCodes;
import com.hdfcbank.common.models.vo.core.ApiResponse;
import com.hdfcbank.common.models.vo.core.ApiResponseStatusCodeLiteral;
import com.hdfcbank.common.models.vo.core.ErrorRef;
import com.hdfcbank.exception.BusinessValidationException;
import com.hdfcbank.insurance.adapter.process.clients.feign.core.GenericApiResponseStatusCodeLiteral;
import com.hdfcbank.insurance.hli.common.core.models.HLIAPIRequestName;
import com.hdfcbank.insurance.hli.common.core.properties.HLIStatusCodes;
import com.hdfcbank.insurance.hli.util.TextSanityUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.jetbrains.annotations.NotNull;
import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

@Slf4j
@Component
public class CustomAPIResponseValidator implements ApplicationContextAware {

    private static HLIStatusCodes apiStatusCodes;
    private static ApplicationContext applicationContext;

    private static final Set<String> SUCCESS_WITH_ERROR_LOG_CODES = Set.of("8001", "8002");
    private static final String SUCCESS_CODE = "0000";

    @Override
    public void setApplicationContext(@NotNull ApplicationContext context) throws BeansException {
        applicationContext = context;
    }

    public static <T> T validateApiResponse(HLIAPIRequestName apiName, ApiResponse<T> response) {
        apiStatusCodes = applicationContext.getBean(HLIStatusCodes.class);
        String code = response.getStatus().getCode();

        if (null == code) {
            throw new BusinessValidationException(
                    CommonApiStatusCodes.DOWNSTREAM_API_ERROR,
                    ErrorRef.of(CommonApiErrors.BUSVL.name()),
                    "error - field is null"
            );
        }

        if (StringUtils.equals(SUCCESS_CODE, code)) {
            return response.getData();
        }

        if (SUCCESS_WITH_ERROR_LOG_CODES.contains(code)) {
            return response.getData();
        }

        handleErrorResponse(apiName, response, code);
        return null;
    }

    private static void handleErrorResponse(HLIAPIRequestName apiName, ApiResponse<?> response, String code) {
        HLIStatusCodes.StatusCodeDetails statusCodeDetails = Optional.ofNullable(apiStatusCodes.getMapping())
                .map(map -> map.get(apiName.getApiName()))
                .map(statusCodeMap -> statusCodeMap.get(code))
                .orElseGet(() -> new HLIStatusCodes.StatusCodeDetails(
                        CommonApiStatusCodes.BUSINESS_VALIDATION_ERROR.getCode(),
                        CommonApiStatusCodes.BUSINESS_VALIDATION_ERROR.getMessage(),
                        null
                ));

        log.warn("Error occurred in ProcessLayerAPI: {} with error code: {}, error message: {}",
                TextSanityUtil.sanitize(apiName.getApiName()),
                TextSanityUtil.sanitize(code),
                TextSanityUtil.sanitize(response.getStatus().getMessage())
        );

        ApiResponseStatusCodeLiteral apiResponseStatusCodeLiteral = GenericApiResponseStatusCodeLiteral.of(
                statusCodeDetails.getCode(),
                statusCodeDetails.getMessageKey()
        );

        if (StringUtils.isNotBlank(statusCodeDetails.getFailureStateName())) {
            FailureStateRecorder failureStateRecorder = applicationContext.getBean(FailureStateRecorder.class);
            failureStateRecorder.recordFailureState(apiName, statusCodeDetails.getFailureStateName());
        }

        throw new BusinessValidationException(
                apiResponseStatusCodeLiteral,
                ErrorRef.of(CommonApiErrors.BUSVL.name()),
                response.getStatus().getErrors().toArray(new String[0])
        );
    }
}