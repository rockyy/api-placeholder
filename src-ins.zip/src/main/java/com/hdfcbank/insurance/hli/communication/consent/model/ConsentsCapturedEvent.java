package com.hdfcbank.insurance.hli.communication.consent.model;

import lombok.Getter;
import lombok.Setter;
import org.springframework.context.ApplicationEvent;

import java.util.List;

@Getter
@Setter
public class ConsentsCapturedEvent extends ApplicationEvent {
    private SubmitCustomerConsentRequest submitCustomerConsentRequestMono;
    private List<CustomerConsentRequest> consents;

    public ConsentsCapturedEvent(Object source, SubmitCustomerConsentRequest submitCustomerConsentRequestMono,
                                 List<CustomerConsentRequest> consents) {
        super(source);
        this.submitCustomerConsentRequestMono = submitCustomerConsentRequestMono;
        this.consents = consents;
    }
}
