package com.hdfcbank.insurance.hli.process.service.impl.proposalQuestion;

import com.hdfcbank.insurance.adapter.process.models.response.GetLoanDetailResponse;
import com.hdfcbank.insurance.hli.process.models.HLIBorrower;
import com.hdfcbank.insurance.hli.process.models.response.HLIProposalQuestionResponse;
import lombok.experimental.UtilityClass;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.ObjectUtils;

import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

@Slf4j
@UtilityClass
public class NomineeUtility {

    public static HLIProposalQuestionResponse.HLINominee getProposalNominee(
            List<GetLoanDetailResponse.Customer> availableNominee
    ) {
        HLIProposalQuestionResponse.HLINominee nominee = new HLIProposalQuestionResponse.HLINominee();
        nominee.setOptions(availableNomineeList(availableNominee));
        log.info("NomineeUtility Nominee  {} ",nominee);
        return nominee;
    }
    private List<HLIBorrower> availableNomineeList(
            List<GetLoanDetailResponse.Customer> availableNominee) {
        if (ObjectUtils.isEmpty(availableNominee)) {
            return Collections.emptyList();
        }
        return availableNominee.stream()
                    .map(BorrowerUtility::mapCustomerToBorrower)
                    .filter(Objects::nonNull)
                    .collect(Collectors.toList());
    }
}
