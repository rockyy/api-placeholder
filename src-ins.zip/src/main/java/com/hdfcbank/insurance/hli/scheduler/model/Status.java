package com.hdfcbank.insurance.hli.scheduler.model;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum Status {
    PURCHASED_INITIATED,
    PURCHASED,
    IN_PROGRESS,
    SUCCESS,
    FAILED,
    PERMANENT_FAILED
}