package com.hdfcbank.insurance.hli.process.models.mapper;

import tools.jackson.databind.ObjectMapper;
import com.hdfcbank.common.models.vo.journey.JourneyData;
import com.hdfcbank.insurance.adapter.process.models.Product;
import com.hdfcbank.insurance.adapter.process.models.request.ContentGroupRequest;
import com.hdfcbank.insurance.adapter.process.models.response.ContentGroupResponse;
import com.hdfcbank.insurance.adapter.process.models.response.CurateProductResponse;
import com.hdfcbank.insurance.adapter.process.models.response.RecommendedProductResponse;
import com.hdfcbank.insurance.hli.common.constant.HLICommonConstants;
import com.hdfcbank.insurance.hli.process.models.HLIProcessConstant;
import com.hdfcbank.insurance.hli.process.models.enums.ProductCode;
import com.hdfcbank.insurance.hli.process.models.response.HLICurateProductResponse;
import com.hdfcbank.insurance.hli.process.models.response.HLIRecommendedProductResponse;
import com.hdfcbank.insurance.hli.util.JourneyUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.Function;
import java.util.stream.Collectors;

import static com.hdfcbank.insurance.hli.common.constant.HLICommonConstants.*;


@Slf4j
public class HLIProductMapping {

    /**
     * This is the mapping method for recommended product,which will prepare
     * response object for recommended product.
     *
     * @param recommendedProductResponse recommended product response
     * @return HLIRecommendedProductResponse
     */
    public static HLIRecommendedProductResponse recommendedResponseMapping(RecommendedProductResponse recommendedProductResponse, ContentGroupResponse contentGroupResponse, int loanTermYears,JourneyData journeyData) {

        Map<String, Product> recommendedMap = getProductMapWithCode(recommendedProductResponse);
        Map<String, Map<String, ContentGroupResponse.Section>> contentGroupMap = constructMapForContentGroupMapping(contentGroupResponse);
        List<HLIRecommendedProductResponse.RecommendationCombo> recommendationCombos = recommendedProductResponse.getCombos().getFixed().stream()
                .map(fixedCombo -> buildComboResponse(fixedCombo, recommendedMap, contentGroupMap,  loanTermYears,journeyData)).toList();
        return HLIRecommendedProductResponse.builder().recommendationCombos(recommendationCombos).build();
    }

    private static HLIRecommendedProductResponse.RecommendationCombo buildComboResponse(RecommendedProductResponse.FixedCombo fixedCombo, Map<String,
            Product> recommendedMap, Map<String, Map<String, ContentGroupResponse.Section>> contentGroupMap, int loanTermYears,JourneyData journeyData) {

        List<HLIRecommendedProductResponse.Product> products = new ArrayList<>();
        List<HLIRecommendedProductResponse.Feature> additionalFeatures = new ArrayList<>();
        AtomicReference<BigDecimal> totalSumInsured = new AtomicReference<>(BigDecimal.ZERO);
        AtomicInteger maxTenure = new AtomicInteger(0);
        // -----------------------------------
        // Build each product within the combo
        // -----------------------------------
        fixedCombo.getProducts().forEach(comboProduct -> {
            updateComboLevelMetrics(comboProduct, totalSumInsured, maxTenure);
            Product recommendedProduct = recommendedMap.get(comboProduct.getCode());
            Map<String, ContentGroupResponse.Section> contentSections = contentGroupMap.get(recommendedProduct.getCode());
            Map<String, String> pdfMap = extractPdfInfo(contentSections);
            List<HLIRecommendedProductResponse.Feature> featureList = extractFeatures(contentSections, additionalFeatures);
            ProductCode.fromProductCode(recommendedProduct.getCode()).ifPresent(productCode -> {
                HLIRecommendedProductResponse.Product detail = buildProductDetail(comboProduct, recommendedProduct, pdfMap, featureList, productCode);
                products.add(detail);
            });
        });

        // -------------------------
        // EMI CALCULATION
        // -------------------------
        int applicableTenureYears = Math.min(loanTermYears, maxTenure.get());

        BigDecimal totalEmi = calculateComboEmi(products,fixedCombo,journeyData);

        // -------------------------
        // Build Combo Response
        // -------------------------
        return HLIRecommendedProductResponse.RecommendationCombo.builder().comboName(fixedCombo.getComboName()).comboCode(fixedCombo.getComboCode())
                .totalPremium(fixedCombo.getTotalPremium()).sumInsured(totalSumInsured.get()).product(products).totalEmiValue(totalEmi).loanTerm(applicableTenureYears)
                .additionalFeature(HLIRecommendedProductResponse.AdditionalFeature.builder().type(ADDITIONAL).name(ADDITIONAL_BENEFIT).featureTitle(ADDITIONAL_BENEFIT)
                        .features(additionalFeatures).build()).build();
    }

    private static void updateComboLevelMetrics(RecommendedProductResponse.ComboProduct comboProduct, AtomicReference<BigDecimal> totalSumInsured,
                                                AtomicInteger maxTenure) {
        maxTenure.updateAndGet(cur -> Math.max(cur, comboProduct.getSuggestedTenure()));
        BigDecimal sumInsured = comboProduct.getSuggestedRevisedSumInsured();
        if (sumInsured != null) {
            totalSumInsured.updateAndGet(cur -> cur.add(sumInsured));
        }
    }

    private static HLIRecommendedProductResponse.Product buildProductDetail(RecommendedProductResponse.ComboProduct comboProduct, Product recommendedProduct, Map<String, String> pdfMap, List<HLIRecommendedProductResponse.Feature> featureList, ProductCode productCode) {

        return HLIRecommendedProductResponse.Product.builder().code(comboProduct.getCode()).productName(recommendedProduct.getName())
                .suggestedPlan(comboProduct.getSuggestedPlan()).suggestedBaseSumInsured(comboProduct.getSuggestedBaseSumInsured())
                .suggestedRevisedSumInsured(comboProduct.getSuggestedRevisedSumInsured()).premium(comboProduct.getPremium())
                .suggestedTenure(getSuggestedTenureInMonths(comboProduct)).emiValue(null) // set later
                .pdfTitle(pdfMap.get(HLIProcessConstant.KEY_PDF_TITLE)).pdfUrl(pdfMap.get(HLIProcessConstant.KEY_PDF_URL))
                .policyStartDelay(recommendedProduct.getPolicyStartDelay())
                .productConfigs(recommendedProduct.getProductConfigs().stream().map(pc -> HLIRecommendedProductResponse.ProductConfig.builder().key(pc.getKey()).value(pc.getValue()).build()).toList())
                .features(featureList).category(HLIRecommendedProductResponse.Category.builder().id(recommendedProduct.getCategory().getId())
                        .categoryName(recommendedProduct.getCategory().getCategoryName()).templateName(recommendedProduct.getCategory().getTemplateName())
                        .code(recommendedProduct.getCategory().getCode()).build()).type(productCode.getType()).name(productCode.getName())
                .featureTitle(productCode.getFeatureTitle()).build();
    }

    private static int getSuggestedTenureInMonths(RecommendedProductResponse.ComboProduct comboProduct) {
        return comboProduct.getSuggestedTenure() != null ? comboProduct.getSuggestedTenure() * 12 : 0;
    }

    private static BigDecimal calculateComboEmi(List<HLIRecommendedProductResponse.Product> products,
                                                RecommendedProductResponse.FixedCombo fixedCombo,JourneyData journeyData) {
        AtomicReference<BigDecimal> totalEmi = new AtomicReference<>(BigDecimal.ZERO);
        List<String> tenureList = fixedCombo.getProducts().stream().map(tenure->String.valueOf(tenure.getSuggestedTenure())).toList();
        products.forEach(product -> {
            BigDecimal emi = emiCalculation(tenureList,journeyData,product.getPremium().toString());
            product.setEmiValue(emi.doubleValue());
            totalEmi.updateAndGet(cur -> cur.add(emi));
        });
        return totalEmi.get();
    }


    private static Map<String, String> extractPdfInfo(Map<String, ContentGroupResponse.Section> contentSections) {
        Map<String, String> pdfMap = new HashMap<>();
        if (contentSections != null) {
            Optional.ofNullable(contentSections.get(HLIProcessConstant.SECTION_VIEW_POLICY_DETAILS))
                    .map(ContentGroupResponse.Section::getDetails)
                    .ifPresent(pdfDetails -> pdfDetails.forEach(pdf -> {
                        pdfMap.put(HLIProcessConstant.KEY_PDF_TITLE, pdf.getInfo());
                        pdfMap.put(HLIProcessConstant.KEY_PDF_URL, pdf.getInfo3());
                    }));
        }
        return pdfMap;
    }

    private static List<HLIRecommendedProductResponse.Feature> extractFeatures(Map<String, ContentGroupResponse.Section> contentSections, List<HLIRecommendedProductResponse.Feature> additionalFeatureList) {

        List<HLIRecommendedProductResponse.Feature> featureList = new ArrayList<>();
        if (contentSections != null) {
            Optional.ofNullable(contentSections.get(COVERAGES)).map(ContentGroupResponse.Section::getDetails).ifPresent(details -> details.forEach(detail -> featureList.add(HLIRecommendedProductResponse.Feature.builder()
                    .icon(detail.getInfo3()).description(detail.getInfo()).name(detail.getInfo()).code(String.valueOf(detail.getId()))
                    .order(detail.getSequence()).build())));

            Optional.ofNullable(contentSections.get(ADDITIONAL_BENEFITS)).map(ContentGroupResponse.Section::getDetails).ifPresent(details -> details.forEach(detail -> additionalFeatureList.add(HLIRecommendedProductResponse
                    .Feature.builder().icon(detail.getInfo3()).description(detail.getInfo()).name(detail.getInfo()).code(String.valueOf(detail.getId()))
                    .order(detail.getSequence()).build())));
        }
        return featureList;
    }


    /**
     * This is the mapping method for curate product,which will prepare
     * response object for curate product.
     *
     * @param curateProductResponse curate product response
     * @return HLICurateProductResponse
     */
    public static HLICurateProductResponse curateProductsResponseMapping(CurateProductResponse curateProductResponse) {
        log.info("mapping started for curate product response :: {}", curateProductResponse.getProducts());
        return HLICurateProductResponse.builder().products(curateProductResponse.getProducts().stream().map(product -> HLICurateProductResponse.Product.builder()
                .code(product.getCode()).name(product.getName()).features(product.getFeatures()
                        .stream().map(feature -> HLICurateProductResponse.Feature.builder()
                                .order(feature.getOrder()).description(feature.getDescription())
                                .code(feature.getCode()).name(feature.getName()).build()).toList())
                .productConfig(product.getProductConfigs().stream().map(productConfig -> HLICurateProductResponse.ProductConfig.builder()
                        .key(productConfig.getKey()).value(productConfig.getValue()).build()).toList()).build()).toList()).build();
    }

    /**
     * This method will prepare request for content group API
     *
     * @param recommendedProductResponse recommended product response
     * @return ContentGroupRequest
     */
    public static ContentGroupRequest mapContentGroupRequest(RecommendedProductResponse recommendedProductResponse) {
        log.info("[mapContentGroupRequest] Preparing ContentGroupRequest");
        Map<String, Product> recommendedMap = getProductMapWithCode(recommendedProductResponse);
        List<ContentGroupRequest.Entity> entities = recommendedMap.values().stream().map(product -> ContentGroupRequest.Entity.builder()
                .type(HLIProcessConstant.ENTITY_TYPE_PRODUCT).code(product.getCode()).build()).toList();
        log.debug("Prepared {} content group entities", entities.size());
        return ContentGroupRequest.builder().page(HLIProcessConstant.PAGE_LANDING).entities(entities).build();
    }

    public static ContentGroupRequest toContentGroupRequest(CurateProductResponse curateAPIResponse) {
        List<ContentGroupRequest.Entity> entities = curateAPIResponse.getProducts().stream().map(product -> ContentGroupRequest.Entity.builder()
                .type(HLIProcessConstant.ENTITY_TYPE_PRODUCT).code(product.getCode()).build()).toList();
        return ContentGroupRequest.builder().page(HLIProcessConstant.PAGE_LANDING).entities(entities).build();
    }


    private static Map<String, Product> getProductMapWithCode(RecommendedProductResponse recommendedProductResponse) {
        // Map product code -> product for quick lookup
        return recommendedProductResponse.getProducts().stream().collect(Collectors.toMap(Product::getCode, product -> product));
    }


    private static Map<String, Map<String, ContentGroupResponse.Section>> constructMapForContentGroupMapping(ContentGroupResponse contentGroupResponse) {

        return contentGroupResponse.getData().stream().filter(data -> SUCCESS.equalsIgnoreCase(data.getStatus()))
                .filter(data -> data.getContentGroup() != null).filter(data -> data.getContentGroup().getSections() != null)
                .collect(Collectors.toMap(ContentGroupResponse.DataItem::getCode,                        // OUTER KEY
                        data -> data.getContentGroup().getSections().stream().collect(Collectors.toMap(s -> s.getCode().trim(),
                                Function.identity(), (s1, s2) -> s1
                        )), (map1, map2) -> map1                                             // IF duplicate DATA codes → keep first
                ));
    }

    public static BigDecimal productTenure(List<String> tenureList, JourneyData journeyData) {
        ObjectMapper objectMapper = new ObjectMapper();
        double loanTermYears = getIPFLoanTermInYears(journeyData, objectMapper);
        Optional<String> maxPolicyTenure = Optional.ofNullable(tenureList).orElse(Collections.emptyList()).stream().filter(Objects::nonNull).max(Comparator.comparingInt(Integer::parseInt));
        if (maxPolicyTenure.isEmpty()) {
            log.error("product tenure is 0");
            return BigDecimal.ZERO;
        }
        return BigDecimal.valueOf(loanTermYears).min(BigDecimal.valueOf(Long.parseLong(maxPolicyTenure.get())));
    }

    private static double getIPFLoanTermInYears(JourneyData journeyData, ObjectMapper objectMapper) {
        return Double.parseDouble(objectMapper.convertValue(JourneyUtil.getByPath(journeyData.getJourneyDetail()
                .getSystemData(), HLICommonConstants.GET_LOAN_TERM), String.class)) / HLICommonConstants.MONTHS_TO_YEAR_UNIT;

    }


    public static BigDecimal productTenure(String tenure, JourneyData journeyData) {
        ObjectMapper objectMapper = new ObjectMapper();
        double loanTermYears = getIPFLoanTermInYears(journeyData, objectMapper);
        if (Objects.isNull(tenure) || tenure.isEmpty()) {
            log.error("product tenure is 0");
            return BigDecimal.ZERO;
        }
        return BigDecimal.valueOf(loanTermYears).min(BigDecimal.valueOf(Double.parseDouble(tenure)));
    }

    public static BigDecimal emiCalculation(String tenure,JourneyData journeyData,String principleAmount){
        ObjectMapper objectMapper = new ObjectMapper();
        double annualRoi = Double.parseDouble(objectMapper.convertValue(JourneyUtil.getByPath(journeyData.getJourneyDetail().getSystemData(), HLICommonConstants.LOAN_DETAIL_MIN_RATE_OF_INTEREST), String.class));
        int ipfTenure = productTenure(tenure,journeyData).intValue();
        if (ipfTenure == 0) {
            log.error("product tenure is 0");
            return BigDecimal.ZERO;
        }
        int months = ipfTenure * 12;
        double monthlyRate = (annualRoi / 12) / 100;

        return calculateEmi(principleAmount, String.valueOf(months), String.valueOf(monthlyRate));

    }
    public static BigDecimal emiCalculation(List<String> tenureList, JourneyData journeyData, String principleAmount) {
        ObjectMapper objectMapper = new ObjectMapper();
        double annualRoi = Double.parseDouble(objectMapper.convertValue(JourneyUtil.getByPath(journeyData.getJourneyDetail().getSystemData(), HLICommonConstants.LOAN_DETAIL_MIN_RATE_OF_INTEREST), String.class));
        int ipfTenure = productTenure(tenureList,journeyData).intValue();
        if (ipfTenure == 0) {
            log.error("product tenure is 0");
            return BigDecimal.ZERO;
        }
        int months = ipfTenure * 12;
        double monthlyRate = (annualRoi / 12) / 100;

        return calculateEmi(principleAmount, String.valueOf(months), String.valueOf(monthlyRate));

    }


    private static BigDecimal calculateEmi(String principleAmount, String ipfTenureMonthly, String monthlyROI) {

        BigDecimal principle = new BigDecimal(principleAmount);

        BigDecimal rate = new BigDecimal(monthlyROI);
        int tenure = Integer.parseInt(ipfTenureMonthly);
        // (1 + Rate)
        BigDecimal onePlusR = BigDecimal.ONE.add(rate);
        // (1 + Rate) ^ Tenure
        BigDecimal power = onePlusR.pow(tenure, MathContext.DECIMAL64);
        // Numerator = Principle × Rate × (1+Rate)^Tenure
        BigDecimal numerator = principle.multiply(rate).multiply(power);
        // Denominator = (1+Rate)^Tenure - 1
        BigDecimal denominator = power.subtract(BigDecimal.ONE);
        // EMI
        return numerator.divide(denominator, 10, RoundingMode.HALF_UP);
    }

}