package com.hdfcbank.insurance.hli.communication.otp.service.impl;


import com.hdfcbank.adapters.clients.feign.journey.JourneyServiceFeignClient;
import com.hdfcbank.common.models.vo.core.ApiResponse;
import com.hdfcbank.common.models.vo.journey.JourneyData;
import com.hdfcbank.insurance.adapter.communication.request.GenerateOTPRequest;
import com.hdfcbank.insurance.adapter.communication.request.ValidateOTPRequest;
import com.hdfcbank.insurance.adapter.communication.response.GenerateOTPResponse;
import com.hdfcbank.insurance.adapter.communication.response.ValidateOTPResponse;
import com.hdfcbank.insurance.hli.common.enums.JourneyStateName;
import com.hdfcbank.insurance.hli.communication.consent.HLIOTPResponseMapper;
import com.hdfcbank.insurance.hli.communication.consent.model.CustomerConsentRequest;
import com.hdfcbank.insurance.hli.communication.consent.model.HLICustomerConsentRequest;
import com.hdfcbank.insurance.hli.communication.consent.service.ConsentService;
import com.hdfcbank.insurance.hli.communication.otp.mapper.HLIOTPMapper;
import com.hdfcbank.insurance.hli.communication.otp.models.request.HLIValidateRequest;
import com.hdfcbank.insurance.hli.communication.otp.models.response.HLIConsentResponse;
import com.hdfcbank.insurance.hli.communication.otp.models.response.HLIValidateResponse;
import com.hdfcbank.insurance.hli.communication.otp.service.CommunicationService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
@Slf4j
@RequiredArgsConstructor
public class CommunicationServiceImpl implements CommunicationService {

    private final JourneyServiceFeignClient journeyServiceFeignClient;
    private final HLIOTPResponseMapper hliotpResponseMapper;
    private final ConsentService consentService;
    private final CommunicationServiceCall communicationServiceCall;
    private final HLIOTPMapper hliOtpMapper;

    /**
     * This method used to send request to communication service to generate OTP for client service.
     */
    @Override
    public ApiResponse<HLIConsentResponse> generateOTP(
            String journeyName,
            String journeyId) {

        JourneyData journeyData = journeyServiceFeignClient.fetch(journeyId);
        journeyServiceFeignClient.updateJourneyState(journeyData.getJourneyId(), JourneyStateName.SEND_OTP_INITIATED.name());
        GenerateOTPRequest generateOTPRequest = hliOtpMapper.toGenerateOTPRequest(journeyData);
        GenerateOTPResponse generateOTPResponse = communicationServiceCall.sendOtp(journeyData.getJourneyId(),generateOTPRequest);
        HLIConsentResponse hliOtpResponse = hliotpResponseMapper.otpResponseMapper(generateOTPResponse);
        journeyServiceFeignClient.updateJourneyState(journeyData.getJourneyId(), JourneyStateName.SEND_OTP_SUCCESS.name());
        return ApiResponse.success(hliOtpResponse);
    }

    /**
     * This method is used to send request to communication service to validate the customer.
     *
     * @param hliValidateRequest
     * @return ApiResponse<HLIValidateResponse>
     */
    @Override
    public ApiResponse<HLIValidateResponse> validateCustomer(
            String journeyName,
            String journeyId,
            HLIValidateRequest hliValidateRequest) {

        JourneyData journeyData = journeyServiceFeignClient.fetch(journeyId);
        journeyServiceFeignClient.updateJourneyState(
                journeyData.getJourneyId(),
                JourneyStateName.VALIDATE_OTP_INITIATED.name());
        ValidateOTPRequest validateOTPRequest = hliOtpMapper.toValidateOTPRequest(hliValidateRequest);

        ValidateOTPResponse validateCustomerResponse = communicationServiceCall.validateOTPCall(
                validateOTPRequest,
                journeyData.getJourneyId());

        if (validateCustomerResponse.isMatched()) {
            journeyServiceFeignClient.updateJourneyState(journeyData.getJourneyId(), JourneyStateName.VALIDATE_OTP_SUCCESS.name());

            List<CustomerConsentRequest> customerConsentRequestList = hliValidateRequest.getLogInConsentData().stream()
                    .map(data -> CustomerConsentRequest.builder()
                            .key(data.getConsentKey())
                            .acceptance(data.getConsentAccepted())
                            .build())
                    .collect(Collectors.toList());
            consentService.storeConsentsData(HLICustomerConsentRequest.builder().customerConsentRequest(customerConsentRequestList).build(), journeyData);

            return ApiResponse.success(
                    HLIValidateResponse.builder()
                            .otpValidated(true)
                            .incorrectAttempts(0).build());
        } else {
            journeyServiceFeignClient.updateJourneyState(journeyData.getJourneyId(), JourneyStateName.VALIDATE_OTP_FAILED.name());
            return ApiResponse.success(
                    HLIValidateResponse.builder()
                            .otpValidated(false)
                            .incorrectAttempts(1).build());
        }
    }
}