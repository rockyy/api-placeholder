package com.hdfcbank.insurance.hli.process.models.request;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.*;

import java.util.List;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class HLIFetchPricingDetailsRequest {

    @NotNull(message = "Products list must not be null")
    @NotEmpty(message = "Products list must not be empty")
    @Valid
    private List<Products> products;

    @Getter
    @Setter
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    @ToString
    public static class Products {

        @NotBlank(message = "Product code must not be blank")
        private String code;

        @NotNull(message = "EntityIds must not be null")
        @NotEmpty(message = "EntityIds must not be empty")
        @Size(min = 1, message = "At least one entityId is required")
        private List<@NotBlank(message = "EntityId must not be blank") String> entityIds;
    }
}
