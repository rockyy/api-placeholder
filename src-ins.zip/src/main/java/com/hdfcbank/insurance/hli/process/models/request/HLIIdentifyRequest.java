package com.hdfcbank.insurance.hli.process.models.request;

import com.hdfcbank.insurance.hli.process.annotations.HLIRequestValidator;
import com.hdfcbank.insurance.hli.process.models.enums.SourceSystem;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@ToString
@HLIRequestValidator
public class HLIIdentifyRequest {
    @NotNull(message = "Loan number can not be blank")
    @NotEmpty
    @Pattern(regexp = "^[0-9]+$", message = "Loan number must contain only numeric digits")
    private String loanFileNumber;
    private @Valid String dob;
    @NotNull(message = "Source can not be blank")
    private @Valid SourceSystem source;
}
