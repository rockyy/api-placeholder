package com.hdfcbank.insurance.hli.communication.otp.models.request;

import com.hdfcbank.insurance.hli.communication.otp.models.annotation.ValidateCommunicationRequest;
import jakarta.validation.constraints.NotNull;
import lombok.*;

import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@ToString
@ValidateCommunicationRequest
public class HLIConsentRequest {
    @NotNull
    private List<LogInConsentData> logInConsentData;
    @Getter
    @Setter
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    @ToString
    public static class LogInConsentData{
        @NotNull
        private String consentKey;
        @NotNull
        private Boolean consentAccepted;
    }
}
