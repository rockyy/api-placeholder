package com.hdfcbank.insurance.hli.process.models.enums;

public enum LCUserType {
    HLIFE, HERGO, HSALES
}
