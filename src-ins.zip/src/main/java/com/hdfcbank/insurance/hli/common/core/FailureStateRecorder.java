package com.hdfcbank.insurance.hli.common.core;


import com.hdfcbank.insurance.hli.common.core.models.HLIAPIRequestName;

public interface FailureStateRecorder {
    void recordFailureState(HLIAPIRequestName apiName, String state);
}
