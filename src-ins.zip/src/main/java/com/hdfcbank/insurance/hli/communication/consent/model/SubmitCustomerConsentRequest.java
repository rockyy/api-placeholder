package com.hdfcbank.insurance.hli.communication.consent.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;
import lombok.experimental.SuperBuilder;

import java.util.List;

@Getter
@Setter
@SuperBuilder
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class SubmitCustomerConsentRequest {
    private String journeyName;
    private String journeyId;
    private CustomerDetail customerDetails;

    @Getter
    @Setter
    @Builder
    public static class CustomerDetail {
        private String pan;
        private String firstName;
        private String lastName;
        private String dateOfBirth;
        private String identifier;
        private String identifierType;
        private List<Consent> consents;
        private String consentsCapturedDate;
    }

    @Getter
    @Setter
    @Builder
    public static class Consent {
        private String key;
        @JsonProperty("acceptance")
        private boolean acceptance;
    }
}
