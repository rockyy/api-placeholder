package com.hdfcbank.insurance.hli.communication.consent;

import com.hdfcbank.insurance.adapter.communication.response.GenerateOTPResponse;
import com.hdfcbank.insurance.hli.communication.otp.models.response.HLIConsentResponse;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface HLIOTPResponseMapper {

    HLIConsentResponse otpResponseMapper(GenerateOTPResponse generateOTPResponse);
}
