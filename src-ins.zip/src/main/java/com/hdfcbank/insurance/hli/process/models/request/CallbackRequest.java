package com.hdfcbank.insurance.hli.process.models.request;

import com.hdfcbank.insurance.hli.process.models.enums.CallbackType;
import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CallbackRequest {

    private CallbackType callbackType;
    private String data;
}
