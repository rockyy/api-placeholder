package com.hdfcbank.insurance.hli.common.constant;

import lombok.experimental.UtilityClass;

@UtilityClass
public class HLICommonConstants {
    public static final Integer UNMASKED_VALUE_LOAN_NUMBER=4;
    public static final Integer UNMASKED_VALUE_SUFFIX = 4;
    public static final Integer UNMASKED_VALUE_PREFIX = 3;
    public static final String LOAN_IDENTIFY_DETAIL_PAGE_NAME = "loanidentifydetails";
    public static final String LOAN_IDENTIFY_REQUEST= "loanidentifyrequest";
    public static final String PURCHASE_PROCESS_TYPE = "STP";


    public static final String LIFE_LC_CODE = "proposalRequest.lifeLCCode";
    public static final String NON_LIFE_LC_CODE = "proposalRequest.nonLifeLCCode";
    public static final String SOURCE_PROPERTY_NODE="SOURCE";
    public static final String DOB_PROPERTY_NODE="DOB";
    public static final String DOB_FORMAT="dd/MM/yyyy";
    public static final String HOME_LOAN_DETAIL = "getLoanDetail";
    public static final String DROPOFF_REASON="dropOffReason";
    public static final String DROPOFF_EXCLUSIONS="dropOffExclusions";
    public static final String JOURNEY_STATUS = "status";
    public static final String JOURNEY_DROP_OFF = "journeyDropOff";
    public static final String JOURNEY_NAME = "ETB_HLI";
    public static final String BORROWER = "BORROWER";
    public static final String JOURNEY_STATUS_DETAIL = "journeyStatusDetail";
    public static final String LEAD_ID_KEY = "getLoanDetail.leadId";
    public static final String LOAN_FILE_NUMBER_KEY = "loanidentifydetails.loanidentifydetails.loanFileNumber";
    public static final String SELECTED_PRODUCT_NOT_FOUND = "Selected Product";
    public static final String SELECTED_PRODUCT_CODE_NOT_FOUND = "Selected Product code";
    public static final String SELECTED_PRODUCT_ENTITY_ID_NOT_FOUND = "Selected Product entity Ids";
    public static final String PRICING_REQUEST = "pricingRequest";
    public static final String PRICING_RESPONSE = "pricingResponse";
    public static final String PRICING_QUESTION_REQUEST = "pricingQuestionRequest";
    public static final String PRICING_QUESTION_RESPONSE = "pricingQuestionResponse";
    public static final String BLANK_MODE_SUBMIT_PROPOSAL="Mode can not be blank or empty for proposal question type";
    public static final String BLANK_QUOTE_ID_SUBMIT_PROPOSAL="Quote Id can not be blank or empty for proposal question type";
    public static final String PRICING_REQUEST_PATH = "pricingRequest.product";
    public static final String DEFAULT_PRICING_STATUS = "Initiated";

    public static final String OCCUPATION_KEY = "occupation";
    public static final String FUNDING_TYPE_KEY = "funding_type";
    public static final String CI_SUM_INSURED_KEY = "ci_sum_insured_option";
    public static final String FUNDING_TYPE_DEFAULT = "Funded";
    public static final String CI_SUM_INSURED_DEFAULT = "100%";
    public static final String MONTHLY_SALARY="monthly_salary";
    public static final String RECOMMENDED_PRODUCT="RECOMMENDED_PRODUCT";
    public static final String KFS_DETAIL="KFS_DETAIL";
    public static final String SUBMIT_FINAL_PROPOSAL_REQUEST ="submitFinalProposalRequest";
    public static final String SUBMIT_FINAL_PROPOSAL_RESPONSE ="submitFinalProposalResponse";
    public static final String BORROWER_ESIGN_DETAIL="borrowerEsignDetail";
    public static final String PROPOSAL_QUESTIONS = "PROPOSAL_QUESTIONS";
    public static final String LGLC_DETAILS = "lglcDetails";
    public static final String PROPOSAL_RESPONSE = "proposalResponse";
    public static final String PROPOSAL_REQUEST = "proposalRequest";
    public static final String LOAN_DETAIL_MIN_RATE_OF_INTEREST = "getLoanDetail.loanEligibility.minRateOfInterest";
    public static final String GET_LOAN_TERM = "getLoanDetail.loan.loanTerm";
    public static final String PLAN = "plan";
    public static final String MIN_ROI = "minROI";
    public static final String ADDITIONAL = "additional";
    public static final String ADDITIONAL_BENEFIT = "Additional Benefits";
    public static final String COVERAGES = "coverages";
    public static final String ADDITIONAL_BENEFITS = "additional_benefits";
    public static final String SUCCESS = "Success";
    public static final String LEAD_ID_FILTER_KEY = "journeyDetail.systemData.getLoanDetail.leadId";
    public static final String LOAN_FILE_NUMBER_FILTER_KEY = "journeyDetail.systemData.loanidentifydetails.loanidentifydetails.loanFileNumber";
    public static final String HDFC_GCP_PLUS = "HDFC_GCP_PLUS";
    public static final String HDFC_3D = "HDFC_3D";
    public static final String HDFC_BGR_4="HDFC_BGR_4";
    public static final String HDFC_ERGO_HCA="HDFC_ERGO_HCA";
    public static final String LEAD_STATUS_ACTIVE = "Active";
    public static final String LEAD_STATUS_IN_ACTIVE = "InActive";
    public static final String AMT_PAYABLE = "amtPayable";
    public static final String LOAN_PRODUCT_TYPE = "loanProductTYpe";
    public static final String EMI_AMT = "emiAmt";
    public static final String EFFECTIVE_ROI = "effectiveRoi";
    public static final String LOAN_TERM = "loanTerm";
    public static final String AGENCY_CODE = "agencyCode";
    public static final String ORIGIN_MODE = "originMode";
    public static final String SOURCE_BRANCH = "sourceBranch";
    public static final String FILE_NO = "fileNo";
    public static final String NO_OF_COBORR = "noOfCoBorrower";
    public static final String TOT_LOAN_AMT = "totalLoanAmt";
    public static final String PRODUCT_TYPE = "productType";
    public static final String FILLER14 = "filter14";
    public static final String EXISTING_BGR_FLAG = "existingBGRFlag";
    public static final String PROP_NO = "propNo";
    public static final String ADDR_LINE1 = "addressLine1";
    public static final String PIN_CODE = "pincode";
    public static final String STATE = "state";
    public static final String CITY = "city";
    public static final String ASSESSED_MKT_VALUE = "assessMktValue";
    public static final String CATEGORY = "category";
    public static final String REL_TO_BORR = "relToBorrower";
    public static final String CUST_FIRST_NAME = "custFirstName";
    public static final String CUST_SUR_NAME = "custSurName";
    public static final String DT_OF_BIRTH = "customerDOB";
    public static final String SEX = "sex";
    public static final String VISA_TYPE = "visaType";
    public static final String PAN_NO = "panNo";
    public static final String CUST_NUMBER = "customerNo";
    public static final String NRI_FLAG = "nriFlag";
    public static final String CAPACITY_DESC = "capacityDesc";
    public static final String INCOME_CONSIDER = "incomeConsider";
    public static final String EDUCATION = "education";
    public static final String NAT_OF_EMP = "natOfEmp";
    public static final String MOBILE = "mobile";
    public static final String FILLER17 = "filler17";
    public static final String P_ADDR_LINE1 = "pAddLine1";
    public static final String P_PIN_CODE = "pPincode";
    public static final String P_STATE = "pState";
    public static final String P_CITY = "pCity";
    public static final String MAX_LOAN = "maxLoan";
    public static final String MIN_RATE_OF_INTEREST = "minRateOfInterest";
    public static final String NO_REASON_AVAILABLE = "noReasonAvailable";
    public static final String INCOME_CONSIDER_Y = "incomeConsiderY";
    public static final String NO_OF_BORROWERS = "noOfBorrowers";
    public static final String INCOME_GREATER_THAN_ZERO = "incomeGreaterThanZero";


    public static final String OTP_VALIDATION_FAILED = "OTP Validation Failed";

    public static final String CAPTURED_DATE_OUTPUT_FORMAT = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'";
    public static final String UTC = "UTC";
    public static final String ISD_CODE_INDIA = "+91";
    public static final String DOCUMENT_ESIGN_EXPIRY_DATE = "esignInitiatedDate";
    public static final String DOCUMENT_ESIGN_EXPIRED = "Document esign expired";

    public static class LGLCDetails {
        public static final String LG_CODE = "lgCode";
        public static final String LIFE_LC_CODE = "lifeLcCode";
        public static final String NON_LIFE_LC_CODE = "nonLifeLcCode";
    }

    public static final String DETAILS_NOT_UPDATED = "Oops! Details Not Updated!";
    public static final String INLINE = "INLINE";
    public static final String JOURNEY_FAILURE_DETAIL =
            "journeyFailureDetail";
    public static final Integer MONTHS_TO_YEAR_UNIT = 12;

    public static final String ESIGN_EXPIRY_DATE_FORMAT = "dd-MM-yyyy";

    public static final String FAILED_PURCHASE_STATUS_UPDATE = "Failed to update purchase status to PURCHASED";

    public static final Integer SCALE_VALUE = 0;
}
