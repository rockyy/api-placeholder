package com.hdfcbank.insurance.hli.common.aspect;

import com.hdfcbank.adapters.clients.feign.journey.JourneyServiceFeignClient;
import com.hdfcbank.common.models.vo.journey.JourneyData;
import com.hdfcbank.common.models.vo.journey.JourneyState;
import com.hdfcbank.insurance.hli.common.config.FailureStateContextHolder;
import com.hdfcbank.insurance.hli.common.config.JourneyContextHolder;
import com.hdfcbank.insurance.hli.common.constant.HLICommonConstants;
import com.hdfcbank.insurance.hli.common.enums.JourneyStateName;
import com.hdfcbank.insurance.hli.common.exception.CustomValidationException;
import com.hdfcbank.insurance.hli.util.JourneyUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.util.Comparator;
import java.util.List;
import java.util.Set;

@Aspect
@Component
@RequiredArgsConstructor
@Slf4j
public class JourneyFailureAspect {

    private final JourneyServiceFeignClient journeyServiceFeignClient;
    private static final Set<JourneyStateName> NON_PERSISTED_STATES = Set.of(JourneyStateName.DROP_OFF_CUSTOMER_EXCLUDED, JourneyStateName.BUSINESS_VALIDATION_FAILED);

    @AfterThrowing(pointcut = "execution(* com.hdfcbank.insurance.hli..*(..))", throwing = "exception")
    public void handleFailure(Exception exception) {
        String journeyId = null;

        try {
            // Skip business validation failures
            if (isValidationException(exception)) {
                log.info("Skipping journey failure persistence " + "for validation exception: {}", exception.getClass().getSimpleName());
                return;
            }
            JourneyData journeyData = JourneyContextHolder.getJourneyData();
            if (journeyData != null) {
                journeyId = journeyData.getJourneyId();
            } else {
                journeyId = FailureStateContextHolder.getJourneyId();
            }
            if (journeyId == null) {
                log.warn("JourneyId not available. " + "Skipping failure persistence");
                return;
            }
            JourneyStateName failedState = FailureStateContextHolder.get();
            if (failedState == null) {
                log.warn("FailureState annotation not found");
                return;
            }
            JourneyFailureDetail failureDetail = JourneyFailureDetail.builder().failedState(failedState.name()).errorMessage(exception.getMessage()).exceptionType(exception.getClass().getSimpleName()).rootCause(ExceptionUtils.getRootCauseMessage(exception)).timestamp(Instant.now()).build();
            log.error("Journey failure for journeyId: {}, state: {}", journeyId, failedState, exception);
            // Save error details
            journeyServiceFeignClient.update(JourneyUtil.toUpdateSystemDataRequest(journeyId, HLICommonConstants.JOURNEY_FAILURE_DETAIL, failureDetail, failedState));
            // Save failed state
            journeyServiceFeignClient.updateJourneyState(journeyId, failedState.name());
        } catch (Exception ex) {
            log.error("Error while storing failure state", ex);
        } finally {
            FailureStateContextHolder.clear();
        }
    }


    private boolean isValidationException(Exception exception) {

        return exception instanceof CustomValidationException;
    }
}