package com.hdfcbank.insurance.hli.process.models.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum BorrowerEsignStatus {
    INITIATED("INITIATED"),IN_PROGRESS("IN_PROGRESS"),SIGNED("SIGNED"),UNSIGNED("UNSIGNED");
    private final String value;
}