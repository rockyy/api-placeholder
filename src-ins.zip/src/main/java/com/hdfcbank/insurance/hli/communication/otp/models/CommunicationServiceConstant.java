package com.hdfcbank.insurance.hli.communication.otp.models;

import lombok.experimental.UtilityClass;

@UtilityClass
public class CommunicationServiceConstant {
    public  static final String COMMUNICATION_CHANNEL="SMS";
    public static final String COMMUNICATION_MESSAGE_TYPE="OTP";
    public static final String COMMUNICATION_TEMPLATE_ID="hli-sms-otp-send"; //TBD
    public static final String SUCCESS_VALIDATE_OTP_CODE="0000";

}
