package com.hdfcbank.insurance.hli.common.handler;

import com.hdfcbank.exception.handler.GlobalExceptionHandler;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.ControllerAdvice;

@Slf4j
@ControllerAdvice
public class HLICommonExceptionHandler implements GlobalExceptionHandler {
    @Override
    public <T extends Exception> void logException(String source, T exception) {
        log.error("Exception(source: {}) - {}", source, exception.getMessage(), exception);
    }
}
