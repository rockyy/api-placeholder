package com.hdfcbank.insurance.hli.process.models;

import com.hdfcbank.insurance.hli.process.models.enums.DocumentType;
import com.hdfcbank.insurance.hli.process.models.mapper.HLICallbackPayload;
import lombok.*;

import java.util.List;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class HLIBorrower {
    private String name;
    private String id;
    private String relationToBorrower;
    private String dateOfBirth;
    private String gender;
    private String email;
    private String mobileNumber;
    private String capacityDesc;

}
