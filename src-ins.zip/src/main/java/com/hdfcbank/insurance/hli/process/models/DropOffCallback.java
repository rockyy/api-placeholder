package com.hdfcbank.insurance.hli.process.models;

import com.hdfcbank.insurance.adapter.common.util.CustomValidationStatus;
import com.hdfcbank.insurance.hli.process.models.mapper.HLICallbackPayload;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@ToString
public class DropOffCallback implements HLICallbackPayload {

    private String journeyId;
    private CustomValidationStatus customValidationStatus;
}
