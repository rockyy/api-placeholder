package com.hdfcbank.insurance.hli.common.annotation;
import com.hdfcbank.insurance.hli.common.enums.JourneyStateName;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
public @interface ValidateJourney {
    JourneyStateName[] shouldExists() default {};
    JourneyStateName[] shouldNotExists() default {};
    JourneyStateName[] hasAny() default {};
}
