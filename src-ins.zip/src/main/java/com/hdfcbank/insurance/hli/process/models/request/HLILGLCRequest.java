package com.hdfcbank.insurance.hli.process.models.request;

import lombok.*;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class HLILGLCRequest {

    private String channel;
}
