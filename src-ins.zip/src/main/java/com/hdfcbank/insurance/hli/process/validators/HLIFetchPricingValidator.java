package com.hdfcbank.insurance.hli.process.validators;


import com.hdfcbank.insurance.hli.process.annotations.ValidHLIFetchPricing;
import com.hdfcbank.insurance.hli.process.models.request.HLIFetchPricingRequest;
import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

import java.util.HashSet;
import java.util.Optional;
import java.util.Set;

public class HLIFetchPricingValidator implements ConstraintValidator<ValidHLIFetchPricing, HLIFetchPricingRequest> {

    @Override
    public boolean isValid(HLIFetchPricingRequest value, ConstraintValidatorContext context) {
        return Optional.ofNullable(value)
                .filter(v -> isModeValid(v, context))
                .filter(v -> isProductListValid(v, context))
                .map(v -> areProductsValid(v, context))
                .orElse(false);
    }

    private boolean isModeValid(HLIFetchPricingRequest value, ConstraintValidatorContext context) {
        if (value.getMode() == null || value.getMode().isBlank()) {
            addViolation(context, "mode", "Mode must not be blank");
            return false;
        }
        return true;
    }

    private boolean isProductListValid(HLIFetchPricingRequest value, ConstraintValidatorContext context) {
        if (value.getProduct() == null || value.getProduct().isEmpty()) {
            addViolation(context, "product", "Product list must not be empty");
            return false;
        }
        return true;
    }

    private boolean areProductsValid(HLIFetchPricingRequest value, ConstraintValidatorContext context) {
        Set<String> productCodes = new HashSet<>();

        for (int i = 0; i < value.getProduct().size(); i++) {
            HLIFetchPricingRequest.Product product = value.getProduct().get(i);
            String productPath = "product[" + i + "]";

            if (!isProductCodeValid(product, productPath, context, productCodes)) {
                return false;
            }

            if (!areAnswersValid(product, productPath, context)) {
                return false;
            }
        }
        return true;
    }

    private boolean isProductCodeValid(HLIFetchPricingRequest.Product product, String productPath,
                                       ConstraintValidatorContext context, Set<String> productCodes) {

        if (product.getCode() == null || product.getCode().isBlank()) {
            addViolation(context, productPath + ".code", "Product code must not be blank");
            return false;
        }

        if (!productCodes.add(product.getCode())) {
            addViolation(context, productPath + ".code", "Duplicate product code: " + product.getCode());
            return false;
        }
        return true;
    }

    private boolean areAnswersValid(HLIFetchPricingRequest.Product product, String productPath,
                                    ConstraintValidatorContext context) {

        if (product.getAnswers() == null || product.getAnswers().isEmpty()) {
            addViolation(context, productPath + ".answers", "Answers list must not be empty");
            return false;
        }

        for (int j = 0; j < product.getAnswers().size(); j++) {
            HLIFetchPricingRequest.Product.Answer answer = product.getAnswers().get(j);
            String answerPath = productPath + ".answers[" + j + "]";

            if (!isAnswerValid(answer)) {
                addViolation(context, answerPath, "Answer fields must not be blank");
                return false;
            }
        }
        return true;
    }

    private boolean isAnswerValid(HLIFetchPricingRequest.Product.Answer answer) {
        return answer.getEntityId() != null && !answer.getEntityId().isBlank()
                && answer.getQuestionKey() != null && !answer.getQuestionKey().isBlank()
                && answer.getAnswer() != null && !answer.getAnswer().isBlank();
    }

    private void addViolation(ConstraintValidatorContext context, String propertyPath, String message) {
        context.disableDefaultConstraintViolation();
        context.buildConstraintViolationWithTemplate(message)
                .addPropertyNode(propertyPath)
                .addConstraintViolation();
    }

}

