package com.hdfcbank.insurance.hli.process.models.enums;

import com.hdfcbank.insurance.hli.process.models.DropOffCallback;
import com.hdfcbank.insurance.hli.process.models.EsignCallback;
import com.hdfcbank.insurance.hli.process.models.EsignCallbackUpdate;
import com.hdfcbank.insurance.hli.process.models.SubmitFinalProposalCallback;
import com.hdfcbank.insurance.hli.process.models.mapper.HLICallbackPayload;
import com.hdfcbank.insurance.hli.process.models.mapper.HLICancelLead;

public enum CallbackType {


    CANCEL_LEAD(HLICancelLead.class),
    ESIGN_REQUEST_SUCCESS(EsignCallback.class),
    ESIGN_CALLBACK(EsignCallbackUpdate.class),
    SUBMIT_FINAL_PROPOSAL_CALLBACK(SubmitFinalProposalCallback.class),
    DROP_OFF_CALLBACK(DropOffCallback.class);
    private final Class<? extends HLICallbackPayload> payloadClass;
    CallbackType(Class<? extends HLICallbackPayload> payloadClass) {this.payloadClass = payloadClass;}
    public Class<? extends HLICallbackPayload> getPayloadClass() {return payloadClass;}


}
