package com.hdfcbank.insurance.hli.setting.utility;

import tools.jackson.databind.JsonNode;
import com.hdfcbank.insurance.hli.util.TextSanityUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Component;
import reactor.util.function.Tuple2;
import tools.jackson.databind.node.ObjectNode;

@Component
@Slf4j
public class SettingUtility {

    @Cacheable(cacheNames = {"InsuranceSettingsCache"}, key = "#journeyName")
    public ObjectNode mergeConfigAndConsents(Tuple2<JsonNode, JsonNode> tuple, String journeyName) {
        log.info("inside getMergeSettingDetails for journey name:{}", TextSanityUtil.sanitize(journeyName));
        if (tuple == null) {
            return null;
        }
        ObjectNode settingsResponse = (ObjectNode) tuple.getT1();
        return settingsResponse.set("consents", tuple.getT2());
    }


    @CacheEvict(cacheNames = {"InsuranceSettingsCache"}, key = "#journeyName")
    public void evictCache(String journeyName) {
        log.info("inside evictCache of setting for journey name:{}", TextSanityUtil.sanitize(journeyName));
    }

}
