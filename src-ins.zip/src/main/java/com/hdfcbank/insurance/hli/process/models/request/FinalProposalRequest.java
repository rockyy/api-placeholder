package com.hdfcbank.insurance.hli.process.models.request;

import com.hdfcbank.insurance.hli.process.models.enums.SourceSystem;
import lombok.*;


@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class FinalProposalRequest {
    private String loanFileNumber;
    private SourceSystem sourceSystem;
}
