package com.hdfcbank.insurance.hli.process.models;

import lombok.*;

import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Builder
public class FinalProposalResponse {
    private List<SignedDocument> signedDocument;
    private LoanDetailResponse loanDetail;
    private ProductInfoResponse productInfo;

    @Getter
    @Setter
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    @ToString
    public static class LoanDetailResponse {
        private String parentFileNumber;
        private String journeyId;
        private String ipfFileNumber;
        private String filler1;
        private String filler2;
    }

    @Getter
    @Setter
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    @ToString
    public static class ProductInfoResponse {
        private BgrProduct bgr;
        private HcaProduct hca;
        private List<CppProduct> cpplus;
    }


    @Getter
    @Setter
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    @ToString
    public static class BgrProduct {
        private String insuranceQuoteId;
        private String policyRecNo;
        private String filler3;
    }

    @Getter
    @Setter
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    @ToString
    public static class HcaProduct {
        private String insuranceQuoteId;
        private String policyRecNo;
        private String filler4;
    }

    @Getter
    @Setter
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    @ToString
    public static class CppProduct {
        private String insuranceQuoteId;
        private String policyRecNo;
        private String filler5;
    }

    @Getter
    @Setter
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    @ToString
    public static class SignedDocument {
        private String quoteId;
        private String status;
        private String successMessage;
        private Object errors;
        private String leadStatus;
    }
}

