package com.hdfcbank.insurance.hli.process.models.response;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.math.BigDecimal;
import java.util.List;


@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@ToString
@JsonInclude(JsonInclude.Include.NON_NULL)
public class HLIFetchPricingResponse {
    private String status;
    private List<Quotes> quotes;
    private BigDecimal monthlyEMI;
    private BigDecimal productTenure;


    @Getter
    @Setter
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    @ToString
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class Quotes{
        private String productCode;
        private String quoteId;
        private String status;
        private Double  basePremium;
        private Double  tax;
        private Double totalPremium;
        private String actionType;
        private String actionMessage;
        private Double calculatedEMI;
        private String errorMessage;
        private String errorType;
        private String entityId;
        private BigDecimal monthlyEMI;
    }

}
