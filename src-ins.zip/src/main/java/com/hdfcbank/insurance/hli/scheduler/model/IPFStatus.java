package com.hdfcbank.insurance.hli.scheduler.model;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum IPFStatus {

    PURCHASED("PURCHASED", "PURCHASED"),
    APPR("APPR", "UNDER PROCESS"),
    SANC("SANC", "SANCTION"),
    DBFX("DBFX", "FIXING"),
    FD_DBMD("FD/DBMD", "DISBURSEMENT"),
    CN("CN", "CANCELLED"),
    CL("CL", "CLOSE");

    private final String ipfStatusCode;
    private final String ipfStatusName;
}
