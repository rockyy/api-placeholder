package com.hdfcbank.insurance.hli.process.models.enums;

import lombok.Getter;

@Getter
public enum HCAOptions {


    HDFC_ERGO_HCA_OPTION_1("Essential Plan (9 illnesses)"),
    HDFC_ERGO_HCA_OPTION_2("Silver Plus Plan (19 illnesses)"),
    HDFC_ERGO_HCA_OPTION_3("Platinum Plan (52 illnesses)");

    private final String mappedValue;

    HCAOptions(String mappedValue) {
        this.mappedValue = mappedValue;
    }

    /**
     * Safe lookup from string input.
     * Converts input to ENUM and returns mapped value.
     */
    public static String getMappedValue(String input) {
        if (input == null) {
            return null;
        }

        try {
            return HCAOptions.valueOf(input.toUpperCase()).getMappedValue();
        } catch (IllegalArgumentException ex) {
            return "Unknown Plan"; // Fallback if needed
        }
    }
}

