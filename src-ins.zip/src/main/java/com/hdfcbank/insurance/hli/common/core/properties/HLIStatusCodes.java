package com.hdfcbank.insurance.hli.common.core.properties;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import java.util.Map;

@Getter
@Setter
@Configuration
@ConfigurationProperties("bff-layer-api-errors")
public class HLIStatusCodes {

    private Map<String, Map<String, StatusCodeDetails>> mapping;

    @Getter
    @Setter
    @AllArgsConstructor
    public static class StatusCodeDetails {
        private String code;
        private String messageKey;
        private String failureStateName;
    }
}
