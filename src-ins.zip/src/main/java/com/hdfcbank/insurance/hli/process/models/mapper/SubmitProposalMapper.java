package com.hdfcbank.insurance.hli.process.models.mapper;

import com.hdfcbank.insurance.adapter.process.models.request.SubmitAnswerRequest;
import com.hdfcbank.insurance.adapter.process.models.response.SubmitAnswerResponse;
import com.hdfcbank.insurance.hli.process.models.request.HLISubmitAnswerRequest;
import com.hdfcbank.insurance.hli.process.models.response.HLILGLCResponse;
import com.hdfcbank.insurance.hli.process.models.response.HLISubmitAnswerResponse;
import lombok.experimental.UtilityClass;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@UtilityClass
public class SubmitProposalMapper {

    public static SubmitAnswerRequest submitAnswerRequestMapping(HLISubmitAnswerRequest hliSubmitAnswerRequest,
                                                                 HLILGLCResponse hlilglcResponse,
                                                                 String leadId, String loanFileNumber) {
        return SubmitAnswerRequest.builder().mode(hliSubmitAnswerRequest.getMode().toString())
                .leadId(leadId).loanFileNumber(loanFileNumber)
                .productWise(hliSubmitAnswerRequest.getProductWiseQuestions().stream().map(productWiseQuestion -> SubmitAnswerRequest.ProductWise.builder()
                        .answers(productWiseQuestion.getAnswers().stream().map(answer -> SubmitAnswerRequest.ProductWise.Answer.builder().answer(answer.getAnswer()).entityId(answer.getEntityId())
                                .questionKey(answer.getQuestionKey()).build()).toList()).quoteId(productWiseQuestion.getQuoteId()).build()).toList()).build();
    }

    public static HLISubmitAnswerResponse hliSubmitProposalResponseMapping(SubmitAnswerResponse submitAnswerResponse) {
        return HLISubmitAnswerResponse.builder().status(submitAnswerResponse.getStatus())
                .proposals(submitAnswerResponse.getProposals().stream().map(proposals -> HLISubmitAnswerResponse.Proposal.builder()
                        .productCode(proposals.getProductCode()).quoteId(proposals.getQuoteId()).medicalAdvice(proposals.getMedicalAdvice()).status(proposals.getStatus()).build()).toList()).build();
    }
}
