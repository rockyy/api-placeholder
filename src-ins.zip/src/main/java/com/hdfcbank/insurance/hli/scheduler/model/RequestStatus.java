package com.hdfcbank.insurance.hli.scheduler.model;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum RequestStatus {

    APPR("APPR", "APPR"),
    SANC("SANC", "SANC"),
    DBFX("DBFX", "DBFX");

    private final String display;
    private final String ipfStatusCode;
}