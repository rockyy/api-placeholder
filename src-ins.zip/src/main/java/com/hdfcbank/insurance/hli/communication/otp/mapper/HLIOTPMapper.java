package com.hdfcbank.insurance.hli.communication.otp.mapper;

import com.hdfcbank.common.models.vo.journey.JourneyData;
import com.hdfcbank.insurance.adapter.communication.request.GenerateOTPRequest;
import com.hdfcbank.insurance.adapter.communication.request.ValidateOTPRequest;
import com.hdfcbank.insurance.hli.communication.otp.models.CommunicationServiceConstant;
import com.hdfcbank.insurance.hli.communication.otp.models.request.HLIValidateRequest;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring")
public interface HLIOTPMapper {

    // Mapping for Generate OTP
    @Mapping(target = "channel", constant = CommunicationServiceConstant.COMMUNICATION_CHANNEL)
    @Mapping(target = "messageType", constant = CommunicationServiceConstant.COMMUNICATION_MESSAGE_TYPE)
    @Mapping(source = "mobileNumber", target = "mobileNumber")
    @Mapping(target = "templateId", constant = CommunicationServiceConstant.COMMUNICATION_TEMPLATE_ID)
    GenerateOTPRequest toGenerateOTPRequest(JourneyData journeyData);

    // Mapping for Validate OTP
    @Mapping(source = "otp", target = "otpValue")
    @Mapping(source = "txnRef", target = "txnRef")
    @Mapping(target = "channel", constant = CommunicationServiceConstant.COMMUNICATION_CHANNEL)
    @Mapping(target = "messageType", constant = CommunicationServiceConstant.COMMUNICATION_MESSAGE_TYPE)
    ValidateOTPRequest toValidateOTPRequest(HLIValidateRequest validateRequest);
}