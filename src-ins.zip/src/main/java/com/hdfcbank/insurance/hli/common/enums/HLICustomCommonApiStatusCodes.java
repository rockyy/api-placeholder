package com.hdfcbank.insurance.hli.common.enums;

import com.hdfcbank.common.models.vo.core.ApiResponseStatusCodeLiteral;
import lombok.Getter;

@Getter
public enum HLICustomCommonApiStatusCodes implements ApiResponseStatusCodeLiteral {

    SUCCESS("0000", "success"),
    LOAN_NOT_FOUND("8001", "Loan not found in system."),
    STATIC_PARALLEL_IDENTIFIER_REQUIRED("8050", "In Static login parallel identifier required with loan file number."),
    LOAN_FILE_NUMBER_NOT_FOUND("8051", "LOAN file number is mandatory in the request payload"),
    DOB_NOT_MATCH_WITH_LOAN_DETAILS("8052", "DOB not matched with provided loan details"),
    LOGIN_CONSENT_DATA_REQUIRED("8000", "logInConsentData with value is required"),
    DOB_NOT_FOUND("8000", "Not a valid DOB value provided"),
    SOURCE_NOT_FOUND("8000","Not a valid source value provided"),
    INVALID_DOB_FORMAT("8000","Invalid DOB format"),
    LEAD_NOT_FOUND("8000","Lead ID not found for the given Loan file number"),
    SELECTED_PRODUCT_NOT_FOUND("8000","Selected product is empty or null"),
    SELECTED_PRODUCT_NOT_FOUND_CODE("8000","Selected product code is empty or null"),
    SELECTED_PRODUCT_NOT_FOUND_ENTITY_ID("8000","Selected product entity id is empty or null"),
    JOURNEY_DETAILS_NOT_FOUND("8000","Journey details not found for the given journey ID"),
    JOURNEY_STATE_NOT_MAINTAINED("8000","Journey state not maintained for this journey ID"),
    HLI_SUBMIT_PROPOSAL_MODE("8000","Mode can not be empty or null for proposal question type"),
    HLI_SUBMIT_PROPOSAL_QUOTE_ID("8000","Quote ID can not be empty or null for proposal question type"),
    LOAN_NUMBER_NOT_FOUND("8000","Loan file number not found for journeyId"),
    UNSUPPORTED_ACTION("8000","Unsupported action"),
    CUSTOM_VALIDATION_EXCEPTION("5001", "failed")
    ;
    private final String code;
    private final String message;


    HLICustomCommonApiStatusCodes(final String code, final String message) {
        this.code = code;
        this.message = message;
    }
}
