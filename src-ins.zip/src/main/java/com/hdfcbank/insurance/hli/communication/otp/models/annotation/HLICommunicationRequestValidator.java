package com.hdfcbank.insurance.hli.communication.otp.models.annotation;

import com.hdfcbank.insurance.hli.common.enums.HLICustomCommonApiStatusCodes;
import com.hdfcbank.insurance.hli.communication.otp.models.request.HLIConsentRequest;
import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

import java.util.List;

public class HLICommunicationRequestValidator implements ConstraintValidator<ValidateCommunicationRequest, HLIConsentRequest> {
    @Override
    public boolean isValid(HLIConsentRequest request, ConstraintValidatorContext context) {
         List<HLIConsentRequest.LogInConsentData> consentDataList = request.getLogInConsentData();

        if (consentDataList == null || consentDataList.isEmpty()) {
            context.disableDefaultConstraintViolation();
            context.buildConstraintViolationWithTemplate(HLICustomCommonApiStatusCodes.LOGIN_CONSENT_DATA_REQUIRED.getMessage())
                    .addPropertyNode("logInConsentData")
                    .addConstraintViolation();
            return false;

        }
        boolean valid = consentDataList.stream()
                .allMatch(cd -> cd.getConsentKey() != null && !cd.getConsentKey().isEmpty() && cd.getConsentAccepted() != null);

        if (!valid) {
            context.disableDefaultConstraintViolation();
            context.buildConstraintViolationWithTemplate("Both consentKey and consentAccepted must be present")
                    .addPropertyNode("logInConsentData")
                    .addConstraintViolation();
        }
        return valid;
    }

}
