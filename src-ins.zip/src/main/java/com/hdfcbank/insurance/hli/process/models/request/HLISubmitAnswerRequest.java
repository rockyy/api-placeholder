package com.hdfcbank.insurance.hli.process.models.request;

import com.hdfcbank.insurance.hli.process.annotations.HLISubmitAnswerRequestValidator;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.*;

import java.util.List;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@HLISubmitAnswerRequestValidator
public class HLISubmitAnswerRequest {
    @NotNull
    private QuestionType questionType;
    private @Valid Mode mode;

    @NotNull
    @NotEmpty
    private List<ProductWiseQuestion> productWiseQuestions;
    private String lgCode;
    private String lifeLCCode;
    private String nonLifeLCCode;
    private String agencyCode;
    private String channel;

    @Getter
    @RequiredArgsConstructor
    public enum Mode {
        INITIATE,
        RETRY_FAILED_PROPOSAL
    }

    @Getter
    @RequiredArgsConstructor
    public enum QuestionType {
        PREMIUM,
        PROPOSAL
    }


    @Getter
    @Setter
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class ProductWiseQuestion {
        @NotNull
        @NotEmpty
        private String quoteId;
        @NotNull
        @NotEmpty
        private List<Answer> answers;

        @Getter
        @Setter
        @Builder
        @NoArgsConstructor
        @AllArgsConstructor
        public static class Answer {
            @NotNull
            @NotEmpty
            private String entityId;
            @NotNull
            @NotEmpty
            private String questionKey;
            @NotNull
            @NotEmpty
            private Object answer;
        }
    }
}
