package com.hdfcbank.insurance.hli.util;

import com.hdfcbank.common.models.vo.journey.JourneyState;
import lombok.experimental.UtilityClass;

import java.util.Date;

@UtilityClass
public class JourneyStateMapper {
    public static JourneyState toJourneyState(String  stateName) {
        return JourneyState.builder()
                .createdOn(new Date())
                .stateName(stateName)
                .build();
    }
}
