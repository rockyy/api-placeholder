package com.hdfcbank.insurance.hli.process.validators;

import com.hdfcbank.insurance.hli.common.constant.HLICommonConstants;
import com.hdfcbank.insurance.hli.common.enums.HLICustomCommonApiStatusCodes;
import com.hdfcbank.insurance.hli.process.annotations.HLISubmitAnswerRequestValidator;
import com.hdfcbank.insurance.hli.process.models.request.HLISubmitAnswerRequest;
import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.util.List;
import java.util.Objects;

@Slf4j
public class HLISubmitAnswerValidator implements ConstraintValidator<HLISubmitAnswerRequestValidator, HLISubmitAnswerRequest> {
    @Override
    public boolean isValid(HLISubmitAnswerRequest hliSubmitAnswerRequest, ConstraintValidatorContext constraintValidatorContext) {
        if (hliSubmitAnswerRequest.getQuestionType().equals(HLISubmitAnswerRequest.QuestionType.PROPOSAL) && (Objects.isNull(hliSubmitAnswerRequest.getMode()))) {
            constraintValidatorContext.disableDefaultConstraintViolation();
            constraintValidatorContext.buildConstraintViolationWithTemplate(HLICustomCommonApiStatusCodes.HLI_SUBMIT_PROPOSAL_MODE.getMessage())
                    .addPropertyNode(HLICommonConstants.BLANK_MODE_SUBMIT_PROPOSAL)
                    .addConstraintViolation();
            return false;
        }

        if (hliSubmitAnswerRequest.getQuestionType().equals(HLISubmitAnswerRequest.QuestionType.PROPOSAL)) {
            List<HLISubmitAnswerRequest.ProductWiseQuestion> productWiseQuestionList = hliSubmitAnswerRequest.getProductWiseQuestions();
            for (HLISubmitAnswerRequest.ProductWiseQuestion productWiseQuestion : productWiseQuestionList) {
                if (Objects.isNull(productWiseQuestion.getQuoteId()) || StringUtils.isEmpty(productWiseQuestion.getQuoteId())) {
                    constraintValidatorContext.disableDefaultConstraintViolation();
                    constraintValidatorContext.buildConstraintViolationWithTemplate(HLICustomCommonApiStatusCodes.HLI_SUBMIT_PROPOSAL_QUOTE_ID.getMessage())
                            .addPropertyNode(HLICommonConstants.BLANK_QUOTE_ID_SUBMIT_PROPOSAL)
                            .addConstraintViolation();
                    return false;
                }
            }
        }

        return true;
    }
}
