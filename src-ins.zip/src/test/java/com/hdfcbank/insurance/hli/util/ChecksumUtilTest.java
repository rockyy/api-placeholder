package com.hdfcbank.insurance.hli.util;

import org.junit.jupiter.api.Test;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import static org.junit.jupiter.api.Assertions.*;

class ChecksumUtilTest {
    @Test
    void ignoresObjectPropertyOrder() {
        var first = new LinkedHashMap<String, Object>();
        first.put("code", "P1");
        first.put("answer", 100);
        var second = new LinkedHashMap<String, Object>();
        second.put("answer", "100");
        second.put("code", "P1");
        assertTrue(ChecksumUtil.areEqual(first, second));
    }

    @Test
    void ignoresProductAndAnswerOrdering() {
        var a = Map.of("questionKey", "a", "entityId", "C1", "answer", "100");
        var b = Map.of("questionKey", "b", "entityId", "C2", "answer", "200");
        var first = List.of(Map.of("code", "P1", "answers", List.of(a, b)), Map.of("code", "P2"));
        var second = List.of(Map.of("code", "P2"), Map.of("code", "P1", "answers", List.of(b, a)));
        assertTrue(ChecksumUtil.areEqual(first, second));
    }

    @Test
    void detectsChangedAnswerOrEntity() {
        assertFalse(ChecksumUtil.areEqual(Map.of("answer", "100"), Map.of("answer", "101")));
        assertFalse(ChecksumUtil.areEqual(Map.of("entityId", "C1"), Map.of("entityId", "C2")));
    }

    @Test
    void nullChecksumIsDeterministicAndDistinctFromEmptyObject() {
        assertTrue(ChecksumUtil.areEqual(null, null));
        assertFalse(ChecksumUtil.areEqual(null, Map.of()));
        assertEquals(ChecksumUtil.generateCanonicalChecksum(Map.of("a", "b")),
                ChecksumUtil.generateCanonicalChecksum(Map.of("a", "b")));
    }
}
