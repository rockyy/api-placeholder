package com.hdfcbank.insurance.hli.process.validators;

import com.hdfcbank.insurance.hli.process.models.request.HLISubmitAnswerRequest;
import jakarta.validation.ConstraintValidatorContext;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.NullAndEmptySource;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class HLISubmitAnswerValidatorTest {
    private final HLISubmitAnswerValidator validator = new HLISubmitAnswerValidator();
    private final ConstraintValidatorContext context = mock(ConstraintValidatorContext.class, RETURNS_DEEP_STUBS);

    @Test
    void acceptsProposalWithModeAndQuote() {
        assertTrue(validator.isValid(request("Q123"), context));
    }

    @Test
    void rejectsProposalWithoutMode() {
        var request = request("Q123");
        request.setMode(null);
        assertFalse(validator.isValid(request, context));
    }

    @ParameterizedTest
    @NullAndEmptySource
    void rejectsProposalWithoutQuote(String quote) {
        assertFalse(validator.isValid(request(quote), context));
    }

    @Test
    void premiumQuestionsDoNotRequireProposalModeOrQuote() {
        var request = request(null);
        request.setMode(null);
        request.setQuestionType(HLISubmitAnswerRequest.QuestionType.PREMIUM);
        assertTrue(validator.isValid(request, context));
    }

    private HLISubmitAnswerRequest request(String quote) {
        return HLISubmitAnswerRequest.builder().questionType(HLISubmitAnswerRequest.QuestionType.PROPOSAL)
                .mode(HLISubmitAnswerRequest.Mode.INITIATE)
                .productWiseQuestions(List.of(HLISubmitAnswerRequest.ProductWiseQuestion.builder().quoteId(quote).build()))
                .build();
    }
}
