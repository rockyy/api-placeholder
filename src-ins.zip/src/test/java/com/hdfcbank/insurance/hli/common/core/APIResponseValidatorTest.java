package com.hdfcbank.insurance.hli.common.core;

import com.hdfcbank.common.models.vo.core.ApiResponse;
import com.hdfcbank.exception.BusinessValidationException;
import com.hdfcbank.insurance.hli.common.core.models.HLIAPIRequestName;
import com.hdfcbank.insurance.hli.common.core.properties.HLIStatusCodes;
import com.hdfcbank.insurance.hli.common.exception.CustomValidationException;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.springframework.context.ApplicationContext;
import java.util.List;
import java.util.Map;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class APIResponseValidatorTest {
    private final HLIStatusCodes codes = new HLIStatusCodes();

    @BeforeEach
    void setUp() {
        var context = mock(ApplicationContext.class);
        when(context.getBean(HLIStatusCodes.class)).thenReturn(codes);
        new ProcessLayerAPIResponseValidator().setApplicationContext(context);
        new CustomAPIResponseValidator().setApplicationContext(context);
    }

    @AfterEach
    void clearStaticContext() {
        new ProcessLayerAPIResponseValidator().setApplicationContext(null);
        new CustomAPIResponseValidator().setApplicationContext(null);
    }

    @Test
    void successReturnsOriginalData() {
        var response = response("0000");
        assertEquals("payload", ProcessLayerAPIResponseValidator.validateApiResponse(HLIAPIRequestName.FETCH_PRICE, response));
        assertEquals("payload", CustomAPIResponseValidator.validateApiResponse(HLIAPIRequestName.VALIDATE_OTP, response));
    }

    @Test
    void noRecommendationCodeUsesEmptySupplier() {
        assertEquals("empty", ProcessLayerAPIResponseValidator.validateApiResponse(
                HLIAPIRequestName.RECOMMENDED_PRODUCT, response("8005"), () -> "empty"));
        assertNull(ProcessLayerAPIResponseValidator.validateApiResponse(HLIAPIRequestName.FETCH_PRICE, response("8005")));
    }

    @Test
    void missingDetailsCodeProducesInlineValidationError() {
        var exception = assertThrows(CustomValidationException.class,
                () -> ProcessLayerAPIResponseValidator.validateApiResponse(HLIAPIRequestName.IDENTIFY, response("8006")));
        assertEquals("INLINE", exception.getScreen());
        assertEquals("Oops! Details Not Updated!", exception.getTitle());
        assertEquals(List.of("downstream error"), exception.getErrors());
    }

    @Test
    void customValidationPreservesDownstreamTitleScreenAndErrors() {
        var response = response("5001");
        response.getStatus().setTitle("Not eligible");
        response.getStatus().setType("FULL_SCREEN");
        var exception = assertThrows(CustomValidationException.class,
                () -> ProcessLayerAPIResponseValidator.validateApiResponse(HLIAPIRequestName.IDENTIFY, response));
        assertEquals("Not eligible", exception.getTitle());
        assertEquals("FULL_SCREEN", exception.getScreen());
        assertEquals(List.of("downstream error"), exception.getErrors());
    }

    @ParameterizedTest
    @ValueSource(strings = {"8001", "8002"})
    void communicationBusinessCodesReturnData(String code) {
        assertEquals("payload", CustomAPIResponseValidator.validateApiResponse(HLIAPIRequestName.VALIDATE_OTP, response(code)));
    }

    @Test
    void nullStatusCodeIsReportedAsBusinessValidationError() {
        assertThrows(BusinessValidationException.class,
                () -> ProcessLayerAPIResponseValidator.validateApiResponse(HLIAPIRequestName.FETCH_PRICE, response(null)));
        assertThrows(BusinessValidationException.class,
                () -> CustomAPIResponseValidator.validateApiResponse(HLIAPIRequestName.VALIDATE_OTP, response(null)));
    }

    @Test
    void configuredErrorMappingIsUsed() {
        codes.setMapping(Map.of(HLIAPIRequestName.FETCH_PRICE.getApiName(),
                Map.of("E1", new HLIStatusCodes.StatusCodeDetails("8123", "mapped.error", null))));
        var exception = assertThrows(BusinessValidationException.class,
                () -> ProcessLayerAPIResponseValidator.validateApiResponse(HLIAPIRequestName.FETCH_PRICE, response("E1")));
        assertEquals("8123", exception.getApiResponseStatusCodeLiteral().getCode());
    }

    @Test
    void unknownErrorCodeFallsBackToBusinessValidationError() {
        assertThrows(BusinessValidationException.class,
                () -> ProcessLayerAPIResponseValidator.validateApiResponse(HLIAPIRequestName.FETCH_PRICE, response("UNKNOWN")));
        assertThrows(BusinessValidationException.class,
                () -> CustomAPIResponseValidator.validateApiResponse(HLIAPIRequestName.VALIDATE_OTP, response("UNKNOWN")));
    }

    private ApiResponse<String> response(String code) {
        var response = ApiResponse.success("payload");
        response.getStatus().setCode(code);
        response.getStatus().setErrors(List.of("downstream error"));
        return response;
    }
}
