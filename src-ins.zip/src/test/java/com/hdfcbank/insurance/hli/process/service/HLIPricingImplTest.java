package com.hdfcbank.insurance.hli.process.service;

import com.hdfcbank.adapters.clients.feign.journey.JourneyServiceFeignClient;
import com.hdfcbank.adapters.vo.UpdateSystemDataJourneyRequest;
import com.hdfcbank.common.models.vo.journey.JourneyData;
import com.hdfcbank.insurance.adapter.process.models.request.PremiumQuestionRequest;
import com.hdfcbank.insurance.adapter.process.models.request.SubmitPremiumAnswerRequest;
import com.hdfcbank.insurance.adapter.process.models.response.PremiumQuestionResponse;
import com.hdfcbank.insurance.adapter.process.models.response.PricingResponse;
import com.hdfcbank.insurance.hli.common.config.JourneyContextHolder;
import com.hdfcbank.insurance.hli.process.models.mapper.HLIFetchPricingMapper;
import com.hdfcbank.insurance.hli.process.models.mapper.PremiumQuestionRequestMapper;
import com.hdfcbank.insurance.hli.process.models.mapper.PricingResponseMapper;
import com.hdfcbank.insurance.hli.process.models.request.HLIFetchPricingDetailsRequest;
import com.hdfcbank.insurance.hli.process.models.request.HLIFetchPricingRequest;
import com.hdfcbank.insurance.hli.process.service.config.ProductConfiguration;
import com.hdfcbank.insurance.hli.process.service.impl.HLIPricingImpl;
import com.hdfcbank.insurance.hli.process.service.impl.ProcessServiceCall;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import tools.jackson.databind.ObjectMapper;
import java.math.BigDecimal;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletionException;
import static com.hdfcbank.insurance.hli.support.JourneyTestData.*;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class HLIPricingImplTest {
    @Mock private JourneyServiceFeignClient journeyClient;
    @Mock private ProcessServiceCall processCall;
    @Mock private PricingResponseMapper responseMapper;
    @Mock private PremiumQuestionRequestMapper questionMapper;
    @Mock private HLIFetchPricingMapper fetchMapper;
    private final ObjectMapper mapper = new ObjectMapper();
    private HLIPricingImpl service;
    private JourneyData journeyData;
    private ProductConfiguration config;

    @BeforeEach
    void setUp() {
        journeyData = journey();
        JourneyContextHolder.setJourneyData(journeyData);
        config = new ProductConfiguration();
        config.setData(Map.of());
        // Run CompletableFuture tasks inline so assertions never depend on thread timing.
        service = new HLIPricingImpl(journeyClient, processCall, Runnable::run, mapper,
                responseMapper, questionMapper, fetchMapper, config);
    }

    @AfterEach
    void clearContext() {
        JourneyContextHolder.clear();
    }

    @Test
    void unchangedRequestSkipsAnswerSubmissionAndPersistsCalculatedPricing() {
        var request = request();
        journeyData.getJourneyDetail().getSystemData().put("pricingRequest", Map.of("product", request.getProduct()));
        var pricing = pricing();
        when(processCall.pricingServiceCall(eq(JOURNEY_ID), any())).thenReturn(pricing);
        service.fetchPricing(request);
        verify(processCall, never()).premiumQuestionServiceCall(anyString(), any());
        verify(processCall, never()).submitPremiumAnswerCall(anyString(), any());
        assertEquals(new BigDecimal("60"), pricing.getProductTenure());
        assertTrue(pricing.getMonthlyEMI().signum() > 0);
        assertTrue(pricing.getQuotes().getFirst().getMonthlyEMI().signum() > 0);
        var updates = ArgumentCaptor.forClass(UpdateSystemDataJourneyRequest.class);
        verify(journeyClient, times(2)).update(updates.capture());
        assertEquals("FETCH_PRICING_INITIATED", updates.getAllValues().get(0).getJourneyState().getStateName());
        assertEquals("FETCH_PRICING_SUCCESS", updates.getAllValues().get(1).getJourneyState().getStateName());
        assertSame(pricing, updates.getAllValues().get(1).getData().get("pricingResponse"));
    }

    @Test
    void changedRequestCombinesUserAnswersAndConfiguredDefaultsWithoutDuplicates() {
        var request = request();
        var defaults = new ProductConfiguration.AnswerDetail();
        defaults.setValue(" Funded ");
        defaults.setLookup(Map.of("FUNDED", "F"));
        config.setData(Map.of("HDFC_3D", Map.of("funding_type", defaults)));
        var premiumRequest = mock(PremiumQuestionRequest.class);
        when(fetchMapper.toPremiumQuestionRequest(LEAD_ID, request)).thenReturn(premiumRequest);
        when(processCall.premiumQuestionServiceCall(JOURNEY_ID, premiumRequest)).thenReturn(
                PremiumQuestionResponse.builder().productWiseQuestions(List.of(
                        PremiumQuestionResponse.ProductWiseQuestion.builder().code("HDFC_3D")
                                .questions(List.of(question("sum_insured"), question("funding_type"))).build())).build());
        when(processCall.pricingServiceCall(eq(JOURNEY_ID), any())).thenReturn(pricing());
        service.fetchPricing(request);
        var submitted = ArgumentCaptor.forClass(SubmitPremiumAnswerRequest.class);
        verify(processCall).submitPremiumAnswerCall(eq(JOURNEY_ID), submitted.capture());
        assertEquals(LEAD_ID, submitted.getValue().getLeadId());
        assertEquals(request.getMode(), submitted.getValue().getMode());
        var answers = submitted.getValue().getProductWise().getFirst().getAnswers();
        assertEquals(2, answers.size());
        assertEquals("100000", answers.get(0).getAnswer());
        assertEquals("F", answers.get(1).getAnswer());
    }

    @Test
    void premiumQuestionFailureStopsSubmissionAndPricing() {
        var request = request();
        var mapped = mock(PremiumQuestionRequest.class);
        when(fetchMapper.toPremiumQuestionRequest(LEAD_ID, request)).thenReturn(mapped);
        when(processCall.premiumQuestionServiceCall(JOURNEY_ID, mapped)).thenThrow(new IllegalStateException("timeout"));
        assertThrows(IllegalStateException.class, () -> service.fetchPricing(request));
        verify(processCall, never()).submitPremiumAnswerCall(anyString(), any());
        verify(processCall, never()).pricingServiceCall(anyString(), any());
        verifyNoInteractions(journeyClient);
    }

    @Test
    void pricingTaskFailureDoesNotPersistSuccess() {
        var request = request();
        journeyData.getJourneyDetail().getSystemData().put("pricingRequest", Map.of("product", request.getProduct()));
        var failure = new IllegalStateException("pricing timeout");
        when(processCall.pricingServiceCall(eq(JOURNEY_ID), any())).thenThrow(failure);
        assertSame(failure, assertThrows(CompletionException.class, () -> service.fetchPricing(request)).getCause());
        verify(journeyClient, never()).update(argThat((UpdateSystemDataJourneyRequest r) -> "FETCH_PRICING_SUCCESS".equals(r.getJourneyState().getStateName())));
    }

    @Test
    void pricingQuestionsPersistRequestAndResponse() {
        var request = new HLIFetchPricingDetailsRequest();
        var mapped = mock(PremiumQuestionRequest.class);
        var expected = new PremiumQuestionResponse();
        when(questionMapper.toPremiumQuestionRequest(request, LEAD_ID)).thenReturn(mapped);
        when(processCall.premiumQuestionServiceCall(JOURNEY_ID, mapped)).thenReturn(expected);
        var response = service.fetchPricingDetails(request);
        assertSame(expected, response.getData());
        var updates = ArgumentCaptor.forClass(UpdateSystemDataJourneyRequest.class);
        verify(journeyClient, times(2)).update(updates.capture());
        assertSame(request, updates.getAllValues().get(0).getData().get("pricingQuestionRequest"));
        assertSame(expected, updates.getAllValues().get(1).getData().get("pricingQuestionResponse"));
        assertEquals("FETCH_PRICING_QUESTIONS_SUCCESS", updates.getAllValues().get(1).getJourneyState().getStateName());
    }

    private HLIFetchPricingRequest request() {
        return HLIFetchPricingRequest.builder().mode("INITIATE_QUOTES").product(List.of(
                HLIFetchPricingRequest.Product.builder().code("HDFC_3D").answers(List.of(
                        HLIFetchPricingRequest.Product.Answer.builder().entityId("C123")
                                .questionKey("sum_insured").answer("100000").build())).build())).build();
    }

    private PremiumQuestionResponse.ProductWiseQuestion.Question question(String key) {
        return PremiumQuestionResponse.ProductWiseQuestion.Question.builder().entityId("C123").questionKey(key).build();
    }

    private PricingResponse pricing() {
        return PricingResponse.builder().status("Completed").totalPremium("1200").quotes(List.of(
                PricingResponse.Quote.builder().policyTenure("5").totalPremium("1200").build())).build();
    }
}
