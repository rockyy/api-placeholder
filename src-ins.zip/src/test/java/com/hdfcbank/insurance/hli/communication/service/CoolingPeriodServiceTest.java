package com.hdfcbank.insurance.hli.communication.service;

import com.hdfcbank.insurance.hli.communication.entity.CoolingPeriodDetailsEntity;
import com.hdfcbank.insurance.hli.communication.otp.service.impl.CoolingPeriodService;
import com.hdfcbank.insurance.hli.communication.repository.CoolingPeriodDetailsRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import java.time.Duration;
import java.time.Instant;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class CoolingPeriodServiceTest {
    @Mock private CoolingPeriodDetailsRepository repository;
    @InjectMocks private CoolingPeriodService service;
    private final Map<String, String> identifiers = Map.of("loanFileNumber", "123", "journeyName", "ETB_HLI");

    @Test
    void missingRecordHasZeroConsumedAttempts() {
        when(repository.findById(identifiers)).thenReturn(Optional.empty());
        assertEquals(0, service.getConsumedAttempts(identifiers));
    }

    @Test
    void returnsStoredAttemptsAndExpiry() {
        var expiry = Date.from(Instant.now().plusSeconds(60));
        when(repository.findById(identifiers)).thenReturn(Optional.of(
                CoolingPeriodDetailsEntity.builder().noOfAttempts(3).expireAt(expiry).build()));
        assertEquals(3, service.getConsumedAttempts(identifiers));
        assertEquals(expiry, service.getExpireAt(identifiers));
    }

    @Test
    void createsNewRecordWithRequestedAttemptsAndTtl() {
        when(repository.findById(identifiers)).thenReturn(Optional.empty());
        var before = Instant.now();
        service.updateConsumeAttempts(identifiers, 2, Duration.ofMinutes(5));
        var after = Instant.now();
        var captor = ArgumentCaptor.forClass(CoolingPeriodDetailsEntity.class);
        verify(repository).save(captor.capture());
        var entity = captor.getValue();
        assertEquals(identifiers, entity.getId());
        assertEquals(2, entity.getNoOfAttempts());
        assertTrue(entity.getExpireAt().getTime() >= before.plusSeconds(300).toEpochMilli());
        assertTrue(entity.getExpireAt().getTime() <= after.plusSeconds(300).toEpochMilli());
        assertNotNull(entity.getCreatedDate());
        verify(repository, never()).updateAttempts(anyMap(), any(), anyInt(), any());
    }

    @Test
    void updatesExistingRecordWithoutCreatingAnother() {
        when(repository.findById(identifiers)).thenReturn(Optional.of(new CoolingPeriodDetailsEntity()));
        service.updateConsumeAttempts(identifiers, 4, Duration.ofMinutes(5));
        verify(repository).updateAttempts(eq(identifiers), any(Date.class), eq(4), any(Date.class));
        verify(repository, never()).save(any());
    }

    @Test
    void wrapsRepositoryFailureAndRetainsCause() {
        var failure = new IllegalStateException("database unavailable");
        when(repository.findById(identifiers)).thenThrow(failure);
        var exception = assertThrows(RuntimeException.class,
                () -> service.updateConsumeAttempts(identifiers, 1, Duration.ofMinutes(5)));
        assertEquals("Unable to update consume attempts", exception.getMessage());
        assertSame(failure, exception.getCause());
    }

    @Test
    void deletesEveryIdentifier() {
        var other = Map.of("loanFileNumber", "456");
        service.deleteEntity(List.of(identifiers, other));
        verify(repository).deleteByMapId(identifiers);
        verify(repository).deleteByMapId(other);
    }

    @Test
    void wrapsDeletionFailure() {
        var failure = new IllegalStateException("database unavailable");
        doThrow(failure).when(repository).deleteByMapId(identifiers);
        assertSame(failure, assertThrows(RuntimeException.class,
                () -> service.deleteEntity(List.of(identifiers))).getCause());
    }
}
