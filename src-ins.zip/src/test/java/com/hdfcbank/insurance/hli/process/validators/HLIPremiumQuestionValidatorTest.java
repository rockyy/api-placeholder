package com.hdfcbank.insurance.hli.process.validators;

import com.hdfcbank.insurance.hli.process.models.request.HLIPremiumQuestionRequest;
import jakarta.validation.ConstraintValidatorContext;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.NullAndEmptySource;
import java.util.Arrays;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class HLIPremiumQuestionValidatorTest {
    private final HLIPremiumQuestionValidator validator = new HLIPremiumQuestionValidator();
    private final ConstraintValidatorContext context = mock(ConstraintValidatorContext.class, RETURNS_DEEP_STUBS);

    @Test
    void acceptsProductCodeAndEntityIds() {
        assertTrue(validator.isValid(request("HDFC_3D", "C123"), context));
    }

    @Test
    void rejectsMissingAndEmptyProducts() {
        var request = new HLIPremiumQuestionRequest();
        assertFalse(validator.isValid(request, context));
        request.setSelectedProducts(List.of());
        assertFalse(validator.isValid(request, context));
    }

    @ParameterizedTest
    @NullAndEmptySource
    void rejectsMissingOrEmptyCode(String code) {
        assertFalse(validator.isValid(request(code, "C123"), context));
    }

    @ParameterizedTest
    @NullAndEmptySource
    void rejectsMissingOrEmptyEntityId(String entityId) {
        assertFalse(validator.isValid(request("HDFC_3D", entityId), context));
    }

    private HLIPremiumQuestionRequest request(String code, String entityId) {
        return HLIPremiumQuestionRequest.builder().questionType("premium")
                .selectedProducts(List.of(HLIPremiumQuestionRequest.SelectedProduct.builder()
                        .code(code).entityIds(Arrays.asList(entityId)).build())).build();
    }
}
