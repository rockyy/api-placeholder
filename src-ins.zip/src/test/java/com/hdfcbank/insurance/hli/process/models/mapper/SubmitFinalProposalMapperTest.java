package com.hdfcbank.insurance.hli.process.models.mapper;

import com.hdfcbank.insurance.hli.process.models.response.HLISubmitAnswerResponse;
import org.junit.jupiter.api.Test;
import org.mapstruct.factory.Mappers;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

class SubmitFinalProposalMapperTest {
    private final SubmitFinalProposalMapper mapper = Mappers.getMapper(SubmitFinalProposalMapper.class);

    @Test
    void mapsLoanIdentifiersAndProductSpecificQuoteIds() {
        var proposals = List.of(proposal("HDFC_BGR_4", "B1"), proposal("HDFC_ERGO_HCA", "H1"),
                proposal("HDFC_GCP_PLUS", "C1"), proposal("HDFC_3D", "D1"));
        var result = mapper.mapFinalProposal("123", "J123", proposals);
        assertEquals("123", result.getLoanDetail().getParentFileNumber());
        assertEquals("J123", result.getLoanDetail().getJourneyId());
        assertEquals("B1", result.getProductInfo().getBgr().getInsuranceQuoteId());
        assertEquals("H1", result.getProductInfo().getHca().getInsuranceQuoteId());
        assertEquals(List.of("C1", "D1"), result.getProductInfo().getCpplus().stream().map(p -> p.getInsuranceQuoteId()).toList());
    }

    @Test
    void matchingIsCaseInsensitiveAndAbsentProductsAreOmitted() {
        var result = mapper.mapProductInfo(List.of(proposal("hdfc_gcp_plus", "C1")));
        assertNull(result.getBgr());
        assertNull(result.getHca());
        assertEquals(1, result.getCpplus().size());
        assertEquals("C1", result.getCpplus().getFirst().getInsuranceQuoteId());
        assertNull(mapper.getQuoteId(null, "HDFC_3D"));
    }

    private HLISubmitAnswerResponse.Proposal proposal(String code, String quote) {
        return HLISubmitAnswerResponse.Proposal.builder().productCode(code).quoteId(quote).build();
    }
}
