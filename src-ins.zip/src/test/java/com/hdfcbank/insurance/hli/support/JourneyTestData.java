package com.hdfcbank.insurance.hli.support;

import com.hdfcbank.common.models.vo.journey.JourneyData;
import com.hdfcbank.common.models.vo.journey.JourneyDetail;
import java.util.HashMap;
import java.util.Map;

public final class JourneyTestData {
    public static final String JOURNEY_ID = "J123";
    public static final String JOURNEY_NAME = "ETB_HLI";
    public static final String LEAD_ID = "LEAD123";
    public static final String LOAN_NUMBER = "1234567890";

    private JourneyTestData() {
    }

    public static JourneyData journey() {
        Map<String, Map<String, ?>> systemData = new HashMap<>();
        systemData.put("getLoanDetail", new HashMap<>(Map.of(
                "leadId", LEAD_ID,
                "loan", Map.of("loanTerm", "120"),
                "loanEligibility", Map.of("minRateOfInterest", "12"))));
        systemData.put("loanidentifydetails", Map.of(
                "loanidentifydetails", Map.of("loanFileNumber", LOAN_NUMBER)));
        return JourneyData.builder().journeyId(JOURNEY_ID).journeyName(JOURNEY_NAME)
                .referenceNo("REF123").mobileNumber("9876543210")
                .journeyDetail(JourneyDetail.builder().systemData(systemData).build()).build();
    }
}
