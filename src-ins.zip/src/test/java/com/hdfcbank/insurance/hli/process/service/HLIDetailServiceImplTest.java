package com.hdfcbank.insurance.hli.process.service;

import com.hdfcbank.adapters.clients.feign.journey.JourneyServiceFeignClient;
import com.hdfcbank.adapters.vo.UpdateSystemDataJourneyRequest;
import com.hdfcbank.common.models.vo.core.ApiResponse;
import com.hdfcbank.common.models.vo.journey.JourneyData;
import com.hdfcbank.exception.InputValidationException;
import com.hdfcbank.insurance.adapter.process.models.request.IdentifyRequest;
import com.hdfcbank.insurance.adapter.process.models.request.SubmitFinalProposalRequest;
import com.hdfcbank.insurance.adapter.process.models.response.*;
import com.hdfcbank.insurance.adapter.refgen.clients.RefGenServiceFeignClient;
import com.hdfcbank.insurance.adapter.refgen.response.RefGenResponse;
import com.hdfcbank.insurance.hli.common.config.JourneyContextHolder;
import com.hdfcbank.insurance.hli.common.properties.HLIAppProperties;
import com.hdfcbank.insurance.hli.common.properties.ReturnJourneyProperties;
import com.hdfcbank.insurance.hli.process.models.BorrowersEsignDetail;
import com.hdfcbank.insurance.hli.process.models.HLIBorrower;
import com.hdfcbank.insurance.hli.process.models.EsignDocumentStorageDetail;
import com.hdfcbank.insurance.hli.process.models.SubmitFinalProposalCallback;
import com.hdfcbank.insurance.hli.process.models.SignerInfo;
import com.hdfcbank.insurance.hli.process.models.enums.BorrowerEsignStatus;
import com.hdfcbank.insurance.hli.process.models.enums.JourneyEsignStatus;
import com.hdfcbank.insurance.hli.process.models.enums.SourceSystem;
import com.hdfcbank.insurance.hli.process.models.enums.DocumentType;
import com.hdfcbank.insurance.hli.process.models.mapper.GetDetailResponseMapper;
import com.hdfcbank.insurance.hli.process.models.mapper.HLIIdentifyResponseMapper;
import com.hdfcbank.insurance.hli.process.models.mapper.SubmitFinalProposalMapper;
import com.hdfcbank.insurance.hli.process.models.request.HLIIdentifyRequest;
import com.hdfcbank.insurance.hli.process.models.request.ResendESignRequest;
import com.hdfcbank.insurance.hli.process.models.request.HLISubmitAnswerRequest;
import com.hdfcbank.insurance.hli.process.models.response.HLIIdentifyResponse;
import com.hdfcbank.insurance.hli.process.models.response.HLILoanDetailResponse;
import com.hdfcbank.insurance.hli.process.models.response.HLISubmitAnswerResponse;
import com.hdfcbank.insurance.hli.process.service.config.EsignProperties;
import com.hdfcbank.insurance.hli.process.service.impl.HLIDetailServiceImpl;
import com.hdfcbank.insurance.hli.process.service.impl.ProcessServiceCall;
import com.hdfcbank.insurance.hli.scheduler.repo.PurchaseRepo;
import com.hdfcbank.insurance.hli.scheduler.entities.PurchaseIPFStatusEntity;
import com.hdfcbank.insurance.hli.scheduler.model.Status;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.EnumSource;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import tools.jackson.databind.ObjectMapper;
import java.util.List;
import java.util.Map;
import static com.hdfcbank.insurance.hli.common.enums.JourneyStateName.*;
import static com.hdfcbank.insurance.hli.support.JourneyTestData.*;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class HLIDetailServiceImplTest {
    @Mock private HLIIdentifyResponseMapper identifyMapper;
    @Mock private JourneyServiceFeignClient journeyClient;
    @Mock private ProcessServiceCall processCall;
    @Mock private GetDetailResponseMapper detailMapper;
    @Mock private HLIAppProperties appProperties;
    @Mock private ReturnJourneyProperties returnProperties;
    @Mock private RefGenServiceFeignClient referenceClient;
    @Mock private PurchaseRepo purchaseRepo;
    @Mock private SubmitFinalProposalMapper proposalMapper;
    @Mock private EsignProperties esignProperties;
    @Spy private ObjectMapper mapper = new ObjectMapper();
    @InjectMocks private HLIDetailServiceImpl service;
    private JourneyData journeyData;

    @BeforeEach
    void setUp() {
        journeyData = journey();
        JourneyContextHolder.setJourneyData(journeyData);
    }

    @AfterEach
    void clearContext() {
        JourneyContextHolder.clear();
    }

    @ParameterizedTest
    @EnumSource(SourceSystem.class)
    void identifyBuildsSourceSpecificIdentifiersAndMasksResponse(SourceSystem source) {
        var request = HLIIdentifyRequest.builder().loanFileNumber(LOAN_NUMBER)
                .source(source).dob("15/01/1988").build();
        var downstream = new IdentifyResponse();
        var identified = HLIIdentifyResponse.builder().loanFileNumber(LOAN_NUMBER)
                .borrowerFirstName("Test").borrowerDob("15/01/1988").borrowerMobile("9876543210").build();
        when(processCall.identifyServiceCall(any(), eq(JOURNEY_ID))).thenReturn(downstream);
        when(identifyMapper.toHLIIdentifyResponse(downstream)).thenReturn(identified);
        when(referenceClient.generateReferenceNumber(any(), eq(JOURNEY_ID), eq(JOURNEY_NAME)))
                .thenReturn(ApiResponse.success(RefGenResponse.builder().refNumber("REF123").build()));
        var response = service.identify(JOURNEY_NAME, JOURNEY_ID, request);
        assertEquals("******7890", response.getData().getLoanFileNumber());
        assertEquals("** ** 1988", response.getData().getBorrowerDob());
        assertEquals("******3210", response.getData().getBorrowerMobile());
        var processRequest = ArgumentCaptor.forClass(IdentifyRequest.class);
        verify(processCall).identifyServiceCall(processRequest.capture(), eq(JOURNEY_ID));
        assertEquals(source.name(), processRequest.getValue().getLoginMethod());
        assertEquals(source == SourceSystem.STATIC ? 2 : 1, processRequest.getValue().getIdentifiers().size());
        assertTrue(processRequest.getValue().getIdentifiers().stream()
                .anyMatch(i -> "LOAN".equals(i.getIdentifierType()) && LOAN_NUMBER.equals(i.getIdentifierValue())));
        var saves = ArgumentCaptor.forClass(JourneyData.class);
        verify(journeyClient, times(2)).saveJourney(saves.capture());
        assertEquals("REF123", saves.getAllValues().get(1).getReferenceNo());
        assertEquals("15/01/1988", saves.getAllValues().get(1).getProfile().getDateOfBirth());
    }

    @Test
    void failedIdentificationDoesNotGenerateReferenceOrRecordEligibilitySuccess() {
        var request = HLIIdentifyRequest.builder().loanFileNumber(LOAN_NUMBER).source(SourceSystem.DYNAMIC).build();
        when(processCall.identifyServiceCall(any(), eq(JOURNEY_ID))).thenThrow(new IllegalStateException("timeout"));
        assertThrows(IllegalStateException.class, () -> service.identify(JOURNEY_NAME, JOURNEY_ID, request));
        verify(journeyClient, times(1)).saveJourney(any());
        verifyNoInteractions(referenceClient, identifyMapper);
    }

    @Test
    void newLoanDetailPersistsDownstreamDataAndActiveStatus() {
        when(journeyClient.fetchDynamicDataResponse(any())).thenReturn(ApiResponse.success(List.of()));
        var downstream = GetLoanDetailResponse.builder().leadId("NEW_LEAD")
                .loanEligibility(new GetLoanDetailResponse.LoanEligibility()).build();
        var expected = HLILoanDetailResponse.builder().maxIpfLimit("10").build();
        when(processCall.getLoanDetailCall(any(), eq(JOURNEY_ID))).thenReturn(downstream);
        when(detailMapper.toResponse(downstream)).thenReturn(expected);
        assertSame(expected, service.fetchLoanDetail().getData());
        assertEquals("10", downstream.getLoanEligibility().getMaxLoanInLacs());
        var updates = ArgumentCaptor.forClass(UpdateSystemDataJourneyRequest.class);
        verify(journeyClient, times(2)).update(updates.capture());
        assertSame(downstream, updates.getAllValues().get(0).getData().get("getLoanDetail"));
        assertEquals(Map.of("status", "Active"), updates.getAllValues().get(1).getData().get("journeyStatusDetail"));
    }

    @Test
    void cancellationLeavesCurrentJourneyActive() {
        var old = journey();
        old.setJourneyId("OLD_JOURNEY");
        when(journeyClient.fetchDynamicDataResponse(any())).thenReturn(ApiResponse.success(List.of(journeyData, old)));
        service.cancelAllJourneys();
        var update = ArgumentCaptor.forClass(UpdateSystemDataJourneyRequest.class);
        verify(journeyClient).update(update.capture());
        assertEquals("OLD_JOURNEY", update.getValue().getJourneyId());
        assertEquals(Map.of("status", "InActive"), update.getValue().getData().get("journeyStatusDetail"));
    }

    @Test
    void kfsRequestUsesLeadAndLoanNumbersAndRecordsSuccess() {
        var expected = new KFSDetailResponse();
        when(processCall.getKFSDetailCall(any(), eq(JOURNEY_ID))).thenReturn(expected);
        assertSame(expected, service.fetchKFSDetail().getData());
        verify(processCall).getKFSDetailCall(argThat(r -> LEAD_ID.equals(r.getLeadId())
                && LOAN_NUMBER.equals(r.getLoanFileNumber())), eq(JOURNEY_ID));
        var order = inOrder(journeyClient);
        order.verify(journeyClient).updateJourneyState(JOURNEY_ID, KFS_FETCH_INITIATED.name());
        order.verify(journeyClient).updateJourneyState(JOURNEY_ID, KFS_FETCH_SUCCESS.name());
    }

    @Test
    void existingEsignIsReturnedWithoutStartingAnotherSigningRequest() {
        putEsign(JourneyEsignStatus.INITIATED, BorrowerEsignStatus.INITIATED);
        assertEquals(JourneyEsignStatus.INITIATED, service.initiateEsign().getData().getBorrowerEsignDetail().getJourneyEsignStatus());
        verifyNoInteractions(processCall);
    }

    @Test
    void completedSignerMarksJourneySigned() {
        putEsign(JourneyEsignStatus.IN_PROGRESS, BorrowerEsignStatus.IN_PROGRESS);
        var downstream = ESignStatusResponse.builder().signerInfo(List.of(
                ESignStatusResponse.SignerInfo.builder().signerId("S1").status("signed")
                        .signedAt("2026-10-29T10:00:00Z").build())).build();
        when(processCall.eSignStatus(any(), eq(JOURNEY_ID))).thenReturn(downstream);
        var detail = service.esignStatus().getData().getBorrowerEsignDetail();
        assertEquals(JourneyEsignStatus.SIGNED, detail.getJourneyEsignStatus());
        assertEquals(BorrowerEsignStatus.SIGNED, detail.getBorrowersInfo().getFirst().getBorrowerEsignStatus());
        assertEquals("October 29, 2026, 10:00", detail.getBorrowersInfo().getFirst().getSignerInfo().getSignedAt());
    }

    @Test
    void unsignedSignerLeavesJourneyInProgress() {
        putEsign(JourneyEsignStatus.IN_PROGRESS, BorrowerEsignStatus.IN_PROGRESS);
        when(processCall.eSignStatus(any(), eq(JOURNEY_ID))).thenReturn(ESignStatusResponse.builder()
                .signerInfo(List.of(ESignStatusResponse.SignerInfo.builder().signerId("S1").status("unsigned").build())).build());
        var detail = service.esignStatus().getData().getBorrowerEsignDetail();
        assertEquals(JourneyEsignStatus.IN_PROGRESS, detail.getJourneyEsignStatus());
        assertEquals(BorrowerEsignStatus.UNSIGNED, detail.getBorrowersInfo().getFirst().getBorrowerEsignStatus());
    }

    @Test
    void alreadySignedBorrowerDoesNotReceiveAnotherLink() {
        putEsign(JourneyEsignStatus.SIGNED, BorrowerEsignStatus.SIGNED);
        var response = service.resendESignLink(ResendESignRequest.builder().borrowerId("C1").build());
        assertEquals(BorrowerEsignStatus.SIGNED.getValue(), response.getData().getStatus());
        verifyNoInteractions(processCall);
    }

    @Test
    void unknownBorrowerIsRejectedBeforeResending() {
        putEsign(JourneyEsignStatus.SIGNED, BorrowerEsignStatus.SIGNED);
        assertThrows(InputValidationException.class,
                () -> service.resendESignLink(ResendESignRequest.builder().borrowerId("unknown").build()));
        verifyNoInteractions(processCall);
    }

    @Test
    void finalProposalMapsMifDocumentsNomineeAndSignerAndCreatesPurchaseRecord() {
        prepareFinalProposal();
        var expected = new SubmitFinalProposalResponse();
        when(processCall.finalProposalSubmission(any(), eq(JOURNEY_ID))).thenReturn(expected);
        when(proposalMapper.mapFinalProposal(eq(LOAN_NUMBER), anyString(), anyList()))
                .thenReturn(new SubmitFinalProposalCallback.SubmitILPSProposalResponse());
        when(purchaseRepo.save(any(PurchaseIPFStatusEntity.class))).thenAnswer(invocation -> invocation.getArgument(0));

        assertSame(expected, service.submitFinalProposal().getData());

        var submitted = ArgumentCaptor.forClass(SubmitFinalProposalRequest.class);
        verify(processCall).finalProposalSubmission(submitted.capture(), eq(JOURNEY_ID));
        var request = submitted.getValue();
        assertEquals(LEAD_ID, request.getLeadId());
        assertEquals(LOAN_NUMBER, request.getLoanFileNumber());
        assertEquals("DYNAMIC", request.getSourceSystem());
        assertEquals(1, request.getEsignDocumentStorageDetails().size());
        assertEquals("MIF1", request.getEsignDocumentStorageDetails().getFirst().getDocumentReferenceId());
        assertEquals("S1", request.getSignerDetails().getFirst().getSignerId());
        assertEquals("C1", request.getNomineeDetails().getFirst().getBorrowerCustNumber());
        assertEquals("Nominee", request.getNomineeDetails().getFirst().getNomineeFirstName());
        assertEquals("AGENCY1", request.getLglcDetails().getAgencyCode());
        var purchase = ArgumentCaptor.forClass(PurchaseIPFStatusEntity.class);
        verify(purchaseRepo).save(purchase.capture());
        assertEquals(Status.PURCHASED_INITIATED, purchase.getValue().getPurchaseStatus());
        assertEquals("STP", purchase.getValue().getProcessType());
        assertNotNull(purchase.getValue().getCreatedDate());
        verify(journeyClient).update(argThat((UpdateSystemDataJourneyRequest r) ->
                "SUBMIT_FINAL_PROPOSAL_INITIATED".equals(r.getJourneyState().getStateName())));
    }

    @Test
    void failedFinalProposalDoesNotCreatePurchaseRecord() {
        prepareFinalProposal();
        when(processCall.finalProposalSubmission(any(), eq(JOURNEY_ID))).thenThrow(new IllegalStateException("timeout"));
        assertThrows(IllegalStateException.class, service::submitFinalProposal);
        verifyNoInteractions(purchaseRepo);
        verify(journeyClient, never()).update(any(UpdateSystemDataJourneyRequest.class));
    }

    private void prepareFinalProposal() {
        putEsign(JourneyEsignStatus.SIGNED, BorrowerEsignStatus.SIGNED);
        var systemData = journeyData.getJourneyDetail().getSystemData();
        var esign = mapper.convertValue(systemData.get("borrowerEsignDetail"), BorrowersEsignDetail.class);
        esign.setEsignDocumentStorageDetail(List.of(
                EsignDocumentStorageDetail.builder().documentType(DocumentType.MIF).documentReferenceId("MIF1")
                        .signerId("S1").quoteId("Q1").build(),
                EsignDocumentStorageDetail.builder().documentType(DocumentType.KFS).documentReferenceId("KFS1").build()));
        systemData.put("borrowerEsignDetail", mapper.convertValue(esign, Map.class));
        systemData.put("loanidentifyrequest", Map.of("source", "DYNAMIC"));
        systemData.put("lglcDetails", Map.of("lgCode", "LG1", "agencyCode", "AGENCY1"));
        var nominee = Map.of("cust_number", "N1", "nominee_type", "existing", "first_name", "Nominee");
        var proposal = HLISubmitAnswerRequest.builder().productWiseQuestions(List.of(
                HLISubmitAnswerRequest.ProductWiseQuestion.builder().quoteId("Q1").answers(List.of(
                        HLISubmitAnswerRequest.ProductWiseQuestion.Answer.builder().questionKey("nominees")
                                .entityId("C1|nominee").answer(nominee).build())).build())).build();
        systemData.put("proposalRequest", mapper.convertValue(proposal, Map.class));
        systemData.put("proposalResponse", mapper.convertValue(HLISubmitAnswerResponse.builder()
                .proposals(List.of(HLISubmitAnswerResponse.Proposal.builder().quoteId("Q1").productCode("HDFC_3D").build()))
                .build(), Map.class));
    }

    private void putEsign(JourneyEsignStatus journeyStatus, BorrowerEsignStatus borrowerStatus) {
        var detail = new BorrowersEsignDetail();
        detail.setJourneyEsignStatus(journeyStatus);
        detail.setDocumentId("DOC1");
        detail.setBorrowersInfo(List.of(BorrowersEsignDetail.BorrowerInfo.builder()
                .borrower(HLIBorrower.builder().id("C1").build()).borrowerEsignStatus(borrowerStatus)
                .signerInfo(SignerInfo.builder().signerId("S1").build()).build()));
        journeyData.getJourneyDetail().getSystemData().put("borrowerEsignDetail", mapper.convertValue(detail, Map.class));
    }
}
