package com.hdfcbank.insurance.hli.communication.validation;

import com.hdfcbank.insurance.hli.communication.otp.models.annotation.HLICommunicationRequestValidator;
import com.hdfcbank.insurance.hli.communication.otp.models.request.HLIConsentRequest;
import jakarta.validation.ConstraintValidatorContext;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.NullAndEmptySource;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class HLICommunicationRequestValidatorTest {
    private final HLICommunicationRequestValidator validator = new HLICommunicationRequestValidator();
    private final ConstraintValidatorContext context = mock(ConstraintValidatorContext.class, RETURNS_DEEP_STUBS);

    @Test
    void acceptsExplicitAcceptedAndDeclinedConsents() {
        var request = HLIConsentRequest.builder().logInConsentData(List.of(
                consent("mandatory", true), consent("optional", false))).build();
        assertTrue(validator.isValid(request, context));
    }

    @Test
    void rejectsMissingAndEmptyConsents() {
        var request = new HLIConsentRequest();
        assertFalse(validator.isValid(request, context));
        request.setLogInConsentData(List.of());
        assertFalse(validator.isValid(request, context));
    }

    @ParameterizedTest
    @NullAndEmptySource
    void rejectsMissingOrEmptyConsentKey(String key) {
        var request = HLIConsentRequest.builder().logInConsentData(List.of(consent(key, true))).build();
        assertFalse(validator.isValid(request, context));
    }

    @Test
    void rejectsMissingAcceptance() {
        var request = HLIConsentRequest.builder().logInConsentData(List.of(consent("mandatory", null))).build();
        assertFalse(validator.isValid(request, context));
    }

    private HLIConsentRequest.LogInConsentData consent(String key, Boolean accepted) {
        return HLIConsentRequest.LogInConsentData.builder().consentKey(key).consentAccepted(accepted).build();
    }
}
