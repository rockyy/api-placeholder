package com.hdfcbank.insurance.hli.process.models.mapper;

import com.hdfcbank.common.models.vo.journey.JourneyData;
import org.junit.jupiter.api.Test;
import java.math.BigDecimal;
import java.util.List;
import java.util.Map;
import static com.hdfcbank.insurance.hli.support.JourneyTestData.journey;
import static org.junit.jupiter.api.Assertions.*;

class HLIProductMappingTest {
    @Test
    void tenureUsesLargestPolicyTenureCappedByLoanTenure() {
        assertEquals(0, new BigDecimal("10").compareTo(HLIProductMapping.productTenure(List.of("5", "15"), journey())));
        assertEquals(0, new BigDecimal("5").compareTo(HLIProductMapping.productTenure(List.of("3", "5"), journey())));
    }

    @Test
    void singlePolicyTenureIsCappedByLoanTenure() {
        assertEquals(0, new BigDecimal("10").compareTo(HLIProductMapping.productTenure("15", journey())));
        assertEquals(0, new BigDecimal("5").compareTo(HLIProductMapping.productTenure("5", journey())));
    }

    @Test
    void missingPolicyTenureReturnsZero() {
        assertEquals(BigDecimal.ZERO, HLIProductMapping.productTenure(List.of(), journey()));
        assertEquals(BigDecimal.ZERO, HLIProductMapping.productTenure((String) null, journey()));
    }

    @Test
    void calculatesKnownEmiForTwelvePercentInterestAndOneYear() {
        // P=1200, annual interest=12%, n=12 gives EMI=106.6185464140.
        var emi = HLIProductMapping.emiCalculation("1", journey(), "1200");
        assertEquals(0, new BigDecimal("106.6185464140").compareTo(emi));
    }

    @Test
    void listAndSinglePolicyCalculationsAgreeForSameTenure() {
        assertEquals(HLIProductMapping.emiCalculation("5", journey(), "1200"),
                HLIProductMapping.emiCalculation(List.of("3", "5"), journey(), "1200"));
    }

    @Test
    void zeroLoanTenureProducesZeroEmi() {
        JourneyData data = journey();
        data.getJourneyDetail().getSystemData().put("getLoanDetail", Map.of(
                "loan", Map.of("loanTerm", "0"), "loanEligibility", Map.of("minRateOfInterest", "12")));
        assertEquals(BigDecimal.ZERO, HLIProductMapping.emiCalculation("5", data, "1200"));
    }
}
