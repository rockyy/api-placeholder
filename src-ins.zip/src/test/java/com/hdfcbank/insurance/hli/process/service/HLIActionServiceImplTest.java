package com.hdfcbank.insurance.hli.process.service;

import com.hdfcbank.adapters.clients.feign.journey.JourneyServiceFeignClient;
import com.hdfcbank.adapters.vo.UpdateSystemDataJourneyRequest;
import com.hdfcbank.common.models.vo.core.ApiResponse;
import com.hdfcbank.common.models.vo.journey.JourneyData;
import com.hdfcbank.exception.BusinessValidationException;
import com.hdfcbank.insurance.hli.common.core.ProcessLayerAPIResponseValidator;
import com.hdfcbank.insurance.hli.common.core.models.HLIAPIRequestName;
import com.hdfcbank.insurance.hli.process.models.BorrowersEsignDetail;
import com.hdfcbank.insurance.hli.process.models.EsignCallbackUpdate;
import com.hdfcbank.insurance.hli.process.models.HLIBorrower;
import com.hdfcbank.insurance.hli.process.models.SignerInfo;
import com.hdfcbank.insurance.hli.process.models.enums.BorrowerEsignStatus;
import com.hdfcbank.insurance.hli.process.models.enums.CallbackType;
import com.hdfcbank.insurance.hli.process.models.enums.JourneyEsignStatus;
import com.hdfcbank.insurance.hli.process.models.mapper.SubmitFinalProposalMapper;
import com.hdfcbank.insurance.hli.process.models.request.CallbackRequest;
import com.hdfcbank.insurance.hli.process.service.config.EsignProperties;
import com.hdfcbank.insurance.hli.process.service.impl.HLIActionServiceImpl;
import com.hdfcbank.insurance.hli.process.service.impl.ProcessServiceCall;
import com.hdfcbank.insurance.hli.scheduler.model.Status;
import com.hdfcbank.insurance.hli.scheduler.repo.PurchaseRepo;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.dao.DataAccessResourceFailureException;
import tools.jackson.databind.ObjectMapper;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import static com.hdfcbank.insurance.hli.support.JourneyTestData.*;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class HLIActionServiceImplTest {
    @Mock private JourneyServiceFeignClient journeyClient;
    @Mock private ProcessServiceCall processCall;
    @Mock private SubmitFinalProposalMapper proposalMapper;
    @Mock private PurchaseRepo purchaseRepo;
    private final ObjectMapper mapper = new ObjectMapper();
    private HLIActionServiceImpl service;
    private JourneyData journeyData;

    @BeforeEach
    void setUp() {
        journeyData = journey();
        var properties = new EsignProperties();
        properties.setExpiry(5);
        service = new HLIActionServiceImpl(journeyClient, processCall, proposalMapper, mapper, purchaseRepo, properties);
    }

    @Test
    void malformedCallbackFailsBeforeExternalCalls() {
        assertThrows(RuntimeException.class, () -> service.performAction(request(CallbackType.ESIGN_CALLBACK, "invalid")));
        verifyNoInteractions(journeyClient, processCall, purchaseRepo);
    }

    @Test
    void signerUpdateOnlyMarksMatchingBorrowersAndCalculatesOverallStatus() {
        var details = details();
        var callback = new EsignCallbackUpdate();
        var signer = new EsignCallbackUpdate.SignerInfo();
        signer.setSignerId("S1");
        callback.setSignerInfo(List.of(signer));
        service.updateStatus(details, callback);
        assertEquals(BorrowerEsignStatus.SIGNED, details.getBorrowersInfo().getFirst().getBorrowerEsignStatus());
        assertEquals(BorrowerEsignStatus.IN_PROGRESS, details.getBorrowersInfo().getLast().getBorrowerEsignStatus());
        assertEquals(JourneyEsignStatus.UNSIGNED, details.getJourneyEsignStatus());
        signer.setSignerId("S2");
        service.updateStatus(details, callback);
        assertEquals(JourneyEsignStatus.SIGNED, details.getJourneyEsignStatus());
    }

    @Test
    void esignStatusCallbackPersistsUpdatedBorrowerStatuses() {
        journeyData.getJourneyDetail().getSystemData().put("borrowerEsignDetail", mapper.convertValue(details(), Map.class));
        when(journeyClient.fetch(JOURNEY_ID)).thenReturn(journeyData);
        service.performAction(request(CallbackType.ESIGN_CALLBACK,
                "{\"journeyId\":\"J123\",\"signerInfo\":[{\"signerId\":\"S1\"}]}"));
        var update = ArgumentCaptor.forClass(UpdateSystemDataJourneyRequest.class);
        verify(journeyClient).update(update.capture());
        assertEquals("ESIGN_STATUS_CALLBACK_RECEIVED", update.getValue().getJourneyState().getStateName());
        var detail = (BorrowersEsignDetail) update.getValue().getData().get("borrowerEsignDetail");
        assertEquals(BorrowerEsignStatus.SIGNED, detail.getBorrowersInfo().getFirst().getBorrowerEsignStatus());
    }

    @Test
    void esignInitiationCallbackMapsSignerAndConfiguredExpiry() {
        var loan = new HashMap<String, Object>(journeyData.getJourneyDetail().getSystemData().get("getLoanDetail"));
        loan.put("customers", List.of(Map.of("number", "C1", "firstName", "Test")));
        journeyData.getJourneyDetail().getSystemData().put("getLoanDetail", loan);
        journeyData.getJourneyDetail().getSystemData().put("journeyStatusDetail", Map.of("status", "Active"));
        when(journeyClient.fetch(JOURNEY_ID)).thenReturn(journeyData);
        service.performAction(request(CallbackType.ESIGN_REQUEST_SUCCESS,
                "{\"journeyId\":\"J123\",\"esignInitiatedDate\":\"01-01-2026\",\"esignDocumentStorageDetail\":[],"
                        + "\"esignResponse\":{\"docketId\":\"D1\",\"documentId\":\"DOC1\","
                        + "\"signerInfo\":[{\"signerRefId\":\"C1\",\"signerId\":\"S1\"}]}}"));
        var updates = ArgumentCaptor.forClass(UpdateSystemDataJourneyRequest.class);
        verify(journeyClient, times(2)).update(updates.capture());
        var detail = (BorrowersEsignDetail) updates.getAllValues().getFirst().getData().get("borrowerEsignDetail");
        assertEquals("DOC1", detail.getDocumentId());
        assertEquals("06-01-2026", detail.getExpireAt());
        assertEquals(JourneyEsignStatus.IN_PROGRESS, detail.getJourneyEsignStatus());
        assertEquals("S1", detail.getBorrowersInfo().getFirst().getSignerInfo().getSignerId());
    }

    @Test
    void cancelCallbackMarksMatchingJourneysInactive() {
        var downstream = ApiResponse.success(List.of(journeyData));
        when(journeyClient.fetchDynamicDataResponse(any())).thenReturn(downstream);
        try (var validator = mockStatic(ProcessLayerAPIResponseValidator.class)) {
            validator.when(() -> ProcessLayerAPIResponseValidator.validateApiResponse(HLIAPIRequestName.ACTION, downstream))
                    .thenReturn(List.of(journeyData));
            service.performAction(request(CallbackType.CANCEL_LEAD, "{\"leadId\":\"LEAD123\",\"loanFileNumber\":\"1234567890\"}"));
        }
        verify(journeyClient).fetchDynamicDataResponse(argThat(r -> "AND".equals(r.getOperationType())
                && r.getFilters().containsValue(LEAD_ID) && r.getFilters().containsValue(LOAN_NUMBER)));
        verify(journeyClient).update(argThat((UpdateSystemDataJourneyRequest r) ->
                "JOURNEY_MARKED_INACTIVE".equals(r.getJourneyState().getStateName())));
    }

    @Test
    void finalProposalCallbackUpdatesPurchaseStatus() {
        when(journeyClient.fetch(JOURNEY_ID)).thenReturn(journeyData);
        service.performAction(request(CallbackType.SUBMIT_FINAL_PROPOSAL_CALLBACK, "{\"journeyId\":\"J123\"}"));
        verify(purchaseRepo).updateStatus(eq(JOURNEY_ID), eq(Status.PURCHASED), any());
        verify(journeyClient, times(2)).update(any(UpdateSystemDataJourneyRequest.class));
    }

    @Test
    void failedPurchaseStatusUpdateIsReportedAsBusinessValidationError() {
        when(journeyClient.fetch(JOURNEY_ID)).thenReturn(journeyData);
        doThrow(new DataAccessResourceFailureException("database unavailable"))
                .when(purchaseRepo).updateStatus(eq(JOURNEY_ID), eq(Status.PURCHASED), any());
        assertThrows(BusinessValidationException.class,
                () -> service.performAction(request(CallbackType.SUBMIT_FINAL_PROPOSAL_CALLBACK, "{\"journeyId\":\"J123\"}")));
    }

    private CallbackRequest request(CallbackType type, String data) {
        return CallbackRequest.builder().callbackType(type).data(data).build();
    }

    private BorrowersEsignDetail details() {
        var detail = new BorrowersEsignDetail();
        detail.setBorrowersInfo(List.of(borrower("C1", "S1"), borrower("C2", "S2")));
        return detail;
    }

    private BorrowersEsignDetail.BorrowerInfo borrower(String id, String signerId) {
        return BorrowersEsignDetail.BorrowerInfo.builder().borrower(HLIBorrower.builder().id(id).build())
                .signerInfo(SignerInfo.builder().signerId(signerId).build())
                .borrowerEsignStatus(BorrowerEsignStatus.IN_PROGRESS).build();
    }
}
