package com.hdfcbank.insurance.hli.communication.controller;

import com.hdfcbank.common.models.vo.core.ApiResponse;
import com.hdfcbank.insurance.hli.communication.otp.models.request.HLIValidateRequest;
import com.hdfcbank.insurance.hli.communication.otp.models.response.HLIConsentResponse;
import com.hdfcbank.insurance.hli.communication.otp.models.response.HLIValidateResponse;
import com.hdfcbank.insurance.hli.communication.otp.service.CommunicationService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import static com.hdfcbank.insurance.hli.support.JourneyTestData.*;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class HLICommunicationControllerTest {
    @Mock private CommunicationService service;
    @InjectMocks private HLICommunicationController controller;

    @Test
    void generateOtpPassesJourneyIdentifiersAndReturnsServiceResponse() {
        var expected = ApiResponse.success(new HLIConsentResponse());
        when(service.generateOTP(JOURNEY_NAME, JOURNEY_ID)).thenReturn(expected);
        assertSame(expected, controller.sendOTP(JOURNEY_NAME, JOURNEY_ID));
    }

    @Test
    void validationPassesRequestAndReturnsUnmatchedOtpResult() {
        var request = new HLIValidateRequest();
        var expected = ApiResponse.success(HLIValidateResponse.builder().otpValidated(false).incorrectAttempts(1).build());
        when(service.validateCustomer(JOURNEY_NAME, JOURNEY_ID, request)).thenReturn(expected);
        assertSame(expected, controller.validateOTP(JOURNEY_NAME, JOURNEY_ID, request));
    }

    @Test
    void generationFailurePropagates() {
        var failure = new IllegalStateException("communication unavailable");
        when(service.generateOTP(JOURNEY_NAME, JOURNEY_ID)).thenThrow(failure);
        assertSame(failure, assertThrows(IllegalStateException.class,
                () -> controller.sendOTP(JOURNEY_NAME, JOURNEY_ID)));
    }
}
