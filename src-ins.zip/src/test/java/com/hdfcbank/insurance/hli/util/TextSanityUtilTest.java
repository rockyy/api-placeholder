package com.hdfcbank.insurance.hli.util;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class TextSanityUtilTest {
    @Test
    void replacesControlCharactersWithSpaces() {
        assertEquals("a b c d", TextSanityUtil.sanitize("a\nb\rc\td"));
    }

    @Test
    void logSanitizerReplacesControlCharactersWithUnderscores() {
        assertEquals("a_b_c_d", TextSanityUtil.sanitizeForLog("a\nb\rc\td"));
        assertEquals("123", TextSanityUtil.sanitizeForLog(123));
    }

    @Test
    void preservesNullAndPlainText() {
        assertNull(TextSanityUtil.sanitize(null));
        assertNull(TextSanityUtil.sanitizeForLog(null));
        assertEquals("plain text", TextSanityUtil.sanitize("plain text"));
    }
}
