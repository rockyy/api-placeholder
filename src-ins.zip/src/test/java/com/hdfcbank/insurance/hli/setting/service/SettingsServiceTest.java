package com.hdfcbank.insurance.hli.setting.service;

import com.hdfcbank.adapters.clients.feign.config.ConfigServiceFeignClient;
import com.hdfcbank.adapters.clients.feign.consents.ConsentsServiceFeignClient;
import com.hdfcbank.adapters.vo.FetchConsentsRequest;
import com.hdfcbank.adapters.vo.FetchConsentsResponse;
import com.hdfcbank.common.models.vo.core.ApiResponseStatus;
import com.hdfcbank.insurance.hli.setting.models.SettingsDataExtension;
import com.hdfcbank.insurance.hli.setting.utility.SettingUtility;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import tools.jackson.databind.ObjectMapper;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class SettingsServiceTest {
    @Mock private ConfigServiceFeignClient configClient;
    @Mock private ConsentsServiceFeignClient consentsClient;
    @Spy private SettingUtility utility = new SettingUtility();
    @InjectMocks private SettingsService service;
    private static final String JOURNEY_NAME = "ETB_HLI";

    @Test
    void cacheMissFetchesAndMergesConfigurationAndConsents() {
        when(configClient.getData(JOURNEY_NAME, "json")).thenReturn("{\"maintenanceWindow\":\"disabled\"}");
        when(consentsClient.fetchConsentsByJourneyName(any(FetchConsentsRequest.class)))
                .thenReturn(List.of(FetchConsentsResponse.Consent.builder().key("mandatory").build()));
        var response = service.fetch(SettingsDataExtension.json, JOURNEY_NAME);
        assertEquals(ApiResponseStatus.success().getCode(), response.getStatus().getCode());
        assertEquals(ApiResponseStatus.success().getMessage(), response.getStatus().getMessage());
        assertEquals("disabled", response.getData().path("maintenanceWindow").asText());
        assertEquals("mandatory", response.getData().path("consents").get(0).path("key").asText());
        verify(utility).evictCache(JOURNEY_NAME);
        verify(consentsClient).fetchConsentsByJourneyName(argThat(r -> JOURNEY_NAME.equals(r.getJourneyName())));
    }

    @Test
    void cacheHitReturnsSettingsWithoutExternalCalls() {
        var cached = new ObjectMapper().createObjectNode().put("cached", true);
        doReturn(cached).when(utility).mergeConfigAndConsents(null, JOURNEY_NAME);
        var response = service.fetch(SettingsDataExtension.json, JOURNEY_NAME);
        assertSame(cached, response.getData());
        assertEquals(ApiResponseStatus.success().getCode(), response.getStatus().getCode());
        verify(utility, never()).evictCache(anyString());
        verifyNoInteractions(configClient, consentsClient);
    }

    @Test
    void invalidConfigurationJsonPropagatesParsingFailure() {
        when(consentsClient.fetchConsentsByJourneyName(any())).thenReturn(List.of());
        when(configClient.getData(JOURNEY_NAME, "json")).thenReturn("invalid-json");
        assertThrows(RuntimeException.class, () -> service.fetch(SettingsDataExtension.json, JOURNEY_NAME));
    }

    @Test
    void consentFetchFailureStopsConfigurationFetch() {
        var failure = new IllegalStateException("consents unavailable");
        when(consentsClient.fetchConsentsByJourneyName(any())).thenThrow(failure);
        assertSame(failure, assertThrows(IllegalStateException.class,
                () -> service.fetch(SettingsDataExtension.json, JOURNEY_NAME)));
        verifyNoInteractions(configClient);
    }
}
