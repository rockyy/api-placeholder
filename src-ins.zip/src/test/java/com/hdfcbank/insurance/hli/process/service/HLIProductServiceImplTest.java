package com.hdfcbank.insurance.hli.process.service;

import com.hdfcbank.adapters.clients.feign.journey.JourneyServiceFeignClient;
import com.hdfcbank.adapters.vo.UpdateSystemDataJourneyRequest;
import com.hdfcbank.common.models.vo.journey.JourneyData;
import com.hdfcbank.insurance.adapter.process.models.request.RecommendedProductRequest;
import com.hdfcbank.insurance.adapter.process.models.response.ContentGroupResponse;
import com.hdfcbank.insurance.adapter.process.models.response.CurateProductResponse;
import com.hdfcbank.insurance.adapter.process.models.response.RecommendedProductResponse;
import com.hdfcbank.insurance.hli.common.config.JourneyContextHolder;
import com.hdfcbank.insurance.hli.process.models.request.DecisionParameterConfig;
import com.hdfcbank.insurance.hli.process.service.impl.HLIProductServiceImpl;
import com.hdfcbank.insurance.hli.process.service.impl.ProcessServiceCall;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import tools.jackson.databind.ObjectMapper;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import static com.hdfcbank.insurance.hli.support.JourneyTestData.*;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class HLIProductServiceImplTest {
    @Mock private ProcessServiceCall processCall;
    @Mock private JourneyServiceFeignClient journeyClient;
    private HLIProductServiceImpl service;
    private DecisionParameterConfig config;
    private JourneyData journeyData;

    @BeforeEach
    void setUp() {
        config = new DecisionParameterConfig();
        config.setParameters(Map.of("lead", "getLoanDetail.leadId"));
        journeyData = journey();
        JourneyContextHolder.setJourneyData(journeyData);
        service = new HLIProductServiceImpl(config, processCall, journeyClient, new ObjectMapper());
    }

    @AfterEach
    void clearContext() {
        JourneyContextHolder.clear();
    }

    @Test
    void decisionParametersSelectPrimaryBorrowerAndIncome() {
        journeyData.getJourneyDetail().getSystemData().put("getLoanDetail", Map.of(
                "leadId", LEAD_ID,
                "customers", List.of(
                        Map.of("capacity", "C", "income", Map.of("consideredForEligibility", "N")),
                        Map.of("capacity", "B", "income", Map.of("consideredForEligibility", "Y")))));
        config.setParameters(Map.of("lead", "getLoanDetail.leadId",
                "capacity", "getLoanDetail.customers.capacity",
                "income", "getLoanDetail.customers.income.consideredForEligibility"));
        var result = service.buildDecisionParameters(journeyData, config).stream()
                .collect(Collectors.toMap(RecommendedProductRequest.DecisionParameter::getKey,
                        RecommendedProductRequest.DecisionParameter::getValue));
        assertEquals(Map.of("lead", LEAD_ID, "capacity", "B", "income", "Y"), result);
    }

    @Test
    void decisionParameterWithoutPrimaryBorrowerHasNullValue() {
        config.setParameters(Map.of("capacity", "getLoanDetail.customers.capacity"));
        var result = service.buildDecisionParameters(journeyData, config);
        assertEquals(1, result.size());
        assertNull(result.getFirst().getValue());
    }

    @Test
    void curateProductsMapsResponseAndPassesLeadAndJourneyIds() {
        var downstream = CurateProductResponse.builder().products(List.of()).build();
        when(processCall.curateProductCall(eq(JOURNEY_ID), any())).thenReturn(downstream);
        var response = service.getCurateProducts();
        assertEquals("0000", response.getStatus().getCode());
        assertTrue(response.getData().getProducts().isEmpty());
        verify(processCall).curateProductCall(eq(JOURNEY_ID), argThat(r -> LEAD_ID.equals(r.getLeadId())));
    }

    @Test
    void recommendationFailureStopsContentFetchAndJourneyUpdate() {
        var failure = new IllegalStateException("recommendations unavailable");
        when(processCall.recommendedProductCall(eq(JOURNEY_ID), any())).thenThrow(failure);
        assertSame(failure, assertThrows(IllegalStateException.class, service::getRecommendedProducts));
        verify(processCall, never()).contentGroupCall(any(), anyString());
        verifyNoInteractions(journeyClient);
    }

    @Test
    void insuranceProductsMergeCatalogAndPersistRecommendation() {
        var recommended = new RecommendedProductResponse();
        var catalog = CurateProductResponse.builder().products(List.of()).build();
        when(processCall.recommendedProductCall(eq(JOURNEY_ID), any())).thenReturn(recommended);
        when(processCall.curateProductCall(eq(JOURNEY_ID), any())).thenReturn(catalog);
        when(processCall.contentGroupCall(any(), eq(JOURNEY_ID))).thenReturn(new ContentGroupResponse());
        var response = service.getInsuranceProducts();
        assertSame(recommended, response.getData());
        assertEquals(List.of(), response.getData().getProducts());
        verify(journeyClient).update(argThat((UpdateSystemDataJourneyRequest r) -> JOURNEY_ID.equals(r.getJourneyId())
                && "RECOMMENDED_PRODUCT_SUCCESS".equals(r.getJourneyState().getStateName())
                && r.getData().get("RECOMMENDED_PRODUCT") == recommended));
        var request = ArgumentCaptor.forClass(RecommendedProductRequest.class);
        verify(processCall).recommendedProductCall(eq(JOURNEY_ID), request.capture());
        assertEquals(LEAD_ID, request.getValue().getLeadId());
        assertEquals(LEAD_ID, request.getValue().getDecisionParameters().getFirst().getValue());
    }
}
