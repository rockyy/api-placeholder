package com.hdfcbank.insurance.hli.util;

import com.hdfcbank.insurance.hli.common.enums.JourneyStateName;
import org.junit.jupiter.api.Test;
import tools.jackson.databind.ObjectMapper;
import java.util.List;
import java.util.Map;
import static com.hdfcbank.insurance.hli.support.JourneyTestData.*;
import static org.junit.jupiter.api.Assertions.*;

class JourneyUtilTest {
    private final ObjectMapper mapper = new ObjectMapper();

    @Test
    void extractsNestedLeadIdAndReturnsEmptyStringForMissingPath() {
        assertEquals(LEAD_ID, JourneyUtil.extractLeadId(journey()));
        assertEquals("", JourneyUtil.getDataFromJourneyService(Map.of(), "missing.field"));
        assertEquals("", JourneyUtil.getDataFromJourneyService(null, "missing"));
    }

    @Test
    void pathLookupTraversesMapsAndLists() {
        var root = Map.of("customers", List.of(Map.of("number", "C1"), Map.of("number", "C2")));
        assertEquals("C1", JourneyUtil.getByPath(root, "customers.number"));
        assertNull(JourneyUtil.getByPath(root, "missing"));
        assertNull(JourneyUtil.getByPath(null, "customers"));
    }

    @Test
    void jsonPathSupportsFilteredEntitiesAndArrayValues() {
        var root = mapper.readTree("{\"customers\":[{\"id\":\"C1\",\"income\":100},{\"id\":\"C2\",\"income\":200}],\"values\":[\"first\",\"second\"]}");
        assertEquals("200", JourneyUtil.getValueFromJsonPath(root, "customers[?(@.id=='c2')].income"));
        assertEquals("first", JourneyUtil.getValueFromJsonPath(root, "values"));
        assertNull(JourneyUtil.getValueFromJsonPath(root, "customers[?(@.id=='missing')].income"));
        assertNull(JourneyUtil.getValueFromJsonPath(root, "missing.path"));
    }

    @Test
    void updateRequestCarriesJourneyStateAndDataUnderPageName() {
        var payload = Map.of("status", "Active");
        var request = JourneyUtil.toUpdateSystemDataRequest(JOURNEY_ID, "journeyStatusDetail", payload, JourneyStateName.GET_DETAIL_SUCCESS);
        assertEquals(JOURNEY_ID, request.getJourneyId());
        assertEquals("GET_DETAIL_SUCCESS", request.getJourneyState().getStateName());
        assertSame(payload, request.getData().get("journeyStatusDetail"));
    }
}
