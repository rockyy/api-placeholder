package com.hdfcbank.insurance.hli.scheduler;

import com.hdfcbank.insurance.adapter.process.models.request.CancelLeadsResponse;
import com.hdfcbank.insurance.adapter.process.models.response.IPFStatusResponse;
import com.hdfcbank.insurance.hli.common.properties.IPFSchedulerConfig;
import com.hdfcbank.insurance.hli.process.models.SubmitFinalProposalCallback.SubmitILPSProposalResponse;
import com.hdfcbank.insurance.hli.process.models.enums.CallbackType;
import com.hdfcbank.insurance.hli.process.service.CallbackService;
import com.hdfcbank.insurance.hli.process.service.impl.ProcessServiceCall;
import com.hdfcbank.insurance.hli.scheduler.entities.PurchaseIPFStatusEntity;
import com.hdfcbank.insurance.hli.scheduler.model.IPFStatus;
import com.hdfcbank.insurance.hli.scheduler.model.Status;
import com.hdfcbank.insurance.hli.scheduler.repo.PurchaseRepo;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.EnumSource;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import static com.hdfcbank.insurance.hli.support.JourneyTestData.*;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class IPFSchedulerServiceTest {
    @Mock private ProcessServiceCall processCall;
    @Mock private PurchaseRepo repository;
    @Mock private CallbackService callbackService;
    @Mock private ScheduledExecutorService scheduler;
    @Mock private ExecutorService workers;
    private IPFSchedulerService service;

    @BeforeEach
    void setUp() {
        var config = new IPFSchedulerConfig();
        var values = new IPFSchedulerConfig.Config();
        values.setEntitiesToProcess(2);
        values.setEntitiesProcessDuration(1);
        config.setConfig(values);
        service = new IPFSchedulerService(processCall, repository, callbackService, config);
        // Capture scheduled work and execute it inline; no real timers or threads are started.
        ReflectionTestUtils.setField(service, "scheduler", scheduler);
        ReflectionTestUtils.setField(service, "asyncExecutor", workers);
    }

    @Test
    void emptyRepositoryDoesNotScheduleOrCallDownstream() {
        when(repository.findByJourneyNameAndPurchaseStatusInAndIpfStatusIn(eq(JOURNEY_NAME), anyList(), anyList()))
                .thenReturn(List.of());
        service.processRecords(List.of());
        verify(scheduler, never()).scheduleAtFixedRate(any(), anyLong(), anyLong(), any());
        verifyNoInteractions(processCall, callbackService);
    }

    @Test
    void buildsPolicyRequestAndPersistsDisbursementSuccess() {
        var entity = entity("REF1");
        var response = response(IPFStatus.FD_DBMD);
        when(processCall.checkIPFStatus(any(), eq(JOURNEY_ID))).thenReturn(response);
        process(List.of(entity));
        assertEquals(Status.SUCCESS, entity.getPurchaseStatus());
        assertEquals(IPFStatus.FD_DBMD.getIpfStatusName(), entity.getIpfStatus());
        assertSame(response, entity.getPurchaseResponse());
        assertNotNull(entity.getModifiedDate());
        verify(processCall).checkIPFStatus(argThat(r -> JOURNEY_ID.equals(r.getJourneyId())
                && LOAN_NUMBER.equals(r.getParentFileNumber()) && r.getPolicy().size() == 3), eq(JOURNEY_ID));
        verify(repository, times(2)).save(entity);
        verify(repository, never()).findByJourneyNameAndPurchaseStatusInAndIpfStatusIn(anyString(), anyList(), anyList());
    }

    @ParameterizedTest
    @EnumSource(value = IPFStatus.class, names = {"CL", "CN"})
    void closedOrCancelledLoanCancelsLeadsAndDispatchesCallback(IPFStatus status) {
        var entity = entity("REF1");
        when(processCall.checkIPFStatus(any(), eq(JOURNEY_ID))).thenReturn(response(status));
        var cancelled = new CancelLeadsResponse();
        cancelled.setSuccessCancelledLeads(List.of(LEAD_ID));
        when(processCall.cancelLead(any(), eq(JOURNEY_ID))).thenReturn(cancelled);
        process(List.of(entity));
        assertEquals(Status.SUCCESS, entity.getPurchaseStatus());
        verify(callbackService).performAction(argThat(r -> r.getCallbackType() == CallbackType.CANCEL_LEAD
                && r.getData().contains(LEAD_ID) && r.getData().contains(LOAN_NUMBER)));
    }

    @Test
    void nonTerminalStatusRemainsInProgress() {
        var entity = entity("REF1");
        when(processCall.checkIPFStatus(any(), eq(JOURNEY_ID))).thenReturn(response(IPFStatus.APPR));
        process(List.of(entity));
        assertEquals(Status.IN_PROGRESS, entity.getPurchaseStatus());
        assertEquals(IPFStatus.APPR.getIpfStatusName(), entity.getIpfStatus());
        verifyNoInteractions(callbackService);
    }

    @Test
    void failedDownstreamCallDoesNotPreventProcessingAnotherRecord() {
        var first = entity("REF1");
        var second = entity("REF2");
        when(processCall.checkIPFStatus(any(), eq(JOURNEY_ID)))
                .thenThrow(new IllegalStateException("first call failed")).thenReturn(response(IPFStatus.FD_DBMD));
        process(List.of(first, second));
        verify(processCall, times(2)).checkIPFStatus(any(), eq(JOURNEY_ID));
        assertEquals(Status.SUCCESS, second.getPurchaseStatus());
    }

    private void process(List<PurchaseIPFStatusEntity> entities) {
        when(workers.submit(any(Runnable.class))).thenAnswer(invocation -> {
            invocation.getArgument(0, Runnable.class).run();
            return CompletableFuture.completedFuture(null);
        });
        service.processRecords(entities);
        var task = ArgumentCaptor.forClass(Runnable.class);
        verify(scheduler).scheduleAtFixedRate(task.capture(), eq(0L), eq(1L), eq(TimeUnit.SECONDS));
        task.getValue().run();
    }

    private IPFStatusResponse response(IPFStatus status) {
        return IPFStatusResponse.builder().ipfStatus(status.getIpfStatusName())
                .journeyId(JOURNEY_ID).parentFileNumber(LOAN_NUMBER).build();
    }

    private PurchaseIPFStatusEntity entity(String id) {
        var product = SubmitILPSProposalResponse.Product.builder().insuranceQuoteId("Q1").build();
        return PurchaseIPFStatusEntity.builder().id(id).productPurchaseRequest(
                SubmitILPSProposalResponse.builder()
                        .loanDetail(SubmitILPSProposalResponse.LoanDetailResponse.builder()
                                .journeyId(JOURNEY_ID).parentFileNumber(LOAN_NUMBER).build())
                        .productInfo(SubmitILPSProposalResponse.ProductInfoResponse.builder()
                                .bgr(product).hca(product).cpplus(List.of(product)).build()).build()).build();
    }
}
