package com.hdfcbank.insurance.hli.util;

import com.hdfcbank.insurance.hli.process.models.response.HLIIdentifyResponse;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import static org.junit.jupiter.api.Assertions.*;

class HLIFieldMaskingTest {
    @ParameterizedTest
    @CsvSource({"1234567890,******7890", "1234,1234", "123,123"})
    void masksLoanNumberExceptLastFourCharacters(String input, String expected) {
        assertEquals(expected, HLIFieldMasking.maskLoanFileNumber(input));
    }

    @ParameterizedTest
    @CsvSource({"15/01/1988,** ** 1988", "15-Jan-1988,** *** 1988", "1988,1988"})
    void masksDayAndMonthForSupportedDobSeparators(String input, String expected) {
        assertEquals(expected, HLIFieldMasking.maskBorrowerDob(input));
    }

    @ParameterizedTest
    @CsvSource({"+919876543210,+91******3210", "9876543210,******3210", "3210,3210"})
    void masksMobileAndPreservesCountryCode(String input, String expected) {
        assertEquals(expected, HLIFieldMasking.maskBorrowerMobile(input));
    }

    @Test
    void handlesNullValues() {
        assertNull(HLIFieldMasking.maskLoanFileNumber(null));
        assertNull(HLIFieldMasking.maskBorrowerDob(null));
        assertNull(HLIFieldMasking.maskBorrowerMobile(null));
    }

    @Test
    void masksAllIdentifyResponseFields() {
        var response = HLIIdentifyResponse.builder().loanFileNumber("1234567890")
                .borrowerDob("15/01/1988").borrowerMobile("+919876543210").borrowerFirstName("Test").build();
        HLIFieldMasking.fieldsMasking(response);
        assertEquals("******7890", response.getLoanFileNumber());
        assertEquals("** ** 1988", response.getBorrowerDob());
        assertEquals("+91******3210", response.getBorrowerMobile());
        assertEquals("Test", response.getBorrowerFirstName());
    }
}
