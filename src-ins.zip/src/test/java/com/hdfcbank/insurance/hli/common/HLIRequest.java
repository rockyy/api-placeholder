package com.hdfcbank.insurance.hli.common;

public class HLIRequest {

    public static final String SAMPLE_IDENTIFY_JSON = """
            {
              "status": {
                "code": "0000",
                "message": "success"
              },
              "data": {
                "isEligible": "Y",
                "loanFileNumber": "******6789",
                "borrowerDob": "** ** 1988",
                "borrowerMobile": "+91******3210",
                "borrowerFirstName": "Bill"
              }
            }""";

    public static final String SAMPLE_CURATE_PRODUCT_JSON = """
            {
              "status": {
                "code": "0000",
                "message": "success"
              },
              "data": {
                "timestamp": null,
                "products": [
                  {
                    "code": "DEMO2_PRODUCT_GSM_LAP",
                    "name": "Group Secure Mind (Standalone)",
                    "category": "HEALTH",
                    "productConfig": [
                      { "key": "name", "value": "Group Secure Mind (Standalone)" },
                      { "key": "description", "value": "Peace of Mind: Essential Insurance for Personal Accidents and Critical Illnesses" },
                      { "key": "minAge", "value": "18" },
                      { "key": "maxAge", "value": "65" },
                      { "key": "haveMedicalQuestions", "value": "TRUE" },
                      { "key": "minSiPerPolicy", "value": "100000" },
                      { "key": "maxSiPerPolicy", "value": "40000000" },
                      { "key": "dependentProducts", "value": "DEMO2_PRODUCT_GHP" },
                      { "key": "minTenure", "value": "1" },
                      { "key": "maxTenure", "value": "5" }
                    ],
                    "covers": [],
                    "features": [
                      { "code": "feature_1", "name": "Feature 1", "description": "Feature description", "order": null }
                    ],
                    "livePremiumRates": null,
                    "popularity": null
                  }
                ],
                "customers": null
              }
            }""";

    public static final String SAMPLE_RECOMMENDED_PRODUCT_JSON = """
            {
              "status": {
                "code": "0000",
                "message": "success"
              },
              "data": {
                "recommendationCombos": [
                  {
                    "comboCode": "GOLD_FIXED_COMBO",
                    "comboName": "Gold",
                    "totalPremium": "38089.0",
                    "sumInsured": "",
                    "product": [
                      {
                        "code": "MEDIBUDDY_TOTAL_CARE",
                        "suggestedPlan": "MediBuddy 3 year plan - 17999",
                        "premium": 12999.0,
                        "suggestedTenure": 3,
                        "features": [
                          {
                            "code": "feature_1",
                            "name": "Feature 1",
                            "description": "Feature description",
                            "order": null
                          }
                        ]
                      }
                    ]
                  }
                ]
              }
            }""";
    public static final String SAMPLE_PREMIUM_PRODUCT_JSON = """
            {
              "status": {
                "code": "0000",
                "message": "success"
              },
              "data": {
                "genericQuestions": [],
                "productWiseQuestions": [
                  {
                    "code": "HDFC_GCP_PLUS",
                    "quoteId": null,
                    "questions": [
                      {
                        "questionKey": "tenure",
                        "question": "Tenure",
                        "valueType": "dropdown",
                        "options": ["1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16"],
                        "sequence": 1,
                        "validations": {
                          "validationType": null,
                          "validationValue": null,
                          "validationMessage": null
                        },
                        "mandatory": false
                      },
                      {
                        "questionKey": "sum_insured",
                        "question": "Sum Insured",
                        "valueType": "number",
                        "options": [],
                        "sequence": 2,
                        "validations": {
                          "validationType": null,
                          "validationValue": "750000,1250000",
                          "validationMessage": "Sum Insured Should be between 750000 and 1250000"
                        },
                        "mandatory": false
                      }
                    ]
                  }
                ]
              }
            }""";

    public static String generateOTPSampleJson = """
            {
              "status": {
                "code": "0000",
                "message": "success"
              },
              "data": {
                "txnRef": "viJ3NQUQ3wbfE6J5COLRBlcqIUl2pyCDjvONimhg+WnEdQYtVTEoHzVxB8tWV7iZQcf7y0LC+Kei2/Po7IVguIX8SdKD30RoPXD1h+QKuhGtVwX7GKAAYbsD7y5y72z+Wai34TiANgsJ3opGzVI8Qv45hHP88YAB8loffWbfRkQ=",
                "retryOtpAttemptsConsumed": null,
                "retryOtpAttemptsLeft": null,
                "verifyOtpAttemptsConsumed": null,
                "verifyOtpAttemptsLeft": null
              }
            }""";

    public static final String validateOTPSampleJson = """
            {
                "status": {
                    "code": "0000",
                    "message": "success"
                },
                "data": {
                    "incorrectAttempts": 0
                }
            }""";


    public static final String fetchPricingSampleJson= """
            {
                "mode": "INITIATE_QUOTES",
                "product": [
                    {
                        "code": "HDFC_3D",
                        "answers": [
                            {
                                "entityId": "UCIC98765",
                                "questionKey": "sum_insured",
                                 "answer": "1610000.0"
            
                            },
                            {
                                "entityId": "UCIC98765",
                                "questionKey": "tenure",
                                "answer": "10"
                            }
                        ]
                    }
                ]
            }""";
}
