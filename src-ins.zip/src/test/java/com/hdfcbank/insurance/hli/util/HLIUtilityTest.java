package com.hdfcbank.insurance.hli.util;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.NullAndEmptySource;
import org.junit.jupiter.params.provider.ValueSource;
import static org.junit.jupiter.api.Assertions.*;

class HLIUtilityTest {
    @ParameterizedTest
    @NullAndEmptySource
    @ValueSource(strings = {" ", "null", "NULL", "invalid"})
    void missingOrInvalidNumbersReturnZero(String value) {
        assertEquals(0.0, HLIUtility.mapToDouble(value));
    }

    @Test
    void convertsNumberAndTrimmedNumericString() {
        assertEquals(12.5, HLIUtility.mapToDouble(12.5));
        assertEquals(12.0, HLIUtility.mapToDouble(12));
        assertEquals(12.5, HLIUtility.mapToDouble(" 12.5 "));
    }
}
