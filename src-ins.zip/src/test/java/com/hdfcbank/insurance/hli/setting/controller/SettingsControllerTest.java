package com.hdfcbank.insurance.hli.setting.controller;

import com.hdfcbank.insurance.hli.setting.models.SettingsDataExtension;
import com.hdfcbank.insurance.hli.setting.models.SettingsRequest;
import com.hdfcbank.insurance.hli.setting.models.SettingsResponse;
import com.hdfcbank.insurance.hli.setting.service.SettingsService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class SettingsControllerTest {
    @Mock private SettingsService settingsService;
    @InjectMocks private SettingsController controller;

    @Test
    void fetchPassesParsedExtensionAndJourneyNameToService() {
        var request = SettingsRequest.builder().extension("json").build();
        var expected = SettingsResponse.builder().build();
        when(settingsService.fetch(SettingsDataExtension.json, "ETB_HLI")).thenReturn(expected);
        assertSame(expected, controller.fetch(request, "ETB_HLI"));
    }

    @Test
    void unsupportedExtensionDoesNotInvokeService() {
        var request = SettingsRequest.builder().extension("xml").build();
        assertThrows(IllegalArgumentException.class, () -> controller.fetch(request, "ETB_HLI"));
        verifyNoInteractions(settingsService);
    }

    @Test
    void fetchPropagatesServiceFailure() {
        var request = SettingsRequest.builder().extension("json").build();
        var failure = new IllegalStateException("config unavailable");
        when(settingsService.fetch(SettingsDataExtension.json, "ETB_HLI")).thenThrow(failure);
        assertSame(failure, assertThrows(IllegalStateException.class,
                () -> controller.fetch(request, "ETB_HLI")));
    }
}
