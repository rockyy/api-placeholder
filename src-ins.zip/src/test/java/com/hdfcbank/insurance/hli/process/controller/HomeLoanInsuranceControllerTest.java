package com.hdfcbank.insurance.hli.process.controller;

import com.hdfcbank.common.models.vo.core.ApiResponse;
import com.hdfcbank.insurance.adapter.process.models.response.PremiumQuestionResponse;
import com.hdfcbank.insurance.hli.process.models.request.CallbackRequest;
import com.hdfcbank.insurance.hli.process.models.enums.CallbackType;
import com.hdfcbank.insurance.hli.process.models.response.CallbackResponse;
import com.hdfcbank.insurance.hli.process.models.response.HLILoanDetailResponse;
import com.hdfcbank.insurance.hli.process.service.CallbackService;
import com.hdfcbank.insurance.hli.process.service.HLIDetailService;
import com.hdfcbank.insurance.hli.process.service.HLIProductService;
import com.hdfcbank.insurance.hli.process.service.impl.HLIPricingImpl;
import com.hdfcbank.insurance.hli.process.service.impl.HLIQuestionServiceImpl;
import com.hdfcbank.insurance.hli.scheduler.IPFSchedulerService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@ExtendWith(MockitoExtension.class)
class HomeLoanInsuranceControllerTest {
    @Mock private HLIDetailService detailService;
    @Mock private HLIProductService productService;
    @Mock private HLIPricingImpl pricingService;
    @Mock private HLIQuestionServiceImpl questionService;
    @Mock private CallbackService callbackService;
    @Mock private IPFSchedulerService schedulerService;
    @InjectMocks private HomeLoanInsuranceController controller;
    private MockMvc mvc;

    @BeforeEach
    void setUp() {
        // Standalone MVC exercises JSON binding and @Valid without infrastructure or AOP.
        mvc = MockMvcBuilders.standaloneSetup(controller)
                .addPlaceholderValue("app.base-path", "/api/v1/hli/insurance").build();
    }

    @Test
    void cancellationCompletesBeforeRefetchingDetails() {
        var expected = ApiResponse.success(new HLILoanDetailResponse());
        when(detailService.fetchLoanDetail()).thenReturn(expected);
        assertSame(expected, controller.cancelPreviousJourneys());
        var order = inOrder(detailService);
        order.verify(detailService).cancelAllJourneys();
        order.verify(detailService).fetchLoanDetail();
    }

    @Test
    void cancellationFailurePreventsDetailFetch() {
        doThrow(new IllegalStateException("cancel failed")).when(detailService).cancelAllJourneys();
        assertThrows(IllegalStateException.class, controller::cancelPreviousJourneys);
        verify(detailService, never()).fetchLoanDetail();
    }

    @Test
    void validPricingQuestionRequestIsBoundAndPassedToService() throws Exception {
        when(pricingService.fetchPricingDetails(any())).thenReturn(ApiResponse.success(new PremiumQuestionResponse()));
        mvc.perform(post("/api/v1/hli/insurance/fetchPriceQuestions")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"products\":[{\"code\":\"HDFC_3D\",\"entityIds\":[\"C123\"]}]}"))
                .andExpect(status().isOk()).andExpect(jsonPath("$.status.code").value("0000"));
        verify(pricingService).fetchPricingDetails(argThat(r -> r.getProducts().size() == 1
                && "HDFC_3D".equals(r.getProducts().getFirst().getCode())
                && r.getProducts().getFirst().getEntityIds().equals(java.util.List.of("C123"))));
    }

    @ParameterizedTest
    @ValueSource(strings = {
            "{}", "{\"products\":[]}",
            "{\"products\":[{\"code\":\" \",\"entityIds\":[\"C123\"]}]}",
            "{\"products\":[{\"code\":\"HDFC_3D\",\"entityIds\":[]}]}",
            "{\"products\":[{\"code\":\"HDFC_3D\",\"entityIds\":[\" \"]}]}"})
    void invalidPricingQuestionsAreRejectedBeforeServiceCall(String json) throws Exception {
        mvc.perform(post("/api/v1/hli/insurance/fetchPriceQuestions")
                        .contentType(MediaType.APPLICATION_JSON).content(json))
                .andExpect(status().isBadRequest());
        verifyNoInteractions(pricingService);
    }

    @Test
    void invalidStaticDobIsRejectedBeforeIdentification() throws Exception {
        mvc.perform(post("/api/v1/hli/insurance/identify").contentType(MediaType.APPLICATION_JSON)
                        .content("{\"loanFileNumber\":\"1234567890\",\"source\":\"STATIC\",\"dob\":\"invalid\"}"))
                .andExpect(status().isBadRequest());
        verifyNoInteractions(detailService);
    }

    @Test
    void callbackDispatchReturnsServiceResponse() {
        var request = CallbackRequest.builder().callbackType(CallbackType.CANCEL_LEAD).data("{}").build();
        var expected = ApiResponse.success(CallbackResponse.builder().message("Success").build());
        when(callbackService.performAction(request)).thenReturn(expected);
        assertSame(expected, controller.executeAction(request));
    }
}
