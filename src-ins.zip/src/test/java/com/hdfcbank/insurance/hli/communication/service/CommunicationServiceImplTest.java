package com.hdfcbank.insurance.hli.communication.service;

import com.hdfcbank.adapters.clients.feign.journey.JourneyServiceFeignClient;
import com.hdfcbank.common.models.vo.journey.JourneyData;
import com.hdfcbank.insurance.adapter.communication.request.GenerateOTPRequest;
import com.hdfcbank.insurance.adapter.communication.request.ValidateOTPRequest;
import com.hdfcbank.insurance.adapter.communication.response.GenerateOTPResponse;
import com.hdfcbank.insurance.adapter.communication.response.ValidateOTPResponse;
import com.hdfcbank.insurance.hli.communication.consent.HLIOTPResponseMapper;
import com.hdfcbank.insurance.hli.communication.consent.model.HLICustomerConsentRequest;
import com.hdfcbank.insurance.hli.communication.consent.service.ConsentService;
import com.hdfcbank.insurance.hli.communication.otp.mapper.HLIOTPMapper;
import com.hdfcbank.insurance.hli.communication.otp.models.request.HLIValidateRequest;
import com.hdfcbank.insurance.hli.communication.otp.models.response.HLIConsentResponse;
import com.hdfcbank.insurance.hli.communication.otp.service.impl.CommunicationServiceCall;
import com.hdfcbank.insurance.hli.communication.otp.service.impl.CommunicationServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import java.util.List;
import static com.hdfcbank.insurance.hli.common.enums.JourneyStateName.*;
import static com.hdfcbank.insurance.hli.support.JourneyTestData.*;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class CommunicationServiceImplTest {
    @Mock private JourneyServiceFeignClient journeyClient;
    @Mock private HLIOTPResponseMapper responseMapper;
    @Mock private ConsentService consentService;
    @Mock private CommunicationServiceCall communicationCall;
    @Mock private HLIOTPMapper requestMapper;
    @InjectMocks private CommunicationServiceImpl service;
    private JourneyData journeyData;

    @BeforeEach
    void setUp() {
        journeyData = journey();
        when(journeyClient.fetch(JOURNEY_ID)).thenReturn(journeyData);
    }

    @Test
    void generateOtpMapsRequestAndResponseAndRecordsStatesInOrder() {
        var request = mock(GenerateOTPRequest.class);
        var downstream = mock(GenerateOTPResponse.class);
        var expected = new HLIConsentResponse();
        when(requestMapper.toGenerateOTPRequest(journeyData)).thenReturn(request);
        when(communicationCall.sendOtp(JOURNEY_ID, request)).thenReturn(downstream);
        when(responseMapper.otpResponseMapper(downstream)).thenReturn(expected);
        var response = service.generateOTP(JOURNEY_NAME, JOURNEY_ID);
        assertEquals("0000", response.getStatus().getCode());
        assertSame(expected, response.getData());
        var order = inOrder(journeyClient, communicationCall);
        order.verify(journeyClient).updateJourneyState(JOURNEY_ID, SEND_OTP_INITIATED.name());
        order.verify(communicationCall).sendOtp(JOURNEY_ID, request);
        order.verify(journeyClient).updateJourneyState(JOURNEY_ID, SEND_OTP_SUCCESS.name());
        verifyNoInteractions(consentService);
    }

    @Test
    void generateOtpPropagatesDownstreamFailureWithoutRecordingSuccess() {
        var request = mock(GenerateOTPRequest.class);
        var failure = new IllegalStateException("OTP unavailable");
        when(requestMapper.toGenerateOTPRequest(journeyData)).thenReturn(request);
        when(communicationCall.sendOtp(JOURNEY_ID, request)).thenThrow(failure);
        assertSame(failure, assertThrows(IllegalStateException.class,
                () -> service.generateOTP(JOURNEY_NAME, JOURNEY_ID)));
        verify(journeyClient, never()).updateJourneyState(JOURNEY_ID, SEND_OTP_SUCCESS.name());
        verifyNoInteractions(responseMapper, consentService);
    }

    @Test
    void matchedOtpStoresAcceptedAndDeclinedConsents() {
        var request = validationRequest();
        var mapped = mock(ValidateOTPRequest.class);
        var downstream = mock(ValidateOTPResponse.class);
        when(requestMapper.toValidateOTPRequest(request)).thenReturn(mapped);
        when(communicationCall.validateOTPCall(mapped, JOURNEY_ID)).thenReturn(downstream);
        when(downstream.isMatched()).thenReturn(true);
        var response = service.validateCustomer(JOURNEY_NAME, JOURNEY_ID, request);
        assertEquals("0000", response.getStatus().getCode());
        assertTrue(response.getData().isOtpValidated());
        assertEquals(0, response.getData().getIncorrectAttempts());
        var consents = ArgumentCaptor.forClass(HLICustomerConsentRequest.class);
        verify(consentService).storeConsentsData(consents.capture(), same(journeyData));
        var captured = consents.getValue().getCustomerConsentRequest();
        assertEquals(List.of("mandatory", "optional"), captured.stream().map(c -> c.getKey()).toList());
        assertTrue(captured.get(0).isAcceptance());
        assertFalse(captured.get(1).isAcceptance());
        var order = inOrder(journeyClient, communicationCall, consentService);
        order.verify(journeyClient).updateJourneyState(JOURNEY_ID, VALIDATE_OTP_INITIATED.name());
        order.verify(communicationCall).validateOTPCall(mapped, JOURNEY_ID);
        order.verify(journeyClient).updateJourneyState(JOURNEY_ID, VALIDATE_OTP_SUCCESS.name());
        order.verify(consentService).storeConsentsData(any(), same(journeyData));
    }

    @Test
    void unmatchedOtpRecordsFailureAndDoesNotStoreConsents() {
        var request = validationRequest();
        var mapped = mock(ValidateOTPRequest.class);
        var downstream = mock(ValidateOTPResponse.class);
        when(requestMapper.toValidateOTPRequest(request)).thenReturn(mapped);
        when(communicationCall.validateOTPCall(mapped, JOURNEY_ID)).thenReturn(downstream);
        var response = service.validateCustomer(JOURNEY_NAME, JOURNEY_ID, request);
        assertEquals("0000", response.getStatus().getCode());
        assertFalse(response.getData().isOtpValidated());
        assertEquals(1, response.getData().getIncorrectAttempts());
        verify(journeyClient).updateJourneyState(JOURNEY_ID, VALIDATE_OTP_FAILED.name());
        verify(journeyClient, never()).updateJourneyState(JOURNEY_ID, VALIDATE_OTP_SUCCESS.name());
        verifyNoInteractions(consentService);
    }

    @Test
    void validationCallFailureDoesNotRecordSuccessOrStoreConsents() {
        var request = validationRequest();
        var mapped = mock(ValidateOTPRequest.class);
        when(requestMapper.toValidateOTPRequest(request)).thenReturn(mapped);
        when(communicationCall.validateOTPCall(mapped, JOURNEY_ID)).thenThrow(new IllegalStateException("timeout"));
        assertThrows(IllegalStateException.class,
                () -> service.validateCustomer(JOURNEY_NAME, JOURNEY_ID, request));
        verify(journeyClient, never()).updateJourneyState(JOURNEY_ID, VALIDATE_OTP_SUCCESS.name());
        verifyNoInteractions(consentService);
    }

    private HLIValidateRequest validationRequest() {
        return HLIValidateRequest.builder().otp("123456").txnRef("TXN123")
                .logInConsentData(List.of(
                        HLIValidateRequest.LogInConsentData.builder().consentKey("mandatory").consentAccepted(true).build(),
                        HLIValidateRequest.LogInConsentData.builder().consentKey("optional").consentAccepted(false).build()))
                .build();
    }
}
