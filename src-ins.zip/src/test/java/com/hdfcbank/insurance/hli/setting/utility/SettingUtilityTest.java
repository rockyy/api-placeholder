package com.hdfcbank.insurance.hli.setting.utility;

import org.junit.jupiter.api.Test;
import reactor.util.function.Tuples;
import tools.jackson.databind.JsonNode;
import tools.jackson.databind.ObjectMapper;
import static org.junit.jupiter.api.Assertions.*;

class SettingUtilityTest {
    private final SettingUtility utility = new SettingUtility();
    private final ObjectMapper mapper = new ObjectMapper();

    @Test
    void cacheProbeWithoutTupleReturnsNull() {
        assertNull(utility.mergeConfigAndConsents(null, "ETB_HLI"));
    }

    @Test
    void mergesConsentsAndPreservesConfiguration() {
        JsonNode config = mapper.readTree("{\"maintenanceWindow\":\"disabled\",\"consents\":[]}");
        JsonNode consents = mapper.readTree("[{\"key\":\"mandatory\"}]");
        var result = utility.mergeConfigAndConsents(Tuples.of(config, consents), "ETB_HLI");
        assertEquals("disabled", result.path("maintenanceWindow").asText());
        assertEquals(consents, result.path("consents"));
    }
}
