package com.hdfcbank.insurance.hli.communication.service;

import com.hdfcbank.common.models.vo.journey.Profile;
import com.hdfcbank.insurance.hli.communication.consent.config.ConsentsApiProperties;
import com.hdfcbank.insurance.hli.communication.consent.model.CustomerConsentRequest;
import com.hdfcbank.insurance.hli.communication.consent.model.HLICustomerConsentRequest;
import com.hdfcbank.insurance.hli.communication.consent.service.ConsentService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;
import software.amazon.awssdk.services.sqs.SqsClient;
import software.amazon.awssdk.services.sqs.model.SendMessageRequest;
import software.amazon.awssdk.services.sqs.model.SendMessageResponse;
import tools.jackson.databind.ObjectMapper;
import java.time.Instant;
import java.util.List;
import static com.hdfcbank.insurance.hli.support.JourneyTestData.*;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ConsentServiceTest {
    @Mock private SqsClient sqsClient;
    private ConsentService service;

    @BeforeEach
    void setUp() {
        service = new ConsentService();
        var properties = new ConsentsApiProperties();
        properties.setQueueUrl("https://sqs.example.test/consents");
        ReflectionTestUtils.setField(service, "sqsClient", sqsClient);
        ReflectionTestUtils.setField(service, "consentsApiProperties", properties);
    }

    @Test
    void publishesCustomerAndConsentPayloadWithUtcCaptureTime() {
        var data = journey();
        data.setProfile(Profile.builder().panNumber("ABCDE1234F").customerFullName("Test User")
                .dateOfBirth("15/01/1988").build());
        var request = HLICustomerConsentRequest.builder().customerConsentRequest(List.of(
                CustomerConsentRequest.builder().key("mandatory").acceptance(true).build(),
                CustomerConsentRequest.builder().key("optional").acceptance(false).build())).build();
        when(sqsClient.sendMessage(any(SendMessageRequest.class))).thenReturn(SendMessageResponse.builder().messageId("MSG1").build());
        service.storeConsentsData(request, data);
        var message = ArgumentCaptor.forClass(SendMessageRequest.class);
        verify(sqsClient).sendMessage(message.capture());
        assertEquals("https://sqs.example.test/consents", message.getValue().queueUrl());
        var json = new ObjectMapper().readTree(message.getValue().messageBody());
        assertEquals(JOURNEY_ID, json.path("journeyId").asText());
        assertEquals(JOURNEY_NAME, json.path("journeyName").asText());
        var customer = json.path("customerDetails");
        assertEquals("ABCDE1234F", customer.path("pan").asText());
        assertEquals("Test User", customer.path("firstName").asText());
        assertEquals("+919876543210", customer.path("identifier").asText());
        assertEquals("MOBILE_NUMBER", customer.path("identifierType").asText());
        assertTrue(customer.path("consents").get(0).path("acceptance").asBoolean());
        assertFalse(customer.path("consents").get(1).path("acceptance").asBoolean());
        assertDoesNotThrow(() -> Instant.parse(customer.path("consentsCapturedDate").asText()));
    }
}
