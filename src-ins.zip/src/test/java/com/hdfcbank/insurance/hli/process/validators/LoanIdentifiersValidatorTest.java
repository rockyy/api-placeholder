package com.hdfcbank.insurance.hli.process.validators;

import com.hdfcbank.insurance.hli.process.annotations.HLIRequestValidator;
import com.hdfcbank.insurance.hli.process.models.enums.SourceSystem;
import com.hdfcbank.insurance.hli.process.models.request.HLIIdentifyRequest;
import jakarta.validation.ConstraintValidatorContext;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class LoanIdentifiersValidatorTest {
    private final LoanIdentifiersValidator validator = new LoanIdentifiersValidator();
    private final ConstraintValidatorContext context = mock(ConstraintValidatorContext.class, RETURNS_DEEP_STUBS);

    @BeforeEach
    void initialize() {
        validator.initialize(HLIIdentifyRequest.class.getAnnotation(HLIRequestValidator.class));
    }

    @Test
    void acceptsStaticLoginWithDayMonthYearDob() {
        assertTrue(validator.isValid(request(SourceSystem.STATIC, "15/01/1988"), context));
    }

    @Test
    void dynamicLoginDoesNotRequireDob() {
        assertTrue(validator.isValid(request(SourceSystem.DYNAMIC, null), context));
    }

    @Test
    void rejectsStaticLoginWithoutDob() {
        assertFalse(validator.isValid(request(SourceSystem.STATIC, null), context));
        verify(context).disableDefaultConstraintViolation();
    }

    @ParameterizedTest
    @ValueSource(strings = {"", " ", "1988-01-15", "15-01-1988", "invalid"})
    void rejectsUnsupportedDobFormats(String dob) {
        assertFalse(validator.isValid(request(SourceSystem.STATIC, dob), context));
    }

    private HLIIdentifyRequest request(SourceSystem source, String dob) {
        return HLIIdentifyRequest.builder().source(source).loanFileNumber("1234567890").dob(dob).build();
    }
}
