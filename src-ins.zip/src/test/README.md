# Insurance BFF unit tests

Tests follow the current production classes, request constraints, and journey states. Production sources and the POM are unchanged.

## Run

Use JDK 25 and Maven with the team's repository settings for the private HDFC artifacts, including `com.hdfcbank:iop-insurance-adapter:0.0.3-release`:

```sh
mvn -s /path/to/settings.xml clean test jacoco:report
```

For an exported source directory without `.git`, append `-Dmaven.gitcommitid.skip=true`. This skips only Git metadata generation.

Maven Surefire writes test results to `target/surefire-reports`. JaCoCo writes HTML and XML coverage reports to `target/site/jacoco`.

## Scope

- Loan identification, STATIC/DYNAMIC identifiers, masking, loan details, cancellation, KFS, e-sign status/resend, and final proposal payload/persistence.
- Product decision parameters, catalog mapping, pricing request reuse, answer defaults/lookups, EMI calculations, and failure propagation.
- Proposal submission and LG/LC details, callback dispatch and persistence, and scheduler status processing.
- OTP generation/validation, accepted and declined consents, SQS message contents, and cooling-period persistence.
- Custom request validators, standalone MVC JSON binding/validation, settings merging/cache behavior, checksum normalization, nominee age boundaries, and journey path helpers.
- Journey prerequisite advice through a real Spring AOP proxy, including context cleanup on success and failure; process/communication response-code handling.

Service tests mock remote clients and repositories. Pricing and scheduler tasks execute inline in tests; there are no real timers, network calls, MongoDB, Redis, SQS, or config-server connections. Standalone MVC tests exercise binding and `@Valid`; they do not exercise the application's security filters or cooling-period aspects from dependencies.

The suite tests supported current behavior. The production gaps found in the review (pricing response freshness, reference/journey identifier consistency, retry bookkeeping, nested validation wiring, failure-recorder initialization and failure-context cleanup) are still separate production changes. A passing suite does not resolve those gaps or establish that the parent POM's coverage thresholds are met.
